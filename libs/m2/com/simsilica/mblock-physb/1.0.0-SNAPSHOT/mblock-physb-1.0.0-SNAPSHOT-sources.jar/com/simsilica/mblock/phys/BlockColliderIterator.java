/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.BlockIterator.Intersection;

/**
 *  Wraps a block BlockIterator to provide additional collider-based
 *  intersection detection.  A BlockIterator will intersect with any
 *  call that has a BlockType but BlockColliderIterator will filter
 *  out results where the ray doesn't hit the collider itself.
 *
 *  @author    Paul Speed
 */
public class BlockColliderIterator implements Iterator<BlockIterator.Intersection> {
    static Logger log = LoggerFactory.getLogger(BlockColliderIterator.class);

    private BlockIterator delegate;
    private Collider[] colliders;

    private Intersection next;

    public BlockColliderIterator( BlockIterator delegate, Collider[] colliders ) {
        this.delegate = delegate;
        this.colliders = colliders;
    }

    private Collider getCollider( int type ) {
        if( type < 0 ) {
            return null;
        }
        return colliders[type];
    }

    protected void fetch() {
        if( next != null ) {
            // We already have one pending
            return;
        }
        // Grab one from the delegate until we have one we actually hit
        while( delegate.hasNext() ) {
            Intersection blockNext = delegate.next();

            Collider collider = getCollider(blockNext.getType());
            if( collider == null ) {
                // Can't click on it
                log.info("no collider for:" + blockNext);
                continue;
            }

            // See if the ray actually hits
            Rayd ray = delegate.getRay();

            // Collider's will want a block-local origin for the ray
            Vec3d origin = ray.getOrigin();
            Vec3i blockIntersect = blockNext.getBlock();
            Vec3d rayOrigin = new Vec3d(origin.x - blockIntersect.x,
                                        origin.y - blockIntersect.y,
                                        origin.z - blockIntersect.z);

            // We pass the full side mask because I think we don't care what
            // is/isn't visible with respect to 'hits'.  I could be wrong but
            // then future me should document that here.  We technically have the
            // mask in the intersection data.
            RayHit hit = collider.getHit(rayOrigin, ray.getDirection(), 0xff, null);
            
            if( hit == null ) {
                continue;
            }

            // We found a valid hit and can update the intersecction data with
            // more accurate information.  Note: we might want to extend Intersection
            // to a local subclass to have a separate normal.  On the one hand, the
            // actual hit normal is bound to be useful but on the other hand, trying to
            // figure out "neighbor block" is going to be weird for some cases.
            // Thinking of wedges, though... it almost makes sense to place on the
            // collision normal's block instead of the flat normals.  Click properly.
            // The 'hit' location is relative to the block's origin
            Vec3d hitWorld = hit.point.add(blockIntersect);
            next = new Intersection(hitWorld, blockNext.getBlock(), blockNext.getType(), 
                                    blockNext.getCellValue(), hit.normal);

            break;
        }
    }

    public boolean hasNext() {
        fetch();
        return next != null;
    }

    @Override
    public Intersection next() {
        fetch();
        Intersection result = next;
        next = null;
        return result;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException( "Remove not supported on intersectors." );
    }
}


