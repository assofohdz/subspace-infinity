/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MassUtils {

    static Logger log = LoggerFactory.getLogger(MassUtils.class);

    public static double getMass( int type ) {
        // For now just a constant for solid blocks
        return type == 0 ? 0 : 1;
    }

    public static BodyMass calculateBodyMass( Group group ) {

//log.info("calculateBodyMass(" + group.getName() + ")");
        // Calculate the CoG of all of the child masses
        double totalMass = 0;
        Vec3d center = new Vec3d();

        // can only call traverse() from roots... and apparently
        // some things call it on child groups.
        for( Part child : group.getChildren() ) {
        //for( Part child : group.traverse() ) {
//log.info(" child part:" + child.getName());
            BodyMass m = child.getMass();
//log.info("  part inverseMass:" + m.getInverseMass());
            if( m.getInverseMass() == 0 ) {
                //return null;  // it's a static object
                // Well, a static child anyway... there might be
                // other non-static children.
                continue;
            }
            double mass = 1/m.getInverseMass();
            totalMass += mass;

            // Positions are relative to the 'model' origin which
            // should be offset by CoG.
            //Vec3d pos = child.getBodyPosition();
            //pos = pos.subtract(m.getCog());
            Vec3d pos = child.getLocalPosition();
            pos = pos.add(child.getLocalOrientation().mult(m.getCog()));

//log.info("  body pos:" + child.getShapeRelativePosition() + "  cog:"
//            + m.getCog() + "  pos:" + pos + "  mass:" + mass);
            center.addLocal(pos.x * mass, pos.y * mass, pos.z * mass);
        }
        if( totalMass == 0 ) {
            return null;
        }
        center.multLocal(1/totalMass);
//log.info("center:" + center);

        // Now that we have the center we can build up the inertia tensor
        // and cog-relative mass radius, etc.
        double radius = 0;

        double[][] tensor = new double[3][3];
        int X = 0;
        int Y = 1;
        int Z = 2;

        for( Part child : group.getChildren() ) {
        //for( Part child : group.traverse() ) {
            BodyMass bodyMass = child.getMass();
            double m = 1/bodyMass.getInverseMass();

            // Maybe we should have kept the original around
            Matrix3d imt = bodyMass.getInverseMassTensor();
            Matrix3d mt = imt.invert();
            //log.info("imt:" + imt);
            //log.info("mt:" + mt);

            // Now... with parallel axis theorem we should be
            // able to shift the moments of inertia (the diagonal)
            // ...but I'm going to be guessing about the products of
            // inertia because I apparently didn't keep good notes
            // on where I read about that before.

            //Vec3d pos = child.getBodyPosition();
            //pos = pos.subtract(bodyMass.getCog());
            Vec3d pos = child.getLocalPosition();
            pos = pos.add(child.getLocalOrientation().mult(bodyMass.getCog()));

//            log.info("child position:" + pos);
//            log.info("child radius:" + bodyMass.getRadius());

            double x = pos.x - center.x;
            double y = pos.y - center.y;
            double z = pos.z - center.z;

            // Moments of inertia shifted with the parallel axis theorem
            tensor[X][X] += mt.m00 + m * y * y + z * z;
            tensor[Y][Y] += mt.m11 + m * x * x + z * z;
            tensor[Z][Z] += mt.m22 + m * x * x + y * y;

            // Products of inertia
            double xy = -(m * x * y);
            double yz = -(m * y * z);
            double zx = -(m * z * x);

            tensor[X][Y] += xy;
            tensor[Y][X] += xy;
            tensor[Y][Z] += yz;
            tensor[Z][Y] += yz;
            tensor[Z][X] += zx;
            tensor[X][Z] += zx;

            // Calculate the maximum radius while we are here
            double dist = Math.sqrt(x * x + y * y + z * z) + bodyMass.getRadius();
////log.info("outer dist:" + dist);
            if( dist > radius ) {
                radius = dist;
            }
        }

////        log.info("final radius:" + radius);

        Matrix3d inertiaTensor = new Matrix3d(
            tensor[0][0], tensor[0][1], tensor[0][2],
            tensor[1][0], tensor[1][1], tensor[1][2],
            tensor[2][0], tensor[2][1], tensor[2][2]
            );

        Matrix3d inverseInertiaTensor = inertiaTensor.invert();

        return new BodyMass(1/totalMass, inverseInertiaTensor, center, radius);
    }

    public static BodyMass calculateBodyMass( CellArray cells, double scale, double mass ) {

        // Calculate the CoG
        double totalMass = 0;
        Vec3d center = new Vec3d();

        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();

        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int value = cells.getCell(i, j, k);
                    int type = MaskUtils.getType(value);

                    double m = getMass(type);

                    totalMass += m;

                    // Add the scaled vector location of the center of this
                    // cell.  Scaling by the individual mass adjusts the influence
                    // of this cell from the overall mass.
                    center.addLocal((i + 0.5) * scale * m, (j + 0.5) * scale * m, (k + 0.5) * scale * m);
                }
            }
        }
        if( totalMass == 0 ) {
            // Empty block
            return null;
        }
        center.multLocal(1/totalMass);

        //log.info("Center of gravity:" + center);
//        System.out.println("Center of gravity:" + center);
//        System.out.println("total mass:" + totalMass);

        // We want our total final mass to be what the user passed in...
        // if they passed in a real value.
        double massScale = 1;
        if( mass > 0 ) {
            massScale = mass / totalMass;
//            log.info("Mass scale:" + massScale);
        }

        // http://hyperphysics.phy-astr.gsu.edu/hbase/mi.html
        // http://physics.usask.ca/~chang/course/ep324/lecture/lecture3.pdf
        // https://en.wikipedia.org/wiki/List_of_moments_of_inertia
        // https://gafferongames.com/post/rotation_and_inertia_tensors/  (just someone crazier than me)
        //
        // Wish I'd found this one before working out all of the below but oh well:
        // http://dmorris.net/projects/tutorials/inertia.tensor.summary.pdf
        // ...it doesn't answer the equation questions really but is a nice introduction
        // that might have made the other material easier to read.


        // General Thoughts (my own brain, may be totally wrong)
        // -----------------
        // Primary moments of inertia are the diagonal of the inertia tensor.
        // Products of inertia are the other cells in the 3x3 matrix:
        //
        //  Ixx  -Ixy  -Ixz
        // -Iyx   Iyy  -Iyz
        // -Izx  -Izy   Izz
        //
        // Ixx, Iyy, Izz are the principle moments of inertia.
        //
        // There is some kind of symmetrical relationship between the
        // products of inertia just based on simple math:
        // Iyx = Ixy for example.
        //
        // Moment of inertia thoughts
        // ------------------------------
        // moment of inertia of a point at x, y, z with mass m
        // Ixx = (y^2 + z^2) * m
        //
        // I think this matches with parallel axis theorem which says that
        // some Moment of Inertia G at gx, gy, gz can be calculated as:
        // Ixx = Gxx + m * (gy^2 + zg^2)
        //
        // Because given the first equation, the Ixx of a point mass on its
        // own would be (0^2 + 0^2) * m = 0... Gxx = 0 to begin with so
        // Ixx = m * (gy^2 + zg^2)
        //
        //
        // Products of Inertia thoughts
        // -----------------------------
        // product of inertia relative to two of the orthogonal planes..
        // say, y-z and x-z if we are calculating in the x-y plane.
        // (three planes: x-y, x-z, y-z, for any targeted plane, we use
        //  the other two.)
        //
        // m * r1 * r2  where r1 is the shortest distance to plane1 and r2
        //              is the shortest distance to plane 2.
        //
        // So Ixy = x * y * m  ...since x is the distance from the y-z plane
        //                        and y is the distance from the x-z plane.
        //
        // Once again, the product for a point mass is going to be 0.
        // m * 0 * 0
        //
        // So this also matches the parallel-plane theorem:
        // Ixy = Gxy + m * gx * gy ...since Gxy is 0
        //
        //
        // Point mass versus cube mass
        // -------------------------------
        // Now, technically we are dealing with cubes and not point masses
        // but in a lot of ways we treat them as tiny spheres for collisions
        // and stuff... maybe we can get away with point masses.  Note: that
        // this becomes less of a strong argument when we start handling partial
        // blocks (though even in that case, one half of the collision is still
        // going to be treated like a point mass so it's not clear which is better.)
        //

        double[][] tensor = new double[3][3];
        int X = 0;
        int Y = 1;
        int Z = 2;

        double radiusSq = 0;

        double totalPointMass = 0;

        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int value = cells.getCell(i, j, k);
                    int type = MaskUtils.getType(value);

                    double m = getMass(type) * massScale;

totalPointMass += m;
                    // A cube would have a particular intertia tensor to start
                    // with... more than just a 0 for a point mass
                    // G = m * 1.0 / 6.0;
                    double g = m * 1.0 / 6.0;

                    double x = ((i + 0.5) * scale) - center.x;
                    double y = ((j + 0.5) * scale) - center.y;
                    double z = ((k + 0.5) * scale) - center.z;

                    // Moments of inertia
                    tensor[X][X] += g + m * y * y + z * z;
                    tensor[Y][Y] += g + m * x * x + z * z;
                    tensor[Z][Z] += g + m * x * x + y * y;

                    // Products of inertia
                    double xy = -(m * x * y);
                    double yz = -(m * y * z);
                    double zx = -(m * z * x);
                    tensor[X][Y] += xy;
                    tensor[Y][X] += xy;
                    tensor[Y][Z] += yz;
                    tensor[Z][Y] += yz;
                    tensor[Z][X] += zx;
                    tensor[X][Z] += zx;

                    // See if this particle increases our radius
                    // Make sure the distance includes the corner of the cube
                    x = Math.abs(x) + 0.5 * scale;
                    y = Math.abs(y) + 0.5 * scale;
                    z = Math.abs(z) + 0.5 * scale;
                    double dSq = x * x + y * y + z * z;
                    if( dSq > radiusSq ) {
                        radiusSq = dSq;
                    }
                }
            }
        }

        //for( int i = 0; i < 3; i++ ) {
        //    for( int j = 0; j < 3; j++ ) {
        //        System.out.print("[" + tensor[i][j] + "]");
        //    }
        //    System.out.println();
        //}

        // Cube tensor would be...
        // M * ((s * s)/6) on the diagonals.
        //double cube = totalMass * ((xSize * xSize) / 6.0);
        //
        // 1/6 * m * s^2
        //double cube = 1.0/6.0 * totalMass * xSize * xSize;
        //System.out.println("Natural cube:" + cube);

        //double unitCube = 1.0/6.0 * 1 * 1 * 1;
        //System.out.println("Unit cube:" + unitCube);

        Matrix3d inertiaTensor = new Matrix3d(
            tensor[0][0], tensor[0][1], tensor[0][2],
            tensor[1][0], tensor[1][1], tensor[1][2],
            tensor[2][0], tensor[2][1], tensor[2][2]
            );

        Matrix3d inverseInertiaTensor = inertiaTensor.invert();

        //System.out.println("Inverse:" + inverseInertiaTensor);

//log.info("scale:" + scale + "  mass:" + mass + "  calculated point mass:" + totalPointMass + "  totalMass:" + totalMass);
//log.info("inertia tensor:" + inertiaTensor);
//log.info("inverse:" + inverseInertiaTensor);
//log.info("inverse inverse:" + inverseInertiaTensor.invert());
//log.info("mass radius:" + Math.sqrt(radiusSq));

        if( mass <= 0 ) {
            // Caller wants us to use the calculated mass
            mass = totalMass;
        }

        return new BodyMass(1/mass, inverseInertiaTensor, center, Math.sqrt(radiusSq));
        //return new BodyMass(1/totalMass, inverseInertiaTensor, center);
    }
}


