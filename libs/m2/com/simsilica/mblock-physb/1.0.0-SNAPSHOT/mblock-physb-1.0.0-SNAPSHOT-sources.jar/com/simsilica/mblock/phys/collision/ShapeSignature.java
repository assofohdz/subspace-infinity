/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ShapeSignature {
    static Logger log = LoggerFactory.getLogger(ShapeSignature.class);

    private long bits;

    public ShapeSignature( long bits ) {
        this.bits = bits;
    }

    public ShapeSignature clone() {
        return new ShapeSignature(bits);
    }

    public ShapeSignature merge( ShapeSignature other ) {
        long combined = bits | other.bits;
        return new ShapeSignature(combined);
    }

    public void clear() {
        this.bits = 0;
    }

    public long getBits() {
        return bits;
    }

    protected int index( int i, int j, int k ) {
        return i * 16 + j * 4 + k;
    }

    protected long getToggleBit( int i, int j, int k ) {
        return 0x1L << index(i, j, k);
    }

    public void set( int i, int j, int k ) {
        long toggle = getToggleBit(i, j, k);
        bits = bits | toggle;
    }

    public void unset( int i, int j, int k ) {
        long toggle = getToggleBit(i, j, k);
        bits = bits & ~toggle;
    }

    public boolean isSet( int i, int j, int k ) {
        long toggle = getToggleBit(i, j, k);
        return (bits & toggle) == toggle;
    }

    @Override
    public String toString() {
        String value = String.format("%64s", Long.toBinaryString(bits));
        value = value.replace(' ', '0');
        return getClass().getSimpleName() + "[" + value + "]";
    }
}
