/*
 * $Id$
 *
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import java.util.Collections;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;


/**
 *  A single part of a shape hierarchy.
 *
 *  @author    Paul Speed
 */
public class CellArrayPart extends Part {

    static Logger log = LoggerFactory.getLogger(CellArrayPart.class);

    public enum Type { Sphere, Blocks };

    private Type type;
    private CellArray cells;
    private double scale;
    private double blockCollisionPriority;
    private double radius;
    private Vec3d center;

    public CellArrayPart( Type type, CellArray cells, double scale, double boundsRadius, BodyMass mass ) {
        this(new Vec3d(), type, cells, scale, boundsRadius, mass);
    }

    public CellArrayPart( Vec3d boundsCenter, Type type, CellArray cells, double scale, double boundsRadius, BodyMass mass ) {
        this("cellArray", boundsCenter, type, cells, scale, boundsRadius, mass);
    }

    public CellArrayPart( String name, Vec3d boundsCenter, Type type, CellArray cells, double scale, double boundsRadius, BodyMass mass ) {
        super(name);
//log.info("name:" + name + "  boundsCenter:" + boundsCenter + "  radius:"
//            + boundsRadius + "  cog:" + mass.getCog() + "  mass:" + mass);

        this.type = type;
        this.cells = cells;
        this.scale = scale;
        this.center = boundsCenter;
        this.radius = boundsRadius;
        setMass(mass);

        if( cells != null ) {
            // Largest volume wins by default...
            this.blockCollisionPriority = cells.getSizeX() * scale + cells.getSizeY() * scale + cells.getSizeZ() * scale;
        } else {
            // Use the sphere volume
            double r3 = (boundsRadius * scale);
            r3 = r3 * r3 * r3;
            this.blockCollisionPriority = 4/3.0 * Math.PI * r3;
        }
    }

    @Override
    public Part[] traverse() {
        // Could cache this
        return new Part[] { this };
    }

    @Override
    protected void markForRefresh( int flag ) {
        super.markForRefresh(flag);
        if( (flag & REFRESH_MASS) != 0 ) {
log.info("Who is refreshing mass of a cell part?", new Throwable("who?"));
        }
    }

    @Override
    protected void updateMass() {
        // Nothing to do
log.info("updatEMass()", new Throwable("why?"));
        // But clear the flags so we don't keep thinking we need updates
        clearRefreshNeeded(REFRESH_MASS);
    }

    // Note: as far as I can tell, this center is only informational and
    // not actually used for anything.  This part is never positioned relative
    // to its center.
    // Note2: I notice that AbstractShape uses the center for calculating
    // an AABB... but not our center.  It's just an arbitrary 0,0,0 we pass
    // in the MBlockShape constructor.  So probably something we are doing
    // incorrectly and/or don't need related to how grid cells are determined.
    public Vec3d getCenter() {
        if( isRefreshNeeded(REFRESH_MASS) ) {
            updateMass();
        }
        return center;
    }

    public double getRadius() {
        if( isRefreshNeeded(REFRESH_MASS) ) {
            updateMass();
        }
        return radius;
    }

    /**
     *  Returns the cell array that contains the combined type + side mask values for
     *  this shape.
     */
    public CellArray getCells() {
        return cells;
    }

    /**
     *  Allows resetting the cell array in very special cases where we might need
     *  a runtime modifiable collision shape and want to swap out a cached cell array
     *  for a unique one.
     */
    public void setCells( CellArray cells ) {
        this.cells = cells;
    }

    /**
     *  Given a coordinate in body space this will return the coordinate in part space,
     *  including any rescaling, etc..
     */
/*    public Vec3d toCellSpace( Vec3d bodySpace, Vec3d store ) {
        if( store == null ) {
            store = new Vec3d();
        }
        // Body space is relative to the CoG so we need to add it in
        store.set(bodySpace).addLocal(getMass().getCog());
        store.multLocal(1/scale);

        return store;
    }*/

    /**
     *  Returns the specified cell space coordinate in shape space where
     *  0, 0, 0 would be the lower corner of the lowest cell, 0.5, 0.5, 0.5
     *  would be the center of the lowest cell, etc..  "Shape space" is
     *  the space of the root-level shape... whose origin may not (probably
     *  never) coincide with the origin of the physics body itself.  For example,
     *  a point (0,0,0) in shape space is the origin of shape space but the
     *  shape is positioned relative to its CoG.  So if the CoG is (5, 5, 5)
     *  the (0,0,0) is really (-5, -5, -5) relative to the rigid body's
     *  position.
     */
    public Vec3d cellToShape( Vec3d cellSpace, Vec3d store ) {

        // Note: it's possible that we are not yet taking boundsCenter
        // properly into consideration.
        // No, bounds center has no use here.  Shape space is just
        // like any scene graph... we accumulate the positions and
        // rotations of the hierarchy.  And that's already done for
        // us by getShapeRelativeOrientation()/getShapeRelativePosition() methods.

//System.out.println("cellToShape(" + cellSpace + ")");
        if( store == null ) {
            store = cellSpace.mult(scale);
        } else {
            store = store.set(cellSpace);
            store.multLocal(scale);
        }

//System.out.println("CoG relative:" + store);

        // Calculate the position relative to the center of mass
//        store = store.subtractLocal(getMass().getCog());

//System.out.println("part local unrotated:" + store);

        // Rotate it into body space.  Remember, 'body orientation' in
        // this context is not the orientation of the body but our
        // overall orientation within the body.
        getShapeRelativeOrientation().mult(store, store);

//System.out.println("part local:" + store);

        // Translate it into body space
        store.addLocal(getShapeRelativePosition());

//System.out.println("body space:" + store);

        return store;
    }

    /**
     *  Returns the body position in cell space where body position
     *  is relative to the center of some cell.  shapeToCell(cellToShape(someValue))
     *  should return the same value (within margin of error).
     */
    public Vec3d shapeToCell( Vec3d bodySpace, Vec3d store ) {
//System.out.println("shapeToCell(" + bodySpace + ")");

        if( store == null ) {
            store = bodySpace.subtract(getShapeRelativePosition());
        } else {
            store.set(bodySpace).subtractLocal(getShapeRelativePosition());
        }
//System.out.println("part local:" + store);

        getShapeRelativeOrientation().inverse().mult(store, store);

//System.out.println("part local unrotated:" + store);

//        store.addLocal(getMass().getCog());
//System.out.println("CoG relative:" + store);

        store.multLocal(1/scale);

//System.out.println("cell space:" + store);

        return store;
    }

    /**
     *  Convenience method for going straight from cell space to world
     *  space.
     */
    public Vec3d cellToWorld( AbstractBody<?, MBlockShape> body, Vec3d cell, Vec3d store ) {
        store = cellToShape(cell, store);
        body.shape.shapeToBody(store, store);
        body.localToWorld(store, store);
        return store;
    }

    public Vec3d worldToCell( AbstractBody<?, MBlockShape> body, Vec3d world, Vec3d store ) {
        store = body.worldToLocal(world, store);
        body.shape.bodyToShape(store, store);
        shapeToCell(store, store);
        return store;
    }

    /**
     *  Convenience method for returning the world position of this
     *  shape.
     */
    public Vec3d getWorldPosition( AbstractBody<?, MBlockShape> body, Vec3d store ) {
        store = body.shape.shapeToBody(getShapeRelativePosition(), store);
        store = body.localToWorld(store, store);
        return store;
    }

    public void calculateBounds( Vec3d min, Vec3d max ) {
        if( type == Type.Sphere ) {
            // Special case with no cells.  We treat it as one 'block'
            // with the radius as its size.
            Vec3d center = cellToShape(new Vec3d(), null);
            double r = radius * scale; // I think we need to but not sure
            min.minLocal(center.subtract(r, r, r));
            max.maxLocal(center.add(r, r, r));
            return;
        }

        // Min/max only make sense in model space... so we can't transform them into
        // part space and adjust them.  We might be moving them in the wrong direction
        // because 'max' in part space is not the same as 'max' in model space.
        // Thus we have to transform every cell bounds into shape space, essentially.
        // There is probably a "quick" way to do this by projecting axes like the
        // collision system does, but if we want as accurate a 'box' as possible
        // then we end up reprojecting all four corners of the box, anyway.  We
        // can't really predict which corner will directly affect min/max.
        // And if we have to do calculations for four corners anyway... we might
        // as well just do the simple/slow way today.
        // For my needs today, it's better to be accurate than quick.
        // Could potentially project the shape axes into the part space and then
        // project block type min/max down the shape axes to find min/max in shape space.
        if( cells == null ) {
            log.warn("Cells null in calculateBounds(), type:" + type);
            min.set(0,0,0);
            max.set(1,1,1);
            return;
        }
        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();
        Vec3d cell = new Vec3d();
        Vec3d shape = new Vec3d();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int v = cells.getCell(i, j, k);
                    if( v == 0 ) {
                        continue;
                    }
                    int type = MaskUtils.getType(v);
                    if( type == 0 ) {
                        continue;
                    }
                    BlockType bt = BlockTypeIndex.get(type);
                    cell.set(i, j, k);
                    Vec3d btMin = bt.getFactory().getMin();
                    Vec3d btMax = bt.getFactory().getMax();

                    accumulateBlockBounds(cell, btMin, btMax, min, max);
                }
            }
        }
    }

    /**
     *  Returns the min/max in part space, no scale applied, etc..
     */
    public void calculateCellBounds( Vec3d min, Vec3d max ) {
        if( type == Type.Sphere ) {
            // Special case with no cells
            min.set(-radius, -radius, -radius);
            max.set(radius, radius, radius);
            return;
        }
        if( cells == null ) {
            log.warn("Cells null in calculateBounds(), type:" + type);
            min.set(0,0,0);
            max.set(0,0,0);
            return;
        }
        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();
        Vec3d cell = new Vec3d();
        Vec3d shape = new Vec3d();
        Vec3d pos = new Vec3d();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int v = cells.getCell(i, j, k);
                    if( v == 0 ) {
                        continue;
                    }
                    int type = MaskUtils.getType(v);
                    if( type == 0 ) {
                        continue;
                    }
                    pos.set(i, j, k);
                    BlockType bt = BlockTypeIndex.get(type);
                    cell.set(i, j, k);
                    Vec3d btMin = bt.getFactory().getMin();
                    Vec3d btMax = bt.getFactory().getMax();

                    min.minLocal(pos.add(btMin));
                    max.maxLocal(pos.add(btMax));
                }
            }
        }
    }

    protected void accumulateBlockBounds( Vec3d pos, Vec3d btMin, Vec3d btMax, Vec3d targetMin, Vec3d targetMax ) {
        accumuluteBounds(pos.add(btMin.x, btMin.y, btMin.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMin.x, btMin.y, btMax.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMin.x, btMax.y, btMin.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMin.x, btMax.y, btMax.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMax.x, btMin.y, btMin.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMax.x, btMin.y, btMax.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMax.x, btMax.y, btMin.z), targetMin, targetMax);
        accumuluteBounds(pos.add(btMax.x, btMax.y, btMax.z), targetMin, targetMax);
    }

    protected void accumuluteBounds( Vec3d pos, Vec3d min, Vec3d max ) {
        Vec3d shape = cellToShape(pos, null);
        min.minLocal(shape);
        max.maxLocal(shape);
    }

    //public final Vec3d localToWorld( Vec3d cellSpace, Vec3d store ) {
    //}

/*
     public final Vec3d worldToLocal( Vec3d point, Vec3d store ) {
//System.out.println("--worldToLocal(" + point + ")");
        if( store == null ) {
            store = point.subtract(position);
        } else {
            store.set(point).subtractLocal(position);
        }
//System.out.println("   translated:" + store);

        // Then 'unrotate' it
        orientation.inverse().mult(store, store);

//System.out.println("   inverse rotated:" + store);

        return store;
    }
 */
    /**
     *  Transforms a point from object space to world space.
     *//*
    public Vec3d localToWorld( Vec3d point, Vec3d store ) {
//System.out.println("--localToWorld(" + point + ")");
        if( store == null ) {
            store = orientation.mult(point);
        } else {
            store = orientation.mult(point, store);
        }
//System.out.println("   rotated:" + store);
        store.addLocal(position);
//System.out.println("   retranslated:" + store);

        return store;
    }*/


    public static CellArrayPart createShape( CellArray cells, double scale, double mass ) {
        return createShape("cellArray", cells, scale, mass);
    }

    public static CellArrayPart createShape( String name, CellArray cells, double scale, double mass ) {

        // Need to calculate a reasonably accurate radius and center
        // so that a broad phase would accurately accept/reject this shape.
        // We could be smart about which blocks are on/off but for now will
        // just shrink a sphere around the whole cell array.  This will always
        // be at least as big as anything in the array but probably too big
        // in many cases.
        Vec3i size = cells.getSize();
        Vec3d center = size.toVec3d().multLocal(0.5 * scale);

        double radius = center.length();

        BodyMass bm = MassUtils.calculateBodyMass(cells, scale, mass);
        if( bm == null ) {
            //throw new IllegalArgumentException("Cells generated no body mass");
            log.warn("Cells generated no body mass, name:" + name + " cells.size:" + cells.getSize() + " scale:" + scale + " mass:" + mass);
            bm = BodyMass.createSolidSphere(mass, scale, cells.getSize().toVec3d().mult(0.5));
        }

        return new CellArrayPart(name, center, Type.Blocks, cells, scale, radius, bm);
    }

    public static CellArrayPart createGhost( double radius ) {
        return new CellArrayPart(new Vec3d(), Type.Sphere, null, 1, radius, BodyMass.createSimple(0, null, radius));
    }

    public static CellArrayPart createSphere( double radius, double mass ) {
        return new CellArrayPart(Type.Sphere, null, 1, radius, BodyMass.createSolidSphere(mass, radius, null));
    }

    public static CellArrayPart createSphere( String name, double radius, double mass ) {
        return new CellArrayPart(name, new Vec3d(), Type.Sphere, null, 1, radius, BodyMass.createSolidSphere(mass, radius, null));
    }

    /**
     *  Provided for convenience.  Creates a static single cell block array using extents/2 as
     *  the scale and a block type of 1.
     */
    public static CellArrayPart createCube( double extents ) {
        CellArray cells = new CellArray(1, 1, 1);
        cells.setCell(0, 0, 0, 1);
        MaskUtils.calculateSideMasks(cells);

        return createShape(cells, extents/2, 0);
    }

    public double getScale() {
        return scale;
    }

    public Type getType() {
        return type;
    }

    /**
     *  Allows overriding the accuracy priority in block-to-block collision tests.
     *  This is normally calculated based on size and scale but can be overridden
     *  in very special cases.
     */
    public void setBlockCollisionPriority( double blockCollisionPriority ) {
        this.blockCollisionPriority = blockCollisionPriority;
    }

    /**
     *  Determines which object gets the more accurate collision testing.
     *  For example, a small object hitting a larger object or a mob hitting
     *  a static object will want the more accurate collision done on the
     *  larger or static object.  Thus, those get a higher priority.  Some
     *  mobs (like the player if even represented as blocks) will always be
     *  the lowest priority.
     *  Note: this only matters for Type.Blocks to Type.Blocks collision tests.
     */
    public double getBlockCollisionPriority() {
        return blockCollisionPriority;
    }

/*    public Vec3d toBodySpace( Vec3d cellSpace, Vec3d store ) {
//System.out.println("--toBodySpace(" + cellSpace + ")");
        if( store == null ) {
            store = cellSpace.mult(getScale());
        } else {
            store = store.set(cellSpace).mult(getScale());
        }
//System.out.println("   scaled:" + store);
        //store = store.subtractLocal(getMass().getCog());
        getShapeRelativeOrientation().mult(store, store);
        store.addLocal(getShapeRelativePosition());
//System.out.println("   retranslated:" + store);
        return store;
    }*/

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .omitNullValues()
                .add("name", getName())
                .add("type", type)
                .add("center", getCenter())
                .add("radius", getRadius())
                .add("bodyMass", getMass())
                .toString();
    }

}
