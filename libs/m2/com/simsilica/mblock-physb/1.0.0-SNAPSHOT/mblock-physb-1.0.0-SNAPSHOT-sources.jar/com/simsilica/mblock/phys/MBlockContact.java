/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import org.slf4j.*;

import com.simsilica.mathd.Vec3d;

import com.simsilica.mblock.BlockType;
import com.simsilica.mblock.BlockTypeIndex;
import com.simsilica.mphys.AbstractBody;
import com.simsilica.mphys.RigidBody;
import com.simsilica.mphys.Contact;

/**
 *  Extends the regular contact class to provide additional
 *  block type and part information.
 *
 *  @author    Paul Speed
 */
public class MBlockContact<K> extends Contact<K, MBlockShape> {
    static Logger log = LoggerFactory.getLogger(MBlockContact.class);

    public Part part1;
    public int type1;

    public Part part2;
    public int type2;

    public MBlockContact() {
    }

    public MBlockContact( RigidBody<K, MBlockShape> body1, AbstractBody<K, MBlockShape> body2,
                          Vec3d contactPoint, Vec3d contactNormal, double penetration ) {
        super(body1, body2, contactPoint, contactNormal, penetration);
    }

    protected String partToString( Part part, int typeIndex ) {
        StringBuilder sb = new StringBuilder();
        if( part == null ) {
            sb.append("null");
        } else {
            sb.append(part.getName());
        }
        BlockType type = BlockTypeIndex.get(typeIndex);
        if( type != null ) {
            sb.append(":" + type.getName());
        }
        sb.append("(" + typeIndex + ")");
        return sb.toString();
    }

    // The Contact class's calculateInternals() method calls the following:
    // calculateContactBasis();
    // relativeContactPosition1 = contactPoint.subtract(body1.position);
    // if( body2 ) relativeContactPosition2 = contactPoint.subtract(body2.position);
    // contactVelocity = calculateLocalVelocity(body1, relativeContactPosition1, t);
    // if( body2 ) contactVelocity.subtractLocal(calculateLocalVelocity((RigidBody)body2, relativeContactPosition2, t));
    // calculateDesiredDeltaVelocity(t);
    //
    // We want to (potentially) inject some additional calculations for local kinematic
    // motion.  The best place to hook is calculateDesiredDeltaVelocity() since we get
    // a chance to adjust the contact velocity.
// Going to do this in our own contact system
//    @Override
//    protected void calculateDesiredDeltaVelocity( double t ) {
//        // Adjust contact velocity based on if we have kinematic information
//        // in pla7.
//        KinematicInfo k1 = part1 != null ? part1.getKinematicInfo() : null;
//        KinematicInfo k2 = part2 != null ? part2.getKinematicInfo() : null;
//        if( k1 != null ) {
//            log.info("calcDesV() " + partToString(part1, type1) + "->" + partToString(part2, type2) + " contactV:" + contactVelocity + "  world:" + contactToWorld.mult(contactVelocity));
//            // How is the contact point moving relative to this kinematic info?
//            // To do this, we calculate the world contact point relative to the kinematic info's
//            // current frame of reference... then use the 'last' frame of reference to figure out
//            // where it would have been in world space... then calculate delta from that.
//            //
//            // For the local position (kp) we want to end up with something
//            // that with loc + rot.mult(kp) would give us our original world position.
//            // So I think that's rot.inverse().mult(cp - loc)
//            //
//            // Kinematic info is in shape space... easiest thing to do is to
//            // move the contact point into shape space also
//            // Local to body first
//            Vec3d bp = contactPoint.subtract(body1.position);
//            // Then to shape space
//            Vec3d sp = body1.shape.bodyToShape(bp, null);
//
//            log.info("  bp:" + bp + "  sp:" + sp);
//            Vec3d kp = k1.getCurrentOrientation().inverse().mult(sp.subtract(k1.getCurrentLocation()));
//            Vec3d lastCp = k1.getLastLocation().add(k1.getLastOrientation().mult(kp));
//            log.info("   cp:" + contactPoint + " sp:" + sp + "  kp:" + kp + "  lastCp:" + lastCp);
//
//            Vec3d sv = sp.subtract(lastCp);
//            log.info("   sv:" + sv);
//        }
//        if( k2 != null && isBody2Enabled() ) {
//        }
//
//        super.calculateDesiredDeltaVelocity(t);
//    }
}
