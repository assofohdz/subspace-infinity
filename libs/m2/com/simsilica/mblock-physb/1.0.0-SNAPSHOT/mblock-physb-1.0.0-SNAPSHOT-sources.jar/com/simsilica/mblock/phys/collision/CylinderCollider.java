/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.Collider;
import com.simsilica.mblock.phys.RayHit;
import com.simsilica.mblock.phys.MBlockContact;


/**
 *
 *
 *  @author    Paul Speed
 */
public class CylinderCollider<K> implements Collider<K> {
    static Logger log = LoggerFactory.getLogger(CylinderCollider.class);

    private Vec3d center;
    private Vec3d axisDir;
    private Vec3d xDir;
    private Vec3d yDir;
    private double extent; // half-height of the cylinder along the axis
    private double cylinderRadius;
    private double cylinderRadiusSq;
    private int axisPosMask;
    private int axisNegMask;
    private boolean approximate;

    public CylinderCollider( Vec3d center, Vec3d axisDir, Vec3d xDir, Vec3d yDir, double extent, double cylinderRadius, boolean approximate ) {
        this.center = center;
        this.axisDir = axisDir;
        this.xDir = xDir;
        this.yDir = yDir;
        this.extent = extent;
        this.cylinderRadius = cylinderRadius;
        this.cylinderRadiusSq = cylinderRadius * cylinderRadius;
        this.approximate = approximate;
        Direction axis = Direction.findDirection(axisDir, 0.001);
        if( axis != null ) {
            axisPosMask = axis.getBitMask();
            axisNegMask = axis.reverse().getBitMask();
        }
    }

    @Override
    public boolean isApproximate() {
        return approximate;
    }

    public MBlockContact<K> getSphereContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask ) {
        //log.info("getSphereContact(" + cellPos + ", " + pos + ", " + radius + ", " + dirMask + ")");

        Vec3d worldCenter = cellPos.add(center);

        // pos - (cellPos + center)
        Vec3d centerRelative = pos.subtract(worldCenter);
        //log.info("   center:" + center + " extent:" + extent + " radius:" + cylinderRadius);
        //log.info("   axis:" + axisDir + " xDir:" + xDir + " yDir:" + yDir);
        //log.info("   center relative:" + centerRelative);

        double x = xDir.dot(centerRelative);
        double y = yDir.dot(centerRelative);
        double z = axisDir.dot(centerRelative);

        //log.info("  x:" + x + "  y:" + y + "  z:" + z);

        double zAbs = Math.abs(z);

        if( zAbs - radius > extent ) {
            //log.info("Above/below axis");
            return null;
        }
        double dSq = x * x + y * y;
        double rSq = cylinderRadius + radius;
        rSq *= rSq;
        if( dSq > rSq ) {
            //log.info("Outside radius");
            return null;
        }

        //log.info("  possible hit");

        // If we get here then we know that the sphere is not purely above/below
        // the cylinder and not completely outside the range of the cylinder sides.

        // Calculate the closest point on the cylinder to the sphere

        // If the sphere center is within the extents then we collide with the outer
        // round part of the cylinder (or are inside it).  Otherwise, we are colliding
        // somewhere on the top
        // We need to calculate both because we will lose the lowest penetrator
        // in the end.
        Vec3d cp = null;
        Vec3d norm = null;
        double penetration = 0;
        if( Math.abs(z) < extent && dSq < cylinderRadiusSq ) {
            // The center of the sphere is inside the cylinder.
            // cp and normal will depend on whether or not top/bottom
            // is enabled and which has the least penetration.
            double d = Math.sqrt(dSq);
            double sidePen = cylinderRadius - (d - radius);
            double posPen = extent - z;
            double negPen = extent + z;
            if( z > 0 && (dirMask & axisPosMask) != 0 && posPen < sidePen ) {
                // The path to the top is the closest
                //log.info("---deep top");
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(extent));
                cp = cp.addLocal(center);
                penetration = extent - (z - radius);
                norm = axisDir.clone();
            } else if( z < 0 && (dirMask & axisPosMask) != 0 && negPen < sidePen ) {
                // The path to the bottom is the closest
                //log.info("---deep bottom");
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(-extent));
                cp = cp.addLocal(center);
                penetration = extent + (z + radius);
                norm = axisDir.mult(-1);
            } else {
                // The path to the side is closest
                //log.info("---deep side");
                if( d == 0 ) {
                    // Right in the center... like the center of the test
                    // sphere is directly in the middle of the cylinder.
                    // Might as well just pick any valid normal
                    //log.info("     directly in center");
                    cp = center.add(axisDir.mult(z));
                    norm = xDir;
                } else {
                    x = (x / d) * cylinderRadius;
                    y = (y / d) * cylinderRadius;
                    cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(z));
                    cp = cp.addLocal(center);
                    penetration = cylinderRadius - (d - radius);
                    norm = xDir.mult(x).addLocal(yDir.mult(y));
                }
            }
        } else if( z > extent && (dirMask & axisPosMask) != 0 ) {
            // Cylinder collides with top
            //log.info("  Hits top");
            if( dSq <= cylinderRadiusSq ) {
                //log.info("   Pointing straight up");
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(extent));
                cp = cp.addLocal(center);
                penetration = extent - (z - radius);
                norm = axisDir.clone();
            } else {
                //log.info("   at edge");
                double d = Math.sqrt(dSq);
                x = (x / d) * cylinderRadius;
                y = (y / d) * cylinderRadius;
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(extent));
                norm = centerRelative.subtractLocal(cp);
                cp = cp.addLocal(center);
                double cpDist = norm.length();
                norm.multLocal(1/cpDist);
                penetration = radius - cpDist;
            }
        } else if( z < -extent && (dirMask & axisNegMask) != 0 ) {
            // Cylinder collides with bottom
            //log.info("  Hits bottom");
            if( dSq <= cylinderRadiusSq ) {
                //log.info("   Pointing straight down");
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(-extent));
                cp = cp.addLocal(center);
                penetration = extent + (z + radius);
                norm = axisDir.mult(-1);
            } else {
                //log.info("   at edge");
                double d = Math.sqrt(dSq);
                x = (x / d) * cylinderRadius;
                y = (y / d) * cylinderRadius;
                cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(-extent));
                norm = centerRelative.subtractLocal(cp);
                cp = cp.addLocal(center);
                double cpDist = norm.length();
                norm.multLocal(1/cpDist);
                penetration = radius - cpDist;
            }
        } else if( zAbs <= extent ) {
            // Center of the sphere is between the top and bottom of the cylinder
            // but outside the cylinder walls
            //log.info("  Hits side");
            double d = Math.sqrt(dSq);
            x = (x / d) * cylinderRadius;
            y = (y / d) * cylinderRadius;
            cp = xDir.mult(x).addLocal(yDir.mult(y)).addLocal(axisDir.mult(z));
            cp = cp.addLocal(center);
            penetration = cylinderRadius - (d - radius);
            norm = xDir.mult(x).addLocal(yDir.mult(y));
        }

        if( cp == null ) {
            return null;
        }

        MBlockContact<K> result = new MBlockContact<>();
        result.contactPoint = cp.addLocal(cellPos);
        result.contactNormal = norm;
        result.penetration = penetration;

        return result;
    }

    @Override
    public MBlockContact<K> getCubeContact( Vec3d cellOrigin, Vec3d pos, double radius, int dirMask ) {
        // For now, just treat it like a sphere contact
        return getSphereContact(cellOrigin, pos, radius, dirMask);
    }

    public RayHit getHit( Vec3d origin, Vec3d dir, int dirMask, RayHit store ) {

        Vec3d min = center.subtract(cylinderRadius, extent, cylinderRadius);
        Vec3d max = center.add(cylinderRadius, extent, cylinderRadius);

        // Copied from CubeCollider temporarily
        // FIXME: implement proper cylinder ray hits
        boolean inside = true;
        int[] quadrant = new int[3];
        double[] maxT = new double[3];
        double[] candidatePlane = new double[3];

        // Find the candidate planes
        for( int i = 0; i < 3; i++ ) {
            if( origin.get(i) < min.get(i) ) {
                quadrant[i] = 1;
                candidatePlane[i] = min.get(i);
                inside = false;
            } else if( origin.get(i) > max.get(i) ) {
                quadrant[i] = 0;
                candidatePlane[i] = max.get(i);
                inside = false;
            } else {
                quadrant[i] = 2;
            }
        }

        if( inside ) {
            // If the origin is inside then it's never a hit for us
            return null;
        }

        // Calculate the T distances to the candidate planes.
        for( int i = 0; i < 3; i++ ) {
            if( quadrant[i] != 2 && dir.get(i) != 0 ) {
                maxT[i] = (candidatePlane[i]-origin.get(i)) / dir.get(i);
            } else {
                maxT[i] = -1; // purposely bogus value?
            }
        }

        // Find the largest of the max Ts
        int whichPlane = 0;
        for( int i = 1; i < 3; i++ ) {
            if( maxT[i] > maxT[whichPlane] ) {
                whichPlane = i;
            }
        }

        // Check that final candidate is actually inside the box
        if( maxT[whichPlane] < 0 ) {
            return null;
        }

        if( store == null ) {
            store = new RayHit();
        }

        for( int i = 0; i < 3; i++ ) {
            if( whichPlane != i ) {
                store.point.set(i, origin.get(i) + maxT[whichPlane] * dir.get(i));
                store.normal.set(i, 0 );
                if( store.point.get(i) < min.get(i) || store.point.get(i) > max.get(i) ) {
                    return null;  // intersection is outside box
                }
            } else {
                store.point.set(i, candidatePlane[i]);
                store.normal.set(i, quadrant[i] == 0 ? 1 : -1);
            }
        }

        return store;
    }
}
