/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.DirectionMasks;
import com.simsilica.mblock.phys.Collider;
import com.simsilica.mblock.phys.RayHit;
import com.simsilica.mblock.phys.MBlockContact;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SphereCollider<K> implements Collider<K>  {

    static Logger log = LoggerFactory.getLogger(SphereCollider.class);

    public static final String DEFAULT_NAME = "box";

    public static final SphereCollider UNIT = new SphereCollider();

    private final Vec3d min;
    private final Vec3d max;
    private final Vec3d center = new Vec3d();
    private final double radius;
    private final String name;
    private final boolean approximate;

    public SphereCollider() {
        this(new Vec3d(0, 0, 0), new Vec3d(1, 1, 1), DEFAULT_NAME, false);
    }

    public SphereCollider( String name, boolean approximate ) {
        this(new Vec3d(0, 0, 0), new Vec3d(1, 1, 1), name, approximate);
    }

    public SphereCollider( Vec3d min, Vec3d max, boolean approximate ) {
        this(min, max, DEFAULT_NAME, approximate);
    }

    public SphereCollider( Vec3d min, Vec3d max, String name, boolean approximate ) {
        this.name = name;
        this.min = min.clone();
        this.max = max.clone();
        this.approximate = approximate;

//log.info("SphereCollider(" + min + ", " + max + ", " + name + ")");
        center.set(min);
        center.addLocal(max);
        center.multLocal(0.5);

        // Just pick one
        this.radius = (max.x - min.x) * 0.5;
    }

    protected SphereCollider( SphereCollider toClone ) {
        this.min = toClone.min.clone();
        this.max = toClone.max.clone();
        this.center.set(toClone.center);
        this.radius = toClone.radius;
        this.name = toClone.name;
        this.approximate = toClone.approximate;
    }

    public Vec3d getCenter() {
        return center;
    }

    public String getName() {
        return name;
    }

    private static Vec3d toNormal( Vec3d delta, double dist ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
System.out.println("Random deflect.");
        delta.x = Math.random() * 0.1;
        delta.y = Math.random() * 0.1;
        delta.z = Math.random() * 0.1;
        return delta.normalizeLocal();
    }

    @Override
    public MBlockContact<K> getSphereContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask ) {
        if( log.isTraceEnabled() ) {
            log.trace("getSphereContact(" + cellPos + ", " + pos + ", " + radius + ", " + DirectionMasks.toString(dirMask) + ")");
        }

        double x = pos.x - (cellPos.x + center.x);
        double y = pos.y - (cellPos.y + center.y);
        double z = pos.z - (cellPos.z + center.z);

        double dSq = x * x + y * y + z * z;
        double both = this.radius + radius;
        if( dSq > both * both ) {
            return null;
        }

        double dist = Math.sqrt(dSq);
        Vec3d cn = toNormal(new Vec3d(x, y, z), dist);
        Vec3d cp = cellPos.add(center).addLocal(cn.mult(this.radius));

        double penetration = -(dist - both);

        MBlockContact<K> result = new MBlockContact<>();
        result.contactPoint = cp;
        result.contactNormal = cn;
        result.penetration = penetration;

        return result;
    }

    @Override
    public MBlockContact<K> getCubeContact( Vec3d cellOrigin, Vec3d pos, double radius, int dirMask ) {
        return getSphereContact(cellOrigin, pos, radius, dirMask);
    }

    @Override
    public RayHit getHit( Vec3d origin, Vec3d dir, int dirMask, RayHit store ) {

        if( log.isTraceEnabled() ) {
            log.trace("getHit(" + origin + ", " + dir + ")");
        }

        // Find where the sphere center projects along the ray.  The
        // ray parameters should already be cell-relative
        Vec3d relative = center.subtract(origin);
        double proj = relative.dot(dir);

        Vec3d closest = origin.add(dir.mult(proj));

        double distSq = center.distanceSq(closest);

        if( log.isTraceEnabled() ) {
            log.trace("  closest:" + closest + "  distSq:" + distSq);
        }

        if( distSq > (radius * radius) ) {
            return null;
        }

        if( store == null ) {
            store = new RayHit();
        }

        // Need to figure out where we would have hit the sphere.  The farther
        // into the radius we are, the closer we are to the origin of the ray.
        // There is a triangle formed between the sphere center (C), the closest
        // point on the ray (P), and the intersection with the sphere (I).
        // The angle between the ray and the line between C and P is 90 degrees.
        // So we have a right triangle whose hypotenuse is 'radius' and we know
        // the base is dist.
        // dSq + x^2 = rSq
        // so: x = sqrt(rSq - dSq);
        // then we can project back along the ray from 'closest'.
        double back = Math.sqrt(radius * radius - distSq);
        Vec3d cp = closest.subtract(dir.mult(back));

        // Calculate the normal as the direction from center to contact point.
        // Contact point should always be on the surface of the sphere so we
        // should be able to just normalize.
        Vec3d normal = cp.subtract(center).normalizeLocal();

        store.point.set(cp);
        store.normal.set(normal);

        return store;
    }

    public String toString() {
        return "SphereCollider[" + name + ", " + center + ", " + radius + "]";
    }
}

