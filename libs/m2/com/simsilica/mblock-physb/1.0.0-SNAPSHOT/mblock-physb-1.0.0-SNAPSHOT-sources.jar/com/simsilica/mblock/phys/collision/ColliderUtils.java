/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.phys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ColliderUtils {
    static Logger log = LoggerFactory.getLogger(ColliderUtils.class);

    /**
     *  Calculate a rough shape signature for the collider based on the
     *  probe radius specified.  This samples the collider in a 4x4x4
     *  grid to produce a 64 bit number representing the 'hits' of the probe
     *  sphere.
     */
    public static ShapeSignature calculateShapeSignature( Collider collider, double probeRadius ) {

        ShapeSignature result = new ShapeSignature(0);

        double spacing = 0.25;
        double offset = spacing * 0.5; // half way in the cell
        Vec3d cellPos = new Vec3d();
        Vec3d pos = new Vec3d();

        for( int i = 0; i < 4; i++ ) {
            pos.x = i * spacing + offset;
            for( int j = 0; j < 4; j++ ) {
                pos.y = j * spacing + offset;
                for( int k = 0; k < 4; k++ ) {
                    pos.z = k * spacing + offset;
                    MBlockContact contact = null;
                    if( collider != null ) {
                        contact = collider.getSphereContact(cellPos, pos, probeRadius, 0xff);
                    }
                    if( contact != null ) {
                        result.set(i, j, k);
                    }
                }
            }
        }

        return result;
    }

    /**
     *  Calculate a rough shape signature for the collider based on the
     *  probe radius specified.  This samples the collider in a 4x4x4
     *  grid to produce a 64 bit number representing the 'hits' of the probe
     *  sphere.
     */
    public static long calculateShapeSignatureBits( Collider collider, double probeRadius ) {

        double spacing = 0.25;
        long result = 0;
        long toggleBit = 0x1;
        Vec3d cellPos = new Vec3d();
        Vec3d pos = new Vec3d();

        for( int i = 0; i < 4; i++ ) {
            pos.x = i * spacing + probeRadius;
            for( int j = 0; j < 4; j++ ) {
                pos.y = j * spacing + probeRadius;
                for( int k = 0; k < 4; k++ ) {
                    pos.z = k * spacing + probeRadius;
                    MBlockContact contact = null;
                    if( collider != null ) {
                        contact = collider.getSphereContact(cellPos, pos, probeRadius, 0xff);
                    }
                    if( contact != null ) {
                        result = result | toggleBit;
                    }
                    toggleBit = toggleBit << 1;
                    if( toggleBit != getToggleBit(i, j, k) ) {
                        log.error("Very bad things:\n" + Long.toBinaryString(toggleBit)
                                + "\n" + getToggleBit(i, j, k));
                    }
                }
            }
        }

        return result;
    }

    protected static int index( int i, int j, int k ) {
        return i * 16 + j * 4 + k;
    }

    protected static long getToggleBit( int i, int j, int k ) {
        return 0x1L << index(i, j, k);
    }

}


