/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.Collider;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SimilarShapeIndex {
    static Logger log = LoggerFactory.getLogger(SimilarShapeIndex.class);

    private ShapeEntry[] shapes;
    private ListMultimap<String, ShapeEntry> shapeIndex = MultimapBuilder.hashKeys().arrayListValues().build();

    public SimilarShapeIndex( BlockType[] types, Collider[] colliders ) {
        this.shapes = new ShapeEntry[types.length];
        for( int i = 0; i < shapes.length; i++ ) {
            if( types[i] == null || colliders[i] ==  null ) {
                continue;
            }
            ShapeEntry entry = new ShapeEntry(i, types[i], colliders[i]);
            shapes[i] = entry;
            shapeIndex.put(types[i].getName().getBase(), shapes[i]);
            if( log.isTraceEnabled() ) {
                log.trace("entry[" + entry.index + "]:" + entry.type.getName() + "  approximate:" + entry.approximate);
            }
        }
        buildSignatures();
    }

    public ShapeSignature getSignature( int index ) {
        return shapes[index] != null ? shapes[index].signature : null;
    }

    /**
     *  Finds the smallest type that can fully contain the specified signature.
     */
    public int findContaining( String base, ShapeSignature sig ) {
//log.info("findContaining(" + base + ", " + sig + ")");
        return findContaining(shapeIndex.get(base), sig);
    }

    public int findContaining( List<ShapeEntry> typeShapes, ShapeSignature sig ) {
        // Find the 'smallest' signature that comes the closest to containing
        // all of the signature bits.
        long testBits = sig.getBits();
        long smallestCount = Long.MAX_VALUE;
        int bestIndex = -1;

        for( ShapeEntry entry : typeShapes ) {
//log.info("  checking:" + entry.type.getName() + " sig:" + entry.signature);
            if( entry.approximate ) {
                continue;
            }
            long bits = entry.signature.getBits();

            // If our test bits have any of the avoid bits then this signature
            // doesn't fully contain this object.  If the base shape has a cube
            // then there should always be at least a maximal answer.
            long avoidBits = ~bits;

            if( (testBits & avoidBits) != 0 ) {
//log.info("     test bits leak outside");
                continue;
            }

            long count = Long.bitCount(bits);
            if( count < smallestCount ) {
                smallestCount = count;
                bestIndex = entry.index;
            }
        }
//log.info("bestIndex:" + bestIndex);
        return bestIndex;
    }

    /**
     *  Finds a block that is as close to the specified signature as possible
     *  without getting bigger.
     */
    public int findSimilar( String base, BlockType skipType, ShapeSignature sig ) {
        return findSimilar(shapeIndex.get(base), skipType, sig);
    }

    public int findSimilar( BlockName name, BlockType skipType, ShapeSignature sig ) {

//if( skipType != null ) {
//    log.info("findSimilar(" + name + ", " + skipType.getName() + ") sig:" + sig);
//} else {
//    log.info("findSimilar(" + name + ", null) sig:" + sig);
//}
        return findSimilar(name.getBase(), skipType, sig);
    }

    public int findSimilar( List<ShapeEntry> typeShapes, BlockType skipType, ShapeSignature sig ) {
        int bestIndex = 0;
        int bestCount = 0;
        long testBits = sig.getBits();
        long avoidBits = ~sig.getBits();
        long maxCount = Long.bitCount(testBits);

        for( ShapeEntry entry : typeShapes ) {
//log.info("  checking:" + entry.type.getName() + " sig:" + entry.signature);
            if( entry.type == skipType ) {
                continue;
            }
            if( entry.approximate ) {
//log.info("    skipping approximate");
                continue;
            }
            //if( entry.collider instanceof CylinderCollider ) {
            //    // Cylinders are in their own type of space
            //    continue;
            //}
            //String shape = entry.type.getName().getShape();
            //if( shape.startsWith("hcyl") ) {
            //    continue;
            //}
            //if( shape.startsWith("cone") ) {
            //    continue;
            //}
            //if( shape.startsWith("spike") ) {
            //    continue;
            //}
            long bits = entry.signature.getBits();
            if( (bits & avoidBits) != 0 ) {
                // The entry has bits that the test signature doesn't
//log.info("     has avoid bits");
                continue;
            }
            if( Long.bitCount(bits) > maxCount ) {
                // Not sure how this can happen if we avoided the avoid bits
//log.info("     bigger than max count");
                continue;
            }
            long combined = bits & testBits;
//log.info("   combined:" + Long.toBinaryString(combined));

            int count = Long.bitCount(combined);
//log.info("   similarity:" + count);
            if( count > bestCount ) {
                bestIndex = entry.index;
                bestCount = count;
            }
        }
//log.info("bestIndex:" + bestIndex);
        return bestIndex;
    }

    public int findSimilar( BlockType type, ShapeSignature sig ) {
        if( type == null || type.getName() == null ) {
            return 0;
        }
        return findSimilar(type.getName(), type, sig);
    }

    public CellArray createFacsimile( int blockTypeIndex ) {
        ShapeEntry entry = shapes[blockTypeIndex];
        if( entry == null || entry.type == null || entry.collider == null ) {
            return null;
        }
        return createFacsimile(entry.type, entry.collider);
    }

    public CellArray createFacsimile( BlockType block, Collider collider ) {

        BlockName name = block.getName();
        List<ShapeEntry> typeShapes = shapeIndex.get(name.getBase());

        CellArray result = new CellArray(4);

        // Go through each quarter cell of the block collider
        for( int i = 0; i < 4; i++ ) {
            for( int j = 0; j < 4; j++ ) {
                for( int k = 0; k < 4; k++ ) {
                    // Find the signatures of the quarter cell area
                    int child = findChildType(i, j, k, typeShapes, collider);
                    result.setCell(i, j, k, child);
                }
            }
        }

        MaskUtils.calculateSideMasks(result);

        return result;
    }

    /**
     *  Searches a quarter-space cell to find the most appropriate block that
     *  matches that shape.
     */
    protected int findChildType( int x, int y, int z, List<ShapeEntry> typeShapes, Collider collider ) {
        double xBase = x * 0.25;
        double yBase = y * 0.25;
        double zBase = z * 0.25;

        double cellSpacing = 0.0625;
        double cellOffset = 0.03125;
        double probeRadius = 0.03124;

        Vec3d cellPos = new Vec3d();
        Vec3d pos = new Vec3d();

        ShapeSignature sig = new ShapeSignature(0);
        for( int i = 0; i < 4; i++ ) {
            pos.x = xBase + (i * cellSpacing) + cellOffset;
            for( int j = 0; j < 4; j++ ) {
                pos.y = yBase + (j * cellSpacing) + cellOffset;
                for( int k = 0; k < 4; k++ ) {
                    pos.z = zBase + (k * cellSpacing) + cellOffset;
                    if( collider.getSphereContact(cellPos, pos, probeRadius, 0xff) != null ) {
                        sig.set(i, j, k);
                    }
                }
            }
        }

        return findSimilar(typeShapes, null, sig);
    }

    private void buildSignatures() {
        double probeRadius = 0.124; // a little off to miss rounding errors.
        // I had to subtract 0.001 to keep x-axis aligned horizontal cylinder's
        // rough cube shape from looking like a slab.  The zMax was being calculated
        // as 0.2500000001

        for( ShapeEntry entry : shapes ) {
            if( entry == null ) {
                continue;
            }
            entry.calculateShapeSignature(probeRadius);
        }
    }

    private class ShapeEntry {
        BlockType type;
        Collider collider;
        ShapeSignature signature;
        int index;
        boolean approximate;

        public ShapeEntry( int index, BlockType type, Collider collider ) {
            this.index = index;
            this.type = type;
            this.collider = collider;
            // Some shapes are too approximate to use for signature matching
            // either because they are in a strange space (cylinders) or haven't
            // had their colliders fully implemented (every wedge corner).
            this.approximate = collider.isApproximate();
            //if( collider instanceof CylinderCollider ) {
            //    this.approximate = true;
            //} else if( collider instanceof CubeCollider ) {
            //    this.approximate = ((CubeCollider)collider).isApproximate();
            //}
        }

        protected void calculateShapeSignature( double probeRadius ) {
            if( collider != null ) {
                this.signature = ColliderUtils.calculateShapeSignature(collider, probeRadius);
            }
        }
    }
}
