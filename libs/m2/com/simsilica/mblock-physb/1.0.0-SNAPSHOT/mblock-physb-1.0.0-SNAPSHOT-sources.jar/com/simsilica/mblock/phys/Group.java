/*
 * $Id$
 *
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;


/**
 *  A group of parts in a shape hierarchy.
 *
 *  @author    Paul Speed
 */
public class Group extends Part {

    static Logger log = LoggerFactory.getLogger(Group.class);

    private DynArray<Part> children = new DynArray<>(Part.class);
    private DynArray<Part> traversed = null;

    public Group( String name ) {
        super(name);
    }

    public void calculateBounds( Vec3d min, Vec3d max ) {
        for( Part p : traverse() ) {
            p.calculateBounds(min, max);
        }
    }

    @Override
    public Part[] traverse() {
        if( traversed != null ) {
            return traversed.getArray();
        }
        if( getParent() != null ) {
            throw new UnsupportedOperationException("traverse() can only be called from root part");
        }

        // Should cache this in the root... which is really the only place
        // it will be called.
        //DynArray<Part> result = new DynArray<>(Part.class);
        traversed = new DynArray<>(Part.class);
//log.info("new DynArray");
        addNonGroups(traversed, children);
        return traversed.getArray();
    }

    protected void addNonGroups( DynArray<Part> target, DynArray<Part> source ) {
        for( Part p : source.getArray() ) {
            if( p instanceof Group ) {
                addNonGroups(target, ((Group)p).getChildren());
            } else {
                target.add(p);
            }
        }
    }

    @Override
    protected void updateMass() {

        // Calculate a body mass for the whole group... right now we
        // shall hard-code it
        //setMass(BodyMass.createSolidSphere(40, 10, null));
        setMass(MassUtils.calculateBodyMass(this));

    }

    @Override
    protected void markForRefresh( int flag ) {
        super.markForRefresh(flag);

        if( (flag & REFRESH_TRANSFORM) != 0 ) {
            // If it's a transform refresh then we need to dirty our children, too
            for( Part child : children.getArray() ) {
                child.markForRefresh(flag);
            }
        }
    }

    @Override
    protected void setParent( Group parent ) {
        super.setParent(parent);
        traversed = null;
    }

    public void addChild( Part part ) {
        if( part == null ) {
            throw new IllegalArgumentException("Part cannot be null");
        }
        if( part.getParent() == this ) {
            return;
        }
        if( part.getParent() != null ) {
            part.getParent().removeChild(part);
        }
        children.add(part);
        part.setParent(this);

        // And it means our overall shape has probably changed
        markForRefresh(REFRESH_MASS);
        traversed = null;
    }

    public boolean removeChild( Part part ) {
        if( part == null ) {
            throw new IllegalArgumentException("Part cannot be null");
        }
        if( part.getParent() != this ) {
            throw new IllegalArgumentException("Part:" + part + " is not a child of:" + this);
        }
        if( children.remove(part) ) {
            part.setParent(null);

            // And it means our overall shape has probably changed
            markForRefresh(REFRESH_MASS);
            traversed = null;
            return true;
        }
        return false;
    }

    public DynArray<Part> getChildren() {
        return children;
    }
}

