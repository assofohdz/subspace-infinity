/*
 * $Id$
 *
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;


/**
 *  Base class for parts in a shape hierarchy.
 *
 *  @author    Paul Speed
 */
public abstract class Part {

    static Logger log = LoggerFactory.getLogger(Part.class);

    protected static final int REFRESH_MASS = 0x1;
    protected static final int REFRESH_TRANSFORM = 0x2;
    protected static final int REFRESH_REL_COG = 0x4;

    private int refreshFlags = 0;

    // Keep track of whether the hierarchy has changed or things have
    // moved around... increment every time we refresh.
    private long version;

    private String name;
    private Group parent;

    private BodyMass mass;

    // The local transform relative to the parent
    private Vec3d localPosition = new Vec3d();
    private Quatd localOrientation = new Quatd();

    // The transform relative to the shape origin.
    private Vec3d shapeRelPosition = new Vec3d();
    private Quatd shapeRelOrientation = new Quatd();
    private Vec3d shapeRelCog = new Vec3d();

    // Experimental optional kinematic info support
    private KinematicInfo kinInfo;

    protected Part( String name ) {
        this.name = name;
    }

    public long getVersion() {
        return version;
    }

    public void setKinematicInfo( KinematicInfo kinInfo ) {
        this.kinInfo = kinInfo;
        kinInfo.initialize(getShapeRelativePosition(), getShapeRelativeOrientation());
    }

    public void updateKinematicInfo() {
        if( kinInfo != null ) {
            kinInfo.update(getShapeRelativePosition(), getShapeRelativeOrientation());
        }
    }

    public KinematicInfo getKinematicInfo() {
        return kinInfo;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    protected int getRefreshFlags() {
        return refreshFlags;
    }

    public void setLocalPosition( Vec3d pos ) {
        localPosition.set(pos);
        markForRefresh(REFRESH_TRANSFORM);
        markForRefresh(REFRESH_REL_COG);
        if( parent != null ) {
            // If we move then the whole body's mass changes
            parent.markForRefresh(REFRESH_MASS);
        }
    }

    public Vec3d getLocalPosition() {
        return localPosition;
    }

    public void setLocalOrientation( Quatd orient ) {
        localOrientation.set(orient);
        markForRefresh(REFRESH_TRANSFORM);
        markForRefresh(REFRESH_REL_COG);
        if( parent != null ) {
            // If we move then the whole body's mass changes
            parent.markForRefresh(REFRESH_MASS);
        }
    }

    public Quatd getLocalOrientation() {
        return localOrientation;
    }

    protected void updateTransform() {
//log.info("updateTransform():" + getName() + "   parent:" + parent);
        if( parent == null ) {
            shapeRelPosition.set(localPosition);
            shapeRelOrientation.set(localOrientation);
        } else {
            Quatd refOrient = parent.getShapeRelativeOrientation();
//log.info("  body orient:" + refOrient);
            refOrient.mult(localPosition, shapeRelPosition);
//log.info("  local rotated position:" + shapeRelPosition + "  parent body position:" + parent.getShapeRelativePosition());
            shapeRelPosition.addLocal(parent.getShapeRelativePosition());
//log.info("  final body position:" + shapeRelPosition);
            shapeRelOrientation.set(refOrient).multLocal(localOrientation);
        }
        clearRefreshNeeded(REFRESH_TRANSFORM);
    }

    protected abstract void updateMass();

    protected void updateCog() {
        // Body cog is offset from the body position but rotated into
        // part space
        getShapeRelativeOrientation().mult(getMass().getCog(), shapeRelCog);
        shapeRelCog.addLocal(getShapeRelativePosition());
        clearRefreshNeeded(REFRESH_REL_COG);
    }

    public Vec3d getShapeRelativePosition() {
        if( isRefreshNeeded(REFRESH_TRANSFORM) ) {
            updateTransform();
        }
        return shapeRelPosition;
    }

    public Quatd getShapeRelativeOrientation() {
        if( isRefreshNeeded(REFRESH_TRANSFORM) ) {
            updateTransform();
        }
        return shapeRelOrientation;
    }

    public Vec3d getShapeRelativeCog() {
        if( isRefreshNeeded(REFRESH_REL_COG) ) {
            updateCog();
        }
        return shapeRelCog;
    }

    protected boolean isRefreshNeeded( int flag ) {
        return (refreshFlags & flag) != 0;
    }

    protected void markForRefresh( int flag ) {
        if( (refreshFlags & REFRESH_MASS) == 0 && flag == REFRESH_MASS ) {
            // Increment the version if we are setting 'REFRESH_MASS' flag.
            // -pspeed:2022-05-09
            version++;
        }
        this.refreshFlags = refreshFlags | flag;

        // If it's part of the overall shape properties then pass it to the parent
        if( parent != null && (flag & REFRESH_MASS) != 0 ) {
            parent.markForRefresh(flag);
        }
    }

    protected void clearRefreshNeeded( int flag ) {
        this.refreshFlags = refreshFlags & ~flag;
        // It's too late to increment the version when we clear.
        // We need to increment it when refreshing a flag for the
        // first time since clearing.  Else callers will never know
        // they need to refresh whatever they need to refresh that
        // clears the flag in the first place (ie: shape.getMass())
        // -pspeed:2022-05-09
        // version++;
    }

    protected void setParent( Group parent ) {
        if( this.parent == parent ) {
            return;
        }
        this.parent = parent;
        markForRefresh(REFRESH_TRANSFORM);
        markForRefresh(REFRESH_REL_COG);
        if( parent != null ) {
            parent.markForRefresh(REFRESH_MASS);
        }
    }

    public Group getParent() {
        return parent;
    }

    protected void setMass( BodyMass mass ) {
        this.mass = mass;
        clearRefreshNeeded(REFRESH_MASS);
        markForRefresh(REFRESH_REL_COG);
    }

    public BodyMass getMass() {
        if( mass == null || isRefreshNeeded(REFRESH_MASS) ) {
            updateMass();
        }
        return mass;
    }

    public abstract Part[] traverse();

    public abstract void calculateBounds( Vec3d min, Vec3d max );

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .omitNullValues()
                .add("name", name)
                .add("bodyMass", mass)
                .toString();
    }

}
