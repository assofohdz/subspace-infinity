/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

import com.jme3.math.Vector2f;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.BoundaryShapes.Triangle;
import com.simsilica.mblock.phys.Collider;
import com.simsilica.mblock.phys.RayHit;
import com.simsilica.mblock.phys.MBlockContact;

/**
 *  A wedge collider but laying on its side.  The 'math' of this
 *  class is essentially identical to WedgeCollider except in the
 *  parameter setup.  There are a lot of parameters so I'm cutting+pasting
 *  today instead of making a proper base class or factory methods or
 *  whatever... but that should be considered at some point.
 *
 *  @author    Paul Speed
 */
public class AngleCollider implements Collider {
    static Logger log = LoggerFactory.getLogger(AngleCollider.class);
 
    private final String name;
    
    // Define the actual wedge with minimal parameters.
    // The min/max will tell us the bounding box and the normal
    // tells us the slope normal which should align with max.y - min.y
    // over some xx or zz distance.
    private final Vec3d min;
    private final Vec3d max;
    private final Vec3d triangleOrigin;
    private final Vec3d worldNormal;
    
    // The direction of the fully solid side, ie: the y-axis of the right triangle
    private final int rotation;
    private final Direction solidDirection;
    private final Direction dir;
    private final Direction up;
    private final Direction right;

    // Define 'wedge space' as the space where the origin
    // is the right-angle corner of the triangle with x,y being positions
    // on the triangle and z being 'into' the triangle, along the non-triangle
    // axis.
    private final Vec3d origin;
    private final Vec3d xDir;
    private final Vec3d yDir;
    private final Vec3d zDir;    

    private final Vec3d triNormal;
 
    private final double xMin;
    private final double yMin;   
    private final double xMax;
    private final double yMax;
    private final double planeDist;
    
    private final int xPosMask;
    private final int xNegMask;
    private final int yPosMask;
    private final int yNegMask;
    private final int zPosMask;
    private final int zNegMask;
 
    public AngleCollider( Vec3d min, Vec3d max, int rotation, String name ) {
        this.name = name;
        this.min = min;
        this.max = max;
        this.rotation = rotation;
        
        // when rotation is 0 the solid directions are north and
        // west.  We will consider that solid = north and up = east.
        // This should make left be down which is a tad more convenient. 
        this.solidDirection = Direction.cardinalDirection(rotation); 

        // Set the wedge space vectors... while we define the collider
        // slope-up, we define wedge space from the right-angle corner
        // ...so backwards.
        this.dir = solidDirection.reverse();
        this.up = solidDirection.rotate(1);
       
        this.xDir = dir.getVec3i().toVec3d();
        this.yDir = up.getVec3i().toVec3d();
        
        // Z should always be 'up' in this case
        //this.zDir = xDir.cross(yDir);
        //this.right = Direction.findDirection(zDir, 0.001);
        this.zDir = Vec3d.UNIT_Y.clone(); // we are on our sides, z in triangle space is y in world space
        this.right = Direction.Up; 

//log.info("xDir:" + xDir + "  yDir:" + yDir + "  zDir:" + zDir);
 
        this.origin = new Vec3d();

        // The triangle parameters are always the same in this case
        this.triNormal = new Vec3d(1, 1, 0).normalizeLocal();
        this.xMin = 0; 
        this.yMin = 0;
        this.xMax = 1; 
        this.yMax = 1;

        // This one probably really could be calculated by rotation
        this.triangleOrigin = new Vec3d();
        switch( solidDirection ) {
            case North:
                // Solid side is north, 'base' is west
                // base origin is 0, 0, 0 
                triangleOrigin.x = 0;
                triangleOrigin.y = 0;
                triangleOrigin.z = 0;
                break;
            case South:
                // Solid side is south, 'base' is east
                // base origin is 1, 0, 1 
                triangleOrigin.x = 1;
                triangleOrigin.y = 0;
                triangleOrigin.z = 1;
                break;
            case East:
                // Solid side is east, 'base' is north
                // base origin is 1, 0, 0 
                triangleOrigin.x = 1;
                triangleOrigin.y = 0;
                triangleOrigin.z = 0;
                break;
            case West:
                // Solid side is west, 'base' is south
                // base origin is 0, 0, 1 
                triangleOrigin.x = 0;
                triangleOrigin.y = 0;
                triangleOrigin.z = 1;
                break;
            default:
                throw new UnsupportedOperationException("Can't yet handle:" + solidDirection);
        }
        
        
        // Need to calculate how far away form triangle origin the slope plane is.
        // This should be a dot of either of the slope components.
        // normal.dot(vec3(xmax, 0, 0))
        // And since that breaks down to:
        // normal.x * xMax + normal.y * 0 + normal.z * 0
        // normal.x * xMax + 0 + 0 = normal.x * xMax;
        this.planeDist = xMax * triNormal.x; 
        
        this.worldNormal = xDir.mult(triNormal.x).addLocal(yDir.mult(triNormal.y)).addLocal(zDir.mult(triNormal.z));
 
        // We need wedge-space relative side masks to more easily mask
        // out sides supplied to the collision methods.
        xPosMask = dir.getBitMask();
        xNegMask = dir.reverse().getBitMask();
        yPosMask = up.getBitMask();
        yNegMask = up.reverse().getBitMask();
        zPosMask = right.getBitMask();
        zNegMask = right.reverse().getBitMask();
    }    

    @Override   
    public MBlockContact getSphereContact( Vec3d cellOrigin, Vec3d pos, double radius, int dirMask ) {
        // Get the position in triangle-origin-relative space
        Vec3d triRelative = pos.clone();
        triRelative.x = triRelative.x - (cellOrigin.x + triangleOrigin.x);
        triRelative.y = triRelative.y - (cellOrigin.y + triangleOrigin.y);
        triRelative.z = triRelative.z - (cellOrigin.z + triangleOrigin.z);        
        
        // The position within the cell cube
        Vec3d cellRelative = pos.subtract(cellOrigin);
        
//log.info("---------Triangle:" + triangle);
//log.info("---solid dir:" + solidDirection + "  upDir:" + up + "  name:" + name);        
//log.info("intercell:" + cellRelative + "  triOrigin:" + triangleOrigin);
//log.info("triRelative:" + triRelative);

        // Now calculate the position in "wedge space"       
        double x = xDir.dot(triRelative);
//log.info("xDir:" + xDir);        
//log.info("x:" + x + " radius:" + radius + " xMin:" + xMin + "  xMax:" + xMax);
        
        // If we are before the lip or after the ramp then
        // there is no intersection... though technically we wouldn't
        // have even been called... it's still good to check.
        if( x + radius <= xMin || x - radius >= xMax ) {
//log.info("   outside x");        
            return null;
        }
        
        // Also check against the solid side... if we don't have one
        // and our center is outside the box then we don't collide...
        // we'll let our neighbor take it.
        if( x < xMin && (dirMask & xNegMask) == 0 ) {
//log.info("  xNegMask");        
            return null;
        }                    

//log.info("yDir:" + yDir);        
        double y = yDir.dot(triRelative);
        
//log.info("y:" + y + " radius:" + radius + " yMin:" + yMin + "  yMax:" + yMax);

        // If we are fully above or fully below the block then there
        // is also no intersection.
        if( y + radius < yMin || y - radius >= yMax ) {
//log.info("   outside y");        
            return null;
        }            
 
        // And if we have no "down" side then we don't check unless
        // the point itself is inside.  We leave it to the neighbor
        // otherwise
        if( y < yMin && (dirMask & yNegMask) == 0 ) {
//log.info("  yNegMask");        
            return null;
        }            
                    
//log.info("zDir:" + zDir);
        double z = zDir.dot(triRelative); 

//log.info("z:" + z);

        // Or fully left or right
        if( z + radius < 0 || z - radius > 1 ) {
            return null;
        }

        // Same as above... we'll do a tighter check if either side
        // is not enabled.
        if( z < 0 && (dirMask & zNegMask) == 0 ) {
//log.info("  zNegMask");        
            return null;
        }
        if( z > 1 && (dirMask & zPosMask) == 0 ) {
//log.info("  zPosMask");        
            return null;
        }
 
//log.info("triangle normal:" + triangle.getNormal() + "  min:" + triangle.getMin() + " max:" + triangle.getMax());        
        double slopeDist = triNormal.dot(x, y, z);
//log.info("slopeDist:" + slopeDist + " planeDist:" + planeDist + " radius:" + radius + "  triNormal:" + triNormal);        
        if( slopeDist >= planeDist + radius ) {
            //log.info("-----Above slope");
            return null;
        }
//log.info("Could collide");
        
        // We collide with the slope, we collide with the sides, or we collide
        // with all of the above.
        // If we intersect with the slope then it's a relatively simple matter to
        // calculate the closest point to the sphere on the slope and then clamp
        // it to the box area.  If that point is within the sphere radius and the sphere
        // center is above the slope then that's where we've collided.
        // If the sphere center is below the slope then we've collided with one 
        // of the box sides... and can use regular box collision style code to
        // calculate that.  (Clamp sphere position to the box, basically.)
        // The exception to the above is if the center of the sphere is within the cube
        // bounds and intersects the slope then we are always colliding with the 
        // slope... whether we are above or below the slope.
        // Note: "above the slope" is interesting in this case because a sphere is
        // above the slope if its contact point is on the slope in the unclamped 
        // range.  Think about when the sphere is near the narrow lip.  The center
        // might be over the end of the lip but we are still "on the slope".
        
        // Calculate the contact point on the slope
        // slopeDist is the sphere's distance from the origin.
        // ...the distance from the slope is then slopeDist - planeDist.
        double dist = slopeDist - planeDist;
        // So we can project backwards from the sphere's location along the triangle normal
        double spx = x - triNormal.x * dist;
        double spy = y - triNormal.y * dist;
        double spz = z;
        double bpx = x;
        double bpy = y;
        double bpz = z;
//log.info("tri space slope intersect:" + spx + ", " + spy + ", " + spz);
//log.info("   xMin:" + xMin + " xMax:" + xMax);
        double cpDist = dist;
        boolean outsideVolume = false;
        boolean clampedSlopePoint = false;
 
        // If we are below the slope plane then we do different 'outside'
        // checks because it's based on the sphere position relative to
        // the cube rather than where the clipped slope contact point is.
        // This is to cover the case where our center causes us to have
        // an in-slope contact point on the slope but our sphere center is
        // actually outside the cube and so we should intersect with the cube
        // side.  
        // We add the spy check, too because that means we are below the base
        // of the triangle and if we are outside in that case then we should stop
        // intersecting with the slope.
        boolean belowSlope = dist < 0 || y < 0; 
//log.info("belowSlope:" + belowSlope);
        double bxNormal = 0;
        double byNormal = 0;
        double bzNormal = 0;
        double sideDist = Double.POSITIVE_INFINITY;        
        if( belowSlope ) {
            if( x < xMin ) {
                bpx = xMin;
                outsideVolume = true;
                sideDist = 0;
            } else if( x > xMax ) {
                bpx = xMax;
                outsideVolume = true;
                sideDist = 0;
            } else {
//log.info("  x is inside");
                bpx = x;
                // Keep track of how far we penetrate from one side or
                // the other... we want the shortest one and we want to
                // remember direction.
                if( x - xMin < xMax - x ) {
                    if( x - xMin < sideDist ) {                    
                        bxNormal = -1;
                        sideDist = x - xMin;
                    }
                } else {
                    if( xMax - x < sideDist ) {
                        bxNormal = 1;
                        sideDist = xMax - x;
                    }
                }
            }
            if( y < yMin ) {
                bpy = yMin;
                outsideVolume = true;
                sideDist = 0;
                bxNormal = 0;
            } else if( y > yMax ) {
                bpy = yMax;
                outsideVolume = true;
                sideDist = 0;
                bxNormal = 0;
            } else {
//log.info("  y is inside");
                bpy = y;
                if( y - yMin < yMax - y ) {
                    if( y - yMin < sideDist ) {
                        bxNormal = 0;
                        byNormal = -1;
                        sideDist = y - yMin;
                    }
                } else {
                    if( yMax - y < sideDist ) {
                        bxNormal = 0;
                        byNormal = 1;
                        sideDist = yMax - y;
                    }
                }
            }
            if( z < 0 ) {
                bpz = 0;
                outsideVolume = true;
                sideDist = 0;
                bxNormal = 0;
                byNormal = 0;
            } else if( z > 1 ) {
                bpz = 1;
                outsideVolume = true;
                sideDist = 0;
                bxNormal = 0;
                byNormal = 0;
            } else {
//log.info("  z is inside");
                bpz = z;
                if( z < 1 - z ) {
                    if( z < sideDist ) {                    
                        bxNormal = 0;
                        byNormal = 0;
                        bzNormal = -1;
                        sideDist = z;
                    }
                } else {
                    if( 1 - z < sideDist ) {
                        bxNormal = 0;
                        byNormal = 0;
                        bzNormal = 1;
                        sideDist = 1 - z;
                    }
                }
            }
        }
        // Center is outside the volume or center is above the slope
        //log.info("center outside the volume:" + outsideVolume);
        
        // If the center of the sphere is below the slope then we've
        // already calculated the box intersect in bpx, bpy, bpz.
        // ...and if the center is inside the volume then we know 
        // how close to the side we are.
 
        // If the above didn't calculate us as being 'outside' then our center
        // is inside the box or above the slope and so we'll calculate and clip to slope.
        // The reason we calculate the above the slope value is to keep track of
        // if it's closer to the sphere center than the side distance.
        if( !outsideVolume ) {
            // If the contact point is outside of the slope's face range
            // then we can clamp it and calculate a new distance
            if( spx < xMin ) {
                spx = xMin;
                clampedSlopePoint = true;
            } else if( spx > xMax ) {
                spx = xMax;
                clampedSlopePoint = true;
                
                // And in this case, we also need to clamp y to where it would
                // be on the slope... which is 0 in triangle space
                spy = 0;
            }
            if( spy < yMin ) {
                spy = yMin;
                clampedSlopePoint = true;
            } else if( spy > yMax ) {
                spy = yMax;
                clampedSlopePoint = true;
            }
            if( spz < 0 ) {
                spz = 0;
                clampedSlopePoint = true;
            } else if( spz > 1 ) {
                spz = 1;
                clampedSlopePoint = true;
            }
        }        
//log.info("slope point clamped to volume:" + clampedSlopePoint);
        
        // If clampedSloptPoint is true then it means that the center of the
        // sphere must be above the slope else the only reason we'd have 
        // calculated the above is because we were already known to be
        // inside the box and no clipping should happen in that case.
        
        // Now we need to pick a contact point, box or slope.  We should
        // be able to use whatever is 'closer'.
        double cpx = 0;
        double cpy = 0;
        double cpz = 0;
        double cpDistMult = 1;
        // We intersect the box sides if we are below the slope
        // and the side distance is less than the slope-plane distance
//log.info("slopeDist - planeDist:" + Math.abs(slopeDist - planeDist) + "  sideDist:" + sideDist);         
        if( belowSlope && sideDist < Math.abs(slopeDist - planeDist) ) {
            // We might be inside and then cp dist is backwards... we'll 
            // fix it if we find a coordinate outside
            cpDistMult = outsideVolume ? 1 : -1; 
            // Intersect the side
//log.info("...box intersect  norm:" + bxNormal + ", " + byNormal + ", " + bzNormal);
            if( bxNormal < 0 ) {
                cpx = xMin;
            } else if( bxNormal > 0 ) {
                cpx = xMax; 
            } else {
                cpx = bpx;
            }
            if( byNormal < 0 ) {
                cpy = yMin;
            } else if( byNormal > 0 ) {
                cpy = yMax; 
            } else {
                cpy = bpy;
            }
            if( bzNormal < 0 ) {
                cpz = 0;
            } else if( bzNormal > 0 ) {
                cpz = 1; 
            } else {
                cpz = bpz;
            }
        } else {
            // Intersect the slope
//log.info("...slope intersect");
            if( belowSlope ) {
                cpDistMult = -1;
            }
            cpx = spx;
            cpy = spy;
            cpz = spz;
        } 
        
        Vec3d cp = triangleOrigin.add(xDir.mult(cpx)).addLocal(yDir.mult(cpy)).addLocal(zDir.mult(cpz));
//log.info("reprojected:" + cp);
        //if( outsideVolume || clampedSlopePoint ) {
        // Probably we could optimize this in a lot of cases but this is the
        // most accurate way.
            cpDist = cellRelative.distance(cp);
        //} 
        cpDist *= cpDistMult;
//log.info("cpDist:" + cpDist + "  dist:" + dist + "  cpDistMult:" + cpDistMult);
            
        if( cpDist > radius ) {
            // Lot of work for nothing
//log.info("radius miss.");
            return null;            
        }
            
        MBlockContact result = new MBlockContact();
        result.contactPoint = cp.addLocal(cellOrigin);
        result.contactNormal = pos.subtract(cp).normalizeLocal();
        if( cpDist == 0 ) {
            result.penetration = radius;
            if( dist == 0 ) {
                // We are right on the slope
                result.contactNormal = worldNormal.clone();
            } else {
                // We have to reconstruct the normal from the sides
                // we are sitting on.  We might be on a corner but
                // at cpDist=0 it's ok to just pick one
                if( Math.abs(x - xMin) < 0.0001 ) {
                    result.contactNormal = xDir.mult(-1);
                } else if( Math.abs(x - xMax) < 0.0001 ) {
                    result.contactNormal = xDir.clone();
                } else if( Math.abs(y - yMin) < 0.0001 ) {
                    result.contactNormal = yDir.mult(-1);
                } else if( Math.abs(y - yMax) < 0.0001 ) {
                    result.contactNormal = yDir.clone();
                } else if( Math.abs(z - 0) < 0.0001 ) {
                    result.contactNormal = zDir.mult(-1);
                } else if( Math.abs(z - 1) < 0.0001 ) {
                    result.contactNormal = zDir.clone();
                }  
            }
        } else if( cpDist < 0 ) {
            // Our center is under the slope... which means normal is also
            // backwards
            result.penetration = radius - cpDist;
            result.contactNormal.multLocal(-1);
        //} else if( cpDistMult < 0 ) {
        //    result.penetration = radius + cpDist;
        } else {
            result.penetration = radius - cpDist;
        }

//log.info("  result:" + result);
        return result;
    }
    
    @Override   
    public MBlockContact getCubeContact( Vec3d cellOrigin, Vec3d pos, double radius, int dirMask ) {
        // For now, just treat it like a sphere contact
        return getSphereContact(cellOrigin, pos, radius, dirMask);
    }
 
    @Override   
    public RayHit getHit( Vec3d origin, Vec3d dir, int dirMask, RayHit store ) {
    
        boolean inside = true;
        int[] quadrant = new int[3];
        double[] maxT = new double[3];
        double[] candidatePlane = new double[3];
        
        // Find the candidate planes
        for( int i = 0; i < 3; i++ ) {
            if( origin.get(i) < min.get(i) ) {
                quadrant[i] = 1;
                candidatePlane[i] = min.get(i);
                inside = false;
            } else if( origin.get(i) > max.get(i) ) {
                quadrant[i] = 0;
                candidatePlane[i] = max.get(i);
                inside = false;
            } else {
                quadrant[i] = 2;
            }
        }
            
        if( inside ) {
            // If the origin is inside then it's never a hit for us
            return null;
        }
    
        // Calculate the T distances to the candidate planes.
        for( int i = 0; i < 3; i++ ) {
            if( quadrant[i] != 2 && dir.get(i) != 0 ) {
                maxT[i] = (candidatePlane[i]-origin.get(i)) / dir.get(i);
            } else {
                maxT[i] = -1; // purposely bogus value?
            }
        }            

        // Find the largest of the max Ts
        int whichPlane = 0;
        for( int i = 1; i < 3; i++ ) {
            if( maxT[i] > maxT[whichPlane] ) {
                whichPlane = i;
            }
        }

        // Check that final candidate is actually inside the box
        if( maxT[whichPlane] < 0 ) {
            return null;
        }
 
        if( store == null ) {
            store = new RayHit();
        }
                   
        for( int i = 0; i < 3; i++ ) {
            if( whichPlane != i ) {
                store.point.set(i, origin.get(i) + maxT[whichPlane] * dir.get(i));
                store.normal.set(i, 0 );
                if( store.point.get(i) < min.get(i) || store.point.get(i) > max.get(i) ) {
                    return null;  // intersection is outside box
                }                
            } else {
                store.point.set(i, candidatePlane[i]);
                store.normal.set(i, quadrant[i] == 0 ? 1 : -1);
            }
        }
    
        return store;
    }     

}
