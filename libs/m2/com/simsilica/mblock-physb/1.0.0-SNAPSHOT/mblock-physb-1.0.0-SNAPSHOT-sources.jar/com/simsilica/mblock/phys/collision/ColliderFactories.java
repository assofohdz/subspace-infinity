/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.BoundaryShape;
import com.simsilica.mblock.geom.BoundaryShapes.Triangle;
import com.simsilica.mblock.phys.Collider;

/**
 *  Registry of ColliderFactory objects keyed by ColliderType name.
 *
 *  @author    Paul Speed
 */
public class ColliderFactories {
    static Logger log = LoggerFactory.getLogger(ColliderFactories.class);

    private Map<String, ColliderFactory> registry = new HashMap<>();

    public ColliderFactories() {
        this(false);
    }

    public ColliderFactories( boolean initDefaults ) {
        if( initDefaults ) {
            initializeDefaults();
        }
    }

    public void initializeDefaults() {
        register("cube", new CubeColliderFactory());

        // FIXME: put the real colliders here
        register("wedge", new WedgeColliderFactory());
        // Note: wide wedge and hi wedge both use WedgeColliderFactory because
        // it's smart enough to figure out where the slope is from the shape
        // information.  The types are split into separate names to be more descriptive
        // and to make it easier for non-collision code to reason about volumes and stuff.
        // (Though ultimately they really should be looking at the shape info also.)
        register("wide-wedge", new WedgeColliderFactory());
        register("hi-wedge", new WedgeColliderFactory());
        register("wedge-corner", new CubeColliderFactory(true));
        register("angle", new AngleColliderFactory());
        register("cone-up", new CylinderColliderFactory(Vec3d.UNIT_Y, Vec3d.UNIT_X, Vec3d.UNIT_Z, true));
        register("cone-dn", new CylinderColliderFactory(Vec3d.UNIT_Y, Vec3d.UNIT_X, Vec3d.UNIT_Z, true));
        register("vcyl", new CylinderColliderFactory(Vec3d.UNIT_Y, Vec3d.UNIT_X, Vec3d.UNIT_Z, false));
        register("hcyl", new CubeColliderFactory(true));
        register("branch", new CubeColliderFactory(true));
        register("wedge-cyl", new CubeColliderFactory(true));
        register("shallow-corner", new CubeColliderFactory(true));
        register("hi-wedge-corner", new CubeColliderFactory(true));
        register("sphere", new SphereColliderFactory(false));
    }

    public void register( String name, ColliderFactory factory ) {
        registry.put(name, factory);
    }

    public Collider[] createColliders( BlockType[] types ) {
        Collider[] result = new Collider[types.length];
        for( int i = 0; i < result.length; i++ ) {
            result[i] = createCollider(types[i]);
            Object name = types[i] != null ? types[i].getName() : null;
            if( log.isTraceEnabled() ) {
                log.trace("types[" + i + "]=" + name + "   collider:" + result[i]);
            }
        }
        return result;
    }

    public Collider createCollider( BlockType type ) {
        if( type == null ) {
            return null;
        }
        ColliderType colliderType = type.getColliderType();
        if( colliderType == null ) {
            return null;
        }
        ColliderFactory factory = registry.get(colliderType.getName());
        if( factory == null ) {
            throw new IllegalArgumentException("No factory found for:" + colliderType.getName());
            //log.warn("No factory found for:" + colliderType.getName() + ", using CubeCollider");
            //factory = registry.get("cube");
        }
        Collider result = factory.createCollider(type);

        // Note: cube colliders are created with prerotated min/max and so
        // are already 'rotated'.  There is no special directional processing
        // and so this method should essentially be a no-op in that case.
        // Fixing a collision shape bug on 2021-03-07
        // 2021-03-08, colliderType can now indicate that no special rotation
        // is required also... but it's still good that the factory ignores it.
        //if( colliderType.getRotation() <= 0 ) {
        //    return result;
        //}
        //return result.rotate(colliderType.getRotation());
        // 2023-11-19 Since the factories are created for the type and the type
        // already knows its rotation, I'm going to leave it up to the factory
        // to sort out collider rotation and no longer rotate it here.
        // This is after implementing the wedge collider which essentially figures
        // out the rotation from the block type.  And cubes already do this, too.
        return result;
    }

    public static class CubeColliderFactory implements ColliderFactory {

        private boolean approximate;

        public CubeColliderFactory() {
        }

        public CubeColliderFactory( boolean approximate ) {
            this.approximate = approximate;
        }

        @Override
        public Collider createCollider( BlockType type ) {
            return new CubeCollider(type.getFactory().getMin(),
                                    type.getFactory().getMax(),
                                    // Type name is more useful than a general "cube" name
                                    type.getName().toString(),
                                    approximate);
                                    //"cube");
        }
    }

    public static class SphereColliderFactory implements ColliderFactory {
        private boolean approximate;

        public SphereColliderFactory( boolean approximate ) {
            this.approximate = approximate;
        }

        @Override
        public Collider createCollider( BlockType type ) {
            // Simple for now since we only support full spheres
            return new SphereCollider(type.getFactory().getMin(),
                                     type.getFactory().getMax(),
                                     // Type name is more useful than a general "cube" name
                                     type.getName().toString(),
                                     approximate);
        }
    }

    public static class WedgeColliderFactory implements ColliderFactory {
        private static Direction[] dirs = Direction.values();

        public WedgeColliderFactory() {
        }

        @Override
        public Collider createCollider( BlockType type ) {
            // Find the triangular side
            Triangle tri = null;
            for( int i = 0; i < 4; i++ ) {
                Direction dir = Direction.cardinalDirection(i);
                BoundaryShape shape = type.getShape(dir);
                if( shape instanceof Triangle ) {
                    tri = (Triangle)shape;
                    break;
                }
            }
            if( tri == null ) {
                throw new IllegalArgumentException("Block type does not have triangle shaped sides:" + type);
            }
            Direction up;
            if( tri.getNormal().y < 0 ) {
                up = Direction.Down;
            } else {
                up = Direction.Up;
            }
            return new WedgeCollider(type.getFactory().getMin(),
                                     type.getFactory().getMax(),
                                     type.getName().getRotation(),
                                     up,
                                     tri,
                                     // Type name is more useful than a general "cube" name
                                     type.getName().toString());
        }
    }

    public static class AngleColliderFactory implements ColliderFactory {

        public AngleColliderFactory() {
        }

        @Override
        public Collider createCollider( BlockType type ) {
            // rotation = 0 is north solid, west solid
            return new AngleCollider(type.getFactory().getMin(),
                                     type.getFactory().getMax(),
                                     type.getName().getRotation(),
                                     // Type name is more useful than a general "cube" name
                                     type.getName().toString());
        }

    }

    public static class CylinderColliderFactory implements ColliderFactory {
        private Vec3d axisDir;
        private Vec3d xDir;
        private Vec3d yDir;
        private boolean approximate;

        public CylinderColliderFactory( Vec3d axisDir, Vec3d xDir, Vec3d yDir, boolean approximate ) {
            this.axisDir = axisDir;
            this.xDir = xDir;
            this.yDir = yDir;
            this.approximate = approximate;
        }

        @Override
        public Collider createCollider( BlockType type ) {
            Integer rotation = type.getName().getRotation();
            Vec3d dir;
            Vec3d x;
            Vec3d y;
            if( rotation == null ) {
                dir = axisDir;
                x = xDir;
                y = yDir;
            } else {
                // Need to rotate it into the proper frame
                Quatd rot = Direction.getRotation(rotation);
                dir = rot.mult(axisDir);
                x = rot.mult(xDir);
                y = rot.mult(yDir);
            }
            // Find the radius and center
            double x1 = x.dot(type.getFactory().getMin());
            double y1 = y.dot(type.getFactory().getMin());
            double z1 = axisDir.dot(type.getFactory().getMin());
            double x2 = x.dot(type.getFactory().getMax());
            double y2 = y.dot(type.getFactory().getMax());
            double z2 = axisDir.dot(type.getFactory().getMax());

            Vec3d center = new Vec3d(x1, y1, z1).addLocal(x2, y2, z2).multLocal(0.5);
            double extent = Math.abs(z2 - center.z);
            double radius = Math.abs(x1 - center.x);

            return new CylinderCollider(center, axisDir, x, y, extent, radius, approximate);
        }
    }

}
