/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.mblock.phys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;
import com.simsilica.mphys.RigidBody;

/**
 *  An experimental class for collecting (optional) body-relative kinematic
 *  information about a part.
 *
 *  @author    Paul Speed
 */
public class KinematicInfo {
    static Logger log = LoggerFactory.getLogger(KinematicInfo.class);

    private Object id;
    private Vec3d lastLocation = new Vec3d();
    private Vec3d currentLocation = new Vec3d();
    private Quatd lastOrientation = new Quatd();
    private Quatd currentOrientation = new Quatd();
    private double scale;  // represents effect of kinematic force

    public KinematicInfo( Object id ) {  
        this.id = id;
    }

    public void initialize( Vec3d location, Quatd orientation ) {
        lastLocation.set(location);
        lastOrientation.set(orientation);
        currentLocation.set(location);
        currentOrientation.set(orientation);
    }

    public Object getId() {
        return id;
    }

    /**
     *  Sets the relative scale of kinematic effects, for example
     *  the difference between a tool that is engaged in a swing and a
     *  tool that is merely being animated as part of a walk cycle.
     */
    public void setScale( double scale ) {
        this.scale = scale;
    }

    public double getScale() {
        return scale;
    }

    public void update( Vec3d location, Quatd orientation ) {
        lastLocation.set(currentLocation);
        lastOrientation.set(currentOrientation);
        currentLocation.set(location);
        currentOrientation.set(orientation);
    }

    public Vec3d getLastLocation() {
        return lastLocation;
    }

    public Vec3d getCurrentLocation() {
        return currentLocation;
    }

    public Quatd getLastOrientation() {
        return lastOrientation;
    }

    public Quatd getCurrentOrientation() {
        return currentOrientation;
    }

    public Vec3d getLinearVelocity() {
        return currentLocation.subtract(lastLocation);
    }

    private static Vec3d parentToChild( Vec3d loc, Vec3d childLoc, Quatd childOrient ) {
        Vec3d relative = loc.subtract(childLoc);
        childOrient.inverse().mult(relative, relative);
        return relative;
    }

    private static Vec3d childToParent( Vec3d loc, Vec3d childLoc, Quatd childOrient ) {
        Vec3d result = childOrient.mult(loc);
        result.addLocal(childLoc);
        return result;
    }

    /**
     *  Returns the velocity of the specified current point in world space
     *  by projecting backwards to the last location+orientation.
     *
     *  @param point the point in the world space.
     */
    public Vec3d getPointVelocity( RigidBody<?, MBlockShape> body, Vec3d point ) {
 
        // Find the point in 'rigid body space'
        Vec3d bodyCp = body.worldToLocal(point, null);

        // From there we can get the contact point in shape space
        Vec3d shapeCp = body.shape.bodyToShape(bodyCp, null);

        // Figure out where that point is relative to the current kinematic
        // info.
        Vec3d kNowRelative = parentToChild(shapeCp, currentLocation, currentOrientation);

        // In theory, the previous contact point in shape space is that point moved to the previous
        // reference frame
        Vec3d kPrevShape = childToParent(kNowRelative, lastLocation, lastOrientation);

        // Now we can project that back into world space
        Vec3d prevBodyCp = body.shape.shapeToBody(kPrevShape, null);

        // And then back into world space
        Vec3d prevCp = body.localToWorld(prevBodyCp, null);

        return point.subtract(prevCp);
    }


    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("lastLocation", lastLocation)
            .add("lastOrientation", lastOrientation)
            .add("currentLocation", currentLocation)
            .add("currentOrientation", currentOrientation)
            .toString();
    }
}

