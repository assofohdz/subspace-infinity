/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Predicate;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mphys.*;
import com.simsilica.mblock.phys.collision.CubeCollider;

import com.simsilica.mworld.*;
import com.simsilica.mworld.base.*;
import com.simsilica.mworld.db.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MBlockCollisionSystem<K> implements CollisionSystem<K, MBlockShape> {

    static Logger log = LoggerFactory.getLogger(MBlockCollisionSystem.class);

    private double restitution = Contact.DEFAULT_RESTITUTION;
    private double friction = Contact.DEFAULT_FRICTION;

    private World world;
    private Collider[] colliders;

    public MBlockCollisionSystem( World world, Collider[] colliders ) {
        this.world = world;
        this.colliders = colliders;
    }

    public BlockColliderIterator rayIterator( Rayd ray, double limit ) {
        BlockIterator worldIterator = new BlockIterator(world, ray, limit);
        return new BlockColliderIterator(worldIterator, colliders);
    }

    public void setRestitution( double restitution ) {
        this.restitution = restitution;
    }

    public double getRestitution() {
        return restitution;
    }

    public void setFriction( double friction ) {
        this.friction = friction;
    }

    public double getFriction() {
        return friction;
    }

    public void generateWorldCollisions( RigidBody<K, MBlockShape> body, ContactListener<K, MBlockShape> results ) {

        Part rootPart = body.shape.getPart();
        generateWorldCollisions(rootPart, body.shape.getMass().getCog(), body, results);
    }

    private void generateWorldCollisions( Part part, Vec3d rootCog, RigidBody<K, MBlockShape> body, ContactListener<K, MBlockShape> results ) {

        if( part instanceof Group ) {
            for( Part child : ((Group)part).traverse() ) {
                generateWorldCollisions(child, rootCog, body, results);
            }
            return;
        }

//log.info("generateWorldCollisions(" + part + ", " + rootCog + ", " + body.id + ")");

        // Figure out the range of leafs we must intersect
        Vec3d cogPos = part.getShapeRelativeCog().subtract(rootCog);
        body.localToWorld(cogPos, cogPos);

        Vec3d partOrigin = part.getShapeRelativePosition().subtract(rootCog);
        body.localToWorld(partOrigin, partOrigin);
        Quatd partOrientation = body.orientation.mult(part.getShapeRelativeOrientation());

        double radius = part.getMass().getRadius();

        if( cogPos.y - radius < 0 ) {
            return;
        }

        Vec3i min = LeafId.fromWorld(cogPos.x - radius, cogPos.y - radius, cogPos.z - radius).getWorld(null);
        Vec3i max = LeafId.fromWorld(cogPos.x + radius, cogPos.y + radius, cogPos.z + radius).getWorld(null);
        int size = WorldGrids.LEAF_SIZE;

        if( part instanceof CellArrayPart ) {
            CellArrayPart cellPart = (CellArrayPart)part;

            Vec3d pos = new Vec3d();
            for( int x = min.x; x <= max.x; x += size ) {
                for( int y = min.y; y <= max.y; y += size ) {
                    for( int z = min.z; z <= max.z; z += size ) {
                        LeafId leafId = LeafId.fromWorld(x, y, z);
                        LeafData leaf = world.getLeaf(leafId);
//log.info("pos:" + x + ", " + y + ", " + z + "  leafId:" + leafId + "  leaf:" + leaf + "  isEmpty:" + leaf.isEmpty());
                        if( leaf == null || leaf.isEmpty() ) {
                            continue;
                        }

                        pos.set(x, y, z);

                        switch( cellPart.getType() ) {
                            case Sphere:
                                sphereToWorld(body, cogPos, radius, pos, leaf.getRawCells(), results);
                                break;
                            case Blocks:
                                blocksToWorld(body, cellPart, partOrigin, partOrientation,
                                              pos, leaf.getRawCells(), results);
                                break;
                        }
                    }
                }
            }
        } else {
            // Just some default behavior
            Vec3d pos = new Vec3d();
            for( int x = min.x; x <= max.x; x += size ) {
                for( int y = min.y; y <= max.y; y += size ) {
                    for( int z = min.z; z <= max.z; z += size ) {
                        LeafId leafId = LeafId.fromWorld(x, y, z);
                        LeafData leaf = world.getLeaf(leafId);
                        if( leaf == null || leaf.isEmpty() ) {
                            continue;
                        }

                        pos.set(x, y, z);

                        sphereToWorld(body, cogPos, radius, pos, leaf.getRawCells(), results);
                    }
                }
            }
        }

    }

    /**
     *  Converts a direction vector to a normal by either dividing by distance
     *  or creating a random perterbation if dist is 0.
     */
    private static Vec3d toNormal( Vec3d delta, double dist ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
        log.trace("Random deflect.");
        delta.x = Math.random() * 0.1;
        delta.y = Math.random() * 0.1;
        delta.z = Math.random() * 0.1;
        return delta.normalizeLocal();
    }

    private static Vec3d toNormal( Vec3d delta, double dist, Vec3d fallback ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
        if( fallback.lengthSq() == 1 ) {
            return fallback;
        }
        return toNormal(fallback, fallback.length());
    }

    /**
     *  Check the cog-centered bounding spheres of the parts to see if they
     *  intersect.
     */
    private boolean broadPhase( AbstractBody<K, MBlockShape> b1, Part p1, AbstractBody<K, MBlockShape> b2, Part p2 ) {
        // The fact that we are constantly subtracting the rootCog means
        // we should be including it automatically in the getShapeRelativeCog().
        Vec3d cog1 = p1.getShapeRelativeCog().subtract(b1.shape.getPart().getMass().getCog());
        b1.localToWorld(cog1, cog1);

        Vec3d cog2 = p2.getShapeRelativeCog().subtract(b2.shape.getPart().getMass().getCog());
        b2.localToWorld(cog2, cog2);

        double distSq = cog1.distanceSq(cog2);
        double rrSq = p1.getMass().getRadius() + p2.getMass().getRadius();
        rrSq *= rrSq;

        return distSq <= rrSq;
    }

    // Note: the only real difference between this method and checkContact()
    // is in the blocksToBlocks() priority sorting.  We always assume that static
    // objects get real shape checks where as checkContact() looks at object priority.
    // We could probably consolidate these two methods just by making sure static shapes
    // always sort properly in that priority check.
    private void checkStaticContact( RigidBody<K, MBlockShape> body, StaticBody<K, MBlockShape> world, ContactListener<K, MBlockShape> results ) {

        if( !broadPhase(body, body.shape.getPart(), world, world.shape.getPart()) ) {
            return;
        }
        //log.info("passed broadphase:" + body + "  static:" + world);

        Part[] arr1 = body.shape.getPart().traverse();
        Part[] arr2 = world.shape.getPart().traverse();

        // No way to avoid an n x m comparison
        for( int i = 0; i < arr1.length; i++ ) {
            // Right now, all of these parts will be CellArrayParts as the
            // only other Part subclass is Group and only leaves are returned
            // in the traverse() results.
            CellArrayPart p1 = (CellArrayPart)arr1[i];
            CellArrayPart.Type type1 = p1.getType();

            for( int j = 0; j < arr2.length; j++ ) {
                CellArrayPart p2 = (CellArrayPart)arr2[j];
                CellArrayPart.Type type2 = p2.getType();

                // Right now there are only two types and so we
                // can simplify the if chain a bit.  If there are
                // ever more than two types then each if clause will have
                // to be expanded to include type1 and type2 checks.
                // The tricky part is that it checks per part.
                // There is also some additional casting that would have
                // to happen since contacts currently have to have RigidBody
                // objects.

                if( type1 == type2 ) {
                    if( type1 == CellArrayPart.Type.Sphere ) {
                        sphereToSphere(body, p1, world, p2, results);
                    } else {
                        // Must be two block objects
                        // No order check because static objects are always the higher priority,
                        // ie: second.
                        blocksToBlocks(body, p1, world, p2, results);
                    }
                } else if( type1 == CellArrayPart.Type.Sphere ) {
                    sphereToBlocks(body, p1, world, p2, results);
                } else if( type1 == CellArrayPart.Type.Blocks ) {
                    // We don't really support the blocks body to static sphere case
                    sphereToSphere(body, p1, world, p2, results);
                } else {
                    throw new UnsupportedOperationException(type1 + " to " + type2 + " collisions not yet supported.");
                }


            }
        }

    }

    private void checkContact( RigidBody<K, MBlockShape> b1, RigidBody<K, MBlockShape> b2, ContactListener<K, MBlockShape> results ) {

        if( b1.shape == null ) {
            throw new IllegalArgumentException("Body:" + b1.id + " has null shape");
        }
        if( b2.shape == null ) {
            throw new IllegalArgumentException("Body:" + b2.id + " has null shape");
        }

        if( !broadPhase(b1, b1.shape.getPart(), b2, b2.shape.getPart()) ) {
            return;
        }

        Part[] arr1 = b1.shape.getPart().traverse();
        Part[] arr2 = b2.shape.getPart().traverse();

        // No way to avoid an n x m comparison
        for( int i = 0; i < arr1.length; i++ ) {
            // Right now, all of these parts will be CellArrayParts as the
            // only other Part subclass is Group and only leaves are returned
            // in the traverse() results.
            CellArrayPart p1 = (CellArrayPart)arr1[i];
            CellArrayPart.Type type1 = p1.getType();

            for( int j = 0; j < arr2.length; j++ ) {
                CellArrayPart p2 = (CellArrayPart)arr2[j];
                CellArrayPart.Type type2 = p2.getType();

                // Right now there are only two types and so we
                // can simplify the if chain a bit.  If there are
                // ever more than two types then each if clause will have
                // to be expanded to include type1 and type2 checks.

                if( type1 == type2 ) {
                    if( type1 == CellArrayPart.Type.Sphere ) {
                        sphereToSphere(b1, p1, b2, p2, results);
                    } else {
                        // Figure out how to order them...
                        double priority1 = p1.getBlockCollisionPriority();
                        double priority2 = p2.getBlockCollisionPriority();
                        if( priority1 <= priority2 ) {
                            // The order is already ok... p2 gets the more accurate "static-style" checks
                            blocksToBlocks(b1, p1, b2, p2, results);
                        } else {
                            // Swap the order so b1 gets the more accurate "static-style" check
                            blocksToBlocks(b2, p2, b1, p1, results);
                        }
                    }
                } else if( type1 == CellArrayPart.Type.Sphere ) {
                    sphereToBlocks(b1, p1, b2, p2, results);
                } else if( type1 == CellArrayPart.Type.Blocks ) {
                    // Sphere goes first
                    sphereToBlocks(b2, p2, b1, p1, results);
                } else {
                    throw new UnsupportedOperationException(type1 + " to " + type2 + " collisions not yet supported.");
                }
            }
        }
    }

    @Override
    public void generateStaticCollisions( RigidBody<K, MBlockShape> body, StaticBody<K, MBlockShape>[] staticObjects, ContactListener<K, MBlockShape> results ) {
        for( StaticBody<K, MBlockShape> world : staticObjects ) {
            checkStaticContact(body, world, results);
        }
    }

    @Override
    public void generateBodyCollisions( RigidBody<K, MBlockShape> body, RigidBody<K, MBlockShape>[] inactiveObjects, ContactListener<K, MBlockShape> results ) {
        for( RigidBody<K, MBlockShape> sleeper : inactiveObjects ) {
            checkContact(body, sleeper, results);
        }
    }

    @Override
    public void generateBodyCollisions( RigidBody<K, MBlockShape>[] bodies, ContactListener<K, MBlockShape> results ) {
        for( int i = 0; i < bodies.length; i++ ) {
            RigidBody<K, MBlockShape> b1 = bodies[i];

            for( int j = i + 1; j < bodies.length; j++ ) {
                RigidBody<K, MBlockShape> b2 = bodies[j];
                checkContact(b1, b2, results);
            }
        }
    }

    @Override
    public void generateStaticCollisions( RigidBody<K, MBlockShape> body, StaticBody<K, MBlockShape>[] staticObjects,
                                          Predicate<? super StaticBody<K, MBlockShape>> bodyFilter,
                                          ContactListener<K, MBlockShape> results ) {
        for( StaticBody<K, MBlockShape> world : staticObjects ) {
            if( bodyFilter.apply(world) ) {
                checkStaticContact(body, world, results);
            }
        }
    }

    @Override
    public void generateBodyCollisions( RigidBody<K, MBlockShape> body, RigidBody<K, MBlockShape>[] inactiveObjects,
                                        Predicate<? super RigidBody<K, MBlockShape>> bodyFilter,
                                        ContactListener<K, MBlockShape> results ) {
        for( RigidBody<K, MBlockShape> sleeper : inactiveObjects ) {
            if( bodyFilter.apply(sleeper) ) {
                checkContact(body, sleeper, results);
            }
        }
    }

    /**
     *  Sort of the unversal "broad phase" check.  The physics space's bin index
     *  is already doing the super-broad phase for us.  This is a straight elimination
     *  based on radius.
     */
    private boolean inRange( AbstractBody b1, AbstractBody b2 ) {
        double r1 = b1.shape.getMass().getRadius();
        double r2 = b2.shape.getMass().getRadius();

        double threshold = (r1 + r2) * (r1 + r2);

        double distSq = b1.position.distanceSq(b2.position);
        return distSq <= threshold;
    }

    @SuppressWarnings("unchecked")
    private Collider<K> getCollider( int type ) {
        return (Collider<K>)colliders[type];
    }

    private void sphereToSphere( RigidBody<K, MBlockShape> b1, Part p1, AbstractBody<K, MBlockShape> b2, Part p2, ContactListener<K, MBlockShape> results ) {

        // Spheres are done with CoG so that's easy
        Vec3d cog1 = p1.getShapeRelativeCog().subtract(b1.shape.getPart().getMass().getCog());
        b1.localToWorld(cog1, cog1);

        Vec3d cog2 = p2.getShapeRelativeCog().subtract(b2.shape.getPart().getMass().getCog());
        b2.localToWorld(cog2, cog2);

        double r1 = p1.getMass().getRadius();
        double r2 = p2.getMass().getRadius();
        double threshold = (r1 + r2) * (r1 + r2);

        double distSq = cog1.distanceSq(cog2);
        if( distSq > threshold ) {
            // No intersection
            return;
        }

        double dist = Math.sqrt(distSq);

        // Contact point is directly in the middle
        // No, dummy... that's only true if they are the same size.
        // Vec3d cp = b2.position.add(b1.position).mult(0.5);
        // Well, I mean technically it depends on whether you want the
        // cp on one of the surfaces or in between the surfaces, etc... but
        // a pure average is not right because for big sphere to small sphere
        // collisions it puts it way inside the big sphere.
        Vec3d cp;
        if( dist > 0 ) {
            // Contact point is down the vector between them but the radius amount
            // We put it on the surface of the second body arbitrarily.  The
            // first one is more likely to be a mob in a mob->static hit.
            // That's the way the normal points, anyway.
            Vec3d delta = cog1.subtract(cog2);
            cp = delta.multLocal(r2/dist).addLocal(cog2);
        } else {
            // Else cp is just one of the positions
            cp = cog1;
        }

        // Contact normal points away from the static object
        // body1 contacts body2 so the normal is on body2... which in this case is the
        // world.
        Vec3d cn = toNormal(cog1.subtract(cog2), dist);

        double penetration = r1 - (dist - r2);

        MBlockContact<K> contact = new MBlockContact<>(b1, b2, cp, cn, penetration);
        contact.part1 = p1;
        contact.part2 = p2;
        contact.restitution = restitution;
        contact.friction = friction;
        if( log.isTraceEnabled() ) {
            log.trace("sphereToSphere(): Contact:" + contact);
        }
        results.newContact(contact);
    }

boolean debug = false;

    /**
     *  Collides a sphere part (p1) with a blocks part (p2).
     */
    private void sphereToBlocks( RigidBody<K, MBlockShape> b1, CellArrayPart p1, AbstractBody<K, MBlockShape> b2, CellArrayPart p2, ContactListener<K, MBlockShape> results ) {

//log.info("sphereToBlocks(" + p1 + ", " + p2 + ")");
        // Find the world position of the sphere
        Vec3d world = p1.getWorldPosition(b1, null);


if( debug ) System.out.println("Sphere world:" + world + "\nblocks world:" + p2.getWorldPosition(b2, null));

        // Translate that into block space
        Vec3d local = b2.worldToLocal(world, null);
if( debug ) System.out.println("raw local:" + local);
if( debug ) System.out.println("part cog:" + b2.shape.getPart().getMass().getCog());
        local.addLocal(b2.shape.getPart().getMass().getCog());
if( debug ) System.out.println("adjusted local:" + local);
        Vec3d spherePos = p2.shapeToCell(local, null);

if( debug ) System.out.println("Sphere in local:" + spherePos);

        // Find the radius in world space
        double sphereRadius = p1.getRadius() * p1.getScale();

        // Find the radius in cell space
        double localRadius = sphereRadius / p2.getScale();

if( debug ) System.out.println("Sphere world radius:" + sphereRadius + "  localRadius:" + localRadius);

        // Project the sphere into the range of coordinates that we
        // will need to check.  One thing to remember is that the center
        // of the sphere is mapped relative to the center of cells.
        // So if 'cell' is 1, 1, 1 and radius is 1 then that legitimately
        // means we need to check 0..2 because the sphere actually goes
        // from 0.5..2.5 centered on 1.5
        int xStart = (int)Math.floor(spherePos.x - localRadius);
        int yStart = (int)Math.floor(spherePos.y - localRadius);
        int zStart = (int)Math.floor(spherePos.z - localRadius);
        int xEnd = (int)Math.floor(spherePos.x + localRadius);
        int yEnd = (int)Math.floor(spherePos.y + localRadius);
        int zEnd = (int)Math.floor(spherePos.z + localRadius);

if( debug ) {
    System.out.println("start:" + xStart + ", " + yStart + ", " + zStart);
    System.out.println("end:" + xEnd + ", " + yEnd + ", " + zEnd);
}
        CellArray cells = p2.getCells();
        if( cells == null ) {
            return;
        }
        int sx = cells.getSizeX();
        int sy = cells.getSizeY();
        int sz = cells.getSizeZ();
if( debug ) System.out.println("cell array size:" + sx + ", " + sy + ", " + sz);

        // See if the sphere is even within the bounds of our cells
        // Basic array bounds check that definitely eliminates any intersection
        if( xStart >= sx ) {
if( debug ) System.out.println("x too high");
            return;
        }
        if( yStart >= sy ) {
if( debug ) System.out.println("y too high");
            return;
        }
        if( zStart >= sz ) {
if( debug ) System.out.println("z too high");
            return;
        }
        if( xEnd < 0 ) {
if( debug ) System.out.println("x too low");
            return;
        }
        if( yEnd < 0 ) {
if( debug ) System.out.println("y too low");
            return;
        }
        if( zEnd < 0 ) {
if( debug ) System.out.println("z too low");
            return;
        }

        // And clamp the rest
        if( xStart < 0 ) {
            xStart = 0;
        }
        if( yStart < 0 ) {
            yStart = 0;
        }
        if( zStart < 0 ) {
            zStart = 0;
        }
        if( xEnd >= sx ) {
            xEnd = sx - 1;
        }
        if( yEnd >= sy ) {
            yEnd = sy - 1;
        }
        if( zEnd >= sz ) {
            zEnd = sz - 1;
        }

if( debug ) {
    System.out.println("clamped start:" + xStart + ", " + yStart + ", " + zStart);
    System.out.println("clamped end:" + xEnd + ", " + yEnd + ", " + zEnd);
}

        Vec3d cellPos = new Vec3d();
        for( int i = xStart; i <= xEnd; i++ ) {
            for( int j = yStart; j <= yEnd; j++ ) {
                for( int k = zStart; k <= zEnd; k++ ) {
                    int val = cells.getCell(i, j, k);
                    if( val == 0 ) {
                        continue;
                    }

                    int type = MaskUtils.getType(val);
                    Collider<K> collider = getCollider(type);
                    if( collider == null ) {
                        continue;
                    }

                    int mask = MaskUtils.getSideMask(val);

                    cellPos.set(i, j, k);

CubeCollider.debug = debug;
                    MBlockContact<K> c = collider.getSphereContact(cellPos, spherePos, localRadius, mask);
                    if( c != null ) {
                        c.part1 = p1;
                        c.part2 = p2;
                        c.type2 = type;

                        // Need to convert the contact position and normal to be back in
                        // world space... penetration needs to be rescaled, etc..
                        p2.cellToWorld(b2, c.contactPoint, c.contactPoint);

                        p2.getShapeRelativeOrientation().mult(c.contactNormal, c.contactNormal);
                        b2.orientation.mult(c.contactNormal, c.contactNormal);

                        c.penetration = c.penetration * p2.getScale();

                        c.setBodies(b1, b2);
                        if( log.isTraceEnabled() ) {
                            log.trace("spherToBlocks(): Contact:" + c);
                        }
                        results.newContact(c);
                    }
                }
            }
        }

    }


    /**
     *  The caller will provide us bodies in smallest to largest order... or really
     *  "inaccurate" to "accurate" order.  One body we approximate all of its cells
     *  as cubes oriented in the "accurate" block's space... where we check those
     *  "inaccurate" blocks against the real colliders.  So if you have a ramp
     *  in the "inaccurate" object it's treated like an target-axis oriented cube.  If you
     *  have a ramp in the "accurate" object then it's treated like a ramp.
     *  2019-11-26 note: I haven't checked for sure right now but I think the 'inaccurate'
     *  cells are actually treated as spheres at this point.
     */
    private void blocksToBlocks( RigidBody<K, MBlockShape> b1, CellArrayPart p1, AbstractBody<K, MBlockShape> b2, CellArrayPart p2, ContactListener<K, MBlockShape> results ) {

        //sphereToSphere(b1, p1, b2, p2, results);

        // For the sake of clarity, "source" will be the less accurate mobile
        // object.  "target" will be the more accurate, possibly static, object.

        // General approach, iterate over "source" cells, project them into
        // "target" space, check "source" against "target" cells (in a source-cell-size bracket)
        // using colliders from the target.
        //
        // We will precalculate a bunch of stuff and project them into target's space.
        // Such as source's origin, x,y,z axes, and cell size.

        // Note: an optimization would be to start from the corner of deepest penetration
        // based on the object's radii.  In that case, we will want to calculate both
        // our corner position as well as the x, y, z step that will correspond to our axes.
        // Thus I will keep those as variables when they might seem obvious otherwise.

        double targetCellSize = p2.getScale();
        double sourceCellSize = p1.getScale();

        // WORLD SPACE CALCULATIONS... source to world

        // Find the position of our corner in world space...
        // but we don't want the corner of the cell we want the center
        // of the cell so we'll start at 0.5, 0.5, 0.5
        Vec3d corner = p1.cellToWorld(b1, new Vec3d(0.5, 0.5, 0.5), null);

        // Define our axes in source object space
        Vec3d xAxis = new Vec3d(1, 0, 0);
        int xStart = 0;
        int xStep = 1;
        Vec3d yAxis = new Vec3d(0, 1, 0);
        int yStart = 0;
        int yStep = 1;
        Vec3d zAxis = new Vec3d(0, 0, 1);
        int zStart = 0;
        int zStep = 1;

        // Orient them to world space...
        // First rotate them from part space to shape space.
        Quatd orient = p1.getShapeRelativeOrientation();
        // Then from shape space to world space
        orient = b1.orientation.mult(orient);
        orient.mult(xAxis, xAxis);
        orient.mult(yAxis, yAxis);
        orient.mult(zAxis, zAxis);


        // TARGET SPACE CALCULATIONS... world to target

        // Get the corner position in target space...
        Vec3d sourceCorner = p2.worldToCell(b2, corner, null);

        // Rotate the world axes into target's space
        // First rotate them into body/shape space
        Quatd toBody = b2.orientation.inverse();
        // Then to part space
        Quatd toPart = p2.getShapeRelativeOrientation().inverse().mult(toBody);
        toPart.mult(xAxis, xAxis);
        toPart.mult(yAxis, yAxis);
        toPart.mult(zAxis, zAxis);

        // Soure scale is essentially the block size of a unit block.
        // We need this scale in target's cell space
        // Note: we do not rescale this amount for the axes scaling because
        // we want things to step in the normal distances.  We only want collisions
        // to use the larger source block radius.
        // 2019-12-01: wait, what?  Below we scale the axes... so I'm not sure
        // what that's talking about.  Maybe it was talking about the motion based
        // rescale that I used to do and removed.  That must be it.  That approach
        // can't really work because it makes things super-fat and they affect things
        // around them when moving fast.  If anything we need to only scale in one
        // direction which makes things badly non-orthogonal.  We may also need to
        // just do multiple collision checks.  Tunneling is a problem for another day
        // as it's related to a bunch of other penetration related issues we will have.
        double sourceBlockSize = p1.getScale() / p2.getScale();
        double cellRadius = sourceBlockSize * 0.5;

        // Similarly scale our axes into target space from source space...
        // Essentially we want to step by our block size.  So it's easy.
        xAxis.multLocal(sourceBlockSize);
        yAxis.multLocal(sourceBlockSize);
        zAxis.multLocal(sourceBlockSize);

        // Get the size of our source object so we don't have to mess with it later
        CellArray sourceCells = p1.getCells();
        CellArray targetCells = p2.getCells();
        if( sourceCells == null || targetCells == null ) {
            return;
        }
        int xSize = sourceCells.getSizeX();
        int ySize = sourceCells.getSizeY();
        int zSize = sourceCells.getSizeZ();
        int xTargetSize = targetCells.getSizeX();
        int yTargetSize = targetCells.getSizeY();
        int zTargetSize = targetCells.getSizeZ();

        // Create some counters that we'll use in the inner loops.
        // These move along the source->target projected axes as we step through
        // the mesh cells
        // Addendum: I think we need to step on the centers else we will miss
        // blocks on the far sides... especially since we bracket based on cellRadius
        // in the inner loop.  post-2017-holiday.
        // 2019-12-01: but note that sphereToBlocks() needed to step at cell origins
        // because the collider is already adjusting for cell center... which may
        // not even be 0.5, 0.5, 0.5 in the end.
        Vec3d px = sourceCorner.clone();
        Vec3d py = new Vec3d();
        Vec3d pz = new Vec3d();

        int sx = xStart;
        for( int i = 0; i < xSize; i++, px.addLocal(xAxis), sx += xStep ) {
            py.set(px);
            int sy = yStart;
            for( int j = 0; j < ySize; j++, py.addLocal(yAxis), sy += yStep ) {
                pz.set(py);
                int sz = zStart;
                for( int k = 0; k < zSize; k++, pz.addLocal(zAxis), sz += zStep ) {

                    // See if there is anything at the source position
                    int sourceVal = sourceCells.getCell(sx, sy, sz);
                    if( sourceVal == 0 ) {
                        continue;
                    }
                    int sourceType = MaskUtils.getType(sourceVal);
                    if( sourceType == 0 ) {
                        continue;
                    }

                    // Note: for source objects we ignore masks because they
                    // won't be rotated properly anyway.  I guess technically we could
                    // come up with a major axis rotation mapping table but it's trickier
                    // than it sounds and would be inaccurate anyway.

                    // Calculate the cells in target space that we span... generally
                    // this will at most one extra in every direction for the typical
                    // cases where the source is the same as or smaller cell size than
                    // the target... but this will also handle the other way if we need it.
                    int xMin = Math.max(0, (int)Math.floor(pz.x - cellRadius));
                    int yMin = Math.max(0, (int)Math.floor(pz.y - cellRadius));
                    int zMin = Math.max(0, (int)Math.floor(pz.z - cellRadius));
                    int xMax = Math.min(xTargetSize - 1, (int)Math.ceil(pz.x + cellRadius));
                    int yMax = Math.min(yTargetSize - 1, (int)Math.ceil(pz.y + cellRadius));
                    int zMax = Math.min(zTargetSize - 1, (int)Math.ceil(pz.z + cellRadius));

                    // Generally, the bracket above will have the maxes 'exclusive'.
                    // I can't think of a case where that is't true but the old code
                    // used inclusive <= checks.  I think that's an extra cell in every direction.
                    // ...no because for a small cellRadius then xMin and xMax might be the same.
                    // Always need to be inclusive... the only case where we would ever hit an
                    // extra cell is when perfectly aligned wher x + cellRadius = floor(x) + 1

                    Vec3d targetPos = new Vec3d();
                    for( int tx = xMin; tx <= xMax; tx++ ) {
                        for( int ty = yMin; ty <= yMax; ty++ ) {
                            for( int tz = zMin; tz <= zMax; tz++ ) {

                                int targetVal = targetCells.getCell(tx, ty, tz);
                                if( targetVal == 0 ) {
                                    continue;
                                }

                                int targetType = MaskUtils.getType(targetVal);
                                if( targetType == 0 ) { // in case we go over the edge
                                    continue;
                                }

                                Collider<K> collider = getCollider(targetType);
                                if( collider == null ) {
                                    continue;
                                }

                                int mask = MaskUtils.getSideMask(targetVal);
                                if( mask == 0 ) {
                                    // Nothing will ever penetrate this but right now
                                    // this is also kind of an error
                                    //log.warn("No mask for:" + targetPos + "  Value:" + MaskUtils.valueToString(targetVal));
                                    // It happens when an object deep-penetrates the world... probably should
                                    // have some default behavior in this case, maybe an upward move causing penetration?
                                    // FIXME: deal with deep penetration in block objects.  In this case,
                                    //        probably push the objects apart.
                                    continue;
                                }

                                targetPos.set(tx, ty, tz);

                                MBlockContact<K> c = collider.getCubeContact(targetPos, pz, cellRadius, mask);
                                if( c != null ) {
                                    c.part1 = p1;
                                    c.type1 = sourceType;
                                    c.part2 = p2;
                                    c.type2 = targetType;

                                    // Note: the collider is returning the corner of the cell.
                                    // I think fixing this will break the sphere case until we
                                    // implement a proper getSphereContact() method.
                                    // 2019-12-01: there is a proper getSphereContact() method
                                    // and I'm no longer sure why returning the cell corner is
                                    // bad.

                                    // Need to convert the contact position and normal to be back in
                                    // world space... penetration needs to be rescaled, etc..
                                    p2.cellToWorld(b2, c.contactPoint, c.contactPoint);

                                    p2.getShapeRelativeOrientation().mult(c.contactNormal, c.contactNormal);
                                    b2.orientation.mult(c.contactNormal, c.contactNormal);

                                    c.penetration = c.penetration * p2.getScale();

                                    c.setBodies(b1, b2);
                                    if( log.isTraceEnabled() ) {
                                        log.trace("blocksToBlocks(): Contact:" + c);
                                    }
                                    results.newContact(c);
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    /**
     *  Translates the source part's blocks into the target axis-aligned cell space and
     *  treats the part's blocks as as tine spheres to hit the cell array's colliders.
     *  worldLoc is the corner of the 'leaf' origin in world space.  worldCells is the
     *  cell array containing the world data for this 'leaf'.
     *  sourceOrigin, sourceOrientation, and sourceCells describe the part in world space.
     */
    private void blocksToWorld( RigidBody<K, MBlockShape> body, CellArrayPart part,
                                Vec3d sourceOrigin, Quatd sourceOrientation,
                                Vec3d worldLoc, CellArray worldCells, ContactListener<K, MBlockShape> results ) {

        //log.info("blocksToWorld(" + body.id + ", " + part + ", " + worldLoc + ", " + worldCells + ")");

        // We assume that the caller already knows this body will potentially
        // intersect the worldCells.  It's more efficient for it to only check
        // what's relevant than it is for us to check inRange() every time.

        // See the description in blocksToBlocks() for how the algorithm works.
        // This is a simplified version that can make a ton of assumptions about
        // the target space.

        // WORLD SPACE CALCULATIONS... source to world
        //-------------------------------------------------
        // Find the position of our corner in world space...
        // but we don't want the corner of the cell we want the center
        // of the cell so we'll start at 0.5, 0.5, 0.5
        //
        // This was provided to us by the caller except without the
        // 0.5 adjustment.  And note: the 0.5 needs to be rotated into
        // body space
        Vec3d corner = new Vec3d(0.5, 0.5, 0.5).multLocal(part.getScale());
        //Vec3d corner = new Vec3d(0, 0, 0).multLocal(part.getScale());
        corner = sourceOrientation.mult(corner, corner);
        corner.addLocal(sourceOrigin);

        // Define our axes in source object space
        Vec3d xAxis = new Vec3d(1, 0, 0);
        int xStart = 0;
        int xStep = 1;
        Vec3d yAxis = new Vec3d(0, 1, 0);
        int yStart = 0;
        int yStep = 1;
        Vec3d zAxis = new Vec3d(0, 0, 1);
        int zStart = 0;
        int zStep = 1;

        // Orient them to world space
        sourceOrientation.mult(xAxis, xAxis);
        sourceOrientation.mult(yAxis, yAxis);
        sourceOrientation.mult(zAxis, zAxis);

        // TARGET SPACE CALCULATIONS... world to target
        //-------------------------------------------------
        // Get the corner position in target space...
        Vec3d sourceCorner = corner.subtract(worldLoc);

        // Soure scale is essentially the block size of a unit block.
        // We need this scale in target's cell space
        // Note: we do not rescale this amount for the axes scaling because
        // we want things to step in the normal distances.  We only want collisions
        // to use the larger source block radius.
        double sourceBlockSize = part.getScale();
        double cellRadius = sourceBlockSize * 0.5;

        // Similarly scale our axes into target space from source space...
        // Essentially we want to step by our block size.  So it's easy.
        xAxis.multLocal(sourceBlockSize);
        yAxis.multLocal(sourceBlockSize);
        zAxis.multLocal(sourceBlockSize);

        // Get the size of our source object so we don't have to mess with it later
        CellArray sourceCells = part.getCells();
        if( sourceCells == null ) {
            return;
        }
        int xSize = sourceCells.getSizeX();
        int ySize = sourceCells.getSizeY();
        int zSize = sourceCells.getSizeZ();
        int xTargetSize = worldCells.getSizeX();
        int yTargetSize = worldCells.getSizeY();
        int zTargetSize = worldCells.getSizeZ();

        // Create some counters that we'll use in the inner loops.
        // These move along the source->target projected axes as we step through
        // the mesh cells
        // Addendum: I think we need to step on the centers else we will miss
        // blocks on the far sides... especially since we bracket based on cellRadius
        // in the inner loop.  post-2017-holiday.
        Vec3d px = sourceCorner.clone();
        Vec3d py = new Vec3d();
        Vec3d pz = new Vec3d();

        int sx = xStart;
        for( int i = 0; i < xSize; i++, px.addLocal(xAxis), sx += xStep ) {
            py.set(px);
            int sy = yStart;
            for( int j = 0; j < ySize; j++, py.addLocal(yAxis), sy += yStep ) {
                pz.set(py);
                int sz = zStart;
                for( int k = 0; k < zSize; k++, pz.addLocal(zAxis), sz += zStep ) {

                    // See if there is anything at the source position
                    int sourceVal = sourceCells.getCell(sx, sy, sz);
                    if( sourceVal == 0 ) {
                        continue;
                    }
                    int sourceType = MaskUtils.getType(sourceVal);
                    if( sourceType == 0 ) {
                        continue;
                    }

                    // Note: for source objects we ignore masks because they
                    // won't be rotated properly anyway.  I guess technically we could
                    // come up with a major axis rotation mapping table but it's trickier
                    // than it sounds and would be inaccurate anyway.

                    // Calculate the cells in target space that we span... generally
                    // this will at most one extra in every direction for the typical
                    // cases where the source is the same as or smaller cell size than
                    // the target... but this will also handle the other way if we need it.
                    int xMin = Math.max(0, (int)Math.floor(pz.x - cellRadius));
                    int yMin = Math.max(0, (int)Math.floor(pz.y - cellRadius));
                    int zMin = Math.max(0, (int)Math.floor(pz.z - cellRadius));
                    int xMax = Math.min(xTargetSize - 1, (int)Math.ceil(pz.x + cellRadius));
                    int yMax = Math.min(yTargetSize - 1, (int)Math.ceil(pz.y + cellRadius));
                    int zMax = Math.min(zTargetSize - 1, (int)Math.ceil(pz.z + cellRadius));

                    // Generally, the bracket above will have the maxes 'exclusive'.
                    // I can't think of a case where that is't true but the old code
                    // used inclusive <= checks.  I think that's an extra cell in every direction.
                    // ...no because for a small cellRadius then xMin and xMax might be the same.
                    // Always need to be inclusive... the only case where we would ever hit an
                    // extra cell is when perfectly aligned wher x + cellRadius = floor(x) + 1

                    Vec3d targetPos = new Vec3d();
                    for( int tx = xMin; tx <= xMax; tx++ ) {
                        for( int ty = yMin; ty <= yMax; ty++ ) {
                            for( int tz = zMin; tz <= zMax; tz++ ) {

                                int targetVal = worldCells.getCell(tx, ty, tz);
                                if( targetVal == 0 ) {
                                    continue;
                                }

                                int targetType = MaskUtils.getType(targetVal);
                                if( targetType == 0 ) { // in case we go over the edge
                                    continue;
                                }

                                Collider<K> collider = getCollider(targetType);
                                if( collider == null ) {
                                    continue;
                                }

                                int mask = MaskUtils.getSideMask(targetVal);
                                if( mask == 0 ) {
                                    // Nothing will ever penetrate this but right now
                                    // this is also kind of an error
                                    //log.warn("No mask for:" + targetPos + "  Value:" + MaskUtils.valueToString(targetVal));
                                    // It happens when an object deep-penetrates the world... probably should
                                    // have some default behavior in this case, maybe an upward move causing penetration?
                                    continue;
                                }

                                targetPos.set(tx, ty, tz);

                                MBlockContact<K> c = collider.getCubeContact(targetPos, pz, cellRadius, mask);
                                if( c != null ) {
                                    c.part1 = part;
                                    c.type1 = sourceType;
                                    c.type2 = targetType;

                                    // Note: the collider is returning the corner of the cell.
                                    // I think fixing this will break the sphere case until we
                                    // implement a proper getSphereContact() method.

                                    // Need to convert the contact position back into
                                    // world space...
                                    c.contactPoint = worldLoc.add(c.contactPoint);
                                    c.setBodies(body, null);
                                    if( log.isTraceEnabled() ) {
                                        log.trace("blocksToWorld(): Contact:" + c);
                                    }
                                    results.newContact(c);
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    private void sphereToWorld( RigidBody<K, MBlockShape> body, Vec3d sphereLoc, double radius, Vec3d worldLoc, CellArray worldCells, ContactListener<K, MBlockShape> results ) {

        //log.info("sphereToWorld(" + body.id + ", " + sphereLoc + ", " + radius + ", " + worldLoc + ", " + worldCells + ")");

        // Find the sphere in block space
        Vec3d pos = sphereLoc.subtract(worldLoc);

        // Now we just have to iterate over the cells and check for intersection between
        // the sphere and exposed faces... easy, eh?  lol
        CellArray cells = worldCells;

        // We can actually project the sphere into the exact set of coordinates to check
        int xStart = (int)Math.floor(pos.x - radius);
        int yStart = (int)Math.floor(pos.y - radius);
        int zStart = (int)Math.floor(pos.z - radius);
        int xEnd = (int)Math.floor(pos.x + radius);
        int yEnd = (int)Math.floor(pos.y + radius);
        int zEnd = (int)Math.floor(pos.z + radius);

        int sx = cells.getSizeX();
        int sy = cells.getSizeY();
        int sz = cells.getSizeZ();

        // Basic array bounds check that definitely eliminates any intersection
        if( xStart >= sx ) {
            return;
        }
        if( yStart >= sy ) {
            return;
        }
        if( zStart >= sz ) {
            return;
        }
        if( xEnd < 0 ) {
            return;
        }
        if( yEnd < 0 ) {
            return;
        }
        if( zEnd < 0 ) {
            return;
        }

        // And clamp the rest
        if( xStart < 0 ) {
            xStart = 0;
        }
        if( yStart < 0 ) {
            yStart = 0;
        }
        if( zStart < 0 ) {
            zStart = 0;
        }
        if( xEnd >= sx ) {
            xEnd = sx - 1;
        }
        if( yEnd >= sy ) {
            yEnd = sy - 1;
        }
        if( zEnd >= sz ) {
            zEnd = sz - 1;
        }

        Vec3d cellPos = new Vec3d();
        for( int i = xStart; i <= xEnd; i++ ) {
            for( int j = yStart; j <= yEnd; j++ ) {
                for( int k = zStart; k <= zEnd; k++ ) {
                    int val = cells.getCell(i, j, k);
                    if( val == 0 ) {
                        continue;
                    }

                    int type = MaskUtils.getType(val);
                    Collider<K> collider = getCollider(type);
                    if( collider == null ) {
                        continue;
                    }
                    //log.info("[" + i + "][" + j + "][" + k + "]  type:" + type + "  collider:" + collider);

                    int mask = MaskUtils.getSideMask(val);
                    //log.info("mask:" + mask + "  val:" + Integer.toHexString(val));

                    cellPos.set(i, j, k);

CubeCollider.debug = false;
                    MBlockContact<K> c = collider.getSphereContact(cellPos, pos, radius, mask);
                    if( c != null ) {
                        c.part1 = body.shape.getPart();
                        c.type2 = type;

                        // Need to convert the contact position and normal to be in
                        // world space.
                        c.contactPoint = worldLoc.add(c.contactPoint);
                        c.setBodies(body, null);

                        if( log.isTraceEnabled() ) {
                            log.trace("sphereToWorld(): Contact:" + c);
                        }
                        results.newContact(c);
                    }
                }
            }
        }
    }

    @Override
    public void queryWorldHits( Rayd ray, HitResults<K, MBlockShape> hits ) {
        log.warn("queryWorldHits() not yet implemented.");
    }

    @Override
    public void queryBodyHits( Rayd ray, RigidBody<K, MBlockShape>[] bodies, HitResults<K, MBlockShape> hits ) {
        for( RigidBody<K, MBlockShape> body : bodies ) {
            queryBody(ray, body, hits);
        }
    }

    @Override
    public void queryStaticHits( Rayd ray, StaticBody<K, MBlockShape>[] staticObjects, HitResults<K, MBlockShape> hits ) {
        for( StaticBody<K, MBlockShape> body : staticObjects ) {
            queryBody(ray, body, hits);
        }
    }

    protected boolean broadPhase( Rayd ray, AbstractBody<K, MBlockShape> body, Part part, double limit ) {

        // Get the overall physics bounding sphere for the body.
        // The fact that we are constantly subtracting the rootCog means
        // we should be including it automatically in the getShapeRelativeCog().
        Vec3d cog = part.getShapeRelativeCog().subtract(body.shape.getPart().getMass().getCog());
        body.localToWorld(cog, cog);

        // The distance to the truncated ray.
        double distSq = ray.distanceSq(cog, limit);

        // If the sphere radius is greater than the distance then the ray
        // intersects the bounding sphere.
        double rSq = part.getMass().getRadius();
        rSq = rSq * rSq;

        return distSq <= rSq;
    }

    protected void queryBody( Rayd ray, AbstractBody<K, MBlockShape> body, HitResults<K, MBlockShape> hits ) {
        double limit = hits.getMaxDistance();

        // Perform a broadphase check to see if the ray will even hit the body in
        // this range
        if( !broadPhase(ray, body, body.shape.getPart(), limit) ) {
            return;
        }

        // We only keep the nearest hit for a particular body.  We may
        // want to make this optional at some point.
        Hit<K, MBlockShape> best = null;
        double minDist = limit == 0 ? Double.POSITIVE_INFINITY : limit;

        // Now we check each part
        Part[] arr = body.shape.getPart().traverse();
        for( Part part : arr ) {
            // Right now, all of these parts will be CellArrayParts as the
            // only other Part subclass is Group and only leaves are returned
            // in the traverse() results.
            CellArrayPart p = (CellArrayPart)part;
            CellArrayPart.Type type = p.getType();
            Hit<K, MBlockShape> hit;
            switch( type ) {
                default:
                case Sphere:
                    hit = rayToSphere(ray, limit, body, p);
                    break;
                case Blocks:
                    hit = rayToBlocks(ray, limit, body, p);
                    break;
            }
            if( hit != null && hit.distance < minDist ) {
                best = hit;
                minDist = hit.distance;
            }
        }

        if( best != null ) {
            hits.addHit(best);
        }
    }

    protected Hit<K, MBlockShape> rayToSphere( Rayd ray, double limit, AbstractBody<K, MBlockShape> body, CellArrayPart part ) {

        if( body.shape.getPart() != part ) {
            // Then we haven't broadphase checked this sphere yet and could
            // do so if optimal.  For a sphere, the broadphase check is not that
            // different from the intersection calculation.  An extra sqrt() is
            // the only expensive part.
        }
        Vec3d center = part.getShapeRelativeCog().subtract(body.shape.getPart().getMass().getCog());
        body.localToWorld(center, center);
        double radius = part.getMass().getRadius();

        // Intersect the sphere but only if origin is outside the sphere
        double distance = ray.intersectSphere(limit, center, radius, true);
        if( distance < 0 ) {
            // No hit
            return null;
        }

        // We have distance, now calculate the rest of the hit values
        Vec3d point = ray.project(distance, null);
        Vec3d normal = point.subtract(center).normalizeLocal();

        return new Hit<>(body, point, normal, distance);
    }

    protected Hit<K, MBlockShape> rayToBlocks( Rayd ray, double limit, AbstractBody<K, MBlockShape> body, CellArrayPart part ) {
        if( body.shape.getPart() != part ) {
            // Haven't done broadphase for this child part so do it
            // now
            if( !broadPhase(ray, body, part, limit) ) {
                return null;
            }
        }

        // Transform the ray into block space
        Vec3d orig = part.worldToCell(body, ray.getOrigin(), null);

        Quatd toBody = body.orientation.inverse();
        Quatd toPart = part.getShapeRelativeOrientation().inverse().mult(toBody);
        Vec3d dir = toPart.mult(ray.getDirection());

        // Make sure to scale limit up appropriately
        double scaledLimit = limit/part.getScale();

        // We can use a block/plane walk routine but we'll need to clip to block
        // space first... ie: find where this ray enters the cell array box
        CellArray cells = part.getCells();
        if( cells == null ) {
            return null;
        }
        double xSize = cells.getSizeX();
        double ySize = cells.getSizeY();
        double zSize = cells.getSizeZ();

        // One of three cases we care about.
        // 1) val < min, dir+
        // 2) val > max, dir-
        // 3) val between min and max
        double xDist = 0;
        if( orig.x < 0 ) {
            if( dir.x <= 0 ) {
                // Ray faces away from cells
                return null;
            }
            xDist = -orig.x / dir.x;
        } else if( orig.x > xSize ) {
            if( dir.x >= 0 ) {
                // Ray faces away from cells
                return null;
            }
            xDist = (orig.x-xSize)/-dir.x;
        } else {
            // inside the cell array already
        }
        double yDist = 0;
        if( orig.y < 0 ) {
            if( dir.y <= 0 ) {
                // Ray faces away from cells
                return null;
            }
            yDist = -orig.y / dir.y;
        } else if( orig.y > ySize ) {
            if( dir.y >= 0 ) {
                // Ray faces away from cells
                return null;
            }
            yDist = (orig.y-ySize)/-dir.y;
        } else {
            // inside the cell array already
        }
        double zDist = 0;
        if( orig.z < 0 ) {
            if( dir.z <= 0 ) {
                // Ray faces away from cells
                return null;
            }
            zDist = -orig.z / dir.z;
        } else if( orig.z > zSize ) {
            if( dir.z >= 0 ) {
                // Ray faces away from cells
                return null;
            }
            zDist = (orig.z-zSize)/-dir.z;
        } else {
            // inside the cell array already
        }

        double dist = Math.max(xDist, Math.max(yDist, zDist));

        // Move the origin along until it hits farthest intersecting plane
        orig.addLocal(dir.x * dist, dir.y * dist, dir.z * dist);

        // I think the origin here should always be in cell space.
        // If we end up outside of cell space then it means we projected
        // beyond the edge in some direction.
        if( orig.x < 0 || orig.x > xSize ) {
            return null;
        }
        if( orig.y < 0 || orig.y > ySize ) {
            return null;
        }
        if( orig.z < 0 || orig.z > zSize ) {
            return null;
        }

        // Check it with a hit
        Vec3d point = orig;
        part.cellToWorld(body, point, point);
        Vec3d normal = new Vec3d(0, 1, 0);

        return new Hit<>(body, point, normal, dist);
    }

}

