/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys.collision;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.DirectionMasks;
import com.simsilica.mblock.phys.Collider;
import com.simsilica.mblock.phys.RayHit;
import com.simsilica.mblock.phys.MBlockContact;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CubeCollider<K> implements Collider<K>  {

    static Logger log = LoggerFactory.getLogger(CubeCollider.class);

    public static final String DEFAULT_NAME = "box";

    public static final CubeCollider UNIT = new CubeCollider();

    private final Vec3d min;
    private final Vec3d max;
    private final Vec3d center = new Vec3d();
    private final Vec3d extents = new Vec3d();
    private final boolean symetric;
    private final String name;

    private int alwaysOnMask;

    private boolean approximate;

    public CubeCollider() {
        this(new Vec3d(0, 0, 0), new Vec3d(1, 1, 1), DEFAULT_NAME);
    }

    public CubeCollider( String name ) {
        this(new Vec3d(0, 0, 0), new Vec3d(1, 1, 1), name);
    }

    public CubeCollider( Vec3d min, Vec3d max ) {
        this(min, max, DEFAULT_NAME);
    }

    public CubeCollider( Vec3d min, Vec3d max, String name ) {
        this(min, max, name, false);
    }

    public CubeCollider( Vec3d min, Vec3d max, String name, boolean approximate ) {
        this.name = name;
        this.min = min.clone();
        this.max = max.clone();
        this.approximate = approximate;

//log.info("CubeCollider(" + min + ", " + max + ", " + name + ")");
        center.set(min);
        center.addLocal(max);
        center.multLocal(0.5);

        extents.set(max);
        extents.subtractLocal(min);
        extents.multLocal(0.5);

        // Not sure the point of this check... if center.x and center.y
        // are both 0 then min and max were both zero or they canceled
        // each other out.  I suspect this was from a time when a unit
        // cube would have been -0.5 to 0.5.
        // I will adjust the check to make sense and then wait for the
        // bugs.  I'm rebuilding from the ground up right now so I will
        // find issues right away.
        // If you have a working system and see this comment then this
        // code can be removed because it's from Mythruna before some
        // early refactoring.
        // "Wouldn't this cause an issue if it's been wrong all this time?"
        // No because the side effect of symetric true is just to save time
        // in rotation... and it's likely that we've just been calculating
        // rotations needlessly up until now.
        //if( center.x == 0 && center.z == 0 ) {
        //    symetric = true;
        //}
        this.symetric = epsilon(center.x) == 0.5 && epsilon(center.z) == 0.5;

        calculateLocalMasks();
    }

    protected CubeCollider( CubeCollider toClone ) {
        this.min = toClone.min.clone();
        this.max = toClone.max.clone();
        this.center.set(toClone.center);
        this.extents.set(toClone.extents);
        this.symetric = toClone.symetric;
        this.name = toClone.name;
        calculateLocalMasks();
    }

    /**
     *  Returns true if this cube collider is just a stand-in for a more
     *  complicated shape that hasn't been implemented yet.
     */
    @Override
    public boolean isApproximate() {
        return approximate;
    }

    public Vec3d getCenter() {
        return center;
    }

    public Vec3d getExtents() {
        return extents;
    }

    protected void calculateLocalMasks() {

        // See if any of the sides are not border sides...
        // For those we need to always calculate.
        Vec3d min = center.subtract(extents);
        Vec3d max = center.add(extents);

        if( epsilon(min.x) > 0 ) {
            alwaysOnMask |= DirectionMasks.WEST_MASK;
        }
        if( epsilon(max.x) < 1 ) {
            alwaysOnMask |= DirectionMasks.EAST_MASK;
        }
        if( epsilon(min.z) > 0 ) {
            alwaysOnMask |= DirectionMasks.NORTH_MASK;
        }
        if( epsilon(max.z) < 1 ) {
            alwaysOnMask |= DirectionMasks.SOUTH_MASK;
        }
        if( epsilon(min.y) > 0 ) {
            alwaysOnMask |= DirectionMasks.DOWN_MASK;
        }
        if( epsilon(max.y) < 1 ) {
            alwaysOnMask |= DirectionMasks.UP_MASK;
        }
    }

    public String getName() {
        return name;
    }

    protected double epsilon( double d ) {
        long i = Math.round(d * 10000);
        d = i / 10000.0;
        return d;
    }

    private final static double clamp( double v, double min, double max ) {
        return (v < min) ? min : (v > max) ? max : v;
    }

    private final static double clamp( double v, double extent ) {
        return clamp(v, -extent, extent);
    }

    private static Vec3d toNormal( Vec3d delta, double dist ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
System.out.println("Random deflect.");
        delta.x = Math.random() * 0.1;
        delta.y = Math.random() * 0.1;
        delta.z = Math.random() * 0.1;
        return delta.normalizeLocal();
    }

public static boolean debug = false;

    /**
     *  Returns the absolute value of the specified value if that direction
     *  is in the supplied dirMask, else it returns 0.
     */
    private static double absDirClamp( double val, int dirMask, int minMask, int maxMask ) {
if( debug ) System.out.println("absDirClamp(" + val + ", " + DirectionMasks.toString(dirMask) + ", " + DirectionMasks.toString(minMask) + ", " + DirectionMasks.toString(maxMask) + ")");
        if( val < 0 ) {
            if( DirectionMasks.hasMask(dirMask, minMask) ) {
if( debug ) System.out.println("has min mask");
                return Math.abs(val);
            }
            return 0;
        } else if( val > 0 ) {
            if( DirectionMasks.hasMask(dirMask, maxMask) ) {
if( debug ) System.out.println("has max mask");
                return val;
            }
            return 0;
        }
        return val;
    }

    public MBlockContact<K> getSphereContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask ) {
//log.info("getSphereContact(" + cellPos + ", " + pos + ", " + radius + ", " + DirectionMasks.toString(dirMask) + ")");
        double x = pos.x - (cellPos.x + center.x);
        double y = pos.y - (cellPos.y + center.y);
        double z = pos.z - (cellPos.z + center.z);

//if( alwaysOnMask != 0 ) {
//    log.info("getSphereContact(" + cellPos + ", " + pos + ", " + radius + ", " + DirectionMasks.toString(dirMask) + ")");
//    log.info("name:" + name + "  min:" + min + "  max:" + max + "  center:" + center + "  extents:" + extents);
//    log.info("relative:" + x + ", " + y+ ", " + z);
//}

        dirMask |= alwaysOnMask;

        // I think if there is no dirMask at all then we can't possibly intersect
        // anywhere, right?
        if( dirMask == 0 ) {
            return null;
        }
if( debug ) log.info("getSphereContact(" + cellPos + ", " + pos + ", " + radius + ", " + DirectionMasks.toString(dirMask) + ")");
if( debug ) log.info("relative:" + x + ", " + y + ", " + z);
if( debug ) log.info("extents:" + extents);

        // We've presumed that the sphere intersects the cell itself
        // but that doesn't mean that it intersects our cube.
        // If it doesn't even intersect with any of the planes then it definitely
        // doesn't intersect.
        if( x <= -(extents.x + radius) ) {
if( debug ) log.info("x too low");
            return null;
        }
        if( y <= -(extents.y + radius) ) {
if( debug ) log.info("y too low");
            return null;
        }
        if( z <= -(extents.z + radius) ) {
if( debug ) log.info("z too low");
            return null;
        }
        if( x >= extents.x + radius ) {
if( debug ) log.info("x too high");
            return null;
        }
        if( y >= extents.y + radius ) {
if( debug ) log.info("y too high");
            return null;
        }
        if( z >= extents.z + radius ) {
if( debug ) log.info("z too high");
            return null;
        }

        // I think we can still early-out based on dir masks just like the aa cube
        // stuff in getCubeContact.  Even though we allow intersecting with corners
        // "for real" here it doesn't change the fact that if a side is masked off then
        // we should be hitting the top's corner, for example... we rely on the neighbor
        // to continue the top surface.
        if( x <= -(extents.x) && !DirectionMasks.hasWest(dirMask) ) {
if( debug ) log.info("x is low and no west mask... x:" + x + "  -extents.x:" + (-extents.x));
            return null;
        }
        if( y <= -(extents.y) && !DirectionMasks.hasDown(dirMask) ) {
if( debug ) log.info("y is low and no down mask... y:" + y + "  -extents.y:" + (-extents.y));
            return null;
        }
        if( z <= -(extents.z) && !DirectionMasks.hasNorth(dirMask) ) {
if( debug ) log.info("z is low and no north mask... z:" + z + "  -extents.z:" + (-extents.z));
            return null;
        }
        if( x > extents.x && !DirectionMasks.hasEast(dirMask) ) {
if( debug ) log.info("x is high and no east mask... x:" + x + "  extents.x:" + extents.x);
            return null;
        }
        if( y > extents.y && !DirectionMasks.hasUp(dirMask) ) {
if( debug ) log.info("y is high and no up mask... y:" + y + "  extents.y:" + extents.y);
            return null;
        }
        if( z > extents.z && !DirectionMasks.hasSouth(dirMask) ) {
if( debug ) log.info("z is high and no south mask... z:" + z + "  extents.z:" + extents.z);
            return null;
        }

        // At this point, I think we can do regular sphere to side intersection
        // calculations and then check the dir masks after.  I believe we've eliminated
        // any cases where we'd detect that we should intersect a corner when that side
        // is masked.  Though maybe it's worth testing.
        // It can happen when the center of the sphere is inside the cubes.  The
        // above checks will pass in that case and we just need to filter our "best"
        // cases out of our search for the best way out.


        // Find the point on the cube closest to the sphere's center
        //double x = body.position.x - world.position.x;
        //double y = body.position.y - world.position.y;
        //double z = body.position.z - world.position.z;
        // x, y, z should already be cube center relative from above


        Vec3d cn = new Vec3d();
        int edgeOrFaceHit = 0;

        // Clamp the values to the box extents
        if( x > extents.x ) {
            x = extents.x;
            cn.x = 1;
if( debug ) log.info("clamp x");
        } else if( x < -extents.x ) {
            x = -extents.x;
            cn.x = -1;
if( debug ) log.info("clamp -x");
        } else {
            cn.x = 0;
            edgeOrFaceHit++;
if( debug ) log.info("x inside");
        }
        if( y > extents.y ) {
            y = extents.y;
            cn.y = 1;
if( debug ) log.info("clamp y");
        } else if( y < -extents.y ) {
            y = -extents.y;
            cn.y = -1;
if( debug ) log.info("clamp -y");
        } else {
            cn.y = 0;
            edgeOrFaceHit++;
if( debug ) log.info("y inside");
        }
        if( z > extents.z ) {
            z = extents.z;
            cn.z = 1;
if( debug ) log.info("clamp z");
        } else if( z < -extents.z ) {
            z = -extents.z;
            cn.z = -1;
if( debug ) log.info("clamp -z");
        } else {
            cn.z = 0;
            edgeOrFaceHit++;
if( debug ) log.info("z inside");
        }
if( debug ) log.info("clamped:" + x + ", " + y + ", " + z);

        Vec3d cp = cellPos.add(center).addLocal(x, y, z);
if( debug ) log.info("cp:" + cp);

        // For a box, if the contact point is not on an edge or corner then the
        // normal is the surface normal of the box itself.
        double penetration;
        if( edgeOrFaceHit > 2 ) {
            double bestExtent = 0;
if( debug ) System.out.println("edgeOrFaceHit:" + edgeOrFaceHit);
            if( edgeOrFaceHit == 3 ) {
if( debug ) System.out.println("Fully Inside. cn:" + cn + "  body:" + pos + "  static:" + cellPos);
                // Fully penetrating.  This is technically a face hit
                // but we have to figure out what the best face is.
                // To do that we need to find the longest delta
                // ...but we need to fliter that based on edge masks so
                // we don't get hits against faces that don't exist.
if( debug ) System.out.println("unfiltered:" + x + ", " + y + ", " + z + " dirs:" + DirectionMasks.toString(dirMask));
                double ax = absDirClamp(x, dirMask, DirectionMasks.WEST_MASK, DirectionMasks.EAST_MASK);
                double ay = absDirClamp(y, dirMask, DirectionMasks.DOWN_MASK, DirectionMasks.UP_MASK);
                // Remember... negative z is north... so north is the min.
                double az = absDirClamp(z, dirMask, DirectionMasks.NORTH_MASK, DirectionMasks.SOUTH_MASK);
if( debug ) System.out.println("filtered:" + ax + ", " + ay + ", " + az);
                double flip = 1;
                if( ax == 0 && ay == 0 && az == 0 ) {
                    // A special case where we are past the center into penetration and
                    // those sides don't exist
if( debug ) System.out.println("no good exits");
                    // Can we calculate better ones?
                    ax = Math.abs(x) + extents.x * Math.signum(x) * -1;
                    ay = Math.abs(y) + extents.y * Math.signum(y) * -1;
                    az = Math.abs(z) + extents.z * Math.signum(z) * -1;
if( debug ) System.out.println("reprojected:" + ax + ", " + ay + ", " + az);
                    ax = absDirClamp(ax, dirMask, DirectionMasks.WEST_MASK, DirectionMasks.EAST_MASK);
                    ay = absDirClamp(ay, dirMask, DirectionMasks.WEST_MASK, DirectionMasks.EAST_MASK);
                    az = absDirClamp(az, dirMask, DirectionMasks.WEST_MASK, DirectionMasks.EAST_MASK);
if( debug ) System.out.println("refiltered:" + ax + ", " + ay + ", " + az);
                    flip = -1;

                    // So this will get us "out" but it's not right.  We normally use the shortest
                    // distance out of the box (the largest x,y,z) but now we end up using the
                    // longest distance out of the box.  I'm going to leave it for now but
                    // I suspect this will bite me later with chaotic behavior.  2018-01
                }
                if( ax > ay ) {
                    if( ax > az ) {
                        // x is best
                        cn.x = Math.signum(x) * flip;
                        bestExtent = extents.x;
if( debug ) System.out.println("x is best");
                    } else {
                        // z is best... it must be >= x which was already > y
                        cn.z = Math.signum(z) * flip;
                        bestExtent = extents.z;
if( debug ) System.out.println("z is best");
                    }
                } else {
                    if( ay > az ) {
                        // y is best
                        cn.y = Math.signum(y) * flip;
                        bestExtent = extents.y;
if( debug ) System.out.println("y is best");
                    } else {
                        // z is best... it must be >= y which was already >= x
                        cn.z = Math.signum(z) * flip;
                        bestExtent = extents.z;
if( debug ) System.out.println("z is best");
                    }
                }

                // Now that we have a proper normal we can proceed
            }

            // We get a more pure normal this way and an easier distance
            // check.  The 'else' branch actually should also cover this
            // ok because the cp as calculated above would already be
            // the closest point on the cube.
            // delta = pos - (cellPos + center)...
            // ie: delta = pos - cellPos - center
            Vec3d delta = pos.subtract(cellPos).subtractLocal(center);
if( debug ) System.out.println("cn:" + cn + "  delta:" + delta);
            // A face is easy... the normal is already right
            double dist = cn.dot(delta);
if( debug ) System.out.println("dist:" + dist + "  bestExtent:" + bestExtent + "  radius:" + radius);
            //if( dist > r1 + r2 ) {
            //    return;
            //}
            penetration = (bestExtent - dist) + radius;

            // Note: the contact point is the center of the sphere at this point
            // so the penetration distance will look strange.  I'm not sure if we should
            // project it out or not given that we're penetrating but usually we
            // use the surface of the target as our CP and not the surface of the source.
            // So the consistent answer would be to project it to the cube surface.
            // Which I think is relatively simple given that we have the normal and
            // we know bestExtent - dist is how far we've penetrated.
            // Let's try it
            double project = bestExtent - dist;
if( debug ) System.out.println("project:" + project);
            cp.addLocal(cn.x * project, cn.y * project, cn.z * project);
        } else {
            // This is a corner hit

            double distSq = cp.distanceSq(pos);
if( debug ) System.out.println("cp:" + cp + "  pos:" + pos + "  distSq:" + distSq + "  radius:" + radius);
            if( distSq > (radius * radius) ) {
                return null;
            }

            double dist = Math.sqrt(distSq);

            //Vec3d cn = body.position.subtract(cp).mult(1/dist);
            if( dist > 0 ) {
                // The easy way
                cn = pos.subtract(cp).mult(1/dist);
            } else {
                // Else at least present in the body center to body center
                // direction if possible
                Vec3d delta = pos.subtract(cellPos).subtractLocal(center);
if( debug ) System.out.println("Deflect. cn:" + cn + "  edgeOrFaceHit:" + edgeOrFaceHit + "  body:" + pos + "  static:" + cellPos);
                cn = toNormal(delta, delta.length());
            }
            penetration = radius - dist;
        }

        MBlockContact<K> result = new MBlockContact<>();
        result.contactPoint = cp;
        result.contactNormal = cn;
        result.penetration = penetration;

        return result;
    }

    public MBlockContact<K> getCubeContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask ) {

if( debug ) log.info("getCubeContact(" + cellPos + ", " + pos + ", " + radius + ", " + DirectionMasks.toString(dirMask) + ")");
        double x = pos.x - (cellPos.x + center.x);
        double y = pos.y - (cellPos.y + center.y);
        double z = pos.z - (cellPos.z + center.z);
if( debug ) log.info("  pos -> center relative:" + x + ", " + y + ", " + z);

        dirMask |= alwaysOnMask;

        // Need to check all six directions (both ways on each axis)
        // if the dir mask says we can.  One issue is that we don't really
        // properly handle the sphere to corner case.
        // One general approach is to find the point on the box closest to the
        // position.  This is the contact point and penetration is then the
        // ratio of the point to the center, etc..  The problem is that this
        // doesn't let us easily mask off any of the sides, I think.  Though
        // maybe the closest point part has that covered.
        //
        // For example, a point at the corner may have a normal not axis aligned.
        // If we are masking off one of the sides of that corner then the collision
        // needs to be dealt with differently... though I guess it's just a matter
        // of masking off the axis we don't want.

        // Calculate the point on the box closest to the position
        //double cx = (x < 0) ? 0 : (x > 1) ? 1 : x;
        //double cy = (y < 0) ? 0 : (y > 1) ? 1 : y;
        //double cz = (z < 0) ? 0 : (z > 1) ? 1 : z;

        // Though one benefit of treating the source material like a cube
        // is that it probably is.  We can just treat it as an oriented
        // one.  This also matches what the current intersection code does and
        // means we can never approach a corner as close as a side, technically.
        //
        // 2017-12-note: I've split this up anyway.  There is this method which
        // deals with the special cubes and another one that we can make do proper
        // sphere checkes someday if we want that.

        // We've presumed that the position intersects the cell itself
        // but that doesn't mean that it intersects our cube.
        if( x <= -(extents.x + radius) ) {
if( debug ) log.info("x too low");
            return null;
        }
        if( y <= -(extents.y + radius) ) {
if( debug ) log.info("y too low");
            return null;
        }
        if( z <= -(extents.z + radius) ) {
if( debug ) log.info("z too low");
            return null;
        }
        if( x >= extents.x + radius ) {
if( debug ) log.info("x too high");
            return null;
        }
        if( y >= extents.y + radius ) {
if( debug ) log.info("y too high");
            return null;
        }
        if( z >= extents.z + radius ) {
if( debug ) log.info("z too high");
            return null;
        }

        // So by now we know the oriented box intersects us on all
        // three axes in some direction.

        // Except... if our side is not on in a particular direction
        // and the _radius_ is outside the box then we should let
        // the neighboring box take care of it, right?  Otherwise
        // what happens is that blocks embedded into corners shoot
        // us in weird directions.  So we'll do some of those checks, too.
        if( x <= -(extents.x) && !DirectionMasks.hasWest(dirMask) ) {
if( debug ) log.info("x is low and no west mask... x:" + x + "  -extents.x:" + (-extents.x));
            return null;
        }
        if( y <= -(extents.y) && !DirectionMasks.hasDown(dirMask) ) {
if( debug ) log.info("y is low and no down mask... y:" + y + "  -extents.y:" + (-extents.y));
            return null;
        }
        if( z <= -(extents.z) && !DirectionMasks.hasNorth(dirMask) ) {
if( debug ) log.info("z is low and no north mask... z:" + z + "  -extents.z:" + (-extents.z));
            return null;
        }
        if( x > extents.x && !DirectionMasks.hasEast(dirMask) ) {
if( debug ) log.info("x is high and no east mask... x:" + x + "  extents.x:" + extents.x);
            return null;
        }
        if( y > extents.y && !DirectionMasks.hasUp(dirMask) ) {
if( debug ) log.info("y is high and no up mask... y:" + y + "  extents.y:" + extents.y);
            return null;
        }
        if( z > extents.z && !DirectionMasks.hasSouth(dirMask) ) {
if( debug ) log.info("z is high and no south mask... z:" + z + "  extents.z:" + extents.z);
            return null;
        }

        // 2017-12: Below notes are old and I wanted to add another wrinkle
        // on the above.  I assumed for a minute that the check was wrong
        // because it's using just our center and not considering our radius.
        // But I think that's ok... because we will check the neighbor.
        // What if we don't have a neighbor and there is open space?  Well,
        // then the mask would have indicated that and we skip the check.
        // The issue I'm seeing is that perfectly aligned objects are going
        // right through.  I thought it could either be an equilibrium issue
        // (and there is an issue since in both cases we <= and >= so a perfectly
        // centered object will miss both) but I was worried maybe the above checks
        // were too aggressive also... but I don't think so.
        // I'm going to remove the high-side = check and see if it fixes my
        // issue.   Seems to.

        // Actually, I know why we used to post-filter now.  We want
        // calculate the best penetration solution no matter which
        // sides are active precisely because it prevents the above
        // problem and many others.  Another example is when we
        // have a block corner fully exposed to us but the bottom
        // is exposed at another level.  Actually, in the case I
        // found it was a wedge configuration.  An upside down wedge
        // near a reglar wedge or something and it pushed me right
        // through the bottom of the ship.  I think it was the
        // same issue as above except with the cube parts of the
        // wedge.
        // Because on the other side of if, if the object is so
        // far penetrated that all "best" options are masked by
        // all colliders then the penetration will fail.


        Vec3d cp = new Vec3d();
        Vec3d normal = new Vec3d();

        // 2017: Set penetration larger than it ever could be so that we have
        // something to min() against and an easy way to check that
        // things were unset.
        double pen = Double.POSITIVE_INFINITY; //10.0; //just needs to be unreasonable

        int hitMask = 0;

        if( DirectionMasks.hasEast(dirMask) ) {
            // We are "x" away from center but we need to be extents.x + radius
            // away.  x < extents.x + radius
            // So: (extents.x + radius) - x is penetration
            double p = (extents.x + radius) - x;
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( 1, 0, 0 );
                cp.set( extents.x, clamp(y,extents.y), clamp(z,extents.z) );
                hitMask = DirectionMasks.EAST_MASK;
            }
        }
        if( DirectionMasks.hasWest(dirMask) ) {
            // Similar to positive X except we are negative.  So in this
            // case x needs to be at least -(extents.x + radius) away.
            // x > -(extents.x + radius)
            // So: x - -(extents.x + radius)
            // or: x + (extents.x + radius)... because x is negative
            double p = x + (extents.x + radius);
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( -1, 0, 0 );
                cp.set( -extents.x, clamp(y,extents.y), clamp(z,extents.z) );
                hitMask = DirectionMasks.WEST_MASK;
            }
        }
        if( DirectionMasks.hasSouth(dirMask) ) {
            double p = (extents.z + radius) - z;
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( 0, 0, 1 );
                cp.set( clamp(x,extents.x), clamp(y,extents.y), extents.z );
                hitMask = DirectionMasks.SOUTH_MASK;
            }
        }
        if( DirectionMasks.hasNorth(dirMask) ) {
            double p = z + (extents.z + radius);
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( 0, 0, -1 );
                cp.set( clamp(x,extents.x), clamp(y,extents.y), -extents.z );
                hitMask = DirectionMasks.NORTH_MASK;
            }
        }
        if( DirectionMasks.hasUp(dirMask) ) {
            double p = (extents.y + radius) - y;
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( 0, 1, 0 );
                cp.set( clamp(x,extents.x), extents.y, clamp(z,extents.z) );
                hitMask = DirectionMasks.UP_MASK;
            }
        }
        if( DirectionMasks.hasDown(dirMask) ) {
            double p = y + (extents.y + radius);
            if( p > 0 && p < pen ) {
                pen = p;
                normal.set( 0, -1, 0 );
                cp.set( clamp(x,extents.x), -extents.y, clamp(z,extents.z) );
                hitMask = DirectionMasks.DOWN_MASK;
            }
        }

        // If the penetration is more than the diameter then there is no
        // part of the penetrator that is exposed through a valid side...
        // we pretend it never happened
        // Actually, that's no good either.  It could still be fully
        // inside of us if it's small... so we'll use our own radius
        // as judge.... which is always 1.0 from our perspective.
        //if( pen >= 1.0 ) {// radius * 2 )
//System.out.println("pen is greater than 1:" + pen);
////        if( pen >= radius * 2 )
//            return null;
//        }
        // mblock-refactor note: the above seems like it may be spurious to me.
        // Needs to be rechecked in a test app.  Seems to me that if the condition
        // is met at all then pen will simply be what we started with: 10
        // And hitMask will be 0.
        // Maybe there was some case where we pass the mask and pen checks but
        // still don't want the value?  Doesn't seem like it.
        // 2017-12-note: Actually, that looks to even be a bug... we eliminate
        // pen > 1.0 which could be a valid penetration when a 'sphere' is larger
        // than the block we are checking.
        if( pen == Double.POSITIVE_INFINITY ) {
System.out.println("no penetrations detected: getCubeContact(" + cellPos + ", "
                            + pos + ", " + radius + ", " + dirMask + ")");
//...though I wonder which cases this happens.
// no penetrations detected:
// getCubeContact(Vec3[13.0, 2.0, 11.0],
//                Vec3[13.312000082578422, 2.361363008589657, 11.007501073832149],
//                0.0625, 0)
// ...no masks.
            return null;
        }

        MBlockContact<K> result = new MBlockContact<>();
        result.contactPoint = cp.addLocal(cellPos).addLocal(center);
        result.contactNormal = normal;
        result.penetration = pen;

        return result;
    }


    public RayHit getHit( Vec3d origin, Vec3d dir, int dirMask, RayHit store ) {

        boolean inside = true;
        int[] quadrant = new int[3];
        double[] maxT = new double[3];
        double[] candidatePlane = new double[3];

        // Find the candidate planes
        for( int i = 0; i < 3; i++ ) {
            if( origin.get(i) < min.get(i) ) {
                quadrant[i] = 1;
                candidatePlane[i] = min.get(i);
                inside = false;
            } else if( origin.get(i) > max.get(i) ) {
                quadrant[i] = 0;
                candidatePlane[i] = max.get(i);
                inside = false;
            } else {
                quadrant[i] = 2;
            }
        }

        if( inside ) {
            // If the origin is inside then it's never a hit for us
            return null;
        }

        // Calculate the T distances to the candidate planes.
        for( int i = 0; i < 3; i++ ) {
            if( quadrant[i] != 2 && dir.get(i) != 0 ) {
                maxT[i] = (candidatePlane[i]-origin.get(i)) / dir.get(i);
            } else {
                maxT[i] = -1; // purposely bogus value?
            }
        }

        // Find the largest of the max Ts
        int whichPlane = 0;
        for( int i = 1; i < 3; i++ ) {
            if( maxT[i] > maxT[whichPlane] ) {
                whichPlane = i;
            }
        }

        // Check that final candidate is actually inside the box
        if( maxT[whichPlane] < 0 ) {
            return null;
        }

        if( store == null ) {
            store = new RayHit();
        }

        for( int i = 0; i < 3; i++ ) {
            if( whichPlane != i ) {
                store.point.set(i, origin.get(i) + maxT[whichPlane] * dir.get(i));
                store.normal.set(i, 0 );
                if( store.point.get(i) < min.get(i) || store.point.get(i) > max.get(i) ) {
                    return null;  // intersection is outside box
                }
            } else {
                store.point.set(i, candidatePlane[i]);
                store.normal.set(i, quadrant[i] == 0 ? 1 : -1);
            }
        }

        return store;
    }

    public String toString() {
        return "CubeCollider[" + name + ", " + center + ", " + extents + "]";
    }
}

