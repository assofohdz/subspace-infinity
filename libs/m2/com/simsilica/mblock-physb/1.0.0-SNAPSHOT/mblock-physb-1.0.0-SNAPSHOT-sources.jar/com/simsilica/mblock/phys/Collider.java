/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import com.simsilica.mathd.*;
import com.simsilica.mphys.*;

/**
 *  An object that can provide some collision information on behalf
 *  of a block.
 *
 *  @author    Paul Speed
 */
public interface Collider<K> {

    /**
     *  Returns true if this collider is only an approximation of the
     *  real shape.
     */
    default boolean isApproximate() {
        return false;
    }

    /**
     *  Returns contact information for the specified position and radius (representing
     *  an axis-aligned cube) given the specified cell position and constrained by the dirMask.
     *  The cell position and position are assumed to be in the same 'space'.  The dirMask parameter
     *  controls which sides can be intersected and which ones are effectively
     *  non-exists.  (For example, two cubes together there is an inside shared side
     *  that should not be checked normally.)
     *  Returns null if there is no contact.
     */
    public MBlockContact<K> getCubeContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask );

    /**
     *  Returns contact information for the specified position and radius (representing
     *  a sphere) given the specified cell position and constrained by the dirMask.
     *  The cell position and position are assumed to be in the same 'space'.  The dirMask parameter
     *  controls which sides can be intersected and which ones are effectively
     *  non-exists.  (For example, two cubes together there is an inside shared side
     *  that should not be checked normally.)
     *  Returns null if there is no contact.
     */
    public MBlockContact<K> getSphereContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask );

    /**
     *  Returns hit information for the specified ray, constrainted to the specified
     *  dirMask.  If store is null then a new RayHit is created.  If there is no
     *  hit then this method returns null.
     */
    public RayHit getHit( Vec3d origin, Vec3d dir, int dirMask, RayHit store );

    /**
     *  Returns a Collider that is a rotated version of this collider around the
     *  up axis.  dirDelta is the number of 90 degree turns to make in one direction
     *  or another.
     */
    //public Collider rotate( int dirDelta );
}
