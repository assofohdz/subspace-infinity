/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.phys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;

import com.simsilica.mblock.phys.CellArrayPart.Type;

/**
 *  A shape implementation that deals with mblock data structures.
 *  Some simpler primitives are also provided.
 *
 *  @author    Paul Speed
 */
public class MBlockShape extends AbstractShape {

    static Logger log = LoggerFactory.getLogger(MBlockShape.class);

    private Part part;
    private long lastPartVersion;

    public MBlockShape( Part part ) {
        //super(new Vec3d(), part.getMass().getRadius(), part.getMass());
        // bounds is calculated by removing Cog so we need to pass Cog as
        // our 'center'.
        super(part.getMass().getCog(), part.getMass().getRadius(), part.getMass());
        this.part = part;
        this.lastPartVersion = part.getVersion();
    }

    public Part getPart() {
        return part;
    }

    public long getVersion() {
        return part.getVersion();
    }

    @Override
    public BodyMass getMass() {
        // Too many cases where updates were slipping in and the
        // shape mass properties wasn't being updated... so we'll make sure
        // now.  This is also more efficient than manually calling validateBoundsInfo()
        // for every change as a single frame might have lots of changes.
        // 2025-12-13: moving the version check to inside of the validateBoundsInfo()
        // call to make it more reusable.
        validateBoundsInfo();
        return super.getMass();
    }

    /**
     *  Called to update the shape's overall BodyMass, only performs actual work when the part has changed.
     *  AbstractShape calls this whenever is uses bounds info related properties to make sure it's
     *  values are the latest.
     */
    @Override
    protected void validateBoundsInfo() {
        if( lastPartVersion >= part.getVersion() ) {
            return;
        }
        // bounds is calculated by removing Cog so we need to pass Cog as
        // our 'center'.  Which really kind of makes sense given that the other
        // two parameters are already mass-relative.
        setBoundsInfo(part.getMass().getCog(), part.getMass().getRadius(), part.getMass());
        this.lastPartVersion = part.getVersion();
    }

    /**
     *  Converts the space-origin-relative point to body-origin-relative.
     */
    public Vec3d shapeToBody( Vec3d shapeSpace, Vec3d store ) {
        if( store == null ) {
            store = shapeSpace.clone();
        } else {
            store.set(shapeSpace);
        }
        // We go directly to the part in case the validateBoundsInfo() call
        // has not been made.  A questionable decision but at least we'll
        // always be 100% accurate in space conversions where as validateBoundsInfo()
        // will otherwise only affect bounding shape calculation.
        store.subtractLocal(part.getMass().getCog());
        return store;
    }

    /**
     *  Converts the body-origin-relative point to shape-origin-relative.
     */
    public Vec3d bodyToShape( Vec3d bodySpace, Vec3d store ) {
        if( store == null ) {
            store = bodySpace.clone();
        } else {
            store.set(bodySpace);
        }
        store.addLocal(part.getMass().getCog());
        return store;
    }

    /*public Type getType() {
        return part.getType();
    }*/

    /**
     *  Returns the cell array that contains the combined type + side mask values for
     *  this shape.
     */
    /*public CellArray getCells() {
        return part.getCells();
    }*/

    /**
     *  Given a coordinate in body space this will return the coordinate in shape space,
     *  including any rescaling, etc..
     */
/*    public Vec3d toCellSpace( Vec3d bodySpace, Vec3d store ) {
//System.out.println("--toCellSpace(" + bodySpace + ")");
        if( store == null ) {
            store = new Vec3d();
        }
        // Body space is relative to the CoG so we need to add it in
        store.set(bodySpace).addLocal(getMass().getCog());
//System.out.println("   translated:" + store);
        store.multLocal(1/getScale());
//System.out.println("   unscaled:" + store);

        return store;
    }
 */
 /*
    public Vec3d toBodySpace( Vec3d cellSpace, Vec3d store ) {
//System.out.println("--toBodySpace(" + cellSpace + ")");
        if( store == null ) {
            store = cellSpace.mult(getScale());
        } else {
            store = store.set(cellSpace).mult(getScale());
        }
//System.out.println("   scaled:" + store);
        store = store.subtractLocal(getMass().getCog());
//System.out.println("   retranslated:" + store);
        return store;
    }*/

    public static MBlockShape createShape( String name, CellArray cells, double scale, double mass ) {
        return new MBlockShape(CellArrayPart.createShape(name, cells, scale, mass));
    }

    public static MBlockShape createShape( CellArray cells, double scale, double mass ) {
        return new MBlockShape(CellArrayPart.createShape(cells, scale, mass));
    }

    public static MBlockShape createGhost( double radius ) {
        return new MBlockShape(CellArrayPart.createGhost(radius));
    }

    public static MBlockShape createSphere( double radius, double mass ) {
        return new MBlockShape(CellArrayPart.createSphere(radius, mass));
    }

    public static MBlockShape createSphere( String name, double radius, double mass ) {
        return new MBlockShape(CellArrayPart.createSphere(name, radius, mass));
    }

    /**
     *  Provided for convenience.  Creates a static single cell block array using extents/2 as
     *  the scale and a block type of 1.
     */
    public static MBlockShape createCube( double extents ) {
        return new MBlockShape(CellArrayPart.createCube(extents));
    }

    /*public double getScale() {
        return part.getScale();
    }

    public double getBlockCollisionPriority() {
        return part.getBlockCollisionPriority();
    }*/

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .omitNullValues()
                .add("part", part)
                .toString();
    }

}
