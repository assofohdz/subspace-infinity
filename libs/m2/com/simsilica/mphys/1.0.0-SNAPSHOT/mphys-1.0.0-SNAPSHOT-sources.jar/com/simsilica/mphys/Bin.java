/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

import org.slf4j.*;

import com.google.common.reflect.TypeToken;

import com.simsilica.mathd.*;

/**
 *  A section of space that contains some set of physical objects.
 *
 *  @author    Paul Speed
 */
public class Bin<K, S extends AbstractShape> {

    static Logger log = LoggerFactory.getLogger(Bin.class);

    public enum Status {
        /**
         *  The Bin has been created but hasn't been filled yet.  This
         *  happens when the contained data is being streamed from
         *  separate threads.
         */
        Empty,

        /**
         *  The only type of objects in this bin are StaticBodies.
         */
        Static,

        /**
         *  The only RigidBodies directly contained in this Bin are
         *  asleep, ie: there are no active bodies contained.
         */
        Asleep,

        /**
         *  There is at least one active (not asleep) RigidBody in
         *  this bin.
         */
        Active
    }

    private final BinIndex<K, S> parent;
    private final GridCell cell;
    private Status status = Status.Empty;

    private int watchers = 0;

    private final DynArray<StaticBody<K, S>> staticObjects
                = new DynArray<>(new TypeToken<StaticBody<K, S>>() {});

    private final DynArray<RigidBody<K, S>> activeObjects
                = new DynArray<>(new TypeToken<RigidBody<K, S>>() {});

    private final DynArray<RigidBody<K, S>> inactiveObjects
                = new DynArray<>(new TypeToken<RigidBody<K, S>>() {});

    public Bin( BinIndex<K, S> parent, GridCell cell ) {
        this.parent = parent;
        this.cell = cell;
    }

    public GridCell getGridCell() {
        return cell;
    }

    public Status getStatus() {
        return status;
    }

    public DynArray<RigidBody<K, S>> getActiveObjects() {
        return activeObjects;
    }

    public DynArray<RigidBody<K, S>> getInactiveObjects() {
        return inactiveObjects;
    }

    public DynArray<StaticBody<K, S>> getStaticObjects() {
        return staticObjects;
    }

    public boolean contains( Vec3d world ) {
        return cell.contains(world);
    }

    public void writeDebugInfo( java.io.PrintWriter out ) {
        out.println("------------------------------------------------------------");
        out.println("Bin:" + cell + "  Status:" + status + "  Watchers:" + watchers);
        out.println("  static bodies:");
        for( StaticBody<K, S> b : staticObjects.getArray() ) {
            out.println("    " + b);
        }

        out.println("  active bodies:");
        for( RigidBody<K, S> b : activeObjects.getArray() ) {
            out.println("    " + b);
        }

        out.println("  inactive bodies:");
        for( RigidBody<K, S> b : inactiveObjects.getArray() ) {
            out.println("    " + b);
        }
    }

/*
public RigidBody<K, S> findBody( K id ) {
    for( RigidBody<K, S> body : activeObjects ) {
        if( Objects.equals(body.id, id) ) {
            return body;
        }
    }
    for( RigidBody<K, S> body : inactiveObjects ) {
        if( Objects.equals(body.id, id) ) {
            return body;
        }
    }
    return null;
}*/

    protected void checkDependencies() {
        if( log.isTraceEnabled() ) {
            log.trace("watchers:" + watchers + "  activeObjects:" + activeObjects.size());
        }
        if( watchers == 0 && status != Status.Active ) {
            if( log.isTraceEnabled() ) {
                log.trace("Bin can be unloaded:" + this);
            }
            parent.markForUnload(this);
        }
    }

    protected void updateWatchersCount( int delta ) {
        watchers += delta;
        checkDependencies();
    }

    protected int getWatchersCount() {
        return watchers;
    }

    public StaticBody<K, S> addStaticBody( K bodyId ) {
        if( log.isTraceEnabled() ) {
            log.trace("addStaticBody(" + bodyId + ") bin:" + this);
        }
        return parent.addStaticBody(bodyId);
        // currently no advantage to having a bin-specific method
        //StaticBody<K, S> result = parent.addStaticBodyToBin(this, bodyId);
        //if( !cell.contains(result.position) ) {
        //    log.warn("StaticBody " + bodyId + " at:" + result.position + " is not really in bin:" + this);
        //}
        //return result;
    }

    // Not even called...
    //public StaticBody<K, S> removeStaticBody( K bodyId ) {
    //    if( log.isTraceEnabled() ) {
    //        log.trace("removeStaticBody(" + bodyId + ") bin:" + this);
    //    }
    //    return parent.removeStaticbody(bodyId);
    //    // Currently no advantage to having a bin-specific method
    //    // and I don't even think this method bin.removeStaticBody() is
    //    // even called.
    //    //return parent.removeStaticBodyFromBin(this, bodyId);
    //}

    public RigidBody<K, S> addRigidBody( K bodyId ) {
        if( log.isDebugEnabled() ) {
            log.debug(this + " add(" + bodyId + ")");
        }
        //RigidBody<K, S> result = parent.addRigidBodyToBin(this, bodyId);
        //if( !cell.contains(result.position) ) {
        //    log.warn("RigidBody " + bodyId + " at:" + result.position + " is not really in bin:" + this);
        //}
        // currently no advantage to having a bin-specific method
        return parent.addRigidBody(bodyId);
    }

    // Not even called...
    //public RigidBody<K, S> removeRigidBody( K bodyId ) {
    //    if( log.isDebugEnabled() ) {
    //        log.debug(this + " remove(" + bodyId + ")");
    //    }
    //    return parent.removeRigidBodyFromBin(this, bodyId);
    //}

    public void addJoint( K jointId, K bodyId1, K bodyId2 ) {
        parent.addJointToBin(this, jointId, bodyId1, bodyId2);
    }

    public void removeJoint( K jointId ) {
        parent.removeJointFromBin(this, jointId);
    }

    protected void add( RigidBody<K, S> body, boolean active ) {
        if( active ) {
            if( log.isTraceEnabled() ) {
                log.trace("adding " + body.id + " to active objects");
            }
            activeObjects.add(body);
        } else {
            if( log.isTraceEnabled() ) {
                log.trace("adding " + body.id + " to inactive objects");
            }
            inactiveObjects.add(body);
        }
        refreshStatus();
    }

    protected void remove( RigidBody<K, S> body, boolean active ) {
        //log.info("remove(body for:" + body.id + ", " + active + ")");
        if( active ) {
            if( log.isTraceEnabled() ) {
                log.trace("removing " + body.id + " from active objects");
            }
            activeObjects.remove(body);
        } else {
            if( log.isTraceEnabled() ) {
                log.trace("removing " + body.id + " from inactive objects");
            }
            inactiveObjects.remove(body);
        }
        refreshStatus();
    }

    protected void add( StaticBody<K, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("adding " + body.id + " to static objects");
        }
        staticObjects.add(body);
        refreshStatus();
    }

    protected void remove( StaticBody<K, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("removing " + body.id + " from static objects");
        }
        staticObjects.remove(body);
        refreshStatus();
    }

    protected void activate( RigidBody<K, S> body ) {
        if( log.isDebugEnabled() ) {
            log.debug(this + " activate(" + body.id + ") sleepy:" + body.isSleepy());
        }
        if( log.isTraceEnabled() ) {
            log.trace("removing " + body.id + " from inactive objects");
        }
        inactiveObjects.remove(body);
        if( log.isTraceEnabled() ) {
            log.trace("adding " + body.id + " to active objects");
        }
        activeObjects.add(body);
        refreshStatus();
    }

    protected void deactivate( RigidBody<K, S> body ) {
        if( log.isDebugEnabled() ) {
            log.debug(this + " deactivate(" + body.id + ") sleepy:" + body.isSleepy());
        }
        if( log.isTraceEnabled() ) {
            log.trace("removing " + body.id + " from active objects");
        }
        activeObjects.remove(body);

        if( log.isTraceEnabled() ) {
            log.trace("adding " + body.id + " to inactive objects");
        }
        inactiveObjects.add(body);
        refreshStatus();
    }

    private Status calculateStatus() {
        if( !activeObjects.isEmpty() ) {
            return Status.Active;
        }
        if( !inactiveObjects.isEmpty() ) {
            return Status.Asleep;
        }
        if( !staticObjects.isEmpty() ) {
            return Status.Static;
        }
        return Status.Empty;
    }

    private void refreshStatus() {
        setStatus(calculateStatus());
    }

    protected void setStatus( Status status ) {
        if( this.status == status ) {
            return;
        }
        Status old = this.status;
        this.status = status;
        if( log.isTraceEnabled() ) {
            log.trace(this + " setStatus(" + status + ")");
        }

        boolean deactivated = false;
        if( old == Status.Active ) {
            parent.deactivate(this);
            deactivated = true;
        } else if( status == Status.Active ) {
            parent.activate(this);
        }

        parent.fireBinStatusChanged(this, status);

        // Do the unloading after events have fired
        if( deactivated ) {
            checkDependencies();
        }
    }

    @Override
    public String toString() {
        return "Bin[" + cell + "]";
    }
}


