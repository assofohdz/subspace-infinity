/*
 * $Id$
 * 
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Playing with body-&gt;body hinge joint ideas.
 *
 *  @author    Paul Speed
 */
public class DynamicHingeJoint<K, S extends AbstractShape> implements Joint<K, S> {
    
    static Logger log = LoggerFactory.getLogger(DynamicHingeJoint.class);

    // At first we'll try to do a 'glue' joint which basically
    // as 'absolute' constraints.  A fixed joint.
    //
    
    K id;
    
    RigidBody<K, S> altBody;
    Vec3d altOffset;
    Vec3d altAxis;
    
    RigidBody<K, S> mainBody;
    Vec3d mainOffset;
    Vec3d mainAxis;
 
    Quatd relativeRotation;
 
    double damping;
    
    double test1;    
 
    /**
     *  We defer to the contact class for many of our calculations but we don't
     *  need a new one every time.  Might as well keep one around.
     */
    private Contact<K, S> contact1 = new Contact<>();
    private Contact<K, S> contact2 = new Contact<>();

    // One for each body
    private Accumulator accumulator1 = new Accumulator();
    private Accumulator accumulator2 = new Accumulator();
    
    
    private BallJoint ball1;
    private BallJoint ball2;

    public DynamicHingeJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset, Quatd mainRot,
                              RigidBody<K, S> altBody, Vec3d altOffset, Quatd altRotation,
                              double damping,
                              double test1 ) {
        this(id, mainBody, mainOffset, mainRot.mult(Vec3d.UNIT_X),
             altBody, altOffset, altRotation.mult(Vec3d.UNIT_X),
             damping, test1);
    }
     
    /**
     * 
     */
    public DynamicHingeJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset, Vec3d mainAxis,
                              RigidBody<K, S> altBody, Vec3d altOffset, Vec3d altAxis,
                              double damping,
                              double test1 ) {
        this.id = id;
        this.altBody = altBody;
        this.altOffset = altOffset;
        this.altAxis = altAxis;
        this.mainBody = mainBody;
        this.mainOffset = mainOffset;
        this.mainAxis = mainAxis;
        this.damping = damping;
        this.test1 = test1;
        this.contact1.setBodies(mainBody, altBody);
        this.contact2.setBodies(mainBody, altBody);
        
        // negative friction indicates that the planar calculation
        // should be skipped but the friction-based impulses should still
        // be used as they are more accurate.
        contact1.friction = -0.7;
        contact2.friction = -0.7;
        
        ball1 = new BallJoint(id, mainBody, mainOffset.subtract(mainAxis.mult(0.5)),
                              altBody, altOffset.subtract(altAxis.mult(0.5)),
                              relativeRotation, damping, test1);
        ball2 = new BallJoint(id, mainBody, mainOffset.add(mainAxis.mult(0.5)),
                              altBody, altOffset.add(altAxis.mult(0.5)),
                              relativeRotation, damping, test1);
        
    } 
 
    public K getId() {
        return id; 
    }
 
    public RigidBody<K, S> getMainBody() {
        return mainBody;
    }
    
    public RigidBody<K, S> getAltBody() {
        return altBody;
    }                  
 
    public RigidBody<K, S> getOtherBody( RigidBody<K, S> body ) {
        if( mainBody == body ) {
            return altBody;
        }
        if( altBody == body ) {
            return mainBody;
        }
        throw new IllegalArgumentException("Specified body:" + body.id + " is not part of this joint:" + id);
    } 

    public boolean isSleepy() {
        //return mainBody.isSleepy() || (altBody != null && altBody.isSleepy());
        return ball1.isSleepy() && ball2.isSleepy();
    }
        
    public void calculateInternals( double step ) {
    }
 
    public void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                         Vec3d angular1, Vec3d angular2 ) {
    }
                                         
    public void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                         Vec3d rotDelta1, Vec3d rotDelta2 ) {
    }
 
    private void calculateInternalsUnconstrainedTwoBody( double step, Contact contact, double axisOffset ) {
        Vec3d world1 = mainBody.localToWorld(mainOffset.add(mainAxis.mult(axisOffset)));
        Vec3d world2 = altBody.localToWorld(altOffset.add(altAxis.mult(axisOffset)));
 
        Vec3d delta = world2.subtract(world1);
        Vec3d normal = null;
        double length = delta.length();
        if( length != 0 ) {
            normal = delta.mult(1/length); 
        } else {
            normal = new Vec3d(0, 1, 0);
        } 
 
        Vec3d cp = world1.add(world2).multLocal(0.5);
log.info("cp:" + cp);        
        contact.setContactInfo(cp, normal, delta.length()); 
        contact.matchLocalTemperature();               
        contact.calculateInternals(step);
    }

    
    public void resolve( double step ) {
log.info("resolve(" + step + ")");    
        int count = 5;
        // 1 is basically the same as regular two ball joint setup
        // 2 is more stable... no negative side effects.  It gives the
        //     two-joint competition a bit of a chance to resolve evenly.
        // 5 
        for( int i = 0; i < count; i++ ) {
            doResolve(step/count);
        }
        //doResolve(step);
        //doResolve(step);
        //doResolve(step);
        //doResolve(step);
        //doResolve(step);
        // Hahah... that makes for a super-stable joint that explodes in the
        // face of paradoxical constraints.  ...sigh.
    }

    public void doResolve( double step ) {
        boolean useTwoBalls = true;
        if( useTwoBalls ) {
            ball1.resolve(step);
            ball2.resolve(step);
            return;
        }

        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();           
        Vec3d linear2 = new Vec3d();           
        Vec3d angular2 = new Vec3d();

    
        // Calculate each end of an imaginary axis as ball joints
        calculateInternalsUnconstrainedTwoBody(step, contact1, -0.5);
        //calculateInternalsUnconstrainedTwoBody(step, contact2, 0.5);

        contact1.calculatePositionChange(linear1, linear2, angular1, angular2, contact1.penetration);
log.info("contact1 pos1:" + contact1.relativeContactPosition1 + "  pos2:" + contact1.relativeContactPosition2);

        mainBody.position.addLocal(linear1);
        mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
        mainBody.calculateDerivedData();
        
        altBody.position.addLocal(linear2);            
        altBody.orientation.addScaledVectorLocal(angular2, 1.0);
        altBody.calculateDerivedData();

        contact1.calculateVelocityChange(linear1, linear2, angular1, angular2);
        
        mainBody.addLinearVelocity(linear1);
        mainBody.addRotationalVelocity(angular2);
        altBody.addLinearVelocity(linear2);
        altBody.addRotationalVelocity(angular2);


        // So if we try to do these together then things get really chaotic...
        // even if it's just calculating this above.  If we calculate it now then
        // it's based on the changes already made by contact1 just like if we run
        // two separate ball joints.  Apparently that is really significant in
        // stability because this way things will at least resolve.  Put this
        // above instead and the chest parts will blow up.
        calculateInternalsUnconstrainedTwoBody(step, contact2, 0.5);
        
        contact2.calculatePositionChange(linear1, linear2, angular1, angular2, contact2.penetration);

        mainBody.position.addLocal(linear1);
        mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
        mainBody.calculateDerivedData();
        
        altBody.position.addLocal(linear2);            
        altBody.orientation.addScaledVectorLocal(angular2, 1.0);
        altBody.calculateDerivedData();
        
        contact2.calculateVelocityChange(linear1, linear2, angular1, angular2);

        mainBody.addLinearVelocity(linear1);
        mainBody.addRotationalVelocity(angular2);
        altBody.addLinearVelocity(linear2);
        altBody.addRotationalVelocity(angular2);
    }

    public void resolve2( double step ) {
log.info("resolve(" + step + ")");    
 
        boolean useTwoBalls = false;
        if( useTwoBalls ) {
            ball1.resolve(step);
            ball2.resolve(step);
            return;
        }
    
        // Calculate each end of an imaginary axis as ball joints
        calculateInternalsUnconstrainedTwoBody(step, contact1, -0.5);
        calculateInternalsUnconstrainedTwoBody(step, contact2, 0.5);


        boolean applySeparate = true;

        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();           
        Vec3d linear2 = new Vec3d();           
        Vec3d angular2 = new Vec3d();
        
        // First the position changes           
        accumulator1.clear();
        accumulator2.clear();
        contact1.calculatePositionChange(linear1, linear2, angular1, angular2, contact1.penetration);
log.info("contact1 pos1:" + contact1.relativeContactPosition1 + "  pos2:" + contact1.relativeContactPosition2);


        if( applySeparate ) {
            mainBody.position.addLocal(linear1);
            mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
            mainBody.calculateDerivedData();
        
            altBody.position.addLocal(linear2);            
            altBody.orientation.addScaledVectorLocal(angular2, 1.0);
            altBody.calculateDerivedData();
        } else {
            accumulator1.accumulate(linear1, angular1);
            accumulator2.accumulate(linear2, angular2);
log.info("linear1:" + linear1 + "  linear2:" + linear2);
        }

        contact2.calculatePositionChange(linear1, linear2, angular1, angular2, contact2.penetration);
log.info("contact2 pos1:" + contact2.relativeContactPosition1 + "  pos2:" + contact2.relativeContactPosition2);

        if( applySeparate ) {
            mainBody.position.addLocal(linear1);
            mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
            mainBody.calculateDerivedData();
        
            altBody.position.addLocal(linear2);            
            altBody.orientation.addScaledVectorLocal(angular2, 1.0);
            altBody.calculateDerivedData();
        } else {
            accumulator1.accumulate(linear1, angular1);
            accumulator2.accumulate(linear2, angular2);
log.info("linear1:" + linear1 + "  linear2:" + linear2);
        }

        if( !applySeparate ) {
            // Apply the accumulated changes between the two hinge balls
            mainBody.position.addLocal(accumulator1.getLinear(linear1));
            mainBody.orientation.addScaledVectorLocal(accumulator1.getAngular(angular1), 1.0);
            mainBody.calculateDerivedData();
            
            altBody.position.addLocal(accumulator2.getLinear(linear2));            
            altBody.orientation.addScaledVectorLocal(accumulator2.getAngular(angular2), 1.0);
            altBody.calculateDerivedData();
log.info("accum linear1:" + linear1 + "  accum linear2:" + linear2);
        }

        // Then the velocity changes
        accumulator1.clear();
        accumulator2.clear();
        contact1.calculateVelocityChange(linear1, linear2, angular1, angular2);
        
        if( applySeparate ) {
            mainBody.addLinearVelocity(linear1);
            mainBody.addRotationalVelocity(angular2);
            altBody.addLinearVelocity(linear2);
            altBody.addRotationalVelocity(angular2);
        } else {
            accumulator1.accumulate(linear1, angular1);
            accumulator2.accumulate(linear2, angular2);
        }
        
        contact2.calculateVelocityChange(linear1, linear2, angular1, angular2);
        if( applySeparate ) {
            mainBody.addLinearVelocity(linear1);
            mainBody.addRotationalVelocity(angular2);
            altBody.addLinearVelocity(linear2);
            altBody.addRotationalVelocity(angular2);
        } else {
            accumulator1.accumulate(linear1, angular1);
            accumulator2.accumulate(linear2, angular2);
        }

        if( !applySeparate ) {
            // Apply the accumulated changes between the two hinge balls
            mainBody.addLinearVelocity(accumulator1.getLinear(linear1));
            mainBody.addRotationalVelocity(accumulator2.getAngular(angular2));
            altBody.addLinearVelocity(accumulator2.getLinear(linear2));
            altBody.addRotationalVelocity(accumulator2.getAngular(angular2));
        }

    }
    
    protected static class Accumulator {
        Vec3d linMin = new Vec3d();
        Vec3d linMax = new Vec3d();
        Vec3d angMin = new Vec3d();
        Vec3d angMax = new Vec3d();
        
        public void accumulate( Vec3d lin, Vec3d ang ) {
            linMin.minLocal(lin);
            linMax.maxLocal(lin);
            angMin.minLocal(ang);
            angMax.maxLocal(ang);
        }
        
        public final Vec3d getLinear( Vec3d store ) {
            store.x = linMin.x + linMax.x;
            store.y = linMin.y + linMax.y;
            store.z = linMin.z + linMax.z;
            return store;           
        }
        
        public final Vec3d getAngular( Vec3d store ) {
            store.x = angMin.x + angMax.x;
            store.y = angMin.y + angMax.y;
            store.z = angMin.z + angMax.z;
            return store;           
        }
        
        public final void clear() {
            linMin.set(0,0,0);
            linMax.set(0,0,0);
            angMin.set(0,0,0);
            angMax.set(0,0,0);
        }
    }    
    
}




