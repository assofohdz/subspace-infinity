/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import com.google.common.base.MoreObjects; 

import com.simsilica.mathd.*;

/**
 *  The base class for all positioned physical objects in the world.
 *
 *  @author    Paul Speed
 */
public class AbstractBody<K, S extends AbstractShape> {
    
    public K id;
    public S shape;
    
    public final Vec3d position = new Vec3d();
    public final Quatd orientation = new Quatd();
    
    protected AbstractBody() {
    }
    
    protected AbstractBody( K id, S shape ) {
        this.id = id;
        this.shape = shape;
    }

    protected AbstractBody( K id, S shape, Vec3d position, Quatd orientation ) {
        this(id, shape);
        this.position.set(position);
        this.orientation.set(orientation);
    }
 
    protected void setShape( S shape ) {
        this.shape = shape;
    }
      
    /**
     *  Transforms a point from world space into object space.
     */
    public final Vec3d worldToLocal( Vec3d point, Vec3d store ) {
//System.out.println("--worldToLocal(" + point + ")");    
        if( store == null ) {
            store = point.subtract(position);    
        } else {
            store.set(point).subtractLocal(position);
        }
//System.out.println("   translated:" + store);
        
        // Then 'unrotate' it
        orientation.inverse().mult(store, store);

//System.out.println("   inverse rotated:" + store);
        
        return store;
    }
 
    /**
     *  Transforms a point from object space to world space.
     */
    public Vec3d localToWorld( Vec3d point, Vec3d store ) {
//System.out.println("--localToWorld(" + point + ")");    
        if( store == null ) {
            store = orientation.mult(point);
        } else {
            store = orientation.mult(point, store);
        }
//System.out.println("   rotated:" + store);
        store.addLocal(position);
//System.out.println("   retranslated:" + store);
        
        return store;        
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("id", id)
                .add("position", position)
                .add("orientation", orientation)
                .add("shape", shape)
                .toString();        
    }
    
    
}


