/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.simsilica.mathd.Grid;
import com.simsilica.mathd.GridCell;
import com.simsilica.mathd.Vec3i;

/**
 *  Bridges a fine BinIndex to a coarser, static-only BinIndex used for
 *  large structures that span multiple fine bins.  Registered as a
 *  BinListener on the fine index, the driver pins the overlapping coarse
 *  bins alive while any fine bin is loaded and caches the per-fine-bin
 *  coarse footprint so contact generation can scan it without recomputing
 *  it every frame.
 *
 *  <p>The coarse index holds StaticBody instances only -- no rigid bodies,
 *  no joints, no migration.  Membership is disjoint from the fine index, so
 *  contact pairs cannot be generated twice.</p>
 *
 *  @author    Asser Fahrenholz
 */
public class LargeStaticBinDriver<K, S extends AbstractShape>
        implements BinListener<K, S> {

    static Logger log = LoggerFactory.getLogger(LargeStaticBinDriver.class);

    private final BinIndex<K, S> largeStaticIndex;
    private final Grid largeGrid;

    private final Map<Bin<K, S>, Bin<K, S>[]> footprint = new HashMap<>();

    public LargeStaticBinDriver( BinIndex<K, S> largeStaticIndex ) {
        this.largeStaticIndex = largeStaticIndex;
        this.largeGrid = largeStaticIndex.getGrid();
    }

    public BinIndex<K, S> getLargeStaticBinIndex() {
        return largeStaticIndex;
    }

    /**
     *  Returns the coarse bins that should be scanned for contacts against
     *  rigid bodies in the given fine bin, or null if the fine bin is not
     *  currently loaded.  The returned array is owned by the driver and
     *  must not be modified by callers.
     */
    public Bin<K, S>[] getCoarseBinsFor( Bin<K, S> fineBin ) {
        return footprint.get(fineBin);
    }

    @Override
    public void initialize( BinIndex<K, S> source ) {
    }

    @Override
    public void terminate( BinIndex<K, S> source ) {
        for( Bin<K, S>[] coarses : footprint.values() ) {
            for( Bin<K, S> c : coarses ) {
                c.updateWatchersCount(-1);
            }
        }
        footprint.clear();
    }

    @Override
    public void loaded( Bin<K, S> fineBin ) {
        Bin<K, S>[] coarses = computeFootprint(fineBin);
        for( Bin<K, S> c : coarses ) {
            c.updateWatchersCount(+1);
        }
        footprint.put(fineBin, coarses);
        if( log.isTraceEnabled() ) {
            log.trace("loaded fine " + fineBin + " -> pinned " + coarses.length + " coarse bin(s)");
        }
    }

    @Override
    public void unloaded( Bin<K, S> fineBin ) {
        Bin<K, S>[] coarses = footprint.remove(fineBin);
        if( coarses == null ) {
            return;
        }
        for( Bin<K, S> c : coarses ) {
            c.updateWatchersCount(-1);
        }
    }

    @Override
    public void statusChanged( Bin<K, S> bin, Bin.Status status ) {
    }

    @SuppressWarnings("unchecked")
    private Bin<K, S>[] computeFootprint( Bin<K, S> fineBin ) {
        // The fine bin always nests fully inside one coarse cell when the
        // grids share an aligned origin and the coarse spacing is an
        // integer multiple of the fine spacing.  Any point inside the fine
        // cell maps to that coarse cell, so the world-origin corner works.
        Vec3i origin = fineBin.getGridCell().getWorldOrigin();
        GridCell ownCoarse = largeGrid.getContainingCell(origin);

        Vec3i r = largeStaticIndex.getGridRadius();
        Vec3i c = ownCoarse.getCell();
        int sx = r.x * 2 + 1;
        int sy = r.y * 2 + 1;
        int sz = r.z * 2 + 1;
        Bin<K, S>[] out = new Bin[sx * sy * sz];

        int i = 0;
        for( int dx = -r.x; dx <= r.x; dx++ ) {
            for( int dy = -r.y; dy <= r.y; dy++ ) {
                for( int dz = -r.z; dz <= r.z; dz++ ) {
                    GridCell cell = largeGrid.getGridCell(c.x + dx, c.y + dy, c.z + dz);
                    // create=true so the populator BinListener registered on
                    // the coarse index gets a chance to fill the bin before
                    // contact-gen scans it.
                    out[i++] = largeStaticIndex.getBin(cell, true);
                }
            }
        }
        return out;
    }
}
