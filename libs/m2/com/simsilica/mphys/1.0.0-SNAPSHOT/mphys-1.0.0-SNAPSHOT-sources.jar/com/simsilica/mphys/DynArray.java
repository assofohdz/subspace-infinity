/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

import com.google.common.reflect.TypeToken;


/**
 *  Similar to CopyOnWriteArrayList excepts that it is not thread safe
 *  and provides direct access to its array.
 *
 *  @author    Paul Speed
 */
public class DynArray<E> implements List<E>, Cloneable {
 
    private Class<E> elementType;
    private List<E> buffer;
    private E[] backingArray;
    private int size = 0;
    
    public DynArray( Class<E> elementType ) {
        this.elementType = elementType;
    }

    public DynArray( Class<E> elementType, Collection<? extends E> c ) {
        this.elementType = elementType;
        addAll(c);
    }

    @SuppressWarnings("unchecked")
    public DynArray( TypeToken<E> token ) {
        this.elementType = (Class<E>)token.getRawType();
    }

    @SuppressWarnings("unchecked")
    public DynArray<E> clone() {
        try {
            DynArray<E> clone = (DynArray<E>)super.clone();

            // Clone whichever backing store is currently active
            if( backingArray != null ) {
                clone.backingArray = backingArray.clone();
            }
            if( buffer != null ) {
                clone.buffer = (List<E>)((ArrayList<E>)buffer).clone();
            }

            return clone;
        } catch( CloneNotSupportedException e ) {
            throw new AssertionError();
        }
    }

    @SuppressWarnings("unchecked")
    protected final <T> T[] createArray(Class<T> type, int size) {
        return (T[])java.lang.reflect.Array.newInstance(type, size);
    }

    protected final E[] createArray(int size) {
        return createArray(elementType, size);
    }
       
    /**
     *  Returns a current snapshot of this List's backing array that
     *  is guaranteed not to change through further List manipulation.
     *  Changes to this array may or may not be reflected in the list and
     *  should be avoided.  Once the backing array is returned then it is
     *  shared until further list changes are made.  So a stable list
     *  means that the array is only created once.
     */
    public final E[] getArray() {
        if( backingArray != null )
            return backingArray;

        if( buffer == null ) {
            backingArray = createArray(0);
        } else {
            // Only keep the array or the buffer but never both at
            // the same time.  1) it saves space, 2) it keeps the rest
            // of the code safer.
            backingArray = buffer.toArray(createArray(buffer.size()));
            buffer = null;
        }
        return backingArray;
    }

    protected final List<E> getBuffer() {
        if( buffer != null )
            return buffer;

        if( backingArray == null ) {
            buffer = new ArrayList<E>();
        } else {
            // Only keep the array or the buffer but never both at
            // the same time.  1) it saves space, 2) it keeps the rest
            // of the code safer.
            buffer = new ArrayList<E>(Arrays.asList(backingArray));
            backingArray = null;
        }
        return buffer;
    }
    
    @Override
    public final int size() {
        return size;
    }

    @Override
    public final boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains( Object o ) {
        return indexOf(o) >= 0;
    }

    @Override
    public Iterator<E> iterator() {
        return listIterator();
    }

    @Override
    public Object[] toArray() {
        return getArray();
    }

    @Override 
    @SuppressWarnings("unchecked")
    public <T> T[] toArray( T[] a ) {

        E[] array = getArray();
        if( a.length < array.length ) {
            return (T[])Arrays.copyOf(array, array.length, a.getClass());
        }

        System.arraycopy(array, 0, a, 0, array.length);

        if( a.length > array.length ) {
            a[array.length] = null;
        }

        return a;
    }        

    @Override
    public boolean add( E e ) {
        boolean result = getBuffer().add(e);
        size = getBuffer().size();
        return result;
    }

    @Override
    public boolean remove( Object o ) {
        boolean result = getBuffer().remove(o);
        size = getBuffer().size();
        return result;
    }

    @Override
    public boolean containsAll( Collection<?> c ) {
        if( buffer != null ) {
            return buffer.containsAll(c);
        }
        return Arrays.asList(getArray()).containsAll(c);
    }

    @Override
    public boolean addAll( Collection<? extends E> c ) {
        boolean result = getBuffer().addAll(c);
        size = getBuffer().size();
        return result;
    }

    @Override
    public boolean addAll( int index, Collection<? extends E> c ) {
        boolean result = getBuffer().addAll(index, c);
        size = getBuffer().size();
        return result;
    }

    @Override
    public boolean removeAll( Collection<?> c ) {
        if( isEmpty() ) {
            return false;
        }
        boolean result = getBuffer().removeAll(c);
        size = getBuffer().size();
        return result;
    }

    @Override
    public boolean retainAll( Collection<?> c ) {
        if( isEmpty() ) {
            return false;
        }
        boolean result = getBuffer().retainAll(c);
        size = getBuffer().size();
        return result;
    }

    @Override
    public void clear() {
        if( isEmpty() ) {
            return;
        }
        getBuffer().clear();
        size = 0;
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        List other = (List)o;
        Iterator it1 = iterator();
        Iterator it2 = other.iterator();
        while( it1.hasNext() && it2.hasNext() ) {
            Object o1 = it1.next();
            Object o2 = it2.next();
            if( !Objects.equals(o1, o2) ) {
                return false;
            }
        }
        return !(it1.hasNext() || it2.hasNext());
    }

    @Override
    public int hashCode() {
        // Exactly the hash code described in the List interface, basically
        E[] array = getArray();
        int result = 1;
        for( E e : array ) {
            result = 31 * result + (e == null ? 0 : e.hashCode());
        }
        return result;
    }

    @Override
    public E get( int index ) {
        if( backingArray != null )
            return backingArray[index];
        if( buffer != null )
            return buffer.get(index);
        throw new IndexOutOfBoundsException( "Index:" + index + ", Size:0" );
    }

    @Override
    public E set( int index, E element ) {
        // We could optionally set the value in the array directly
        // but we don't.  It means the array values are more stable
        // during iteration.
        return getBuffer().set(index, element);
    }

    @Override
    public void add( int index, E element ) {
        getBuffer().add(index, element);
        size = getBuffer().size();
    }

    @Override
    public E remove( int index ) {
        E result = getBuffer().remove(index);
        size = getBuffer().size();
        return result;
    }

    @Override
    public int indexOf( Object o ) {
        // We could unroll this to use the buffer if it exists
        // but this is more consistent with other behavior the caller
        // might be doing... plus given the use-cases for this class,
        // it is likely the array will be needed elsewhere anyway.
        E[] array = getArray();
        for( int i = 0; i < array.length; i++ ) {
            E element = array[i];
            if( element == o ) {
                return i;
            }
            if( element != null && element.equals(o) ) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int lastIndexOf( Object o ) {
        E[] array = getArray();
        for( int i = array.length - 1; i >= 0; i-- ) {
            E element = array[i];
            if( element == o ) {
                return i;
            }
            if( element != null && element.equals(o) ) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public ListIterator<E> listIterator() {
        return new ArrayIterator<E>(getArray(), 0);
    }

    @Override
    public ListIterator<E> listIterator( int index ) {
        return new ArrayIterator<E>(getArray(), index);
    }

    @Override
    public List<E> subList( int fromIndex, int toIndex ) {
        // It is non-trivial to support the full sublist semantics without
        // implementing a whole new list subclass.  We can re-examine that
        // kind of implementation is we ever need full mutable semantics for
        // sublists.  In the mean time, we'll return a read-only list to avoid
        // confusion about what may or may not be valid.
        List<E> raw =  Arrays.asList(getArray()).subList(fromIndex, toIndex);
        return Collections.unmodifiableList(raw);
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + Arrays.asList(getArray());
    }
                  
    protected class ArrayIterator<E> implements ListIterator<E> {
        private E[] array;
        private int next;
        private int lastReturned;

        protected ArrayIterator( E[] array, int index ) {
            this.array = array;
            this.next = index;
            this.lastReturned = -1;
        }

        public boolean hasNext() {
            return next != array.length;
        }

        public E next() {
            if( !hasNext() )
                throw new NoSuchElementException();
            lastReturned = next++;
            return array[lastReturned];
        }

        public boolean hasPrevious() {
            return next != 0;
        }

        public E previous() {
            if( !hasPrevious() )
                throw new NoSuchElementException();
            lastReturned = --next;
            return array[lastReturned];
        }

        public int nextIndex() {
            return next;
        }

        public int previousIndex() {
            return next - 1;
        }

        public void remove() {
            // This operation is not so easy to do but we will fake it.
            // The issue is that the backing list could be completely
            // different than the one this iterator is a snapshot of.
            // We'll just remove(element) which in most cases will be
            // correct.  If the list had earlier .equals() equivalent
            // elements then we'll remove one of those instead.  Either
            // way, none of those changes are reflected in this iterator.
            DynArray.this.remove(array[lastReturned]);
        }

        public void set( E e ) {
            if( array == backingArray ) {
                // We could technically do it in this case but it would be
                // different than the DynArray.set() semantics so I'm not.
            }
            throw new UnsupportedOperationException();
        }

        public void add( E e ) {
            // We cannot easily support this one either as the underlying
            // list may have changed since this iterator was created and thus
            // the local index makes no sense anymore.
            throw new UnsupportedOperationException();
        }
    }
}
