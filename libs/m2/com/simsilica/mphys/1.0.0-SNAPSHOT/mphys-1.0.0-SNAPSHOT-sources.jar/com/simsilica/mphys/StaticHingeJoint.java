/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Forked this from the old HingeJoint as it only handles world-&gt;body
 *  hinges.  I want to try some body-&gt;body approaches that are 'wordy'.
 *
 *  @author    Paul Speed
 */
public class StaticHingeJoint<K, S extends AbstractShape> implements Joint<K, S> {
    
    static Logger log = LoggerFactory.getLogger(StaticHingeJoint.class);

    // At first we'll try to do a 'glue' joint which basically
    // as 'absolute' constraints.  A fixed joint.
    //
    
    K id;
    
    RigidBody<K, S> altBody;
    Vec3d altOffset;
    Quatd altRot;
    
    RigidBody<K, S> mainBody;
    Vec3d mainOffset;
    Quatd mainRot;
 
    Quatd relativeRotation;
 
    double damping;
    
    double test1;    
 
    /**
     *  We defer to the contact class for many of our calculations but we don't
     *  need a new one every time.  Might as well keep one around.
     */
    private Contact<K, S> contact = new Contact<>();
 
    private int axis = 0;
 
    /**
     *  Creates a free-form ball joint that connects two bodies together
     *  or a body to world point.  If the altBody is null then the altOffset
     *  is the world location for attachment.
     */
    public StaticHingeJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset, Quatd mainRot,
                       RigidBody<K, S> altBody, Vec3d altOffset, Quatd altRotation,
                       int axis,
                       double damping,
                       double test1 ) {
        this.id = id;
        this.altBody = altBody;
        this.altOffset = altOffset;
        this.altRot = altRot;
        this.mainBody = mainBody;
        this.mainOffset = mainOffset;
        this.mainRot = mainRot;
        this.axis = axis;
        this.damping = damping;
        this.test1 = test1;
        this.contact.setBodies(mainBody, altBody);
        
        // negative friction indicates that the planar calculation
        // should be skipped but the friction-based impulses should still
        // be used as they are more accurate.
        contact.friction = -0.7;
    } 
 
    public K getId() {
        return id; 
    }
 
    public RigidBody<K, S> getMainBody() {
        return mainBody;
    }
    
    public RigidBody<K, S> getAltBody() {
        return altBody;
    }                  
 
    public RigidBody<K, S> getOtherBody( RigidBody<K, S> body ) {
        if( mainBody == body ) {
            return altBody;
        }
        if( altBody == body ) {
            return mainBody;
        }
        throw new IllegalArgumentException("Specified body:" + body.id + " is not part of this joint:" + id);
    } 

    public boolean isSleepy() {
        // The joint has to be relatively "closed" for us to be sleepy
        if( Math.abs(contact.penetration) > 0.00001 ) {
            return false;
        }        
        return mainBody.isSleepy() || (altBody != null && altBody.isSleepy());
    }
        
    public void calculateInternals( double step ) {
    }
 
    public void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                         Vec3d angular1, Vec3d angular2 ) {
    }
                                         
    public void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                         Vec3d rotDelta1, Vec3d rotDelta2 ) {
    }
 
    
    public void resolve2( double step ) {
log.debug("Joint.resolve()");
log.debug("  pos:" + mainBody.position + "  orient:" + mainBody.orientation);
        // Try to treat it like a spring
        
        Vec3d world1 = altOffset;
        Vec3d world2 = mainBody.localToWorld(mainOffset);
        
        Vec3d delta = world1.subtract(world2);
        Vec3d dir = delta.normalize();

log.debug("  world1:" + world1 + "  world2:" + world2);
log.debug("  delta:" + delta + "  dir:" + dir);               
        
        mainBody.addForceAtPoint(delta.mult(100), world2);
        
    }

    public void resolve( double step ) {
        //resolveUnconstrained(step);
        resolveConstrained(step);
    }
    
    public void resolveConstrained( double step ) {
log.debug("Joint.resolve()");
    
        // Testing the hanging from a single point case
        Vec3d world1 = altOffset;
        Vec3d world2 = mainBody.localToWorld(mainOffset);
 
        Vec3d delta = world1.subtract(world2);
        double length = delta.length();
        if( length == 0 ) { //< 0.0001 ) {
log.debug("  delta length:" + length);
            contact.penetration = 0;        
            return; // let's see what happens
        }
        Vec3d normal = delta.mult(1/length); //world2.subtract(mainBody.position).normalizeLocal(); 
if( normal.isNaN() ) {
    // This happens when the mainBody has not been integrated yet, thus its
    // calculateDerivedData() has never been called.  I don't know 
    // how that can happen.
    log.warn("Normal is NaN.... length:" + length + "  delta:" + delta + "  world1:" + world1 + "  world2:" + world2);
} 
 
/*log.debug("  pos:" + mainBody.position + "  orient:" + mainBody.orientation);
log.debug("  world1:" + world1 + "  world2:" + world2);
log.debug("  normal:" + normal + "  delta:" + delta);               

log.debug("  lin:" + mainBody.getLinearVelocity());         
log.debug("  rot:" + mainBody.getRotationalVelocity());*/ 
double linVelSq = mainBody.getLinearVelocity().lengthSq() / mainBody.getTemperature();
double rotVelSq = mainBody.getRotationalVelocity().lengthSq() / mainBody.getTemperature();

//log.debug("  linMovement:" + linVelSq + "  rotMovement:" + rotVelSq);

double originalInvMass = mainBody.inverseMass;
//mainBody.inverseMass = 100; // tiny mass
//mainBody.inverseMass = 10; // less tiny mass
//mainBody.inverseMass = 0.001;

// A smaller mass makes the object slow down quicker as the result of
// the joint but it doesn't make the joint any stiffer in general.  If
// other objects hit it then it still goes bonkers.
// Large masses here like 1000 make the joint shudder sometimes.  It's quick
// to get to small oscillations but stays a long time there.

// Note: 2019-04-19... the above was before I'd fixed a lot of the intertia
// tensor issues.  Unclear if this would still be the case now.

        // So what if we just treat it like a contact
        //Contact<K, S> contact = new Contact<>(mainBody, world2, normal, delta.length());
        //Contact<K, S> contact = new Contact<>(mainBody, world2, normal, delta.length());
        contact.setContactInfo(world2, normal, delta.length());
        
        // Friction doesn't seem to matter at all
        //contact.friction = 0;
        // Neither does restitution... 
        //contact.restitution = 1;
        // I suspect they would for larger distances but once we've locked in then
        // the non-planar impulse is likely to be small and the restitution threshold
        // never exceeded.
        
        // Let's check if these really matter
        if( test1 > 0 ) {
            contact.friction = 0;
            contact.restitution = 0;
        }
        
        contact.matchLocalTemperature();               
        contact.calculateInternals(step);

        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();           
        Vec3d linear2 = new Vec3d();           
        Vec3d angular2 = new Vec3d();           
        contact.calculatePositionChange(linear1, linear2, angular1, angular2, contact.penetration);
 
//log.debug("  p linear1:" + linear1);
//log.debug("  p angular1:" + angular1);
double[] angles;
boolean postCleanup;

if( false ) { 
    // This doesn't actually work because the euler angles representation gets
    // messed up in some quadrants.  It's one thing to zero out components and feed
    // it back, it's another thing entirely to try to use it as a rotational
    // vector.
    angles = mainBody.orientation.toAngles(null);
    log.debug("      angles:" + angles[0] + ", " + angles[1] + ", " + angles[2]);
    angular1.x = -angles[0];
    angular1.z = -angles[2];
} else {
    // This works but let's error creep in and so we have to post-correct
    switch( axis ) {
        case 0:
            angular1.y = 0;
            angular1.z = 0;
            break;
        case 1:
            angular1.x = 0;
            angular1.z = 0;
            break;
        case 2:
            angular1.x = 0;
            angular1.y = 0;
            break;
    }            
    postCleanup = true;
}
 
        mainBody.position.addLocal(linear1);            
        mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
//log.debug("  after pos:" + mainBody.position + "  orient:" + mainBody.orientation);
//double[] angles = mainBody.orientation.toAngles(null);
if( postCleanup ) {
    angles = mainBody.orientation.toAngles(null);
    //log.debug("      angles:" + angles[0] + ", " + angles[1] + ", " + angles[2]);
    switch( axis ) {
        case 0:
            mainBody.orientation.fromAngles(angles[0], 0, 0);
            break;
        case 1:
            mainBody.orientation.fromAngles(0, angles[1], 0);
            break;
        case 2:
            mainBody.orientation.fromAngles(0, 0, angles[2]);
            break;
    }
}
        mainBody.calculateDerivedData();
 
        contact.calculateVelocityChange(linear1, linear2, angular1, angular2);
//log.debug("  v linear1:" + linear1);
//log.debug("  v angular1:" + angular1);
Vec3d rot = mainBody.getRotationalVelocity();
//rot = mainBody.orientation.inverse().mult(rot);
//angular1 = mainBody.orientation.inverse().mult(angular1);
double slow = damping; //0.1; 
switch( axis ) {
    case 0:
        angular1.x = angular1.x - rot.x * slow; 
        angular1.y = -rot.y;
        angular1.z = -rot.z;
        break;
    case 1:
        angular1.x = -rot.x;
        angular1.y = angular1.y - rot.y * slow; 
        angular1.z = -rot.z;
        break;
    case 2:
        angular1.x = -rot.x;
        angular1.y = -rot.y;
        angular1.z = angular1.z - rot.z * slow; 
        break;
}        

//angular1 = mainBody.orientation.mult(angular1);
        mainBody.addLinearVelocity(linear1);
        mainBody.addRotationalVelocity(angular1);
mainBody.inverseMass = originalInvMass;        
    }

    
/*    
    public void resolve1( double step ) {
System.out.println("Joint.resolve()");

        Vec3d world1;
        if( altBody == null ) {
            world1 = altOffset;
        } else {
            world1 = altBody.localToWorld(altOffset);
        }
        Quatd worldRot1;
        if( altBody == null ) {
            worldRot1 = relativeRotation;
        } else {
            worldRot1 = altBody.orientation.mult(relativeRotation);
        }
 
        mainBody.orientation.set(worldRot1);
        mainBody.calculateDerivedData();
        
        Vec3d world2 = mainBody.localToWorld(mainOffset);
        
        Vec3d delta = world1.subtract(world2);
System.out.println("world1:" + world1 + "  world2:" + world2 + "  delta:" + delta);           
System.out.println("  velocity:" + mainBody.getLinearVelocity()); 
        
        mainBody.position.addLocal(delta);
        
        // Unless we also kill velocity this object will never settle down

        Vec3d dir = delta.normalize();
        double vFromAcc = mainBody.getLastFrameAcceleration().mult(step).dot(dir);
System.out.println("vFromAcc:" + vFromAcc);
        mainBody.addLinearVelocity(mainBody.getLinearVelocity().mult(-1));
        
        // We should probably also kill rotational velocity        
        
        // Because we are adjusting the center of the object and not
        // taking torque into account, the object kind of just floats in its
        // orientation when unconstrained... rather than hang down like we
        // might like.  Need to figure out the contact code I need to borrow
        // to make that happen.  I could make it work by treating it like
        // a fake contact but then I think I lose the ability to apply my own
        // angular constraints.  It would be better to steal the contact code
        // as _IF_ I was doing the contact solution.  Then pull it apart to
        // see where I can inject constraints.
    }*/
}
