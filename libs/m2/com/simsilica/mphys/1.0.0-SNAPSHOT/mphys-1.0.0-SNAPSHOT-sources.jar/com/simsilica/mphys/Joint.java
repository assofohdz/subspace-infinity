/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public interface Joint<K, S extends AbstractShape> {
 
    public K getId();
 
    public RigidBody<K, S> getMainBody();
    public RigidBody<K, S> getAltBody();
 
    public RigidBody<K, S> getOtherBody( RigidBody<K, S> body ); 
    
    public void resolve( double step );
 
    public boolean isSleepy();
    
    // As part of using the tandem resolver we treat joints kind of
    // like contacts so we need to be able to ask for the position
    // change and the velocity change separately.
    public void calculateInternals( double step );
       
    public void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                         Vec3d angular1, Vec3d angular2 );
                                         
    public void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                         Vec3d rotDelta1, Vec3d rotDelta2 );
                                            
}
