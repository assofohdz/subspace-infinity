/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SpringJoint<K, S extends AbstractShape> implements Joint<K, S> {
    
    static Logger log = LoggerFactory.getLogger(SpringJoint.class);

    // At first we'll try to do a 'glue' joint which basically
    // as 'absolute' constraints.  A fixed joint.
    //
    
    K id;
    
    RigidBody<K, S> altBody;
    Vec3d altOffset;
    
    RigidBody<K, S> mainBody;
    Vec3d mainOffset;
 
    Quatd relativeRotation;
 
    double damping;
 
    double springLength = 0; //1;
       
    double test1;    
 
    /**
     *  Creates a free-form ball joint that connects two bodies together
     *  or a body to world point.  If the altBody is null then the altOffset
     *  is the world location for attachment.
     */
    public SpringJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset,
                      RigidBody<K, S> altBody, Vec3d altOffset, 
                      Quatd relativeRotation,
                      double damping,
                      double test1 ) {
        this(id, mainBody, mainOffset, altBody, altOffset, relativeRotation,
             damping, 1, test1);                      
    }                      
                      
    public SpringJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset,
                      RigidBody<K, S> altBody, Vec3d altOffset, 
                      Quatd relativeRotation,
                      double damping,
                      double springLength, 
                      double test1 ) {
        this.id = id;
        this.altBody = altBody;
        this.altOffset = altOffset;
        this.mainBody = mainBody;
        this.mainOffset = mainOffset;
        this.relativeRotation = relativeRotation;
        this.damping = damping;
        this.springLength = springLength;
        this.test1 = test1;
    } 
 
    public K getId() {
        return id; 
    }
 
    public RigidBody<K, S> getMainBody() {
        return mainBody;
    }
    
    public RigidBody<K, S> getAltBody() {
        return altBody;
    }                  
 
    public RigidBody<K, S> getOtherBody( RigidBody<K, S> body ) {
        if( mainBody == body ) {
            return altBody;
        }
        if( altBody == body ) {
            return mainBody;
        }
        throw new IllegalArgumentException("Specified body:" + body.id + " is not part of this joint:" + id);
    } 
       
    public boolean isSleepy() {
        // Both have to be sleepy for this joint to be sleepy
        return mainBody.isSleepy() && (altBody == null || altBody.isSleepy());
    }
 
    public void calculateInternals( double step ) {
    }
 
    public void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                         Vec3d angular1, Vec3d angular2 ) {
    }
                                         
    public void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                         Vec3d rotDelta1, Vec3d rotDelta2 ) {                                         
    }
 
    public void resolve( double step ) {
        //double k = 100;
        double k = 1000;
 
        Vec3d world1 = mainBody.localToWorld(mainOffset); 
        Vec3d world2 = altOffset;
        if( altBody != null ) {
            world2 = altBody.localToWorld(altOffset);
        } 
 
        Vec3d delta = world2.subtract(world1); 
        double distance = delta.length(); 
 
        // Hooke's law       
        double x = distance - springLength;        
        //double f = k * x;  
        //double f = k * (x * x * x);
        double f;
        f = k * x;
        double rotDamping;
        if( test1 == 0 ) {
            //f = k * x;
            rotDamping = 1;
        } else { 
            //f = k * x * Math.abs(x);
            rotDamping = test1;
        }
        
        // Make sure the force isn't ridiculous
        //f = Math.min(f, 1000);
        // Except it needs to take negative forces into account
//System.out.println("f:" + f);
        
        // |delta| = distance
        // delta / distance = dir
        // dir * f = force
        // force = dir * f = (delta / distance) * f
        // force = delta * f / distance
        Vec3d force = delta.mult(f / distance);
        
        // For now just test applying a force up
        mainBody.addForceAtBodyPoint(force, rotDamping, mainOffset);

    }    
}
