/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

/**
 *  A truncated pyramid defined by a location and orientation representing a
 *  Z-axis view vector and some left/up parameter representing the
 *  angles of the sides of a symmetric view volume.  This is designed
 *  to represent "perception" style collision shapes used for visible
 *  rigid body queries.
 *
 *  @author    Paul Speed
 */
public class Frustum implements QueryVolume {
    static Logger log = LoggerFactory.getLogger(Frustum.class);

    private Vec3d position;
    private Quatd orientation;
    private double far;
    private double xFov;
    private double yFov;

    // Keep track of the calculated sin/cos/tan of the x and y FOVs
    private Vec3d xTrig = new Vec3d();
    private Vec3d yTrig = new Vec3d();

    // Cache the view space vectors
    private Vec3d dir;
    private Vec3d left;
    private Vec3d up;

    public Frustum( double far, double xFov, double yFov ) {
        this(new Vec3d(), new Quatd(), far, xFov, yFov);
    }

    public Frustum( Vec3d position, Quatd orientation, double far, double xFov, double yFov ) {
        this.position = position;
        this.orientation = orientation;
        this.far = far;
        this.xFov = xFov;
        this.yFov = yFov;
        recalculateXTrig();
        recalculateYTrig();
    }

    public void set( Vec3d position, Quatd orientation ) {
        setPosition(position);
        setOrientation(orientation);
    }

    protected final void recalculateXTrig() {
        double half = xFov * 0.5;
        xTrig.x = Math.cos(half);
        xTrig.y = Math.sin(half);
        xTrig.z = Math.tan(half);
    }

    protected final void recalculateYTrig() {
        double half = yFov * 0.5;
        yTrig.x = Math.cos(half);
        yTrig.y = Math.sin(half);
        yTrig.z = Math.tan(half);
    }

    public void setPosition( Vec3d position ) {
        this.position.set(position);
    }

    public Vec3d getPosition() {
        return position;
    }

    public void setOrientation( Quatd orientation ) {
        this.orientation.set(orientation);
        dir = null;
        left = null;
        up = null;
    }

    public Quatd getOrientation() {
        return orientation;
    }

    /**
     *  Sets the far clip plane of the frustum.
     */
    public void setFar( double far ) {
        this.far = far;
    }

    public double getFar() {
        return far;
    }

    /**
     *  Sets the full horizontal field of view in radians.
     */
    public void setHorizontalFov( double xFov ) {
        this.xFov = xFov;
        recalculateXTrig();
    }

    public double getHorizontalFov() {
        return xFov;
    }

    /**
     *  Sets the full vertical field of view in radians.
     */
    public void setVerticalFov( double yFov ) {
        this.yFov = yFov;
        recalculateYTrig();
    }

    public double getVerticalFov() {
        return yFov;
    }

    /**
     *  Returns the z-axis (central/view vector) of this frustum's view space.
     */
    public final Vec3d getDir() {
        if( dir == null ) {
            dir = orientation.mult(Vec3d.UNIT_Z);
        }
        return dir;
    }

    /**
     *  Returns the x-axis vector of this frustum's view space.
     */
    public final Vec3d getLeft() {
        if( left == null ) {
            left = orientation.mult(Vec3d.UNIT_X);
        }
        return left;
    }

    /**
     *  Returns the y-axis vector of this frustum's view space.
     */
    public final Vec3d getUp() {
        if( up == null ) {
            up = orientation.mult(Vec3d.UNIT_Y);
        }
        return up;
    }

    @Override
    public boolean intersects( Vec3d pos, double radius ) {
        return toFrustumSpace(pos, radius, null) != null;
    }

    /**
     *  If the specified position and radius intersect this frustum then
     *  the 'frustum space' transformation is returned else it returns
     *  null.  If a target is specified then the values will be set to it
     *  and a non-null return will be that target vector, else a vector
     *  will be created as needed.
     */
    public Vec3d toFrustumSpace( Vec3d pos, double radius, Vec3d target ) {
        if( target == null ) {
            target = new Vec3d();
        }

//log.info("  toFrustumSpace(" + pos + ", " + radius + ")");

        // frustum relative position
        target.set(pos).subtractLocal(position);
//log.info("  relative:" + target + "   origin:" + position);
        double z = target.dot(getDir());
//log.info("   z:" + z + "  dir:" + getDir());
        if( z + radius < 0 ) {
            // It's fully behind
            return null;
        }
        if( z - radius > far ) {
            // It's fully outside the far plane
            return null;
        }

        // The 'sphere' will intersect further down the frustum than our
        // z-projection.  It will be a tangent plane to that sphere so
        // I think we can just move z forward by radius * sin.
        //
        // Crude ascii art:
        //           /
        //          X((()
        //         /(\   )   cz = the amount of z forward to meet the tangent point.
        //        /(  \   )
        //       / (      )  should be sin(theta) * radius.  The line from radius
        //      /   (    )   to tangent point will be perpendicular to the frustum
        //     /     (())    side so as fov gets smaller so does sine and so does cz.
        //    x
        //
        // Note that the distance to the sphere's center will also need to be
        // adjusted by cos(theta) * radius to get the proper intersection threshold.
        //double zRadius = Math.sin(xFov * 0.5) * radius;
        //double xRadius = Math.cos(xFov * 0.5) * radius;
        //double xAtZ = Math.tan(xFov * 0.5) * (z + zRadius);
        double zRadius = xTrig.y * radius;
        double xRadius = xTrig.x * radius;
        double xAtZ = xTrig.z * (z + zRadius);

        double x = target.dot(getLeft());
//log.info("   x:" + x + "  left:" + getLeft());
        if( x > 0 ) {
            if( x - xRadius > xAtZ ) {
                // Completely to the left
                return null;
            }
        } else {
            if( x + xRadius < -xAtZ ) {
                // Completely to the right
                return null;
            }
        }

        //zRadius = Math.sin(yFov * 0.5) * radius;
        //double yRadius = Math.cos(yFov * 0.5) * radius;
        //double yAtZ = Math.tan(yFov * 0.5) * (z + zRadius);
        zRadius = yTrig.y * radius;
        double yRadius = yTrig.x * radius;
        double yAtZ = yTrig.z * (z + zRadius);

        double y = target.dot(getUp());
//log.info("   y:" + y + "   up:" + getUp());
        if( y > 0 ) {
            if( y - yRadius > yAtZ ) {
                // Completely above
                return null;
            }
        } else {
            if( y + yRadius < -yAtZ ) {
                // Completely below
                return null;
            }
        }

        // It is within the frustum so we can fill in target with
        // the axis values we calculated.
        target.set(x, y, z);
        return target;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("position", position)
            .add("orientation", orientation)
            .add("far", far)
            .add("xFov", xFov)
            .add("yFov", yFov)
            .toString();
    }
}
