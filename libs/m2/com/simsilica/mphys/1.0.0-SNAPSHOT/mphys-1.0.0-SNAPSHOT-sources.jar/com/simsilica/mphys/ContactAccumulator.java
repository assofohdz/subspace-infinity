/*
 * $Id$
 * 
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ContactAccumulator<K, S extends AbstractShape> implements ContactListener<K, S> {
    
    public List<Contact<K, S>> contacts = new ArrayList<>();

    public ContactAccumulator() {
    }

    public boolean isEmpty() {
        return contacts.isEmpty();
    }

    public void clear() {
        contacts.clear();
    }

    @Override
    public void newContact( Contact<K, S> contact ) {
    
        // In any contact dispatch chain, the contact accumulator is
        // always the last in line.  All filtering/disabling has been
        // done by now... so it should be safe to deliver it to any
        // drivers.
        ControlDriver<K, S> driver = contact.body1.getControlDriver(); 
        if( driver != null ) {
            driver.newContact(contact);
        }
        driver = contact.body2 instanceof RigidBody ? ((RigidBody<K,S>)contact.body2).getControlDriver() : null; 
        if( driver != null ) {
            driver.newContact(contact);
        }

        // If a driver didn't kill it then keep it.
        if( contact.isEnabled() ) {    
            contacts.add(contact);
        }
    }
}


