/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys.simple;

import java.util.*;

import com.google.common.base.Predicate;

import com.simsilica.mathd.*;
 
import com.simsilica.mphys.*; 

/**
 *
 *
 *  @author    Paul Speed
 */
public class SimpleCollisionSystem<K> implements CollisionSystem<K, SimpleShape> {

    private double restitution = Contact.DEFAULT_RESTITUTION;
    private double friction = Contact.DEFAULT_FRICTION; 

    public SimpleCollisionSystem() {
    }
    
    public void setRestitution( double restitution ) {
        this.restitution = restitution;
    }
    
    public double getRestitution() {
        return restitution;
    }

    public void setFriction( double friction ) {
        this.friction = friction;
    }
    
    public double getFriction() {
        return friction;
    }

    public void generateWorldCollisions( RigidBody<K, SimpleShape> body, ContactListener<K, SimpleShape> results ) {
        
        // Just collide with the ground for now
        double radius = body.shape.getMass().getRadius();
        Vec3d pos = body.position;
        if( pos.y < radius ) {
            // Generate a contact against the floor
            Vec3d cp = new Vec3d(pos.x, 0, pos.z);
            Vec3d cn = new Vec3d(0, 1, 0);
            
            // Can't remember which way penetration goes.  I think >= 0 means
            // no penetration.
            //double penetration = pos.y - radius;
            // Nope, that was backwards.  Penetration is positive into the object, ie:
            // along the normal.  <=0 is no penetration. 
            double penetration = radius - pos.y; 
            
            Contact<K, SimpleShape> contact = new Contact<>(body, cp, cn, penetration);
            contact.restitution = restitution;
            contact.friction = friction;
            results.newContact(contact); 
        }
    }

    /**
     *  Converts a direction vector to a normal by either dividing by distance
     *  or creating a random perterbation if dist is 0.
     */
    private static Vec3d toNormal( Vec3d delta, double dist ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
System.out.println("Random deflect.");        
        delta.x = Math.random() * 0.1;
        delta.y = Math.random() * 0.1;
        delta.z = Math.random() * 0.1;
        return delta.normalizeLocal();
    }

    private static Vec3d toNormal( Vec3d delta, double dist, Vec3d fallback ) {
        if( dist > 0 ) {
            return delta.mult(1/dist);
        }
        if( fallback.lengthSq() == 1 ) {
            return fallback;
        }
        return toNormal(fallback, fallback.length());
    }

    private void checkStaticContact( RigidBody<K, SimpleShape> body, StaticBody<K, SimpleShape> world, ContactListener<K, SimpleShape> results ) {
        double r1 = body.shape.getMass().getRadius();
        double r2 = world.shape.getMass().getRadius();
 
        if( world.shape.getType() == SimpleShape.Type.Sphere ) {           
            double threshold = (r1 + r2) * (r1 + r2);
            
            double distSq = body.position.distanceSq(world.position);
            if( distSq > threshold ) {
                // No intersection
                return;
            }
    
            double dist = Math.sqrt(distSq);
                
            // Contact point is directly in the middle
            // No, dummy... that's only true if they are the same size.
            // Vec3d cp = b2.position.add(b1.position).mult(0.5);
            // Well, I mean technically it depends on whether you want the
            // cp on one of the surfaces or in between the surfaces, etc... but
            // a pure average is not right because for big sphere to small sphere
            // collisions it puts it way inside the big sphere.
            Vec3d cp;
            if( dist > 0 ) {
                // Contact point is down the vector between them but the radius amount
                // We put it on the surface of the second body arbitrarily.  The
                // first one is more likely to be a mob in a mob->static hit.
                // That's the way the normal points, anyway.
                Vec3d delta = body.position.subtract(world.position);
                cp = delta.multLocal(r2/dist).addLocal(world.position);
            } else {
                // Else cp is just one of the positions
                cp = world.position.clone();
            }
                
            // Contact normal points away from the static object
            // body1 contacts body2 so the normal is on body2... which in this case is the
            // world.
            //Vec3d cn = body.position.subtract(world.position).multLocal(1/dist);
            if( !(dist > 0) ) {
                System.out.println("Static sphere coincidence body:" + body.position + "  sphere:" + world.position + "  dist:" + dist);
            }
            Vec3d cn = toNormal(body.position.subtract(world.position), dist);
                
            double penetration = r1 - (dist - r2);
            
            Contact<K, SimpleShape> contact = new Contact<>(body, world, cp, cn, penetration);
            contact.restitution = restitution;
            contact.friction = friction;
            results.newContact(contact);
        } else {
            
            // Find the point on the cube closest to the sphere's center
            double x = body.position.x - world.position.x;
            double y = body.position.y - world.position.y;
            double z = body.position.z - world.position.z;
 
            Vec3d cn = new Vec3d();
            int edgeOrFaceHit = 0;
 
            // Clamp the values to the box radius               
            if( x > r2 ) {
                x = r2;
                cn.x = 1;
            } else if( x < -r2 ) {
                x = -r2;
                cn.x = -1;
            } else {
                cn.x = 0;
                edgeOrFaceHit++;
            }                 
            if( y > r2 ) {
                y = r2;
                cn.y = 1;
            } else if( y < -r2 ) {
                y = -r2;
                cn.y = -1;
            } else {
                cn.y = 0;
                edgeOrFaceHit++;
            }
            if( z > r2 ) {
                z = r2;
                cn.z = 1;
            } else if( z < -r2 ) {
                z = -r2;
                cn.z = -1;
            } else {
                cn.z = 0;
                edgeOrFaceHit++;
            }
                
            Vec3d cp = world.position.add(x, y, z);
                
            // For a box, if the contact point is not on an edge or corner then the
            // normal is the surface normal of the box itself.
            double penetration;                
            if( edgeOrFaceHit > 2 ) {
                if( edgeOrFaceHit == 3 ) {
System.out.println("Inside. cn:" + cn + "  edgeOrFaceHit:" + edgeOrFaceHit + "  body:" + body.position + "  static:" + world.position);
                    // Fully penetrating.  This is technically a face hit
                    // but we have to figure out what the best face is.
                    // To do that we need to find the longest delta
                    if( x > y ) {
                        if( x > z ) {
                            // x is best
                            cn.x = 1;
                        } else {
                            // z is best... it must be >= x which was already > y
                            cn.z = 1;
                        }
                    } else {
                        if( y > z ) {
                            // y is best
                            cn.y = 1;
                        } else {
                            // z is best... it must be >= y which was already >= x
                            cn.z = 1;
                        }
                    }
                        
                    // Now that we have a proper normal we can proceed
                }
                    
                // We get a more pure normal this way and an easier distance
                // check.  The 'else' branch actually should also cover this
                // ok because the cp as calculated above would already be
                // the closest point on the cube. 
                Vec3d delta = body.position.subtract(world.position);                
                // A face is easy... the normal is already right
                double dist = cn.dot(delta);
                if( dist > r1 + r2 ) {
                    return;
                }
                penetration = r1 - (dist - r2);
            } else {
                    
                double distSq = cp.distanceSq(body.position);
                if( distSq > (r1 * r1) ) {
                    return;
                }
                
                double dist = Math.sqrt(distSq);
                
                //Vec3d cn = body.position.subtract(cp).mult(1/dist);
                if( dist > 0 ) {
                    // The easy way
                    cn = body.position.subtract(cp).mult(1/dist);
                } else {
                    // Else at least present in the body center to body center
                    // direction if possible
                    Vec3d delta = body.position.subtract(world.position);
System.out.println("Deflect. cn:" + cn + "  edgeOrFaceHit:" + edgeOrFaceHit + "  body:" + body.position + "  static:" + world.position);                        
                    cn = toNormal(delta, delta.length());
                } 
                penetration = r1 - dist;
            }
                
            Contact<K, SimpleShape> contact = new Contact<>(body, world, cp, cn, penetration);
            contact.restitution = restitution;
            contact.friction = friction;
            results.newContact(contact);
        }
    }

    @Override   
    public void generateStaticCollisions( RigidBody<K, SimpleShape> body, StaticBody<K, SimpleShape>[] staticObjects, ContactListener<K, SimpleShape> results ) {
        for( StaticBody<K, SimpleShape> world : staticObjects ) {
            checkStaticContact(body, world, results);
        } 
    }

    @Override   
    public void generateBodyCollisions( RigidBody<K, SimpleShape> body, RigidBody<K, SimpleShape>[] inactiveObjects, ContactListener<K, SimpleShape> results ) {
        for( RigidBody<K, SimpleShape> sleeper : inactiveObjects ) {
            checkContact(body, sleeper, results);
        }
    }
 
    @Override   
    public void generateBodyCollisions( RigidBody<K, SimpleShape>[] bodies, ContactListener<K, SimpleShape> results ) {
        for( int i = 0; i < bodies.length; i++ ) {
            RigidBody<K, SimpleShape> b1 = bodies[i];
            
            for( int j = i + 1; j < bodies.length; j++ ) {
                RigidBody<K, SimpleShape> b2 = bodies[j];
                
                checkContact(b1, b2, results);
            }
        }
    }

    @Override
    public void generateStaticCollisions( RigidBody<K, SimpleShape> body, StaticBody<K, SimpleShape>[] staticObjects, 
                                          Predicate<? super StaticBody<K, SimpleShape>> bodyFilter, 
                                          ContactListener<K, SimpleShape> results ) {
        for( StaticBody<K, SimpleShape> world : staticObjects ) {
            if( bodyFilter.apply(world) ) {
                checkStaticContact(body, world, results);
            }
        } 
    }
    
    @Override
    public void generateBodyCollisions( RigidBody<K, SimpleShape> body, RigidBody<K, SimpleShape>[] inactiveObjects, 
                                        Predicate<? super RigidBody<K, SimpleShape>> bodyFilter, 
                                        ContactListener<K, SimpleShape> results ) {
        for( RigidBody<K, SimpleShape> sleeper : inactiveObjects ) {
            if( bodyFilter.apply(sleeper) ) {
                checkContact(body, sleeper, results);
            }
        }
    }

    protected void checkContact( RigidBody<K, SimpleShape> b1, RigidBody<K, SimpleShape> b2, ContactListener<K, SimpleShape> results ) {              
        double r1 = b1.shape.getMass().getRadius();
        double r2 = b2.shape.getMass().getRadius();
 
        double threshold = (r1 + r2) * (r1 + r2);
            
        double distSq = b1.position.distanceSq(b2.position);
        if( distSq > threshold ) {
            // No intersection
            return;
        }
    
        double dist = Math.sqrt(distSq);
 
        // Contact point is directly in the middle
        // No, dummy... that's only true if they are the same size.
        // Vec3d cp = b2.position.add(b1.position).mult(0.5);
        // Well, I mean technically it depends on whether you want the
        // cp on one of the surfaces or in between the surfaces, etc... but
        // a pure average is not right because for big sphere to small sphere
        // collisions it puts it way inside the big sphere.
        Vec3d cp;
        if( dist > 0 ) {
            // Contact point is down the vector between them but the radius amount
            // We put it on the surface of the second body arbitrarily.  The
            // first one is more likely to be a mob in a mob->static hit.
            // That's the way the normal points, anyway.
            Vec3d delta = b1.position.subtract(b2.position);
            cp = delta.multLocal(r2/dist).addLocal(b2.position);
        } else {
            // Else cp is just one of the positions
            cp = b1.position.clone();
        }
               
        // Contact normal points away from the static object
        // body1 contacts body2 so the normal is on body2... which in this case is the
        // world.
        Vec3d cn = toNormal(b1.position.subtract(b2.position), dist);
                
        double penetration = r1 - (dist - r2);
                
        Contact<K, SimpleShape> contact = new Contact<>(b1, b2, cp, cn, penetration);
        contact.restitution = restitution;
        contact.friction = friction;
        results.newContact(contact);                
    }

    @Override
    public void queryBodyHits( Rayd ray, RigidBody<K, SimpleShape>[] bodies, HitResults<K, SimpleShape> hits ) {
        // Not particularly hard to support... essentially just a ray distance
        // check.  I just don't have time today and there is not a convenient demo
        // to add a query test to. (Only simple shape demo doesn't have a cross-hair.)
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void queryStaticHits( Rayd ray, StaticBody<K, SimpleShape>[] staticObjects, HitResults<K, SimpleShape> hits ) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void queryWorldHits( Rayd ray, HitResults<K, SimpleShape> hits ) {
        throw new UnsupportedOperationException();
    }
}


