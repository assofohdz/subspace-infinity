/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Resolves contacts by accumulating the penetraction and velocity changes
 *  per object and then applying the sum.  This vastly improves the cases
 *  where objects are under multiple nearly-competing constraints since 
 *  resolving one contact doesn't push it further into another.  It's also more stable
 *  Because all of the contacts are handled at once based on the initial state
 *  rather than based on a state that changes after each contact is resolved.
 *
 *  <p>Accumulation is done by tracking the maximum and the minimum adjustments
 *  along each of the three coordinate axes.  When applied, these values are summed.</p>
 * 
 *  <p>A down side of this approach is that objects that are mutually constrained
 *  on all sides will more-or-less float in freefall because all of the constraint
 *  forces sum to near zero.  On the other hand, that object is still pushing out
 *  on those constraints and will hopefully resolve... assuming it is not under
 *  similar constraints and so on.</p>
 *
 *  <p>For a relatively simple approach it performs way better than the naive
 *  approach of resolving each contact independently... and that approach has all
 *  of the same issues anyway.</p> 
 *
 *  @author    Paul Speed
 */
public class TandemContactResolver<K, S extends AbstractShape> implements ContactResolver<K, S> {

    static Logger log = LoggerFactory.getLogger(TandemContactResolver.class);
 
    // Resolving joints with the rest of contacts was a nice idea but it
    // causes issues.  Joints become less stable and we have activation
    // problems (that may be solvable) but as it stands the other issues
    // make it not really worth investigating.  For example, unlike contacts
    // we can in theory carefully order our joints such things like chains
    // are resolved in a proper order that doesn't jitter. 
    protected boolean resolveJoints = true;
 
    public TandemContactResolver() {
    }
    
    @Override
    public void resolveContacts( List<Contact<K, S>> contacts, List<Joint<K, S>> joints, double step ) {
 
//if( true ) {
//    return;
//}    
        Map<RigidBody<K, S>, Accumulator> accumulators = new HashMap<>();
        
        // In theory, the basic steps go like:
        // 1) accumulate penetration-related position/rotation updates
        // 2) apply updates per-body
        // 3) calculate derived data per body
        // 4) accumulate velocity-related changes
        // 5) apply velocity related updates per body
        //
        // 1-3 we'll do in one pass, 4-5 we'll do in a second pass
        resolvePenetration(contacts, joints, step, accumulators);       
        resolveVelocity(contacts, joints, step, accumulators);        
    }

    protected void resolvePenetration( List<Contact<K, S>> contacts, List<Joint<K, S>> joints, double step,
                                       Map<RigidBody<K, S>, Accumulator> accumulators ) {
                                       
        // Some local workspace that we will reuse per contact
        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();
        Vec3d linear2 = new Vec3d();
        Vec3d angular2 = new Vec3d();
        
        for( Contact<K, S> c : contacts ) {
//System.out.println("Contact:" + c);

            // The contact may have been disabled and we can save a bunch of time
            if( !c.isEnabled() ) {
                continue;
            }
        
            c.matchLocalTemperature();
 
            // We have to check the contact's temperature and not
            // one of the body temperatures because in the velocity loop
            // the body temperatures may have been changed from subsequence
            // contact's 'matchLocalTemperature' calls.  There is not really
            // a good way to consistently propagate temperature but we do
            // our best.
            double localTemperature = c.localTemperature;
            if( RigidBody.isCold(localTemperature) ) {
                continue;
            }
  
            c.calculateInternals(step * localTemperature);
            
            // See what the position change should be for this contact
            // as applied to both bodies.
            c.calculatePositionChange(linear1, linear2, angular1, angular2, c.penetration);
            
            if( Double.isNaN(linear1.x) ) {
                log.error("Contact produced NaN position adjustment:" + c);
            }

            getAccumulator(c.body1, accumulators).accumulate(linear1, angular1);
            getAccumulator(c.getBody2(), accumulators).accumulate(linear2, angular2);            
        }
 
        if( resolveJoints ) {       
            for( Joint<K, S> joint : joints ) {
                if( joint.isSleepy() ) {
                    continue;
                }

                joint.calculateInternals(step);
                
                joint.calculatePositionChange(linear1, linear2, angular1, angular2);
                
                if( Double.isNaN(linear1.x) ) {
                    log.error("Joint produced NaN position adjustment:" + joint);
                }
                
                getAccumulator(joint.getMainBody(), accumulators).accumulate(linear1, angular1);            
                getAccumulator(joint.getAltBody(), accumulators).accumulate(linear2, angular2);
            }
        }
        
        // Now that we know, go through all of the bodies and apply
        // their accumulated adjustments
        Vec3d lin = linear1.set(0, 0, 0); // might as well reuse the temp var from above
        Vec3d ang = angular1.set(0, 0, 0);
 
        for( Map.Entry<RigidBody<K, S>, Accumulator> e : accumulators.entrySet() ) {
            RigidBody b = e.getKey();
            Accumulator acc = e.getValue();
            
            // Figure out the accumulated position and rotation change                        
            Vec3d l = acc.getLinear(lin);
            Vec3d a = acc.getAngular(ang);
            acc.clear();
 
            boolean check = b.position.isNaN();            
            // Apply the accumulated position and rotation changes to the 
            // body            
            b.position.addLocal(l);
                        
            if( !check && b.position.isNaN() ) {
                log.error("Body went NaN linear:" + l);               
            }
            b.orientation.addScaledVectorLocal(a, 1.0);
            b.calculateDerivedData();                         
        }                                       
    }

    protected void resolveVelocity( List<Contact<K, S>> contacts, List<Joint<K, S>> joints, double step,
                                    Map<RigidBody<K, S>, Accumulator> accumulators ) {
                                    
        // Some local workspace that we will reuse per contact
        Vec3d vDelta1 = new Vec3d();
        Vec3d rotDelta1 = new Vec3d();
        Vec3d vDelta2 = new Vec3d();
        Vec3d rotDelta2 = new Vec3d();
 
        // Now calculate the velocity and rotation changes
        // given the latest info           
        for( Contact<K, S> c : contacts ) {
        
            // We have to check the contact's temperature and not
            // one of the body temperatures because in the velocity loop
            // the body temperatures may have been changed from subsequence
            // contact's 'matchLocalTemperature' calls.  There is not really
            // a good way to consistently propagate temperature but we do
            // our best.
            double localTemperature = c.localTemperature;
            if( RigidBody.isCold(localTemperature) ) {
                continue;
            }
 
            c.calculateVelocityChange(vDelta1, vDelta2, rotDelta1, rotDelta2);

            if( vDelta1.isNaN() ) {
                System.out.println("NaN velocity delta 1 for contact:" + c);
            }
            if( vDelta2.isNaN() ) {
                System.out.println("NaN velocity delta 2 for contact:" + c);
            }

            getAccumulator(c.body1, accumulators).accumulate(vDelta1, rotDelta1);       
            getAccumulator(c.getBody2(), accumulators).accumulate(vDelta2, rotDelta2);       
        }

        if( resolveJoints ) {
            for( Joint<K, S> joint : joints ) {
                if( joint.isSleepy() ) {
                    continue;
                }
                
                joint.calculateVelocityChange(vDelta1, vDelta2, rotDelta1, rotDelta2);
                
                if( vDelta1.isNaN() ) {
                    System.out.println("NaN velocity delta 1 for joint:" + joint);
                }
                if( vDelta2.isNaN() ) {
                    System.out.println("NaN velocity delta 2 for joint:" + joint);
                }
                
                getAccumulator(joint.getMainBody(), accumulators).accumulate(vDelta1, rotDelta1);
                getAccumulator(joint.getAltBody(), accumulators).accumulate(vDelta2, rotDelta2);
            }
        }
        
        // Now that we know, go through all of the bodies and apply
        // their accumulated adjustments
        Vec3d lin = new Vec3d();
        Vec3d ang = new Vec3d();
        for( Map.Entry<RigidBody<K, S>, Accumulator> e : accumulators.entrySet() ) {
            RigidBody<K, S> b = e.getKey();
            Accumulator acc = e.getValue();
            
            // Figure out the accumulated position and rotation change                        
            Vec3d l = acc.getLinear(lin);
            Vec3d a = acc.getAngular(ang);
            acc.clear();                         
 
//if( b.id.equals(10) ) {
//    log.debug("Adding linear velocity:" + l);
//} 
            // Apply the velocity changes to the body
            b.addLinearVelocity(l);
//if( b.id.equals(10) ) {
//    log.debug("Velocity after:" + b.getLinearVelocity());
//} 
            b.addRotationalVelocity(a);
        }
                                    
    }
 
    private static Accumulator nullAccumulator = new Accumulator();
    
    /**
     *  Retrieves an acculuator for the specified body, creating one if necessary.  If
     *  the body is null then an accumulator is still returned but is generally ignored during
     *  final resolution.
     */   
    private final Accumulator getAccumulator( RigidBody<K, S> body, Map<RigidBody<K, S>, Accumulator> accumulators ) {
        if( body == null ) {
            return nullAccumulator;
        }
            
        Accumulator result = accumulators.get(body);
        if( result == null ) {
            result = new Accumulator();
            accumulators.put(body, result);
        }
        return result; 
    }
     
    /**
     *  Accumulates per-body results of contact resolution.  This is reused
     *  for both position and velocity accumulation in their separate passes.
     */     
    protected static class Accumulator {
        Vec3d linMin = new Vec3d();
        Vec3d linMax = new Vec3d();
        Vec3d angMin = new Vec3d();
        Vec3d angMax = new Vec3d();
        
        public void accumulate( Vec3d lin, Vec3d ang ) {
            linMin.minLocal(lin);
            linMax.maxLocal(lin);
            angMin.minLocal(ang);
            angMax.maxLocal(ang);
        }
        
        public final Vec3d getLinear( Vec3d store ) {
            store.x = linMin.x + linMax.x;
            store.y = linMin.y + linMax.y;
            store.z = linMin.z + linMax.z;
            return store;           
        }
        
        public final Vec3d getAngular( Vec3d store ) {
            store.x = angMin.x + angMax.x;
            store.y = angMin.y + angMax.y;
            store.z = angMin.z + angMax.z;
            return store;           
        }
        
        public final void clear() {
            linMin.set(0,0,0);
            linMax.set(0,0,0);
            angMin.set(0,0,0);
            angMax.set(0,0,0);
        }
    }    
}

/*
    

    protected void resolveVelocity( List<Contact> contacts, double t, 
                                    Map<RigidBody,Accumulator> accumulators )
    {                                    
        Vec3d vDelta1 = new Vec3d();
        Vec3d rotDelta1 = new Vec3d();
        Vec3d vDelta2 = new Vec3d();
        Vec3d rotDelta2 = new Vec3d();
 
//Set<RigidBody> debug = new HashSet<RigidBody>();
//System.out.println( "resolveVelocity()" );
        // Now calculate the velocity and rotation changes
        // given the latest info           
        for( Contact c : contacts )
            {
            if( RigidBody.isCold(c.localTemperature) )
                continue;
 
            c.calculateVelocityChange( vDelta1, vDelta2, 
                                       rotDelta1, rotDelta2 );

            getAccumulator(c.body1, accumulators).accumulate(vDelta1, rotDelta1);       
            getAccumulator(c.body2, accumulators).accumulate(vDelta2, rotDelta2);       
            }

        // Now that we know, go through all of the bodies and apply
        // their accumulated adjustments
        Vec3d lin = new Vec3d();
        Vec3d ang = new Vec3d();
        for( Map.Entry<RigidBody,Accumulator> e : accumulators.entrySet() )
            {
            RigidBody b = e.getKey();
            Accumulator acc = e.getValue();
            
            // Figure out the accumulated position and rotation change                        
            Vec3d l = acc.getLinear(lin);
            Vec3d a = acc.getAngular(ang);
            acc.clear();                         
 
//if( debug.contains(b) )   
//System.out.println( "Applying contact velocity change:" + b.getCollisionMesh().getId() + "  at:" +  b.getCollisionMesh().position );                                  
//System.out.println( "vel resolution   l:" + l + "   a:" + a );
            // Apply the velocity changes to the body
            b.addVelocity( l );
if( b.debugOn ) {
    log.debug("added:" + l);
}

            // The problem is that the angular change hasn't been through
            // the inertia tensor.  I don't know if this is right or not
            // but something has to be done.  One down side is that when
            // we changed velocity based on being able to rotate, we didn't
            // take this into account necessarily.
            // All not true.
//System.out.println( "accel change before:" + a );            
//System.out.println( " inertiaTensorWorld:" + b.getInertiaTensorWorld() );            
            //a = b.getInertiaTensorWorld().mult(a);
//System.out.println( "                    after:" + a );            
            
            b.addRotation( a );
//System.out.println( "Body v:" + b.getVelocity() );            
            }
    }            
 
*/ 


