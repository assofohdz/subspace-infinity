/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import com.google.common.base.MoreObjects;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class RigidBody<K, S extends AbstractShape> extends AbstractBody<K, S> {

    public static final double DEFAULT_LINEAR_DAMPING = 0.9;
    public static final double DEFAULT_ANGULAR_DAMPING = 0.8;
    // Higher dampening means more energy is retained

    static Logger log = LoggerFactory.getLogger(RigidBody.class);

    public long lastUpdateFrame;

    private AaBBox bounds = new AaBBox();

    private Vec3d linAccel = new Vec3d();
    private Vec3d rotAccel = new Vec3d();

    private Vec3d linVelocity = new Vec3d();
    private Vec3d rotVelocity = new Vec3d();

    private Vec3d forces = new Vec3d();
    private Vec3d torques = new Vec3d();

    private Vec3d lastFrameAccel = new Vec3d();
    private Vec3d lastFrameLinVel = new Vec3d();
    private Vec3d lastFrameRotVel = new Vec3d();

    // Derived from the position and rotation
    private Matrix4d transform = new Matrix4d();

    // Derived from the world transform and the shapes inverseInertiaTensor
    private Matrix3d inverseInertiaTensorWorld = new Matrix3d();

    private double linearDamping = DEFAULT_LINEAR_DAMPING;
    private double angularDamping = DEFAULT_ANGULAR_DAMPING;

    private AnnealingFunction annealing = DefaultAnnealingFunction.GLOBAL_ANNEALING;

    private static final double SLEEP_EPSILON = 0.01;
    //private static final double WAKING_TEMPERATURE = 0.1;

    private double temperature = 1.0;

    private int contactCount;

    // TODO: make invMass private again once we're done messing with joints
    public double inverseMass; // cached from the shape

    /**
     *  An optional control driver associated with a RigidBody.  This will
     *  be updated every frame to add forces, adjust velocity, etc. for a body.
     *  Note: if the object should stay awake always then it is up to the driver
     *  to wake it up.  Else the sleepy object is available for unloading just
     *  like any other sleepy body.
     */
    private ControlDriver<K,S> driver;

    public RigidBody() {
        super();
    }

    public RigidBody( K id, S shape ) {
        super(id, shape);
        this.inverseMass = shape.getMass().getInverseMass();
    }

    public RigidBody( K id, S shape, Vec3d position, Quatd orientation ) {
        super(id, shape, position, orientation);
        this.inverseMass = shape.getMass().getInverseMass();
    }

    public final AaBBox getWorldBounds() {
        return bounds;
    }

    /**
     *  Returns true if the object's temperature is below the sleeping
     *  threshold.
     */
    public boolean isSleepy() {
        //return temperature < SLEEP_EPSILON;
        return annealing.isCold(temperature);
    }

    /**
     *  Returns true if the specified temperature would be considered
     *  "sleepy" if it were the object's temperature.
     */
    public static boolean isCold( double temperature ) {
        // TODO: this method is not right and should be replaced where called
        return temperature < SLEEP_EPSILON;
    }

    /**
     *  Returns a temperature of the object representing its kinetic energy
     *  as a sort of simulated annealing.  An object that is slowing will
     *  also cool which in turn will slow its time step making micro-calculations
     *  more accurate.  Objects in motion will tend to heat up ensuring that
     *  they move at accurate speeds until they begin to slow down and cool
     *  again.  This is essentially to help deal with oscillation effects that
     *  happen with fixed step sizes.  If a counter-contact motion is small enough
     *  that it would oscillate against its contact point then it is also small
     *  enough that the object will cool.  As the object cools, each frame is actually
     *  effectively calculating a smaller time step and helping the object zero in
     *  on the balance point.  If more accurate calculations then lead to larger
     *  forces (say it slips off the edge of a cliff) then the temperature will heat
     *  up rapidly and the object will go back to full speed.
     */
    public double getTemperature() {

        // To decrease volatility we will reduce the temperature
        // when the contact count is high.  It's a bit arbitrary
        // at the moment.
        //if( contactCount > 10 ) {
        // Because it's arbitrary then that means if we have higher
        // resolution objects in general then we will need a higher value
        // here... clearly this "isn't right".  FIXME: but I don't know
        // what the fix is, really.
        if( contactCount > 50 ) {
            if( temperature > 0.25 ) {
                return temperature * 0.5;
            }
        }

        return temperature;
    }

    // TODO: the problem is that forcing a temperature in from outside,
    // that might be based on the result of getTemperature(), is ignoring
    // the contact counts.
    protected void setTemperature( double t ) {
        this.temperature = t;
    }

    public Vec3d getLastFrameAcceleration() {
        return lastFrameAccel;
    }

    /**
     *  Calculates the internal derived data such as the world transform
     *  and related fields.  Usually this is called automatically during integrate()
     *  but can be called manually if accurate local to world transforms are
     *  needed prior to integration.
     */
    public final void calculateDerivedData() {
        orientation.normalizeLocal();
        transform.setTransform(position, orientation.toRotationMatrix());

        transformInertiaTensor(inverseInertiaTensorWorld,
                               shape.getMass().getInverseMassTensor(),
                               transform);

        // FIXME: this presumes that the bounds center is the object's position
        //        which is only true at the moment.  It would be better to get the
        //        original local AaBBox from the shape and then let the shape
        //        tell us what the new center should be.
        //bounds.setCenter(position);
        // Fixing it.
        // The shape now keeps the Cog-relative min/max so we will apply those
        // to the AaBBox relative to position.
        AaBBox cb = shape.getCogBounds();
        Vec3d min = cb.getMin();
        Vec3d max = cb.getMax();
        bounds.getMin().set(position.x + min.x, position.y + min.y, position.z + min.z);
        bounds.getMax().set(position.x + max.x, position.y + max.y, position.z + max.z);
    }

    public Matrix3d getInverseInertiaTensorWorld() {
        return inverseInertiaTensorWorld;
    }

    public double getInverseMass() {
        return inverseMass;
    }

    /**
     *  Increments a counter that tracks how many contacts this body was involved
     *  in during this frame.
     */
    public final void incrementContactCount() {
        contactCount++;
    }

    /**
     *  Decrements a counter that tracks how many contacts this body was involved
     *  in during this frame.  This is used by the Contact object when an end
     *  is disabled.
     */
    public final void decrementContactCount() {
        contactCount--;
    }

    /**
     *  Clears the accumulated forces and torques.  This is generally called
     *  at the end of the integrate() method but can be called manually if it
     *  is necessary to clear active forces (for example, to force-clear the
     *  contact generated forces for some reason.)
     */
    public final void clearAccumulators() {
        forces.set(0, 0, 0);
        torques.set(0, 0, 0);
        contactCount = 0;
    }

    public void teleport( Vec3d loc, Quatd orient ) {
        if( loc != null ) {
            this.position.set(loc);
        }
        if( orient != null ) {
            this.orientation.set(orient);
        }

        // Normalize the orientation, update the combined local to world
        // transforms, etc..
        calculateDerivedData();
    }

    public void morph( S shape ) {
        setShape(shape);
        this.inverseMass = shape.getMass().getInverseMass();

        // Just in case... I think integrate() relies on this information being
        // current before integration.
        calculateDerivedData();
    }

    public void updateDriver( long frameTime, double tpf ) {
        if( driver != null ) {
            driver.update(frameTime, tpf);
        }
    }

    public void setControlDriver( ControlDriver<K, S> driver ) {
        if( this.driver != null ) {
            this.driver.terminate(this);
        }
        this.driver = driver;
        if( this.driver != null ) {
            this.driver.initialize(this);
        }
    }

    public final ControlDriver<K, S> getControlDriver() {
        return driver;
    }

    /**
     *  Moves the object based on the specifie time step and the current
     *  accleration, velocity, forces, etc..
     */
    public final void integrate( double t ) {

        if( inverseMass == 0 ) {
            // Special indicator that we should not integrate it
            return;
        }
//boolean debug = id.equals(10);
boolean debug = false;
if( debug ) {
    log.debug("pos before:" + position);
}
//log.info("Wobble: pos before:" + position);
        boolean check;

        // 'temper' the time by the current temperature.  Colder
        // objects will effectively slow down as they get smaller time
        // steps.  This also makes the math more accurate.
        t = t * getTemperature();

        // Save this frame's acceleration.  This is used
        // by contact resolution to unwind how much of the current
        // velocity was related to the previous frame's acceleration.
        // As I recall, it's a sort of shot-in-the-dark attempt to
        // ignore acceleration due to small penetrations.
        //
        // It's also convenient because we can use it as our workspace
        // without messing up the original acceleration which is often
        // held over from frame to frame.
        lastFrameAccel.set(linAccel);

        Vec3d tempLinAccel = lastFrameAccel;

        // Add the accumulated forces to the linear acceleration we will
        // use.  F = MA  So A = F/M... 1/M = inverseMass... it's almost
        // like we knew what we were doing when we kept that instead of mass.
        tempLinAccel.addScaledVectorLocal(forces, inverseMass);

        // Transform the torques to local rotational acceleration.
        Vec3d tempRotAccel = inverseInertiaTensorWorld.mult(torques);

        // Combine those transformed torques with any existing rotational
        // acceleration.  Note: rotAccel += tempRotAccel is no different than
        // tempRotAccel += rotAccel except that we get to use tempRotAccel as
        // our workspace in the latter case... even if it feels a bit 'backwards'.
        tempRotAccel.addLocal(rotAccel);

        check = linVelocity.isNaN();

        // Integrate velocity
        linVelocity.addScaledVectorLocal(tempLinAccel, t);
        rotVelocity.addScaledVectorLocal(tempRotAccel, t);

        if( !check && linVelocity.isNaN() ) {
            System.out.println("Velocity went NaN for body:" + id + " accel:" + linAccel + " local t:" + t);
        }

        // Apply the damping parameters
        // Note: these will be constant when t is constant but
        //       we might vary t by object someday.  I don't know how
        //       expensive pow() is anymore, though.  May not be
        //       worth mentioning.
        linVelocity.multLocal(Math.pow(linearDamping, t));
        rotVelocity.multLocal(Math.pow(angularDamping, t));

        check = position.isNaN();

        // Now integrate the position and orientation... the real stuff.
        position.addScaledVectorLocal(linVelocity, t);
        orientation.addScaledVectorLocal(rotVelocity, t);

        if( !check && position.isNaN() ) {
            System.out.println("Position went NaN for body:" + id + " velocity:" + linVelocity + " local t:" + t);
        }

        // Normalize the orientation, update the combined local to world
        // transforms, etc..
        calculateDerivedData();

        temperature = annealing.calculateTemperature(getTemperature(),
                                                     linVelocity, rotVelocity, lastFrameAccel,
                                                     lastFrameLinVel, lastFrameRotVel,
                                                     t);
        lastFrameLinVel.set(linVelocity);
        lastFrameRotVel.set(rotVelocity);

        // Clear the external forces and torques for next time
        clearAccumulators();

if( debug ) {
    log.debug("pos after:" + position);
}
//log.info("Wobble: pos after:" + position + "  up:" + orientation.mult(new Vec3d(0, 1, 0))
//                + "  temp:" + getTemperature()
//                + "  lin vel:" + linVelocity + " rot vel:" + rotVelocity);
    }


    public void setDamping( double linear, double angular ) {
        this.linearDamping = linear;
        this.angularDamping = angular;
    }

    public void setLinearDamping( double linear ) {
        this.linearDamping = linear;
    }

    public double getLinearDamping() {
        return linearDamping;
    }

    public void setAngularDamping( double angular ) {
        this.angularDamping = angular;
    }

    public double getAngularDamping() {
        return angularDamping;
    }

    public void setRotationalAcceleration( double x, double y, double z ) {
        this.rotAccel.set(x, y, z);
    }

    public void setLinearAcceleration( Vec3d a ) {
        this.linAccel.set(a);
    }

    public void setLinearAcceleration( double x, double y, double z ) {
        this.linAccel.set(x,y,z);
    }

    public Vec3d getLinearAcceleration() {
        return linAccel;
    }

    public void setLinearVelocity( Vec3d v ) {
        this.linVelocity.set(v);
    }

    public void setVelocity( double x, double y, double z ) {
        this.linVelocity.set(x,y,z);
    }

    public Vec3d getLinearVelocity() {
        return linVelocity;
    }

    public void addLinearVelocity( Vec3d v ) {
        if( v.isNaN() ) {
            throw new IllegalArgumentException("Cannot add a NaN velocity:" + v + "  body:" + id);
        }
        linVelocity.addLocal(v);
    }

    public void addLinearVelocity( double x, double y, double z ) {
        linVelocity.addLocal(x,y,z);
    }

    public void setRotationalVelocity( Vec3d rotation ) {
        this.rotVelocity.set(rotation);
    }

    public void setRotationalVelocity( double x, double y, double z ) {
        this.rotVelocity.set(x,y,z);
    }

    public Vec3d getRotationalVelocity() {
        return rotVelocity;
    }

    public void addRotationalVelocity( Vec3d delta ) {
        rotVelocity.addLocal(delta);
    }

    /**
     *  Transforms a point from object space to world space.
     */
    public final Vec3d localToWorld( Vec3d point ) {
        return transform.mult(point);
    }

    /**
     *  If the temperature has put this object to sleep then the
     *  temperature is given a boost to wake the object up.
     */
    public void wakeUp() {
        if( isSleepy() ) {
            temperature = annealing.getWakingTemperature();
        }
    }

    public void wakeUp( boolean fully ) {
        temperature = 1;
    }

    public void makeSleepy() {
        temperature = 0;
    }

    public void makeSleepy( double scale ) {
        temperature *= scale;
    }

    /**
     *  Adds a force to this body at its center of mass.
     */
    public void addForce( Vec3d f ) {
        forces.addLocal( f );

        // FIXME: Temperature change should probably be based on the amount of force applied, really
        wakeUp();
    }

    /**
     *  Adds a force pushing at the specified location in local
     *  object space.
     */
    public void addForceAtBodyPoint( Vec3d f, Vec3d p ) {
        Vec3d pt = localToWorld(p);
        addForceAtPoint( f, pt );
    }

    /**
     *  Adds a force pushing at the specified location in world space.
     */
    public void addForceAtPoint( Vec3d f, Vec3d p ) {

        // Add the raw force to the linear forces against
        // the center of mass
        forces.addLocal(f);

        // This is a bit of magic to transfer the push force into
        // a torque.
        Vec3d pt = p.subtract(position);
        torques.addLocal(pt.cross(f));

        // FIXME: Temperature change should probably be based on the amount of force applied, really
        wakeUp();
    }

    /**
     *  Adds a force pushing at the specified location in local
     *  object space.
     */
    public void addForceAtBodyPoint( Vec3d f, double rotDamping, Vec3d p ) {
        Vec3d pt = localToWorld(p);
        addForceAtPoint(f, rotDamping, pt);
    }

    /**
     *  Adds a force pushing at the specified location in world space.
     */
    public void addForceAtPoint( Vec3d f, double rotDamping, Vec3d p ) {

        // Add the raw force to the linear forces against
        // the center of mass
        forces.addLocal(f);

        // This is a bit of magic to transfer the push force into
        // a torque.
        Vec3d pt = p.subtract(position);
        torques.addLocal(pt.cross(f.mult(rotDamping)));

        // FIXME: Temperature change should probably be based on the amount of force applied, really
        wakeUp();
    }

    /**
     *  Returns the forces accumulated so far.
     */
    public Vec3d getForces() {
        return forces;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("RigidBody")
                .add("id", id)
                .add("position", position)
                .add("orientation", orientation)
                .add("linearVelocity", linVelocity)
                .add("rotationalVelocity", rotVelocity)
                .add("rawTemperature", temperature)
                .add("temperature", getTemperature())
                .add("shape", shape)
                .add("driver", driver)
                .toString();
    }


    /*
        Ugly utility method copied directly from the book.  Not at all explained
        other than that it was generated.

        m4f:            m3f
        0   0,0         0   0,0
        1   0,1         1   0,1
        2   0,2         2   0,2
        3   0,3         3   1,0
        4   1,0         4   1,1
        5   1,1         5   1,2
        6   1,2         6   2,0
        7   1,3         7   2,1
        8   2,0         8   2,2
        9   2,1
        10  2,2
        11  2,3
        ----12  3,0
        ----14  3,1
        ----15  3,2
        ----16  3,3
    */
    private static void transformInertiaTensor( Matrix3d iitWorld, Matrix3d iitBody,
                                                Matrix4d rotmat ) {
        double t4 = rotmat.m00 * iitBody.m00
                    + rotmat.m01 * iitBody.m10
                    + rotmat.m02 * iitBody.m20;

        double t9 = rotmat.m00 * iitBody.m01
                    + rotmat.m01 * iitBody.m11
                    + rotmat.m02 * iitBody.m21;

        double t14 = rotmat.m00 * iitBody.m02
                    + rotmat.m01 * iitBody.m12
                    + rotmat.m02 * iitBody.m22;

        double t28 = rotmat.m10 * iitBody.m00
                    + rotmat.m11 * iitBody.m10
                    + rotmat.m12 * iitBody.m20;
        double t33 = rotmat.m10 * iitBody.m01
                    + rotmat.m11 * iitBody.m11
                    + rotmat.m12 * iitBody.m21;
        double t38 = rotmat.m10 * iitBody.m02
                    + rotmat.m11 * iitBody.m12
                    + rotmat.m12 * iitBody.m22;

        double t52 = rotmat.m20 * iitBody.m00
                    + rotmat.m21 * iitBody.m10
                    + rotmat.m22 * iitBody.m20;
        double t57 = rotmat.m20 * iitBody.m01
                    + rotmat.m21 * iitBody.m11
                    + rotmat.m22 * iitBody.m21;
        double t62 = rotmat.m20 * iitBody.m02
                    + rotmat.m21 * iitBody.m12
                    + rotmat.m22 * iitBody.m22;

        iitWorld.m00 =  t4 * rotmat.m00
                         + t9 * rotmat.m01
                         + t14 * rotmat.m02;
        iitWorld.m01 =  t4 * rotmat.m10
                         + t9 * rotmat.m11
                         + t14 * rotmat.m12;
        iitWorld.m02 =  t4 * rotmat.m20
                         + t9 * rotmat.m21
                         + t14 * rotmat.m22;

        iitWorld.m10 =  t28 * rotmat.m00
                         + t33 * rotmat.m01
                         + t38 * rotmat.m02;
        iitWorld.m11 =  t28 * rotmat.m10
                         + t33 * rotmat.m11
                         + t38 * rotmat.m12;
        iitWorld.m12 =  t28 * rotmat.m20
                         + t33 * rotmat.m21
                         + t38 * rotmat.m22;

        iitWorld.m20 =  t52 * rotmat.m00
                         + t57 * rotmat.m01
                         + t62 * rotmat.m02;
        iitWorld.m21 =  t52 * rotmat.m10
                         + t57 * rotmat.m11
                         + t62 * rotmat.m12;
        iitWorld.m22 =  t52 * rotmat.m20
                         + t57 * rotmat.m21
                         + t62 * rotmat.m22;
    }
}


