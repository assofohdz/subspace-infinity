/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys.simple;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;
import com.simsilica.mphys.*;

/**
 *  A simple shape for the SimpleCollisionSystem that just uses the
 *  shape radius to do spherical collisions.  It also supports axis-aligned cubes
 *  as static objects.
 *
 *  @author    Paul Speed
 */
public class SimpleShape extends AbstractShape {

    public enum Type { Cube, Sphere };
    
    private Type type;

    public SimpleShape( Type type, double boundsRadius, BodyMass mass ) {
        super(new Vec3d(), boundsRadius, mass);
        this.type = type;
    }
 
    public static SimpleShape createCube( double radius ) {
        return new SimpleShape(Type.Cube, radius, BodyMass.createSimple(0, null, radius));
    }
    
    public static SimpleShape createSphere( double radius, double mass ) {
        return new SimpleShape(Type.Sphere, radius, BodyMass.createSolidSphere(mass, radius, null));
    }
    
    public Type getType() {
        return type;
    }
    
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .omitNullValues()
                .add("type", type)
                .add("boundsCenter", getBoundsCenter())
                .add("boundsRadius", getBoundsRadius())
                .add("bodyMass", getMass())
                .toString();
    }

}
