/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import com.simsilica.mathd.*;

/**
 *  A default control driver that just makes sure an object stays
 *  upright.
 *
 *  @author    Paul Speed
 */
public class UprightDriver<K, S extends AbstractShape> extends AbstractControlDriver<K,S> {

    // Allows for an UprightDriver that tries to dampen activity.
    private double sleepScale;
    private double[] angles = new double[3];

    public UprightDriver() {
        this(1.0);
    }

    public UprightDriver( double sleepScale ) {
        this.sleepScale = sleepScale;
    }

    public void update( long frameTime, double step ) {

        // Kill any non-yaw orientation
        RigidBody<K, S> body = getBody();
        body.orientation.toAngles(angles);
        if( angles[0] != 0 || angles[2] != 0 ) {
            angles[0] = 0;
            angles[2] = 0;
            body.orientation.fromAngles(angles);
        }

        Vec3d rot = body.getRotationalVelocity();
        if( rot.x != 0 || rot.z != 0 ) {
            rot.x = 0;
            //rot.y *= 0.95; // Let's see if we can dampen the spinning
            rot.z = 0;

            // Don't really need to set it back but just in case
            body.setRotationalVelocity(rot);
        }

        if( sleepScale < 1.0 ) {
            body.makeSleepy(sleepScale);
        }
//System.out.println("******** UprightDriver body temp:" + body.getTemperature());
//body.setTemperature(1);
    }
}


