/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.List;

import com.google.common.base.Predicate;

import com.simsilica.mathd.Rayd;

/**
 *  Performs collisions detection between sets of objects
 *  and generates contacts.
 *
 *  @author    Paul Speed
 */
public interface CollisionSystem<K, S extends AbstractShape> {

    public void generateWorldCollisions( RigidBody<K, S> body, ContactListener<K, S> results );
 
    public void generateStaticCollisions( RigidBody<K, S> body, StaticBody<K, S>[] staticObjects, ContactListener<K, S> results );
    
    public void generateBodyCollisions( RigidBody<K, S> body, RigidBody<K, S>[] inactiveObjects, ContactListener<K, S> results );
    
    public void generateBodyCollisions( RigidBody<K, S>[] bodies, ContactListener<K, S> results );

    public void generateStaticCollisions( RigidBody<K, S> body, StaticBody<K, S>[] staticObjects, 
                                          Predicate<? super StaticBody<K, S>> bodyFilter, 
                                          ContactListener<K, S> results );
    
    public void generateBodyCollisions( RigidBody<K, S> body, RigidBody<K, S>[] inactiveObjects, 
                                        Predicate<? super RigidBody<K, S>> bodyFilter, 
                                        ContactListener<K, S> results );
    
    public void queryWorldHits( Rayd ray, HitResults<K, S> hits );
    public void queryBodyHits( Rayd ray, RigidBody<K, S>[] bodies, HitResults<K, S> hits );
    public void queryStaticHits( Rayd ray, StaticBody<K, S>[] staticObjects, HitResults<K, S> hits );
}


