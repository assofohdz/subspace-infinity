/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

/**
 *  Represents the minimum collision mesh and mass properties of an object,
 *  whether static or mobile.  For purely static objects, it is ok for
 *  mass information to be empty or blank but often shapes will be shared
 *  between mobile and static bodies.  Different physics configurations
 *  will choose to subclass Shape to provide more information that is used
 *  by a custom CollisionSystem.
 *
 *  <p><b>Origin and related offsets:</b> the origin of the shape is at
 *  0,0,0 in local space.  It's the local space's origin.  That should be no
 *  surprise.</p>
 *
 *  <p>The boundsCenter is then the volumetric center of the object such
 *  that boundsRadius makes sense.  For example, if the shape was a person
 *  and the shape's origin is between the feet then the boundsCenter would
 *  be somewhere near their waist.</p>
 *
 *  <p>The BodyMass center of gravity (cog) is the center of mass (or 'centroid')
 *  of the shape relative to the shape's origin.  This may or may not be
 *  similar to the boundsCenter as it's entirely related to the mass distribution.
 *  For example, if the person in the above example were wearing lead boots
 *  then the cog would be considerably lower than the boundsCenter.</p>
 *
 *  <p>Now, in the physics space, objects are positioned according to their center
 *  of mass.  So the actual physics body-relative origin is -cog.  The actual
 *  physics body-relative boundsCenter is then -cog + boundsCenter.</p>
 *
 *  <p>Note: none of the current collision systems actually use the bounding
 *  shape for anything... they all defer to the BodyMass.  This whole thing
 *  should probably be revisited.</p>
 *
 *  @author    Paul Speed
 */
public abstract class AbstractShape {
    private static Logger log = LoggerFactory.getLogger(AbstractShape.class);

    private Vec3d boundsCenter;
    private double boundsRadius;
    private BodyMass mass;
    private AaBBox cogBounds = new AaBBox();

    /**
     *  Uses for subclasses that will derive their shape bounds and body mass
     *  after construction.
     */
    protected AbstractShape() {
    }

    protected AbstractShape( Vec3d boundsCenter, double boundsRadius, BodyMass mass ) {
        if( boundsCenter == null ) {
            throw new IllegalArgumentException("boundsCenter cannot be null");
        }
        if( mass == null ) {
            throw new IllegalArgumentException("BodyMass cannot be null");
        }
        if( mass.getCog() == null ) {
            throw new IllegalArgumentException("BodyMass has no CoG");
        }
        this.boundsCenter = boundsCenter;
        this.boundsRadius = boundsRadius;
        this.mass = mass;
        calculateCogBounds();
    }

    private void calculateCogBounds() {
        // Calculate the min/max relative to the center of gravity.
        //  min = -cog + shapeCenter - radius
        //  max = -cog + shapeCenter + radius
        // AaBBox is already doing some of that for us with a single point and radius.
        cogBounds.setForRadius(boundsCenter.subtract(mass.getCog()), boundsRadius);
    }

    // TODO: potentially refactor how this is done because some things like MBlockShape
    // will have the same bounds center as the mass's Cog, same bounds radius as the mass,
    // etc... and in those cases, cogBounds is even easier to deal with.
    // Perhaps don't require separate ones and leave the getters abstract or something.
    // Then setBoundsInfo() could potentially go away. -pspeed:20200725
    protected void setBoundsInfo( Vec3d boundsCenter, double boundsRadius, BodyMass mass ) {
        if( boundsCenter == null ) {
            throw new IllegalArgumentException("boundsCenter cannot be null");
        }
        if( mass == null ) {
            throw new IllegalArgumentException("BodyMass cannot be null");
        }
        if( mass.getCog() == null ) {
            throw new IllegalArgumentException("BodyMass has no CoG");
        }
        this.boundsCenter = boundsCenter;
        this.boundsRadius = boundsRadius;
        this.mass = mass;
        calculateCogBounds();
    }

    /**
     *  Can be overridden by subclasses to provide custom bounds info recalculation.
     *  Default implementation does nothing but this will be called in this class for anything
     *  that uses boundsCenter, boundsRadius, etc..
     */
    protected void validateBoundsInfo() {
    }

    /**
     *  For shapes that support runtime changes, this can be used to indicate
     *  that the shape has changed in some significant way.
     */
    public long getVersion() {
        return 0;
    }

    /**
     *  Returns the volumetric center of the shape relative to the shape's own
     *  origin.  For shapes that are centered over the origin then this is 0,0,0.
     */
    public final Vec3d getBoundsCenter() {
        validateBoundsInfo();
        return boundsCenter;
    }

    /**
     *  Returns the maximum containing radius for the shape as centered around
     *  the shape's volumetric center (returned by getBoundsCenter()).
     */
    public final double getBoundsRadius() {
        validateBoundsInfo();
        return boundsRadius;
    }

    /**
     *  Returns the mass-related properties of this shape or null if the shape
     *  does not define mass (ie: it's always used by static objects).
     */
    public BodyMass getMass() {
        return mass;
    }

    /**
     *  Returns the shape's AaBBox relative to the center of gravity.
     */
    public AaBBox getCogBounds() {
        return cogBounds;
    }

    /**
     *  Returns the shape's origin in world space relative to the specified
     *  body.
     */
    public Vec3d getWorldShapeOrigin( AbstractBody body ) {
        Vec3d offset = body.orientation.mult(getBoundsCenter());
        offset.multLocal(-1).addLocal(body.position);
        return offset;
    }

    // Kind of straddles the line for some of the demos/apps that do this
    // calculate in the view layer and know the world position and orientation
    // of the body but not the actual body.
    public Vec3d getWorldShapeOrigin( Vec3d bodyPos, Quatd bodyOrientation ) {
        Vec3d offset = bodyOrientation.mult(getBoundsCenter());
        offset.multLocal(-1).addLocal(bodyPos);
        return offset;
    }

    /**
     *  Moves the body so that it's orientation and position are such that
     *  'world' is its world space origin.  After calling this, getWorldShapeOrigin()
     *  should return the same 'world' parameter we passed in.
     *  Application code will reason about the position of objects relative to the
     *  shapes they've defined.  The physics engine likes to reason about things
     *  relative to CoG.  Because the CoG of a shape/object might move around during
     *  its lifetime, it is difficult to write application code that can position the
     *  model for visualization (or position other things relative to that model).
     *  The getWorldShapeOrigin() and setWorldShapeOrigin() methods are a way of
     *  translating body position to/from model space position.
     */
    public void setWorldShapeOrigin( AbstractBody body, Vec3d world, Quatd orientation ) {
        body.orientation.set(orientation);
        Vec3d offset = body.orientation.mult(getBoundsCenter());
        body.position.set(world).addLocal(offset);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("center", getBoundsCenter())
                .add("radius", getBoundsRadius())
                .add("bodyMass", getMass())
                .toString();
    }
}


