/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

/**
 *  Represents the mass-related properties of a physical object.
 *
 *  @author    Paul Speed
 */
public class BodyMass {

    private double inverseMass;
    private Matrix3d inverseMassTensor;
    private Vec3d cog;
    private double radius;
    
    public BodyMass( double inverseMass, Matrix3d inverseMassTensor, Vec3d cog, double radius ) {
        this.inverseMass = inverseMass;
        this.inverseMassTensor = inverseMassTensor;
        this.cog = cog;
        this.radius = radius;
    }    

    /**
     *  Creates a solid sphere body mass.
     */
    public static BodyMass createSolidSphere( double mass, double radius, Vec3d cog ) {
        if( mass == 0 ) {
            return createSimple(mass, cog, radius);
        }
        if( cog == null ) {
            cog = new Vec3d();
        }
        Matrix3d inertiaTensor = new Matrix3d().makeIdentity();
        inertiaTensor.multLocal(2.0/5.0 * mass * radius * radius);
        
        // We could have calculated it as inverted but I wanted to keep the 
        // code close to real intertia tensor creation.
        Matrix3d inverseInertiaTensor = inertiaTensor.invert();
                                    
        return new BodyMass(1/mass, inverseInertiaTensor, cog, radius);  
    } 

    /**
     *  Creates a simple BodyMass with an identity-based inertia tensor
     *  that is merely scaled by mass.
     */
    public static BodyMass createSimple( double mass, Vec3d cog, double radius ) {
        if( cog == null ) {
            cog = new Vec3d();
        }
        if( mass == 0 ) {
            return new BodyMass(0, new Matrix3d().makeIdentity(), cog, radius);
        } else {
            // inverse inertia tensor
            return new BodyMass(1/mass, new Matrix3d().makeIdentity().multLocal(1/mass), cog, radius);
        } 
    }

    public final double getInverseMass() {
        return inverseMass;
    }
    
    public final Matrix3d getInverseMassTensor() {
        return inverseMassTensor;
    }
    
    public final Vec3d getCog() {
        return cog; 
    }
    
    public final double getRadius() {
        return radius;
    }
    
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("inverseMass", inverseMass)
                .add("inverseMassTensor", inverseMassTensor)
                .add("cog", cog)
                .add("radius", radius)
                .toString();
    }
}
