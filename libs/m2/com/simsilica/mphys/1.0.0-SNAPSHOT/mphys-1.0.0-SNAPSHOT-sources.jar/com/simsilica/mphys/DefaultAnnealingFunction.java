/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.Vec3d;

/**
 *  A standard annealing function that simply reduces or increases
 *  temperature based on thresholds.
 *
 *  @author    Paul Speed
 */
public class DefaultAnnealingFunction implements AnnealingFunction {
 
    static Logger log = LoggerFactory.getLogger(DefaultAnnealingFunction.class);
 
    public static final DefaultAnnealingFunction GLOBAL_ANNEALING = new DefaultAnnealingFunction(); 

 
    //private static final double MOTION_EPSILON = 0.12;
    //private static final double ROTATION_EPSILON = 0.02;
    //private static final double MOTION_SLOW_COOL = 0.31;
    //private static final double ROTATION_SLOW_COOL = 0.1;
    private static final double MOTION_EPSILON = 0.07;
    private static final double ROTATION_EPSILON = 0.01;
    private static final double MOTION_SLOW_COOL = 0.15;
    private static final double ROTATION_SLOW_COOL = 0.04;
 
    //private static final double COOLING = 0.9;
    private static final double COOLING = 0.98;
    private static final double SLOW_COOLING = 0.99;
    private static final double HEATING = 1.5;

    private static final double SLEEP_EPSILON = 0.01;
    private static final double WAKING_TEMPERATURE = 0.1;
 
    private double minLinear = Math.sqrt(MOTION_EPSILON);
    private double minRot = Math.sqrt(ROTATION_EPSILON);
    private double midLinear = Math.sqrt(MOTION_SLOW_COOL);
    private double midRot = Math.sqrt(ROTATION_SLOW_COOL); 
    private double highLinear = Math.sqrt(MOTION_SLOW_COOL * 1.5);
    private double highRot = Math.sqrt(ROTATION_SLOW_COOL * 1.5);
     
    private double minLinearSq = MOTION_EPSILON;
    private double minRotSq = ROTATION_EPSILON;
    private double midLinearSq = MOTION_SLOW_COOL;
    private double midRotSq = ROTATION_SLOW_COOL; 
    private double highLinearSq = MOTION_SLOW_COOL * 1.5;
    private double highRotSq = ROTATION_SLOW_COOL * 1.5; 

    private double coolingFactor = COOLING;
    private double slowCoolingFactor = SLOW_COOLING;
    private double heatingFactor = HEATING;
 
    private double minTemperature = SLEEP_EPSILON;
    private double wakingTemperature = WAKING_TEMPERATURE;
 
    public DefaultAnnealingFunction() {
    } 
 
    public void setMinLinear( double d ) {
        this.minLinear = d;
        this.minLinearSq = d * d;
    }
    
    public double getMinLinear() {
        return minLinear;
    }
    
    public void setMinRotational( double d ) {
        this.minRot = d;
        this.minRotSq = d * d;
    }
    
    public double getMinRotational() {
        return minRot;
    }

    public void setMidLinear( double d ) {
        this.midLinear = d;
        this.midLinearSq = d * d;
    }
    
    public double getMidLinear() {
        return midLinear;
    }
    
    public void setMidRotational( double d ) {
        this.midRot = d;
        this.midRotSq = d * d;
    }
    
    public double getMidRotational() {
        return midRot;
    }
    
    public void setHighLinear( double d ) {
        this.highLinear = d;
        this.highLinearSq = d * d;
    }
    
    public double getHighLinear() {
        return highLinear;
    }
    
    public void setHighRotational( double d ) {
        this.highRot = d;
        this.highRotSq = d * d;
    }
    
    public double getHighRotational() {
        return highRot;
    }
 
    public void setCoolingFactor( double d ) {
        this.coolingFactor = d;
    }
    
    public double getCoolingFactor() {
        return coolingFactor;
    }
    
    public void setSlowCoolingFactor( double d ) {
        this.slowCoolingFactor = d;
    }
    
    public double getSlowCoolingFactor() {
        return slowCoolingFactor;
    }
    
    public void setHeatingFactor( double d ) {
        this.heatingFactor = d;
    }
    
    public double getHeatingFactor() {
        return heatingFactor;
    }
    
    public void setMinimumTemperature( double d ) {
        this.minTemperature = d;
    }
    
    public double getMinimumTemperature() {
        return minTemperature;
    }
    
    public void setWakingTemperature( double d ) {
        this.wakingTemperature = d;
    }
    
    @Override   
    public double getWakingTemperature() {
        return wakingTemperature;
    }    
 
    @Override   
    public boolean isCold( double temperature ) {
        return temperature < minTemperature;
    }
    
    @Override   
    public double calculateTemperature( double temperature, 
                                        Vec3d linearVel, Vec3d rotVel, Vec3d linearAccel,
                                        Vec3d lastLinearVel, Vec3d lastRotVel,
                                        double time ) {
 
        double linVelSq = linearVel.lengthSq();// / temperature;
        double rotVelSq = rotVel.lengthSq();// / temperature;
        // re: the above / temperature... it's the right idea to pull it out of
        // 'slowed time' but ultimately we'd have to do it against the non-squared
        // values for it to mean anything.
           
        if( linVelSq < minLinearSq && rotVelSq < minRotSq ) {
            temperature *= coolingFactor;
        } else if( linVelSq < midLinearSq && rotVelSq < midRotSq ) {
            temperature *= slowCoolingFactor; 
        } else if( linVelSq > highLinearSq && rotVelSq > highRotSq ) {
            // TODO: check to see if this last check should really be an OR
            temperature *= heatingFactor;
            if( temperature > 1.0 ) {
                temperature = 1.0;           
            }            
        }
 
 /*       
log.debug("linear:" + linearVel + "  last:" + lastLinearVel);
log.debug("  accel:" + linearAccel);
        Vec3d vAcc = linearAccel.mult(time);
log.debug("  vAcc:" + vAcc);
*/        

//log.debug("rot:" + rotVel + "  last:" + rotVel);        
        
        return temperature;
    }
                                    
}


