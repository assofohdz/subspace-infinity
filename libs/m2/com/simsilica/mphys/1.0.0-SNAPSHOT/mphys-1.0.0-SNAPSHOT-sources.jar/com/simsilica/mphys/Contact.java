/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects; 

import com.simsilica.mathd.*;

/**
 *  Information about a contact between one body and the world or other
 *  bodies.
 *
 *  @author    Paul Speed
 */
public class Contact<K, S extends AbstractShape> {
    static Logger log = LoggerFactory.getLogger(Contact.class);
 
    public static final double DEFAULT_FRICTION = 0.7; 
    public static final double DEFAULT_RESTITUTION = 0.1;  
    public static final double MIN_CONTACT_TEMPERATURE = 0.001;
    
    public RigidBody<K, S> body1;
    private boolean body1Enabled;
    
    public AbstractBody<K, S> body2;
    private boolean body2Enabled;
    
    public Vec3d contactPoint;
    public Vec3d contactNormal;
    public double penetration;

    public double friction = DEFAULT_FRICTION;
    public double restitution = DEFAULT_RESTITUTION;
    
    private static final double DEFAULT_RESTITUTION_THRESHOLD = 0.25;
    private static double restitutionThreshold = DEFAULT_RESTITUTION_THRESHOLD;

    // Notes kept from the old code in case it is relevant 2016/12/27     
        // 0.5 looks better for objects that don't go all jittery
        // because they swing more freely in hard links.
        // 0.01 works better for really heavy objects because otherwise
        // they go all jittery.  And I suspect it may also depend on the
        // kind of link.
    // The angular limit controls how far the position resolver will
    // adjust rotation as part of resolving the penetration.  The
    // reason that a low value probably works is because objects will
    // tend to settle on their own anyway.
    private static final double DEFAULT_ANGULAR_LIMIT = 0.001;
    private static double angularLimit = DEFAULT_ANGULAR_LIMIT;
 
    // Latest relearning 2016/12/27
    // The linear limit is used to clamp the position adjustment due to
    // the contact.  The 0.25 * 60 thing seems to be completely arbitrary
    // but I've kept it just in case it triggers a memory later.  The 60 is
    // not related to frames or anything as the value is applied per step.
    // Effectively, this limits the movement of an object to no more than
    // 15 meters in a single time step.  This may be too high, actually.
    // It could be that the old 0.25 * 60 value really was frame related at
    // some time and that a much smaller value would be better.  So exposing
    // this as a tweakable parameter probably a good thing.
    // Note: this is to prevent explosive changes the result from highly
    // constrained objects... but I can't come up with any math that would
    // ever move a penetrating object 15 meters to resolve the contact.
    // In the end, I will have to wait until I have a situation where explosive
    // behavior is seen again and then tweak it.     
    //private static final double DEFAULT_LINEAR_LIMIT = 0.25 * 60; // 15
    // Basic experimentation shows that a smaller value is fine... even 1 should
    // be pretty large and we'll log a warning anyway.
    private static final double DEFAULT_LINEAR_LIMIT = 15; //1; 
    private static double linearLimit = DEFAULT_LINEAR_LIMIT;       
    
    // Used internally    
    protected Matrix3d contactToWorld = new Matrix3d();
    protected Vec3d contactVelocity;
    protected double desiredDeltaVelocity;
    protected Vec3d relativeContactPosition1;
    protected Vec3d relativeContactPosition2;
 
    public double localTemperature;
 
private boolean debug;
public static boolean globalDebug;
 
    public Contact() {
    }
    
    public Contact( RigidBody<K, S> body, Vec3d contactPoint, Vec3d contactNormal, double penetration ) {
        this(body, null, contactPoint, contactNormal, penetration);
    }
           
    public Contact( RigidBody<K, S> body1, AbstractBody<K, S> body2, 
                    Vec3d contactPoint, Vec3d contactNormal, double penetration ) {
        if( body1 == null ) {
            throw new IllegalArgumentException("body1 cannot be null");
        }
        if( contactNormal.isNaN() ) {
            throw new IllegalArgumentException("Invalid contact normal:" + contactNormal);
        }
        if( body1 == body2 ) {
            throw new IllegalArgumentException("Self-contacts not allowed:" + body1);
        }
        if( body2 != null && Objects.equals(body1.id, body2.id) ) {
            throw new IllegalArgumentException("Different bodies have the same ID, b1:" + body1.id + "  b2:" + body2.id);
        }
        this.body1 = body1;
        this.body1Enabled = true;
        this.body2 = body2;
        this.body2Enabled = body2 instanceof RigidBody;
        this.contactPoint = contactPoint;
        this.contactNormal = contactNormal;
        this.penetration = penetration;
        
        if( body1 != null ) {
            body1.incrementContactCount();
        }
        if( body2Enabled ) {
            ((RigidBody)body2).incrementContactCount();
        }
/*if( body1.id.equals(10) || (body2 != null && body2.id.equals(10)) ) {
    log.debug("Debug mode on for:" + this);
    debug = true;
}*/        
    }

    public void setBodies( RigidBody<K, S> body1, AbstractBody<K, S> body2 ) {
        if( body1 == null ) {
            throw new IllegalArgumentException("body1 cannot be null");
        }
        if( body1 == body2 ) {
            throw new IllegalArgumentException("Self-contacts not allowed:" + body1);
        }
        if( body2 != null && Objects.equals(body1.id, body2.id) ) {
            throw new IllegalArgumentException("Different bodies have the same ID, b1:" + body1.id + "  b2:" + body2.id);
        }
        this.body1 = body1;
        this.body1Enabled = true;
        this.body2 = body2;
        this.body2Enabled = body2 instanceof RigidBody;
        
        if( body1 != null ) {
            body1.incrementContactCount();
        }
        if( body2Enabled ) {
            ((RigidBody)body2).incrementContactCount();
        }
/*if( body1.id.equals(10) || (body2 != null && body2.id.equals(10)) ) {
    log.debug("Debug mode on for:" + this);
    debug = true;
}*/        
    }
 
    /**
     *  Returns true if either end has the specified ID.
     */
    public boolean hasId( K id ) {
        if( id == null ) {
            return body1 == null || body2 == null;
        }
        if( body1 != null && id.equals(body1.id) ) {
            return true;
        }
        if( body2 != null && id.equals(body2.id) ) {
            return true;
        }
        return false;
    }
 
    /**
     *  Returns true if either end is enabled.
     */
    public final boolean isEnabled() {
        // Note that we swap bodies when disabling body1... so if we are enabled
        // at all then body1 is enabled.        
        return body1Enabled;
    }
 
    protected boolean isBody2Enabled() {
        return body2Enabled;
    }
 
    /**
     *  Disables this contact from resolution.
     */
    public void disable() {
        if( body1Enabled ) {
            body1Enabled = false;
            body1.decrementContactCount();
        }
        if( body2Enabled ) {            
            body2Enabled = false;
            ((RigidBody)body2).decrementContactCount();
        }
    }
 
    /**
     *  Disables body1 so that no contact resolution will be applied to it.
     *  Note: this method swaps the bodies.
     */
    public void disableBody1() {
        if( body1Enabled ) {
            // Swap the bodies
            contactNormal.multLocal(-1);
            AbstractBody<K, S> temp = body1;
            body1 = (RigidBody<K,S>)body2;
            body2 = temp;
            body1Enabled = body2Enabled;
        
            // And we know that body2 is now disabled because that's why we swapped them
            body2Enabled = false;                       
            ((RigidBody)body2).decrementContactCount();
        }
    }
 
    /**
     *  Disables body2 from contact resolution.
     */   
    public void disableBody2() {
        // This is the easy one
        if( body2Enabled ) {            
            body2Enabled = false;
            ((RigidBody)body2).decrementContactCount();
        }
    }
    
    public void setContactInfo( Vec3d contactPoint, Vec3d contactNormal, double penetration ) {
        if( contactNormal.isNaN() ) {
            throw new IllegalArgumentException("Invalid contact normal:" + contactNormal);
        }
        this.contactPoint = contactPoint;
        this.contactNormal = contactNormal;
        this.penetration = penetration;
    }

    public static void setRestitutionThreshold( double r ) {
        restitutionThreshold = r;
    }
    
    public static double getRestitutionThreshold() {
        return restitutionThreshold; 
    }
    
    public static void setAngularLimit( double d ) {
        angularLimit = d;
    }
    
    public static double getAngularLimit() {
        return angularLimit;
    }
    
    public static void setLinearLimit( double d ) {
        linearLimit = d;
    }
    
    public static double getLinearLimit() {
        return linearLimit;
    }
 
    public final RigidBody<K, S> getBody1() {
        return body1;
    }

    public final RigidBody<K, S> getBody2() {
        return body2Enabled ? (RigidBody<K,S>)body2 : null;
    }
 
    public double calculateContactTemperature() {
        // TODO: consider if we should scale minimum contact temperature with restitution   
        double result = Math.max(body1.getTemperature(), MIN_CONTACT_TEMPERATURE);
        if( !body2Enabled ) {
            // Nothing else to do
            return result;
        }        
        result = Math.max(((RigidBody)body2).getTemperature(), result); 
        return result;       
    }
 
    /**
     *  Matches this contact's local temperature to the body or bodies involved
     *  in the contact.  The combined temperature is then applied back to the bodies.
     */   
    public void matchLocalTemperature() {
 
        // TODO: consider if we should scale minimum contact temperature with restitution   
        localTemperature = Math.max(body1.getTemperature(), MIN_CONTACT_TEMPERATURE);
        if( !body2Enabled ) {
            // Nothing else to do
            return;
        }
        
        localTemperature = Math.max(((RigidBody)body2).getTemperature(), localTemperature);
        
        // Apply the new local temperature to both bodies so that they match
        body1.setTemperature(localTemperature);
        ((RigidBody)body2).setTemperature(localTemperature);
    }
    
    protected void calculateInternals( double t ) {
        if( body1 == null ) {
            // My original code paths all had this body swapping stuff.  As of
            // today, I'm not sure when I'd create a contact without knowing whether
            // I had one body or two.
            //swapBodies();
            throw new RuntimeException("No body1 specified.");
        }
             
        calculateContactBasis();
        
        relativeContactPosition1 = contactPoint.subtract(body1.position);
        if( body2Enabled ) {
            relativeContactPosition2 = contactPoint.subtract(body2.position);
        }            
            
        contactVelocity = calculateLocalVelocity(body1, relativeContactPosition1, t);
        if( body2Enabled ) {
            contactVelocity.subtractLocal(calculateLocalVelocity((RigidBody)body2, relativeContactPosition2, t));
        }
                                    
        calculateDesiredDeltaVelocity(t);
    }

    protected void calculateDesiredDeltaVelocity( double t ) {
    
        double vFromAcc = 0;
if( debug ) {        
    log.debug("lastFrameAccel:" + body1.getLastFrameAcceleration());
    log.debug("  cn:" + contactNormal);
    log.debug("  pen:" + penetration);
}
        
        vFromAcc = body1.getLastFrameAcceleration().mult(t).dot(contactNormal);
if( debug ) {        
    log.debug("  vFromAcc:" + vFromAcc);
}        
        if( body2Enabled ) {
            vFromAcc -= ((RigidBody)body2).getLastFrameAcceleration().mult(t).dot(contactNormal); 
        }
if( debug ) {        
    log.debug("  cVel:" + contactVelocity);
    log.debug("  bVel:" + body1.getLinearVelocity());
}
 
        // It's possible that this comparison should not be against 'abs'
        // since negative contactVelocity.x indicates objects are separating
        // and it should be fine to kill restitution?  2016/12/27           
        double r = restitution;
        if( Math.abs(contactVelocity.x) < restitutionThreshold ) {
            r = 0.0f; 
        }

        desiredDeltaVelocity = -contactVelocity.x - r * (contactVelocity.x - vFromAcc);
if( debug ) {        
    log.debug("  desiredDeltaV:" + desiredDeltaVelocity);
}             
    }
    
    protected Vec3d calculateLocalVelocity( RigidBody b, Vec3d relContactPos, double t ) {
 
if( debug ) {        
    log.debug("relContactPos:" + relContactPos);
    log.debug("   rotVel:" + b.getRotationalVelocity());
}        
        Vec3d v = b.getRotationalVelocity().cross(relContactPos);
if( debug ) {        
    log.debug("   v:" + v);
    log.debug("   linearV:" + b.getLinearVelocity());
}             
        v.addLocal(b.getLinearVelocity());
if( debug ) {        
    log.debug("   v:" + v);
}
 
        Vec3d vContact = contactToWorld.transpose().mult(v);
if( debug ) {        
    log.debug("   vContact:" + vContact);
}    
        
        Vec3d vAcc = b.getLastFrameAcceleration().mult(t);
if( debug ) {        
    log.debug("   vAcc:" + vAcc);
}            
        vAcc = contactToWorld.transpose().mult(vAcc); 
if( debug ) {        
    log.debug("   vAcc:" + vAcc);
}    
        
        vAcc.x = 0;
if( debug ) {        
    log.debug("   vAcc:" + vAcc);
}
               
        vContact.addLocal(vAcc);
if( debug ) {        
    log.debug("   vContact:" + vContact);
}    
 
        return vContact;     
    }
     
    protected void calculateContactBasis() {
    
        Vec3d contactTangent0 = new Vec3d();
        Vec3d contactTangent1 = new Vec3d();
 
        if( Math.abs(contactNormal.x) > Math.abs(contactNormal.y) ) {
            double s = 1.0f / Math.sqrt(contactNormal.z * contactNormal.z   
                                               + contactNormal.x * contactNormal.x);
            
            contactTangent0.x = contactNormal.z * s;
            contactTangent0.y = 0;
            contactTangent0.z = -contactNormal.x * s;
            
            contactTangent1.x = contactNormal.y * contactTangent0.x;
            contactTangent1.y = contactNormal.z * contactTangent0.x
                                - contactNormal.x * contactTangent0.z;
            contactTangent1.z = -contactNormal.y * contactTangent0.x;
        } else {
            double s = 1.0f / Math.sqrt(contactNormal.z * contactNormal.z   
                                               + contactNormal.y * contactNormal.y);
            
            contactTangent0.x = 0; 
            contactTangent0.y = -contactNormal.z * s;
            contactTangent0.z = contactNormal.y * s;
            
            contactTangent1.x = contactNormal.y * contactTangent0.z
                                - contactNormal.z * contactTangent0.y;
            contactTangent1.y = -contactNormal.x * contactTangent0.z;
            contactTangent1.z = contactNormal.x * contactTangent0.y;
        }       
            
        contactToWorld.setColumn(0, contactNormal);
        contactToWorld.setColumn(1, contactTangent0);
        contactToWorld.setColumn(2, contactTangent1);    
    }

    /**
     *  Calculates what the position change would be if we resolved the contact
     *  directly and then returns the deltas for each object in the target parameters
     *  specified.
     */
    protected void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                            Vec3d angular1, Vec3d angular2,
                                            double penetration ) {
                                            
        // 0.5 looks better for objects that don't go all jittery
        // because they swing more freely in hard links.
        // 0.01 works better for really heavy objects because otherwise
        // they go all jittery.  And I suspect it may also depend on the
        // kind of link.
        // Should be a property of the contact, I think.
        //double angularLimit = 0.5;
        //double angularLimit = 0.2;
        double angularLimit = 0.001;
 
        // Playing with an angular limit that might work better
        // with the "all contacts at once" approach    
//        double angularLimit = 1;
                
        double angularMove1;
        double angularMove2;
        double linearMove1;
        double linearMove2;
 
        double totalInertia = 0;
        double linearInertia1 = 0;       
        double linearInertia2 = 0;       
        double angularInertia1 = 0;
        double angularInertia2 = 0;
 
        // Calculate the values for body1.  body1 should never be null but it
        // keeps the code more symmetric if we treat it that way and makes working scope
        // prettier.
        if( body1 != null ) {
            Matrix3d iit = body1.getInverseInertiaTensorWorld();        
            Vec3d angularInertiaWorld = relativeContactPosition1.cross(contactNormal);
            angularInertiaWorld = iit.mult(angularInertiaWorld);
            angularInertiaWorld = angularInertiaWorld.cross(relativeContactPosition1);
            angularInertia1 = angularInertiaWorld.dot(contactNormal);
            
            linearInertia1 = body1.getInverseMass();
            totalInertia += linearInertia1 + angularInertia1;
        }
 
        // If there is a body 2 then calculate for that also
        if( body2Enabled )  {
            Matrix3d iit = ((RigidBody)body2).getInverseInertiaTensorWorld();
            Vec3d angularInertiaWorld = relativeContactPosition2.cross(contactNormal);
            angularInertiaWorld = iit.mult(angularInertiaWorld);
            angularInertiaWorld = angularInertiaWorld.cross(relativeContactPosition2);
            angularInertia2 = angularInertiaWorld.dot(contactNormal);
            
            linearInertia2 = ((RigidBody)body2).getInverseMass();
            totalInertia += linearInertia2 + angularInertia2;
        }
if( globalDebug && body2Enabled ) {
    log.debug("linInert1:" + linearInertia1 + " angInert1:" + angularInertia1);
    log.debug("linInert2:" + linearInertia2 + " angInert2:" + angularInertia2);
    log.debug("total inertia:" + totalInertia);
}        

        if( body1 != null ) {
            double sign = 1;
            angularMove1 = sign * penetration * (angularInertia1 / totalInertia);
            linearMove1 = sign * penetration * (linearInertia1 / totalInertia);            
            Vec3d projection = relativeContactPosition1.clone();
            
            projection.addScaledVectorLocal(contactNormal, -relativeContactPosition1.dot(contactNormal)); 
            //addScaledVector(projection, contactNormal, -relativeContactPosition1.dot(contactNormal));
            
            double maxMagnitude = angularLimit * projection.length();
            if( angularMove1 < -maxMagnitude ) {
                double totalMove = angularMove1 + linearMove1;
                angularMove1 = -maxMagnitude;
                linearMove1 = totalMove - angularMove1;
            } else if( angularMove1 > maxMagnitude ) {
                double totalMove = angularMove1 + linearMove1;
                angularMove1 = maxMagnitude;
                linearMove1 = totalMove - angularMove1;
            } else {
                angularMove1 = 0;  // Trying this because it almost makes sense.
            }
                
            if( angularMove1 == 0 ) {
                angular1.set(0,0,0);
            } else {
                Vec3d targetAngularDirection = relativeContactPosition1.cross(contactNormal);
                Matrix3d iit = body1.getInverseInertiaTensorWorld();
                angular1.set(iit.mult(targetAngularDirection).multLocal(angularMove1 / angularInertia1));
            }

            // An atribitrary limiter I stuck in at some point but not permanently in
            // the old code.  It seems to limit the maximum movement.  If movement is in
            // meters then it may mean no more than 0.25 meters in one second based on a FPS of 60...
            // for movement produced by contacts.  This seems reasonable given my application
            // but in the general case we might want to parameterize it.
            // TODO: figure out what removing this/changing this does and then document it better.
            //double vLimit = 0.25 * 60;
            if( linearMove1 > linearLimit ) {
                log.warn("Clamping movement:" + linearMove1 + " to:" + linearLimit + " for body1:" + body1);            
                linearMove1 = linearLimit;
            }    
            linear1.set(contactNormal.mult(linearMove1));            
        }                            
                                        
        if( body2Enabled ) {
            double sign = -1;
            angularMove2 = sign * penetration * (angularInertia2 / totalInertia);
            linearMove2 = sign * penetration * (linearInertia2 / totalInertia);
            
            Vec3d projection = relativeContactPosition2.clone();
            projection.addScaledVectorLocal(contactNormal, -relativeContactPosition2.dot(contactNormal)); 
            
            double maxMagnitude = angularLimit * projection.length();
            
            if( angularMove2 < -maxMagnitude ) {
                double totalMove = angularMove2 + linearMove2;
                angularMove2 = -maxMagnitude;
                linearMove2 = totalMove - angularMove2;
            } else if( angularMove2 > maxMagnitude ) {
                double totalMove = angularMove2 + linearMove2;
                angularMove2 = maxMagnitude;
                linearMove2 = totalMove - angularMove2;
            }

            if( angularMove2 == 0 ) {
                angular2.set(0,0,0);
            } else {
                Vec3d targetAngularDirection = relativeContactPosition2.cross(contactNormal);
                Matrix3d iit = ((RigidBody)body2).getInverseInertiaTensorWorld();
                angular2.set(iit.mult(targetAngularDirection).multLocal(angularMove2 / angularInertia2));
            }

            // See comment above... though given the comment added to this one, one of  us is
            // confused.  Need to trace back through how linearMove is used and see if it's time
            // scaled or not.  If it is scaled by time step then 0.25 * 60 means that we've limited
            // the movement of contact resolution to 1/4 of a meter.  This I think is ok for contacts
            // (it's not velocity after all) but is maybe too arbitrary.
            //double vLimit = 0.25 * 60;
                // Original comment with the above line:  
                // though that's still pretty large, 15 m/sec is not very fast when you
                // think about it.
                
            // Notes on 2016/12/26 after tracing back out:
            // These linear vectors are used for direct movement of the object to resolve
            // its penetration.  So that implies that the value of 60 above is just arbitrary
            // and not really frame related.  In one frame, we're limiting movement to 
            // less than 15 meters, basically.  That's actually quite a bit faster than
            // 15 ms/sec.                
                
            if( linearMove2 > linearLimit ) {
                log.warn("Clamping movement:" + linearMove2 + " to:" + linearLimit + " for body2:" + body2);                        
                linearMove2 = linearLimit;
            }    
            
            linear2.set(contactNormal.mult(linearMove2));
        }                            
    }

    protected void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                            Vec3d rotDelta1, Vec3d rotDelta2 ) {
 
        Matrix3d iit1 = null;
        Matrix3d iit2 = null;
        iit1 = body1.getInverseInertiaTensorWorld();
        if( body2Enabled ) { 
            iit2 = ((RigidBody)body2).getInverseInertiaTensorWorld();
        }
        
        Vec3d impContact;
        if( friction == 0 ) {
            impContact = calculateFrictionlessImpulse(iit1, iit2);
        } else {
            impContact = calculateFrictionImpulse(iit1, iit2);
        }
        if( impContact.isNaN() ) {
            System.out.println("NaN contact impulse.");
        }

        // impContact is the impulse that the contact pushes against the 
        // bodies at the contact point.  If friction is high, it will push
        // orthogonally to the normal.  If friction is low then it will
        // only push along the contact normal.
        // impContact is in 'contact space' where x is along the normal.
        // The contactToWorld matrix will put it back into world space.

if( debug ) {        
    log.debug("calcVelChange  impContact:" + impContact);
}    
        Vec3d imp = contactToWorld.mult(impContact);
        if( imp.isNaN() ) {
            System.out.println("NaN impulse.");
        }
if( debug ) {        
    log.debug("  imp:" + imp);
}    

        Vec3d impTorque = relativeContactPosition1.cross(imp);
if( debug ) {        
    log.debug("  impTorque:" + impTorque);
}
        // impTorque is the force converted to a rotational change.
        // The cross product here is a bit magic to me... but it does make
        // some sense.  The cross product will give us a scaled vector
        // that is orthogonal to the original two vectors.  In this case,
        // the impulse pushing against us and the direction from our center
        // of mass to the contact position.  So if we imagine that the contact
        // point is directly down (0, -y, 0) and the impulse is directly +x
        // then we'll get a vector that is mostly z... which represents rotation
        // around z.  Which is exactly what one would expect. 
 
        // We have to pass that rotational vector through the inverse intertial
        // tensor, though.  This effectively mutes/expands different axis rotations
        // depending on how hard/easy the object is to rotate in particular directions.
        rotDelta1.set(iit1.mult(impTorque));
if( debug ) {        
    log.debug("  rotDelta1:" + rotDelta1);   
}
        // The inverse mass of both bodies was added together when calculating
        // the total contact impulse... based on an inverted version of that
        // calculation.  Thus scaling by that now effectively applies only the part 
        // related to one body.  Any additional impulse is extra and applies to
        // both in proportion.  I still think that things with mass less than 1
        // (ie: inverse mass greater than 1) behave strangely.           
        vDelta1.set(0,0,0);
        vDelta1.addScaledVectorLocal(imp, body1.getInverseMass());
if( debug ) {        
    log.debug("  invMass:" + body1.getInverseMass());
    log.debug("  vDelta1:" + vDelta1);
}
        
        if( body2Enabled ) {
            impTorque = imp.cross(relativeContactPosition2);
            rotDelta2.set(iit2.mult(impTorque));
            vDelta2.set(0,0,0);
            vDelta2.addScaledVectorLocal(imp, -((RigidBody)body2).getInverseMass());
        }        
    }

    /** 
     *  Calculates and returns the impulse for a frictionless contact given
     *  the body1 and body2 inverse inertia tensors in world space.
     */
    protected Vec3d calculateFrictionlessImpulse( Matrix3d iit1, Matrix3d iit2 ) {
    
        Vec3d impContact = new Vec3d();            
        
        Vec3d vDeltaWorld = relativeContactPosition1.cross(contactNormal);
        vDeltaWorld = iit1.mult(vDeltaWorld);
        vDeltaWorld = vDeltaWorld.cross(relativeContactPosition1);
        
        double vDelta = vDeltaWorld.dot(contactNormal);
         
        vDelta += body1.getInverseMass();
        
        if( iit2 != null ) {
            vDeltaWorld = relativeContactPosition2.cross(contactNormal);
            vDeltaWorld = iit2.mult(vDeltaWorld);
            vDeltaWorld = vDeltaWorld.cross(relativeContactPosition2);
            
            vDelta += vDeltaWorld.dot(contactNormal);
            
            vDelta += ((RigidBody)body2).getInverseMass();
        }

        impContact.x = desiredDeltaVelocity / vDelta;
        return impContact;    
    }

            
    /** 
     *  Calculates and returns the impulse at this contact given
     *  the body1 and body2 inverse inertia tensors in world space.
     *  The contact friction is used to transfer motion into reverse planar
     *  force and/or counter-rotation. 
     */
    protected Vec3d calculateFrictionImpulse( Matrix3d iit1, Matrix3d iit2 ) {
        Vec3d impContact;            
  
        double invMass = body1.getInverseMass();
if( debug ) {        
    log.debug("invMass:" + invMass);
}
        
        // The equivalent of a cross product in matrices is multiplication
        // by a skew symmetric matrix - we build the matrix for converting
        // between linear and angular quantities.
        Matrix3d impToTorque = new Matrix3d().setSkewSymmetric(relativeContactPosition1);

        Matrix3d vDeltaWorld = impToTorque.clone();
        vDeltaWorld.multLocal(iit1);
        vDeltaWorld.multLocal(impToTorque);
        vDeltaWorld.multLocal(-1);

        if( iit2 != null ) {
            impToTorque.setSkewSymmetric(relativeContactPosition2);
            
            Matrix3d vDeltaWorld2 = impToTorque.clone();
            vDeltaWorld2.multLocal(iit2);
            vDeltaWorld2.multLocal(impToTorque);
            vDeltaWorld2.multLocal(-1);
 
            vDeltaWorld.addLocal(vDeltaWorld2);
            
            invMass += ((RigidBody)body2).getInverseMass();
        }
 
        Matrix3d vDelta = contactToWorld.transpose();
        vDelta.multLocal(vDeltaWorld);
        vDelta.multLocal(contactToWorld);
        
        vDelta.m00 = vDelta.m00 + invMass;
        vDelta.m11 = vDelta.m11 + invMass;
        vDelta.m22 = vDelta.m22 + invMass;
 
        Matrix3d impMatrix = vDelta.invert();
 
        // Calculate the velocity necessary to kill the motion from the
        // perspective of the contact point.       
        Vec3d velKill = new Vec3d(desiredDeltaVelocity, -contactVelocity.y, -contactVelocity.z);
if( debug ) {        
    log.debug("  velKill:" + velKill);
}
        impContact = impMatrix.mult(velKill);
if( debug ) {        
    log.debug("  impContact:" + impContact);
}
 
        if( true ) {
            // I'm pretty sure that a negative impContact.x means that the objects
            // are flying apart.  I'm not sure we should be imparting any lateral
            // forces at all in that case... but if we are then we should be 
            // taking the abs() of impContact.x * friction else values get wild
            // and we risk letting planarImp be 0 causing a bunch of NaNs.
            // The friction > 0 check is so that we can set special negative friction
            // if we want to completely avoid the planar friction... useful for reusing
            // contacts as part of constraint calculations.
            if( friction > 0 && impContact.x > 0 ) {
                // If the motion along the contact 'plane' (ie: the non-reverse-penetrating motion) is
                // more than the frictional force of the contact then we need to break free and 
                // use dynamic friction.  Prior to that threshold, friction is like the object
                // is 'stuck' at that contact point in a sense.       
                double planarImp = Math.sqrt(impContact.y * impContact.y + impContact.z * impContact.z);
if( debug ) {        
    log.debug("  planarImp:" + planarImp + "  total friction:" + (impContact.x * friction));
}    
//if( false ) {                
                if( planarImp > impContact.x * friction ) {
//if( friction == 0.9 || friction == 0.1) {
//    log.debug("  planarImp:" + planarImp + "  total friction:" + (impContact.x * friction) + "  friction:" + friction);                
//}                
                    // We need to use dynamic friction
                    impContact.y /= planarImp;
                    impContact.z /= planarImp;
if( debug ) {        
    log.debug("  impContact:" + impContact);
}
                    
                    impContact.x = vDelta.m00 
                            + vDelta.m01 * friction * impContact.y
                            + vDelta.m02 * friction * impContact.z;
if( debug ) {        
    log.debug("  impContact:" + impContact);
}
                    impContact.x = desiredDeltaVelocity / impContact.x;
                    impContact.y *= friction * impContact.x;
                    impContact.z *= friction * impContact.x; 
if( debug ) {        
    log.debug("  impContact:" + impContact);
}
                }
                if( impContact.isNaN() ) {        
                    System.out.println("NaN contact impulse desiredDeltaV:" + desiredDeltaVelocity + " planarImp:" + planarImp);
                    System.out.println("velKill:" + velKill);
                }
//}                
            }
        } else {
            // If the motion along the contact 'plane' (ie: the non-reverse-penetrating motion) is
            // more than the frictional force of the contact then we need to break free and 
            // use dynamic friction.  Prior to that threshold, friction is like the object
            // is 'stuck' at that contact point in a sense.       
            double planarImp = Math.sqrt(impContact.y * impContact.y + impContact.z * impContact.z);
            if( planarImp > Math.abs(impContact.x * friction) ) {
                // We need to use dynamic friction
                impContact.y /= planarImp;
                impContact.z /= planarImp;
                    
                impContact.x = vDelta.m00 
                            + vDelta.m01 * friction * impContact.y
                            + vDelta.m02 * friction * impContact.z;
                impContact.x = desiredDeltaVelocity / impContact.x;
                impContact.y *= friction * impContact.x;
                impContact.z *= friction * impContact.x; 
            }
            if( impContact.isNaN() ) {        
                System.out.println("NaN contact impulse desiredDeltaV:" + desiredDeltaVelocity + " planarImp:" + planarImp);
                System.out.println("velKill:" + velKill);
            }
        }
 
        return impContact;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("Contact")
                .add("cp", contactPoint)
                .add("cn", contactNormal)
                .add("p", penetration)
                .add("f", friction)
                .add("r", restitution)
                .add("b1", body1)
                .add("b2", body2)
                .toString();        
    }
}


