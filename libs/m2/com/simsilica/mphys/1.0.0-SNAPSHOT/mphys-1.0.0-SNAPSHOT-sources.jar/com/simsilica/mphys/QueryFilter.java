/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

/**
 *  Defines the type of objects to check in contact and hit queries.
 *
 *  @author    Paul Speed
 */
public class QueryFilter<K, S extends AbstractShape> {
    public static final int TYPE_WORLD = 0x1;
    public static final int TYPE_STATIC = 0x2;
    public static final int TYPE_INACTIVE = 0x4;
    public static final int TYPE_ACTIVE = 0x8;
    public static final int TYPE_ALL = 0xff;
 
    private int flags;
    private Predicate<? super RigidBody<K, S>> rigidBodyFilter;
    private Predicate<? super StaticBody<K, S>> staticBodyFilter;
    
    public QueryFilter( int flags ) {
        this(flags, Predicates.alwaysTrue(), Predicates.alwaysTrue());
    }

    public QueryFilter( int flags, 
                        Predicate<? super RigidBody<K, S>> rigidBodyFilter,
                        Predicate<? super StaticBody<K, S>> staticBodyFilter ) {
        this.flags = flags;
        this.rigidBodyFilter = rigidBodyFilter;
        this.staticBodyFilter = staticBodyFilter;
    }
    
    public Predicate<? super RigidBody<K, S>> getRigidBodyFilter() {
        return rigidBodyFilter;
    } 

    public Predicate<? super StaticBody<K, S>> getStaticBodyFilter() {
        return staticBodyFilter;
    } 
    
    public boolean includeWorld() {
        return (flags & TYPE_WORLD) != 0;
    }
    
    public boolean includeStatic() {
        return (flags & TYPE_STATIC) != 0;
    }
    
    public boolean includeInactive() {
        return (flags & TYPE_INACTIVE) != 0;
    }
    
    public boolean includeActive() {
        return (flags & TYPE_ACTIVE) != 0;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + Integer.toBinaryString(flags) + "]";
    }
}
