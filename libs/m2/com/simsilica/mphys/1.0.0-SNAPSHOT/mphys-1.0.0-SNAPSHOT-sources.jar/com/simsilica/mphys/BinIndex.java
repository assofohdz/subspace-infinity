/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;
import com.google.common.reflect.TypeToken;

import com.simsilica.mathd.*;

/**
 *  Keeps track of the loaded bins and the RigidBody-to-Bin relationships.
 *  The 'bins' are a way to partition the world in such a way that only
 *  the active physics zones need computation applied.  As bins are
 *  loaded/unloaded the objects in them are given physical bodies or
 *  physical bodies are cleared.
 *
 *  <p>A bin is "loaded" if it is active or if it is next to a bin that is
 *  active.  A loaded bin will have all of its contained static and rigid
 *  bodies "realized" by calling the BinListener.  The application's
 *  BinListener implementation will then tell the bin to add the bodies
 *  to the bin based on the application's game object implementation.
 *  The bodies themselves are created by calling the application's
 *  PhysicsFactory.<p>
 *
 *  <p>The typical lifecycle is that the game indicates that some object
 *  should be activated.  If the bin that would contain that object has
 *  not been loaded then it is "loaded".  Loading the bin calls the
 *  application-specific BinListener which will figure out which objects
 *  are in that bin and tell the Bin about them.  The Bin will then call
 *  the application-specific PhysicsFactory to create the static and
 *  rigid bodies as required.</p>
 *
 *  <p>Calls to most of the methods on this class need to be aware
 *  that a body may not exist at the time of the call.  Some methods
 *  can be used to force activation while others will passively return
 *  null if a particular object is not currently being handled by the
 *  physics engine.</p>
 *
 *  <p>Note: A body (static or rigid) will only ever be in one Bin
 *  at a time.  The physics engine takes care of neighboring-bin collisions
 *  so that objects do not need to be duplicated across bins.</p>
 *
 *  @author    Paul Speed
 */
public class BinIndex<K, S extends AbstractShape> {

    static Logger log = LoggerFactory.getLogger(BinIndex.class);

    private final Grid grid;
    private final Vec3i gridRadius;

    private final Map<GridCell, Bin<K, S>> bins = new HashMap<>();

    private final DynArray<Bin<K, S>> activeBins
                = new DynArray<>(new TypeToken<Bin<K, S>>() {});

    private Set<Bin<K, S>> pendingUnload = new HashSet<>();

    private Map<Bin<K, S>, Neighborhood> neighborhoods = new HashMap<>();

    private final DynArray<BinListener<K, S>> binListeners = new DynArray<>(new TypeToken<BinListener<K, S>>() {});

    private PhysicsFactory<K, S> factory;
    private Map<K, RigidBodyEntry> rigidBodies = new HashMap<>();
    private Map<K, StaticBody<K, S>> staticBodies = new HashMap<>();

    private Map<K, Joint<K, S>> jointIndex = new HashMap<>();
    private ListMultimap<RigidBody<K, S>, Joint<K, S>> bodyJoints = ArrayListMultimap.create();
    private final DynArray<Joint<K, S>> activeJoints
                = new DynArray<>(new TypeToken<Joint<K, S>>() {});

    public BinIndex( Grid grid ) {
        this(grid, null);

    }

    public BinIndex( Grid grid, Vec3i gridRadius ) {
        this.grid = grid;
        if( gridRadius != null ) {
            this.gridRadius = gridRadius;
        } else {
            // Guess the default grid radius based on the type of grid
            int xd = grid.getSpacing().x != 0 ? 1 : 0;
            int yd = grid.getSpacing().y != 0 ? 1 : 0;
            int zd = grid.getSpacing().z != 0 ? 1 : 0;
            this.gridRadius = new Vec3i(xd, yd, zd);
        }
    }

    public Set<K> getBodyIds() {
        return rigidBodies.keySet();
    }

    public Set<K> getStaticBodyIds() {
        return staticBodies.keySet();
    }

    /**
     *  Note: this must be called on the same thread that's running the physics simulation.
     */
    public void writeDebugInfo( java.io.PrintWriter out ) {
        out.println("Total bin count:" + bins.size());
        for( Map.Entry<GridCell, Bin<K, S>> e : bins.entrySet() ) {
            e.getValue().writeDebugInfo(out);
            if( pendingUnload.contains(e.getValue()) ) {
                out.println("  ** pending unload **");
            }
        }
        out.println("----------------------------");
        out.println("Rigid body entries:");
        for( RigidBodyEntry e : rigidBodies.values() ) {
            out.println("    " + e);
        }
    }

    public final int size() {
        return bins.size();
    }

    public final int getActiveBinCount() {
        return neighborhoods.size();
    }

    public final int getActiveJointCount() {
if( activeJoints.size() != jointIndex.size() ) {
    log.warn("active joints:" + activeJoints.size() + "  joints:" + jointIndex.size());
}
        return activeJoints.size();
    }

    public final int getRigidBodyCount() {
        return rigidBodies.size();
    }

    public Grid getGrid() {
        return grid;
    }

    public Vec3i getGridRadius() {
        return gridRadius;
    }

    public void setPhysicsFactory( PhysicsFactory<K, S> factory ) {
        this.factory = factory;
    }

    public PhysicsFactory<K, S> getPhysicsFactory() {
        return factory;
    }

    public void addBinListener( BinListener<K, S> l ) {
        l.initialize(this);
        binListeners.add(l);
    }

    public void removeBinListener( BinListener<K, S> l ) {
        binListeners.remove(l);
        l.terminate(this);
    }

    protected void fireBinLoaded( Bin<K, S> bin ) {
        for( BinListener<K, S> l : binListeners.getArray() ) {
            l.loaded(bin);
        }
    }

    protected void fireBinStatusChanged( Bin<K, S> bin, Bin.Status status ) {
        for( BinListener<K, S> l : binListeners.getArray() ) {
            l.statusChanged(bin, status);
        }
    }

    protected void fireBinUnloaded( Bin<K, S> bin ) {
        for( BinListener<K, S> l : binListeners.getArray() ) {
            l.unloaded(bin);
        }
    }

    /**
     *  Activate the bin containing the specified location.  If the bin has
     *  not already been loaded then it will be loaded.
     */
    public void activate( Vec3d location ) {
        GridCell cell = grid.getContainingCell(location);
        activate(cell);
    }

    /**
     *  Causes the physics system to activate the specified bin.
     */
    public void activate( GridCell cell ) {
        getBin(cell, true);
    }

    /**
     *  Called to indicate that an object is likely to reactivate because
     *  of new contacts or additional information or because it was manually
     *  woken up.
     */
    public void activate( RigidBody<K, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("activate(" + body.id + ") bin:" + getBin(body));
        }
        RigidBodyEntry entry = getRigidBodyEntry(body.id, false);
        entry.setActive(true);
    }

    public void deactivate( RigidBody<K, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("deactivate(" + body.id + ") bin:" + getBin(body));
        }
        RigidBodyEntry entry = getRigidBodyEntry(body.id, false);
        entry.setActive(false);
    }

    /**
     *  Returns the RigidBody for the specified ID if that body is
     *  currently active in the physics space.
     */
    public RigidBody<K, S> getRigidBody( K id ) {
        RigidBodyEntry entry = getRigidBodyEntry(id, false);
        return entry == null ? null : entry.body;
    }

    /**
     *  Returns the StaticBody for the specified ID if that body is
     *  currently active in the physics space.
     */
    public StaticBody<K, S> getStaticBody( K id ) {
        return staticBodies.get(id);
    }

    // There are two modes with which a caller will interact with the
    // BinIndex:
    // 1) we are loading a specific bin and trying to add all of the objects
    //    in that bin.
    // 2) we know that an object is new but do not (yet) know what bin
    //    it should be in.
    //
    // Originally, we made the caller look up the bin based on the object's
    // location.  This has a few problems.  First, the caller may not know
    // best what the physics engine considers the location to be.  Second,
    // the object may already be loaded and then we did extra (potentially
    // wrong) work to find a bin we didn't need to.
    //
    // As such, now we provide addRigidBody(id)/addStaticBody(id) methods
    // for these one-off cases.  This also matches what we were already doing
    // with remove()... which was a case where we definitely know better than
    // the caller what bin the body is in.
    // However, this add stuff goes a little further into diluting the already
    // confusing plethora of "add" methods.
    //
    // These new methods are more straight forward:
    // addBody(id)
    //   -create body if it doesn't exist
    //   -find its bin
    //   -directly add it to the bin
    //      -refresh the bin status
    //
    // The bin case is weirder:
    // bin.addBody(id)
    //   -call BinIndex.addBodyToBin(this, id)
    //   -create the body if it doesn't exist
    //   -looks up the real bin
    //   -directly adds it to the real bin
    //      -refresh the bin status
    //   -warns about a different bin
    //
    // We don't get a lot of advantage by having the separate calls since
    // the bin-specific "add" will already have to look up the real bin.
    // In the case of RigidBody, this is unavoidable because we keep a
    // RigidBodyEntry for each RigidBody and that already keeps track of the
    // bin so we know when it moves from one to another.
    // For static bins, it's possible that we could do optimizations if
    // we already know the bin is correct (bin.contains() style check).
    //
    // I don't even see how the current approach will get us a different
    // listener notification order (if we cared).
    //
    // The only "advantage" we get out of the current API is that we get a warning
    // when a bin.addBody() call gets the bin wrong.  But the reason we know that
    // is because it's so important that we get the right bin that we have to second
    // guess the caller.  We could just take the choice out of their hands.

    /**
     *  Makes sure that the specified RigidBody is loaded, loading the
     *  requisite bin as necessary.  If the object is already loaded then
     *  it is simply returned.
     */
    public RigidBody<K, S> addRigidBody( K id ) {
        RigidBodyEntry entry = getRigidBodyEntry(id, true);
        return entry.body;
    }

    /**
     *  Makes sure that the specified StaticBody is loaded, loading the
     *  requisite bin as necessary.  If the object is already loaded then
     *  it is simply returned.
     */
    public StaticBody<K, S> addStaticBody( K id ) {
        StaticBody<K, S> body = getStaticBody(id, true);

        // Find the bin for the body
        Bin<K, S> bin = getBin(body.position, true);
        bin.add(body);

        return body;
    }

    /**
     *  Called to indicate that an object no longer exists and should
     *  be removed from the physics space.  Returns the body if the object
     *  existed in some bin and was removed.  Returns null if the object
     *  was not a current body.
     */
    public AbstractBody<K, S> remove( K bodyId ) {
        //if( log.isTraceEnabled() ) {
        //    log.trace("remove(" + bodyId + ")");
        //}
        RigidBodyEntry entry = rigidBodies.remove(bodyId);
        if( log.isTraceEnabled() ) {
            log.trace("remove(" + bodyId + ") hasRigidBody:" + (entry != null));
        }
        if( entry != null ) {
            // Rigid body is the easy one
            entry.release();

            // Remove any joints connected to this body
            removeJoints(entry.body);

            return entry.body;
        }

        // For static bodies, we have to look up the bin manually
        StaticBody<K, S> sb = staticBodies.remove(bodyId);
        if( sb == null ) {
            if( log.isTraceEnabled() ) {
                log.trace("No entry or static object exists for:" + bodyId);
            }
            return null;
        }

        // We need to remove it from its bin since we don't
        // have entry objects for static objects.
        Bin<K, S> bin = getBin(sb.position, false);
        if( bin != null ) {
            bin.remove(sb);
        } else {
            // We have no active bin but somehow have still indexed the object
            log.error("Removed stale static body from the master index:" + bodyId);
        }

        return sb;
    }

    /**
     *  Called to teleport the object with the specified ID.  Either
     *  loc or orient can be null and only the non-null value will be
     *  applied.  Returns true if the body existed and was updated.
     *  Returns false if the body did not exist and so was not updated.
     */
    public boolean teleport( K id, Vec3d loc, Quatd orient ) {
        RigidBodyEntry entry = getRigidBodyEntry(id, false);
        if( entry == null ) {
            return false;
        }
        entry.body.teleport(loc, orient);

        // Make sure it gets moved to the proper bin
        entry.update();

        // Make sure it's activated if it wasn't before.
        entry.setActive(true);

        return true;
    }

    /**
     *  Change the shape of a body.  Returns true if the object exists in
     *  the physics space and was changed.  False if the object isn't currently
     *  in the loaded physics space.
     */
    public boolean morph( K id, S shape ) {
        RigidBodyEntry entry = getRigidBodyEntry(id, false);
        if( entry == null ) {
            return false;
        }
        entry.body.morph(shape);

        // I don't think anything else needs to be done because we don't
        // use the bounds for anything.

        return true;
    }

    /**
     *  Called to update the current bin-related indexing for
     *  the specified body.
     */
    public void update( RigidBody<K, S> body ) {
        RigidBodyEntry entry = getRigidBodyEntry(body.id, false);
        entry.update();
    }

    /**
     *  Applies a one-time velocity change to the specified body, activating
     *  and loading it if necessary.  If the object doesn't exist then false
     *  is returned.  Note: this specific method may be modified to something
     *  more general as impulse/force requirements expand.
     */
    public boolean applyImpulse( K id, Vec3d impulse ) {
        RigidBodyEntry entry = getRigidBodyEntry(id, true);
        if( entry == null ) {
            return false;
        }
        entry.body.addLinearVelocity(impulse);
        entry.setActive(true);
        return true;
    }

    public Bin<K, S>[] getActiveBins() {
        return activeBins.getArray();
    }

    public DynArray<Joint<K, S>> getActiveJoints() {
        return activeJoints;
    }

    public Bin<K, S> getBin( Vec3d location, boolean create ) {
        GridCell cell = grid.getContainingCell(location);
        return getBin(cell, create);
    }

    public Bin<K, S> getBin( GridCell cell, boolean create ) {
        Bin<K, S> result = bins.get(cell);
        if( result == null && create ) {
            result = new Bin<>(this, cell);
            bins.put(cell, result);
            fireBinLoaded(result);

            // Add it to the pending unload queue in case it never
            // gets filled and never gets used.  This should be ok
            markForUnload(result);
        }
        return result;
    }

    public Bin<K, S> getBin( RigidBody<K, S> body ) {
        RigidBodyEntry entry = getRigidBodyEntry(body.id, false);
        return entry.bin;
    }

    public Bin<K, S>[] getNeighbors( Bin<K, S> bin ) {
        Neighborhood n = neighborhoods.get(bin);
        if( n == null ) {
            return null;
        }
        return n.neighbors;
    }

    protected void activate( Bin<K, S> bin ) {
        Neighborhood n = neighborhoods.get(bin);
        if( n == null ) {
            n = new Neighborhood(bin);
            neighborhoods.put(bin, n);
            n.acquire();
            activeBins.add(bin);
        } else {
            // This shouldn't happen
            throw new RuntimeException("*** How did this happen?");
        }
    }

    protected void deactivate( Bin<K, S> bin ) {
        Neighborhood n = neighborhoods.remove(bin);
        if( n != null ) {
            n.release();
            activeBins.remove(bin);
        } else {
            // This shouldn't happen
            throw new RuntimeException("*** How did this happen?");
        }
    }

    protected void markForUnload( Bin<K, S> bin ) {
        if( log.isTraceEnabled() ) {
            log.trace("marked for unloading:" + bin);
        }
        pendingUnload.add(bin);
    }

    private void unload( Bin<K, S> bin ) {
        Bin<K, S> removed = bins.remove(bin.getGridCell());
        if( log.isTraceEnabled() ) {
            log.trace("unloading:" + removed);
        }

        // This is the part that's more expensive with a central index
        // but we'll at least limit it to the dynamic objects
        for( RigidBody<K, S> body : bin.getActiveObjects() ) {
            unloadRigidBody(body.id);
        }
        for( RigidBody<K, S> body : bin.getInactiveObjects() ) {
            unloadRigidBody(body.id);
        }

        // 2021-02-07 - but if we don't do the static objects then
        // how will that cache get cleared?
        for( StaticBody<K, S> body : bin.getStaticObjects() ) {
            unloadStaticBody(body.id);
        }

        fireBinUnloaded(bin);
    }

    public final void flushPending() {
        if( log.isTraceEnabled() ) {
            log.trace("flushPending()");
        }
        if( pendingUnload.isEmpty() ) {
            return;
        }
        for( Bin<K, S> bin : pendingUnload ) {
            if( log.isTraceEnabled() ) {
                log.trace("Checking bin:" + bin + "  watchersCount:" + bin.getWatchersCount() + "  status:" + bin.getStatus());
            }
            if( bin.getWatchersCount() == 0 && bin.getStatus() != Bin.Status.Active ) {
                unload(bin);
            }
        }
        pendingUnload.clear();
    }

    @SuppressWarnings("unchecked")
    private Bin<K, S>[] findNeighbors( Bin<K, S> bin ) {
        //// Calculate a 3x3 grid without the center
        //// over the number of dimensions that the grid covers.
        //// ie: 2D 3x3, 3D 3x3x3
        //int dimensions = grid.getDimensions();
        //int size = (int)Math.pow(3, dimensions) - 1;
        //Bin[] neighbors = new Bin[size];
        //int pos = 0;
        //Vec3i cell = bin.getGridCell().getCell();
        //int xd = grid.getSpacing().x != 0 ? 1 : 0;
        //int yd = grid.getSpacing().y != 0 ? 1 : 0;
        //int zd = grid.getSpacing().z != 0 ? 1 : 0;
        // 2024-12-08
        // BinIndex now allows more specific control over the grid radius and that
        // also means that we don't need to recalculate it every time.  It turns
        // out that there was a "really 2D grid" case that the above didn't cover
        // and that's when we've specified a 'y' value so large as to always encompass
        // anything in the world, ie: really tall zones.
        int xd = gridRadius.x;
        int yd = gridRadius.y;
        int zd = gridRadius.z;

        int size = (xd * 2 + 1) * (yd * 2 + 1) * (zd * 2 + 1);
        Bin[] neighbors = new Bin[size - 1];  // -1 because we don't include the center
        int pos = 0;

        // Look all around the center cell and grab the neighbors
        Vec3i cell = bin.getGridCell().getCell();
        for( int x = cell.x - xd; x <= cell.x + xd; x++ ) {
            for( int y = cell.y - yd; y <= cell.y + yd; y++ ) {
                for( int z = cell.z - zd; z <= cell.z + zd; z++ ) {
                    if( cell.x == x && cell.y == y && cell.z == z ) {
                        // It's the center... so skip it
                        continue;
                    }
                    neighbors[pos++] = getBin(grid.getGridCell(x, y, z), true);
                }
            }
        }

        return (Bin<K, S>[])neighbors;
    }

    /**
     *  Called by a bin to add a new object to the physics space on behalf of
     *  that bin.  The object will be 'loaded', ie: created, at this time.
     */
    protected RigidBody<K, S> addRigidBodyToBin( Bin<K, S> bin, K bodyId ) {
        // Creation of the RigidBodyEntry will automatically add the object
        // to the bin.
        RigidBodyEntry entry = getRigidBodyEntry(bodyId, true);
        if( entry.bin != bin ) {
            log.warn("Object " + bodyId + " is not in target bin:" + bin + " and has been rehomed to:" + entry.bin);
        }
        return entry.body;
    }

    ///**
    // *  Called by a bin to remove an existing object from the physics space
    // *  on behalf of a particular bin.  The bin isn't really necessary except
    // *  for sanity checking.
    // */
    //protected RigidBody<K, S> removeRigidBodyFromBin( Bin<K, S> bin, K bodyId ) {
    //    // Note: other than the sanity check, this could/should call remove(bodyId)
    //    RigidBodyEntry entry = rigidBodies.remove(bodyId);
    //    if( entry.bin != bin ) {
    //        log.warn("Object " + bodyId + " is not in bin:" + bin + " to be removed.  Removing it from real bin:" + entry.bin);
    //    }
    //    entry.release();
    //
    //    // Remove any joints connected to this body
    //    removeJoints(entry.body);
    //
    //    return entry.body;
    //}

    /**
     *  Called by a bin to add a new object to the physics space on behalf of
     *  that bin.  The object will be 'loaded', ie: created, at this time.
     */
    protected StaticBody<K, S> addStaticBodyToBin( Bin<K, S> bin, K bodyId ) {
        // Create the body if necessary
        StaticBody<K, S> body = getStaticBody(bodyId, true);

        // Find the bin for the body and add it
        Bin<K, S> bodyBin = getBin(body.position, true);
        bodyBin.add(body);

        if( bodyBin != bin ) {
            log.warn("Object " + bodyId + " is no in bin:" + bin + " to be added.  Adding it to the real bin:" + bodyBin);
        }

        return body;
    }

    ///**
    // *  Called by a bin to remove an existing object from the physics space
    // *  on behalf of a particular bin.  The bin isn't really necessary except
    // *  for sanity checking.
    // */
    //protected StaticBody<K, S> removeStaticBodyFromBin( Bin<K, S> bin, K bodyId ) {
    //
    //    StaticBody<K, S> body = staticBodies.remove(bodyId);
    //    if( body == null ) {
    //        log.warn("Removed static body:" + bodyId + " is not in master index.  Bin:" + bin);
    //        return null;
    //    }
    //
    //    // Find the bin for the body and remove it
    //    Bin<K, S> bodyBin = getBin(body.position, false);
    //    if( bodyBin != null ) {
    //        bodyBin.remove(body);
    //    }
    //    if( bodyBin != bin ) {
    //        log.warn("Object " + bodyId + " is not in bin:" + bin + " to be removed.  Removed it from real bin:" + bodyBin);
    //    }
    //    // And remove it from the reported bin just in case
    //    bin.remove(body);
    //
    //    return body;
    //}

    protected RigidBodyEntry getRigidBodyEntry( K key, boolean create ) {
        RigidBodyEntry result = rigidBodies.get(key);
        if( result == null && create ) {
            if( log.isDebugEnabled() ) {
                log.debug("Creating RigidBody for:" + key);
            }
            RigidBody<K, S> body = factory.createRigidBody(key);
            result = new RigidBodyEntry(body);
            rigidBodies.put(key, result);
        }
        return result;
    }

    /**
     *  Called during bin unloading... does not need to do further object
     *  unloading from the bin.  It's called to clean up any central
     *  indexing or caching.  We also clean up connected joints here.
     */
    protected void unloadRigidBody( K key ) {
        RigidBodyEntry entry = rigidBodies.remove(key);

        // Remove any joints connected to this body
        removeJoints(entry.body);
    }

    protected void removeJoints( RigidBody<K, S> body ) {

        // Remove any joints connected to this body
        for( Joint<K, S> joint : bodyJoints.removeAll(body) ) {
            jointIndex.remove(joint.getId());
            activeJoints.remove(joint);

            // And check to see if the joint has another end that
            // it should be also removed from
            RigidBody<K, S> other = joint.getOtherBody(body);
            if( other != null ) {
                bodyJoints.remove(other, joint);
            }
        }
    }

    protected StaticBody<K, S> getStaticBody( K key, boolean create ) {
        StaticBody<K, S> result = staticBodies.get(key);
        if( result == null && create ) {
            result = factory.createStaticBody(key);
            staticBodies.put(key, result);
        }
        return result;
    }

    protected void unloadStaticBody( K key ) {
        StaticBody<K, S> body = staticBodies.remove(key);
    }

    protected void addJointToBin( Bin<K, S> bin, K jointId, K bodyId1, K bodyId2 ) {
        // Joints are not really kept in bins... but we follow the pattern just the same.

        if( log.isDebugEnabled() ) {
            log.debug("addJoint(" + bin + ", " + jointId + ", " + bodyId1 + ", " + bodyId2 + ")");
        }

        // First see if we already created this joint
        Joint<K, S> joint = jointIndex.get(jointId);
        if( joint != null ) {
            log.debug("Joint already exists for:" + jointId);
            // Done
            return;
        }

        if( bodyId2 != null ) {
            // It's a body->body joint and requires special care to make sure
            // both end's bin are loaded properly.

            // Grabbing both endpoints and creating them if needed should
            // be enough.  We'll either be creating them fresh or we'll be
            // reloading objects that are already there.  If we are creating
            // them fresh then it's likely that their bins might be loaded
            // also.  If that's the case then addJointToBin() will be called
            // for the 'other end' and by that point the joint's endpoints
            // will be fully available and the joint will get created and
            // indexed.
            //
            // So, if after loading both endpoints, we check again and the joint
            // exists then there is nothing more to do.

            // Grab the entries for both ends, possible creating them, loading
            // their bins, etc..  (Our bin will have already been created anyway.)
            RigidBodyEntry end1 = getRigidBodyEntry(bodyId1, true);
            RigidBodyEntry end2 = getRigidBodyEntry(bodyId2, true);

            log.debug("retrieved end1:" + end1 + "  end2:" + end2);

            // Now, it's possible that loading one of those ends caused the
            // joint to be created... in which case we don't need to.  So
            // we'll check.
            joint = jointIndex.get(jointId);
            if( joint != null ) {
                log.debug("Joint:" + jointId + " loaded by other bin.");
                return;
            }

            // Else now we have everything we need to create the joint
            joint = factory.createJoint(jointId, end1.body, end2.body );
            log.debug("created joint:" + jointId);
            jointIndex.put(jointId, joint);
            activeJoints.add(joint);
            bodyJoints.put(end1.body, joint);
            bodyJoints.put(end2.body, joint);
        } else {
            // It's a single endpoint joint and those are much easier to deal with
            RigidBodyEntry end1 = getRigidBodyEntry(bodyId1, true);

            log.debug("retrieved end1:" + end1);

            // Now... just in case, we'll check to see if creating that entry
            // also loaded the joint behind our backs.  It's theoretically only
            // possible if the joint was associated with the wrong bin to begin with.
            joint = jointIndex.get(jointId);
            if( joint != null ) {
                log.warn("Single ended joint:" + jointId + " loaded by other bin.");
                return;
            }

            // Else now we have everything we need to create the joint
            joint = factory.createJoint(jointId, end1.body, null);
            log.debug("created joint:" + jointId);
            jointIndex.put(jointId, joint);
            activeJoints.add(joint);
            bodyJoints.put(end1.body, joint);
        }
    }

    public void removeJointFromBin( Bin<K, S> bin, K jointId ) {
        if( log.isDebugEnabled() ) {
            log.debug("removeJoint(" + bin + ", " + jointId + ")");
        }

        // Find the joint
        Joint<K, S> joint = jointIndex.remove(jointId);
        if( joint == null ) {
            log.warn("No joint found for:" + jointId + " in removeJointFromBin()");
            return;
        }

        // Remove it from the reverse index
        bodyJoints.remove(joint.getMainBody(), joint);
        activeJoints.remove(joint);
        if( joint.getAltBody() != null ) {
            bodyJoints.remove(joint.getAltBody(), joint);
        }
    }

    private class Neighborhood {
        Bin<K, S> bin;
        Bin<K, S>[] neighbors;

        public Neighborhood( Bin<K, S> bin ) {
            this.bin = bin;
            this.neighbors = findNeighbors(bin);
        }

        protected void acquire() {
            for( Bin<K, S> bin : neighbors ) {
                bin.updateWatchersCount(1);
            }
        }

        protected void release() {
            for( Bin<K, S> bin : neighbors ) {
                bin.updateWatchersCount(-1);
            }
        }
    }

    protected class RigidBodyEntry {

        final RigidBody<K,S> body;
        Bin<K, S> bin;
        boolean active;

        public RigidBodyEntry( RigidBody<K,S> body ) {
            this.body = body;
            this.active = !body.isSleepy();

            // Set the bin and make sure the object belongs to it
            bin = getBin(body.position, true);
            if( log.isDebugEnabled() ) {
                log.debug("Adding " + body.id + " to:" + bin);
            }
            bin.add(body, active);
        }

        public void setActive( boolean active ) {
            if( this.active == active ) {
                return;
            }
            this.active = active;
            if( active ) {
                bin.activate(body);
            } else {
                bin.deactivate(body);
            }
        }

        public void update() {
            // See if we are still in the same bin
            if( bin.contains(body.position) ) {
                // Yep
                return;
            }

            if( log.isTraceEnabled() ) {
                log.trace(body.id + " is leaving " + bin);
            }

            bin.remove(body, active);
            // I sort of feel like the removal from the existing bin
            // was important to do before retrieving the next bin
            // but I cannot prove it right now.

            // Need to move it
            bin = getBin(body.position, true);

            if( log.isTraceEnabled() ) {
                log.trace(body.id + " is entering " + bin);
            }

            bin.add(body, active);
        }

        /**
         *  Removes it from its current bin so that it can 'die'.
         */
        public void release() {
            bin.remove(body, active);
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[body=" + body.id + ", bin=" + bin + ", active=" + active + "]";
        }
    }
}
