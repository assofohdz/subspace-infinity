/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.List;

/**
 *  Implementations of ContactResolver employ a particular strategy for
 *  resolving a set of contacts between objects.
 *
 *  @author    Paul Speed
 */
public interface ContactResolver<K, S extends AbstractShape> {

    /**
     *  Sets the listener that will be notified about each new contact on
     *  a frame.  This is usually done as part of the resolveContacts() internal
     *  loop.  The listener can either dispatch to other listeners or deal
     *  with the contacts itself.
     *
     *  <p>Listeners are called before contacts are resolved and so are allowed
     *  to make modifications to contact, for example: setting restitution, friction,
     *  disabling bodies, etc..</p>
     *
     *  <p>Default value is a no-op listener.</p>
     */
    //public void setContactDispatcher( ContactListener<K, S> listener );
    
    //public ContactListener<K, S> getContactDispatcher();

    public void resolveContacts( List<Contact<K, S>> contacts, List<Joint<K, S>> joints, double step );
}
