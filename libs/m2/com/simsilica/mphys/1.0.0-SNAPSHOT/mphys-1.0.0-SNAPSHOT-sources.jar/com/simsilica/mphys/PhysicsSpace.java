/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Predicate;
import com.google.common.reflect.TypeToken;

import com.simsilica.mathd.Grid;
import com.simsilica.mathd.GridCell;
import com.simsilica.mathd.Quatd;
import com.simsilica.mathd.Rayd;
import com.simsilica.mathd.Vec3d;
import com.simsilica.mathd.Vec3i;
import com.simsilica.mathd.filter.SimpleMovingMean;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PhysicsSpace<K, S extends AbstractShape> {

    static Logger log = LoggerFactory.getLogger(PhysicsSpace.class);

    private CollisionSystem<K, S> collisionSystem;
    //private List<Contact<K, S>> contacts = new ArrayList<>();

    // Keep track of the contacts for the current physics frame.
    private ContactAccumulator<K, S> contactAccumulator = new ContactAccumulator<>();

    // Keep a separate listener in case we need to wrap it for delegation/filtering
    // by the calling code.
    private ContactListener<K, S> contactListener = contactAccumulator;
    private ContactResolver<K, S> contactResolver = new TandemContactResolver<>();

    private int activeObjectCount;

    private BinIndex<K, S> binIndex;

    // Optional second index for static-only large structures that span
    // multiple fine bins.  Null if the application didn't configure one.
    private BinIndex<K, S> largeStaticIndex;
    private LargeStaticBinDriver<K, S> largeStaticDriver;

    private final DynArray<PhysicsListener<K, S>> listeners = new DynArray<>(new TypeToken<PhysicsListener<K, S>>() {});

    private boolean tandemJointResolution = false;

    private PhysicsStats stats = new PhysicsStats();
    private PhysicsStats.Stat contactCountStat;
    private PhysicsStats.Stat contactGenTimeStat;
    private PhysicsStats.Stat contactResTimeStat;
    private PhysicsStats.Stat integrationTimeStat;
    private PhysicsStats.Stat driverTimeStat;
    private PhysicsStats.Stat binUpdateTimeStat;
    private PhysicsStats.Stat frameTimeStat;
    private PhysicsStats.Stat binCountStat;
    private PhysicsStats.Stat activeBinCountStat;
    private PhysicsStats.Stat bodyCountStat;
    private PhysicsStats.Stat activeBodyCountStat;
    private boolean collectStats = true;

    public PhysicsSpace( Grid binGrid ) {
        this(binGrid, null);
    }

    public PhysicsSpace( Grid binGrid, Vec3i gridRadius ) {
        this(binGrid, gridRadius, null, null);
    }

    /**
     *  Creates a PhysicsSpace with both a fine bin grid and a coarser
     *  static-only bin grid for large structures that span multiple fine
     *  bins.  The coarse grid spacing must be an integer multiple of the
     *  fine grid spacing and share the same origin so each fine bin nests
     *  fully inside exactly one coarse bin.
     *
     *  <p>If largeBinGrid is null the large-static support is disabled and
     *  this constructor behaves like {@link #PhysicsSpace(Grid, Vec3i)}.</p>
     */
    public PhysicsSpace( Grid binGrid, Vec3i gridRadius,
                         Grid largeBinGrid, Vec3i largeGridRadius ) {
        this.binIndex = new BinIndex<K, S>(binGrid, gridRadius);
        if( largeBinGrid != null ) {
            this.largeStaticIndex = new BinIndex<K, S>(largeBinGrid, largeGridRadius);
            this.largeStaticDriver = new LargeStaticBinDriver<>(largeStaticIndex);
            this.binIndex.addBinListener(largeStaticDriver);
        }
        ((TandemContactResolver)contactResolver).resolveJoints = tandemJointResolution;

        contactCountStat = stats.getStat(PhysicsStats.STAT_CONTACTS);
        contactGenTimeStat = stats.getStat(PhysicsStats.STAT_CONTACT_GEN_TIME, new SimpleMovingMean(60));
        contactResTimeStat = stats.getStat(PhysicsStats.STAT_CONTACT_RES_TIME, new SimpleMovingMean(60));
        integrationTimeStat = stats.getStat(PhysicsStats.STAT_INTEGRATION_TIME, new SimpleMovingMean(60));
        driverTimeStat = stats.getStat(PhysicsStats.STAT_DRIVER_TIME, new SimpleMovingMean(60));
        binUpdateTimeStat = stats.getStat(PhysicsStats.STAT_BIN_UPDATE_TIME, new SimpleMovingMean(60));
        frameTimeStat = stats.getStat(PhysicsStats.STAT_FRAME_TIME, new SimpleMovingMean(60));
        binCountStat = stats.getStat(PhysicsStats.STAT_BIN_COUNT);
        activeBinCountStat = stats.getStat(PhysicsStats.STAT_ACTIVE_BIN_COUNT);
        bodyCountStat = stats.getStat(PhysicsStats.STAT_BODY_COUNT);
        activeBodyCountStat = stats.getStat(PhysicsStats.STAT_ACTIVE_BODY_COUNT);
    }

    public void writeDebugInfo( java.io.PrintWriter out ) {
        out.println("Active object count:" + activeObjectCount);
        binIndex.writeDebugInfo(out);
        if( largeStaticIndex != null ) {
            out.println("=== Large static bin index ===");
            largeStaticIndex.writeDebugInfo(out);
        }
    }

    /**
     *  Provided mostly for debug access.
     */
    public BinIndex<K, S> getBinIndex() {
        return binIndex;
    }

    /**
     *  Returns the coarse static-only bin index used for large structures
     *  that span multiple fine bins, or null if the space was not created
     *  with a large grid.
     */
    public BinIndex<K, S> getLargeStaticBinIndex() {
        return largeStaticIndex;
    }

    public Grid getGrid() {
        return binIndex.getGrid();
    }

    public Grid getLargeGrid() {
        return largeStaticIndex == null ? null : largeStaticIndex.getGrid();
    }

    public void setPhysicsFactory( PhysicsFactory<K, S> factory ) {
        binIndex.setPhysicsFactory(factory);
        if( largeStaticIndex != null ) {
            largeStaticIndex.setPhysicsFactory(factory);
        }
    }

    public PhysicsFactory<K, S> getPhysicsFactory() {
        return binIndex.getPhysicsFactory();
    }

    public void addBinListener( BinListener<K, S> l ) {
        binIndex.addBinListener(l);
    }

    public void removeBinListener( BinListener<K, S> l ) {
        binIndex.removeBinListener(l);
    }

    public void addPhysicsListener( PhysicsListener<K, S> l ) {
        listeners.add(l);
    }

    public void removePhysicsListener( PhysicsListener<K, S> l ) {
        listeners.remove(l);
    }

    /**
     *  Sets the listener that will be notified about each new contact on
     *  a frame.  See ContactResolver for more information.
     */
    public void setContactDispatcher( ContactListener<K, S> listener ) {
        //contactResolver.setContactDispatcher(listener);
        if( listener == null ) {
            contactListener = contactAccumulator;
            return;
        }
        // Reset our filter to the new dispatcher
        contactListener = new FilteredContactListener<>(listener, contactAccumulator);
    }

    public ContactListener<K, S> getContactDispatcher() {
        //return contactResolver.getContactDispatcher();
        if( contactListener == contactAccumulator ) {
            return null;
        }
        return ((FilteredContactListener<K, S>)contactListener).getFilter();
    }

    public Bin.Status getBinStatus( GridCell cell ) {
        Bin bin = binIndex.getBin(cell, false);
        if( bin == null ) {
            return null;
        }
        return bin.getStatus();
    }

    public final PhysicsStats getStats() {
        return stats;
    }

    public final int getActiveObjectCount() {
        return activeObjectCount;
    }

    public final int getBinCount() {
        return binIndex.size();
    }

    public final int getActiveBinCount() {
        return binIndex.getActiveBinCount();
    }

    public final int getActiveJointCount() {
        return binIndex.getActiveJointCount();
    }

    public void setCollisionSystem( CollisionSystem<K, S> collisionSystem ) {
        this.collisionSystem = collisionSystem;
    }

    public CollisionSystem<K, S> getCollisionSystem() {
        return collisionSystem;
    }

    /**
     *  Called to teleport the object with the specified ID.  Either
     *  loc or orient can be null and only the non-null value will be
     *  applied.  Returns true if the body existed and was updated.
     *  Returns false if the body did not exist and so was not updated.
     */
    public boolean teleport( K id, Vec3d loc, Quatd orient ) {
        return binIndex.teleport(id, loc, orient);
    }

    /**
     *  Change the shape of a body.  Returns true if the object exists in
     *  the physics space and was changed.  False if the object isn't currently
     *  in the loaded physics space.
     */
    public boolean morph( K id, S shape ) {
        return binIndex.morph(id, shape);
    }

    /**
     *  Applies a one-time velocity change to a rigid body, activating it if necessary.
     *  Note: this specific method may be modified to something more general as impulse/force
     *  requirements expand.
     */
    public boolean applyImpulse( K id, Vec3d impulse ) {
        return binIndex.applyImpulse(id, impulse);
    }

    /**
     *  Checks the static and dynamic objects for Ray hits.  World queries
     *  should be done separately directly on the collision system.
     */
    public HitResults<K, S> queryHits( Rayd ray, HitResults<K, S> hits ) {

        // Poor man's way to check that we've visited the bins
        Set<Bin<K, S>> visited = new HashSet<>();

        // Go through every active bin and its neighbors
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            if( !visited.add(bin) ) {
                // Been here already
                continue;
            }
            collisionSystem.queryBodyHits(ray, bin.getActiveObjects().getArray(), hits);
            collisionSystem.queryBodyHits(ray, bin.getInactiveObjects().getArray(), hits);
            collisionSystem.queryStaticHits(ray, bin.getStaticObjects().getArray(), hits);

            // Then do the same for the neighbors
            for( Bin<K, S> neighbor : binIndex.getNeighbors(bin) ) {
                if( neighbor.getStatus() == Bin.Status.Active ) {
                    // Active bins will be visited by the outer loop, we only
                    // care about inactive bins here.
                    continue;
                }
                if( !visited.add(neighbor) ) {
                    continue;
                }

                collisionSystem.queryBodyHits(ray, neighbor.getInactiveObjects().getArray(), hits);
                collisionSystem.queryStaticHits(ray, neighbor.getStaticObjects().getArray(), hits);
            }
        }

        return hits;
    }

    /**
     *  Queries for contacts against the specified shape as if it
     *  was a body shape in the world.  Note: this will not activate
     *  physics zones and presumes the shape location is already an
     *  active zone.
     */
    public void queryContacts( Vec3d position, Quatd orientation, S shape, QueryFilter<K, S> filter, ContactListener<K,S> results ) {
        // We'll cheat and create a fake RigidBody... that way we
        // don't require any changes to CollisionSystem.
        RigidBody<K, S> standin = new RigidBody<>(null, shape, position, orientation);

        if( filter.includeWorld() ) {
            collisionSystem.generateWorldCollisions(standin, results);
        }
        boolean includeStatic = filter.includeStatic();
        boolean includeInactive = filter.includeInactive();
        boolean includeActive = filter.includeActive();

        Predicate<? super RigidBody<K, S>> rigidBodyFilter = filter.getRigidBodyFilter();
        Predicate<? super StaticBody<K, S>> staticBodyFilter = filter.getStaticBodyFilter();

        // Poor man's way to check that we've visited the bins
        Set<Bin<K, S>> visited = new HashSet<>();

        // Go through every active bin and its neighbors
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            if( !visited.add(bin) ) {
                // Been here already
                continue;
            }

            if( includeStatic ) {
                collisionSystem.generateStaticCollisions(standin, bin.getStaticObjects().getArray(),
                                                         staticBodyFilter, results);
            }
            if( includeInactive ) {
                collisionSystem.generateBodyCollisions(standin, bin.getInactiveObjects().getArray(),
                                                       rigidBodyFilter, results);
            }

            // Then do the same for the neighbors
            for( Bin<K, S> neighbor : binIndex.getNeighbors(bin) ) {
                if( neighbor.getStatus() == Bin.Status.Active ) {
                    // Active bins will be visited by the outer loop, we only
                    // care about inactive bins here.
                    continue;
                }
                if( !visited.add(neighbor) ) {
                    continue;
                }

                if( includeStatic ) {
                    collisionSystem.generateStaticCollisions(standin, neighbor.getStaticObjects().getArray(),
                                                             staticBodyFilter, results);
                }
                if( includeInactive ) {
                    collisionSystem.generateBodyCollisions(standin, neighbor.getInactiveObjects().getArray(),
                                                           rigidBodyFilter, results);
                }
            }

            if( includeActive ) {
                // The outer loop we also check for active
                collisionSystem.generateBodyCollisions(standin, bin.getActiveObjects().getArray(),
                                                       rigidBodyFilter, results);
            }
        }
    }

    /**
     *  Queries for bodies whose bounds intersect the specified frustum.
     */
    public Collection<AbstractBody<K, S>> queryBounds( QueryVolume queryVolume, QueryFilter<K, S> filter ) {
        // 2024-03-13: note: we should probably limit the scope of the bins based on
        // some min/max values or something.  If there are a bunch of players on then
        // the active bins + neighbors can be quite numerous.

        boolean includeStatic = filter.includeStatic();
        boolean includeInactive = filter.includeInactive();
        boolean includeActive = filter.includeActive();

        Predicate<? super RigidBody<K, S>> rigidBodyFilter = filter.getRigidBodyFilter();
        Predicate<? super StaticBody<K, S>> staticBodyFilter = filter.getStaticBodyFilter();

        Set<AbstractBody<K, S>> results = new HashSet<>();

        // Poor man's way to check that we've visited the bins
        Set<Bin<K, S>> visited = new HashSet<>();

        Vec3d temp = new Vec3d();

        // Go through every active bin and its neighbors
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            if( !visited.add(bin) ) {
                // Been here already
                continue;
            }

            if( includeStatic ) {
                for( StaticBody<K, S> body : bin.getStaticObjects().getArray() ) {
                    // Usually we expect these to run pretty fast so I'll do it first
                    // but really the frustum check is also very fast and might overall
                    // be faster than many types of predicate.
                    if( !staticBodyFilter.apply(body) ) {
                        continue;
                    }
                    // 2024-02-24
                    // It seems like the shapes are already adjusted only by the bounds center
                    // and do not take CoG offset into account... in which case their bounds
                    // radius is CoG relative.  This is assuming that CoG is 'model origin relative'
                    // in the first place... and if so then when the CoG and bounds center do not
                    // line up then that difference is the 'error' we are introducing here and
                    // in other loops.  It's easy to add it in but getWorldShapeOrigin() is already
                    // what we're using to calculate the 'object position' in networking space
                    // and that is not including it.  I think that's probably incorrect but until
                    // we fix that then there is little point in caring here.
                    // And for the record, this is just an approximation anyway.  Shape radius
                    // is already a super fuzzy way to detect objects in a frustum.
                    if( queryVolume.intersects(body.position, body.shape.getBoundsRadius()) ) {
                        results.add(body);
                    }
                }
            }
            if( includeInactive ) {
                for( RigidBody<K, S> body : bin.getInactiveObjects().getArray() ) {
                    if( !rigidBodyFilter.apply(body) ) {
                        continue;
                    }
                    if( queryVolume.intersects(body.position, body.shape.getBoundsRadius()) ) {
                        results.add(body);
                    }
                }
            }

            // Then do the same for the neighbors
            for( Bin<K, S> neighbor : binIndex.getNeighbors(bin) ) {
                if( neighbor.getStatus() == Bin.Status.Active ) {
                    // Active bins will be visited by the outer loop, we only
                    // care about inactive bins here.
                    continue;
                }
                if( !visited.add(neighbor) ) {
                    continue;
                }

                if( includeStatic ) {
                    for( StaticBody<K, S> body : neighbor.getStaticObjects().getArray() ) {
                        if( !staticBodyFilter.apply(body) ) {
                            continue;
                        }
                        if( queryVolume.intersects(body.position, body.shape.getBoundsRadius()) ) {
                            results.add(body);
                        }
                    }
                }
                if( includeInactive ) {
                    for( RigidBody<K, S> body : neighbor.getInactiveObjects().getArray() ) {
                        if( !rigidBodyFilter.apply(body) ) {
                            continue;
                        }
                        if( queryVolume.intersects(body.position, body.shape.getBoundsRadius()) ) {
                            results.add(body);
                        }
                    }
                }
            }

            if( includeActive ) {
                // The outer loop we also check for active
                for( RigidBody<K, S> body : bin.getActiveObjects().getArray() ) {
                    if( !rigidBodyFilter.apply(body) ) {
                        continue;
                    }
                    if( queryVolume.intersects(body.position, body.shape.getBoundsRadius()) ) {
                        results.add(body);
                    }
                }
            }
        }

        return results;
    }

    protected void activate( RigidBody<K, S> body ) {
//log.debug("activate(" + body.id + "@" + System.identityHashCode(body) + ")");
        binIndex.activate(body);
    }

    protected void deactivate( RigidBody<K, S> body ) {
//log.debug("deactivate(" + body.id + "@" + System.identityHashCode(body) + ")");
        binIndex.deactivate(body);
    }

    protected final void fireStartFrame( long frameTime, double step ) {
        for( PhysicsListener<K, S> l : listeners.getArray() ) {
            l.startFrame(frameTime, step);
        }
    }

    protected final void fireAfterIntegrate( long frameTime, double step ) {
        for( PhysicsListener<K, S> l : listeners.getArray() ) {
            l.afterIntegrate(frameTime, step);
        }
    }

    protected final void fireEndFrame() {
        for( PhysicsListener<K, S> l : listeners.getArray() ) {
            l.endFrame();
        }
    }

    protected final void fireObjectUpdate( RigidBody<K, S> body ) {
        for( PhysicsListener<K, S> l : listeners.getArray() ) {
            l.update(body);
        }
    }

    private boolean delayedResolve = false; //true;

    public void integrate( long frameTime, double step ) {
        if( collectStats ) {
            long start = System.nanoTime();
            doIntegrate(frameTime, step);
            long end = System.nanoTime();
            frameTimeStat.updateValue(end - start);

            binCountStat.updateValue(binIndex.size());
            activeBinCountStat.updateValue(binIndex.getActiveBinCount());
            bodyCountStat.updateValue(binIndex.getRigidBodyCount());
            activeBodyCountStat.updateValue(activeObjectCount);
        } else {
            doIntegrate(frameTime, step);
        }
    }

    private void doIntegrate( long frameTime, double step ) {

        // Notify listeners about frame start
        fireStartFrame(frameTime, step);

        if( delayedResolve ) {
            reactivateObjects();
            resolveContacts(step);
        }

        if( binIndex.getActiveBinCount() == 0 ) {
            // Even though we are skipping the frame, we may still need
            // to do pending cleanup
            binIndex.flushPending();
            if( largeStaticIndex != null ) {
                largeStaticIndex.flushPending();
            }

            // And we still need to notify the listeners about the frame end
            fireEndFrame();
            return;
        }

        // Apply control driver forces

        // Apply other forces
//resolveJoints(step);

        long start1 = System.nanoTime();
        long driverTime = 0;
        // Integrate all of the active objects
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            for( RigidBody<K, S> body : bin.getActiveObjects().getArray() ) {
                long s = System.nanoTime();
                body.updateDriver(frameTime, step);
                long e = System.nanoTime();
                if( collectStats ) {
                    driverTime += (e - s);
                }
                body.integrate(step);
//System.out.println("integrated body:" + body.id + "  pos:" + body.position);
            }
        }
        if( collectStats ) {
            integrationTimeStat.updateValue(System.nanoTime() - start1);
            driverTimeStat.updateValue(driverTime);
        }

        if( !tandemJointResolution ) {
            resolveJoints(step);
        }

        fireAfterIntegrate(frameTime, step);

        generateContacts();
        if( !delayedResolve ) {
            reactivateObjects();
            resolveContacts(step);
        }

        // Objects that were moved or changed as part of integration OR as
        // part of contact resolution should now be in the activeObjects array.
        long start2 = System.nanoTime();
        activeObjectCount = 0;
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            for( RigidBody<K, S> body : bin.getActiveObjects().getArray() ) {

                // Figure out which bin it belongs in now and move it.
                // Note: moving it might move it into a bin that we
                // haven't processed yet which means we'll end up hitting the
                // object twice.  So we'll use a frame marker to decide if we
                // should skip it or not
                if( body.lastUpdateFrame == frameTime ) {
                    // We already processed it this frame
                    continue;
                }
                body.lastUpdateFrame = frameTime;

                binIndex.update(body);

                activeObjectCount++;

                // Notify the listeners about object change
                fireObjectUpdate(body);

                // Deactivate objects that are asleep
                if( body.isSleepy() ) {
                    deactivate(body);

                    // We don't count it anymore
                    activeObjectCount--;
                }
            }
        }
        if( collectStats ) {
            binUpdateTimeStat.updateValue(System.nanoTime() - start2);
        }

        // Notify listeners about frame end
        fireEndFrame();

        binIndex.flushPending();
        if( largeStaticIndex != null ) {
            largeStaticIndex.flushPending();
        }
    }

    protected void generateContacts() {
        contactAccumulator.clear();

        long start = System.nanoTime();

        // Do all of the world, static, and sleeping contacts in one big pass.
        // It may at some point be desirable to move the sleeping contacts into
        // their own pass or into the active objects pass if we ever want to
        // prioritize static and world contacts.
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {
            // Coarse static bins overlapping this fine bin (null when
            // large-static support is disabled).
            Bin<K, S>[] coarseBins = largeStaticDriver == null
                    ? null : largeStaticDriver.getCoarseBinsFor(bin);

            for( RigidBody<K, S> body : bin.getActiveObjects().getArray() ) {
                // First contact against the world
                collisionSystem.generateWorldCollisions(body, contactListener);

                // Then static contacts against this bin
                collisionSystem.generateStaticCollisions(body, bin.getStaticObjects().getArray(), contactListener);

                // And sleeping contacts against this bin
                collisionSystem.generateBodyCollisions(body, bin.getInactiveObjects().getArray(), contactListener);

                // Then do the same for the neighbors
                for( Bin<K, S> neighbor : binIndex.getNeighbors(bin) ) {
                    collisionSystem.generateStaticCollisions(body, neighbor.getStaticObjects().getArray(), contactListener);
                    collisionSystem.generateBodyCollisions(body, neighbor.getInactiveObjects().getArray(), contactListener);
                }

                // Static contacts against large structures.  Membership is
                // disjoint from the fine index so contact pairs are unique;
                // no dedup needed.
                if( coarseBins != null ) {
                    for( Bin<K, S> c : coarseBins ) {
                        collisionSystem.generateStaticCollisions(body, c.getStaticObjects().getArray(), contactListener);
                    }
                }
            }
        }

        // Poor man's way to check that we've visited until we can mark
        // the bins themselves
        Set<Bin<K, S>> visited = new HashSet<>();

        // We can now do the active object checks
        for( Bin<K, S> bin : binIndex.getActiveBins() ) {

            // First the inter-bin contacts
            collisionSystem.generateBodyCollisions(bin.getActiveObjects().getArray(), contactListener);

            Bin<K, S>[] neighbors = binIndex.getNeighbors(bin);
            // Now for each active object, hit it against the neighbors
            for( RigidBody<K, S> body : bin.getActiveObjects().getArray() ) {
                for( Bin<K, S> neighbor : neighbors ) {
                    if( neighbor.getStatus() != Bin.Status.Active ) {
                        continue;
                    }
                    if( visited.contains(neighbor) ) {
                        continue;
                    }
                    collisionSystem.generateBodyCollisions(body, neighbor.getActiveObjects().getArray(), contactListener);
                }
            }

            visited.add(bin);
        }

        /*for( Contact<K, S> c : contacts ) {
        //     contactResolver.getContactDispatcher().newContact(c);
        }*/
//if( !contactAccumulator.isEmpty() ) {
//    log.debug("total contacts:" + contactAccumulator.contacts.size());
//}
        if( collectStats ) {
            long delta = System.nanoTime() - start;

            contactCountStat.updateValue(contactAccumulator.contacts.size());
            contactGenTimeStat.updateValue(delta);
        }
    }

    protected void reactivateObjects() {
        for( Contact<K, S> c : contactAccumulator.contacts ) {
            if( c.getBody2() == null ) {
                continue;
            }
            double temp = c.calculateContactTemperature();

            if( RigidBody.isCold(temp) ) {
                // IF the contact's combined temperature will not wake up the
                // objects then there is no reason to reactivate them here.
                // It reduces some of the churn but not all.  There are cases
                // where the contact temperature is just above the threshold
                // but there isn't really enough energy in the contact to keep
                // the objects from sleeping.  There might be a way to predict this
                // energy but it's also not a huge deal... and getting it wrong would
                // be way worse.
                // TODO: see if we can predict the contact energy better.
                continue;
            }
            // Contacts may have swapped active and inactive so we need to check both
            // ends.
            if( c.body1.isSleepy() ) {
                // We are about to be reactivated when this contact is resolved
                activate(c.body1);
            }
            if( c.getBody2().isSleepy() ) {
                // We are about to be reactivated when this contact is resolved
                activate(c.getBody2());
            }

            // FIXME: the above is a fragile way to check if we have already
            // actived the object or not.  isSleepy() is based on RigidBody's internally
            // kept temperature which may (due to unforeseen bugs) potentially be out of sync
            // with what BinIndex thinks is active or inactive.
            // A better approach would be to directly ask BinIndex or if we want to
            // check RigidBody then have a flag that is only ever updated by BinIndex.
            // I say this because I just spent several hours tracking down a bug that
            // was caused by swapped contact endpoints.  The inactive body was body1
            // and we were only reactivating body2... but the contact was still going
            // to match the temperatures.  Subsequent intersections would then fail because
            // the rigid body looked 'active' by temperature but was not actually active
            // and so was being skipped in collision tests with the ground. (So was pushed
            // under ground.)
            // Also, technically there is no reason to ask BinIndex since we'd performing
            // the same query the BinIndex would use to activate the object... and it
            // will already avoid activating if it is already active.  So if we don't
            // go with a bin-managed RigidBody active flag then we might as well just
            // always activate.

            // Note also: because of the way we notify listeners after this method
            // is called, if they disable one end or the other (or both) we will still
            // reactivate the objects.  Really, disabled ends should effectively be
            // invisible and this may come back to bite us later. -pspeed 2018-01
        }

        if( tandemJointResolution ) {
            // If we are resolving joints as part of contacts then we need to manually
            // reactivate things in a separate loop... though for some reason in the
            // experiment, this seems to miss some bodies.
            for( Joint<K, S> joint : binIndex.getActiveJoints().getArray() ) {

                if( joint.isSleepy() ) {
                    // Could deactivate the joint but for now we'll just skip
                    // processing it
                    //log.debug("Joint is sleepy");
                    continue;
                }

                // See if either end will be woken up
                if( joint.getMainBody().isSleepy() ) {
                    activate(joint.getMainBody());
                }
                if( joint.getAltBody() != null && joint.getAltBody().isSleepy() ) {
                    activate(joint.getAltBody());
                }
            }
        }
    }

    protected void resolveContacts( double step ) {
        if( collectStats ) {
            long start = System.nanoTime();
            contactResolver.resolveContacts(contactAccumulator.contacts, binIndex.getActiveJoints(), step);
            long end = System.nanoTime();
            contactResTimeStat.updateValue(end - start);
        } else {
            contactResolver.resolveContacts(contactAccumulator.contacts, binIndex.getActiveJoints(), step);
        }
    }

    protected void resolveJoints( double step ) {
        for( Joint<K, S> joint : binIndex.getActiveJoints().getArray() ) {

            if( joint.isSleepy() ) {
                // Could deactivate the joint but for now we'll just skip
                // processing it
                //log.debug("Joint is sleepy");
                continue;
            }

            // See if either end will be woken up
            if( joint.getMainBody().isSleepy() ) {
                activate(joint.getMainBody());
            }
            if( joint.getAltBody() != null && joint.getAltBody().isSleepy() ) {
                activate(joint.getAltBody());
            }

            joint.resolve(step);
        }
    }
}




