/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mphys;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BallJoint<K, S extends AbstractShape> implements Joint<K, S> {
    
    static Logger log = LoggerFactory.getLogger(BallJoint.class);

    // At first we'll try to do a 'glue' joint which basically
    // as 'absolute' constraints.  A fixed joint.
    //
    
    K id;
    
    RigidBody<K, S> altBody;
    Vec3d altOffset;
    
    RigidBody<K, S> mainBody;
    Vec3d mainOffset;
 
    Quatd relativeRotation;
 
    double damping;
    
    double test1;    
 
    /**
     *  We defer to the contact class for many of our calculations but we don't
     *  need a new one every time.  Might as well keep one around.
     */
    private Contact<K, S> contact = new Contact<>();

    /**
     *  Creates a free-form ball joint that connects two bodies together
     *  or a body to world point.  If the altBody is null then the altOffset
     *  is the world location for attachment.
     */
    public BallJoint( K id, RigidBody<K, S> mainBody, Vec3d mainOffset,
                      RigidBody<K, S> altBody, Vec3d altOffset, 
                      Quatd relativeRotation,
                      double damping,
                      double test1 ) {
        this.id = id;
        this.altBody = altBody;
        this.altOffset = altOffset;
        this.mainBody = mainBody;
        this.mainOffset = mainOffset;
        this.relativeRotation = relativeRotation;
        this.damping = damping;
        this.test1 = test1;
        this.contact.setBodies(mainBody, altBody);
        
        // negative friction indicates that the planar calculation
        // should be skipped but the friction-based impulses should still
        // be used as they are more accurate.
        contact.friction = -0.7;
    } 
 
    public K getId() {
        return id; 
    }
 
    public RigidBody<K, S> getMainBody() {
        return mainBody;
    }
    
    public RigidBody<K, S> getAltBody() {
        return altBody;
    }                  
 
    public RigidBody<K, S> getOtherBody( RigidBody<K, S> body ) {
        if( mainBody == body ) {
            return altBody;
        }
        if( altBody == body ) {
            return mainBody;
        }
        throw new IllegalArgumentException("Specified body:" + body.id + " is not part of this joint:" + id);
    } 
       
    public boolean isSleepy() {
//log.info("isSleepy()  contact pen:" + contact.penetration);
        // The joint has to be relatively "closed" for us to be sleepy
        if( Math.abs(contact.penetration) > 0.00001 ) {
            return false;
        }
        // Both have to be sleepy for this joint to be sleepy
        return mainBody.isSleepy() && (altBody == null || altBody.isSleepy());
    }
 
    public void calculateInternals( double step ) {
        if( altBody == null ) {
            calculateInternalsUnconstrained(step);
        } else {
            calculateInternalsUnconstrainedTwoBody(step);
        }
    }
 
    public void calculatePositionChange( Vec3d linear1, Vec3d linear2, 
                                         Vec3d angular1, Vec3d angular2 ) {
//log.debug("calculatePositionChange()");                                         
//log.debug("contact:" + contact);                                         
        contact.calculatePositionChange(linear1, linear2, angular1, angular2, contact.penetration);
    }
                                         
    public void calculateVelocityChange( Vec3d vDelta1, Vec3d vDelta2, 
                                         Vec3d rotDelta1, Vec3d rotDelta2 ) {
                                         
        contact.calculateVelocityChange(vDelta1, vDelta2, rotDelta1, rotDelta2);
 
        if( damping == 0 ) {
            return;
        }
        
        double slow = damping; 
        
        // To come up with the total resistance we have to 
        // figure out what the rotational velocity will be _after_
        // we add the angular velocity.
        // rot + angular1
        // total angular velocity we will need to add is:
        // angular1 + (rot + angular1) * -slow
        Vec3d rot = mainBody.getRotationalVelocity();
        rotDelta1.addLocal(rot.add(rotDelta1).multLocal(-slow));

        if( altBody != null ) {
            rot = altBody.getRotationalVelocity();
            rotDelta2.addLocal(rot.add(rotDelta2).multLocal(-slow));
        }
    }
 
    private void calculateInternalsUnconstrained( double step ) {
        Vec3d world1 = altOffset;
        Vec3d world2 = mainBody.localToWorld(mainOffset);
 
        Vec3d delta = world1.subtract(world2);
        Vec3d normal = null;
        double length = delta.length();
        if( length != 0 ) {
            normal = delta.mult(1/length); 
        } else {
            normal = new Vec3d(0, 1, 0);
        }
        
        contact.setContactInfo(world2, normal, length);
        contact.calculateInternals(step);
    }

    private void calculateInternalsUnconstrainedTwoBody( double step ) {
        Vec3d world1 = mainBody.localToWorld(mainOffset);
        Vec3d world2 = altBody.localToWorld(altOffset);
 
        Vec3d delta = world2.subtract(world1);
        Vec3d normal = null;
        double length = delta.length();
        if( length != 0 ) {
            normal = delta.mult(1/length); 
        } else {
            normal = new Vec3d(0, 1, 0);
        } 
 
        // FIXME: the cp should probably be the midpoint actually... I've noticed
        //        this as I'm transitioning to a different resolution strategy so
        //        I'm trying to avoid changing things until that's done.
        // contact.setContactInfo(world1, normal, delta.length());
        // Ok, so let's do it.
        Vec3d cp = world1.add(world2).multLocal(0.5);
        contact.setContactInfo(cp, normal, delta.length()); 
        contact.matchLocalTemperature();               
        contact.calculateInternals(step);
    }
    
    public void resolve( double step ) {
//if( true ) {
//    return;
//}
//log.debug("resolve(" + step + ")");
 
        if( true ) {
            calculateInternals(step);
//if( true ) return;
            Vec3d linear1 = new Vec3d();
            Vec3d angular1 = new Vec3d();           
            Vec3d linear2 = new Vec3d();           
            Vec3d angular2 = new Vec3d();           
        
            calculatePositionChange(linear1, linear2, angular1, angular2);
//log.debug("  p linear1:" + linear1 + "  p angular1:" + angular1 + "  linear2:" + linear2 + "  angular2:" + angular2);
                
            mainBody.position.addLocal(linear1);            
            mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
            mainBody.calculateDerivedData();
            if( altBody != null ) {
                altBody.position.addLocal(linear2);
                altBody.orientation.addScaledVectorLocal(angular2, 1.0);
                altBody.calculateDerivedData();
            }
                
            calculateVelocityChange(linear1, linear2, angular1, angular2);
//log.debug("  p linear1:" + linear1 + "  p angular1:" + angular1 + "  linear2:" + linear2 + "  angular2:" + angular2);
    
            mainBody.addLinearVelocity(linear1);
            mainBody.addRotationalVelocity(angular1);
            if( altBody != null ) {
                altBody.addLinearVelocity(linear2);
                altBody.addRotationalVelocity(angular2);
            }
        } else {
            if( altBody == null ) {
                resolveUnconstrained(step);
            } else {
                resolveUnconstrainedTwoBody(step);
            }
        }
    }
 
    public void resolveUnconstrained( double step ) {
//log.debug("Joint.resolve()");
    
        // Testing the hanging from a single point case
        Vec3d world1 = altOffset;
        Vec3d world2 = mainBody.localToWorld(mainOffset);
 
        Vec3d delta = world1.subtract(world2);
        double length = delta.length();
        if( length == 0 ) { //< 0.0001 ) {
//log.debug("  delta length:" + length);        
            return; // let's see what happens
        }
        Vec3d normal = delta.mult(1/length); //world2.subtract(mainBody.position).normalizeLocal(); 
 
 
//log.debug("  pos:" + mainBody.position + "  orient:" + mainBody.orientation);
//log.debug("  world1:" + world1 + "  world2:" + world2);
//log.debug("  normal:" + normal + "  delta:" + delta);               

//log.debug("  lin:" + mainBody.getLinearVelocity());         
//log.debug("  rot:" + mainBody.getRotationalVelocity()); 
double linVelSq = mainBody.getLinearVelocity().lengthSq() / mainBody.getTemperature();
double rotVelSq = mainBody.getRotationalVelocity().lengthSq() / mainBody.getTemperature();

//log.debug("  linMovement:" + linVelSq + "  rotMovement:" + rotVelSq);

        // So what if we just treat it like a contact
        //Contact<K, S> contact = new Contact<>(mainBody, world2, normal, delta.length());
        contact.setContactInfo(world2, normal, delta.length());
        
        // Friction doesn't seem to matter at all
        //contact.friction = 0;
        // Neither does restitution... 
        //contact.restitution = 1;
        // I suspect they would for larger distances but once we've locked in then
        // the non-planar impulse is likely to be small and the restitution threshold
        // never exceeded.
        
        // Let's check if these really matter
        /*if( test1 > 0 ) {
            // These settings really do matter... damping = 0.1 and
            // the ball moves around randomly once nearing the oscillation point
            //contact.friction = 0;
            //contact.restitution = 0;
            // With these settings, the ball settles down mostly but
            // oscillates like crazy in a barely moving sort of way.
            //contact.friction = 0;
            //contact.restitution = 0.5;
            // With these settings the ball behaves almost unconstrained
            //contact.friction = 0.1;
            //contact.restitution = 0;
            // With these it behaves similarly to the non-test version
            //contact.friction = 0.9;
            //contact.restitution = 0;
            // With these also
            //contact.friction = 0.9;
            //contact.restitution = 0.9;
            // So it seems like friction is the important one which is a shame
            // because the math is simpler without friction.
            // The interesting part is that it's probably not the part that
            // applies the planar friction since that only comes into play
            // at extremes... and we see the problems near the point of equilibrium.
            // Let's test that.  Yep, leaving that part out has no effect.
            contact.friction = test1;
            contact.restitution = 0.9;
            // Except when friction is very small then I think the planar 
            // check happens more often.  Higher friction also does make the joint
            // behave stiffer.
            // Hmmm... commenting out the planar impulse check fixes the oscillation
            // but the one with a higher friction still slows faster.  That makes
            // no sense as the friction value isn't even used outside that block.
            // It doesn't... the test ball with a higher friction was hitting another
            // ball that slowed it down.  The friction value doesn't matter if the
            // planar impulse is ignored.
            // And if the planar impulse is put back in the higher friction one
            // actually takes slightly longer to slow down (and the smaller friction
            // super-vibrates at equil.)
            // Anyway, in the real joint math we will need to use the frictional
            // impulse calculator but we can ignore the friction part.  May even
            // want to investigate why they are different. 
        }*/
        
        
        contact.calculateInternals(step);

        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();           
        Vec3d linear2 = new Vec3d();           
        Vec3d angular2 = new Vec3d();           
//log.debug("contact:" + contact);                                         
        contact.calculatePositionChange(linear1, linear2, angular1, angular2, contact.penetration);
//log.debug("  p linear1:" + linear1 + "  p angular1:" + angular1 + "  linear2:" + linear2 + "  angular2:" + angular2);
 
//log.debug("  p linear1:" + linear1);
//log.debug("  p angular1:" + angular1);
 
        mainBody.position.addLocal(linear1);            
        mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
//log.debug("  after pos:" + mainBody.position + "  orient:" + mainBody.orientation);
        mainBody.calculateDerivedData();
 
        contact.calculateVelocityChange(linear1, linear2, angular1, angular2);
//log.debug("  v linear1:" + linear1);
//log.debug("  v angular1:" + angular1);

double slow = damping; 
Vec3d rot = mainBody.getRotationalVelocity();
//log.debug("  v rot:" + rot);


//angular1.x = angular1.x - rot.x * slow; 
//angular1.y = angular1.y - rot.y * slow; 
//angular1.z = angular1.z - rot.z * slow;
//        double rotLenSq = rot.lengthSq();
//        double angLenSq = angular1.lengthSq();
//double threshold = 1.0 - slow;
//threshold = threshold * threshold;
//double threshold = 0.005;               
//log.debug("rotLen:" + rotLenSq + "  angLen:" + angLenSq + "  threshold:" + threshold);         
 
//if( rotLenSq > threshold || angLenSq > threshold ) {
//    if( rotLenSq < angLenSq ) {    
//        angular1.x = slow(angular1.x, rot.x, slow); 
//        angular1.y = slow(angular1.y, rot.y, slow);  
//        angular1.z = slow(angular1.z, rot.z, slow);
//    }

//angular1.addLocal(rot);
//angular1.mult(1.0 - slow);
  
//log.debug("  v angular1:" + angular1);
//} else {
//    angular1.x = 0;
//    angular1.y = 0;
//    angular1.z = 0;
//log.debug("  v angular1:" + angular1);
//}
        // To come up with the total resistance we have to 
        // figure out what the rotational velocity will be _after_
        // we add the angular velocity.
        // rot + angular1
        // total angular velocity we will need to add is:
        // angular1 + (rot + angular1) * -slow
        angular1.addLocal(rot.add(angular1).multLocal(-slow));

//log.debug("  p linear1:" + linear1 + "  p angular1:" + angular1 + "  linear2:" + linear2 + "  angular2:" + angular2);
        mainBody.addLinearVelocity(linear1);
        mainBody.addRotationalVelocity(angular1);
//log.debug("  v rot:" + rot);
        //mainBody.addRotationalVelocity(rot.mult(-slow));
//log.debug("  v rot:" + rot);
    }

    public void resolveUnconstrainedTwoBody( double step ) {   
//log.debug("resolveUnconstrainedTwoBody()@" + System.identityHashCode(this));
//log.debug(" body1:" + mainBody.id + "@" + System.identityHashCode(mainBody) 
//       + "  body2:" + altBody.id + "@" + System.identityHashCode(altBody));
        // Testing the hanging from a single point case
        Vec3d world1 = mainBody.localToWorld(mainOffset);
        Vec3d world2 = altBody.localToWorld(altOffset);
 
        Vec3d delta = world2.subtract(world1);
        double length = delta.length();
        if( length == 0 ) { //< 0.0001 ) {
log.debug("  delta length:" + length);        
            return; // let's see what happens
        }
        Vec3d normal = delta.mult(1/length); //world2.subtract(mainBody.position).normalizeLocal(); 
 
 
double linVelSq = mainBody.getLinearVelocity().lengthSq() / mainBody.getTemperature();
double rotVelSq = mainBody.getRotationalVelocity().lengthSq() / mainBody.getTemperature();

//log.debug("  linMovement:" + linVelSq + "  rotMovement:" + rotVelSq);

//log.debug("  pos body1:" + mainBody.position + "  body2:" + altBody.position);

        // So what if we just treat it like a contact
        //Contact<K, S> contact = new Contact<>(mainBody, world2, normal, delta.length());
        contact.setContactInfo(world1, normal, delta.length());
 
        contact.matchLocalTemperature();               
        contact.calculateInternals(step);

//log.debug("  temperatre 1:" + mainBody.getTemperature() + "  2:" + altBody.getTemperature());
        Vec3d linear1 = new Vec3d();
        Vec3d angular1 = new Vec3d();           
        Vec3d linear2 = new Vec3d();           
        Vec3d angular2 = new Vec3d();           
        contact.calculatePositionChange(linear1, linear2, angular1, angular2, contact.penetration);
 
//log.debug("  p linear1:" + linear1 + "  linear2:" + linear2);
//log.debug("  p angular1:" + angular1 + "  angular2:" + angular2);
 
        mainBody.position.addLocal(linear1);            
        mainBody.orientation.addScaledVectorLocal(angular1, 1.0);
        mainBody.calculateDerivedData();
 
        altBody.position.addLocal(linear2);
        altBody.orientation.addScaledVectorLocal(angular2, 1.0);
        altBody.calculateDerivedData();
 
        contact.calculateVelocityChange(linear1, linear2, angular1, angular2);
//log.debug("  v linear1:" + linear1 + "  linear2:" + linear2);
//log.debug("  v angular1:" + angular1 + "  angular2:" + angular2);

double slow = damping; 
Vec3d rot1 = mainBody.getRotationalVelocity();
Vec3d rot2 = altBody.getRotationalVelocity();

        // To come up with the total resistance we have to 
        // figure out what the rotational velocity will be _after_
        // we add the angular velocity.
        // rot + angular1
        // total angular velocity we will need to add is:
        // angular1 + (rot + angular1) * -slow
        angular1.addLocal(rot1.add(angular1).multLocal(-slow));
        angular2.addLocal(rot2.add(angular2).multLocal(-slow));

        mainBody.addLinearVelocity(linear1);
        mainBody.addRotationalVelocity(angular1);
        altBody.addLinearVelocity(linear2);
        altBody.addRotationalVelocity(angular2);
    }
    
}
