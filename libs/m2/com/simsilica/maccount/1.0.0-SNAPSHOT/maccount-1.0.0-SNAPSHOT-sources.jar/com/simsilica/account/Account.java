/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account;

/**
 *  A user account.
 *
 *  @author    Paul Speed
 */
public interface Account {

    /**
     *  Returns the server-unique ID for this user.
     */
    public String getUserId();
    
    /**
     *  Returns the globally unique ID for this user.  This
     *  may be different than servier-unique ID.
     */
    public String getGlobalUserId();
 
    /**
     *  Returns the human-readable user name.  Usually this is that
     *  same as the user ID but can be different. 
     */
    public String getName();
 
    /**
     *  Returns a custom property associated with this account.
     *  In general, non-primitive values are supported as long as
     *  the account manager implementation supports them.
     */   
    public <T> T getProperty( String name, Class<T> type );
 
    /**
     *  Returns true if the account has the specified custom property.
     */
    public boolean hasProperty( String name );
    
    /**
     *  Sets a custom property associated with this account.
     *  Setting a property to null is the same as removing it
     *  from the hasProperty() perspective. 
     *  In general, non-primitive values are supported as long as
     *  the account manager implementation supports them.
     */
    public void setProperty( String name, Object value );
}
