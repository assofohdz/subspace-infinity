/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account.base;

import java.util.*;

import org.slf4j.*;

import com.simsilica.account.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DefaultAccount implements Account {
    static Logger log = LoggerFactory.getLogger(DefaultAccount.class);
 
    public static final String PROP_NAME = "name";
    
    private String globalUserId;
    private String userId;
    private Map<String, Object> properties;
    
    public DefaultAccount( String globalUserId, String userId, Map<String, Object> properties ) {
        this.globalUserId = globalUserId;
        this.userId = userId;
        this.properties = properties;
    }
    
    @Override
    public String getUserId() {
        return userId;
    }
    
    @Override
    public String getGlobalUserId() {
        return globalUserId;
    }
 
    @Override
    public String getName() {
        Object name = properties.get(PROP_NAME);
        if( name == null ) {
            return userId;
        }
        return String.valueOf(name); 
    }
 
    @Override
    public <T> T getProperty( String name, Class<T> type ) {
        Object result = properties.get(name);
        if( result == null ) {
            return null;
        }
        return type.cast(result);
    }
 
    @Override
    public boolean hasProperty( String name ) {
        return properties.containsKey(name);
    }
    
    @Override
    public void setProperty( String name, Object value ) {
        if( value == null ) {
            properties.remove(name);
        } else {
            properties.put(name, value);
        }
    }
           
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[userId:" + userId + ", globalUserId:" + globalUserId + "]";
    }    
}
