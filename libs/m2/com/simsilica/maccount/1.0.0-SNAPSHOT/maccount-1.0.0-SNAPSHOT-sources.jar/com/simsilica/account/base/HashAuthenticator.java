/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account.base;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.hash.*;

import com.simsilica.account.*;

/**
 *  
 *
 *  @author    Paul Speed
 */
public class HashAuthenticator implements Authenticator {
    static Logger log = LoggerFactory.getLogger(HashAuthenticator.class);

    public static final HashAuthenticator SHA512 = new HashAuthenticator("sha512", Hashing.sha512());

    private String name;
    private HashFunction hash;

    public HashAuthenticator( String name, HashFunction hash ) {
        this.name = name;
        this.hash = hash;
    }
 
    public String hash( String s ) {
        return hash.hashString(s, Charsets.UTF_8).toString();
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public AuthResult authenticate( Account account, String randomSalt, Map<String, Object> credentials ) {
        Object cred = credentials.get(name);
        if( cred == null ) {
            // We can't handle this set of credentials
            return AuthResult.Ignore;
        }
        
        // Get the stored hashed password
        String stored = account.getProperty(name, String.class);
        
        // Hash it again with the random salt because that's what the client
        // did.
        String comp = hash(randomSalt + stored);
 
        if( Objects.equals(cred, comp) ) {
            return AuthResult.Success;
        }
        return AuthResult.Failure;
    }

}
