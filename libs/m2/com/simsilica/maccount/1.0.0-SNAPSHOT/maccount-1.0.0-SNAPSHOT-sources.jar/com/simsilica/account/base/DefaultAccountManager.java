/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account.base;

import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.account.*;

/**
 *  A default implementation of the AccountManager interface with
 *  pluggable strategies for some customizable parts.
 *
 *  @author    Paul Speed
 */
public class DefaultAccountManager implements AccountManager {
    static Logger log = LoggerFactory.getLogger(DefaultAccountManager.class);

    private AccountStorage storage;
    private Map<String, Authenticator> auths = new LinkedHashMap<>(); // order is important
    private Function<String, String> guidGenerator;
    
    public DefaultAccountManager( AccountStorage storage ) {
        this.storage = storage;
    }     

    /**
     *  Sets the function that will turn local user IDs into globally unique
     *  user IDs... usually by salting with this server's GUID or something.
     */
    public void setGuidGenerator( Function<String, String> guidGenerator ) {
        this.guidGenerator = guidGenerator;
    } 

    // can hook in a factory here is we want to
    protected DefaultAccount createDefaultAccount( String globalUserId, String userId, Map<String, Object> properties ) {
        return new DefaultAccount(globalUserId, userId, properties);
    } 
 
    public void addAuthenticator( Authenticator auth ) {
        auths.put(auth.getName(), auth);
    }
    
    public void removeAuthenticator( Authenticator auth ) {
        auths.values().remove(auth);
    } 
 
    @Override
    public List<String> getCredentialTypes() {
        return new ArrayList<>(auths.keySet());
    }
    
    @Override
    public Account login( String userId, String randomSalt, Map<String, Object> credentials ) {
        Account account = getAccount(userId);
        if( account == null ) {
            throw new IllegalArgumentException("Invalid user ID");
        }
        for( Authenticator auth : auths.values() ) {
            AuthResult result = auth.authenticate(account, randomSalt, credentials);
            switch( result ) {
                case Success:
                    return account;
                case Failure:
                default:
                    throw new RuntimeException("Invalid credentials");
                case Ignore:
                    // continue along and try the next auth
                    break;
            }
        }
        throw new IllegalArgumentException("No authenticators matched supplied credentials");
    }
    
    @Override
    public Account createAccount( String userId, Map<String, Object> info ) {
        DefaultAccount account = (DefaultAccount)getAccount(userId);
        if( account != null ) {
            throw new IllegalArgumentException("User already exists:" + userId + "  global ID:" + account.getGlobalUserId());
        }
        String guid = userId;
        if( guidGenerator != null ) {
            guid = guidGenerator.apply(userId);           
        }
 
        account = createDefaultAccount(guid, userId, info);
        
        storage.store(account);
               
        return account;
    }
    
    @Override       
    public void saveAccount( Account account ) {
        if( !storage.exists(account.getGlobalUserId()) ) {
            throw new IllegalArgumentException("Account has not been created");
        }
        storage.store((DefaultAccount)account);
    }
    
    @Override   
    public Account getAccount( String userId ) {
        // The userId may already be a GUID
        Account result = storage.load(userId);
        if( result != null ) {
            return result;
        }
        if( guidGenerator == null ) {
            return null;
        } 
        // Then turn it into a guid and check    
        String guid = guidGenerator.apply(userId);
        result = storage.load(guid);
        return result;
    }
    
}
