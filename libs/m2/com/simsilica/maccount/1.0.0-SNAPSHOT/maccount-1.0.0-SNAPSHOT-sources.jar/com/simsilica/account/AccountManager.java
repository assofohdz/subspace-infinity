/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account;

import java.util.*;


/**
 *  Manages the creation and storage of user accounts and the
 *  authentication necessary to login.
 *
 *  @author    Paul Speed
 */
public interface AccountManager {
 
    /**
     *  Creates a new account for the specified userId if that user
     *  does not already have an account.  Throws an exception if the
     *  account already exists.
     */
    public Account createAccount( String userId, Map<String, Object> info );
 
    /**
     *  Saves any changes to the specified account data.
     */
    public void saveAccount( Account account );
    
    /** 
     *  Looks up the account instance of the specified user ID.
     *  If the server tracks both global and locally unique IDs
     *  then the globally unique IDs are searched first.
     */
    public Account getAccount( String userId );
 
    /**
     *  Returns the list of accepted credential types in preferred order.
     */
    public List<String> getCredentialTypes();
    
    /**
     *  Attempts to login the specified user using the specified credentials.
     *  Credentials are an implementation-specific set of data containing the
     *  necessary login information.  This may be hashed passwords, PKI certs,
     *  etc..  Generally, one or more of the map keys will match one of 
     *  the strings returned from getCredentialTypes() but it's not a requirement.
     *  It depends on the internal implementation.
     */
    public Account login( String userId, String randomSalt, Map<String, Object> credentials );
}
