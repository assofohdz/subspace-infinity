/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account.base.json;

import java.io.IOException;
import java.util.*;

import org.slf4j.*;

import com.google.gson.*;
import com.google.gson.internal.Streams;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.*;


/**
 *  A GSON TypeAdapter that can convert map values to/from JSON.
 *
 *  @author    Paul Speed
 */
@SuppressWarnings("unchecked")
public class MapValueTypeAdapterFactory implements TypeAdapterFactory {

    static Logger log = LoggerFactory.getLogger(MapValueTypeAdapterFactory.class);

    private TypeToken<?> mapType;
    private Set<Class> resolve = new HashSet<>();
    private Map<String, Class> classIndex = new HashMap<>();

    public MapValueTypeAdapterFactory( Class baseType, Class... resolveTypes ) {
        this(TypeToken.getParameterized(baseType, String.class, Object.class), resolveTypes);
    }

    public MapValueTypeAdapterFactory( TypeToken<?> mapType, Class... resolveTypes ) {
        this.mapType = mapType;
        this.resolve = new HashSet<>(Arrays.asList(resolveTypes));
        for( Class c : resolve ) {
            classIndex.put(c.getSimpleName(), c);
        }
    }

    public <T> TypeAdapter<T> create( Gson gson, TypeToken<T> type ) {
        if( !Objects.equals(type, mapType) ) {
            return null;
        }

        @SuppressWarnings({"unchecked", "rawtypes"})
        TypeAdapter<T> result = new MapAdapter(gson);
        return result;
    }

    private class MapAdapter<K, V> extends TypeAdapter<Map<K, V>> {
        private Gson gson;
        private TypeAdapter<V> valueAdapter;

        public MapAdapter( Gson gson ) {
            this.gson = gson;

            TypeToken<V> token = (TypeToken<V>)TypeToken.get(Object.class);
            this.valueAdapter = gson.getAdapter(token);
        }

        @Override
        public Map<K, V> read( JsonReader in ) throws IOException {
            JsonToken peek = in.peek();
            if( peek == JsonToken.NULL ) {
                in.nextNull();
                return null;
            }

            Map<K, V> map = new HashMap<>();
            if( peek != JsonToken.BEGIN_OBJECT ) {
                throw new JsonSyntaxException("Expected object but found:" + peek);
            }

            in.beginObject();

            while( in.hasNext() ) {
                String name = in.nextName();
                int split = name.lastIndexOf(":");
                if( split < 0 ) {
                    map.put((K)name, valueAdapter.read(in));
                    continue;
                }

                String cName = name.substring(split + 1);
                name = name.substring(0, split);

                Class type = classIndex.get(cName);

                V value = (V)gson.getAdapter(TypeToken.get(type)).read(in);
                map.put((K)name, value);
            }

            in.endObject();

            return map;
        }

        @Override
        public void write( JsonWriter out, Map<K, V> map ) throws IOException {
            if( map == null ) {
                out.nullValue();
                return;
            }

            out.beginObject();
            for( Map.Entry<K, V> entry : map.entrySet() ) {
                if( entry.getValue() == null ) {
                    continue;
                }
                Class c = entry.getValue().getClass();
                if( !resolve.contains(c) ) {
                    out.name(String.valueOf(entry.getKey()));
                    valueAdapter.write(out, entry.getValue());
                    continue;
                }

                // This string concatenation is simple and fits our needs today
                // because we know the map keys will never have ":" in them and
                // this makes the json more readable.  However, this is not a general
                // solution all maps.
                out.name(String.valueOf(entry.getKey()) + ":" + c.getSimpleName());
                valueAdapter.write(out, entry.getValue());
            }
            out.endObject();
        }
    }
}

