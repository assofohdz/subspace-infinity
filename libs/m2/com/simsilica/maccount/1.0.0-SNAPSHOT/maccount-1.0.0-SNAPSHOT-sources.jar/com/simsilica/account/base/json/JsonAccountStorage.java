/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.account.base.json;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import com.simsilica.account.*;
import com.simsilica.account.base.*;

/**
 *  Stores account information in separate JSON files with a single
 *  central index file.
 *
 *  @author    Paul Speed
 */
public class JsonAccountStorage implements AccountStorage {
    static Logger log = LoggerFactory.getLogger(JsonAccountStorage.class);

    public static final int FORMAT_VERSION = 1;
    private static final String FORMAT_PROPERTY = "_json_format_version";

    private Gson indexGson;
    private Gson accountGson;

    private File root;
    private Map<String, String> index;
    private Function<String, String> cleaner = new FileNameFilter();

    public JsonAccountStorage( File root, Class... valueTypes ) {
        this.root = root;

        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        this.indexGson = gsonBuilder.create();
 
        // Need to treat the map special since otherwise we won't
        // have any typing information to read back proper objects.       
        gsonBuilder.registerTypeAdapterFactory(new MapValueTypeAdapterFactory(Map.class, valueTypes));
        
        this.accountGson = gsonBuilder.create();
        
        initIndex();
    } 

    protected File toFile( String userId ) {
        // Note: because we use the cleaner on both load and store then
        // we will never have collisions where two users end up in the
        // same file... but we will potentially have cases where a second
        // user is not allowed to create a similar account that only
        // differs by a disallowed character.  That's ok.
        return new File(root, cleaner.apply(userId) + ".json");
    }

    @Override
    public boolean exists( String userId ) {
        String globalUserId = index.get(userId);
        if( globalUserId == null ) {
            return false;
        }
        File f = toFile(globalUserId);
        return f.exists();
    }   

    @Override
    public DefaultAccount load( String userId ) {
        String globalUserId = index.get(userId);
        if( globalUserId == null ) {
            return null;
        }
        File f = toFile(globalUserId);
        if( !f.exists() ) {
            return null;
        }
        try {
            DefaultAccount account = loadAccount(f);            
            
            // Clear the format we stored last time.
            account.setProperty(FORMAT_PROPERTY, null);
            
            return account;
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }       
    }
 
    @Override   
    public void store( DefaultAccount account ) {
        File f = toFile(account.getGlobalUserId());
        
        // Temporarily tuck away the format version just for storage
        account.setProperty(FORMAT_PROPERTY, FORMAT_VERSION);
        
        try {
            storeAccount(f, account);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
        
        index.put(account.getUserId(), account.getGlobalUserId());
        
        // Logic is easier if we also store the identity mapping
        index.put(account.getGlobalUserId(), account.getGlobalUserId());
        try {
            storeIndex();
        } catch( IOException e ) {
            throw new RuntimeException("Error storing user index", e);
        } 
    }    
 
    /**
     *  Migrates older account formats to newer conventions as needed.
     */
    protected void upgrade( DefaultAccount account ) {
    }
 
    protected DefaultAccount loadAccount( File f ) throws IOException {
        String json = Files.toString(f, Charsets.UTF_8);
        DefaultAccount account = accountGson.fromJson(json, DefaultAccount.class);
        upgrade(account);
        return account;
    }
    
    protected synchronized void storeAccount( File f, DefaultAccount account ) throws IOException {
        String json = accountGson.toJson(account);
        
        // In case things go poorly, write the data to a new file first
        // so that we don't lost the old file
        File temp = new File(f.getParentFile(), f.getName() + ".new");
        Files.write(json, temp, Charsets.UTF_8);
        
        // If we made it this far then the file was written successfully
        // and it's safe to remove any older file
        if( f.exists() ) {
            f.delete();
        } 
        // Rename the temp file to the real file       
        if( !temp.renameTo(f) ) {
            throw new IOException("Error renaming:" + temp + " to:" + f);
        }
    }
    
    protected synchronized void storeIndex() throws IOException {
        // In case things go poorly, write the data to a new file
        // first.
        File f = new File(root, "user.index");
        File temp = new File(root, "user.index.new");
        
        String json = indexGson.toJson(index);
        Files.write(json, temp, Charsets.UTF_8);
 
        // Do the rename shuffle to make sure we don't blow away
        // a good index with a bad write.       
        if( f.exists() ) {
            f.delete();
        }
        if( !temp.renameTo(f) ) {
            throw new IOException("Error renaming:" + temp + " to:" + f);
        }  
    }

    protected void initIndex() {
        File f = new File(root, "user.index");
        if( !f.exists() ) {
            index = new HashMap<>();
            return;
        }
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            Type mapType = new TypeToken<Map<String, String>>(){}.getType();
            index = new HashMap<>(indexGson.fromJson(json, mapType));
        } catch( IOException e ) {
            throw new RuntimeException("Error loading user index", e);
        }
    }

 
    /**
     *  Function to return a clean string where only alpha-numeric and
     *  a few special characters are kept.
     */   
    public static class FileNameFilter implements Function<String, String> {
        public String apply( String s ) {
            StringBuilder sb = new StringBuilder();
            for( int i = 0; i < s.length(); i++ ) {
                char c = s.charAt(i);
                if( Character.isLetterOrDigit(c) ) {
                    sb.append(c);
                } else if( c == '_' ) {
                    sb.append(c);
                } else if( c == '-' ) {
                    sb.append(c);
                } else if( c == '@' ) {
                    sb.append(c);
                } else if( c == '.' ) {
                    sb.append(c);
                }
            }
            return sb.toString();
        }
    }    
}

