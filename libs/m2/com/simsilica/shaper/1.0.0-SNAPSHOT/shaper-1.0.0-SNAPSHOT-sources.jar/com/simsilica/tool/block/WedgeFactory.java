/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class WedgeFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(WedgeFactory.class);

    public WedgeFactory() {
        super("Wedge", "wedge",
                new Parameter<Double>("Y Scale", Double.class, 1.0, 0.05, 1.0),
                new Parameter<Double>("Z Scale", Double.class, 1.0, 0.05, 1.0),       
                new Parameter<Boolean>("Invert Y", Boolean.class, false),
                new Parameter<Boolean>("Skew Texture", Boolean.class, false)
            );
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        float yScale = (float)(double)(Double)parameterValues[0];
        float zScale = (float)(double)(Double)parameterValues[1];
        Boolean invertY = (Boolean)parameterValues[2];
        Boolean skew = (Boolean)parameterValues[3];
        boolean stretch = false;

        Vec3d min = new Vec3d(0, 0, 0);
        Vec3d max = new Vec3d(1, yScale, zScale);
        if( invertY ) {
            min.y = 1.0 - yScale;
            max.y = 1.0;
        }

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);        
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
            
        MaterialType mtInternal = config2.getMaterialType();

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();
        
        Vector3f normal = new Vector3f(0, zScale * (invertY ? -1 : 1), yScale).normalizeLocal();

        BoundaryShape northShape = BoundaryShapes.getRect(0, min.y, 1, max.y);
        BoundaryShape downShape = BoundaryShapes.getRect(0, 0, 1, zScale);
        BoundaryShape triangle = BoundaryShapes.getTriangle(0, min.y, zScale, max.y, normal.z, normal.y);
    
        //BoundaryShape quad = BoundaryShapes.UNIT_SQUARE;  
        //BoundaryShape triangle = BoundaryShapes.getTriangle(0, 0, 1, 1, 1/Math.sqrt(2), 1/Math.sqrt(2)); 

        GeomPart north = GeomPart.createQuad(min, max, mt, Direction.North, stretch);
        if( skew && yScale < 1 ) {
            // Potentially need to slide the texture coordinates
            float[] uvs = north.getTexCoords();
            for( int i = 0; i < uvs.length; i += 2 ) {                
                // Shift the uvs appropriately
                if( invertY ) {
                    uvs[i + 1] -= min.y;
                } else {
                    uvs[i + 1] += (1 - max.y);
                }
            }
        } 
        dirTemplates[0] = DefaultPartFactory.create(northShape, north);
        if( invertY ) {
            dirTemplates[4] = DefaultPartFactory.create(downShape, GeomPart.createQuad(min, max, mt, Direction.Up, stretch));
        } else {
            dirTemplates[5] = DefaultPartFactory.create(downShape, GeomPart.createQuad(min, max, mt, Direction.Down, stretch));
        }

        GeomPart east = new GeomPart(mt, Direction.East.ordinal(), false);
        if( invertY ) {
            //   1     2
            //  
            //         0
            east.setCoords(
                (float)max.x, (float)min.y, (float)min.z,
                (float)max.x, (float)max.y, (float)max.z,
                (float)max.x, (float)max.y, (float)min.z
                );
        } else {
            //         0
            // 
            //   2     1
            east.setCoords(
                (float)max.x, (float)max.y, (float)min.z,
                (float)max.x, (float)min.y, (float)min.z,
                (float)max.x, (float)min.y, (float)max.z
                );
        }
        if( skew ) {
            // Skewing is not stretching... we won't squish, we'll
            // just skew the texture to conform to the slope
            if( invertY ) {
                east.setTexCoords(
                    1, 0,
                    (float)max.z, 0,
                    1, 1 - (float)min.y
                    );
            } else {
                east.setTexCoords(
                    1, 1,
                    1, 1 - (float)max.y,
                    1 - (float)max.z, 1
                    );
            }
        } else {
            float[] coords = east.getCoords();
            east.setTexCoords(
                    1 - coords[2], coords[1],
                    1 - coords[5], coords[4],
                    1 - coords[8], coords[7]
                );
        }
        east.setIndexes(2, 1, 0);
        east.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[2] = DefaultPartFactory.create(triangle, east);

        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        if( invertY ) {
            //  0     1
            //   
            //  2
            west.setCoords(
                (float)min.x, (float)max.y, (float)min.z,
                (float)min.x, (float)max.y, (float)max.z,
                (float)min.x, (float)min.y, (float)min.z
                );
        } else {
            //  1    
            // 
            //  0    2
            west.setCoords(
                (float)min.x, (float)min.y, (float)min.z,
                (float)min.x, (float)max.y, (float)min.z,
                (float)min.x, (float)min.y, (float)max.z
                );
        }
        if( skew ) {
            // Skewing is not stretching... we won't squish, we'll
            // just skew the texture to conform to the slope
            if( invertY ) {
                west.setTexCoords(
                    0, 1 - (float)min.y,
                    (float)max.z, 0,
                    0, 0                    
                    );
            } else {
                west.setTexCoords(
                    0, 1 - (float)max.y,
                    0, 1,                    
                    (float)max.z, 1
                    );
            }
        } else {
            float[] coords = west.getCoords();
            west.setTexCoords(
                    coords[2], coords[1],
                    coords[5], coords[4],
                    coords[8], coords[7]
                );
        }
        west.setIndexes(2, 1, 0);
        west.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[3] = DefaultPartFactory.create(triangle, west);
 
 
        Vector3f norm = normal; //new Vector3f(0, 1, 1).normalizeLocal();            
        Vector3f tangent = new Vector3f(1, 0, 0); 

        GeomPart slope = new GeomPart(mtInternal, -1, false);
        if( invertY ) {            
            slope.setCoords(
                (float)min.x, (float)min.y, (float)min.z,
                (float)max.x, (float)min.y, (float)min.z,
                (float)max.x, (float)max.y, (float)max.z,
                (float)min.x, (float)max.y, (float)max.z
                );
        } else {
            slope.setCoords(
                (float)min.x, (float)min.y, (float)max.z,
                (float)max.x, (float)min.y, (float)max.z,
                (float)max.x, (float)max.y, (float)min.z,
                (float)min.x, (float)max.y, (float)min.z
                );
        }
        slope.setTexCoords(
            0, 0,
            1, 0,
            1, 1,
            0, 1
            );
                
        slope.setNormals(FloatUtils.toFloatArray(4, norm));
        slope.setTangents(FloatUtils.toFloatArray(4, tangent));
        slope.setIndexes(0, 1, 2, 0, 2, 3);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("wedge", 0));
    }
}


