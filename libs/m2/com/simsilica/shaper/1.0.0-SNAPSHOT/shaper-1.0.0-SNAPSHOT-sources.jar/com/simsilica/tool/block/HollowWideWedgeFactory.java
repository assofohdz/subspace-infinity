/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *  A vertically thin wedge sitting next to a box, basically.
 *
 *  @author    Paul Speed
 */
public class HollowWideWedgeFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(HollowWideWedgeFactory.class);

    private boolean doubleSided = true;

    public HollowWideWedgeFactory() {
        super("Hollow Wide Wedge", "hollow-wide-wedge",
                new Parameter<MaterialType>("Inner Material", MaterialType.class, null),
                new Parameter<Boolean>("Invert Y", Boolean.class, false),
                new Parameter<Boolean>("Include Back", Boolean.class, false),
                new Parameter<Boolean>("Include Bottom", Boolean.class, false),
                new Parameter<Boolean>("Include Top", Boolean.class, false)
            );
    }

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        Boolean invertY = (Boolean)parameterValues[1];
        boolean stretch = false;
        Boolean skew = false; //(Boolean)parameterValues[1];

        boolean includeBack = Boolean.TRUE.equals(parameterValues[2]);
        boolean includeBottom = Boolean.TRUE.equals(parameterValues[3]);
        boolean includeTop = Boolean.TRUE.equals(parameterValues[4]);


        // Skewing is difficult across wide wedges and thin wedges.
        // Nothing will ever line up 100% and it starts to become an
        // artistic decision.  Rotating the texture coordinates would
        // work but requires coordinates outside of the 0..1 range
        // and so implies that the texture wraps like we expect it to.
        // Given how much time I've spent on this today, I'm punting
        // and deciding that it's better to have rotated textures.
        // That way the 'artist' can choose to scale them after rotation
        // to line them up better with non-rotated textures if they choose
        // to or find some other balance.  Maybe they still want vertical
        // parts to be vertical or whatever.
        // so in that light, we'll just always project.

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();

        MaterialType mtInternal = config2.getMaterialType();

        config1 = materials.findBest((String)parameterValues[0], GeomReq.IndexedNormals);
        config2 = materials.findBest((String)parameterValues[0], GeomReq.Normals, GeomReq.Tangents);
        MaterialType mt2 = config1 == null ? null : config1.getMaterialType();
        MaterialType mtInternal2 = config2 == null ? null : config2.getMaterialType();

        // min/max defines the box part.  It makes some calls easier
        Vec3d min = new Vec3d(0, 0, 0);
        Vec3d max = new Vec3d(1, 1, 0.5);

        // n,s,e,w,u,d
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();

        Vector3f normal = new Vector3f(0, 0.5f * (invertY ? -1 : 1), 1).normalizeLocal();

        BoundaryShape northShape = BoundaryShapes.UNIT_SQUARE;
        BoundaryShape topShape = BoundaryShapes.getRect(0, 0, 1, 0.5);
        BoundaryShape downShape = BoundaryShapes.UNIT_SQUARE;

        // We don't have a trapezoidal shape so we'll pick a shape that
        // will match our other similar sides but is unlikely to match
        // other things.  In this case, just the triangle part.  This is
        // what the original engine did but we may want something better eventually
        // since this will mess with anything that tries to reason about the boundary
        // shape.
        BoundaryShape sideShape;
        if( invertY ) {
            // Half triangle facing down... starting at x = 0.5
            sideShape = BoundaryShapes.getTriangle(0.5, 0, 1, 1, normal.z, normal.y);
        } else {
            // Half triangle facing up
            sideShape = BoundaryShapes.getTriangle(0.5, 0, 1, 1, normal.z, normal.y);
        }

        if( includeBack ) {
            GeomPart north = GeomPart.createFace(mt, Direction.North);
            if( doubleSided ) {
                dirTemplates[0] = DefaultPartFactory.create(northShape, north, north.invert(mt2));
            } else {
                dirTemplates[0] = DefaultPartFactory.create(northShape, north);
            }
        }

        if( invertY ) {
            if( includeTop ) {
                GeomPart up = GeomPart.createFace(mt, Direction.Up);
                if( doubleSided ) {
                    dirTemplates[4] = DefaultPartFactory.create(downShape, up, up.invert(mt2));
                } else {
                    dirTemplates[4] = DefaultPartFactory.create(downShape, up);
                }
            }
            if( includeBottom ) {
                GeomPart down = GeomPart.createQuad(min, max, mt, Direction.Down, stretch);
                if( doubleSided ) {
                    dirTemplates[5] = DefaultPartFactory.create(topShape, down, down.invert(mt2));
                } else {
                    dirTemplates[5] = DefaultPartFactory.create(topShape, down);
                }
            }
        } else {
            if( includeTop ) {
                GeomPart up = GeomPart.createQuad(min, max, mt, Direction.Up, stretch);
                if( doubleSided ) {
                    dirTemplates[4] = DefaultPartFactory.create(topShape, up, up.invert(mt2));
                } else {
                    dirTemplates[4] = DefaultPartFactory.create(topShape, up);
                }
            }
            if( includeBottom ) {
                GeomPart down = GeomPart.createFace(mt, Direction.Down);
                if( doubleSided ) {
                    dirTemplates[5] = DefaultPartFactory.create(downShape, down, down.invert(mt2));
                } else {
                    dirTemplates[5] = DefaultPartFactory.create(downShape, down);
                }
            }
        }

        // The east/west sides will eb sideway trapezoids made of two
        // triangles... basically a box with one of the corners pull up.
        GeomPart east = new GeomPart(mt, Direction.East.ordinal(), false);
        if( invertY ) {
            east.setCoords(
                1, 0, 0,
                1, 1, 0,
                1, 1, 1,
                1, 0, 0.5f
                );
            if( skew ) {
                east.setTexCoords(
                    1, 0.5f,
                    1, 1,
                    0, 0,
                    0.5f, 0
                    );

            } else {
                east.setTexCoords(
                    1, 0,
                    1, 1,
                    0, 1,
                    0.5f, 0
                    );
            }
            east.setIndexes(0, 1, 3, 1, 2, 3);
        } else {
            east.setCoords(
                1, 0, 0,
                1, 1, 0,
                1, 1, 0.5f,
                1, 0, 1
                );
            if( skew ) {
                east.setTexCoords(
                    1, 0,
                    1, 0.5f,
                    0.5f, 1,
                    0, 1
                    );
            } else {
                east.setTexCoords(
                    1, 0,
                    1, 1,
                    0.5f, 1,
                    0, 0
                    );
            }
            east.setIndexes(0, 1, 2, 0, 2, 3);
        }
        east.setupAlternates(); // for indexed and non-indexed materials
        if( doubleSided ) {
            dirTemplates[2] = DefaultPartFactory.create(sideShape, east, east.invert(mt2));
        } else {
            dirTemplates[2] = DefaultPartFactory.create(sideShape, east);
        }


        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        if( invertY ) {
            west.setCoords(
                0, 0, 0,
                0, 1, 0,
                0, 1, 1,
                0, 0, 0.5f
                );
            if( skew ) {
                west.setTexCoords(
                    1, 0.5f,
                    1, 1,
                    0, 0,
                    0.5f, 0
                    );

            } else {
                west.setTexCoords(
                    0, 0,
                    0, 1,
                    1, 1,
                    0.5f, 0
                    );
            }
            west.setIndexes(0, 3, 1, 1, 3, 2);
        } else {
            west.setCoords(
                0, 0, 0,
                0, 1, 0,
                0, 1, 0.5f,
                0, 0, 1
                );
            if( skew ) {
                west.setTexCoords(
                    1, 0,
                    1, 0.5f,
                    0.5f, 1,
                    0, 1
                    );
            } else {
                west.setTexCoords(
                    0, 0,
                    0, 1,
                    0.5f, 1,
                    1, 0
                    );
            }
            west.setIndexes(0, 2, 1, 0, 3, 2);
        }

        west.setupAlternates(); // for indexed and non-indexed materials
        if( doubleSided ) {
            dirTemplates[3] = DefaultPartFactory.create(sideShape, west, west.invert(mt2));
        } else {
            dirTemplates[3] = DefaultPartFactory.create(sideShape, west);
        }

        Vector3f norm = normal; //new Vector3f(0, 1, 1).normalizeLocal();
        Vector3f tangent = new Vector3f(1, 0, 0);

        GeomPart slope = new GeomPart(mtInternal, -1, false);
        if( invertY ) {
            slope.setCoords(
                (float)min.x, (float)0, (float)max.z,
                (float)max.x, (float)0, (float)max.z,
                (float)max.x, (float)1, (float)1,
                (float)min.x, (float)1, (float)1
                );
        } else {
            slope.setCoords(
                (float)min.x, (float)0, (float)1,
                (float)max.x, (float)0, (float)1,
                (float)max.x, (float)1, (float)max.z,
                (float)min.x, (float)1, (float)max.z
                );
        }
        slope.setTexCoords(
            0, 0,
            1, 0,
            1, 1,
            0, 1
            );

        slope.setNormals(FloatUtils.toFloatArray(4, norm));
        slope.setTangents(FloatUtils.toFloatArray(4, tangent));
        slope.setIndexes(0, 1, 2, 0, 2, 3);
        internalParts.add(slope);
        if( doubleSided ) {
            internalParts.add(slope.invert(mtInternal2));
        }

        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray);
        }
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);

        // Future-Paul, sorry for hard-coding this ColliderType string here.
        return new BlockType(name, bf, new ColliderType("wedge", 0));
    }
}


