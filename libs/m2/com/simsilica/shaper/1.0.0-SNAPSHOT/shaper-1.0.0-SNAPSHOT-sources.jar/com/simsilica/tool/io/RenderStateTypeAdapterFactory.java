/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.io;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

import org.slf4j.*;

import com.google.gson.*;
import com.google.gson.internal.Streams;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import com.jme3.material.RenderState;

/**
 *  Flattens the defaults out of a written RenderState.
 *
 *  @author    Paul Speed
 */
public class RenderStateTypeAdapterFactory<T> implements TypeAdapterFactory {

    static Logger log = LoggerFactory.getLogger(RenderStateTypeAdapterFactory.class);

    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
                "cachedHashCode"
            ));

    private static final Set<String> FIELDS = new HashSet<>(Arrays.asList(
                "wireframe",
                "cullMode",
                "depthWrite",
                "depthTest",
                "colorWrite",
                "blendEquation",
                "blendEquationAlpha",
                "blendMode",
                "offsetFactor",
                "offsetUnits",
                "offsetEnabled",
                "stencilTest",
                "lineWidth",
                "depthFunc",
                "frontStencilStencilFailOperation",
                "frontStencilDepthFailOperation",
                "frontStencilDepthPassOperation",
                "backStencilStencilFailOperation",
                "backStencilDepthFailOperation",
                "backStencilDepthPassOperation",
                "frontStencilFunction",
                "backStencilFunction",
                "sfactorRGB",
                "dfactorRGB",
                "sfactorAlpha",
                "dfactorAlpha"
            ));
    private static Map<String, Field> FIELD_INDEX = new HashMap<>();
    static {
        for( Field f : RenderState.class.getDeclaredFields() ) {
            if( SKIP.contains(f.getName()) ) {
                continue;
            }
            if( Modifier.isStatic(f.getModifiers()) ) {
                continue;
            }
            if( f.getName().startsWith("apply") ) {
                continue;
            }
            if( !FIELDS.contains(f.getName()) ) {
                log.warn("Skipping mapping of field:" + f);
                continue;
            }
            f.setAccessible(true);
            FIELD_INDEX.put(f.getName(), f);
        }
    }

    private RenderState defaultValues = new RenderState();

    public RenderStateTypeAdapterFactory() {
    }

    public static <T> RenderStateTypeAdapterFactory create() {
        return new RenderStateTypeAdapterFactory<T>();
    }

    public <S> TypeAdapter<S> create( Gson gson, TypeToken<S> type ) {
        if( RenderState.class != type.getRawType() ) {
            return null;
        }
        
        TypeAdapter<S> delegate = gson.getDelegateAdapter(this, type);
        return new RenderStateAdapter<>(delegate); 
    }

    private class RenderStateAdapter<S> extends TypeAdapter<S> {
 
        private TypeAdapter<S> delegate;
    
        public RenderStateAdapter( TypeAdapter<S> delegate ) {
            this.delegate = delegate;
        }
    
        @Override
        public S read( JsonReader in ) throws IOException {
            S result = delegate.read(in);
            return result;
        }
 
        @Override       
        public void write( JsonWriter out, S value ) throws IOException {
            if( value == null ) {
                out.nullValue();
                return;
            }        
        
            JsonObject jsonObject = delegate.toJsonTree(value).getAsJsonObject();

            // First remove any of the 'apply' properties as we never want to
            // store thos
            for( Iterator<String> it = jsonObject.keySet().iterator(); it.hasNext(); ) {
                String s = it.next();
                Field f = FIELD_INDEX.get(s);
                if( f == null ) {
                    it.remove();
                    continue;
                }
 
                try {               
                    Object o1 = f.get(defaultValues);
                    Object o2 = f.get(value);
                    if( Objects.equals(o1, o2) ) {
                        it.remove();
                    }
                } catch( Exception e ) {
                    throw new JsonParseException("Error resolving field:" + f, e);
                }   
            }
            
            Streams.write(jsonObject, out);
        } 
    }
}



