/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.Vector3f;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.SpringGridLayout;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.tool.io.*;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FileMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FileMenuState.class);

    private Label fileLoadTitle;
    private Container fileLoadDialog;
    private ListBox<String> files;

    public FileMenuState() {        
    }
 
    public void saveBlocks() {
        getState(BlockSetMenuState.class).tempSave();
    }

    public void saveFluids() {
        getState(BlockSetMenuState.class).saveFluidSet();
    }
    
    public void compileBlocks() throws IOException {
        getState(BlockSetMenuState.class).tempCompileBlocks();
    }

    public void compileMaterials() throws IOException {
        getState(BlockSetMenuState.class).tempCompileMaterials();
    }
 
    public void importBlocks() {
        selectFile(ShaperConfig.getInstance().getImportDir(), ".json");
    }
 
    public void exportBlockOrder() throws IOException {
        getState(BlockSetMenuState.class).exportBlockOrder();
    }
    
    public void importBlockOrder() throws IOException {
        getState(BlockSetMenuState.class).importBlockOrder();
    }
    
    @Override    
    protected void initialize( Application app ) {
        Container options = new Container();
        
        options.addChild(new ActionButton(new CallMethodAction(this, "saveBlocks")));
        options.addChild(new ActionButton(new CallMethodAction(this, "saveFluids")));
        options.addChild(new ActionButton(new CallMethodAction(this, "compileBlocks")));
        options.addChild(new ActionButton(new CallMethodAction(this, "compileMaterials")));
        options.addChild(new ActionButton(new CallMethodAction(this, "importBlocks")));
        options.addChild(new ActionButton(new CallMethodAction(this, "exportBlockOrder")));
        options.addChild(new ActionButton(new CallMethodAction(this, "importBlockOrder")));
        
        getState(MainMenuState.class).getTabs().addTab("File", options);
        
        
        
        // A simple file selection dialog that just displays a list of all
        // .blocks files and allows selection
        fileLoadDialog = new Container();
        fileLoadTitle = fileLoadDialog.addChild(new Label("Load Object", new ElementId("title.label")));
        
        // Set the preferred width of the title so that the whole box is nice and wide
        Vector3f pref = fileLoadTitle.getPreferredSize();
        pref.x = Math.max(pref.x, 200);
        fileLoadTitle.setPreferredSize(pref);
         
        files = fileLoadDialog.addChild(new ListBox<String>());
        files.setVisibleItems(10);   
        Container buttons = fileLoadDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Load", this, "loadSelectedFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", fileLoadDialog, "removeFromParent")));    

        
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
 
    protected void loadSelectedFile() {
        System.out.println("loadSelectedFile()");
        fileLoadDialog.removeFromParent();
        
        Integer selection = files.getSelectionModel().getSelection();
        if( selection == null ) {
            getState(OptionPanelState.class).show("Not Loaded", 
                                                  "Object not loaded.  No file was selected.");
            return;
        }
        
        String s = files.getModel().get(selection);
        importFile(s);
    }        

    protected void importFile( String s ) {
        log.info("importFile(" + s + ")");
                
        File f = new File(ShaperConfig.getInstance().getImportDir(), s + ".json");
        BlockSet imported = BlockSetJson.load(f);

        log.info("loaded:" + imported);
        
        BlockSet blocks = getState(BlockSetMenuState.class).getBlockSet();
        
        List<String> replaced = new ArrayList<>();
        for( BlockType type : imported.getTypes() ) {
            BlockType existing = blocks.get(type.getName());
            if( existing != null ) {
                log.info("replacing:" + existing.getName());
                replaced.add(type.getName().toString());
                blocks.replace(existing, type);
            } else {
                blocks.add(type);
            }
        }
                
    }
    
    protected void selectFile( File dir, String extension ) {
        System.out.println("selectFile()");
 
        if( extension.charAt(0) != '.' ) {
            extension = "." + extension;
        }
        
        // Update the file list
        List<String> objects = new ArrayList<>();
        for( String s : dir.list() ) {
            if( !s.toLowerCase().endsWith(extension) ) {
                continue;
            }
            s = s.substring(0, s.length() - extension.length());
            objects.add(s);
        }
 
        files.getModel().clear();
        files.getModel().addAll(objects);
        files.getSelectionModel().clear();
            
        Vector3f pref = fileLoadDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileLoadDialog.setLocalTranslation(loc);
 
        GuiGlobals.getInstance().getPopupState().showModalPopup(fileLoadDialog);
    }
    
}
