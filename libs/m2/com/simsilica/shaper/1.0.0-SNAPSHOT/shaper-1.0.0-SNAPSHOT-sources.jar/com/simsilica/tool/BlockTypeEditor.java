/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Strings;

import com.jme3.math.*;
import com.jme3.scene.Spatial;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BlockTypeEditor extends Container implements VersionedObject<BlockType> {

    static Logger log = LoggerFactory.getLogger(BlockTypeEditor.class);

    private long version;

    private BlockNameEditor nameEditor;
    private VersionedReference<BlockName> nameRef;

    private TextField groupField;
    private VersionedReference<DocumentModel> groupRef;

    private VersionedList<ColliderType> colliderTypes = new VersionedList<>(Arrays.asList(
                null,
                new ColliderType("cube", -1),
                new ColliderType("angle", 0),
                new ColliderType("angle", 1),
                new ColliderType("angle", 2),
                new ColliderType("angle", 3),
                new ColliderType("branch", 0),
                new ColliderType("branch", 1),
                new ColliderType("branch", 2),
                new ColliderType("branch", 3),
                new ColliderType("cone-dn", -1),
                new ColliderType("cone-up", -1),
                new ColliderType("hcyl", 0),
                new ColliderType("hcyl", 1),
                new ColliderType("shallow-corner", 0),
                new ColliderType("shallow-corner", 1),
                new ColliderType("shallow-corner", 2),
                new ColliderType("shallow-corner", 3),
                new ColliderType("sphere", -1),
                new ColliderType("hi-wedge", 0),
                new ColliderType("hi-wedge", 1),
                new ColliderType("hi-wedge", 2),
                new ColliderType("hi-wedge", 3),
                new ColliderType("hi-wedge-corner", 0),
                new ColliderType("hi-wedge-corner", 1),
                new ColliderType("hi-wedge-corner", 2),
                new ColliderType("hi-wedge-corner", 3),
                new ColliderType("vcyl", 0),
                new ColliderType("wedge", 0),
                new ColliderType("wedge", 1),
                new ColliderType("wedge", 2),
                new ColliderType("wedge", 3),
                new ColliderType("wedge-corner", 0),
                new ColliderType("wedge-corner", 1),
                new ColliderType("wedge-corner", 2),
                new ColliderType("wedge-corner", 3),
                new ColliderType("wedge-cyl", 0),
                new ColliderType("wedge-cyl", 1),
                new ColliderType("wedge-cyl", 2),
                new ColliderType("wedge-cyl", 3),
                new ColliderType("wide-wedge", 0),
                new ColliderType("wide-wedge", 1),
                new ColliderType("wide-wedge", 2),
                new ColliderType("wide-wedge", 3)
                ));

    private Selector<ColliderType> colliderSelector;
    private VersionedReference<ColliderType> colliderRef;

    private Button editColor;
    private QuadBackgroundComponent colorView;
    private Container lightEditor;
    private Checkbox emissionCheck;
    private ColorChooser lightColorChooser;
    private VersionedReference<Boolean> emissionRef;
    private VersionedReference<ColorRGBA> lightColorRef;
    private TextField lightValueField;
    private VersionedReference<DocumentModel> lightValueRef;

    private RollupPanel substanceArrayRollup;
    private SubstanceArrayEditor substanceArrayEditor;
    private VersionedReference<List<Substance>> substanceArrayRef;

    private VersionedList<String> factoryTypes = new VersionedList<>(Arrays.asList("Default"));
    //private Selector factorySelector;
    private Label blockFactoryName;

    private Map<Class, String> factoryClassNames = new HashMap<>();
    private Map<Class, BlockFactoryEditor> factoryEditors = new HashMap<>();
    private RollupPanel factoryEditorRollup;

    private BlockSet blockSet;
    private MaterialSet materialSet;
    private BlockType blockType;
    private BlockFactory blockFactory;
    private VersionedReference<BlockFactory> blockFactoryChanges;

    public BlockTypeEditor() {
        factoryEditors.put(DefaultBlockFactory.class, new DefaultBlockFactoryEditor());
        factoryClassNames.put(DefaultBlockFactory.class, "Default");

        nameEditor = addChild(new BlockNameEditor());
        nameRef = nameEditor.createBlockNameReference();

        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("Group:"));

        Predicate<Character> numbers = TextFilters.isInChars('-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
        DocumentModel numeric = new DocumentModelFilter(TextFilters.charFilter(numbers), null);
        groupField = properties.addChild(new TextField(numeric), 1);
        groupRef = groupField.getDocumentModel().createReference();

        properties.addChild(new Label("Emission:"));
        Container light = properties.addChild(new Container(), 1);

        DocumentModel hex = new DocumentModelFilter(
                    TextFilters.charFilter(
                        TextFilters.isInChars('0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                                              'a', 'b', 'c', 'd', 'e', 'f',
                                              'A', 'B', 'C', 'D', 'E', 'F')), null);
        lightValueField = light.addChild(new TextField(hex));
        lightValueRef = lightValueField.getDocumentModel().createReference();
        editColor = light.addChild(new Button(""), 1);
        editColor.setInsets(new Insets3f(0, 0, 0, 0));
        colorView = new QuadBackgroundComponent(ColorRGBA.Black);
        editColor.setIcon(colorView);
        editColor.addClickCommands(new ColorPopupCommand());

        lightEditor = new Container();
        lightEditor.setBackground(new QuadBackgroundComponent(ColorRGBA.Black));
        lightEditor.getControl(GuiControl.class).addListener(new KeepOnScreen());
        emissionCheck = lightEditor.addChild(new Checkbox("Emission Enabled:"));
        lightColorChooser = lightEditor.addChild(new ColorChooser());
        emissionRef = emissionCheck.getModel().createReference();
        lightColorRef = lightColorChooser.getModel().createReference();

        properties.addChild(new Label("Collider:"));
        colliderSelector = properties.addChild(new Selector<ColliderType>(colliderTypes), 1);
        ((DefaultValueRenderer<ColliderType>)colliderSelector.getValueRenderer()).setStringTransform(new ColliderTypeToString());
        colliderRef = colliderSelector.createSelectedItemReference();

        properties.addChild(new Label("Block Factory:"));
        //factorySelector = properties.addChild(new Selector(factoryTypes), 1);
        blockFactoryName = properties.addChild(new Label("Default"), 1);

        factoryEditorRollup = addChild(new RollupPanel("Block Factory Editor", null));

        factoryEditorRollup.setContents(factoryEditors.get(DefaultBlockFactory.class).getEditor());


        substanceArrayRollup = addChild(new RollupPanel("Substances", null));
        substanceArrayEditor = new SubstanceArrayEditor();
        substanceArrayRollup.setContents(substanceArrayEditor);
        substanceArrayRef = substanceArrayEditor.createSubstanceArrayRef();
    }

    public void addBlockTypeFactory( String name, Class factoryType, BlockFactoryEditor editor ) {
        factoryEditors.put(factoryType, editor);
        factoryClassNames.put(factoryType, name);
        factoryTypes.add(name);
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);

        if( blockType == null ) {
            return;
        }

        if( nameRef.update() ) {
            blockType.setName(nameRef.get());
            version++;
        }
        if( colliderRef.update() ) {
            blockType.setColliderType(colliderRef.get());
            version++;
        }
        if( groupRef.update() ) {
            int val = 0;
            if( !Strings.isNullOrEmpty(groupField.getText()) ) {
                try {
                    val = Integer.parseInt(groupField.getText());
                } catch( NumberFormatException e ) {
                    val = -1;
                }
            }
            blockType.setTransparencyGroup(val);
            version++;
        }
        if( lightValueRef.update() ) {
            short color = parseLight(lightValueRef.get().getText());
            if( color > -1 ) {
                blockType.setLight(color);
                emissionCheck.setChecked(color != 0);

                ColorRGBA lightColor = lightToColor(color);
                colorView.setColor(lightColor);

                version++;
            }
        }
        if( emissionRef.update() || lightColorRef.update() ) {
            short color = calculateLightColor();
            log.info("Changing:" + blockType.getLight() + " to:" + color);
            blockType.setLight(color);

            ColorRGBA lightColor = lightToColor(color);
            colorView.setColor(lightColor);

            lightValueField.setText(String.format("%03X", blockType.getLight()));

            version++;
        }
        if( blockFactoryChanges != null && blockFactoryChanges.update() ) {
log.info("block factory changed.");
            blockType.setFactory(blockFactory);
            version++;
        }

        if( substanceArrayRef.update() ) {
            version++;
        }
    }

    protected short parseLight( String s ) {
        if( Strings.isNullOrEmpty(s) ) {
            return 0;
        }
        try {
            int i = Integer.parseInt(s, 16);
            return (short)i;
        } catch( Exception e ) {
            log.warn("Error parsing:" + s, e);
            return -1;
        }
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public BlockType getObject() {
        return blockType;
    }

    @Override
    public VersionedReference<BlockType> createReference() {
        return new VersionedReference<>(this);
    }

    public void setBlockSet( BlockSet blockSet ) {
        this.blockSet = blockSet;
        for( BlockFactoryEditor editor : factoryEditors.values() ) {
            editor.setBlockSet(blockSet);
        }
    }

    public void setMaterialSet( MaterialSet materialSet ) {
        this.materialSet = materialSet;
        for( BlockFactoryEditor editor : factoryEditors.values() ) {
            editor.setMaterialSet(materialSet);
        }
    }

    public void setBlockType( BlockType blockType ) {
        if( this.blockType == blockType ) {
            return;
        }
        this.blockType = blockType;
        substanceArrayEditor.setBlockType(blockType);
        updateFields();
    }

    protected void clearFields() {
        nameEditor.setBlockName(null);
        groupField.setText("0");
        colorView.setColor(ColorRGBA.Black);
        lightValueField.setText("000");
        emissionCheck.setChecked(false);
        //factorySelector.setSelectedItem("Default");
        blockFactoryName.setText("Default");
    }

    protected short calculateLightColor() {
        if( !emissionCheck.isChecked() ) {
            return 0;
        }
        ColorRGBA color = lightColorChooser.getColor();
        int r = (int)(color.r * 15);
        int g = (int)(color.g * 15);
        int b = (int)(color.b * 15);
        return (short)LightUtils.toLight(0, r, g, b);
    }

    protected ColorRGBA lightToColor( short light ) {
        float r = LightUtils.red(light) / 15f;
        float g = LightUtils.green(light) / 15f;
        float b = LightUtils.blue(light) / 15f;

        return new ColorRGBA(r,g,b,1);
    }

    protected void updateFields() {
        if( blockType == null ) {
            clearFields();
            return;
        }

        nameEditor.setBlockName(blockType.getName());
        groupField.setText(String.valueOf(blockType.getTransparencyGroup()));

        ColorRGBA lightColor;
        if( blockType.getLight() != 0 ) {
            lightColor = lightToColor(blockType.getLight());
            emissionCheck.setChecked(true);
        } else {
            lightColor = ColorRGBA.Black;
            emissionCheck.setChecked(false);
        }
        colorView.setColor(lightColor);
        lightColorChooser.setColor(lightColor);
        lightValueField.setText(String.format("%03X", blockType.getLight()));

        BlockFactory blockFactory = blockType.getFactory();
        setBlockFactory(blockFactory);

        if( !colliderTypes.contains(blockType.getColliderType()) ) {
            log.warn("Block type's collider is not selectable:" + blockType.getColliderType());
            log.info("types:" + colliderTypes);
        }
        colliderSelector.setSelectedItem(blockType.getColliderType());
    }

    @SuppressWarnings("unchecked")
    protected void setBlockFactory( BlockFactory blockFactory ) {
        if( this.blockFactory == blockFactory ) {
            return;
        }
        this.blockFactory = blockFactory;
        factoryEditorRollup.setContents(null);
        blockFactoryChanges = null;
        if( blockFactory == null ) {
            return;
        }
        BlockFactoryEditor factoryEditor = factoryEditors.get(blockFactory.getClass());
        if( factoryEditor != null ) {
            factoryEditor.setBlockFactory(blockFactory);
            factoryEditorRollup.setContents(factoryEditor.getEditor());
            blockFactoryChanges = factoryEditor.createReference();
        }
        String name = factoryClassNames.get(blockFactory.getClass());
        if( name == null ) {
            name = "Unknown";
        }
        blockFactoryName.setText(name);
    }

    private class ColorPopupCommand implements Command<Button> {
        public void execute( Button b ) {
            lightEditor.setLocalTranslation(b.getWorldTranslation());
            GuiGlobals.getInstance().getPopupState().clampToGui(lightEditor);
            GuiGlobals.getInstance().getPopupState().showPopup(lightEditor);
        }
    }

    private static class ColliderTypeToString implements Function<ColliderType, String> {
        public String apply( ColliderType type ) {
            if( type == null ) {
                return "-none-";
            }
            return type.toDisplay();
        }
    }

    private class KeepOnScreen extends AbstractGuiControlListener {

        @Override
        public void reshape( GuiControl source, Vector3f offset, Vector3f size ) {
            Spatial owner = source.getSpatial();
            if( owner == null ) {
                return;
            }
            GuiGlobals.getInstance().getPopupState().clampToGui(owner);
        }
    }
}
