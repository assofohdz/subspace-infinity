/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.BlockFactory;

/**
 *  Base class for making it easier to create custom block factory
 *  editors.
 *
 *  @author    Paul Speed
 */
public abstract class AbstractBlockFactoryEditor<T extends BlockFactory>
                                                    extends Container
                                                    implements BlockFactoryEditor<T> {
    static Logger log = LoggerFactory.getLogger(AbstractBlockFactoryEditor.class);

    private BlockSet blockSet;
    private MaterialSet materials;

    private T blockFactory;
    private long version;

    protected AbstractBlockFactoryEditor() {
    }

    protected void incrementVersion() {
        version++;
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public T getObject() {
        return blockFactory;
    }

    @Override
    public VersionedReference<T> createReference() {
        return new VersionedReference<>(this);
    }

    @Override
    public void setBlockSet( BlockSet blockSet ) {
        this.blockSet = blockSet;
    }

    protected BlockSet getBlockSet() {
        return blockSet;
    }

    @Override
    public void setMaterialSet( MaterialSet materials ) {
        this.materials = materials;
    }

    protected MaterialSet getMaterialSet() {
        return materials;
    }

    @Override
    public void setBlockFactory( T factory ) {
        if( this.blockFactory == factory ) {
            return;
        }
        this.blockFactory = (T)factory;
        onBlockFactoryChange(blockFactory);
    }

    @Override
    public T getBlockFactory() {
        return blockFactory;
    }

    @Override
    public Panel getEditor() {
        return this;
    }

    protected abstract void onBlockFactoryChange( T factory );

}
