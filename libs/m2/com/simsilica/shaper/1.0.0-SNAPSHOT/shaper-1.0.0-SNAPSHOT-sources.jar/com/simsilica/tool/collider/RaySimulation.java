/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.InputManager;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.input.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mworld.BlockIterator;
import com.simsilica.mworld.BlockIterator.Intersection;
import com.simsilica.tool.*;

/**
 *  Simulation that uses the mouse to intersect rays with the colliders.
 *
 *  @author    Paul Speed
 */
public class RaySimulation implements Simulation {

    static Logger log = LoggerFactory.getLogger(RaySimulation.class);

    private RayConfig config;
    private MBlockCollisionSystem<String> collisionSystem;

    private Camera camera;
    private InputManager inputMgr;
    private Node root;
    private double defaultLimit = 10;
    
    private Container editor;
    private Checkbox mouseCapture;
    
    private Vec3dEditor majorPos;
    private VersionedReference<Vec3d> majorRef;
    private Vec3dEditor minorPos;
    private VersionedReference<Vec3d> minorRef;
    private Label combinedPos;

    private Vec3dEditor direction;
    private VersionedReference<Vec3d> directionRef;
    private Spinner<Double> yaw;
    private VersionedReference<Double> yawRef;
    private Spinner<Double> pitch;
    private VersionedReference<Double> pitchRef;
    
    private Spinner<Double> projection;
    private VersionedReference<Double> projectionRef;
    private Spinner<Double> length;
    private VersionedReference<Double> lengthRef;
 
    private VersionedList<RayInfo> rays = new VersionedList<>();
    private ListBox<RayInfo> rayList;
    private VersionedReference<Integer> raySelectionRef;
    
    private RayInfo current;
    private Geometry rayGeom;
    private Mesh rayMesh;
    private ColorRGBA rayColor = ColorRGBA.Gray;
    private ColorRGBA projColor = ColorRGBA.Yellow;

    private Node viewRoot = new Node("hitViews");
    private Map<String, HitGeom> hitViews = new HashMap<>();
    
    public RaySimulation( Camera camera, InputManager inputMgr ) {
        this.camera = camera;
        this.inputMgr = inputMgr;
 
        this.config = RayConfig.getInstance();
        
        editor = new Container();
                
        mouseCapture = editor.addChild(new Checkbox("Mouse capture"));
 
        editor.addChild(new Label("Major Position:"));        
        majorPos = editor.addChild(new Vec3dEditor(Axis.X, -10, 10, 1.0, 1.0));
        majorPos.setObject(config.getMajorPos());
        majorRef = majorPos.createReference();

        editor.addChild(new Label("Minor Position:"));
        minorPos = editor.addChild(new Vec3dEditor(Axis.X, -1, 1, 0.01, 0.01));
        minorPos.setObject(config.getMinorPos());
        minorRef = minorPos.createReference();
 
        editor.addChild(new Label("Combined Position:"));
        combinedPos = editor.addChild(new Label(getPositionString()));

        editor.addChild(new Label("Direction:"));
        direction = editor.addChild(new Vec3dEditor(Axis.X, -1, 1, 0.01, 0.01));
        direction.setObject(config.getDirection());
        directionRef = direction.createReference();

        Container sub = editor.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        sub.addChild(new Label("Yaw:"));
        yaw = ProbeSimulation.createDoubleSpinner(-Math.PI, Math.PI, 0.01, 0.01, config.getYaw());
        sub.addChild(yaw);
        yawRef = yaw.getModel().createReference();

        sub.addChild(new Label("Pitch:"));
        pitch = ProbeSimulation.createDoubleSpinner(-Math.PI * 0.5, Math.PI * 0.5, 0.01, 0.01, config.getPitch());
        sub.addChild(pitch);
        pitchRef = pitch.getModel().createReference();

        editor.addChild(new Label("Projection:"));

        sub = editor.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        sub.addChild(new Label("Base:"));
        projection = ProbeSimulation.createDoubleSpinner(-10, 10, 0.01, 0.01, config.getProjection());
        sub.addChild(projection);
        projectionRef = projection.getModel().createReference();

        sub.addChild(new Label("Limit:"));
        length = ProbeSimulation.createDoubleSpinner(0.01, 10.0, 0.1, 0.01, config.getLength());
        sub.addChild(length);
        lengthRef = length.getModel().createReference();
 
 
        rays.addAll(config.getRays());
        editor.addChild(new Label("Saved Rays:"));
        rayList = editor.addChild(new ListBox<>(rays));
        raySelectionRef = rayList.getSelectionModel().createSelectionReference();
        editor.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeRay")));
        
        this.rayMesh = new Mesh();
        rayMesh.setMode(Mesh.Mode.Lines);
        rayGeom = new Geometry("ray", rayMesh);
        rayGeom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.White, false).getMaterial());
        rayGeom.getMaterial().setBoolean("VertexColor", true);
        
        resetRayGeom(new Vec3d(), new Vec3d(), 0, 0);
    }
 
    @Override
    public String getName() {
        return "Ray";
    }
 
    @Override
    public void setCollisionSystem( MBlockCollisionSystem<String> collisionSystem ) {
        this.collisionSystem = collisionSystem;
    }
    
    @Override
    public void update( float tpf ) {
        if( root != null && mouseCapture.isChecked() ) {
            pick();
        }
        if( raySelectionRef.update() ) {
            Integer selection = raySelectionRef.get();
            if( selection != null ) {
                setRayInfo(rays.get(selection));
            }
        }
        boolean changed = false;
        if( majorRef.update() ) {
            changed = true;
        }
 
        if( minorRef.update() ) {
            changed = true;
        }
        if( directionRef.update() ) {
            changed = true;
        }
        if( yawRef.update() ) {
            changed = true;
        }
        if( pitchRef.update() ) {
            changed = true;
        }
        if( projectionRef.update() ) {
            changed = true;
        }
        if( lengthRef.update() ) {
            changed = true;
        }
        if( changed ) {
            updateRay();
        }
    }
        
    @Override
    public Panel attach( Node root ) {
        this.root = root;

        root.attachChild(rayGeom);
        root.attachChild(viewRoot);
        
        return editor;        
    }
        
    @Override
    public void release() {
        rayGeom.removeFromParent();
        viewRoot.removeFromParent();
        
        config.setMajorPos(majorPos.getObject());
        config.setMinorPos(minorPos.getObject());
        config.setDirection(direction.getObject());
        config.setYaw(yaw.getValue());
        config.setPitch(pitch.getValue());
        config.setProjection(projection.getValue());
        config.setLength(length.getValue());

        config.setRays(rays);
        RayConfig.save();
        
    }
        
    @Override
    public void next() {
    }
        
    @Override
    public void previous() {
    }
        
    @Override
    public void freeze() {
        boolean capturing = mouseCapture.isChecked(); 
        mouseCapture.setChecked(!capturing);
        if( capturing ) {
            addRay();
        }        
    }
 
    protected void removeRay() {
        RayInfo ray = rayList.getSelectedItem();
        rays.remove(ray);
    }
    
    protected void addRay() {
        if( current != null && !rays.contains(current) ) {
            rays.add(current);
        }
    }
 
    protected Vec3d getPosition() {
        Vec3d major = majorPos.getObject();
        Vec3d minor = minorPos.getObject();
        return major.add(minor);
    }
    
    protected void setPosition( Vec3d pos ) {
        Vec3d major = pos.floor().toVec3d();
        Vec3d minor = pos.subtract(major);
        majorPos.setObject(major);
        minorPos.setObject(minor);
        combinedPos.setText(getPositionString());
    }
  
    protected String getPositionString() {
        Vec3d pos = getPosition();
        return String.format("x: %.2f  y: %.2f  z: %.2f", pos.x, pos.y, pos.z); 
    }
 
    protected Rayd getPickRay( Vector2f cursor ) {
    
        // Turns out these can be calculated the same as perspective... and
        // we should technically clip perspective also.
        Vector3f clickFar  = camera.getWorldCoordinates(cursor, 1);
        Vector3f clickNear = camera.getWorldCoordinates(cursor, 0);
        if( log.isTraceEnabled() ) {                
            log.trace("Creating Viewport ray, clickNear:" + clickNear + " clickFar:" + clickFar);
        }
        
        // Move those into block space
        clickFar = root.worldToLocal(clickFar, null);
        clickNear = root.worldToLocal(clickNear, null); 

        Vec3d base = new Vec3d(clickNear);
        Vec3d dir = new Vec3d(clickFar).subtractLocal(base).normalizeLocal();
        
        double lengthSq = dir.lengthSq();
        if( Math.abs(1.0 - lengthSq) > 0.1 ) {
            return null;
        }
        
        Rayd ray = new Rayd(base, dir);
        return ray;
    }
 
 
    protected void pick() {
        Rayd ray = getPickRay(inputMgr.getCursorPosition());        
        //log.info("Ray:" + ray);
        setRayInfo(new RayInfo(ray.getOrigin(), ray.getDirection(), 0, defaultLimit));
    }
    
    protected void setRayInfo( RayInfo current ) {
        if( Objects.equals(this.current, current) ) {
            return;
        }
        if( current == null ) {
            current = new RayInfo(new Vec3d(), new Vec3d(), 0, 0);
        }
        this.current = current;
        log.info("current:" + current);
        
        setPosition(current.origin);
        
        direction.setObject(current.dir);
        yaw.setValue(current.yaw);
        pitch.setValue(current.pitch);
        
        projection.setValue(current.projection);
        length.setValue(current.length);
        
        resetRayGeom(current.origin, current.dir, current.projection, current.length);
        
        updateHits();
    }
    
    protected void updateRay() {
        if( current == null ) {
            return;
        }
        current.origin.set(getPosition());
        current.dir.set(direction.getObject());
        current.yaw = yaw.getValue();
        current.pitch = pitch.getValue();
        current.projection = projection.getValue();
        current.length = length.getValue();
        resetRayGeom(current.origin, current.dir, current.projection, current.length);

        updateHits();
    }
 
    protected void updateHits() {
        Rayd ray = current.createRay();
        double limit = current.length - current.projection;

        Map<String, HitGeom> newViews = new HashMap<>();
        
        for( BlockColliderIterator it = collisionSystem.rayIterator(ray, limit); it.hasNext(); ) {
            Intersection hit = it.next();
            //log.info("hit:" + hit);
            String key = hit.toString();
            HitGeom geom = hitViews.remove(key);
            if( geom == null ) {
                if( newViews.containsKey(key) ) {
                    log.info("**** Already had a hit for:" + key);
                    // Leaving these in because the doodoo is a good indicator
                    // of other kinds of bugs.  Found and fixed the one that was
                    // causing me to see this today.
                    //continue; 
                }
                geom = new HitGeom(hit);
                geom.setLocalTranslation(hit.getPoint().toVector3f());
                viewRoot.attachChild(geom);
            }
            newViews.put(key, geom);
        }

        for( HitGeom geom : hitViews.values() ) {
            geom.removeFromParent();
        }

        hitViews = newViews;
    }
    
    protected void resetRayGeom( Vec3d base, Vec3d dir, double proj, double length ) {
 
        Mesh mesh = rayMesh;
        float crossScale = 0.01f;
        float endCross = 0.01f;
        Vector3f p = dir.mult(proj).toVector3f();
        Vector3f l = dir.mult(length).toVector3f();   
 
        mesh.setBuffer(VertexBuffer.Type.Position, 3, new float[] {
                    // Center crosshair
                    -crossScale, 0, 0,
                    crossScale, 0, 0,
                    0, -crossScale, 0,
                    0, crossScale, 0,
                    0, 0, -crossScale,
                    0, 0, crossScale,
                    
                    // Base to projection
                    0, 0, 0,
                    p.x, p.y, p.z,
                    
                    // Projection to length
                    p.x, p.y, p.z,
                    l.x, l.y, l.z,
                                        
                    // End cross
                    l.x - endCross, l.y, l.z,
                    l.x + endCross, l.y, l.z,
                    l.x, l.y - endCross, l.z,
                    l.x, l.y + endCross, l.z,
                    l.x, l.y, l.z - endCross,
                    l.x, l.y, l.z + endCross
                });
    
        mesh.setBuffer(VertexBuffer.Type.Color, 4, new float[] {
                    // Center crosshair
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    
                    // Base to projection
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    rayColor.r, rayColor.g, rayColor.b, rayColor.a,
                    
                    // Projection to length                    
                    projColor.r, projColor.g, projColor.b, projColor.a, 
                    projColor.r, projColor.g, projColor.b, projColor.a,

                    // End cross
                    projColor.r, projColor.g, projColor.b, projColor.a, 
                    projColor.r, projColor.g, projColor.b, projColor.a,
                    projColor.r, projColor.g, projColor.b, projColor.a, 
                    projColor.r, projColor.g, projColor.b, projColor.a,
                    projColor.r, projColor.g, projColor.b, projColor.a, 
                    projColor.r, projColor.g, projColor.b, projColor.a
                });
 
        mesh.updateBound();
        rayGeom.updateModelBound();
        rayGeom.setLocalTranslation(base.toVector3f());               
    }
    
    public static class RayInfo {
        public Vec3d origin;
        public Vec3d dir;
        public double yaw;
        public double pitch;
        public double projection;
        public double length;
        
        public RayInfo( Vec3d origin, Vec3d dir, double projection, double length ) {
            this.origin = origin.clone();
            this.dir = dir.clone();
            this.projection = projection;
            this.length = length;
            updateAngles();
        }

        public void updateAngles() {
            yaw = Math.atan2(dir.x, -dir.z);
            double xzDist = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
            pitch = Math.atan2(dir.y, xzDist);
        }
        
        public void rebase() {
            origin = origin.add(dir.mult(projection));
            length -= projection;
            projection = 0;
        }
        
        public Rayd createRay() {
            Vec3d o = origin.add(dir.mult(projection));
            return new Rayd(o, dir.normalize());
        }
 
        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            RayInfo other = (RayInfo)o;
            if( other.projection != projection ) {
                return false;
            }
            if( other.length != length ) {
                return false;
            }
            if( !Objects.equals(other.origin, origin) ) {
                return false;
            }
            if( !Objects.equals(other.dir, dir) ) {
                return false;
            }
            return true;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(origin, dir, projection, length);
        }
        
        @Override
        public String toString() {
            return String.format("[%.2f, %.2f, %.2f] d:[%.2f, %.2f, %.2f] p:%.2f l:%.2f", 
                                origin.x, origin.y, origin.z, 
                                dir.x, dir.y, dir.z, 
                                projection, length);
        }
    }
}
