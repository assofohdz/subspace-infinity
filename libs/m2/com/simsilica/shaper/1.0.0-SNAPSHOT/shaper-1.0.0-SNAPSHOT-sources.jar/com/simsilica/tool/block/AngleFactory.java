/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *  A wedge laying on its side, few bells or whistles.
 *
 *  @author    Paul Speed
 */
public class AngleFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(AngleFactory.class);

    public AngleFactory() {
        super("Angle", "angle");
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
            
        MaterialType mtInternal = config2.getMaterialType();

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();

        BoundaryShape quad = BoundaryShapes.UNIT_SQUARE;
        BoundaryShape triangle = BoundaryShapes.getTriangle(0, 0, 1, 1, 1/Math.sqrt(2), 1/Math.sqrt(2)); 
 
        dirTemplates[0] = DefaultPartFactory.create(quad, GeomPart.createFace(mt, Direction.North));
        dirTemplates[3] = DefaultPartFactory.create(quad, GeomPart.createFace(mt, Direction.West));

        GeomPart up = new GeomPart(mt, Direction.Up.ordinal(), false);
        up.setCoords(
            1, 1, 0,
            0, 1, 0,
            0, 1, 1
            );
        up.setTexCoords(
            1, 1,
            0, 1,
            0, 0
            );
        up.setIndexes(0, 1, 2);
        up.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[4] = DefaultPartFactory.create(triangle, up);

        GeomPart down = new GeomPart(mt, Direction.Down.ordinal(), false);
        down.setCoords(
            0, 0, 0,
            1, 0, 0,
            0, 0, 1
            );
        // These coordinates will stretch the texture funny but that's
        // the default mapping for old Mythruna, also.
        down.setTexCoords(
            0, 0,
            1, 0,
            0, 1
            );
        down.setIndexes(0, 1, 2);
        down.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[5] = DefaultPartFactory.create(triangle, down);
 
 
        Vector3f norm = new Vector3f(1, 0, 1).normalizeLocal();
        Vector3f tangent = new Vector3f(1, 0, -1).normalizeLocal();

        GeomPart slope = new GeomPart(mtInternal, -1, false);            
        slope.setCoords(
            0, 0, 1,
            1, 0, 0,
            1, 1, 0,
            0, 1, 1
            );
        slope.setTexCoords(
            0, 0,
            1, 0,
            1, 1,
            0, 1
            );
                
                
        slope.setNormals(FloatUtils.toFloatArray(4, norm));
        slope.setTangents(FloatUtils.toFloatArray(4, tangent));
        slope.setIndexes(0, 1, 2, 0, 2, 3);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("angle", 0));
    }
}



