/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.input.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.tool.collider.*;

/**
 *  Simulation that drops random spheres on the colliders.
 *
 *  @author    Paul Speed
 */
public class SpheresSimulation implements Simulation {

    static Logger log = LoggerFactory.getLogger(SpheresSimulation.class);

    private MBlockCollisionSystem<String> collisionSystem;
    
    private Panel editor;
    
    public SpheresSimulation() {
        editor = new Label("Ray");
    }
 
    @Override
    public String getName() {
        return "Spheres";
    }
 
    @Override
    public void setCollisionSystem( MBlockCollisionSystem<String> collisionSystem ) {
        this.collisionSystem = collisionSystem;
    }
 
    @Override
    public void update( float tpf ) {
    }
        
    @Override
    public Panel attach( Node root ) {
        return editor;        
    }
        
    @Override
    public void release() {
    }
        
    @Override
    public void next() {
    }
        
    @Override
    public void previous() {
    }
        
    @Override
    public void freeze() {
    }
}
