/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class WedgeCornerFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(WedgeCornerFactory.class);

    public WedgeCornerFactory() {
        super("Wedge Corner", "wedge-corner",
              new Parameter<Boolean>("Stretch Side UVs", Boolean.class, false),
              new Parameter<Boolean>("Mitre Corner UVs", Boolean.class, false)
            );
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        Boolean stretch = (Boolean)parameterValues[0];
        Boolean mitre = (Boolean)parameterValues[1];

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
            
        MaterialType mtInternal = config2.getMaterialType();

        // This shape has three boundary faces and two internal faces.
        // A quad boundary face for "down" (which will have different texture
        // coordinates based on the 'mitre' flag.
        // Two triangular faces for the sides, possibly with stretched UVs similar to
        // a regular wedge.
        // And the two internal triangles that make up the corner. 

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();

        BoundaryShape quad = BoundaryShapes.UNIT_SQUARE;
        BoundaryShape triangle = BoundaryShapes.getTriangle(0, 0, 1, 1, 1/Math.sqrt(2), 1/Math.sqrt(2)); 
 
        GeomPart down;
        if( mitre ) {
            // For a mitred base, we have to use unshared vertexes or
            // we won't be able to mitre the UVs
            // Note: I think for indexed normals that our tangents will
            // be wrong for half of the base... problem for another day.
            // Sorry, future-Paul.  -pspeed:2021-05-14
            down = new GeomPart(mt, Direction.Down.ordinal(), false);
            down.setCoords(
                    0, 0, 0,
                    1, 0, 1,
                    0, 0, 1,                    
                    0, 0, 0,
                    1, 0, 0,
                    1, 0, 1                    
                );
            down.setTexCoords(
                0, 0,
                1, 1,
                0, 1,
                0, 1,  // the mitre
                0, 0,
                1, 0
                );
            down.setIndexes(0, 1, 2, 3, 4, 5);
            down.setupAlternates(); // for indexed and non-indexed materials
        } else {
            down = GeomPart.createFace(mt, Direction.Down);
        } 
        dirTemplates[5] = DefaultPartFactory.create(quad, down);

        GeomPart north = new GeomPart(mt, Direction.North.ordinal(), false);
        north.setCoords(
            1, 0, 0,
            0, 0, 0,
            0, 1, 0
            );
        if( stretch ) {
            north.setTexCoords(
                0, 1,
                1, 0,
                1, 1
                );
        } else {
            north.setTexCoords(
                0, 0,
                1, 0,
                1, 1
                );
        }
                
        north.setIndexes(0, 1, 2);
        north.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[0] = DefaultPartFactory.create(triangle, north);

        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        west.setCoords(
            0, 0, 0,
            0, 0, 1,
            0, 1, 0
            );
        if( stretch ) {
            west.setTexCoords(
                0, 0,
                1, 1,
                0, 1    
                );
        } else {
            west.setTexCoords(
                0, 0,
                1, 0,
                0, 1    
                );
        }
        west.setIndexes(0, 1, 2);
        west.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[3] = DefaultPartFactory.create(triangle, west);
 
        // Now for the two slopes
        Vector3f normSouth = new Vector3f(0, 1, 1).normalizeLocal();
        Vector3f tanSouth = new Vector3f(1, 0, 0);
        Vector3f normEast = new Vector3f(1, 1, 0).normalizeLocal();
        Vector3f tanEast = new Vector3f(0, 0, -1);
 
        // South first
        GeomPart slope;
        slope = new GeomPart(mtInternal, -1, false);            
        slope.setCoords(
            0, 0, 1,
            1, 0, 1,
            0, 1, 0
            );
        slope.setTexCoords(
            0, 0,
            1, 0,
            0, 1
            );
        slope.setNormals(FloatUtils.toFloatArray(3, normSouth));
        slope.setTangents(FloatUtils.toFloatArray(3, tanSouth));
        slope.setIndexes(0, 1, 2);
        internalParts.add(slope);            

        // Now east
        slope = new GeomPart(mtInternal, -1, false);            
        slope.setCoords(
            1, 0, 1,
            1, 0, 0,
            0, 1, 0
            );
        if( mitre ) {
            slope.setTexCoords(
                0, 0,
                1, 0,
                1, 1
                );
        } else {
            slope.setTexCoords(
                1, 0,
                1, 1,
                0, 1
                );
        }
        slope.setNormals(FloatUtils.toFloatArray(3, normEast));
        slope.setTangents(FloatUtils.toFloatArray(3, tanEast));
        slope.setIndexes(0, 1, 2);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("wedge-corner", 0));
    }
}



