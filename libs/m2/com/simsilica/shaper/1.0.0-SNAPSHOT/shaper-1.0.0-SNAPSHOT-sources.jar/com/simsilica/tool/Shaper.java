/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import java.util.Objects;

import com.jme3.anim.*;
import com.jme3.anim.tween.action.*;
import com.jme3.anim.util.*;
import com.jme3.app.*;
import com.jme3.app.state.ScreenshotAppState;
import com.jme3.light.*;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;
import com.jme3.system.AppSettings;

import com.jme3.util.mikktspace.MikktspaceTangentGenerator;
import com.jme3.texture.plugins.AWTLoader;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.QuadBackgroundComponent;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.*;

import com.simsilica.fx.LightingState;
import com.simsilica.fx.sky.SkyState;
import com.simsilica.fx.sky.SkySettingsState;

import com.simsilica.input.MovementState;
import com.simsilica.state.*;


import com.simsilica.mblock.geom.*;

/**
 *  The main demo for the mphys stuff.
 *
 *  @author    Paul Speed
 */
public class Shaper extends SimpleApplication {

    private Geometry baseCube;

    public static void main( String... args ) throws Exception {

        Shaper main = new Shaper();
        AppSettings settings = new AppSettings(true);

        // Set some defaults that will get overwritten if
        // there were previously saved settings from the last time the user
        // ran.
        settings.setWidth(1280);
        settings.setHeight(720);
        settings.setVSync(true);

        settings.load("MOSS-Shaper Tool");
        settings.setTitle("MOSS-Shaper Tool");

        settings.setUseJoysticks(true);

        main.setSettings(settings);

        main.start();
    }

    public Shaper() {
        super(new StatsAppState(), new DebugKeysAppState(), new BasicProfilerState(false),
              new DebugHudState(),
              new MemoryDebugState(),
              new DebugNormalsState(),
              new CameraState(70, 0.1f, 8000),
              //new MovementState(), // from SiO2
              new OptionPanelState(), // from Lemur
              new OrbitCameraState(),
              new LightingState(),
              new SkyState(true),
              new SkySettingsState(),
              new GeometryInfoState(),
              new MainMenuState("Shaper"),
              new FileMenuState(),
              new ShaperEnvironmentSettingsState(),
              new BlockSetMenuState(),
              new FluidSetMenuState(),
              new ColliderTabMenuState(),
              new DebugSignatureState(),
              new MessageState(),
              new BlockTypeState(),
              new DebugBoundaryShapesState(),
              new DebugSettingsState(),
              new CommandConsoleState(),
              new ScriptsState(),
              new BlockSetReportState(),
              new ScreenshotAppState("", System.currentTimeMillis()));
    }

    public void simpleInitApp() {

        setPauseOnLostFocus(false);
        setDisplayFps(false);
        setDisplayStatView(false);

        GuiGlobals.initialize(this);

        GuiGlobals globals = GuiGlobals.getInstance();

        BaseStyles.loadGlassStyle();
        globals.getStyles().setDefaultStyle("glass");

        InputMapper inputMapper = globals.getInputMapper();
        MainMenuState.initializeDefaultMappings(inputMapper);
        OrbitCameraFunctions.initializeDefaultMappings(inputMapper);


        // Some manual styling for the debug HUD
        Styles styles = globals.getStyles();

        Attributes attrs = styles.getSelector(DebugHudState.CONTAINER_ID, "glass");
        attrs.set("background", null);

        attrs = styles.getSelector(DebugHudState.NAME_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("textHAlignment", HAlignment.Right);
        attrs.set("insets", new Insets3f(0, 0, 0, 0));

        attrs = styles.getSelector(DebugHudState.VALUE_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("insets", new Insets3f(0, 0, 0, 0));
        //attrs.set("textHAlignment", HAlignment.Right);


        globals.setCursorEventsEnabled(false);

        SkyState sky = stateManager.getState(SkyState.class);
        sky.getGroundColor().set(0.3f, 0.5f, 0.1f, 1);
        //sky.setShowGroundDisc(false);
        //sky.setFlatShaded(true);

        // Set the time of day
        LightingState lighting = stateManager.getState(LightingState.class);
        //lighting.setSunColor(ColorRGBA.White.clone().mult(1.5f));
        //lighting.setAmbient(ColorRGBA.White.clone());
        lighting.setSunColor(ColorRGBA.White.clone());
        lighting.setAmbient(ColorRGBA.White.clone().mult(0.75f));

        /*Geometry geom;
        Box box;
        Material mat;

        box = new Box(1, 1, 1);
        geom = new Geometry("blueBox", box);

        MaterialConfig mConfig = new MaterialConfig("blueBox", "Common/MatDefs/Light/PBRLighting.j3md");
        mConfig.put("BaseColor", ColorRGBA.Gray);
        mConfig.put("Metallic", 0.99f);
        mConfig.put("Roughness", 0.01f);
        geom.setMaterial(mConfig.createMaterial(assetManager));
        //geom.move(0, 1, -4);
        geom.center();
        geom.move(0, 1, 0);
        rootNode.attachChild(geom);

        box = new Box(5, 0.1f, 5);
        geom = new Geometry("stage", box);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Gray, true).getMaterial());
        geom.getMaterial().setColor("Ambient", ColorRGBA.Gray.mult(0.5f));
        geom.center();
        geom.move(0, -0.1f, 0);
        rootNode.attachChild(geom);*/

        // For now until we have the real camera control setup
        //cam.setLocation(new Vector3f(4.728622f, 3.3771257f, 8.399825f));
        //cam.setRotation(new Quaternion(-0.04122545f, 0.9576989f, -0.17686273f, -0.22323282f));
        //cam.setLocation(new Vector3f(4.728622f, 3.3771257f, 8.399825f));
        //cam.setRotation(new Quaternion(-0.117936045f, 0.88107693f, -0.30090657f, -0.34532556f));
    }


}


