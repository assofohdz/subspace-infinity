/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *  A half wedge sitting on a box, basically.
 *
 *  @author    Paul Speed
 */
public class HiWedgeFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(HiWedgeFactory.class);

    public HiWedgeFactory() {
        super("HiWedge", "hi-wedge",
                new Parameter<Boolean>("Invert Y", Boolean.class, false),
                new Parameter<Boolean>("Skew Texture", Boolean.class, false)
            );
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        Boolean invertY = (Boolean)parameterValues[0];
        boolean stretch = false;
        Boolean skew = (Boolean)parameterValues[1];

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);        
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
 
        // For the truncated side south... and the quad parts
        // of the east/west sides
        Vec3d min = new Vec3d(0, 0, 0);
        Vec3d max = new Vec3d(1, 0.5, 1);
        if( invertY ) {
            min.y = 0.5;
            max.y = 1.0;
        }
            
        MaterialType mtInternal = config2.getMaterialType();

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();
        
        Vector3f normal = new Vector3f(0, 1 * (invertY ? -1 : 1), 0.5f).normalizeLocal();

        BoundaryShape northShape = BoundaryShapes.UNIT_SQUARE;
        BoundaryShape southShape = BoundaryShapes.getRect(min.x, min.y, max.x, max.y);
        BoundaryShape downShape = BoundaryShapes.UNIT_SQUARE; 
        
        // We don't have a trapezoidal shape so we'll pick a shape that
        // will match our other similar sides but is unlikely to match
        // other things.  In this case, just the triangle part.  This is
        // what the original engine did but we may want something better eventually
        // since this will mess with anything that tries to reason about the boundary
        // shape.
        BoundaryShape sideShape;
        if( invertY ) { 
            // Half triangle facing down from y = 0.5
            sideShape = BoundaryShapes.getTriangle(0, 0, 1, 0.5, normal.z, normal.y);
        } else {
            // Half triangle facing up from y = 0.5
            sideShape = BoundaryShapes.getTriangle(0, 0.5, 1, 1, normal.z, normal.y);
        }
                                                                    
        dirTemplates[0] = DefaultPartFactory.create(northShape, GeomPart.createFace(mt, Direction.North));
        GeomPart south = GeomPart.createQuad(min, max, mt, Direction.South, stretch);
        if( skew ) {
            // Potentially need to slide the texture coordinates
            float[] uvs = south.getTexCoords();
            for( int i = 0; i < uvs.length; i += 2 ) {                
                // Shift the uvs appropriately
                if( invertY ) {
                    uvs[i + 1] -= min.y;
                } else {
                    uvs[i + 1] += (1 - max.y);
                }
            }
        } 
        dirTemplates[1] = DefaultPartFactory.create(southShape, south);
        if( invertY ) {
            dirTemplates[4] = DefaultPartFactory.create(downShape, GeomPart.createFace(mt, Direction.Up));
        } else {
            dirTemplates[5] = DefaultPartFactory.create(downShape, GeomPart.createFace(mt, Direction.Down));
        }

        // The east/west sides will eb sideway trapezoids made of two
        // triangles... basically a box with one of the corners pull up.
        // Except that distorts the stretched textures so I think we have
        // to do three triangles... two for a quad and one for the triangle
        // top.
        GeomPart east = new GeomPart(mt, Direction.East.ordinal(), false);
        if( invertY ) {
            east.setCoords(
                1, (float)max.y, 1,
                1, (float)max.y, 0,
                1, (float)min.y, 0,
                1,        0,     0,
                1, (float)min.y, 1
                );
            if( skew ) {
                east.setTexCoords(
                    0, (float)min.y,
                    1, 1,
                    1, (float)min.y,
                    1, 0,
                    0, 0
                    );
                    
            } else {
                east.setTexCoords(
                    0, 1,
                    1, 1,
                    1, (float)min.y,
                    1, 0,
                    0, (float)min.y
                    );
            }
            east.setIndexes(0, 2, 1, 0, 4, 2, 2, 4, 3);
        } else {
            //       3
            //
            //  4    2
            //       
            //  0    1
            east.setCoords(
                1, (float)min.y, 1,
                1, (float)min.y, 0,
                1, (float)max.y, 0,
                1,        1,     0,
                1, (float)max.y, 1
                );
            if( skew ) {
                east.setTexCoords(
                    0, (float)max.y,
                    1, 0,
                    1, (float)max.y,
                    1, 1,
                    0, 1
                    );
            } else {
                east.setTexCoords(
                    0, 0,
                    1, 0,
                    1, (float)max.y,
                    1, 1,
                    0, (float)max.y
                    );
            }
            //east.setIndexes(0, 1, 2, 0, 2, 4, 2, 3, 4);
            east.setIndexes(0, 1, 4, 1, 2, 4, 2, 3, 4);
        }
        east.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[2] = DefaultPartFactory.create(sideShape, east);


        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        if( invertY ) {
            west.setCoords(
                0, (float)max.y, 1,
                0, (float)max.y, 0,
                0, (float)min.y, 0,
                0,        0,     0,
                0, (float)min.y, 1
                );
            if( skew ) {
                west.setTexCoords(
                    1, (float)min.y,
                    0, 1,
                    0, (float)min.y,
                    0, 0,
                    1, 0
                    );
                    
            } else {
                west.setTexCoords(
                    1, 1,
                    0, 1,
                    0, (float)min.y,
                    0, 0,
                    1, (float)min.y
                    );
            }
            west.setIndexes(0, 1, 2, 0, 2, 4, 2, 3, 4);
        } else {
            west.setCoords(
                0, (float)min.y, 1,
                0, (float)min.y, 0,
                0, (float)max.y, 0,
                0,        1,     0,
                0, (float)max.y, 1
                );
            if( skew ) {
                west.setTexCoords(
                    1, (float)max.y,
                    0, 0,
                    0, (float)max.y,
                    0, 1,
                    1, 1
                    );
            } else {
                west.setTexCoords(
                    1, 0,
                    0, 0,
                    0, (float)max.y,
                    0, 1,
                    1, (float)max.y
                    );
            }
            west.setIndexes(0, 4, 1, 1, 4, 2, 2, 4, 3);
        }

        west.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[3] = DefaultPartFactory.create(sideShape, west);
 
        Vector3f norm = normal; //new Vector3f(0, 1, 1).normalizeLocal();            
        Vector3f tangent = new Vector3f(1, 0, 0); 

        GeomPart slope = new GeomPart(mtInternal, -1, false);
        if( invertY ) {            
            slope.setCoords(
                (float)min.x, (float)0, (float)min.z,
                (float)max.x, (float)0, (float)min.z,
                (float)max.x, (float)min.y, (float)max.z,
                (float)min.x, (float)min.y, (float)max.z
                );
        } else {
            slope.setCoords(
                (float)min.x, (float)max.y, (float)max.z,
                (float)max.x, (float)max.y, (float)max.z,
                (float)max.x, (float)1, (float)min.z,
                (float)min.x, (float)1, (float)min.z
                );
        }
        slope.setTexCoords(
            0, 0,
            1, 0,
            1, 1,
            0, 1
            );
                
        slope.setNormals(FloatUtils.toFloatArray(4, norm));
        slope.setTangents(FloatUtils.toFloatArray(4, tangent));
        slope.setIndexes(0, 1, 2, 0, 2, 3);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("wedge", 0));
    }
}


