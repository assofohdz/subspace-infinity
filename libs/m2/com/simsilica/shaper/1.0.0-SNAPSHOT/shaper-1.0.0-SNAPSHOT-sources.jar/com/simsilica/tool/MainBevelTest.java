/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import java.util.Objects;

import com.jme3.anim.*;
import com.jme3.anim.tween.action.*;
import com.jme3.anim.util.*;
import com.jme3.app.*;
import com.jme3.app.state.ScreenshotAppState;
import com.jme3.light.*;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;
import com.jme3.system.AppSettings;

import com.jme3.util.mikktspace.MikktspaceTangentGenerator;
import com.jme3.texture.plugins.AWTLoader;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.QuadBackgroundComponent;
import com.simsilica.lemur.style.*;

import com.simsilica.fx.LightingState;
import com.simsilica.fx.sky.SkyState;
import com.simsilica.fx.sky.SkySettingsState;

import com.simsilica.input.MovementState;
import com.simsilica.state.*;


import com.simsilica.mblock.geom.*;

/**
 *  The main demo for the mphys stuff.
 *
 *  @author    Paul Speed
 */
public class MainBevelTest extends SimpleApplication {

    private Geometry baseCube;

    public static void main( String... args ) throws Exception {

        MainBevelTest main = new MainBevelTest();
        AppSettings settings = new AppSettings(true);

        // Set some defaults that will get overwritten if
        // there were previously saved settings from the last time the user
        // ran.
        settings.setWidth(1280);
        settings.setHeight(720);
        settings.setVSync(true);

        settings.load("MOSS-Net Char Demo");
        settings.setTitle("MOSS-Net Char Demo");

        settings.setUseJoysticks(true);

        main.setSettings(settings);

        main.start();
    }

    public MainBevelTest() {
        super(new StatsAppState(), new DebugKeysAppState(), new BasicProfilerState(false),
              new DebugHudState(),
              new MemoryDebugState(),
              new CameraState(70, 0.1f, 8000),
              new MovementState(), // from SiO2
              new OptionPanelState(), // from Lemur
              new LightingState(),
              new SkyState(true),
              new SkySettingsState(),
              new MessageState(),
              new CommandConsoleState(),
              new ScreenshotAppState("", System.currentTimeMillis()));
    }

    public void simpleInitApp() {

        setPauseOnLostFocus(false);
        setDisplayFps(false);
        setDisplayStatView(false);

        GuiGlobals.initialize(this);

        GuiGlobals globals = GuiGlobals.getInstance();

        BaseStyles.loadGlassStyle();
        globals.getStyles().setDefaultStyle("glass");

        // Some manual styling for the debug HUD
        Styles styles = globals.getStyles();

        Attributes attrs = styles.getSelector(DebugHudState.CONTAINER_ID, "glass");
        attrs.set("background", null);

        attrs = styles.getSelector(DebugHudState.NAME_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("textHAlignment", HAlignment.Right);
        attrs.set("insets", new Insets3f(0, 0, 0, 0));

        attrs = styles.getSelector(DebugHudState.VALUE_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("insets", new Insets3f(0, 0, 0, 0));
        //attrs.set("textHAlignment", HAlignment.Right);

        globals.setCursorEventsEnabled(false);

        SkyState sky = stateManager.getState(SkyState.class);
        sky.getGroundColor().set(0.3f, 0.5f, 0.1f, 1);

        // Set the time of day
        LightingState lighting = stateManager.getState(LightingState.class);
        //lighting.setSunColor(ColorRGBA.White.clone().mult(1.5f));
        //lighting.setAmbient(ColorRGBA.White.clone()); 
        lighting.setSunColor(ColorRGBA.White.clone());
        //lighting.setAmbient(ColorRGBA.White.clone().mult(0.75f));
/*
        Geometry geom;
        Box box;
        Material mat;

        box = new Box(1, 1, 1);
        geom = new Geometry("blueBox", box);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Blue, true).getMaterial());
        geom.getMaterial().setColor("Ambient", ColorRGBA.Blue.mult(0.5f));
        geom.move(0, 1, -4);
        rootNode.attachChild(geom);

        box = new Box(5, 0.1f, 5);
        geom = new Geometry("stage", box);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Gray, true).getMaterial());
        geom.getMaterial().setColor("Ambient", ColorRGBA.Gray.mult(0.5f));
        geom.move(0, -0.1f, 0);
        rootNode.attachChild(geom);
        
        MaterialConfig mConfig = new MaterialConfig("test", "Common/MatDefs/Light/PBRLighting.j3md");
        mConfig.put("BaseColor", ColorRGBA.Blue);  
        mConfig.put("Metallic", 0.5f);
        mConfig.put("Roughness", 0.5f);
        
        box = new Box(0.5f, 0.5f, 0.5f);
        geom = new Geometry("cube", box);
        //mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        //mat.setColor("BaseColor", ColorRGBA.Blue);
        //mat.setFloat("Metallic", 0.5f);        
        //mat.setFloat("Roughness", 0.5f);
        mat = mConfig.createMaterial(assetManager);        
        geom.setMaterial(mat);
        geom.move(0, 0.5f, 0);
        rootNode.attachChild(geom);
 
        Sphere ball = new Sphere(12, 24, 0.5f); 
        geom = new Geometry("ball", ball);
        mat = mConfig.createMaterial(assetManager);        
        //mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        //mat.setColor("BaseColor", ColorRGBA.Blue);
        //mat.setFloat("Metallic", 0.5f);        
        //mat.setFloat("Roughness", 0.5f);        
        geom.setMaterial(mat);
        geom.move(2, 0.5f, 0);
        rootNode.attachChild(geom);
  
        ball = new Sphere(24, 24, 0.5f); 
        geom = new Geometry("ball", ball);
        //mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        //mat.setColor("BaseColor", ColorRGBA.Blue);
        //mat.setFloat("Metallic", 0.75f);        
        //mat.setFloat("Roughness", 0.25f);
        mConfig.put("Metallic", 0.75f);
        mConfig.put("Roughness", 0.25f);
        mat = mConfig.createMaterial(assetManager);        
        geom.setMaterial(mat);
        geom.move(-2, 0.5f, 0);
        rootNode.attachChild(geom);       

        ball = new Sphere(24, 24, 0.5f); 
        geom = new Geometry("ball", ball);
        //mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        //mat.setColor("BaseColor", ColorRGBA.Blue);
        mConfig.put("Metallic", 0); //0.5f);        
        mConfig.put("Roughness", 1); //0.5f);
        mConfig.put("UseSpecGloss", true);
        mConfig.put("Glossiness", 0.5f);        
        mConfig.put("Metallic", 0.75f);
        mConfig.put("Roughness", 0.25f);
        mat = mConfig.createMaterial(assetManager);        
        geom.setMaterial(mat);
        geom.move(4, 0.5f, 0);
        rootNode.attachChild(geom);


        BufferedImage img = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB); 
        Graphics g = img.createGraphics();
        
//      vec3 normal = normalHeight.xyz 
//                * vec3(2.0, NORMAL_TYPE * 2.0, 2.0) 
//                - vec3(1.0, NORMAL_TYPE * 1.0, 1.0)));
//
//      I think this means that 0..1 maps to -1..1
//      so a normal straight up would be color 0.5, 1, 0.5, right?
//      No, because z is 'up'... so 0.5, 0.5, 1 = 0, 0, 1 in tangent space.
//      Straight up.
//
        //g.setColor(new Color(0.5f, 1, 0.5f));
        g.setColor(new Color(0.5f, 0.5f, 1));
        g.fillRect(0, 0, 128, 128); 
 
        Vector3f v = new Vector3f(0, 1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color n45 = new Color(v.x, v.y, v.z);
        g.setColor(n45);
        g.fillRect(0, 127, 128, 128); 

        v = new Vector3f(0, -1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color s45 = new Color(v.x, v.y, v.z);
        g.setColor(s45);
        g.fillRect(0, 0, 128, 1); 
 
        v = new Vector3f(1, 0, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color e45 = new Color(v.x, v.y, v.z);
        g.setColor(e45);
        g.fillRect(127, 0, 128, 128);  

        v = new Vector3f(-1, 0, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color w45 = new Color(v.x, v.y, v.z);
        g.setColor(w45);
        g.fillRect(0, 0, 1, 128);  

        // Fill in something for the corners, too.
        v = new Vector3f(1, 1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color ne45 = new Color(v.x, v.y, v.z);
        g.setColor(ne45);
        g.fillRect(127, 127, 128, 128);  

        v = new Vector3f(-1, 1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color nw45 = new Color(v.x, v.y, v.z);
        g.setColor(nw45);
        g.fillRect(0, 127, 1, 128);  

        v = new Vector3f(1, -1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color se45 = new Color(v.x, v.y, v.z);
        g.setColor(se45);
        g.fillRect(127, 0, 128, 1);  

        v = new Vector3f(-1, -1, 1).normalizeLocal();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        Color sw45 = new Color(v.x, v.y, v.z);
        g.setColor(sw45);
        g.fillRect(0, 0, 1, 1);  

        
        //g.setColor(Color.BLUE);
        //g.fillRect(10, 10, 60, 60);
        g.dispose();        

        Image jmeImg = new AWTLoader().load(img, false);
        Texture nm = new Texture2D(jmeImg); 
        nm.setMinFilter(Texture.MinFilter.NearestNoMipMaps);
        nm.setMagFilter(Texture.MagFilter.Nearest);
        //nm.setWrap(Texture.WrapMode.Repeat);
        Texture bevel1 = nm;

        box = new Box(0.5f, 0.5f, 0.5f);        
        //box = new Box(1, 0.5f, 0.5f);
        //box.scaleTextureCoordinates(new Vector2f(2, 1));        
        geom = new Geometry("cube", box);
        mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        mat.setColor("BaseColor", ColorRGBA.Blue);
        //mat.setTexture("BaseColorMap", nm);
        mat.setFloat("Metallic", 0.5f);        
        mat.setFloat("Roughness", 0.5f);
        //Texture nm = assetManager.loadTexture("human-female-norms.png");
        mat.setTexture("NormalMap", nm);
        mat.setFloat("NormalType", 1);
        geom.setMaterial(mat);
        geom.move(0, 2.5f, 0);
        MikktspaceTangentGenerator.generate(geom);
        rootNode.attachChild(geom);

        baseCube = geom.clone();
        baseCube.setLocalTranslation(0, 0, 0);

        //Texture nm = assetManager.loadTexture("human-female-norms.png");
        img = createGradientBox(128, 8, UP | DOWN | LEFT | RIGHT);
        jmeImg = new AWTLoader().load(img, false);
        nm = new Texture2D(jmeImg); 
        //nm.setWrap(Texture.WrapMode.Repeat);
        Texture bevel2 = nm;
        //nm.setMinFilter(Texture.MinFilter.NearestNoMipMaps);
        //nm.setMagFilter(Texture.MagFilter.Nearest);

        //box = new Box(0.5f, 0.5f, 0.5f);        
        geom = baseCube.clone(); //new Geometry("cube", box);
        mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        mat.setColor("BaseColor", ColorRGBA.Blue);
        //mat.setTexture("BaseColorMap", nm);
        mat.setFloat("Metallic", 0.5f);        
        mat.setFloat("Roughness", 0.5f);
        mat.setTexture("NormalMap", nm);
        mat.setFloat("NormalType", 1);
        geom.setMaterial(mat);
        geom.move(2, 2.5f, 0);
        //MikktspaceTangentGenerator.generate(geom);
        rootNode.attachChild(geom);

        geom = geom.clone();
        geom.rotate(0, 0, FastMath.PI);
        geom.move(1.5f, 0, 0);
        rootNode.attachChild(geom);
*/

        //box = new Box(0.5f, 0.5f, 0.5f);        
        /*geom = baseCube.clone(); //new Geometry("cube", box);
        mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        Texture base = assetManager.loadTexture("Textures/mortared-rock.jpg");
        nm = assetManager.loadTexture("Textures/mortared-rock-norm.jpg"); 
        mat.setTexture("BaseColorMap", base);
        mat.setFloat("Metallic", 0.5f); //0.1f);        
        mat.setFloat("Roughness", 0.5f); //0.65f);
        mat.setTexture("NormalMap", nm);
        mat.setFloat("NormalType", -1);
        geom.setMaterial(mat);
        geom.move(0, 0.5f, 2);
        //MikktspaceTangentGenerator.generate(geom);
        rootNode.attachChild(geom);*/

/*
        addBlockType("Textures/mortared-rock.jpg", 
                     "Textures/mortared-rock-normal.png",
                     "Textures/mortared-rock-bumps.png",
                     bevel1, bevel2, 
                     new Vector3f(0, 0.65f, 2)); 

        addBlockType("Textures/wood-planks.png", 
                     "Textures/wood-planks-normal.png",
                     "Textures/wood-planks-bump.png",
                     bevel1, bevel2, 
                     new Vector3f(0, 0.65f, 5)); 

        addBlockType("Textures/waddle-daub-plain.png", 
                     "Textures/waddle-daub-plain-normal.png",
                     "Textures/waddle-daub-plain-bumps.png",
                     bevel1, bevel2, 
                     new Vector3f(0, 0.65f, 8)); 

        addBlockType("Textures/pebbles.jpg", 
                     "Textures/pebbles-normal.png",
                     "Textures/pebbles-bump.png",
                     bevel1, bevel2, 
                     new Vector3f(0, 0.65f, 11)); 

        
        // Setup the light probe here until we have proper light management.
        //Spatial probeHolder = assetManager.loadModel("studio.j3o");
        Spatial probeHolder = assetManager.loadModel("flower_road.j3o");
        LightProbe probe = (LightProbe)probeHolder.getLocalLightList().get(0);
        probe.setPosition(Vector3f.ZERO);
        probeHolder.removeLight(probe);
        rootNode.addLight(probe);
        
        cam.setLocation(new Vector3f(2.9688232f, 4.30845f, 11.967401f));
        cam.setRotation(new Quaternion(-0.08889451f, 0.91084176f, -0.2732993f, -0.29626432f));
        
        cam.setLocation(new Vector3f(2.3345993f, 1.5275577f, 12.353077f));
        cam.setRotation(new Quaternion(-0.08794872f, 0.8893685f, -0.19316076f, -0.40494156f));
*/        
    }
 
 /*
    private void addBlockType( String baseColor, String normal, String bumps, Texture bevel1, Texture bevel2, Vector3f location ) {
    
        Geometry geom = baseCube.clone();

        Texture base = assetManager.loadTexture(baseColor);
        base.setWrap(Texture.WrapMode.Repeat);
        Texture nm = assetManager.loadTexture(normal); 
        nm.setWrap(Texture.WrapMode.Repeat);
        Texture bm = assetManager.loadTexture(bumps); 
        bm.setWrap(Texture.WrapMode.Repeat);
        
        MaterialConfig mConfig = new MaterialConfig("test", "Common/MatDefs/Light/PBRLighting.j3md");
        mConfig.put("BaseColorMap", base);
        //mat.setTexture("DiffuseMap", base);
        //mConfig.put("Metallic", 0.5f); //0.1f);        
        //mConfig.put("Roughness", 0.5f); //0.65f);
        mConfig.put("Metallic", 0);        
        mConfig.put("Roughness", 0.5f);
        mConfig.put("NormalMap", nm);
        mConfig.put("NormalType", -1);
        mConfig.put("ParallaxMap", bm);
        //mConfig.put("UseSpecGloss", true);
        //mConfig.put("Glossiness", 1f);
        //mConfig.put("Specular", ColorRGBA.Red);
                
         
        //Material mat = new Material(assetManager, "Common/MatDefs/Light/PBRLighting.j3md");
        ////Material mat = new Material(assetManager, "Common/MatDefs/Light/Lighting.j3md");
        //Texture base = assetManager.loadTexture(baseColor);
        //base.setWrap(Texture.WrapMode.Repeat);
        //Texture nm = assetManager.loadTexture(normal); 
        //nm.setWrap(Texture.WrapMode.Repeat);
        //mat.setTexture("BaseColorMap", base);
        ////mat.setTexture("DiffuseMap", base);
        //mat.setFloat("Metallic", 0.5f); //0.1f);        
        //mat.setFloat("Roughness", 0.5f); //0.65f);
        //mat.setTexture("NormalMap", nm);
        //mat.setFloat("NormalType", -1);
        //Texture bm = assetManager.loadTexture(bumps); 
        //bm.setWrap(Texture.WrapMode.Repeat);
        //mat.setTexture("ParallaxMap", bm);
        Material mat = mConfig.createMaterial(assetManager);
        geom.setMaterial(mat);
        geom.setLocalTranslation(location);
        rootNode.attachChild(geom);


        geom = geom.clone();
        geom.move(1, 0, 0);
        rootNode.attachChild(geom);
        
        geom = baseCube.clone();
        mConfig = new MaterialConfig("test", "MatDefs/PBRLighting.j3md"); 
        //mat = new Material(assetManager, "MatDefs/PBRLighting.j3md"); 
        //mat.setTexture("BaseColorMap", base);
        
        
        //Texture emissive = assetManager.loadTexture("Textures/black-marble.jpg");        
        //mat.setTexture("EmissiveMap", emissive);
        //mat.setFloat("EmissivePower", 1); // default 3
        //mat.setFloat("EmissiveIntensity", 1); // default 2
 
        //mat.setColor("Emissive", ColorRGBA.Blue);
        
        // For Spec gloss pipeline
        //Boolean UseSpecGloss
        //Texture2D SpecularMap
        //Texture2D GlossinessMap
        //Texture2D SpecularGlossinessMap
        //Color Specular : 1.0 1.0 1.0 1.0
        //Float Glossiness : 1.0
        //mat.setBoolean("UseSpecGloss", true);
        //Texture specular = assetManager.loadTexture("Textures/black-marble.jpg");
        //Texture specular = assetManager.loadTexture("Textures/bad.jpg");
        //Texture glossiness = assetManager.loadTexture("Textures/black-marble.jpg");
        //mat.setTexture("SpecularMap", specular);        
        //mat.setTexture("GlossinessMap", glossiness);        
        
        
        // The emissive color of the object
        //Color Emissive        
        // the emissive power
        //Float EmissivePower : 3.0        
        // the emissive intensity
        //Float EmissiveIntensity : 2.0
        
         
        mConfig.put("BaseColorMap", base);
        mConfig.put("Metallic", 0.5f); //0.1f);        
        mConfig.put("Roughness", 0.5f); //0.65f);
        mConfig.put("NormalMap", nm);
        mConfig.put("NormalType", -1);
        mConfig.put("NormalMap2", bevel1);
        mConfig.put("NormalType2", 1);
        mConfig.put("Glossiness", 0);
        mConfig.put("Specular", ColorRGBA.Black);
        mat = mConfig.createMaterial(assetManager);
        geom.setMaterial(mat);
        geom.setLocalTranslation(location);
        geom.move(0, 2.5f, 0);
        rootNode.attachChild(geom);

        geom = baseCube.clone();
        //mat = new Material(assetManager, "MatDefs/PBRLighting.j3md"); 
        //mat.setTexture("BaseColorMap", base);
        //mat.setFloat("Metallic", 0.5f); //0.1f);        
        //mat.setFloat("Roughness", 0.5f); //0.65f);
        //mat.setTexture("NormalMap", nm);
        //mat.setFloat("NormalType", -1);
        //mat.setTexture("NormalMap2", bevel2);
        //mat.setFloat("NormalType2", 1);
        mConfig.put("BaseColorMap", base);
        mConfig.put("Metallic", 0.5f); //0.1f);        
        mConfig.put("Roughness", 0.5f); //0.65f);
        mConfig.put("NormalMap", nm);
        mConfig.put("NormalType", -1);
        mConfig.put("NormalMap2", bevel2);
        mConfig.put("NormalType2", 1);
        mat = mConfig.createMaterial(assetManager);
        geom.setMaterial(mat);
        geom.setLocalTranslation(location);
        geom.move(2, 2.5f, 0);
        rootNode.attachChild(geom);
        
        
    }*/
 
    private Color vectorToColor( Vector3f v ) {
        v = v.normalize();
        v.multLocal(0.5f);
        v.addLocal(0.5f, 0.5f, 0.5f);
        return new Color(v.x, v.y, v.z);
    }   
    
    public static final int UP = 0x1;
    public static final int DOWN = 0x2;
    public static final int LEFT = 0x4;
    public static final int RIGHT = 0x8;
    
    private BufferedImage createGradientBox( int size, int radius, int dirMask ) {
 
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB); 
        Graphics g = img.createGraphics();
 
        Color flat = vectorToColor(Vector3f.UNIT_Z);
        g.setColor(flat);
        g.fillRect(0, 0, 128, 128); 
        
        double startAngle = Math.toRadians(45);
        double endAngle = Math.toRadians(90);
        double delta = (endAngle - startAngle) / radius;
        double[] sines = new double[radius+1];
        double[] cosines = new double[radius+1];
        for( int i = 0; i <= radius; i++ ) {
            sines[i] = Math.sin(startAngle + delta * i);
            cosines[i] = Math.cos(startAngle + delta * i);
        }

        int upMult = (dirMask & UP) != 0 ? 1 : 0; 
        int downMult = (dirMask & DOWN) != 0 ? 1 : 0; 
        int leftMult = (dirMask & LEFT) != 0 ? 1 : 0; 
        int rightMult = (dirMask & RIGHT) != 0 ? 1 : 0; 

        if( downMult == 1 ) {             
        
            // Bottom          
            for( int i = 0; i <= radius; i++ ) {
                Vector3f v = new Vector3f(0, -(float)cosines[i], (float)sines[i]);
                Color c = vectorToColor(v);
                g.setColor(c);
                g.drawLine(i * leftMult, i, size-(i * rightMult)-1, i);
            }
        }

        if( upMult == 1 ) { 
            // Top
            for( int i = 0; i <= radius; i++ ) {
                Vector3f v = new Vector3f(0, (float)cosines[i], (float)sines[i]);
                Color c = vectorToColor(v);
                g.setColor(c);
                int y = size-i;
                g.drawLine(i * leftMult, y-1, size-(i * rightMult)-1, y-1);
            }
        }

        if( leftMult == 1 ) { 
            // Left
            for( int i = 0; i <= radius; i++ ) {
                Vector3f v = new Vector3f(-(float)cosines[i], 0, (float)sines[i]);
                g.setColor(vectorToColor(v));
                g.drawLine(i, i * downMult, i, size-(i * upMult)-1);
            }
        }

        if( rightMult == 1 ) { 
            // Right
            for( int i = 0; i <= radius; i++ ) {
                Vector3f v = new Vector3f((float)cosines[i], 0, (float)sines[i]);
                Color c = vectorToColor(v);
                g.setColor(c);
                int x = size-i;
                g.drawLine(x, i * downMult, x, size-(i * upMult)-1);
            }
        }
        
        g.dispose();
        
        return img;       
    }
    
}


/*
        // Alpha threshold for fragment discarding
        Float AlphaDiscardThreshold (AlphaTestFallOff)

        //metalness of the material
        Float Metallic : 1.0
        //Roughness of the material
        Float Roughness : 1.0        
        // Base material color
        Color BaseColor : 1.0 1.0 1.0 1.0
        // The emissive color of the object
        Color Emissive        
        // the emissive power
        Float EmissivePower : 3.0        
        // the emissive intensity
        Float EmissiveIntensity : 2.0

        // BaseColor map
        Texture2D BaseColorMap

        // Metallic map
        Texture2D MetallicMap -LINEAR
        
        // Roughness Map
        Texture2D RoughnessMap -LINEAR

        //Metallic and Roughness are packed respectively in the b and g channel of a single map
        // r: unspecified
        // g: Roughness
        // b: Metallic
        Texture2D MetallicRoughnessMap -LINEAR
        
        // Texture of the emissive parts of the material
        Texture2D EmissiveMap

        // Normal map
        Texture2D NormalMap -LINEAR

        //The type of normal map: -1.0 (DirectX), 1.0 (OpenGl)
        Float NormalType : -1.0

        // For Spec gloss pipeline
        Boolean UseSpecGloss
        Texture2D SpecularMap
        Texture2D GlossinessMap
        Texture2D SpecularGlossinessMap
        Color Specular : 1.0 1.0 1.0 1.0
        Float Glossiness : 1.0

        // Parallax/height map
        Texture2D ParallaxMap -LINEAR

        //Set to true if parallax map is stored in the alpha channel of the normal map
        Boolean PackedNormalParallax   

        //Sets the relief height for parallax mapping
        Float ParallaxHeight : 0.05       

        //Set to true to activate Steep Parallax mapping
        Boolean SteepParallax

        //Horizon fade
        Boolean HorizonFade

        // Set to Use Lightmap
        Texture2D LightMap

        // Set to use TexCoord2 for the lightmap sampling
        Boolean SeparateTexCoord
        // the light map is a gray scale ao map, on ly the r channel will be read.
        Boolean LightMapAsAOMap

        //shadows
        Int FilterMode
        Boolean HardwareShadows

        Texture2D ShadowMap0
        Texture2D ShadowMap1
        Texture2D ShadowMap2
        Texture2D ShadowMap3
        //pointLights
        Texture2D ShadowMap4
        Texture2D ShadowMap5
        
        Float ShadowIntensity
        Vector4 Splits
        Vector2 FadeInfo

        Matrix4 LightViewProjectionMatrix0
        Matrix4 LightViewProjectionMatrix1
        Matrix4 LightViewProjectionMatrix2
        Matrix4 LightViewProjectionMatrix3
        //pointLight
        Matrix4 LightViewProjectionMatrix4
        Matrix4 LightViewProjectionMatrix5   
        Vector3 LightPos
        Vector3 LightDir

        Float PCFEdge
        Float ShadowMapSize

        // For hardware skinning
        Int NumberOfBones
        Matrix4Array BoneMatrices

        // For Morph animation
        FloatArray MorphWeights
        Int NumberOfMorphTargets
        Int NumberOfTargetsBuffers
                
        // For instancing
        Boolean UseInstancing

        // For Vertex Color
        Boolean UseVertexColor

        Boolean BackfaceShadows : false
*/