/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;
import com.google.gson.*;

import com.simsilica.mathd.*;

import com.simsilica.tool.ShaperConfig;

import com.simsilica.tool.collider.RaySimulation.RayInfo;

/**
 *  Config settings for the ray simulation.
 *
 *  @author    Paul Speed
 */
public class RayConfig {

    public static final String CONFIG_FILE = "shaper.ray.config";

    static Logger log = LoggerFactory.getLogger(RayConfig.class);

    private Vec3d majorPos;
    private Vec3d minorPos;
    private Vec3d direction;
    private double yaw;
    private double pitch;
    private double projection;
    private double length;
    private List<RayInfo> rays;
                 
    private static RayConfig instance;
 
    public RayConfig() {
    }
 
    public void setMajorPos( Vec3d majorPos ) {
        this.majorPos = majorPos;
    }
    
    public Vec3d getMajorPos() {
        return majorPos;
    }
    
    public void setMinorPos( Vec3d minorPos ) {
        this.minorPos = minorPos;
    }
    
    public Vec3d getMinorPos() {
        return minorPos;
    }
    
    public void setDirection( Vec3d direction ) {
        this.direction = direction;
    }
    
    public Vec3d getDirection() {
        return direction;
    }
    
    public void setProjection( double projection ) {
        this.projection = projection;
    }
    
    public double getProjection() {
        return projection;
    }
    
    public void setLength( double length ) {
        this.length = length;
    }
    
    public double getLength() {
        return length;
    }
 
    public void setYaw( double yaw ) {
        this.yaw = yaw;
    }
    
    public double getYaw() {
        return yaw;
    }
    
    public void setPitch( double pitch ) {
        this.pitch = pitch;
    }
    
    public double getPitch() {
        return pitch;
    }
 
    public void setRays( List<RaySimulation.RayInfo> rays ) {
        this.rays = new ArrayList<>(rays);
    }
    
    public List<RaySimulation.RayInfo> getRays() {
        if( rays == null ) {
            return Collections.emptyList();
        }
        return rays;
    }
    
    protected void initializeDefaults() {
        majorPos = new Vec3d();
        minorPos = new Vec3d();
        direction = new Vec3d();
        yaw = 0;
        pitch = 0;
        projection = 0;
        length = 0;
    }
    
    protected void upgrade() {
        if( direction == null ) {
            direction = new Vec3d();
        }
    }
 
    private static File getConfigFile() {
        return new File(ShaperConfig.getInstance().getProjectDir(), CONFIG_FILE);
    }
 
    public static RayConfig getInstance() {
        if( instance == null ) {
            File f = getConfigFile();
            if( f.exists() ) { 
                try {
                    instance = load(f);
                    instance.upgrade();
                } catch( Exception e ) {
                    log.error("Error loading config file.  Initializing defaults", e);
                }
            }
        }
        if( instance == null ) {
            instance = new RayConfig();
            instance.initializeDefaults();
            File f = getConfigFile();
            if( !f.exists() ) {
                store(instance, f);
            }
        }
        return instance;
    }
 
    public static void save() {
        store(instance, getConfigFile());
    }
 
    public static RayConfig load( File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return gson.fromJson(json, RayConfig.class);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }
 
    public static void store( RayConfig config, File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + f);
            String json = gson.toJson(config);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }        
    }
}

