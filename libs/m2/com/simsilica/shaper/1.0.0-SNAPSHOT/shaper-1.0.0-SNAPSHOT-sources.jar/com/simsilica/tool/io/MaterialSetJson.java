/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.io;

import java.io.*;
import java.util.Map;

import com.simsilica.tool.gson.MapValueTypeAdapterFactory;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.*;

import com.jme3.math.ColorRGBA;

import com.simsilica.mblock.config.*;

import com.simsilica.tool.MaterialSet;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MaterialSetJson {

    private static MaterialSetJson instance = new MaterialSetJson();

    private Gson gson;

    public MaterialSetJson() {
        initializeGson();
    }

    protected void initializeGson() {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();

        // Need to treat the map special since otherwise we won't
        // have any typing information to read back proper objects.
        gsonBuilder.registerTypeAdapterFactory(new MapValueTypeAdapterFactory(Map.class, ColorRGBA.class, TextureConfig.class));

        // Add an adapter for render state just so we don't write out default
        // property values.
        gsonBuilder.registerTypeAdapterFactory(RenderStateTypeAdapterFactory.create());

        this.gson = gsonBuilder.create();
    }

    public String toJson( MaterialSet blockSet ) {
        return gson.toJson(blockSet);
    }

    public MaterialSet fromJson( String json ) {
        return gson.fromJson(json, MaterialSet.class);
    }

    public static MaterialSet load( File f ) {
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return instance.fromJson(json);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }

    public static void store( MaterialSet materials, File f ) {
        try {
            String json = instance.toJson(materials);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }
}


