/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.nio.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.io.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mblock.phys.collision.*;
import com.simsilica.mworld.World;
import com.simsilica.tool.collider.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DebugSignatureState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(DebugSignatureState.class);

    private VersionedReference<Integer> blockType;

    private Node signatureRoot;

    private BlockSet blockSet;
    private Collider[] colliders;

    public DebugSignatureState() {
        //setEnabled(false);
        setEnabled(ShaperConfig.getInstance().getStartupSetting("showSignatureDebug", false));
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    @Override
    protected void initialize( Application app ) {
        this.signatureRoot = new Node("signatures");
        this.blockSet = getState(BlockSetMenuState.class).getBlockSet();

        blockType = getState(BlockSetMenuState.class).getSelectedTypeRef();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(signatureRoot);

        BlockType[] types = blockSet.getTypes().toArray(new BlockType[0]);
        this.colliders = new ColliderFactories(true).createColliders(types);

        resetShapes();
    }

    @Override
    protected void onDisable() {
        signatureRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( blockType.update() ) {
            resetShapes();
        }
    }

    public Long calculateSignature( int typeIndex ) {
        Collider collider = colliders[typeIndex];
        if( collider == null ) {
            return null;
        }

        double spacing = 0.25;
        double probeRadius = 0.124;

        long result = 0;
        long mask = 0x1;
        Vec3d cellPos = new Vec3d();

        for( int i = 0; i < 4; i++ ) {
            double x = i * spacing + probeRadius;
            for( int j = 0; j < 4; j++ ) {
                double y = j * spacing + probeRadius;
                for( int k = 0; k < 4; k++ ) {
                    double z = k * spacing + probeRadius;
                    MBlockContact contact = null;
                    if( collider != null ) {
                        contact = collider.getSphereContact(cellPos, new Vec3d(x, y, z), probeRadius, 0xff);
                    }
                    if( contact != null ) {
                        result = result | mask;
                    }
                    mask = mask << 1;
                }
            }
        }

        return result;
    }

    protected void resetShapes() {
        signatureRoot.detachAllChildren();

        BlockType type = BlockTypeIndex.get(blockType.get());
        if( type == null ) {
            return;
        }

        Collider collider = colliders[blockType.get()];

        log.info("Collider:" + collider);

        double spacing = 0.25;
        double offset = spacing * 0.5;
        double probeRadius = 0.124;

        boolean approximate = collider.isApproximate();
        //if( collider instanceof CubeCollider ) {
        //    approximate = ((CubeCollider)collider).isApproximate();
        //}

        Sphere marker = new Sphere(8, 8, (float)probeRadius);
        ColorRGBA inside = new ColorRGBA(0, 1, 1, 0.1f);
        if( approximate ) {
            inside = new ColorRGBA(1, 1, 0, 0.1f);
        }
        Material insideMat = GuiGlobals.getInstance().createMaterial(inside, false).getMaterial();
        insideMat.getAdditionalRenderState().setWireframe(true);
        insideMat.getAdditionalRenderState().setDepthTest(false);
        insideMat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        Material outsideMat = GuiGlobals.getInstance().createMaterial(new ColorRGBA(1f, 0, 0, 0.1f), false).getMaterial();
        outsideMat.getAdditionalRenderState().setWireframe(true);

        Vec3d cellPos = new Vec3d();

        //long bits = collider == null ? 0L : ColliderUtils.calculateShapeSignature(collider, probeRadius);
        //long toggleBit = 0x1;
        ShapeSignature sig = collider == null ? null : ColliderUtils.calculateShapeSignature(collider, probeRadius);

        for( int i = 0; i < 4; i++ ) {
            double x = i * spacing + offset;
            for( int j = 0; j < 4; j++ ) {
                double y = j * spacing + offset;
                for( int k = 0; k < 4; k++ ) {
                    double z = k * spacing + offset;
                    Geometry geom = new Geometry("[" + i + "][" + j + "][" + k + "]", marker);
                    geom.setLocalTranslation((float)x, (float)y, (float)z);
                    geom.move(-0.5f, 0.5f, -0.5f);
                    geom.setQueueBucket(Bucket.Transparent);

                    //MBlockContact contact = null;
                    //if( collider != null ) {
                    //    contact = collider.getSphereContact(cellPos, new Vec3d(x, y, z), probeRadius, 0xff);
                    //}
    //public MBlockContact<K> getSphereContact( Vec3d cellPos, Vec3d pos, double radius, int dirMask );
                    //boolean on = (toggleBit & bits) == toggleBit;

//if( sig != null ) {
//    sig.unset(i, j, k);
//}
                    boolean on = sig != null && sig.isSet(i, j, k);

                    //if( contact != null ) {
                    if( on ) {
                        geom.setMaterial(insideMat);
                    } else {
                        geom.setMaterial(outsideMat);
                    }

                    signatureRoot.attachChild(geom);

                    //toggleBit = toggleBit << 1;
                }
            }
        }

        //Long sig = calculateSignature(blockType.get());
        //if( sig == null ) {
        //    log.info("Signature:" + sig);
        //} else {
        //    log.info("Signature:" + Long.toBinaryString(bits));
        //}
        log.info("" + sig);
    }
}
