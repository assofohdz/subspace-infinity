/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.DefaultCellRenderer;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class DefaultPartFactoryEditor extends Container implements PartFactoryEditor {

    static Logger log = LoggerFactory.getLogger(DefaultPartFactoryEditor.class);

    private MaterialSet materialSet;
    private VersionedList<MaterialConfig> materials = new VersionedList<>();

    private long version;
    private DefaultPartFactory factory;
    private Direction dir;

    private Container parts;
    private Selector[] materialSelectors;
    private VersionedReference[] materialRefs;

    public DefaultPartFactoryEditor() {
        parts = addChild(new Container());
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public PartFactory getObject() {
        return factory;
    }

    @Override
    public VersionedReference<PartFactory> createReference() {
        return new VersionedReference<>(this);
    }

    @Override
    public void setBlockSet( BlockSet blockSet ) {
    }

    @Override
    public void setMaterialSet( MaterialSet materialSet ) {
        if( this.materialSet == materialSet ) {
            return;
        }
        this.materialSet = materialSet;
        if( materialSet == null ) {
            materials.clear();
        } else {
            materials.clear();
            materials.addAll(materialSet.getMaterials());
        }
    }

    @Override
    @SuppressWarnings("unchecked")// FIXME: do better typing
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);

        if( materialRefs != null ) {
            boolean changed = false;
            for( int i = 0; i < materialRefs.length; i++ ) {
                if( materialRefs[i].update() ) {
log.info("-----------material changed[" + i + "]");
                    MaterialConfig config = (MaterialConfig)materialSelectors[i].getSelectedItem();
log.info("  selected:" + (config == null ? "null" : config.getName()));
                    if( config != null ) {
                        GeomPart part = factory.getTemplates()[i];
                        // Note that these canRender() calls are a little redundant since
                        // we shouldn't have even had an option in the list for invalid material types.
log.info("*************Is valid?:" +  config.canRender(part));
                        if( config.canRender(part) ) {
                            MaterialType mat = config.getMaterialType();
log.info("setting material type:" + mat);
                            part.setMaterialType(mat);
                        } else {
                            // Note: we see a double update because we'll process
                            // both the down and up mouse button events.  No real
                            // way around it because the list needs to select on the down.

                            log.info("Material is invalid:" + config.getName() + "  missing:" + config.getMissingReqs(part));
                            if( part.getMaterialType() != null ) {
                                // Reselect the old one
                                config = materialSet.get(part.getMaterialType());
log.info("Setting back to:" + config.getName());
                                materialSelectors[i].setSelectedItem(config);
                            } else {
                                // Set it to the first compatible one
                                List<MaterialConfig> list = materialSelectors[i].getListBox().getModel();
                                for( MaterialConfig mc : list ) {
                                    if( mc.canRender(part) ) {
log.info("Setting to:" + config.getName());
                                        materialSelectors[i].setSelectedItem(mc);
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
log.info("no material... part factory:" + factory);
                    }
                    changed = true;
                }
            }
            if( changed ) {
                version++;
            }
        }
    }

    @SuppressWarnings("unchecked")// FIXME: do better typing
    public void setPartFactory( PartFactory factory, Direction dir ) {
log.info("setPartFactory(" + factory + ")");
        this.dir = dir;
        if( this.factory == factory ) {
            return;
        }
        this.factory = (DefaultPartFactory)factory;

        parts.clearChildren();
        if( factory == null ) {
            return;
        }

        parts.addChild(new Label("#"));
        parts.addChild(new Label("Type"), 1);
        parts.addChild(new Label("Material"), 2);

        GeomPart[] templates = this.factory.getTemplates();
        materialSelectors = new Selector[templates.length];
        materialRefs = new VersionedReference[templates.length];

        for( int i = 0; i < templates.length; i++ ) {
            GeomPart part = templates[i];

            parts.addChild(new Label("[" + i + "]"));
            parts.addChild(new Label(part.getPrimitiveType().toString()), 1);
            materialSelectors[i] = parts.addChild(new Selector<MaterialConfig>(getMaterials(part), new MaterialConfigToString()), 2);
            MaterialConfig config = materialSet.get(part.getMaterialType());
            materialSelectors[i].setSelectedItem(config);

            materialRefs[i] = materialSelectors[i].createSelectedItemReference();
        }
    }

    protected VersionedList<MaterialConfig> getMaterials( GeomPart part ) {
log.info("getMaterials(" + part + ")");

        // Yes, this is all kinds of inefficient... but we're not performance cricital either
        VersionedList<MaterialConfig> result = new VersionedList<>();

        MaterialRegistry registry = materialSet.getRegistry();
        for( String name : registry.getNames() ) {
log.info("  checking:" + name);
            MaterialConfig best = registry.findBest(name, part);
log.info("    best:" + best);
            if( best != null ) {
                result.add(best);
            }
        }

        return result;
    }

    public PartFactory getPartFactory() {
        return factory;
    }

    public Direction getDirection() {
        return dir;
    }

    public Panel getEditor() {
        return this;
    }

    public static class MaterialConfigToString implements Function<MaterialConfig, String> {
        public String apply( MaterialConfig config ) {
            if( config == null ) {
                return "-none-";
            }
            return config.getName();
        }
    }
}


