/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import org.slf4j.*;

import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;
import com.simsilica.mworld.BlockIterator;
import com.simsilica.mworld.BlockIterator.Intersection;

/**
 *  Visual representation of a hit.
 *
 *  @author    Paul Speed
 */
public class HitGeom extends Node {
    static Logger log = LoggerFactory.getLogger(HitGeom.class);
 
    public static final ColorRGBA NORMAL_COLOR = new ColorRGBA(0, 0, 1, 1);
    public static final ColorRGBA CONTACT_COLOR = new ColorRGBA(0, 1, 1, 1);
    public static final ColorRGBA BLOCK_COLOR = new ColorRGBA(0.5f, 0.5f, 0.5f, 1);
 
    private Intersection hit;
    
    private Geometry geom;
    private Geometry transGeom;
    
    public HitGeom( Intersection hit ) {
        super("view:" + hit);
        
        this.hit = hit;
        
        float crossScale = 0.1f;
        float normalScale = 0.5f;
        float normalCross = 0.01f;
        
        Vector3f nDir = hit.getNormal().mult(normalScale).toVector3f();
        
        Vector3f pos = hit.getPoint().toVector3f();
        Vector3f min = hit.getBlock().toVector3f();
        min.subtractLocal(pos); 
        Vector3f max = min.add(1, 1, 1);

        Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.Lines);

        mesh.setBuffer(VertexBuffer.Type.Position, 3, new float[] {
                    // Center crosshair
                    -crossScale, 0, 0,
                    crossScale, 0, 0,
                    0, -crossScale, 0,
                    0, crossScale, 0,
                    0, 0, -crossScale,
                    0, 0, crossScale,
                    
                    // Normal line
                    0, 0, 0,
                    nDir.x, nDir.y, nDir.z,
                    
                    // Normal cross
                    nDir.x - normalCross, nDir.y, nDir.z,
                    nDir.x + normalCross, nDir.y, nDir.z,
                    nDir.x, nDir.y - normalCross, nDir.z,
                    nDir.x, nDir.y + normalCross, nDir.z,
                    nDir.x, nDir.y, nDir.z - normalCross,
                    nDir.x, nDir.y, nDir.z + normalCross,
                    
                    // Block indicator wire frame
                    min.x, min.y, min.z,
                    max.x, min.y, min.z,
                    max.x, min.y, min.z,
                    max.x, max.y, min.z,
                    max.x, max.y, min.z,
                    min.x, max.y, min.z,
                    min.x, max.y, min.z,
                    min.x, min.y, min.z,

                    min.x, min.y, max.z,
                    max.x, min.y, max.z,
                    max.x, min.y, max.z,
                    max.x, max.y, max.z,
                    max.x, max.y, max.z,
                    min.x, max.y, max.z,
                    min.x, max.y, max.z,
                    min.x, min.y, max.z,

                    min.x, min.y, min.z,
                    min.x, min.y, max.z,
                    max.x, min.y, min.z,
                    max.x, min.y, max.z,
                    max.x, max.y, min.z,
                    max.x, max.y, max.z,
                    min.x, max.y, min.z,
                    min.x, max.y, max.z
                });
    
        mesh.setBuffer(VertexBuffer.Type.Color, 4, new float[] {
                    // Center crosshair
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    CONTACT_COLOR.r, CONTACT_COLOR.g, CONTACT_COLOR.b, CONTACT_COLOR.a,  
                    
                    // Normal line
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a, 
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a,

                    // Normal cross
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a, 
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a,
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a, 
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a,
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a,
                    NORMAL_COLOR.r, NORMAL_COLOR.g, NORMAL_COLOR.b, NORMAL_COLOR.a,

                    // Block indicator wire frame
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,

                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,

                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a,
                    BLOCK_COLOR.r, BLOCK_COLOR.g, BLOCK_COLOR.b, BLOCK_COLOR.a
                });
    
        geom = new Geometry("hit", mesh);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.White, false).getMaterial());
        geom.getMaterial().setBoolean("VertexColor", true);
        attachChild(geom);
            
        transGeom = geom.clone();
        transGeom.setMaterial(GuiGlobals.getInstance().createMaterial(new ColorRGBA(1, 1, 1, 0.5f), false).getMaterial());
        transGeom.getMaterial().setBoolean("VertexColor", true);
        transGeom.getMaterial().getAdditionalRenderState().setDepthTest(false);
        transGeom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        transGeom.setQueueBucket(Bucket.Translucent);
        attachChild(transGeom);        
    }
      
}
