/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.collect.*;
import com.google.common.io.Files;

import com.google.gson.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.input.KeyInput;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.SpringGridLayout;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.input.*;
import com.simsilica.lemur.list.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.config.*;

import com.simsilica.tool.block.*;
import com.simsilica.tool.io.BlockSetJson;
import com.simsilica.tool.io.FluidSetJson;
import com.simsilica.tool.io.MaterialSetJson;

/**
 *  Shows the block set menu on the right.
 *
 *  @author    Paul Speed
 */
public class BlockSetMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BlockSetMenuState.class);

    public static final FunctionId F_NEXT_TYPE = new FunctionId("Next Type");
    public static final FunctionId F_PREV_TYPE = new FunctionId("Prev. Type");

    private Container window;
    private TabbedPanel tabs;
    private ReshapeListener reshapeListener = new ReshapeListener();

    private GeometryFactory geomFactory;

    private VersionedList<BlockType> typeModel;
    private Selector<BlockType> typeSelector;
    private Selector<BlockType> groundSelector;
    private Selector<BlockType> roofSelector;

    // For selecting the 'bad type index'
    private Selector<BlockType> badTypeSelector;

    // Setup the preconfigured block type factories
    private BlockTypeFactory[] defaultFactories = new BlockTypeFactory[] { // generics are dumb
                new CubeFactory(),
                new BoxFactory(),
                new WedgeFactory(),
                new WedgeCornerFactory(),
                new ShallowCornerFactory(),
                new HiWedgeFactory(),
                new HiWedgeCornerFactory(),
                new WideWedgeFactory(),
                new AngleFactory(),
                new VerticalCylinderFactory(),
                new HorizontalCylinderFactory(),
                new FreeCylinderFactory(),
                new WedgeCylinderFactory(),
                new HollowBoxFactory(),
                new HollowWedgeFactory(),
                new HollowWedgeCornerFactory(),
                new HollowWideWedgeFactory(),
                new HollowHiWedgeFactory()
            };

    private VersionedList<BlockTypeFactory> blockTypeFactories = new VersionedList<BlockTypeFactory>(Arrays.asList(defaultFactories));

    private BlockSet blockSet;
    private VersionedHolder<BlockSet> blockSetHolder = new VersionedHolder<>();
    private VersionedReference<List<BlockType>> blockTypesRef;
    private MaterialSet materialSet;
    private MaterialRegistry materials = new MaterialRegistry();
    private FluidSet fluidSet;
    private VersionedHolder<FluidSet> fluidSetHolder = new VersionedHolder<>();

    private BlockTypeEditor typeEditor;
    private VersionedReference<BlockType> currentTypeRef;
    private VersionedReference<BlockType> badTypeRef;
    private VersionedReference<BlockType> editorRef;

    public BlockSetMenuState() {
    }

    public BlockTypeEditor getBlockTypeEditor() {
        return typeEditor;
    }

    public BlockSet getBlockSet() {
        return blockSet;
    }

    public FluidSet getFluidSet() {
        return fluidSet;
    }

    public MaterialSet getMaterialSet() {
        return materialSet;
    }

    public VersionedReference<FluidSet> createFluidSetReference() {
        return fluidSetHolder.createReference();
    }

    public VersionedList<BlockTypeFactory> getBlockTypeFactories() {
        return blockTypeFactories;
    }

    public void tempSave() {
        File f = ShaperConfig.getInstance().getBlocksFile();
        if( f.exists() ) {
            // Rename it
            File backup = new File(f.getParentFile(), ".backups/" + f.getName() + "." + System.currentTimeMillis());
            if( !backup.getParentFile().exists() ) {
                backup.getParentFile().mkdirs();
            }
            File move = new File(f.toString());
            move.renameTo(backup);
            move.renameTo(backup);
            //f = new File("blocks.json");
        }
        log.info("Writing:" + f);
        BlockSetJson.store(blockSet, f);
    }

    public void saveFluidSet() {
        File f = ShaperConfig.getInstance().getFluidsFile();
        if( f.exists() ) {
            // Rename it
            File backup = new File(f.getParentFile(), ".backups/" + f.getName() + "." + System.currentTimeMillis());
            if( !backup.getParentFile().exists() ) {
                backup.getParentFile().mkdirs();
            }
            File move = new File(f.toString());
            move.renameTo(backup);
            move.renameTo(backup);
            //f = new File("blocks.json");
        }
        log.info("Writing:" + f);
        FluidSetJson.store(fluidSet, f);
    }

    public void tempCompileBlocks() throws IOException {
        log.info("Writing block set with " + BlockTypeIndex.getTypeCount() + " types and bad type index:" + BlockTypeIndex.getBadTypeIndex());

        for( File target : ShaperConfig.getInstance().getCompileTargets() ) {
            File f = new File(target, "blocks.bset");
            log.info("Writing:" + f);
            try( FileOutputStream out = new FileOutputStream(f) ) {
                BlockTypeIndex.store(out);
                log.info("Wrote:" + BlockTypeIndex.getTypeCount() + " types");
            }
        }
        for( File target : ShaperConfig.getInstance().getCompileTargets() ) {
            File f = new File(target, "fluids.fset");
            log.info("Writing:" + f);
            try( FileOutputStream out = new FileOutputStream(f) ) {
                FluidTypeIndex.store(out);
                log.info("Wrote:" + BlockTypeIndex.getTypeCount() + " types");
            }
        }
    }

    public void tempCompileMaterials() throws IOException {
        for( File target : ShaperConfig.getInstance().getCompileTargets() ) {
            File f = new File(target, "materials.mset");
            log.info("Writing:" + f);
            try( FileOutputStream out = new FileOutputStream(f) ) {
                materials.storeCompiledMaterials(out);
                log.info("Wrote:" + materials.getMaterials().size() + " materials");
            }
        }
    }

    public void importBlockOrder() throws IOException {
        // Compile the current block types into a searchable index
        ListMultimap<BlockName, BlockType> index = MultimapBuilder.linkedHashKeys().arrayListValues().build();
        for( BlockType type : blockSet.getTypes() ) {
            if( type != null ) {
                index.put(type.getName(), type);
            }
        }

        List<BlockName> order = new ArrayList<>();

        File f = new File(ShaperConfig.getInstance().getImportDir(), "block-order.txt");
        log.info("Reading:" + f);
        for( String line : Files.readLines(f, Charsets.UTF_8) ) {
            line = line.trim();
            if( line.length() == 0 ) {
                continue;
            }
            if( line.equals(null) ) {
                order.add(null);
            } else {
                order.add(BlockName.parse(line));
            }
        }

        List<BlockType> types = new ArrayList<>();
        for( BlockName name : order ) {
            if( name == null ) {
                types.add(null);
            } else {
                List<BlockType> list = index.get(name);
                if( list.isEmpty() ) {
                    throw new RuntimeException("Type not found for:" + name);
                }
                types.add(list.remove(0));
            }
        }
        // And any unmapped ones just tack onto the end
        types.addAll(index.values());
        blockSet.getTypes().clear();
        blockSet.getTypes().addAll(types);
    }

    public void exportBlockOrder() throws IOException {
        File f = new File(ShaperConfig.getInstance().getImportDir(), "block-order.txt");
        FileOutputStream fOut = new FileOutputStream(f);
        PrintWriter out = new PrintWriter(new OutputStreamWriter(fOut, "UTF-8"));
        try {
            for( BlockType type : blockSet.getTypes() ) {
                if( type == null ) {
                    out.println("null");
                } else {
                    out.println(type.getName());
                }
            }
        } finally {
            out.close();
        }
        log.info("Wrote:" + f);
    }

    public static void writeBlocks( File f, BlockSet blocks ) {
        if( f.exists() ) {
            // Rename it
            File backup = new File(f.getParentFile(), ".backups/" + f.getName() + "." + System.currentTimeMillis());
            if( !backup.getParentFile().exists() ) {
                backup.getParentFile().mkdirs();
            }
            File move = new File(f.toString());
            move.renameTo(backup);
        }
        log.info("Writing:" + f);
        BlockSetJson.store(blocks, f);
    }

    protected AssetManager getAssetManager() {
        return getApplication().getAssetManager();
    }

    public VersionedReference<Integer> getSelectedTypeRef() {
        return typeSelector.getListBox().getSelectionModel().createSelectionReference();
    }

    public VersionedReference<Integer> getSelectedGroundRef() {
        return groundSelector.getListBox().getSelectionModel().createSelectionReference();
    }

    public VersionedReference<Integer> getSelectedRoofRef() {
        return roofSelector.getListBox().getSelectionModel().createSelectionReference();
    }

    public VersionedReference<Integer> getSelectedBadTypeRef() {
        return badTypeSelector.getListBox().getSelectionModel().createSelectionReference();
    }

    public VersionedReference<BlockType> getBlockTypeRef() {
        return typeEditor.createReference();
    }

    public GeometryFactory getGeomFactory() {
        return geomFactory;
    }

    protected Node getGuiNode() {
        return ((SimpleApplication)getApplication()).getGuiNode();
    }

    public void toggleEnabled() {
        setEnabled(!isEnabled());
    }

    public TabbedPanel getTabs() {
        return tabs;
    }

    public void nextType() {
        Integer i = typeSelector.getSelectionModel().getSelection();
        if( i == null ) {
            return;
        }
        i++;
        if( i < typeSelector.getModel().size() ) {
            typeSelector.getSelectionModel().setSelection(i);
        }
    }

    public void previousType() {
        Integer i = typeSelector.getSelectionModel().getSelection();
        if( i == null ) {
            return;
        }
        i--;
        if( i >= 0 ) {
            typeSelector.getSelectionModel().setSelection(i);
        }
    }

    @Override
    protected void initialize( Application app ) {
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.map(F_NEXT_TYPE, KeyInput.KEY_PGDN);
        inputMapper.map(F_PREV_TYPE, KeyInput.KEY_PGUP);
        inputMapper.addDelegate(F_NEXT_TYPE, this, "nextType");
        inputMapper.addDelegate(F_PREV_TYPE, this, "previousType");

        inputMapper.addDelegate(MainMenuState.F_SETTINGS, this, "toggleEnabled");


        File f;
        // For now try to load a prebuilt block set if it exists.
        //f = new File("blocks.json");
        f = ShaperConfig.getInstance().getBlocksFile();
        if( f.exists() ) {
            log.info("Loading:" + f);
            this.blockSet = BlockSetJson.load(f);
        } else {
            log.info("Generating default:" + f);
            this.blockSet = BlockSet.createDefault();
            BlockSetJson.store(blockSet, f);
        }

        upgrade(blockSet);

        // For now try to load a prebuilt block set if it exists.
        //f = new File("blocks.json");
        f = ShaperConfig.getInstance().getFluidsFile();
        if( f.exists() ) {
            log.info("Loading:" + f);
            this.fluidSet = FluidSetJson.load(f);
        } else {
            log.info("Generating default:" + f);
            this.fluidSet = FluidSet.createDefault();
            FluidSetJson.store(fluidSet, f);
        }
        fluidSetHolder.setObject(fluidSet);

        upgrade(fluidSet);

        // For now, try to load a prebuilt material set if it exists
        //f = new File("materials.json");
        f = ShaperConfig.getInstance().getMaterialsFile();
        if( f.exists() ) {
            log.info("Loading:" + f);
            this.materialSet = MaterialSetJson.load(f);
        } else {
            log.info("Generating default:" + f);
            this.materialSet = MaterialSet.createDefault("Textures/palette1.png", "Textures/palette2.png", "Textures/bad.jpg");
            MaterialSetJson.store(materialSet, f);
        }


        this.geomFactory = new GeometryFactory(materials.getMaterials());
        this.blockSetHolder.setObject(blockSet);

        updateBlocks();
        updateFluids();
        updateMaterials();

        window = new Container();
        window.getControl(GuiControl.class).addListener(reshapeListener);

        RollupPanel rollup = window.addChild(new RollupPanel("Block Set", null));

        tabs = new TabbedPanel();
        rollup.setContents(tabs);

        // The main "Types" panel
        Container types = new Container();

        Container tools = types.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        // col1
        tools.addChild(new ActionButton(new CallMethodAction(this, "createBlockType")));
        tools.addChild(new ActionButton(new CallMethodAction(this, "moveTypeToTop")), 1);
        tools.addChild(new ActionButton(new CallMethodAction(this, "moveTypeToBottom")), 2);
        tools.addChild(new ActionButton(new CallMethodAction(this, "moveTypeUp")), 3);
        tools.addChild(new ActionButton(new CallMethodAction(this, "moveTypeDown")), 4);
        tools.addChild(new ActionButton(new CallMethodAction(this, "deleteBlockType")), 5);

        // col2
        tools.addChild(new ActionButton(new CallMethodAction(this, "createRotations")));
        tools.addChild(new ActionButton(new CallMethodAction(this, "exportBlockType")), 1);
        tools.addChild(new ActionButton(new CallMethodAction(this, "exportBaseSubset")), 2);
        tools.addChild(new ActionButton(new CallMethodAction(this, "createReskin")), 3);
        tools.addChild(new ActionButton(new CallMethodAction("Remap Type UVs", this, "remapTypeUvs")), 4);
        tools.addChild(new ActionButton(new CallMethodAction("Remap Base UVs", this, "remapBaseUvs")), 5);

        typeModel = blockSet.getTypes();
        blockTypesRef = typeModel.createReference();

        Container selectors = types.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        selectors.addChild(new Label("Ground:"));
        groundSelector = selectors.addChild(new Selector<>(typeModel,
                                   new TypeCellRenderer(new ElementId("selector.item"), null),
                                   null), 1);
        selectors.addChild(new Label("Roof:"));
        roofSelector = selectors.addChild(new Selector<>(typeModel,
                                   new TypeCellRenderer(new ElementId("selector.item"), null),
                                   null), 1);
        selectors.addChild(new Label("Type:"));
        typeSelector = selectors.addChild(new Selector<>(typeModel,
                                   new TypeCellRenderer(new ElementId("selector.item"), null),
                                   null), 1);
        currentTypeRef = typeSelector.createSelectedItemReference();

        // This should really be separated in the panel from the selectors and part of some
        // 'blockset' section.
        selectors.addChild(new Label("Bad Type:"));
        badTypeSelector = selectors.addChild(new Selector<>(typeModel,
                                   new TypeCellRenderer(new ElementId("selector.item"), null),
                                   null), 1);

        int ground = ShaperConfig.getInstance().getStartupSettingInt("startingGroundType", 1);
        int type = ShaperConfig.getInstance().getStartupSettingInt("startingType", 2);
        groundSelector.getSelectionModel().setSelection(ground);
        typeSelector.getSelectionModel().setSelection(type);
        badTypeSelector.getSelectionModel().setSelection(blockSet.getBadTypeIndex());
        badTypeRef = badTypeSelector.createSelectedItemReference();

        typeEditor = new BlockTypeEditor();
        typeEditor.setBlockSet(blockSet);
        typeEditor.setMaterialSet(materialSet);
        editorRef = typeEditor.createReference();
        types.addChild(new RollupPanel("Type Editor", typeEditor, null));

        tabs.addTab("Block Types", types);

    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {

        getGuiNode().attachChild(window);

        Vector3f pref = window.getPreferredSize();

        window.setLocalTranslation(getApplication().getCamera().getWidth() - pref.x - 10,
                                   getApplication().getCamera().getHeight() - 20,
                                   0);

        GuiGlobals.getInstance().requestCursorEnabled(this);
    }


    public void update( float tpf ) {
        if( currentTypeRef.update() ) {
            typeEditor.setBlockType(currentTypeRef.get());
        }
        if( badTypeRef.update() ) {
            blockSet.setBadTypeIndex(badTypeSelector.getSelectionModel().getSelection());
            updateBlocks();
        }
        if( editorRef.update() ) {

        }
        if( blockTypesRef.update() ) {
            updateBlocks();
        }
    }

    @Override
    protected void onDisable() {
        window.removeFromParent();
        GuiGlobals.getInstance().releaseCursorEnabled(this);
    }

    // Can be whatever we need it to be to programmatically 'fix'
    // a blockset as things evolve.
    protected void upgrade( BlockSet blocks ) {
        for( BlockType type : blocks.getTypes() ) {
            upgrade(type);
        }
    }
    protected void upgrade( BlockType type ) {
        if( type == null ) {
            return;
        }
        if( type.getFactory() instanceof DefaultBlockFactory ) {
            upgrade((DefaultBlockFactory)type.getFactory());
        }
    }
    protected void upgrade( DefaultBlockFactory factory ) {
        if( factory == null ) {
            return;
        }
        if( factory.getDirParts() != null ) {
            for( PartFactory f : factory.getDirParts() ) {
                upgrade(f);
            }
        }
        upgrade(factory.getInternalParts());
    }
    protected void upgrade( PartFactory factory ) {
        if( factory instanceof DefaultPartFactory ) {
            upgrade((DefaultPartFactory)factory);
        }
    }
    protected void upgrade( DefaultPartFactory factory ) {
        if( factory == null ) {
            return;
        }
        for( GeomPart part : factory.getTemplates() ) {
            upgrade(part);
        }
    }
    protected void upgrade( GeomPart part ) {
        if( part == null ) {
            return;
        }
        part.setMaterialType(fixMaterialType(part.getMaterialType()));
    }
    protected MaterialType fixMaterialType( MaterialType mt ) {
        if( mt == null ) {
            return null;
        }
        //if( mt.getGeomReqs() == null ) {
        //    mt = new MaterialType(mt.getName(), mt.needsIndexedNormals(), mt.needsNormals(), mt.needsTangents());
        //}
        //if( mt.needsIndexedNormals() ) {
        //    mt.getGeomReqs().add(GeomReq.IndexedNormals);
        //} else {
        //    if( mt.needsNormals() ) {
        //        mt.getGeomReqs().add(GeomReq.Normals);
        //    }
        //    if( mt.needsTangents() ) {
        //        mt.getGeomReqs().add(GeomReq.Tangents);
        //    }
        //}
        return mt;
    }

    // Can be whatever we need it to be to programmatically 'fix'
    // a fluidset as things evolve.
    protected void upgrade( FluidSet fluids ) {
        for( FluidType type : fluids.getTypes() ) {
            upgrade(type);
        }
    }
    protected void upgrade( FluidType type ) {
        if( type == null ) {
            return;
        }
        upgrade(type.getFactory());
    }
    protected void upgrade( FluidFactory factory ) {
        if( factory == null ) {
            return;
        }
    }

    protected void createBlockType() {
        log.info("createBlockType()");

        final CreateBlockTypeDialog dialog = new CreateBlockTypeDialog(getState(OptionPanelState.class), blockSet, materialSet, blockTypeFactories);
        GuiGlobals.getInstance().getPopupState().centerInGui(dialog);
        GuiGlobals.getInstance().getPopupState().showModalPopup(dialog, (src) -> {
                    BlockType type = dialog.getBlockType();
                    if( type != null ) {
                        typeSelector.setSelectedItem(type);
                    }
            });

    }

    protected void moveTypeToTop() {
        BlockType selected = typeSelector.getSelectedItem();
        blockSet.remove(selected);
        // index 0 is always the empty block... so we use index 1
        blockSet.insert(1, selected);
    }

    protected void moveTypeToBottom() {
        BlockType selected = typeSelector.getSelectedItem();
        blockSet.remove(selected);
        // index 0 is always the empty block... so we use index 1
        blockSet.add(selected);
    }

    protected void moveTypeUp() {
        BlockType selected = typeSelector.getSelectedItem();
        int index = blockSet.getTypes().indexOf(selected);
        if( index < 0 ) {
            return; // shouldn't happen
        }
        if( index >= blockSet.getTypes().size() - 1 ) {
            // Can't move down
            return;
        }
        blockSet.remove(selected);
        // index 0 is always the empty block... so we use index 1
        blockSet.insert(index - 1, selected);
    }

    protected void moveTypeDown() {
        BlockType selected = typeSelector.getSelectedItem();
        int index = blockSet.getTypes().indexOf(selected);
        if( index < 0 ) {
            return; // shouldn't happen
        }
        if( index >= blockSet.getTypes().size() - 1 ) {
            // Can't move down
            return;
        }
        blockSet.remove(selected);
        // index 0 is always the empty block... so we use index 1
        blockSet.insert(index + 1, selected);
    }

    protected void deleteBlockType() {
        BlockType selected = typeSelector.getSelectedItem();
        blockSet.remove(selected);
    }

    protected void createRotations() {
        BlockType selected = typeSelector.getSelectedItem();
        int index = blockSet.getTypes().indexOf(selected);
        BlockType newType;

        if( selected.getName().getRotation() == null ) {
            newType = selected.createRotation(0);
            blockSet.insert(++index, newType);
        }
        newType = selected.createRotation(1);
        blockSet.insert(++index, newType);
        newType = selected.createRotation(2);
        blockSet.insert(++index, newType);
        newType = selected.createRotation(3);
        blockSet.insert(++index, newType);
    }

    protected void exportBlockType() {

        BlockType selected = typeSelector.getSelectedItem();
        if( selected == null ) {
            return;
        }
        BlockSet subset = new BlockSet();
        subset.add(selected);

        String name = selected.getName().toString();
        for( File target : ShaperConfig.getInstance().getExportTargets() ) {
            if( !target.exists() ) {
                target.mkdirs();
            }
            writeBlocks(new File(target, name.replaceAll(":", "-") + ".json"), subset);
         }
    }

    protected void exportBaseSubset() {

        BlockType selected = typeSelector.getSelectedItem();
        String base = selected.getName().getBase();
        BlockSet subset = new BlockSet();
        for( BlockType type : blockSet.getTypes() ) {
            if( type == null ) {
                continue;
            }
            if( base.equals(type.getName().getBase()) ) {
                subset.add(type);
            }
        }

        for( File target : ShaperConfig.getInstance().getExportTargets() ) {
            if( !target.exists() ) {
                target.mkdirs();
            }
            writeBlocks(new File(target, base + "-blocks.json"), subset);
        }
    }

    protected void updateBlocks() {
        if( BlockTypeIndex.getTypeCount() != blockSet.getTypes().size() ) {
            BlockTypeIndex.reset();
            int bad = blockSet.getBadTypeIndex();
            BlockTypeIndex.initialize(blockSet.getTypes().toArray(new BlockType[0]), bad);
        } else {
            // Bad surgery
            BlockType[] types = BlockTypeIndex.getTypes();
            List<BlockType> list = blockSet.getTypes();
            for( int i = 0; i < types.length; i++ ) {
                types[i] = list.get(i);
            }
            BlockTypeIndex.setBadTypeIndex(blockSet.getBadTypeIndex());
        }
    }

    protected void updateFluids() {
        if( FluidTypeIndex.getTypeCount() != fluidSet.getTypes().size() ) {
            FluidTypeIndex.reset();
            FluidTypeIndex.initialize(fluidSet.getTypes().toArray(new FluidType[0]));
        } else {
            // Bad surgery
            FluidType[] types = FluidTypeIndex.getTypes();
            List<FluidType> list = fluidSet.getTypes();
            for( int i = 0; i < types.length; i++ ) {
                types[i] = list.get(i);
            }
        }
    }

    protected void updateMaterials() {
        Set<MaterialType> toRemove = new HashSet<>(materials.getTypes());
        for( MaterialConfig config : materialSet.getMaterials() ) {
            toRemove.remove(config.getMaterialType());
            materials.addConfig(config); // just in case it doesn't already have it
        }

        if( !toRemove.isEmpty() ) {
            for( MaterialType type : toRemove ) {
                materials.remove(type);
            }
        }

        // Need to do two passes so that all materials are available for
        // inheritance... we'll also process the removes first just to
        // be sure we are referentially intact.
        for( MaterialConfig config : materialSet.getMaterials() ) {
            materials.update(config, getAssetManager());
        }

    }

    protected void createReskin() {
        BlockType selected = typeSelector.getSelectedItem();
        if( selected == null ) {
            return;
        }

        String base = selected.getName().getBase();
        List<BlockType> subset = new ArrayList<>();
        for( BlockType type : blockSet.getTypes() ) {
            if( type == null ) {
                continue;
            }
            if( base.equals(type.getName().getBase()) ) {
                subset.add(type);
            }
        }

        final CreateReskin dialog = new CreateReskin(subset, blockSet, materialSet);

        GuiGlobals.getInstance().getPopupState().centerInGui(dialog);
        GuiGlobals.getInstance().getPopupState().showModalPopup(dialog, (src) -> {
                    log.info("Done:" + dialog);
                    BlockType type = dialog.getFirstNewType();
                    if( type != null ) {
                        typeSelector.setSelectedItem(type);
                    }
                });

    }

    protected void remapTypeUvs() {
        BlockType selected = typeSelector.getSelectedItem();
        if( selected == null ) {
            return;
        }
        remapUvs(Arrays.asList(selected));
    }

    protected void remapBaseUvs() {
        BlockType selected = typeSelector.getSelectedItem();
        if( selected == null ) {
            return;
        }

        String base = selected.getName().getBase();
        List<BlockType> subset = new ArrayList<>();
        for( BlockType type : blockSet.getTypes() ) {
            if( type == null ) {
                continue;
            }
            if( base.equals(type.getName().getBase()) ) {
                subset.add(type);
            }
        }
        remapUvs(subset);
    }

    protected void remapUvs( List<BlockType> types ) {
        RemapUvCoordinates dialog = new RemapUvCoordinates(types);

        GuiGlobals.getInstance().getPopupState().centerInGui(dialog);
        GuiGlobals.getInstance().getPopupState().showModalPopup(dialog, (src) -> {
                    // Cause a repaint to happen somehow
                    BlockType type = typeSelector.getSelectedItem();
                    typeSelector.setSelectedItem(null);
                    typeSelector.setSelectedItem(type);
                });
    }

    public static class TypeCellRenderer extends DefaultCellRenderer<BlockType> {

        public TypeCellRenderer( ElementId elementId, String style ) {
            super(elementId, style);
        }

        public Panel getView( BlockType value, boolean selected, Panel existing ) {
            Label result = (Label)super.getView(value, selected, existing);
            if( value == null ) {
                result.setText("-empty-");
            } else {
                result.setText(String.valueOf(value.getName()));
            }
            return result;
        }
    }

    private class ReshapeListener extends AbstractGuiControlListener {

        private int minWidth = 250;

        @Override
        public void reshape( GuiControl source, Vector3f pos, Vector3f size ) {
log.info("reshape(" + pos + ", " + size + ")");
            // Note: reshape() is about the layout within the container
            // and not its position on screen... so moving the popup isn't
            // really a recursive operation.
            Vector3f windowSize = window.getSize();
            if( windowSize.x < minWidth ) {
                windowSize.x = minWidth;
                // Note: this does result in a recursive call... so be careful
                // that we always create stable results.
                window.setSize(windowSize);
            }
            Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() - windowSize.x - 10,
                                        getApplication().getCamera().getHeight() - 20,
                                        0);
            window.setLocalTranslation(loc);
        }
    }
}


