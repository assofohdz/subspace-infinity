/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ShallowCornerFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(ShallowCornerFactory.class);

    public ShallowCornerFactory() {
        super("Shallow Corner", "shallow-corner",
              new Parameter<Boolean>("Skew Side UVs", Boolean.class, false)
            );
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        Boolean skew = (Boolean)parameterValues[0];

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
            
        MaterialType mtInternal = config2.getMaterialType();

        // This shape is four triangles.  Two half triangles facing
        // north and west.  A full triangle facing down.  And a triangle
        // for the slope.

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();

        // 1:2 normals
        Vector3f normal1 = new Vector3f(0.5f, 1, 0).normalizeLocal();
        Vector3f normal2 = new Vector3f(0, 1, 0.5f).normalizeLocal(); 

        BoundaryShape bottom = BoundaryShapes.getTriangle(0, 0, 1, 1, 1/Math.sqrt(2), 1/Math.sqrt(2)); 
        BoundaryShape triangle = BoundaryShapes.getTriangle(0, 0, 1, 0.5, normal1.x, normal1.y); 
 
        GeomPart down = new GeomPart(mt, Direction.Down.ordinal(), false);
        //  2
        //  
        //  0   1
        down.setCoords(
                0, 0, 0,
                1, 0, 0,
                0, 0, 1
            );
        down.setTexCoords(
                0, 0,
                1, 0,
                0, 1
            );
        down.setIndexes(0, 1, 2);
        dirTemplates[5] = DefaultPartFactory.create(bottom, down);

        GeomPart north = new GeomPart(mt, Direction.North.ordinal(), false);
        //       2
        //      
        //  0    1
        north.setCoords(
            1, 0, 0,
            0, 0, 0,
            0, 0.5f, 0
            );
        if( skew ) {
            north.setTexCoords(
                0, 1,
                1, 0.5f,
                1, 1
                );
        } else {
            north.setTexCoords(
                0, 0,
                1, 0,
                1, 0.5f
                );
        }                
        north.setIndexes(0, 1, 2);
        north.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[0] = DefaultPartFactory.create(triangle, north);

        //  2
        //
        //  0    1
        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        west.setCoords(
            0, 0, 0,
            0, 0, 1,
            0, 0.5f, 0
            );
        if( skew ) {
            west.setTexCoords(
                0, 0.5f,
                1, 1,
                0, 1    
                );
        } else {
            west.setTexCoords(
                0, 0,
                1, 0,
                0, 0.5f    
                );
        }
        west.setIndexes(0, 1, 2);
        west.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[3] = DefaultPartFactory.create(triangle, west);
 
        // Now for the slope
        Vector3f norm = normal1.add(normal2).normalizeLocal();
        Vector3f tan = new Vector3f(1, 0, 0); // texture will still be oriented x,z
 
        GeomPart slope;
        slope = new GeomPart(mtInternal, -1, false);
        //  0    2
        //
        //  1            
        slope.setCoords(
            0, 0.5f, 0,
            0, 0,    1,
            1, 0,    0
            );
        slope.setTexCoords(
            0, 1,
            0, 0,
            1, 1
            );
        slope.setNormals(FloatUtils.toFloatArray(3, norm));
        slope.setTangents(FloatUtils.toFloatArray(3, tan));
        slope.setIndexes(0, 1, 2);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("shallow-corner", 0));
    }
}



