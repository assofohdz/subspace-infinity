/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.nio.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DebugBoundaryShapesState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(DebugBoundaryShapesState.class);

    private VersionedReference<Integer> blockType;

    private Node shapeRoot;

    public DebugBoundaryShapesState() {        
    }
 
    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }
    
    @Override
    protected void initialize( Application app ) {
        this.shapeRoot = new Node("shapes");
        
        blockType = getState(BlockSetMenuState.class).getSelectedTypeRef();
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(shapeRoot);
        resetShapes();
    }
    
    @Override
    protected void onDisable() {
        shapeRoot.removeFromParent();
    }
    
    @Override
    public void update( float tpf ) {
        if( blockType.update() ) {
            resetShapes();
        }
    }
    
    protected void resetShapes() {
        shapeRoot.detachAllChildren();
        
        BlockType type = BlockTypeIndex.get(blockType.get());        
        if( type == null ) {
            return;
        }
 
        // The block type 'field' has been centered which makes its
        // block origin offset.
        Vector3f origin = new Vector3f(-0.5f, 0.5f, -0.5f);
 
        Geometry og = new Geometry("origin", new Box(0.1f, 0.1f, 0.1f));
        og.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Cyan, false).getMaterial());
        og.setLocalTranslation(origin);
        shapeRoot.attachChild(og);
        
        for( int d = 0; d < 6; d++ ) {
            Direction dir = Direction.values()[d];
            
            BoundaryShape shape = type.getShape(dir);
 
            //Vec3i proj = dir.getVec3i();
            Vec3d proj = dir.getAxis().getDirection().toVec3d().multLocal(0.5);
            proj.addLocal(dir.getVec3i().toVec3d().mult(0.6));
            
            Vec3i left = dir.getAxis().getLeft();
            Vec3i up = dir.getAxis().getUp();
 
            List<Vector3f> verts = new ArrayList<>();
            
            for( Vector2f bv : shape.getBorder() ) {
                Vector3f v = new Vector3f(origin); 
                v.addLocal(proj.toVector3f());
                v.addLocal(-left.x * bv.x, -left.y * bv.x, -left.z * bv.x); 
                v.addLocal(up.x * bv.y, up.y * bv.y, up.z * bv.y);
                
                verts.add(v); 
            }
            if( verts.isEmpty() ) {
                continue;
            }
            
            // Close the loop
            verts.add(verts.get(0));
            
            Mesh mesh = new Mesh();
            mesh.setMode(Mesh.Mode.LineStrip);
            
            FloatBuffer pb = BufferUtils.createFloatBuffer(verts.toArray(new Vector3f[0]));
            mesh.setBuffer(VertexBuffer.Type.Position, 3, pb);
            mesh.updateBound();
            mesh.setStatic();

            ColorRGBA color = ColorRGBA.Yellow; 
            switch( dir.getAxis() ) {
                case X:
                    color = ColorRGBA.Red;
                    break;
                case Y:
                    color = ColorRGBA.Green;
                    break;
                case Z:
                    color = ColorRGBA.Blue;
                    break;
            }
            
            
            Geometry geom = new Geometry("shape:" + dir, mesh);
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(color, false).getMaterial());
            shapeRoot.attachChild(geom);
        }       
    } 
}
