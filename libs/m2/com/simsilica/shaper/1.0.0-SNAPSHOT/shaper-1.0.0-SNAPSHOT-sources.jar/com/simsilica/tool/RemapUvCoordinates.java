/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.math.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *  Allows bulk remapping the UV coordinates for some block type
 *  or set of block types.
 *
 *  @author    Paul Speed
 */
public class RemapUvCoordinates extends Container {
    static Logger log = LoggerFactory.getLogger(RemapUvCoordinates.class);
 
    private List<BlockType> types;
    private Map<MaterialType, UvIndex> index = new HashMap<>();
    private ListMultimap<Vector2fEditor, Uv> editors = MultimapBuilder.linkedHashKeys().arrayListValues().build();
    
    public RemapUvCoordinates( BlockType... types ) {
        this(Arrays.asList(types));
    }
    
    public RemapUvCoordinates( List<BlockType> types ) {
        super(new BorderLayout());
        
        this.types = types;
 
        buildIndex();

        addChild(new Label("Remap UVs", new ElementId("window.title"), null), BorderLayout.Position.North);
        
        Container contents = addChild(new Container(), BorderLayout.Position.Center);        

        for( Map.Entry<MaterialType, UvIndex> e : index.entrySet() ) {
            log.info("Material:" + e.getKey());
 
            MaterialType mt = e.getKey();           
            contents.addChild(new Label("Material:" + mt.getName() + "   with:" + mt.getGeomReqs()));
            Container properties = contents.addChild(new Container());
            
            for( Vector2f v : e.getValue().uvs.keySet() ) {
                log.info("   " + v);
                properties.addChild(new Label(v.toString()));
                Vector2fEditor editor = properties.addChild(new Vector2fEditor(Axis.X, -1, 1, 0.01, 0.001), 1);
                editor.setObject(v);
                List<Uv> uvs = e.getValue().uvs.get(v); 
                editors.putAll(editor, uvs);
            }            
        }

        Container buttons = contents.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "clearAll")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "resetAll")));
        
        buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)), BorderLayout.Position.South);
        buttons.addChild(new ActionButton(new CallMethodAction(this, "apply")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));
    }
    
    public void apply() {
        
        for( Map.Entry<Vector2fEditor, Uv> e : editors.entries() ) {
            Vector2f v = e.getKey().getObject();
            log.info("Applying:" + v + "  to:" + e.getValue());
            e.getValue().set(v);
        }
    
        removeFromParent();
    }
    
    public void cancel() {
        removeFromParent();
    }
 
    public void clearAll() {
        for( Vector2fEditor editor : editors.keySet() ) {
            editor.setObject(new Vector2f(0,0));
        }
    }
    
    public void resetAll() {
        for( Map.Entry<Vector2fEditor, Uv> e : editors.entries() ) {
            // Only really need to do one per editor
            e.getKey().setObject(e.getValue().get());
        }
    }
 
    protected void buildIndex() {
        // Build up the set of UVs and material sections
        for( BlockType type : types ) {
            index(type);    
        }       
    }
    
    protected void index( BlockType type ) {
        if( type.getFactory() instanceof DefaultBlockFactory ) {
            index((DefaultBlockFactory)type.getFactory());
        }
    }
    
    protected void index( DefaultBlockFactory factory ) {
        if( factory == null ) {
            return;
        }
        if( factory.getDirParts() != null ) {
            for( PartFactory f : factory.getDirParts() ) {
                index(f);
            }
        } 
        index(factory.getInternalParts());
    }

    protected void index( PartFactory factory ) {
        if( factory instanceof DefaultPartFactory ) {
            index((DefaultPartFactory)factory);
        }
    }        
    protected void index( DefaultPartFactory factory ) {
        if( factory == null ) {
            return;
        }
        for( GeomPart part : factory.getTemplates() ) {
            index(part);
        }
    }
    protected void index( GeomPart part ) {
        if( part == null ) {
            return;
        }
        if( part.getTexCoords() == null ) {
            return;
        }
        log.info("index(part) size:" + (part.getTexCoords().length/2) + " material:" + part.getMaterialType());
     
        UvIndex uvIndex = index.get(part.getMaterialType());
        if( uvIndex == null ) {
            uvIndex = new UvIndex();
            index.put(part.getMaterialType(), uvIndex);
        }        
        uvIndex.add(part);
    }

    protected class Uv {
        GeomPart part;
        int index;
        
        public Uv( GeomPart part, int index ) {
            this.part = part;
            this.index = index;            
        }
        
        public Vector2f get() {
            float[] uvs = part.getTexCoords();
            return new Vector2f(uvs[index], uvs[index+1]);
        }
        
        public void set( Vector2f uv ) {
            float[] uvs = part.getTexCoords();
            uvs[index] = uv.x;
            uvs[index+1] = uv.y;
        }
        
        public String toString() {
            return "Uv[part:" + part + ", index:" + index + "]";
        }
    }

    protected class UvIndex {
        private ListMultimap<Vector2f, Uv> uvs = MultimapBuilder.hashKeys().arrayListValues().build();

        public void add( GeomPart part ) {
            int size = part.getTexCoords().length;
            for( int i = 0; i < size; i += 2 ) {
                Uv uv = new Uv(part, i);
                uvs.put(uv.get(), uv);
            }   
        }

    }      
}


