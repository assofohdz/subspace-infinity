/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Strings;
import com.google.common.collect.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CreateReskin extends Container {
    static Logger log = LoggerFactory.getLogger(CreateReskin.class);
    
    private List<BlockType> subset;
    private BlockSet blockSet;
    private MaterialSet materials;

    private List<MaterialType> materialIndex = new ArrayList<>();
 
    private TextField groupName;
    private Map<String, Selector<String>> remap = new HashMap<>();
 
    private BlockType first;
    
    public CreateReskin( List<BlockType> subset, BlockSet blockSet, MaterialSet materials ) {
        super(new BorderLayout());
        
        this.subset = subset;
        this.blockSet = blockSet;
        this.materials = materials;
            
        buildIndex();
 
        Set<String> names = new TreeSet<>();               
        for( MaterialType type : materialIndex ) {
            log.info("Material:" + type);            
            names.add(type.getName());
        }
 
        addChild(new Label("Create Reskinned Set", new ElementId("window.title"), null), BorderLayout.Position.North);
        
        Container contents = addChild(new Container(), BorderLayout.Position.Center);        
 
        Container properties;
        
        properties = contents.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("New Base:"));
        groupName = properties.addChild(new TextField(""), 1);
        
        contents.addChild(new Label("Remap materials:"));
        properties = contents.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        for( String name : names ) {
            properties.addChild(new Label(name + ":"));
            Selector<String> selector = properties.addChild(new Selector<String>(materials.getMaterialNames()), 1);
            remap.put(name, selector);
        }
        
        Container buttons;       
        buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)), BorderLayout.Position.South);
        buttons.addChild(new ActionButton(new CallMethodAction(this, "createReskin")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));
    }
    
    public void createReskin() {
 
        String newBase = groupName.getText().trim();
        if( Strings.isNullOrEmpty(newBase) ) {
            return;
        }
    
        List<BlockType> newTypes = new ArrayList<>();
        
        for( BlockType type : subset ) {
            BlockType clone = clone(type);
            BlockName name = clone.getName();            
            clone.setName(new BlockName(newBase, name.getShape(), name.getRotation()));
 
            remapMaterials(clone);
            
            newTypes.add(clone);
            blockSet.add(clone);
        }        
        
        first = newTypes.get(0);    
        removeFromParent();
    }
    
    public BlockType getFirstNewType() {
        return first;
    }
 
    protected BlockType clone( BlockType type ) {
 
        try {
            // Create a deep clone using the serializer.  This will guarantee
            // we don't leak anything.
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();    
            try( ObjectOutputStream out = new ObjectOutputStream(bytes) ) {
                out.writeObject(type);
            }
            ByteArrayInputStream rawIn = new ByteArrayInputStream(bytes.toByteArray());
            try( ObjectInputStream in = new ObjectInputStream(rawIn) ) {
                return (BlockType)in.readObject();
            }
        } catch( Exception e ) {
            throw new RuntimeException("Error cloning object:" + type, e);
        } 
    }
    
    public void cancel() {
        removeFromParent();
    }
    
    protected void buildIndex() {
        // Build up the set of UVs and material sections
        for( BlockType type : subset ) {
            index(type);    
        }       
    }
    
    protected void index( BlockType type ) {
        if( type.getFactory() instanceof DefaultBlockFactory ) {
            index((DefaultBlockFactory)type.getFactory());
        }
    }
    
    protected void index( DefaultBlockFactory factory ) {
        if( factory == null ) {
            return;
        }
        if( factory.getDirParts() != null ) {
            for( PartFactory f : factory.getDirParts() ) {
                index(f);
            }
        } 
        index(factory.getInternalParts());
    }

    protected void index( PartFactory factory ) {
        if( factory instanceof DefaultPartFactory ) {
            index((DefaultPartFactory)factory);
        }
    }        
    protected void index( DefaultPartFactory factory ) {
        if( factory == null ) {
            return;
        }
        for( GeomPart part : factory.getTemplates() ) {
            index(part);
        }
    }
    protected void index( GeomPart part ) {
        if( part == null ) {
            return;
        }
                
        // Each part may have a unique set of materials to select
        // from depending on its own requirements.  For now we will
        // assume that all material names + caps are fungible to 
        // some material type of a different name... because that meets
        // my requirements today.  Indexing the requirements is otherwise
        // not straight-forward.  We'll do the fixup the best we can when
        // we are reskinning the copies.
        materialIndex.add(part.getMaterialType());        
    }
 
    protected void remapMaterials( BlockType type ) {
        if( type.getFactory() instanceof DefaultBlockFactory ) {
            remapMaterials((DefaultBlockFactory)type.getFactory());
        }
    }
    
    protected void remapMaterials( DefaultBlockFactory factory ) {
        if( factory == null ) {
            return;
        }
        if( factory.getDirParts() != null ) {
            for( PartFactory f : factory.getDirParts() ) {
                remapMaterials(f);
            }
        } 
        remapMaterials(factory.getInternalParts());
    }

    protected void remapMaterials( PartFactory factory ) {
        if( factory instanceof DefaultPartFactory ) {
            remapMaterials((DefaultPartFactory)factory);
        }
    }        
    protected void remapMaterials( DefaultPartFactory factory ) {
        if( factory == null ) {
            return;
        }
        for( GeomPart part : factory.getTemplates() ) {
            remapMaterials(part);
        }
    }
    protected void remapMaterials( GeomPart part ) {
        if( part == null ) {
            return;
        }
        
        String oldName = part.getMaterialType().getName();
        Selector<String> newNameSelector = remap.get(oldName);
        String newName = newNameSelector != null ? newNameSelector.getSelectedItem() : null;
        if( newName == null ) {
            log.error("No new name for:" + oldName);
            return;
        }
        
        EnumSet<GeomReq> caps = part.calculateGeomCaps();
        
        MaterialConfig best = materials.findBest(newName, part.calculateGeomCaps());
        if( best != null ) {
            MaterialType newType = best.getMaterialType(); 
            log.info("Remapping:" + oldName + " to:" + newType);
            part.setMaterialType(newType);
        }
    }
}

/*    protected VersionedList<MaterialConfig> getMaterials( GeomPart part ) {
log.info("getMaterials(" + part + ")");    
    
        // Yes, this is all kinds of inefficient... but we're not performance cricital either
        VersionedList<MaterialConfig> result = new VersionedList();
        
        MaterialRegistry registry = materialSet.getRegistry();
        for( String name : registry.getNames() ) {
log.info("  checking:" + name);        
            MaterialConfig best = registry.findBest(name, part);
log.info("    best:" + best);             
            if( best != null ) {
                result.add(best);
            }
        }
        
        return result;
    }*/

