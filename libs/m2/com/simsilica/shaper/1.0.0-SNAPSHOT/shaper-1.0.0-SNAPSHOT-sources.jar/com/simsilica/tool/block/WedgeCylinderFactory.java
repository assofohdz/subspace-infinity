/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class WedgeCylinderFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(WedgeCylinderFactory.class);

    public WedgeCylinderFactory() {
        super("Wedge Cylinder", "wedge-cyl",
                new Parameter<Double>("Top Radius", Double.class, 0.5, 0.0, 1.0),
                new Parameter<Double>("Bottom Radius", Double.class, 0.5, 0.0, 1.0),
                new Parameter<Double>("Height", Double.class, 1.0, 0.0, 1.0),
                new Parameter<Double>("Slope", Double.class, 1.0, -1.0, 1.0)
            );
    }

    public WedgeCylinderFactory( String name, String shape, double topRadius, double bottomRadius ) {
        super(name, shape,
              new Parameter<Double>("Top Radius", Double.class, topRadius, 0.0, 1.0),
              new Parameter<Double>("Bottom Radius", Double.class, bottomRadius, 0.0, 1.0)
            );
    }

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        //float slope = 1; // 45 degrees
        float height = (float)(double)(Double)parameterValues[2];
        float slope = (float)(double)(Double)parameterValues[3];

        height = Math.max(Math.abs(slope), height);

        // For the end caps
        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        // For the sides
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mtEnds = config1.getMaterialType();
        MaterialType mtSides = config2.getMaterialType();

        PartFactory[] dirTemplates = new PartFactory[6];
        //List<GeomPart> internalParts = new ArrayList<>();

        float yTop = 1;
        float yBottom = 0;

        if( slope > 0 ) {
            yTop = height;
        } else if( slope < 0 ) {
            yBottom = 1 - height;
        }

        //float radius = 0.5f;
        float topRadius = (float)(double)(Double)parameterValues[0];
        float bottomRadius = (float)(double)(Double)parameterValues[1];
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;

        // How often the texture repeats around the sides
        float tex = 4.0f / sideCount;

        // The texture coordinates are a little odd in that they cover the
        // full square and squash it in the angles.
        // The index 0 will be used for the center texture coordinate
        // So one for the center and 8 for the sides.
        float[][] topTex = new float[9][2];
        topTex[0][0] = 0.5f;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;    // right
        topTex[1][1] = 0.5f;
        topTex[2][0] = 1;    // upper right
        topTex[2][1] = 1;
        topTex[3][0] = 0.5f; // upper
        topTex[3][1] = 1;
        topTex[4][0] = 0;    // upper left
        topTex[4][1] = 1;
        topTex[5][0] = 0;    // left
        topTex[5][1] = 0.5f;
        topTex[6][0] = 0;    // lower left
        topTex[6][1] = 0;
        topTex[7][0] = 0.5f; // lower
        topTex[7][1] = 0;
        topTex[8][0] = 1;    // lower right
        topTex[8][1] = 0;

        float cosNormal = 1;
        float sinNormal = bottomRadius - topRadius;
        float temp = FastMath.sqrt(sinNormal * sinNormal + cosNormal * cosNormal);
        sinNormal /= temp;
        cosNormal /= temp;

        GeomPart top;
        Vector3f[] topCoords;
        if( topRadius == 0 ) {
            top = null;
            topCoords = null;
        } else {
            if( slope > 0 ) {
                // The bottom is solid but the top is sloped
                top = new GeomPart(mtSides);

                // Calculate the normal for all of those points
                top.setNormals(FloatUtils.toFloatArray(9, new Vector3f(0, 1, slope).normalizeLocal()));
                top.setTangents(FloatUtils.toFloatArray(9, new Vector3f(1, 0, 0)));

                // Note: it might be a bug that if you only set normals then the material
                // reqs won't show normals... you have to set both tangents and normals.
                // It could be by design and I don't have time to look into it at the moment. -pspeed:2022-10-12
            } else {
                // The top is solid and the bottom is sloped
                top = new GeomPart(mtEnds, Direction.Up.ordinal(), true);
            }
            // End caps will have side count vertexes and a center point.
            // We'll build the triangles from those.
            top.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            topCoords = new Vector3f[9];
        }
        GeomPart bottom;
        Vector3f[] bottomCoords;
        if( bottomRadius == 0 ) {
            bottom = null;
            bottomCoords = null;
        } else {
            if( slope < 0 ) {
                // The top is solid and the bottom is sloped
                bottom = new GeomPart(mtSides);

                // Calculate the normal for all of those points
                bottom.setNormals(FloatUtils.toFloatArray(9, new Vector3f(0, -1, -slope).normalizeLocal()));
                bottom.setTangents(FloatUtils.toFloatArray(9, new Vector3f(1, 0, 0)));
            } else {
                // The bottom is solid and the top is sloped
                bottom = new GeomPart(mtEnds, Direction.Down.ordinal(), true);
            }
            bottom.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            bottomCoords = new Vector3f[9];
        }

        BoundaryShape topShape = top == null ? null : BoundaryShapes.getCircle(0.5, 0.5, topRadius);
        BoundaryShape bottomShape = bottom == null ? null : BoundaryShapes.getCircle(0.5, 0.5, bottomRadius);

        // The side coordinates will need to wrap around and overlap
        // so that texture coordinates will wrap properly.
        Vector3f[] sideCoords = new Vector3f[9 * 2];
        Vector3f[] sideNormals = new Vector3f[9 * 2];
        Vector3f[] sideTangents = new Vector3f[9 * 2];
        Vector2f[] sideTexCoords = new Vector2f[9 * 2];

        if( topCoords != null ) {
            if( slope <= 0 ) {
                topCoords[0] = new Vector3f(0.5f, yTop, 0.5f);
            } else {
                topCoords[0] = new Vector3f(0.5f, yTop - slope * 0.5f, 0.5f);
            }
        }
        if( bottomCoords != null ) {
            if( slope >= 0 ) {
                bottomCoords[0] = new Vector3f(0.5f, yBottom, 0.5f);
            } else {
                bottomCoords[0] = new Vector3f(0.5f, yBottom - slope * 0.5f, 0.5f);
            }
        }
        for( int i = 0; i < sideCount; i++ ) {
            // Note: -z goes 'up' in the sense of our textures
            float x = FastMath.cos(i * delta);
            float z = -FastMath.sin(i * delta);

            float y1 = yTop;
            float y2 = yBottom;

            if( slope > 0 ) {
                y1 = yTop - (0.5f + z * 0.5f) * slope;
            } else if( slope < 0 ) {
                y2 = yBottom - (0.5f + z * 0.5f) * slope;
            }

            if( topCoords != null ) {
                topCoords[i+1] = new Vector3f(0.5f + x * topRadius, y1, 0.5f + z * topRadius);
            }
            if( bottomCoords != null ) {
                bottomCoords[i+1] = new Vector3f(0.5f + x * bottomRadius, y2, 0.5f + z * bottomRadius);
            }

            Vector3f norm = new Vector3f(x * cosNormal, sinNormal, z * cosNormal).normalizeLocal();
            Vector3f tan = norm.cross(Vector3f.UNIT_Y);
            sideCoords[i * 2] = new Vector3f(0.5f + x * topRadius, y1, 0.5f + z * topRadius);
            sideNormals[i * 2] = norm;
            sideTangents[i * 2] = tan;
            sideTexCoords[i * 2] = new Vector2f(i * tex, 1);
            sideCoords[i * 2 + 1] = new Vector3f(0.5f + x * bottomRadius, y2, 0.5f + z * bottomRadius);
            sideNormals[i * 2 + 1] = norm;
            sideTangents[i * 2 + 1] = tan;
            sideTexCoords[i * 2 + 1] = new Vector2f(i * tex, 0);
        }
        // and the overlap
        sideCoords[sideCount * 2] = sideCoords[0];
        sideCoords[sideCount * 2 + 1] = sideCoords[1];
        sideNormals[sideCount * 2] = sideNormals[0];
        sideNormals[sideCount * 2 + 1] = sideNormals[1];
        sideTangents[sideCount * 2] = sideTangents[0];
        sideTangents[sideCount * 2 + 1] = sideTangents[1];
        sideTexCoords[sideCount * 2] = new Vector2f(sideCount * tex, 1);
        sideTexCoords[sideCount * 2 + 1] = new Vector2f(sideCount * tex, 0);

        if( top != null ) {
            top.setCoords(FloatUtils.toFloatArray(topCoords));
            top.setIndexes(
                0, 1, 2,
                0, 2, 3,
                0, 3, 4,
                0, 4, 5,
                0, 5, 6,
                0, 6, 7,
                0, 7, 8,
                0, 8, 1
                );
        }
        if( bottom != null ) {
            bottom.setCoords(FloatUtils.toFloatArray(bottomCoords));
            bottom.setIndexes(
                0, 2, 1,
                0, 3, 2,
                0, 4, 3,
                0, 5, 4,
                0, 6, 5,
                0, 7, 6,
                0, 8, 7,
                0, 1, 8
                );
        }

        GeomPart sides = new GeomPart(mtSides);
        sides.setCoords(FloatUtils.toFloatArray(sideCoords));
        sides.setNormals(FloatUtils.toFloatArray(sideNormals));
        sides.setTangents(FloatUtils.toFloatArray(sideTangents));
        sides.setTexCoords(FloatUtils.toFloatArray(sideTexCoords));

        int[] sideIndexes = new int[sideCount * 2 * 3]; // 2 triangles per side
        int baseIndex = 0;
        int sideIndex = 0;
        for( int i = 0; i < sideCount; i++ ) {
            // We built the vertex array as top, bottom, top, bottom
            // First triangle b, bNext, tNext, b, tNext, t
            // 0 2
            // 1 3
            // 1, 3, 2
            // 1, 2, 0
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 3;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 0;

            baseIndex += 2;
        }
        sides.setIndexes(sideIndexes);

        DefaultPartFactory internalFactory;
        if( slope > 0 && top != null ) {
            internalFactory = DefaultPartFactory.create(sides, top);
        } else if( slope < 0 && bottom != null ) {
            internalFactory = DefaultPartFactory.create(sides, bottom);
        } else {
            internalFactory = DefaultPartFactory.create(sides);
        }

        // Have to wrap the GeomParts after we make them else the DefaultPartFactory
        // will get NPEs and stuff.
        if( top != null && slope <= 0 ) {
            dirTemplates[top.getDirectionIndex()] = DefaultPartFactory.create(topShape, top);
        }
        if( bottom != null && slope >= 0 ) {
            dirTemplates[bottom.getDirectionIndex()] = DefaultPartFactory.create(bottomShape, bottom);
        }

        //GeomPart[] partArray = null;
        //if( !internalParts.isEmpty() ) {
        //    partArray = internalParts.toArray(new GeomPart[0]);
        //    internalFactory = DefaultPartFactory.create(partArray);
        //}
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);

        // For now we'll mangle the min/max so that a cube collider will sort of work.
        if( slope > 0 ) {
            // By creating a block that only covers half the space then we simulate
            // a wedge sort of... in the sense that something on top would fall off
            // halfway over.
            bf.getMin().set(0, yBottom, 0);
            bf.getMax().set(1, yTop, 0.5);
        } else if( slope < 0 ) {
            bf.getMin().set(0, yBottom, 0);
            bf.getMax().set(1, yTop, 0.5);
        }

        // Future-Paul, sorry for hard-coding this ColliderType string here.
        return new BlockType(name, bf, new ColliderType("cube", 0));
    }
}

