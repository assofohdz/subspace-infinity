/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import com.simsilica.lemur.core.VersionedList;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.config.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MaterialSet {
    
    private VersionedList<MaterialConfig> materials = new VersionedList<>();
    private transient MaterialRegistry registry;
    private transient VersionedList<String> materialNames;
    
    public MaterialSet() {
    }
    
    public static MaterialSet createDefault( String baseTexture, String specialTexture, String badTexture ) {
        MaterialRegistry mats = DefaultBlockSet.createDefaultMaterials(baseTexture, specialTexture, badTexture);
        MaterialSet result = new MaterialSet();         
        result.materials.addAll(mats.getConfigs());        
        return result;
    }
 
    public MaterialConfig findBest( String name, EnumSet<GeomReq> caps ) {
        MaterialConfig result = getRegistry().findBest(name, caps);
        if( result == null ) {
            result = getRegistry().findBest("bad", caps);
        }
        return result;
    }

    public MaterialConfig findBest( String name, GeomReq... caps ) {
        MaterialConfig result = getRegistry().findBest(name, caps);
        if( result == null ) {
            result = getRegistry().findBest("bad", caps);
        }
        return result;
    }
 
    public MaterialRegistry getRegistry() {
        if( registry == null ) {
            registry = new MaterialRegistry();
            registry.addConfigs(materials);
        }
        return registry;
    }
    
    public VersionedList<String> getMaterialNames() {
        if( materialNames == null ) {
            materialNames = new VersionedList<>(new ArrayList<String>(getRegistry().getNames()));
        }
        return materialNames;
    }
 
    public MaterialConfig get( MaterialType type ) {
        for( MaterialConfig config : materials ) {
            if( Objects.equals(type, config.getMaterialType()) ) {
                return config;
            }
        }
        return null;
    }
    
    public VersionedList<MaterialConfig> getMaterials() {
        return materials;
    } 
}
