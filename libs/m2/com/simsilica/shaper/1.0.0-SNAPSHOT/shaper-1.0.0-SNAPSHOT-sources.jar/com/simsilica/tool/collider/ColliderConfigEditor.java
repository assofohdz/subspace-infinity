/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;

import com.simsilica.tool.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ColliderConfigEditor extends Container {
    static Logger log = LoggerFactory.getLogger(ColliderConfigEditor.class);
 
    private BlockSet blockSet;
    
    private boolean editorVisible;
    private Label placeholder;
    
    private Container editor;
    private Selector<BlockType> typeSelector;
    private VersionedReference<Integer> typeIndexRef;
 
    private SideToggle[] toggles; 
 
    private VersionedHolder<Integer> cellValue = new VersionedHolder<>(0);
    
    public ColliderConfigEditor( BlockSet blockSet ) {
        this.blockSet = blockSet;
 
        placeholder = addChild(new Label("N/A"));

        editor = new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last));
        Container sub = editor.addChild(new Container());
        sub.addChild(new Label("Type:"));
        typeSelector = sub.addChild(
                    new Selector<>(blockSet.getTypes(),
                                   new BlockSetMenuState.TypeCellRenderer(new ElementId("selector.item"), null),
                                   null), 
                    1);
        
        typeIndexRef = typeSelector.getListBox().getSelectionModel().createSelectionReference();
 
        editor.addChild(new Label("Side masks:"));       
        sub = editor.addChild(new Container());
        sub.setInsetsComponent(new DynamicInsetsComponent(0, 0, 0, 1));
        toggles = new SideToggle[6];
        toggles[0] = new SideToggle("n", Direction.North);
        toggles[1] = new SideToggle("s", Direction.South);
        toggles[2] = new SideToggle("e", Direction.East);
        toggles[3] = new SideToggle("w", Direction.West);
        toggles[4] = new SideToggle("up", Direction.Up);
        toggles[5] = new SideToggle("down", Direction.Down);
 
        sub.addChild(toggles[0].check, 0, 1);
        sub.addChild(toggles[1].check, 2, 1);
        sub.addChild(toggles[2].check, 1, 2);
        sub.addChild(toggles[3].check, 1, 0);
        sub.addChild(new Label("  "), 0, 3);
        sub.addChild(toggles[4].check, 0, 4);
        sub.addChild(toggles[5].check, 2, 4);
        sub.addChild(new Label(" "), 0, 5);
    }
 
    public void setCellValue( Integer value ) {
        if( cellValue.updateObject(value) ) {
            updateForm();
        }        
    }
 
    public Integer getCellValue() {
        return cellValue.getObject();
    }
    
    public VersionedReference<Integer> createCellValueRef() {
        return cellValue.createReference();
    }
    
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        boolean valueChanged = false;
        if( typeIndexRef.update() ) {
            valueChanged = true;
        }
        for( SideToggle toggle : toggles ) {
            if( toggle.update() ) {
                valueChanged = true;
            }
        }
        if( valueChanged ) {
            updateValue();
        }        
    }
 
    public void setEditorVisible( boolean editorVisible ) {
        if( this.editorVisible == editorVisible ) {
            return;
        }
        this.editorVisible = editorVisible;
        if( editorVisible ) {
            removeChild(placeholder);
            addChild(editor);
        } else {
            removeChild(editor);
            addChild(placeholder);
        }
    }
 
    /**
     *  Called when then data changes externally and must now be reflected in the view.
     */    
    protected void updateForm() {
        Integer val = cellValue.getObject();
        setEditorVisible(val != null);
 
        int sides = 0;       
        if( val == null ) {
            typeSelector.setSelectedItem(null);
        } else {
            int type = MaskUtils.getType(val);
            sides = MaskUtils.getSideMask(val);
            typeSelector.getListBox().getSelectionModel().setSelection(type);
        }
    
        updateToggles();
    }
    
    protected void updateToggles() {       
        Integer val = cellValue.getObject();
        int sides = val == null ? 0 : MaskUtils.getSideMask(val);
        for( SideToggle toggle : toggles ) {
            toggle.updateCheck(sides);
        }
    }
 
    /**
     *  Called when the view changes and must now be reflected in the model.
     */   
    protected void updateValue() {
        Integer type = typeSelector.getListBox().getSelectionModel().getSelection();
        if( type == null ) {
            cellValue.setObject(null);
            return;
        }
 
        // Else we need to add the mask info in
        int mask = 0;
        for( SideToggle toggle : toggles ) {
            if( toggle.check.isChecked() ) {            
                mask = mask | toggle.dirMask;
            }
        }
        boolean override = false;
        if( mask == 0 ) {
            mask = 0x3f;
            override = true;
        }
                        
        cellValue.setObject(MaskUtils.setSideMask(type, mask));
        if( override ) {
            updateToggles();
        }
    }
    
    private class SideToggle {
        Checkbox check;
        VersionedReference<Boolean> checkRef;
        Direction dir;
        int dirMask;
        
        public SideToggle( String name, Direction dir ) {
            this.check = new Checkbox(name);
            this.checkRef = check.getModel().createReference();
            this.dir = dir;
            this.dirMask = dir.getBitMask();
        }
 
        public boolean update() {
            return checkRef.update();
        }
        
        public void updateCheck( int val ) {
            check.setChecked((val & dirMask) != 0);
        }
    }
}
