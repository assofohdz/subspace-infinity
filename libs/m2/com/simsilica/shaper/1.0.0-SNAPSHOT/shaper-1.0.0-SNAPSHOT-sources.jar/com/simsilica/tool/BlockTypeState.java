/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.shader.VarType;
import com.jme3.util.TangentBinormalGenerator;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedReference;

import com.simsilica.fx.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *  Displays the current block type.
 *
 *  @author    Paul Speed
 */
public class BlockTypeState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BlockTypeState.class);

    private boolean invalid = true;

    private Node blocks;
    private Node fluids;
    private boolean smoothLighting = true;

    private ColorRGBA lightColor = ColorRGBA.White;
    private float sunStrength = 0.75f;
    private float localLight = 1;

    private int cellArraySize = 5;
    private CellArray cells = new CellArray(cellArraySize);
    private CellArray lightData = new CellArray(cellArraySize);
    private CellData safeLightData = new SafeCellData(lightData, LightUtils.DIRECT_SUN);
    private CellArray fluidData = new CellArray(cellArraySize);

    private Node normalsDebug;
    private Material normalsMaterial;
    private boolean showNormals = false;

    private VersionedReference<Integer> blockType;
    private VersionedReference<Integer> groundType;
    private VersionedReference<Integer> roofType;
    private VersionedReference<Integer> fluidType;
    private VersionedReference<Integer> fluidLevel;

    private VersionedReference<BlockType> blockTypeChanges;
    private VersionedReference<FluidType> fluidTypeChanges;

    public BlockTypeState() {
    }

    public void setShowNormals( boolean b ) {
        if( this.showNormals == b ) {
            return;
        }
        this.showNormals = b;
        updateNormalsDebug();
    }

    public boolean getShowNormals() {
        return showNormals;
    }

    public void setSunStrength( float f ) {
        if( this.sunStrength == f ) {
            return;
        }
        this.sunStrength = f;
        resetSunStrength();
    }

    public float getSunStrength() {
        return sunStrength;
    }

    public void setLocalLight( float localLight ) {
        this.localLight = localLight;
        resetLocalLight();
    }

    public float getLocalLight() {
        return localLight;
    }

    protected void resetSunStrength() {
        getState(LightingState.class).setSunColor(lightColor.mult(sunStrength));
        getState(LightingState.class).setAmbient(lightColor.mult(sunStrength * 0.5f));
    }

    protected void resetLocalLight() {
        if( blocks == null ) {
            return;
        }
        MatParamOverride mo = new MatParamOverride(VarType.Float, "LocalLightStrength", localLight);
        blocks.addMatParamOverride(mo);
        fluids.addMatParamOverride(mo);
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected GeometryFactory getGeomFactory() {
        return getState(BlockSetMenuState.class).getGeomFactory();
    }

    @Override
    protected void initialize( Application app ) {

        blocks = new Node("blocks");
        getGeomFactory().generateBlocks(blocks, cells, safeLightData, smoothLighting);

        fluids = new Node("fluids");
        getGeomFactory().generateFluid(fluids,  fluidData, cells, safeLightData, smoothLighting);

        normalsDebug = new Node("normals");
        normalsMaterial = GuiGlobals.getInstance().createMaterial(ColorRGBA.Cyan, false).getMaterial();

        float move = cellArraySize * 0.5f;
        blocks.move(-move, -0.5f, -move);
        fluids.move(-move, -0.5f, -move);
        normalsDebug.move(-move, -0.5f, -move);

        blockType = getState(BlockSetMenuState.class).getSelectedTypeRef();
        groundType = getState(BlockSetMenuState.class).getSelectedGroundRef();
        roofType = getState(BlockSetMenuState.class).getSelectedRoofRef();
        blockTypeChanges = getState(BlockSetMenuState.class).getBlockTypeRef();
        fluidType = getState(FluidSetMenuState.class).getSelectedTypeRef();
        fluidLevel= getState(FluidSetMenuState.class).getLevelRef();
        fluidTypeChanges = getState(FluidSetMenuState.class).getFluidTypeRef();

        resetStage();
        resetSunStrength();
        resetLocalLight();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    protected void recalculateMasks() {
        MaskUtils.calculateSideMasks(cells, cellArraySize);
        FluidUtils.calculateSideMasks(fluidData, cells, cellArraySize);

        // And we want the bottom border to always have the
        // sides cleared... ie: only render the top.
        /*for( int i = 0; i < cellArraySize; i++ ) {
            for( int j = 0; j < cellArraySize; j++ ) {
                int val = cells.getCell(i, 0, j);
                int type = MaskUtils.getType(val);
                if( type != 0 ) {
                    val = MaskUtils.setSideMask(val, DirectionMasks.UP_MASK);
                    cells.setCell(i, 0, j, val);
                }
            }
        }*/
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(blocks);
        getRoot().attachChild(fluids);
        getRoot().attachChild(normalsDebug);
    }

    @Override
    public void update( float tpf ) {
        if( blockTypeChanges.update()
            || fluidTypeChanges.update()
            || blockType.update()
            || groundType.update()
            || roofType.update()
            || fluidType.update()
            || fluidLevel.update() ) {
            resetStage();
        }

        if( invalid ) {
            invalid = false;
            recalculateLighting(cells, lightData, cellArraySize);
            getGeomFactory().generateBlocks(blocks, cells, safeLightData, smoothLighting);
            getGeomFactory().generateFluid(fluids,  fluidData, cells, safeLightData, smoothLighting);
            getState(DebugNormalsState.class).updateNormalsDebug(blocks);
            getState(GeometryInfoState.class).updateStats(blocks, fluids);
        }
    }

    @Override
    protected void onDisable() {
        getState(GeometryInfoState.class).clearStats();
        blocks.removeFromParent();
        fluids.removeFromParent();
        normalsDebug.removeFromParent();
    }

    public void setCells( CellData newCells ) {
        if( newCells == null ) {
            resetStage();
            return;
        }
        for( int i = 0; i < cellArraySize; i++ ) {
            for( int j = 0; j < cellArraySize; j++ ) {
                for( int k = 0; k < cellArraySize; k++ ) {
                    int val = newCells.getCell(i, j, k);
                    cells.setCell(i, j, k, val);
                }
            }
        }

        recalculateLighting(cells, lightData, cellArraySize);
        invalid = true;
    }

    public int getCell( int x, int y, int z ) {
        return cells.getCell(x, y, z);
    }

    protected void resetStage() {
        Integer type = blockType.get();
        Integer ground = groundType.get();
        Integer roof = roofType.get();
        Integer fluid = fluidType.get();
        Integer level = fluidLevel.get();

        log.info("type:" + type + "  ground:" + ground + "  roof:" + roof);

        if( type == null ) {
            type = 0;
        }
        if( ground == null ) {
            ground = 0;
        }
        if( roof == null ) {
            roof = 0;
        }
        if( fluid == null ) {
            fluid = 0;
        }
        if( level == null || fluid == 0 ) {
            level = 0;
        } else if( level != null ) {
            // It looks like 1-8 visually but the value in the fluid
            // data should be 0-7
            level--;
        }

        cells.clear();

        BlockType bt = BlockTypeIndex.get(type);
        if( bt != null ) {
            dump("", bt);
        }

        for( int i = 0; i < cellArraySize; i++ ) {
            for( int j = 0; j < cellArraySize; j++ ) {
                cells.setCell(i, 0, j, ground);
                //cells.setCell(i, 0, j, 0);
                //if( i > 0 && j > 0 && i < cellArraySize - 1 && j < cellArraySize - 1 ) {
                    cells.setCell(i, Math.min(5, cellArraySize-1), j, roof);
                //}

                fluidData.setCell(i, 1, j, FluidUtils.setLevel(fluid, level));

            }
        }
        int center = cellArraySize / 2;
        //cells.setCell(center, 0, center, ground);
        for( int i = 0; i < center; i++ ) {
            cells.setCell(i, 0, center, 0);
        }
        cells.setCell(center, 1, center, type);


        recalculateMasks();
        recalculateLighting(cells, lightData, cellArraySize);
        invalid = true;
    }

    protected void dump( String indent, BlockType type ) {
        log.info(indent + type.getName());
        log.info(indent + ".colliderType:" + type.getColliderType());
        log.info(indent + ".sideProps:");
        for( Direction dir : Direction.values() ) {
            log.info(indent + "  " + dir + " solid:" + type.isSolid(dir) + " transparent:" + type.getTransparency(dir) + "  shape:" + type.getShape(dir));
        }
        log.info(indent + ".factory:");
        dump(indent + "  ", type.getFactory());
    }

    protected void dump( String indent, BlockFactory factory ) {
        if( factory instanceof DefaultBlockFactory ) {
            dump(indent, (DefaultBlockFactory)factory);
        } else {
            log.info(indent + factory);
        }
    }

    protected void dump( String indent, DefaultBlockFactory factory ) {
        log.info(indent + ".bounds:");
        log.info(indent + "  min:" + factory.getMin());
        log.info(indent + "  max:" + factory.getMax());
        log.info(indent + ".parts:");
        log.info(indent + "  internal:");
        dump(indent + "    ", factory.getInternalParts());
        log.info(indent + "  dirs:");
        if( factory.getDirParts() != null ) {
            for( Direction dir : Direction.values() ) {
                log.info(indent + "    " + dir + ":");
                dump(indent + "    ", factory.getDirParts()[dir.ordinal()]);
            }
        }
    }

    protected void dump( String indent, PartFactory factory ) {
        if( factory instanceof DefaultPartFactory ) {
            dump(indent, (DefaultPartFactory)factory);
        } else {
            log.info(indent + factory);
        }
    }

    protected void dump( String indent, DefaultPartFactory factory ) {
        int i = 0;
        for( GeomPart part : factory.getTemplates() ) {
            log.info(indent + "[" + (i++) + "] type:" + part.getPrimitiveType()
                        + "  material:" + part.getMaterialType().getId() + " dir:" + part.getDirectionIndex());
        }
    }

    protected void recalculateLighting( CellArray cells, CellArray lights, int size ) {
        //log.info("recalculateLighting()");
        long start = System.nanoTime();
        LightUtils.recalculateLighting(cells, lights, size);
        long end = System.nanoTime();
        log.info("Recalculated lighting in " + ((end-start)/1000000.0) + " ms");
    }

    protected void updateNormalsDebug() {
        normalsDebug.detachAllChildren();
        updateNormalsDebug(normalsDebug, blocks);
        updateNormalsDebug(normalsDebug, fluids);
    }

    protected void updateNormalsDebug( Node target, Node source ) {
        if( !showNormals ) {
            return;
        }
        for( Spatial child : source.getChildren() ) {
            Spatial newChild = null;
            if( child instanceof Geometry ) {
                Mesh m = ((Geometry)child).getMesh();
                Mesh norms = TangentBinormalGenerator.genNormalLines(m, 0.25f);
                norms.updateBound();
                newChild = new Geometry("debug", norms);
                newChild.setMaterial(normalsMaterial);
            } else if( child instanceof Node ) {
                newChild = new Node("debug:" + child.getName());
                updateNormalsDebug((Node)newChild, (Node)child);
            } else {
                log.warn("unhandled spatial type:" + child);
                continue;
            }
            newChild.setLocalTranslation(child.getLocalTranslation());
            newChild.setLocalRotation(child.getLocalRotation());
            newChild.setLocalScale(child.getLocalScale());
            target.attachChild(newChild);
        }
    }
}

