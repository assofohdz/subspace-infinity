/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.input.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;
import com.simsilica.tool.*;

/**
 *  Simulation that allows placing a probe in the scene to see what
 *  intersects.
 *
 *  @author    Paul Speed
 */
public class ProbeSimulation implements Simulation {

    static Logger log = LoggerFactory.getLogger(ProbeSimulation.class);

    private ProbeConfig config;
    private MBlockCollisionSystem<String> collisionSystem;

    private Container editor;
    private Vec3dEditor majorPos;
    private VersionedReference<Vec3d> majorRef;
    private Vec3dEditor minorPos;
    private VersionedReference<Vec3d> minorRef;
    private Label combinedPos;
    
    private Spinner<Double> radius;
    private VersionedReference<Double> radiusRef;
    private Spinner<Double> opacity;
    private VersionedReference<Double> opacityRef;

    private VersionedList<ProbeInfo> probes = new VersionedList<>();
    private ListBox<ProbeInfo> probeList;
    private VersionedReference<Integer> probeSelectionRef;
        
    private Sphere sphere;
    private int radials = 24;
    private int slices = 24;
    private Geometry probeGeom;
    private ColorRGBA probeColor = new ColorRGBA(0, 0, 1, 0.5f);
    private Node probeNode;
 
    private Node contactRoot = new Node("contacts");   
    private MBlockShape probeShape;
    private RigidBody<String, MBlockShape> probeBody;
    private ContactAccumulator<String, MBlockShape> contacts = new ContactAccumulator<>();
    private Map<String, ContactGeom> contactViews = new HashMap<>();
    
    public ProbeSimulation() {
        this.config = ProbeConfig.getInstance();
    
        editor = new Container();
        
        editor.addChild(new Label("Major Position:"));        
        majorPos = editor.addChild(new Vec3dEditor(Axis.X, 0, 5, 1.0, 1.0));
        majorPos.setObject(config.getMajorPos());
        majorRef = majorPos.createReference();

        editor.addChild(new Label("Minor Position:"));
        minorPos = editor.addChild(new Vec3dEditor(Axis.X, -1, 1, 0.01, 0.01));
        minorPos.setObject(config.getMinorPos());
        minorRef = minorPos.createReference();
 
        editor.addChild(new Label("Combined Position:"));
        combinedPos = editor.addChild(new Label(getPositionString()));
        
        editor.addChild(new Label("Radius:"));
            
        radius = createDoubleSpinner(0.01, 1.0, 0.01, 0.01, config.getRadius());
        editor.addChild(radius);
        radiusRef = radius.getModel().createReference();

        editor.addChild(new Label("Opacity:"));
        opacity = createDoubleSpinner(0.01, 1.0, 0.1, 0.01, config.getOpacity());
        editor.addChild(opacity);
        opacityRef = opacity.getModel().createReference();
        probeColor.a = (float)(double)opacityRef.get();
  
        probes.addAll(config.getProbes());
        editor.addChild(new Label("Saved Probes:"));
        probeList = editor.addChild(new ListBox<>(probes));
        probeSelectionRef = probeList.getSelectionModel().createSelectionReference();
        editor.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeProbe")));
        editor.addChild(new ActionButton(new CallMethodAction("Random", this, "randomProbe"))); 
            
        sphere = new Sphere(slices, radials, (float)(double)radiusRef.get());
        probeGeom = new Geometry("probe", sphere);
        probeGeom.setMaterial(GuiGlobals.getInstance().createMaterial(probeColor, true).getMaterial());
        probeGeom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        probeGeom.setQueueBucket(Bucket.Transparent);

        probeNode = new Node("probe");
        probeNode.attachChild(probeGeom);
        
        // Add a crosshair to the center of the probe so we know what the
        // actual position is
        Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.Lines);
        float crossScale = 0.01f;
        mesh.setBuffer(VertexBuffer.Type.Position, 3, new float[] {
                    // Center crosshair
                    -crossScale, 0, 0,
                    crossScale, 0, 0,
                    0, -crossScale, 0,
                    0, crossScale, 0,
                    0, 0, -crossScale,
                    0, 0, crossScale
                    });
        ColorRGBA centerColor = ColorRGBA.Green;
        mesh.setBuffer(VertexBuffer.Type.Color, 4, new float[] {
                    // Center crosshair
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a,  
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a,  
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a,  
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a,  
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a,  
                    centerColor.r, centerColor.g, centerColor.b, centerColor.a
                    });
        Geometry geom = new Geometry("probeCenter", mesh);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.White, false).getMaterial());
        geom.getMaterial().setBoolean("VertexColor", true);
        probeNode.attachChild(geom);
            
        geom = geom.clone();
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(new ColorRGBA(1, 1, 1, 0.15f), false).getMaterial());
        geom.getMaterial().setBoolean("VertexColor", true);
        geom.getMaterial().getAdditionalRenderState().setDepthTest(false);
        geom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        geom.setQueueBucket(Bucket.Translucent);
        probeNode.attachChild(geom);        
                    
        
        
        probeShape = MBlockShape.createSphere(radiusRef.get(), 1);
        probeBody = new RigidBody<>("probe", probeShape); 
    }
 
    public static Spinner<Double> createDoubleSpinner( double min, double max, double step, double precision, double initialValue ) {
        SequenceModel<Double> model 
                = SequenceModels.rangedSequence(
                        new DefaultRangedValueModel(min, max, initialValue), 
                        step, precision);
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");            
        return new Spinner<>(model, renderer);
    }    
    
    @Override
    public String getName() {
        return "Probe";
    }
 
    @Override
    public void setCollisionSystem( MBlockCollisionSystem<String> collisionSystem ) {
        this.collisionSystem = collisionSystem;
    }
 
    protected Vec3d getPosition() {
        Vec3d major = majorPos.getObject();
        Vec3d minor = minorPos.getObject();
        return major.add(minor);
    }
 
    protected String getPositionString() {
        Vec3d pos = getPosition();
        return String.format("x: %.2f  y: %.2f  z: %.2f", pos.x, pos.y, pos.z); 
    }
 
    @Override
    public void update( float tpf ) {
        if( majorRef.update() || minorRef.update() ) {
            probeNode.setLocalTranslation(getPosition().toVector3f());
            combinedPos.setText(getPositionString());
            probeBody.position.set(getPosition());
        }
        if( radiusRef.update() ) {
            sphere.updateGeometry(slices, radials, (float)(double)radiusRef.get());
            probeGeom.updateModelBound();
            probeShape = MBlockShape.createSphere(radiusRef.get(), 1);    
            probeBody.shape = probeShape;
        }
        if( opacityRef.update() ) {
            probeColor.a = (float)(double)opacityRef.get();
        }
        if( probeSelectionRef.update() ) {
            Integer selection = probeSelectionRef.get();
            if( selection != null ) {
                snapToProbeInfo(probes.get(selection));
            }
        }
 
        if( collisionSystem != null ) {
            contacts.clear();
            collisionSystem.generateWorldCollisions(probeBody, contacts);
            
            //log.info("Contacts:" + contacts.contacts);
            viewContacts(contacts.contacts);
        } 
    }
    
    protected void viewContacts( List<Contact<String, MBlockShape>> list ) {
    
        Map<String, ContactGeom> newViews = new HashMap<>();
        
        for( Contact<String, MBlockShape> contact : list ) {
            String key = "" + contact.contactPoint + "|" + contact.contactNormal + "|" + contact.penetration;
            ContactGeom geom = contactViews.remove(key);
            if( geom == null ) {
                // Need to create it
                geom = new ContactGeom(contact);
                geom.setLocalTranslation(contact.contactPoint.toVector3f());
                contactRoot.attachChild(geom);
            }
            newViews.put(key, geom);
        }
 
        for( ContactGeom geom : contactViews.values() ) {
            geom.removeFromParent();
        }
        
        contactViews = newViews;
    }
        
    @Override
    public Panel attach( Node root ) {
        root.attachChild(probeNode);
        root.attachChild(contactRoot);
        return editor;        
    }
        
    @Override
    public void release() {
        probeNode.removeFromParent();
        contactRoot.removeFromParent();
 
        config.setMajorPos(majorPos.getObject());
        config.setMinorPos(minorPos.getObject());       
        config.setRadius(radius.getValue());
        config.setOpacity(opacity.getValue());
        config.setProbes(probes);
        ProbeConfig.save();
    }
        
    @Override
    public void next() {
    }
        
    @Override
    public void previous() {
    }
        
    @Override
    public void freeze() {
        log.info("save pos:" + getPosition() + "  size:" + radius.getValue());
        addProbe();
    }
 
    protected void snapToProbeInfo( ProbeInfo probe ) {
        Vec3d major = probe.pos.floor().toVec3d();
        Vec3d minor = probe.pos.subtract(major);
        majorPos.setObject(major);
        minorPos.setObject(minor);
        radius.setValue(probe.radius);
        opacity.setValue(probe.opacity);
    }

    protected void snapToPosition( Vec3d pos ) {
        Vec3d major = pos.floor().toVec3d();
        Vec3d minor = pos.subtract(major);
        majorPos.setObject(major);
        minorPos.setObject(minor);
    }
 
    protected void removeProbe() {
        ProbeInfo probe = probeList.getSelectedItem();
        probes.remove(probe);
    }
    
    protected void addProbe() {
        ProbeInfo probe = new ProbeInfo(getPosition(), radius.getValue(), opacity.getValue());
        probes.add(probe);
    }
    
    protected void randomProbe() {
        double x = Math.random() * 5;
        double y = Math.random() * 5;
        double z = Math.random() * 5;
        snapToPosition(new Vec3d(x, y, z));
    }
    
    public static class ProbeInfo {
        public Vec3d pos;
        public double radius;
        public double opacity;
        
        public ProbeInfo( Vec3d pos, double radius, double opacity ) {
            this.pos = pos.clone();
            this.radius = radius;
            this.opacity = opacity;
        }
 
        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            ProbeInfo other = (ProbeInfo)o;
            if( other.radius != radius ) {
                return false;
            }
            if( other.opacity != opacity ) {
                return false;
            }
            if( !Objects.equals(other.pos, pos) ) {
                return false;
            }
            return true;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(pos, radius, opacity);
        }
        
        @Override
        public String toString() {
            return String.format("%s r:%.2f o:%.2f", pos, radius, opacity);
        }
    }
}
