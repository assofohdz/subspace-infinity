/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class VerticalCylinderFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(VerticalCylinderFactory.class);

    public VerticalCylinderFactory() {
        super("Vert. Cylinder", "vcyl",
                new Parameter<Double>("Top Radius", Double.class, 0.5, 0.0, 1.0),
                new Parameter<Double>("Bottom Radius", Double.class, 0.5, 0.0, 1.0)
            );
    }

    public VerticalCylinderFactory( String name, String shape, double topRadius, double bottomRadius ) {
        super(name, shape,
              new Parameter<Double>("Top Radius", Double.class, topRadius, 0.0, 1.0),
              new Parameter<Double>("Bottom Radius", Double.class, bottomRadius, 0.0, 1.0)
            );
    }

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        // For the end caps
        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        // For the sides
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mtEnds = config1.getMaterialType();
        MaterialType mtSides = config2.getMaterialType();

        PartFactory[] dirTemplates = new PartFactory[6];
        //List<GeomPart> internalParts = new ArrayList<>();

        float yTop = 1;
        float yBottom = 0;
        //float radius = 0.5f;
        float topRadius = (float)(double)(Double)parameterValues[0];
        float bottomRadius = (float)(double)(Double)parameterValues[1];
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;

        // How often the texture repeats around the sides
        float tex = 4.0f / sideCount;

        // The texture coordinates are a little odd in that they cover the
        // full square and squash it in the angles.
        // The index 0 will be used for the center texture coordinate
        // So one for the center and 8 for the sides.
        float[][] topTex = new float[9][2];
        topTex[0][0] = 0.5f;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;    // right
        topTex[1][1] = 0.5f;
        topTex[2][0] = 1;    // upper right
        topTex[2][1] = 1;
        topTex[3][0] = 0.5f; // upper
        topTex[3][1] = 1;
        topTex[4][0] = 0;    // upper left
        topTex[4][1] = 1;
        topTex[5][0] = 0;    // left
        topTex[5][1] = 0.5f;
        topTex[6][0] = 0;    // lower left
        topTex[6][1] = 0;
        topTex[7][0] = 0.5f; // lower
        topTex[7][1] = 0;
        topTex[8][0] = 1;    // lower right
        topTex[8][1] = 0;

        float cosNormal = 1;
        float sinNormal = bottomRadius - topRadius;
        float temp = FastMath.sqrt(sinNormal * sinNormal + cosNormal * cosNormal);
        sinNormal /= temp;
        cosNormal /= temp;

        GeomPart top;
        Vector3f[] topCoords;
        if( topRadius == 0 ) {
            top = null;
            topCoords = null;
        } else {
            top = new GeomPart(mtEnds, Direction.Up.ordinal(), true);
            // End caps will have side count vertexes and a center point.
            // We'll build the triangles from those.
            top.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            topCoords = new Vector3f[9];
        }
        GeomPart bottom;
        Vector3f[] bottomCoords;
        if( bottomRadius == 0 ) {
            bottom = null;
            bottomCoords = null;
        } else {
            bottom = new GeomPart(mtEnds, Direction.Down.ordinal(), true);
            bottom.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            bottomCoords = new Vector3f[9];
        }

        BoundaryShape topShape = top == null ? null : BoundaryShapes.getCircle(0.5, 0.5, topRadius);
        BoundaryShape bottomShape = bottom == null ? null : BoundaryShapes.getCircle(0.5, 0.5, bottomRadius);

        // The side coordinates will need to wrap around and overlap
        // so that texture coordinates will wrap properly.
        Vector3f[] sideCoords = new Vector3f[9 * 2];
        Vector3f[] sideNormals = new Vector3f[9 * 2];
        Vector3f[] sideTangents = new Vector3f[9 * 2];
        Vector2f[] sideTexCoords = new Vector2f[9 * 2];

        if( topCoords != null ) {
            topCoords[0] = new Vector3f(0.5f, yTop, 0.5f);
        }
        if( bottomCoords != null ) {
            bottomCoords[0] = new Vector3f(0.5f, yBottom, 0.5f);
        }
        for( int i = 0; i < sideCount; i++ ) {
            // Note: -z goes 'up' in the sense of our textures
            float x = FastMath.cos(i * delta);
            float z = -FastMath.sin(i * delta);
            if( topCoords != null ) {
                topCoords[i+1] = new Vector3f(0.5f + x * topRadius, yTop, 0.5f + z * topRadius);
            }
            if( bottomCoords != null ) {
                bottomCoords[i+1] = new Vector3f(0.5f + x * bottomRadius, yBottom, 0.5f + z * bottomRadius);
            }

            Vector3f norm = new Vector3f(x * cosNormal, sinNormal, z * cosNormal).normalizeLocal();
            Vector3f tan = norm.cross(Vector3f.UNIT_Y);
            sideCoords[i * 2] = new Vector3f(0.5f + x * topRadius, yTop, 0.5f + z * topRadius);
            sideNormals[i * 2] = norm;
            sideTangents[i * 2] = tan;
            sideTexCoords[i * 2] = new Vector2f(i * tex, 1);
            sideCoords[i * 2 + 1] = new Vector3f(0.5f + x * bottomRadius, yBottom, 0.5f + z * bottomRadius);
            sideNormals[i * 2 + 1] = norm;
            sideTangents[i * 2 + 1] = tan;
            sideTexCoords[i * 2 + 1] = new Vector2f(i * tex, 0);
        }
        // and the overlap
        sideCoords[sideCount * 2] = sideCoords[0];
        sideCoords[sideCount * 2 + 1] = sideCoords[1];
        sideNormals[sideCount * 2] = sideNormals[0];
        sideNormals[sideCount * 2 + 1] = sideNormals[1];
        sideTangents[sideCount * 2] = sideTangents[0];
        sideTangents[sideCount * 2 + 1] = sideTangents[1];
        sideTexCoords[sideCount * 2] = new Vector2f(sideCount * tex, 1);
        sideTexCoords[sideCount * 2 + 1] = new Vector2f(sideCount * tex, 0);

        if( top != null ) {
            top.setCoords(FloatUtils.toFloatArray(topCoords));
            top.setIndexes(
                0, 1, 2,
                0, 2, 3,
                0, 3, 4,
                0, 4, 5,
                0, 5, 6,
                0, 6, 7,
                0, 7, 8,
                0, 8, 1
                );
        }
        if( bottom != null ) {
            bottom.setCoords(FloatUtils.toFloatArray(bottomCoords));
            bottom.setIndexes(
                0, 2, 1,
                0, 3, 2,
                0, 4, 3,
                0, 5, 4,
                0, 6, 5,
                0, 7, 6,
                0, 8, 7,
                0, 1, 8
                );
        }

        GeomPart sides = new GeomPart(mtSides);
        sides.setCoords(FloatUtils.toFloatArray(sideCoords));
        sides.setNormals(FloatUtils.toFloatArray(sideNormals));
        sides.setTangents(FloatUtils.toFloatArray(sideTangents));
        sides.setTexCoords(FloatUtils.toFloatArray(sideTexCoords));

        int[] sideIndexes = new int[sideCount * 2 * 3]; // 2 triangles per side
        int baseIndex = 0;
        int sideIndex = 0;
        for( int i = 0; i < sideCount; i++ ) {
            // We built the vertex array as top, bottom, top, bottom
            // First triangle b, bNext, tNext, b, tNext, t
            // 0 2
            // 1 3
            // 1, 3, 2
            // 1, 2, 0
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 3;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 0;

            baseIndex += 2;
        }
        sides.setIndexes(sideIndexes);

        DefaultPartFactory internalFactory = DefaultPartFactory.create(sides);

        // Have to wrap the GeomParts after we make them else the DefaultPartFactory
        // will get NPEs and stuff.
        if( top != null ) {
            dirTemplates[top.getDirectionIndex()] = DefaultPartFactory.create(topShape, top);
        }
        if( bottom != null ) {
            dirTemplates[bottom.getDirectionIndex()] = DefaultPartFactory.create(bottomShape, bottom);
        }

        //GeomPart[] partArray = null;
        //if( !internalParts.isEmpty() ) {
        //    partArray = internalParts.toArray(new GeomPart[0]);
        //    internalFactory = DefaultPartFactory.create(partArray);
        //}
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);

        // Future-Paul, sorry for hard-coding this ColliderType string here.
        return new BlockType(name, bf, new ColliderType("vcyl", 0));

    }
}

/*

    template( "vcylinder" ) {

        // For now
        collider( CubeCollider.UNIT );

        float radius = 0.5f;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;
        float tex = 4f / sideCount;

        float[][] topTex = new float[9][2];
        topTex[0][0] = 1;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;
        topTex[1][1] = 1;
        topTex[2][0] = 0.5f;
        topTex[2][1] = 1;
        topTex[3][0] = 0;
        topTex[3][1] = 1;
        topTex[4][0] = 0;
        topTex[4][1] = 0.5f;
        topTex[5][0] = 0;
        topTex[5][1] = 0;
        topTex[6][0] = 0.5f;
        topTex[6][1] = 0;
        topTex[7][0] = 1;
        topTex[7][1] = 0;
        topTex[8][0] = 1;
        topTex[8][1] = 0.5f;


        up( BoundaryShapes.getCircle( 0.5f, 0.5f, 0.5f ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 1 ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 1 ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                    vertex( 0.5f, 0.5f, 1 ){
                        texture( 0.5, 0.5 );
                    }
                }
            }
        }

        down( BoundaryShapes.getCircle( 0.5f, 0.5f, 0.5f ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 0 ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 0 ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                    vertex( 0.5f, 0.5f, 0 ){
                        texture( 0.5, 0.5 );
                    }
                }
            }
        }

        internal {

            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );


                quad {
                    material("core:dirt");

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 0 ) {
                        texture( modLow(i * tex), 0 )
                        normal( x1, y1, 0 )
                        tangent( y1, -x1, 0 )
                    }

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 0 ) {
                        texture( modHigh((i+1) * tex), 0 )
                        normal( x2, y2, 0 )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 1 ) {
                        texture( modHigh((i+1) * tex), 1 )
                        normal( x2, y2, 0 )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 1 ) {
                        texture( modLow(i * tex), 1 )
                        normal( x1, y1, 0 )
                        tangent( y1, -x1, 0 )
                    }
                }
            }
        }
    }

    template( "vcylinder.25" ) {
        fromTemplate( "vcylinder" )
        scale( 0.5, 0.5, 1 )

        // For now
        collider( new CubeCollider( new Vector3f(0.25f, 0.25f, 0), new Vector3f(0.75f, 0.75f, 1) ) )
    }

    template( "free-cylinder" ) {

        collider( CubeCollider.UNIT );
        float radius = 0.5f;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;
        float textureScale = 0.5f;
        float tex = 4f / sideCount;

        float[][] topTex = new float[9][2];
        topTex[0][0] = 1;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;
        topTex[1][1] = 1;
        topTex[2][0] = 0.5f;
        topTex[2][1] = 1;
        topTex[3][0] = 0;
        topTex[3][1] = 1;
        topTex[4][0] = 0;
        topTex[4][1] = 0.5f;
        topTex[5][0] = 0;
        topTex[5][1] = 0;
        topTex[6][0] = 0.5f;
        topTex[6][1] = 0;
        topTex[7][0] = 1;
        topTex[7][1] = 0;
        topTex[8][0] = 1;
        topTex[8][1] = 0.5f;


        internal {

            // Top
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:bark-top" )

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 1 ){
                        texture( topTex[i][0], topTex[i][1] );
                        normal( 0, 0, 1 );
                        tangent( 1, 0, 0 )
                    }
                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 1 ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                        normal( 0, 0, 1 );
                        tangent( 1, 0, 0 )
                    }
                    vertex( 0.5f, 0.5f, 1 ){
                        texture( 0.5, 0.5 );
                        normal( 0, 0, 1 );
                        tangent( 1, 0, 0 )
                    }
                }
            }

            // Bottom
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:bark-top" )

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 0 ){
                        texture( topTex[i][0], topTex[i][1] );
                        normal( 0, 0, -1 );
                        tangent( -1, 0, 0 )
                    }
                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 0 ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                        normal( 0, 0, -1 );
                        tangent( -1, 0, 0 )
                    }
                    vertex( 0.5f, 0.5f, 0 ){
                        texture( 0.5, 0.5 );
                        normal( 0, 0, -1 );
                        tangent( -1, 0, 0 )
                    }
                }
            }

            // Sides
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );


                quad {
                    material("core:bark");

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 0 ) {
                        texture( modLow(i * tex), 0 )
                        normal( x1, y1, 0 )
                        tangent( y1, -x1, 0 )
                    }

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 0 ) {
                        texture( modHigh((i+1) * tex), 0 )
                        normal( x2, y2, 0 )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x2 * radius, 0.5f + y2 * radius, 1 ) {
                        texture( modHigh((i+1) * tex), 1 )
                        normal( x2, y2, 0 )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x1 * radius, 0.5f + y1 * radius, 1 ) {
                        texture( modLow(i * tex), 1 )
                        normal( x1, y1, 0 )
                        tangent( y1, -x1, 0 )
                    }
                }
            }
        }
    }

    template( "free-cylinder.25" ) {
        fromTemplate( "free-cylinder" )
        scale( 0.5, 0.5, 1 )
        collider( new CubeCollider( new Vector3f(0.25f, 0.25f, 0), new Vector3f(0.75f, 0.75f, 1) ) )
    }

    template( "branch45.25" ) {
        fromTemplate( "free-cylinder" )
        scale( 0.5, 0.5, sqrt(2) )

        internal {
            // Scale the texture only for the sides with full bark
            polys( "core:bark" ) {
                scaleTexture( 0.5, 1 )
            }
        }

        rotate( new Quaternion().fromAngles( -FastMath.QUARTER_PI, 0, 0 ) )
        translate( 0, 0.25, 0 )

        // For now
        collider( CubeCollider.UNIT );
    }

    template( "cone-up" ) {

        // For now
        collider( CubeCollider.UNIT );

        float topRadius = 0f;
        float bottomRadius = 0.5f
        float top = 1.2;
        float bottom = 0;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;
        float tex = 4f / sideCount;

        float[][] topTex = new float[9][2];
        topTex[0][0] = 1;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;
        topTex[1][1] = 1;
        topTex[2][0] = 0.5f;
        topTex[2][1] = 1;
        topTex[3][0] = 0;
        topTex[3][1] = 1;
        topTex[4][0] = 0;
        topTex[4][1] = 0.5f;
        topTex[5][0] = 0;
        topTex[5][1] = 0;
        topTex[6][0] = 0.5f;
        topTex[6][1] = 0;
        topTex[7][0] = 1;
        topTex[7][1] = 0;
        topTex[8][0] = 1;
        topTex[8][1] = 0.5f;

        float sinNormal = 1;
        float cosNormal = bottomRadius - topRadius;
        float temp = sqrt(sinNormal * sinNormal + cosNormal * cosNormal);
        sinNormal /= temp;
        cosNormal /= temp;

        down( BoundaryShapes.getCircle( 0.5f, 0.5f, bottomRadius ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x2 * bottomRadius, 0.5f + y2 * bottomRadius, bottom ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f + x1 * bottomRadius, 0.5f + y1 * bottomRadius, bottom ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                    vertex( 0.5f, 0.5f, bottom ){
                        texture( 0.5, 0.5 );
                    }
                }
            }
        }

        internal {

            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );


                quad {
                    material("core:dirt");

                    vertex( 0.5f + x1 * bottomRadius, 0.5f + y1 * bottomRadius, bottom ) {
                        texture( modLow(i * tex), 0 )
                        normal( x1 * cosNormal, y1 * cosNormal, sinNormal )
                        tangent( y1, -x1, 0 )
                    }

                    vertex( 0.5f + x2 * bottomRadius, 0.5f + y2 * bottomRadius, bottom ) {
                        texture( modHigh((i+1) * tex), 0 )
                        normal( x2 * cosNormal, y2 * cosNormal, sinNormal )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x2 * topRadius, 0.5f + y2 * topRadius, top ) {
                        texture( modHigh((i+1) * tex), 1 )
                        normal( x2 * cosNormal, y2 * cosNormal, sinNormal )
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x1 * topRadius, 0.5f + y1 * topRadius, top ) {
                        texture( modLow(i * tex), 1 )
                        normal( x1 * cosNormal, y1 * cosNormal, sinNormal )
                        tangent( y1, -x1, 0 )
                    }
                }
            }
        }
    }

    template( "cone-dn" ) {

        // For now
        collider( CubeCollider.UNIT );

        float topRadius = 0.5f;
        float bottomRadius = 0f
        float top = 1;
        float bottom = -0.2f;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;
        float tex = 4f / sideCount;

        float[][] topTex = new float[9][2];
        topTex[0][0] = 1;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;
        topTex[1][1] = 1;
        topTex[2][0] = 0.5f;
        topTex[2][1] = 1;
        topTex[3][0] = 0;
        topTex[3][1] = 1;
        topTex[4][0] = 0;
        topTex[4][1] = 0.5f;
        topTex[5][0] = 0;
        topTex[5][1] = 0;
        topTex[6][0] = 0.5f;
        topTex[6][1] = 0;
        topTex[7][0] = 1;
        topTex[7][1] = 0;
        topTex[8][0] = 1;
        topTex[8][1] = 0.5f;

        float sinNormal = 1;
        float cosNormal = topRadius - bottomRadius;
        float temp = sqrt(sinNormal * sinNormal + cosNormal * cosNormal);
        sinNormal /= temp;
        cosNormal /= temp;

        up( BoundaryShapes.getCircle( 0.5f, 0.5f, topRadius ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x1 * topRadius, 0.5f + y1 * topRadius, top ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f + x2 * topRadius, 0.5f + y2 * topRadius, top ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                    vertex( 0.5f, 0.5f, top ){
                        texture( 0.5, 0.5 );
                    }
                }
            }
        }

        internal {

            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );


                quad {
                    material("core:dirt");

                    vertex( 0.5f + x1 * bottomRadius, 0.5f + y1 * bottomRadius, bottom ) {
                        texture( modLow(i * tex), 1 )
                        normal( x1 * cosNormal, y1 * cosNormal, -sinNormal ).normalizeLocal()
                        tangent( y1, -x1, 0 )
                    }

                    vertex( 0.5f + x2 * bottomRadius, 0.5f + y2 * bottomRadius, bottom ) {
                        texture( modHigh((i+1) * tex), 1 )
                        normal( x2 * cosNormal, y2 * cosNormal, -sinNormal ).normalizeLocal()
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x2 * topRadius, 0.5f + y2 * topRadius, top ) {
                        texture( modHigh((i+1) * tex), 0 )
                        normal( x2 * cosNormal, y2 * cosNormal, -sinNormal ).normalizeLocal()
                        tangent( y2, -x2, 0 )
                    }

                    vertex( 0.5f + x1 * topRadius, 0.5f + y1 * topRadius, top ) {
                        texture( modLow(i * tex), 0 )
                        normal( x1 * cosNormal, y1 * cosNormal, -sinNormal ).normalizeLocal()
                        tangent( y1, -x1, 0 )
                    }
                }
            }
        }
    }

    template( "cone-up.25" ) {
        fromTemplate( "cone-up" )
        scale( 0.5, 0.5, 0, 0.5, 0.5, 0.917 )

        // for now
        collider( new CubeCollider( new Vector3f(0.25f, 0.25f, 0), new Vector3f(0.75f, 0.75f, 1) ) )
    }
    template( "cone-dn.25" ) {
        fromTemplate( "cone-dn" )
        scale( 0.5, 0.5, 1, 0.5, 0.5, 0.917 )

        // for now
        collider( new CubeCollider( new Vector3f(0.25f, 0.25f, 0), new Vector3f(0.75f, 0.75f, 1) ) )
    }

    template( "hcylinder-ns" ) {

        // For now
        collider( CubeCollider.UNIT );

        // Up and down, not transparent at all
        // side to side, just barely.  The proper value
        // would be 1 - PI * r^2
        transparencyAxes(0.2, 0.2, 0);

        float radius = 0.5f;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;
        float tex = 4f / sideCount;

        float[][] topTex = new float[9][2];
        topTex[0][0] = 1;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;
        topTex[1][1] = 1;
        topTex[2][0] = 0.5f;
        topTex[2][1] = 1;
        topTex[3][0] = 0;
        topTex[3][1] = 1;
        topTex[4][0] = 0;
        topTex[4][1] = 0.5f;
        topTex[5][0] = 0;
        topTex[5][1] = 0;
        topTex[6][0] = 0.5f;
        topTex[6][1] = 0;
        topTex[7][0] = 1;
        topTex[7][1] = 0;
        topTex[8][0] = 1;
        topTex[8][1] = 0.5f;


        south( BoundaryShapes.getCircle( 0.5f, 0.5f, 0.5f ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x1 * radius, 1, 0.5f + y1 * radius ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f, 1, 0.5f ){
                        texture( 0.5, 0.5 );
                    }
                    vertex( 0.5f + x2 * radius, 1, 0.5f + y2 * radius ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                }
            }
        }

        north( BoundaryShapes.getCircle( 0.5f, 0.5f, 0.5f ) )  {
            indexedNormals(true);
            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );

                triangle {
                    material( "core:dirt" )

                    vertex( 0.5f + x2 * radius, 0, 0.5f + y2 * radius ){
                        texture( topTex[i][0], topTex[i][1] );
                    }
                    vertex( 0.5f, 0, 0.5f ){
                        texture( 0.5, 0.5 );
                    }
                    vertex( 0.5f + x1 * radius, 0, 0.5f + y1 * radius ){
                        texture( topTex[i+1][0], topTex[i+1][1] );
                    }
                }
            }
        }

        internal {

            for( int i = 0; i < sideCount; i++ ) {

                // Note: since y is flipped we need
                // to unflip the sins.
                float x1 = cos( i * delta );
                float y1 = -sin( i * delta );
                float x2 = cos( (i+1) * delta );
                float y2 = -sin( (i+1) * delta );


                quad {
                    material("core:dirt");

                    vertex( 0.5f + x2 * radius, 0, 0.5f + y2 * radius ) {
                        texture( modHigh((i+1) * tex), 0 )
                        normal( x2, 0, y2 )
                        tangent( y2, 0, -x2 )
                    }

                    vertex( 0.5f + x1 * radius, 0, 0.5f + y1 * radius ) {
                        texture( modLow(i * tex), 0 )
                        normal( x1, 0, y1 )
                        tangent( y1, 0, -x1 )
                    }

                    vertex( 0.5f + x1 * radius, 1, 0.5f + y1 * radius ) {
                        texture( modLow(i * tex), 1 )
                        normal( x1, 0, y1 )
                        tangent( y1, 0, -x1 )
                    }

                    vertex( 0.5f + x2 * radius, 1, 0.5f + y2 * radius ) {
                        texture( modHigh((i+1) * tex), 1 )
                        normal( x2, 0, y2 )
                        tangent( y2, 0, -x2 )
                    }
                }
            }
        }
    }

    template( "hcylinder-ns.25" ) {
        fromTemplate( "hcylinder-ns" )
        scale( 0.5, 1, 0.5 )

        internal {
            scaleTexture( 0.5, 1 )
        }

        // for now
        collider( new CubeCollider( new Vector3f(0.25f, 0f, 0.25f), new Vector3f(0.75f, 1, 0.75f) ) )
    }
*/
