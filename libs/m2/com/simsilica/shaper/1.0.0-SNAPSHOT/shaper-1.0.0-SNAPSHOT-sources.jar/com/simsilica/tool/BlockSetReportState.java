/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.*;

import com.simsilica.mblock.*;

/**
 *  Can generate a report on the current block set that calculates
 *  certain statistics and may therefore warn about certain issues like missing
 *  colliders, etc..
 *
 *  @author    Paul Speed
 */
public class BlockSetReportState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BlockSetReportState.class);

    private Container main;
    private ListBox<String> report;

    public BlockSetReportState() {        
    }
 
    public void regenerate() {
        log.info("Regenerating block set report");
        
        BlockSet blocks = getState(BlockSetMenuState.class).getBlockSet();
 
        // Initially let's just count the number of different 
        // collider types, etc..
        Counter<String> colliders = new Counter<>();
        for( BlockType type : blocks.getTypes() ) {
            if( type == null ) {
                continue;
            }
            ColliderType ct = type.getColliderType();
            String name;
            if( ct == null ) {
                name = "** null **";
            } else {
                name = ct.toDisplay();
            }
             
            colliders.add(name);
        }
 
        report.getModel().clear();
 
        log.info("Block set report:");
        for( Map.Entry<String, Integer> e : colliders.counts.entrySet() ) {
            report.getModel().add(String.valueOf(e));
            log.info(String.valueOf(e));
        }       

    }
    
    @Override    
    protected void initialize( Application app ) {
        this.main = new Container();
        getState(BlockSetMenuState.class).getTabs().addTab("Reports", main);    
    
        main.addChild(new ActionButton(new CallMethodAction(this, "regenerate")));
        
        report = main.addChild(new ListBox<String>());
        report.setVisibleItems(15);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    private class Counter<T extends Comparable> {
        private Map<T, Integer> counts = new TreeMap<>();
        
        public void add( T type ) {
            Integer val = counts.get(type);
            if( val == null ) {
                counts.put(type, 1);
            } else {
                counts.put(type, val + 1);
            }
        } 
    }
}
