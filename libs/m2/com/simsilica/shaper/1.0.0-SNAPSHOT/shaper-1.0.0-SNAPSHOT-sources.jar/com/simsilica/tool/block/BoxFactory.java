/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector2f;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BoxFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(BoxFactory.class);
    
    public BoxFactory() {
        super("Box", "box",
                new Parameter<Vec3d>("Min", Vec3d.class, new Vec3d(0, 0, 0)),
                new Parameter<Vec3d>("Max", Vec3d.class, new Vec3d(1, 1, 1)),
                new Parameter<Boolean>("Scale UV", Boolean.class, true)
             );
    } 
 
    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {
        MaterialConfig config = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialType mt = config.getMaterialType();
 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();
            
        Vec3d min = (Vec3d)parameterValues[0];
        Vec3d max = (Vec3d)parameterValues[1];
        Boolean scaleTexCoords = (Boolean)parameterValues[2];
 
        int count = 0;
        for( Direction dir : Direction.values() ) {            
            GeomPart part = GeomPart.createQuad(min, max, mt, dir, scaleTexCoords);
 
            //if( !scaleTexCoords ) {               
            //    // Calculate projected texture coordinates
            //    Vector2f low = BoundaryShapes.unprojectDir(min, dir);
            //    Vector2f high = BoundaryShapes.unprojectDir(max, dir);
            //
            //    part.setTexCoords(new float[] {
            //            low.x, low.y,
            //            high.x, low.y,
            //            high.x, high.y,
            //            low.x, high.y
            //        });
            //}
                
            BoundaryShape shape = BoundaryShapes.getBoxSide(min, max, dir);
            if( shape == null ) {
                internalParts.add(part);
            } else {
                dirTemplates[dir.ordinal()] = DefaultPartFactory.create(shape, part);
                count++;
            }                 
        }
        if( count == 0 ) {
            dirTemplates = null;
        }
 
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
        return new BlockType(name, bf); 
    }    
}

