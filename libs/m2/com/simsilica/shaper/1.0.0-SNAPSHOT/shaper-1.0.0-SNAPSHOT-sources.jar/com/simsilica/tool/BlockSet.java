/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import com.simsilica.lemur.core.VersionedList;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.DefaultBlockSet;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BlockSet {

    private VersionedList<BlockType> types = new VersionedList<>();
    private String materialSetPath;
    private int badTypeIndex;

    public BlockSet() {
    }

    public BlockSet( BlockType... types ) {
        this.types.addAll(Arrays.asList(types));
    }

    public static BlockSet createDefault() {
        BlockType[] types = DefaultBlockSet.createBlockTypes();
        BlockSet result = new BlockSet(types);
        return result;
    }

    public void setMaterialSetPath( String materialSetPath ) {
        this.materialSetPath = materialSetPath;
    }

    public String getMaterialSetPath() {
        return materialSetPath;
    }

    public void setBadTypeIndex( int badTypeIndex ) {
        this.badTypeIndex = badTypeIndex;
    }

    public int getBadTypeIndex() {
        return badTypeIndex;
    }

    public BlockType get( BlockName name ) {
        for( BlockType type : types ) {
            if( type == null ) {
                continue;
            }
            if( Objects.equals(type.getName(), name) ) {
                return type;
            }
        }
        return null;
    }

    public void insert( int index, BlockType type ) {
        types.add(index, type);
    }

    public boolean add( BlockType type ) {
        return types.add(type);
    }

    public boolean remove( BlockType type ) {
        return types.remove(type);
    }

    public BlockType replace( BlockType existing, BlockType newType ) {
        int index = types.indexOf(existing);
        return types.set(index, newType);
    }

    public VersionedList<BlockType> getTypes() {
        return types;
    }
}
