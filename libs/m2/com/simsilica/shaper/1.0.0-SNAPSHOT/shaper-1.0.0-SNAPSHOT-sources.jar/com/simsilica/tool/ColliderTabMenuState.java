/*
 * $Id$
 *
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.input.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.io.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mblock.phys.collision.*;
import com.simsilica.mworld.World;
import com.simsilica.tool.collider.*;


/**
 *  A mode for testing colliders.
 *
 *  @author    Paul Speed
 */
public class ColliderTabMenuState extends BaseAppState {
    static Logger log = LoggerFactory.getLogger(ColliderTabMenuState.class);

    private Node simRoot;
    private BlockSet blockSet;
    private Collider[] colliders;
    private MBlockCollisionSystem<String> collisionSystem;

    private int cellArraySize = 5;
    //private CellArray cells = new CellArray(cellArraySize);
    private CellSelectorGrid selectors;
    private VersionedReference<Vec3i> selectedCellRef;
    private SmallWorld world = new SmallWorld(1);
    private CellData cells = world;

    private Container colliderPanel;
    private VersionedReference<TabbedPanel.Tab> tabRef;
    private boolean open = false;
    private boolean savedShapeBoundaryEnabled;
    private boolean invalid;

    private Checkbox showSelectors;
    private VersionedReference<Boolean> showSelectorsRef;

    private ColliderConfigEditor colliderEditor;
    private VersionedReference<Integer> cellValueRef;

    private InputObserver inputObserver = new InputObserver();
    private VersionedList<Simulation> simulations = new VersionedList<>();
    private Selector<Simulation> simulationSelector;
    private VersionedReference<Simulation> simulationSelectorRef;
    private RollupPanel simPanel;
    private Simulation currentSim;

    public ColliderTabMenuState() {
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    @Override
    protected void initialize( Application app ) {

        this.blockSet = getState(BlockSetMenuState.class).getBlockSet();

        loadBlocks();

        colliderPanel = new Container();

        showSelectors = colliderPanel.addChild(new Checkbox("Show cell selectors"));
        showSelectorsRef = showSelectors.getModel().createReference();

        Container sub = colliderPanel.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        sub.addChild(new ActionButton(new CallMethodAction("Clear", this, "clearBlocks")));
        sub.addChild(new ActionButton(new CallMethodAction("Reset Masks", this, "resetMasks")));

        this.colliderEditor = colliderPanel.addChild(new ColliderConfigEditor(blockSet));
        this.cellValueRef = colliderEditor.createCellValueRef();

        this.selectors = new CellSelectorGrid(cellArraySize);
        this.selectedCellRef = selectors.createSelectedCellRef();
        float move = cellArraySize * 0.5f;
        selectors.move(-move, -0.5f, -move);

        this.simRoot = new Node("simRoot");
        simRoot.move(-move, -0.5f, -move);

        // Automatically select the center cell
        selectors.setSelectedCell(2, 1, 2);

        // Just for testing
        //int val = MaskUtils.setSideMask(1, 0x3f);
        //cells.setCell(1, 0, 1, val);
        //cells.setCell(2, 1, 2, val);
        //cells.setCell(3, 2, 3, val);

        // Setup the simulations
        simulations.add(new RaySimulation(app.getCamera(), app.getInputManager()));
        simulations.add(new SpheresSimulation());
        simulations.add(new ProbeSimulation());

        Container properties = colliderPanel.addChild(new Container());
        properties.addChild(new Label("Simulation:"));
        simulationSelector = properties.addChild(
                new Selector<Simulation>(simulations, (sim) -> sim.getName()),
                1);
        simulationSelectorRef = simulationSelector.createSelectedItemReference();


        simPanel = colliderPanel.addChild(new RollupPanel("Simulation Settings", null));

        getState(BlockSetMenuState.class).getTabs().addTab("Colliders", colliderPanel);
        tabRef = getState(BlockSetMenuState.class).getTabs().getSelectionModel().createReference();

        InputMapper mapper = GuiGlobals.getInstance().getInputMapper();
        SimulationFunctions.initializeDefaultMappings(mapper);
        mapper.addStateListener(inputObserver,
                            SimulationFunctions.F_FREEZE,
                            SimulationFunctions.F_NEXT,
                            SimulationFunctions.F_PREVIOUS
                            );
    }

    @Override
    protected void cleanup( Application app ) {
        log.info("cleanup()");
        setOpen(false);
        InputMapper mapper = GuiGlobals.getInstance().getInputMapper();
        mapper.removeStateListener(inputObserver,
                            SimulationFunctions.F_FREEZE,
                            SimulationFunctions.F_NEXT,
                            SimulationFunctions.F_PREVIOUS
                            );
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void update( float tpf ) {
        if( tabRef.update() ) {
            Panel selected = tabRef.get() == null ? null : tabRef.get().getContents();
            boolean nowOpen = selected == colliderPanel;
            setOpen(nowOpen);
        }
        if( showSelectorsRef.update() ) {
            selectors.setEnabled(showSelectorsRef.get());
        }
        if( selectedCellRef.update() ) {
            resetColliderEditor();
        }
        if( cellValueRef.update() ) {
            Vec3i cell = selectedCellRef.get();
            Integer val = cellValueRef.get();
            log.info("selected value:" + val);
            if( val == null ) {
                val = 0;
            }
            cells.setCell(cell.x, cell.y, cell.z, val);
            invalid = true;
        }
        if( simulationSelectorRef.update() ) {
            setCurrentSimulation(simulationSelectorRef.get());
        }
        if( invalid ) {
            invalid = false;
            if( open ) {
                getState(BlockTypeState.class).setCells(cells);
            }
        }

        if( currentSim != null && open ) {
            currentSim.update(tpf);
        }
    }

    protected void setOpen( boolean open ) {
        if( this.open == open ) {
            return;
        }
        if( this.open ) {
            onTabClosed();
        }
        this.open = open;
        if( this.open ) {
            onTabOpened();
        }
    }

    public void resetMasks() {
        MaskUtils.calculateSideMasks(cells, 5);
        resetColliderEditor();
    }

    public void clearBlocks() {
        for( int i = 0; i < cellArraySize; i++ ) {
            for( int j = 0; j < cellArraySize; j++ ) {
                for( int k = 0; k < cellArraySize; k++ ) {
                    cells.setCell(i, j, k, 0);
                }
            }
        }
        getState(BlockTypeState.class).setCells(cells);
        resetColliderEditor();
    }

    protected void resetColliderEditor() {
        Vec3i cell = selectedCellRef.get();
        log.info("Selected cell:" + cell);
        if( cell == null ) {
            colliderEditor.setCellValue(null);
        } else {
            int val = cells.getCell(cell.x, cell.y, cell.z);
            colliderEditor.setCellValue(val);
        }
    }

    protected void onTabOpened() {
        savedShapeBoundaryEnabled = getState(DebugBoundaryShapesState.class).isEnabled();
        getState(DebugBoundaryShapesState.class).setEnabled(false);

        if( cells.getCell(2, 1, 2) == 0 ) {
            // Make it whatever is currently on the main display for continuity
            int current = getState(BlockTypeState.class).getCell(2, 1, 2);
            cells.setCell(2, 1, 2, current);

            MaskUtils.recalculateSideMasks(cells, 2, 1, 2, 0);

            current = cells.getCell(2, 1, 2);
            colliderEditor.setCellValue(current);
        }

        getState(BlockTypeState.class).setCells(cells);
        getRoot().attachChild(selectors);
        getRoot().attachChild(simRoot);

        GuiGlobals.getInstance().getInputMapper().activateGroup(SimulationFunctions.IN_SIM);

        BlockType[] types = blockSet.getTypes().toArray(new BlockType[0]);
        this.colliders = new ColliderFactories(true).createColliders(types);
        this.collisionSystem = new MBlockCollisionSystem<>(world, colliders);

        setCurrentSimulation(simulationSelector.getSelectedItem());
        if( currentSim != null ) {
            currentSim.setCollisionSystem(collisionSystem);
        }
    }

    protected void onTabClosed() {
        setCurrentSimulation(null);

        getState(DebugBoundaryShapesState.class).setEnabled(savedShapeBoundaryEnabled);
        getState(BlockTypeState.class).setCells(null);
        selectors.removeFromParent();
        simRoot.removeFromParent();
        GuiGlobals.getInstance().getInputMapper().deactivateGroup(SimulationFunctions.IN_SIM);

        saveBlocks();
    }

    protected void saveBlocks() {
        CellArray array = new CellArray(cellArraySize);
        for( int i = 0; i < cellArraySize; i++ ) {
            for( int j = 0; j < cellArraySize; j++ ) {
                for( int k = 0; k < cellArraySize; k++ ) {
                    int val = cells.getCell(i, j, k);
                    array.setCell(i, j, k, val);
                }
            }
        }

        File f = new File(ShaperConfig.getInstance().getProjectDir(), "collider.blocks");
        try {
            BlockObject bo = new BlockObject(array, new CellArray(cellArraySize));
            BlocksFileFormat.writeBlocks(bo, f);
        } catch( IOException e ) {
            log.error("Error saving file:" + f, e);
        }
    }

    protected void loadBlocks() {
        File f = new File(ShaperConfig.getInstance().getProjectDir(), "collider.blocks");
        try {
            BlockObject bo = BlocksFileFormat.readBlocks(f, false);

            for( int i = 0; i < cellArraySize; i++ ) {
                for( int j = 0; j < cellArraySize; j++ ) {
                    for( int k = 0; k < cellArraySize; k++ ) {
                        int val = bo.cells.getCell(i, j, k);
                        cells.setCell(i, j, k, val);
                    }
                }
            }
        } catch( IOException e ) {
            log.error("Error saving file:" + f, e);
        }
    }

    protected void setCurrentSimulation( Simulation currentSim ) {
        if( this.currentSim == currentSim ) {
            return;
        }
        if( this.currentSim != null ) {
            this.currentSim.release();
            simPanel.setContents(null);
        }
        this.currentSim = currentSim;
        if( this.currentSim != null ) {
            Panel editor = this.currentSim.attach(simRoot);
            simPanel.setContents(editor);
            currentSim.setCollisionSystem(collisionSystem);
        }
    }

    private class InputObserver implements StateFunctionListener {
        public void valueChanged( FunctionId func, InputState value, double tpf ) {
            if( currentSim != null && value == InputState.Off ) {
                if( func == SimulationFunctions.F_FREEZE ) {
                    currentSim.freeze();
                } else if( func == SimulationFunctions.F_NEXT ) {
                    currentSim.next();
                } else if( func == SimulationFunctions.F_PREVIOUS ) {
                    currentSim.previous();
                }
            }
        }
    }
}
