/*
 * $Id$
 *
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.*;
import com.simsilica.mworld.tile.tree.*;

/**
 *  A small static world with fixed number of leaf data.  Used
 *  by the simulations to have an MBlockCollisionSystem.  Really only
 *  supplies the getLeaf() method.
 *
 *  @author    Paul Speed
 */
public class SmallWorld implements World, CellData {
    static Logger log = LoggerFactory.getLogger(SmallWorld.class);

    private int size;
    private LeafData[][][] data;

    public SmallWorld( int size ) {
        this.size = size;
        this.data = new LeafData[size][size][size];

        for( int i = 0; i < size; i++ ) {
            for( int j = 0; j < size; j++ ) {
                for( int k = 0; k < size; k++ ) {
                    LeafId id = LeafId.fromWorld(i * 32, j * 32, k * 32);
                    data[i][j][k] = new LeafData(id, 0);
                }
            }
        }
    }

    public final int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    public final int getCell( int x, int y, int z, int defaultValue ) {
        int i = x / 32;
        if( i < 0 || i >= size ) {
            return defaultValue;
        }
        int j = y / 32;
        if( j < 0 || j >= size ) {
            return defaultValue;
        }
        int k = z / 32;
        if( k < 0 || k >= size ) {
            return defaultValue;
        }
        LeafData leaf = data[i][j][k];
        return leaf.getCell(x % 32, y % 32, z % 32, defaultValue);
    }

    public final int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    public final void setCell( int x, int y, int z, int type ) {
        int i = x / 32;
        if( i < 0 || i >= size ) {
            return;
        }
        int j = y / 32;
        if( j < 0 || j >= size ) {
            return;
        }
        int k = z / 32;
        if( k < 0 || k >= size ) {
            return;
        }
        LeafData leaf = data[i][j][k];
        leaf.setCell(x % 32, y % 32, z % 32, type);
    }

    public int setWorldCell( Vec3d world, int cellType ) {
        Vec3i loc = world.floor();
        int existing = getCell(loc.x, loc.y, loc.z);
        setCell(loc.x, loc.y, loc.z, cellType);
        return existing;
    }

    public int getWorldCell( Vec3d world ) {
        Vec3i loc = world.floor();
        return getCell(loc.x, loc.y, loc.z, -1);
    }

    public int getMaxY() {
        return size * 32 - 1;
    }

    public LeafData getWorldLeaf( Vec3d worldLocation ) {
        Vec3i loc = worldLocation.floor();
        return getLeaf(loc.x, loc.y, loc.z);
    }

    public LeafData getLeaf( LeafId leafId ) {
        Vec3i loc = leafId.getWorld(null);
        return getLeaf(loc.x, loc.y, loc.z);
    }

    protected LeafData getLeaf( int x, int y, int z ) {
        int i = x / 32;
        if( i < 0 || i >= size ) {
            return null;
        }
        int j = y / 32;
        if( j < 0 || j >= size ) {
            return null;
        }
        int k = z / 32;
        if( k < 0 || k >= size ) {
            return null;
        }
        LeafData leaf = data[i][j][k];
        return leaf;
    }

    public LightData getLight( LeafId leafId ) {
        throw new UnsupportedOperationException();
    }

    public FluidData getFluid( LeafId leafId ) {
        throw new UnsupportedOperationException();
    }

    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res ) {
        throw new UnsupportedOperationException();
    }

    public TreeLayer getTrees( TileId id, Resolution res ) {
        throw new UnsupportedOperationException();
    }

    public PointCloudLayer getPointCloudLayer( TileId id, Resolution res ) {
        throw new UnsupportedOperationException();
    }

    public void addTileListener( TileListener l ) {
        throw new UnsupportedOperationException();
    }

    public void removeTileListener( TileListener l ) {
        throw new UnsupportedOperationException();
    }

    public void addLeafChangeListener( LeafChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public void removeLeafChangeListener( LeafChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public void addCellChangeListener( CellChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public void removeCellChangeListener( CellChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public void addColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public void removeColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }
}
