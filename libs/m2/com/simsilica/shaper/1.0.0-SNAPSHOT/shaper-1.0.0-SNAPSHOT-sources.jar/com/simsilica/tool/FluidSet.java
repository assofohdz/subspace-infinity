/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import com.simsilica.lemur.core.VersionedList;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.DefaultBlockSet;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidSet {
    
    private VersionedList<FluidType> types = new VersionedList<>();
    private String materialSetPath;
    
    public FluidSet() {
    }
    
    public FluidSet( FluidType... types ) {
        this.types.addAll(Arrays.asList(types));
    }

    public static FluidSet createDefault() {
        FluidType[] types = DefaultBlockSet.createFluidTypes();
        FluidSet result = new FluidSet(types);        
        return result;
    }
 
    public void setMaterialSetPath( String materialSetPath ) {
        this.materialSetPath = materialSetPath;
    }
    
    public String getMaterialSetPath() {
        return materialSetPath;
    }
 
    public FluidType get( FluidName name ) {
        for( FluidType type : types ) {
            if( type == null ) {
                continue;
            }
            if( Objects.equals(type.getName(), name) ) {
                return type;
            }
        }
        return null;
    }
 
    public void insert( int index, FluidType type ) {
        types.add(index, type);
    }
    
    public boolean add( FluidType type ) {
        return types.add(type);
    }
 
    public boolean remove( FluidType type ) {
        return types.remove(type);
    }
    
    public FluidType replace( FluidType existing, FluidType newType ) {
        int index = types.indexOf(existing);
        return types.set(index, newType);
    }
 
    public VersionedList<FluidType> getTypes() {
        return types;
    }    
}
