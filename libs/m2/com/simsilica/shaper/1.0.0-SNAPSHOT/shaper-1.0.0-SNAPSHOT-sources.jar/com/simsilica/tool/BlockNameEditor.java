/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.DocumentModel;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BlockNameEditor extends Container {

    static Logger log = LoggerFactory.getLogger(BlockNameEditor.class);

    private VersionedHolder<BlockName> holder = new VersionedHolder<>(); 
    private TextField baseField;
    private TextField shapeField;
    private Selector<Integer>  rotationSelector;

    private VersionedReference<DocumentModel> baseRef;
    private VersionedReference<DocumentModel> shapeRef;
    private VersionedReference<Integer> rotationRef;

    public BlockNameEditor() {
        addChild(new Label("Base:"));
        addChild(new Label("Shape:"), 1);
        addChild(new Label("Rot.:"), 2);        
        baseField = addChild(new TextField(""));
        shapeField = addChild(new TextField(""), 1);
        shapeField.setInsets(new Insets3f(0, 2, 0, 3));
        
        VersionedList<Integer> rotations = new VersionedList<Integer>(Arrays.asList(null, 0, 1, 2, 3)); 
        rotationSelector = addChild(new Selector<Integer>(rotations), 2);
        
        baseRef = baseField.getDocumentModel().createReference();                 
        shapeRef = shapeField.getDocumentModel().createReference();
        rotationRef = rotationSelector.createSelectedItemReference();
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
 
        if( baseRef.update() || shapeRef.update() || rotationRef.update() ) {
            updateName();
        }
    }
    
    public void setBlockName( BlockName name ) {
        if( Objects.equals(name, holder.getObject()) ) {
            return;
        }
        holder.setObject(name);
        refreshFields();
    }
    
    public BlockName getBlockName() {
        return holder.getObject();
    }
    
    public VersionedReference<BlockName> createBlockNameReference() {
        return holder.createReference();
    }
    
    protected void updateName() {
        BlockName bn = new BlockName(baseField.getText(), shapeField.getText(), rotationRef.get());            
        log.info("Updating block name:" + bn);
        holder.setObject(bn);
    }
    
    protected void refreshFields() {
        BlockName name = holder.getObject();
        if( name == null ) {
            baseField.setText("");
            shapeField.setText("");
            rotationSelector.setSelectedItem(0);
        } else {
            baseField.setText(name.getBase());
            shapeField.setText(name.getShape());
            rotationSelector.setSelectedItem(name.getRotation());
        }
    }
}


