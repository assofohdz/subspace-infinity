/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.collider;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;

/**
 *  A 3D grid of cell selector widgets. 
 *
 *  @author    Paul Speed
 */
public class CellSelectorGrid extends Node {
    static Logger log = LoggerFactory.getLogger(CellSelectorGrid.class);

    private static final ColorRGBA DEFAULT_OFF = new ColorRGBA(0, 1, 1, 0.25f);   
    private static final ColorRGBA DEFAULT_HOVER = new ColorRGBA(1, 1, 0, 0.25f);
    private static final ColorRGBA DEFAULT_SELECTED = new ColorRGBA(1, 1, 1, 0.75f);
 
    private int gridSize;
    private CellArray cells;
    private CellSelector[] selectors;
    private VersionedHolder<Vec3i> selectedCell = new VersionedHolder<>();
    private boolean enabled;
    
    private ColorRGBA offColor = DEFAULT_OFF;
    private ColorRGBA hoverColor = DEFAULT_HOVER;
    private ColorRGBA selectedColor = DEFAULT_SELECTED; 
     
    public CellSelectorGrid( int gridSize ) {
        super("CellSelectorGrid:" + gridSize);
        this.gridSize = gridSize;
        this.cells = new CellArray(gridSize);
        this.selectors = new CellSelector[gridSize * gridSize * gridSize];
 
        int index = 0;              
        for( int i = 0; i < gridSize; i++ ) {
            for( int j = 0; j < gridSize; j++ ) {
                for( int k = 0; k < gridSize; k++ ) {                    
                    selectors[index] = new CellSelector(new Vec3i(i, j, k), 0);
                    attachChild(selectors[index]);
                    index++;
                }
            }
        }
        
        updateEnabled();
    }
    
    public void setEnabled( boolean enabled ) {
        if( this.enabled == enabled ) {
            return;
        }
        this.enabled = enabled;
        updateEnabled();
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    protected void updateEnabled() {
        if( enabled ) {
            setCullHint(CullHint.Inherit);
        } else {
            setCullHint(CullHint.Always);
        }
    }
    
    public VersionedReference<Vec3i> createSelectedCellRef() {
        return selectedCell.createReference();
    }   
 
    public void setSelectedCell( int x, int y, int z ) {
        setSelectedCell(new Vec3i(x, y, z));
    }
 
    public void setSelectedCell( Vec3i cell ) {
        if( !selectedCell.updateObject(cell) ) {
            // Nothing changed
            return;
        }        
        // Reset selection
        for( CellSelector selector : selectors ) {
            selector.setSelected(Objects.equals(cell, selector.cell));
        }
    }
    
    public Vec3i getSelectedCell() {
        return selectedCell.getObject();
    }
    
    private class CellSelector extends Node 
                               implements CursorListener {
        private Vec3i cell;
        private ColorRGBA boxColor = new ColorRGBA(0, 0, 1, 0.1f);
        private ColorRGBA wireColor = new ColorRGBA(0, 1, 1, 0.25f);
        
        private boolean hovered = false;
        private boolean selected = false;
        
        public CellSelector( Vec3i cell, int blockType ) {
            this.cell = cell;
            setLocalTranslation(cell.toVector3f().addLocal(0.5f, 0.5f, 0.5f));
            
            Mesh mesh = new Box(0.1f, 0.1f, 0.1f);
            Geometry geom = new Geometry(cell.toString(), mesh);
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(boxColor, true).getMaterial());
            geom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
            geom.setQueueBucket(Bucket.Transparent);
            attachChild(geom);
 
            mesh = new WireBox(0.1f, 0.1f, 0.1f);
            geom = new Geometry(cell.toString(), mesh);
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(wireColor, false).getMaterial());
            geom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
            geom.getMaterial().getAdditionalRenderState().setDepthTest(false);
            geom.setQueueBucket(Bucket.Translucent);
            attachChild(geom);
            
            CursorEventControl.addListenersToSpatial(this, this);
        }
 
        public void setSelected( boolean selected ) {
            if( this.selected == selected ) {
                return;
            }
            this.selected = selected;
            resetColor();
        }

        public boolean isSelected() {
            return selected;
        }
        
        protected void resetColor() {
            ColorRGBA color = offColor;
            if( selected ) {
                color = selectedColor;
            } else if( hovered ) {
                color = hoverColor;
            }
            
            wireColor.set(color);
            boxColor.set(color.mult(0.25f));
        }
        
        public void cursorButtonEvent( CursorButtonEvent event, Spatial target, Spatial capture ) {
            if( target != capture ) {
                return;
            }
            if( event.isPressed() ) {
                return;
            }
            if( event.getButtonIndex() == 0 ) {
                setSelectedCell(cell);
            } 
        }
         
        public void cursorEntered( CursorMotionEvent event, Spatial target, Spatial capture ) {
            hovered = true;
            resetColor();
        }
         
        public void cursorExited( CursorMotionEvent event, Spatial target, Spatial capture ) {
            hovered = false;
            resetColor();
        }
         
        public void cursorMoved( CursorMotionEvent event, Spatial target, Spatial capture ) {
        }         
    }
}
