/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.DocumentModel;
import com.simsilica.lemur.value.*;
import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SubstanceArrayEditor extends Container {
    static Logger log = LoggerFactory.getLogger(SubstanceArrayEditor.class);

    private BlockType blockType;
    private Substance[] substanceArray;
    private VersionedList<Substance> substances = new VersionedList<>();
    private SubstanceEditor[] editors;
    private Container table;
    private Container buttons;

    public SubstanceArrayEditor() {
        table = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.Proportional)));

        buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.ForcedEven, FillMode.None)));
        buttons.addChild(new ActionButton(new CallMethodAction("Add", this, "addRow")));
        buttons.addChild(new ActionButton(new CallMethodAction("Normalize", this, "normalizeAmounts")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeRows")));
    }

    public VersionedReference<List<Substance>> createSubstanceArrayRef() {
        return substances.createReference();
    }

    public void setBlockType( BlockType blockType ) {
        if( this.blockType == blockType ) {
            return;
        }
        this.blockType = blockType;
        this.substanceArray = blockType != null ? blockType.getSubstances() : null;
        resetView();
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( editors != null ) {
            for( SubstanceEditor editor : editors ) {
                editor.update();
            }
        }
    }

    protected void resetView() {
        table.clearChildren();
        substances.clear();
        if( substanceArray == null ) {
            return;
        }
        table.addChild(new Label("Select"));
        table.addChild(new Label("Name"), 1);
        table.addChild(new Label("Amount"), 2);
        substances.addAll(Arrays.asList(substanceArray));
        editors = new SubstanceEditor[substanceArray.length];
        for( int i = 0; i < substanceArray.length; i++ ) {
            editors[i] = new SubstanceEditor(i, substanceArray[i]);
            table.addChild(editors[i].selected);
            table.addChild(editors[i].name, 1);
            table.addChild(editors[i].amount, 2);
        }
    }

    protected void resetFields() {
        for( SubstanceEditor editor : editors ) {
            editor.resetFields();
        }
    }

    protected void resetArray() {
        this.substanceArray = substances.toArray(new Substance[0]);
        blockType.setSubstances(substanceArray);
        resetView();
    }

    protected void addRow() {
        Substance toAdd = new Substance(new SubstanceName("new"), 1.0);
        substances.add(toAdd);
        resetArray();
    }

    protected void normalizeAmounts() {
        double total = 0;
        for( Substance substance : substances ) {
            total += substance.getAmount();
        }
        if( total == 0 ) {
            return;
        }
        double volume = blockType.getFactory().getVolume();
        for( Substance substance : substances ) {
            substance.setAmount(volume * substance.getAmount()/total);
        }
        resetFields();
    }

    protected void removeRows() {
        for( int i = 0; i < editors.length; i++ ) {
            if( editors[i].selected.isChecked() ) {
                substances.remove(editors[i].substance.getObject());
            }
        }
        resetArray();
    }

    protected class SubstanceEditor {
        private VersionedHolder<Substance> substance;
        private Checkbox selected;
        private Label indexLabel;
        private TextField name;
        private VersionedReference<DocumentModel> nameRef;
        private Spinner<Double> amount;
        private SequenceModel<Double> amountModel;
        private VersionedReference<Double> amountRef;

        public SubstanceEditor( int index, Substance substance ) {
            this.selected = new Checkbox("");
            this.substance = new VersionedHolder<>(substance);
            indexLabel = new Label("[" + index + "]");
            name = new TextField(substance.getName().getName());
            // Preferred width just has to be big enough to give more proportional
            // sizing compared to the checkboxes and the spinner.
            name.setPreferredWidth(100);
            nameRef = name.getDocumentModel().createReference();

            amountModel
                = SequenceModels.rangedSequence(
                        new DefaultRangedValueModel(0, 1, substance.getAmount()),
                        0.01, 0.01);
            amountRef = amountModel.createReference();

            DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
            amount = new Spinner<>(amountModel, renderer);
            amount.setValueEditor(ValueEditors.doubleEditor("%.2f"));
        }

        public void resetFields() {
            name.setText(substance.getObject().getName().getName());
            amountModel.setObject(substance.getObject().getAmount());
        }

        public void update() {
            if( nameRef.update() ) {
                substance.getObject().setName(new SubstanceName(name.getText()));
            }
            if( amountRef.update() ) {
                substance.getObject().setAmount(amountModel.getObject());
            }
        }
    }
}
