/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.lang.reflect.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.DefaultValueRenderer;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class LiquidFactoryEditor extends Container implements FluidFactoryEditor {

    static Logger log = LoggerFactory.getLogger(LiquidFactoryEditor.class);

    private FluidSet fluidSet;
    private LiquidFactory liquidFactory;
    private long version;
    private MaterialSet materialSet;

    private Selector<MaterialConfig> topSelector;
    private VersionedReference<MaterialConfig> topRef;
    private Selector<MaterialConfig> sideSelector;
    private VersionedReference<MaterialConfig> sideRef;

    private static BackdoorAccess backdoorAccess = new BackdoorAccess();

    public LiquidFactoryEditor() {

        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        properties.setBackground(null);

        VersionedList<MaterialConfig> materials = new VersionedList<>();

        DefaultPartFactoryEditor.MaterialConfigToString fString = new DefaultPartFactoryEditor.MaterialConfigToString();

        properties.addChild(new Label("Top:"));
        topSelector = properties.addChild(new Selector<MaterialConfig>(materials, fString), 1);
        topRef = topSelector.createSelectedItemReference();

        properties.addChild(new Label("Sides:"));
        sideSelector = properties.addChild(new Selector<MaterialConfig>(materials, fString), 1);
        sideRef = sideSelector.createSelectedItemReference();
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public FluidFactory getObject() {
        return liquidFactory;
    }

    @Override
    public VersionedReference<FluidFactory> createReference() {
        return new VersionedReference<>(this);
    }

    @Override
    public void setFluidSet( FluidSet fluidSet ) {
        this.fluidSet = fluidSet;
    }

    @Override
    public void setMaterialSet( MaterialSet materialSet ) {
        this.materialSet = materialSet;
        VersionedList<MaterialConfig> materials = getMaterials();
        topSelector.setModel(materials);
        sideSelector.setModel(materials);
    }

    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        boolean changed = false;
        if( topRef.update() && liquidFactory != null ) {
            backdoorAccess.setTop(liquidFactory, topRef.get().getMaterialType());
            changed = true;
        }
        if( sideRef.update() && liquidFactory != null ) {
            backdoorAccess.setSide(liquidFactory, sideRef.get().getMaterialType());
            changed = true;
        }
        if( changed ) {
            version++;
        }
    }

    @Override
    public void setFluidFactory( FluidFactory factory ) {
log.info("setFluidFactory(" + factory + ")");
        if( this.liquidFactory == factory ) {
            return;
        }
        this.liquidFactory = (LiquidFactory)factory;
        if( liquidFactory != null ) {
            MaterialConfig config;
            config = materialSet.get(liquidFactory.getTopMaterialType());
log.info("materialType:" + liquidFactory.getTopMaterialType() + "  found:" + config);
            topSelector.setSelectedItem(config);
            config = materialSet.get(liquidFactory.getSideMaterialType());
log.info("materialType:" + liquidFactory.getSideMaterialType() + "  found:" + config);
            sideSelector.setSelectedItem(config);
        }
    }

    @Override
    public FluidFactory getFluidFactory() {
        return liquidFactory;
    }

    @Override
    public Panel getEditor() {
        return this;
    }

    protected VersionedList<MaterialConfig> getMaterials() {
        EnumSet<GeomReq> reqs = EnumSet.of(GeomReq.IndexedNormals);
        reqs = GeomReq.expandImplied(reqs);

        VersionedList<MaterialConfig> result = new VersionedList<>();

        MaterialRegistry registry = materialSet.getRegistry();
        for( String name : registry.getNames() ) {
log.info("  checking:" + name);
            MaterialConfig best = registry.findBest(name, reqs);
log.info("    best:" + best);
            if( best != null ) {
                result.add(best);
            }
        }

        return result;
    }

    private static class BackdoorAccess {
        private Field topField;
        private Field sideField;

        public BackdoorAccess() {
            try {
                topField = LiquidFactory.class.getDeclaredField("topType");
                topField.setAccessible(true);

                sideField = LiquidFactory.class.getDeclaredField("sideType");
                sideField.setAccessible(true);
            } catch( Exception e ) {
                throw new RuntimeException("Error looking up material type fields", e);
            }
        }

        public void setTop( LiquidFactory factory, MaterialType top ) {
            try {
                topField.set(factory, top);
            } catch( Exception e ) {
                throw new RuntimeException("Error performing backdoor access", e);
            }
        }

        public void setSide( LiquidFactory factory, MaterialType side ) {
            try {
                sideField.set(factory, side);
            } catch( Exception e ) {
                throw new RuntimeException("Error performing backdoor access", e);
            }
        }
    }
}

