/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.DocumentModel;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidNameEditor extends Container {

    static Logger log = LoggerFactory.getLogger(FluidNameEditor.class);

    private VersionedHolder<FluidName> holder = new VersionedHolder<>(); 
    private TextField baseField;

    private VersionedReference<DocumentModel> baseRef;

    public FluidNameEditor() {
        super(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last));
        addChild(new Label("Name:"));
        baseField = addChild(new TextField(""), 1);        
        baseRef = baseField.getDocumentModel().createReference();                 
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
 
        if( baseRef.update() ) {
            updateName();
        }
    }
    
    public void setFluidName( FluidName name ) {
        if( Objects.equals(name, holder.getObject()) ) {
            return;
        }
        holder.setObject(name);
        refreshFields();
    }
    
    public FluidName getFluidName() {
        return holder.getObject();
    }
    
    public VersionedReference<FluidName> createFluidNameReference() {
        return holder.createReference();
    }
    
    protected void updateName() {
        FluidName bn = new FluidName(baseField.getText());
        log.info("Updating fluid name:" + bn);
        holder.setObject(bn);
    }
    
    protected void refreshFields() {
        FluidName name = holder.getObject();
        if( name == null ) {
            baseField.setText("");
        } else {
            baseField.setText(name.getBase());
        }
    }
}


