/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.io;

import java.io.*;

import com.simsilica.tool.gson.GsonResolveTypeAdapter;
import com.simsilica.tool.gson.PolyTypeAdapterFactory;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.*;

import com.simsilica.mblock.geom.*;

import com.simsilica.tool.FluidSet;


/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidSetJson {

    private static FluidSetJson instance = new FluidSetJson();
  
    private Gson gson;
 
    public FluidSetJson() {
        initializeGson();
    }
    
    protected void initializeGson() {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        
        gsonBuilder.registerTypeAdapterFactory(PolyTypeAdapterFactory.create(FluidFactory.class));
        gsonBuilder.registerTypeAdapterFactory(new GsonResolveTypeAdapter<MaterialType>(MaterialType.class) {
                    protected MaterialType resolve( MaterialType mt ) {
                        if( mt == null ) {
                            return null;
                        }
                        return mt.internalize();
                    }        
                });

        this.gson = gsonBuilder.create();
    }
    
    public String toJson( FluidSet fluidSet ) {
        return gson.toJson(fluidSet);
    }
    
    public FluidSet fromJson( String json ) {
        return gson.fromJson(json, FluidSet.class);
    }  

    public static FluidSet load( File f ) {
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return instance.fromJson(json);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }

    public static void store( FluidSet materials, File f ) {
        try {
            String json = instance.toJson(materials);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }
}


