/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *  Version of a cylinder that can be rotated or shrunk smaller than a block
 *  because it does not have 'boundary shapes'.  All parts are 'internal' parts.
 *
 *  @author    Paul Speed
 */
public class FreeCylinderFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(FreeCylinderFactory.class);

    public FreeCylinderFactory() {
        super("Free Cylinder", "cyl",
                new Parameter<Double>("Top Radius", Double.class, 0.5, 0.0, 1.0),
                new Parameter<Double>("Top Offset", Double.class, 1.0, 0.0, 1.5),
                new Parameter<Double>("Bottom Radius", Double.class, 0.5, 0.0, 1.0),
                new Parameter<Double>("Bottom Offset", Double.class, 0.0, -0.5, 1.0),
                new Parameter<Double>("Pitch", Double.class, 0.0, 0.0, 360.0, 5.0),
                new Parameter<Double>("Yaw", Double.class, 0.0, 0.0, 360.0, 5.0),
                new Parameter<Vec3d>("Offset", Vec3d.class, new Vec3d(0, 0, 0))
            );
        // Note: one of the downsides of having so many parameters is that the
        // user cannot tweak them once the type is created.  A real custom BlockFactory
        // implementation would allow that but comes with its own challenges.
        // We'd have to create a custom UI for it, though it could probably reuse parts
        // of the existing DefaultBlockFactoryEditor.
    }

    protected Vector3f xformCoord( Quaternion rotation, Vector3f offset, Vector3f v ) {
        if( rotation == null ) {
            return v;
        }
        v = v.subtract(0.5f, 0.5f, 0.5f);
        return rotation.mult(v).addLocal(0.5f, 0.5f, 0.5f).addLocal(offset);
    }

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        // For the sides and top/bottom... because everything is unindexed here
        MaterialConfig config = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config.getMaterialType();

        PartFactory[] dirTemplates = new PartFactory[6];
        //List<GeomPart> internalParts = new ArrayList<>();

        float topRadius = (float)(double)(Double)parameterValues[0];
        float yTop = (float)(double)(Double)parameterValues[1];
        float bottomRadius = (float)(double)(Double)parameterValues[2];
        float yBottom = (float)(double)(Double)parameterValues[3];
        float pitch = (float)Math.toRadians((double)(Double)parameterValues[4]);
        float yaw = (float)Math.toRadians((double)(Double)parameterValues[5]);
        Vec3d offsetd = (Vec3d)parameterValues[6];
        Vector3f offset = offsetd.toVector3f();

        Quaternion rotation = new Quaternion().fromAngles(pitch, -yaw, 0);

        //float radius = 0.5f;
        int sideCount = 8;
        float delta = FastMath.TWO_PI / sideCount;

        // How often the texture repeats around the sides
        float tex = 4.0f / sideCount;

        // The texture coordinates are a little odd in that they cover the
        // full square and squash it in the angles.
        // The index 0 will be used for the center texture coordinate
        // So one for the center and 8 for the sides.
        float[][] topTex = new float[9][2];
        topTex[0][0] = 0.5f;
        topTex[0][1] = 0.5f;
        topTex[1][0] = 1;    // right
        topTex[1][1] = 0.5f;
        topTex[2][0] = 1;    // upper right
        topTex[2][1] = 1;
        topTex[3][0] = 0.5f; // upper
        topTex[3][1] = 1;
        topTex[4][0] = 0;    // upper left
        topTex[4][1] = 1;
        topTex[5][0] = 0;    // left
        topTex[5][1] = 0.5f;
        topTex[6][0] = 0;    // lower left
        topTex[6][1] = 0;
        topTex[7][0] = 0.5f; // lower
        topTex[7][1] = 0;
        topTex[8][0] = 1;    // lower right
        topTex[8][1] = 0;

        float cosNormal = 1;
        float sinNormal = bottomRadius - topRadius;
        float temp = FastMath.sqrt(sinNormal * sinNormal + cosNormal * cosNormal);
        sinNormal /= temp;
        cosNormal /= temp;

        GeomPart top;
        Vector3f[] topCoords;
        if( topRadius == 0 ) {
            top = null;
            topCoords = null;
        } else {
            top = new GeomPart(mt, -1, true);
            // End caps will have side count vertexes and a center point.
            // We'll build the triangles from those.
            top.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            top.setNormals(FloatUtils.toFloatArray(9, rotation.mult(Vector3f.UNIT_Y)));

            // Note: this is not really accurate but it's what the old code did
            top.setTangents(FloatUtils.toFloatArray(9, rotation.mult(Vector3f.UNIT_X)));

            topCoords = new Vector3f[9];
        }
        GeomPart bottom;
        Vector3f[] bottomCoords;
        if( bottomRadius == 0 ) {
            bottom = null;
            bottomCoords = null;
        } else {
            bottom = new GeomPart(mt, -1, true);
            bottom.setTexCoords(FloatUtils.toFloatArray(topTex, 2));
            bottomCoords = new Vector3f[9];

            bottom.setNormals(FloatUtils.toFloatArray(9, rotation.mult(Vector3f.UNIT_Y.negate())));

            // Note: this is not really accurate but it's what the old code did
            bottom.setTangents(FloatUtils.toFloatArray(9, rotation.mult(Vector3f.UNIT_X.negate())));
        }

        // The side coordinates will need to wrap around and overlap
        // so that texture coordinates will wrap properly.
        Vector3f[] sideCoords = new Vector3f[9 * 2];
        Vector3f[] sideNormals = new Vector3f[9 * 2];
        Vector3f[] sideTangents = new Vector3f[9 * 2];
        Vector2f[] sideTexCoords = new Vector2f[9 * 2];

        if( topCoords != null ) {
            topCoords[0] = xformCoord(rotation, offset, new Vector3f(0.5f, yTop, 0.5f));
        }
        if( bottomCoords != null ) {
            bottomCoords[0] = xformCoord(rotation, offset, new Vector3f(0.5f, yBottom, 0.5f));
        }
        for( int i = 0; i < sideCount; i++ ) {
            // Note: -z goes 'up' in the sense of our textures
            float x = FastMath.cos(i * delta);
            float z = -FastMath.sin(i * delta);
            if( topCoords != null ) {
                topCoords[i+1] = xformCoord(rotation, offset, new Vector3f(0.5f + x * topRadius, yTop, 0.5f + z * topRadius));
            }
            if( bottomCoords != null ) {
                bottomCoords[i+1] = xformCoord(rotation, offset, new Vector3f(0.5f + x * bottomRadius, yBottom, 0.5f + z * bottomRadius));
            }

            Vector3f norm = new Vector3f(x * cosNormal, sinNormal, z * cosNormal).normalizeLocal();
            Vector3f tan = norm.cross(Vector3f.UNIT_Y);
            norm = rotation.mult(norm);
            tan = rotation.mult(tan);
            sideCoords[i * 2] = xformCoord(rotation, offset, new Vector3f(0.5f + x * topRadius, yTop, 0.5f + z * topRadius));
            sideNormals[i * 2] = norm;
            sideTangents[i * 2] = tan;
            sideTexCoords[i * 2] = new Vector2f(i * tex, 1);
            sideCoords[i * 2 + 1] = xformCoord(rotation, offset, new Vector3f(0.5f + x * bottomRadius, yBottom, 0.5f + z * bottomRadius));
            sideNormals[i * 2 + 1] = norm;
            sideTangents[i * 2 + 1] = tan;
            sideTexCoords[i * 2 + 1] = new Vector2f(i * tex, 0);
        }
        // and the overlap
        sideCoords[sideCount * 2] = sideCoords[0];
        sideCoords[sideCount * 2 + 1] = sideCoords[1];
        sideNormals[sideCount * 2] = sideNormals[0];
        sideNormals[sideCount * 2 + 1] = sideNormals[1];
        sideTangents[sideCount * 2] = sideTangents[0];
        sideTangents[sideCount * 2 + 1] = sideTangents[1];
        sideTexCoords[sideCount * 2] = new Vector2f(sideCount * tex, 1);
        sideTexCoords[sideCount * 2 + 1] = new Vector2f(sideCount * tex, 0);

        if( top != null ) {
            top.setCoords(FloatUtils.toFloatArray(topCoords));
            top.setIndexes(
                0, 1, 2,
                0, 2, 3,
                0, 3, 4,
                0, 4, 5,
                0, 5, 6,
                0, 6, 7,
                0, 7, 8,
                0, 8, 1
                );
        }
        if( bottom != null ) {
            bottom.setCoords(FloatUtils.toFloatArray(bottomCoords));
            bottom.setIndexes(
                0, 2, 1,
                0, 3, 2,
                0, 4, 3,
                0, 5, 4,
                0, 6, 5,
                0, 7, 6,
                0, 8, 7,
                0, 1, 8
                );
        }

        GeomPart sides = new GeomPart(mt);
        sides.setCoords(FloatUtils.toFloatArray(sideCoords));
        sides.setNormals(FloatUtils.toFloatArray(sideNormals));
        sides.setTangents(FloatUtils.toFloatArray(sideTangents));
        sides.setTexCoords(FloatUtils.toFloatArray(sideTexCoords));

        int[] sideIndexes = new int[sideCount * 2 * 3]; // 2 triangles per side
        int baseIndex = 0;
        int sideIndex = 0;
        for( int i = 0; i < sideCount; i++ ) {
            // We built the vertex array as top, bottom, top, bottom
            // First triangle b, bNext, tNext, b, tNext, t
            // 0 2
            // 1 3
            // 1, 3, 2
            // 1, 2, 0
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 3;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 1;
            sideIndexes[sideIndex++] = baseIndex + 2;
            sideIndexes[sideIndex++] = baseIndex + 0;

            baseIndex += 2;
        }
        sides.setIndexes(sideIndexes);

        DefaultPartFactory internalFactory = DefaultPartFactory.create(top, bottom, sides);
        DefaultBlockFactory bf = DefaultBlockFactory.create(null, internalFactory);

        // Future-Paul, sorry for hard-coding this ColliderType string here.
        // Though note that there really is no good general collider in this case.
        return new BlockType(name, bf, new ColliderType("cube", 0));

    }
}

