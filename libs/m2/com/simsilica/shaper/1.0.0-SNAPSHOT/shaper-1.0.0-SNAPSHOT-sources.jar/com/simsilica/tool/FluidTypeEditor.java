/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;
import com.google.common.base.Strings;

import com.jme3.math.*;
import com.jme3.scene.Spatial;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidTypeEditor extends Container implements VersionedObject<FluidType> {

    static Logger log = LoggerFactory.getLogger(FluidTypeEditor.class);

    private long version;

    private FluidNameEditor nameEditor;
    private VersionedReference<FluidName> nameRef;

    private Button editColor;
    private QuadBackgroundComponent colorView;
    private Container lightEditor;
    private Checkbox emissionCheck;
    private ColorChooser lightColorChooser;
    private VersionedReference<Boolean> emissionRef;
    private VersionedReference<ColorRGBA> lightColorRef;
    private TextField lightValueField;
    private VersionedReference<DocumentModel> lightValueRef;

    private VersionedList<String> factoryTypes = new VersionedList<>(Arrays.asList("Liquid"));
    private Selector<String> factorySelector;

    private Map<String, Class> factoryClassNames = new HashMap<>();
    private Map<Class, FluidFactoryEditor> factoryEditors = new HashMap<>();
    private RollupPanel factoryEditorRollup;

    private FluidSet fluidSet;
    private MaterialSet materialSet;
    private FluidType fluidType;
    private FluidFactory fluidFactory;
    private VersionedReference<FluidFactory> fluidFactoryChanges;

    public FluidTypeEditor() {
        factoryEditors.put(LiquidFactory.class, new LiquidFactoryEditor());
        factoryClassNames.put("Default", LiquidFactory.class);

        nameEditor = addChild(new FluidNameEditor());
        nameRef = nameEditor.createFluidNameReference();

        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));

        properties.addChild(new Label("Emission:"));
        Container light = properties.addChild(new Container(), 1);

        DocumentModel hex = new DocumentModelFilter(
                    TextFilters.charFilter(
                        TextFilters.isInChars('0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                                              'a', 'b', 'c', 'd', 'e', 'f',
                                              'A', 'B', 'C', 'D', 'E', 'F')), null);
        lightValueField = light.addChild(new TextField(hex));
        lightValueRef = lightValueField.getDocumentModel().createReference();
        editColor = light.addChild(new Button(""), 1);
        editColor.setInsets(new Insets3f(0, 0, 0, 0));
        colorView = new QuadBackgroundComponent(ColorRGBA.Black);
        editColor.setIcon(colorView);
        editColor.addClickCommands(new ColorPopupCommand());

        lightEditor = new Container();
        lightEditor.setBackground(new QuadBackgroundComponent(ColorRGBA.Black));
        lightEditor.getControl(GuiControl.class).addListener(new KeepOnScreen());
        emissionCheck = lightEditor.addChild(new Checkbox("Emission Enabled:"));
        lightColorChooser = lightEditor.addChild(new ColorChooser());
        emissionRef = emissionCheck.getModel().createReference();
        lightColorRef = lightColorChooser.getModel().createReference();

        properties.addChild(new Label("Fluid Factory:"));
        factorySelector = properties.addChild(new Selector<>(factoryTypes), 1);

        factoryEditorRollup = addChild(new RollupPanel("Fluid Factory Editor", null));

        factoryEditorRollup.setContents(factoryEditors.get(LiquidFactory.class).getEditor());
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);

        if( fluidType == null ) {
            return;
        }

        if( nameRef.update() ) {
            fluidType.setName(nameRef.get());
            version++;
        }
        if( lightValueRef.update() ) {
            short color = parseLight(lightValueRef.get().getText());
            if( color > -1 ) {
                fluidType.setLight(color);
                emissionCheck.setChecked(color != 0);

                ColorRGBA lightColor = lightToColor(color);
                colorView.setColor(lightColor);

                version++;
            }
        }
        if( emissionRef.update() || lightColorRef.update() ) {
            short color = calculateLightColor();
            log.info("Changing:" + fluidType.getLight() + " to:" + color);
            fluidType.setLight(color);

            ColorRGBA lightColor = lightToColor(color);
            colorView.setColor(lightColor);

            lightValueField.setText(String.format("%03X", fluidType.getLight()));

            version++;
        }
        if( fluidFactoryChanges != null && fluidFactoryChanges.update() ) {
log.info("fluid factory changed.");
            fluidType.setFactory(fluidFactory);
            version++;
        }
    }

    protected short parseLight( String s ) {
        if( Strings.isNullOrEmpty(s) ) {
            return 0;
        }
        try {
            int i = Integer.parseInt(s, 16);
            return (short)i;
        } catch( Exception e ) {
            log.warn("Error parsing:" + s, e);
            return -1;
        }
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public FluidType getObject() {
        return fluidType;
    }

    @Override
    public VersionedReference<FluidType> createReference() {
        return new VersionedReference<>(this);
    }

    public void setFluidSet( FluidSet fluidSet ) {
        this.fluidSet = fluidSet;
        for( FluidFactoryEditor editor : factoryEditors.values() ) {
            editor.setFluidSet(fluidSet);
        }
    }

    public void setMaterialSet( MaterialSet materialSet ) {
        this.materialSet = materialSet;
        for( FluidFactoryEditor editor : factoryEditors.values() ) {
            editor.setMaterialSet(materialSet);
        }
    }

    public void setFluidType( FluidType fluidType ) {
        if( this.fluidType == fluidType ) {
            return;
        }
        this.fluidType = fluidType;
        updateFields();
    }

    protected void clearFields() {
        nameEditor.setFluidName(null);
        colorView.setColor(ColorRGBA.Black);
        lightValueField.setText("000");
        emissionCheck.setChecked(false);
        factorySelector.setSelectedItem("Default");
    }

    protected short calculateLightColor() {
        if( !emissionCheck.isChecked() ) {
            return 0;
        }
        ColorRGBA color = lightColorChooser.getColor();
        int r = (int)(color.r * 15);
        int g = (int)(color.g * 15);
        int b = (int)(color.b * 15);
        return (short)LightUtils.toLight(0, r, g, b);
    }

    protected ColorRGBA lightToColor( short light ) {
        float r = LightUtils.red(light) / 15f;
        float g = LightUtils.green(light) / 15f;
        float b = LightUtils.blue(light) / 15f;

        return new ColorRGBA(r,g,b,1);
    }

    protected void updateFields() {
        if( fluidType == null ) {
            clearFields();
            return;
        }

        nameEditor.setFluidName(fluidType.getName());

        ColorRGBA lightColor;
        if( fluidType.getLight() != 0 ) {
            lightColor = lightToColor(fluidType.getLight());
            emissionCheck.setChecked(true);
        } else {
            lightColor = ColorRGBA.Black;
            emissionCheck.setChecked(false);
        }
        colorView.setColor(lightColor);
        lightColorChooser.setColor(lightColor);
        lightValueField.setText(String.format("%03X", fluidType.getLight()));

        FluidFactory fluidFactory = fluidType.getFactory();
        setFluidFactory(fluidFactory);
    }

    protected void setFluidFactory( FluidFactory fluidFactory ) {
        if( this.fluidFactory == fluidFactory ) {
            return;
        }
        this.fluidFactory = fluidFactory;
        factoryEditorRollup.setContents(null);
        fluidFactoryChanges = null;
        if( fluidFactory == null ) {
            return;
        }
        FluidFactoryEditor factoryEditor = factoryEditors.get(fluidFactory.getClass());
        if( factoryEditor != null ) {
            factoryEditor.setFluidFactory(fluidFactory);
            factoryEditorRollup.setContents(factoryEditor.getEditor());
            fluidFactoryChanges = factoryEditor.createReference();
        }
    }

    private class ColorPopupCommand implements Command<Button> {
        public void execute( Button b ) {
            lightEditor.setLocalTranslation(b.getWorldTranslation());
            GuiGlobals.getInstance().getPopupState().clampToGui(lightEditor);
            GuiGlobals.getInstance().getPopupState().showPopup(lightEditor);
        }
    }

    private class KeepOnScreen extends AbstractGuiControlListener {

        @Override
        public void reshape( GuiControl source, Vector3f offset, Vector3f size ) {
            Spatial owner = source.getSpatial();
            if( owner == null ) {
                return;
            }
            GuiGlobals.getInstance().getPopupState().clampToGui(owner);
        }
    }
}
