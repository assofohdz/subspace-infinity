/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.block;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.geom.*;

import com.simsilica.tool.MaterialSet;

/**
 *
 *
 *  @author    Paul Speed
 */
public class HiWedgeCornerFactory extends AbstractBlockTypeFactory {
    static Logger log = LoggerFactory.getLogger(HiWedgeCornerFactory.class);

    public HiWedgeCornerFactory() {
        super("HiWedge Corner", "hi-wedge-corner",
              new Parameter<Boolean>("Skew Side UVs", Boolean.class, false),
              new Parameter<Boolean>("Mitre Corner UVs", Boolean.class, false)
            );
    } 

    @Override
    public BlockType create( MaterialSet materials, BlockName name, String materialName, Object... parameterValues ) {

        Boolean skew = (Boolean)parameterValues[0];
        Boolean mitre = (Boolean)parameterValues[1];

        MaterialConfig config1 = materials.findBest(materialName, GeomReq.IndexedNormals);
        MaterialConfig config2 = materials.findBest(materialName, GeomReq.Normals, GeomReq.Tangents);

        MaterialType mt = config1.getMaterialType();
            
        MaterialType mtInternal = config2.getMaterialType();

        // n,s,e,w,u,d 
        PartFactory[] dirTemplates = new PartFactory[6];
        List<GeomPart> internalParts = new ArrayList<>();

        Vector3f normal1 = new Vector3f(0.5f, 1, 0).normalizeLocal();
        Vector3f normal2 = new Vector3f(0, 1, 0.5f).normalizeLocal();

        BoundaryShape quad = BoundaryShapes.UNIT_SQUARE;
        BoundaryShape sides = BoundaryShapes.getTriangle(0, 0.5f, 1, 1, normal1.x, normal1.y); 
        BoundaryShape triangle = BoundaryShapes.getTriangle(0, 0, 1, 0.5f, normal1.x, normal1.y); 
 
        GeomPart down;
        if( mitre ) {
            // For a mitred base, we have to use unshared vertexes or
            // we won't be able to mitre the UVs
            // Note: I think for indexed normals that our tangents will
            // be wrong for half of the base... problem for another day.
            // Sorry, future-Paul.  -pspeed:2021-05-14
            down = new GeomPart(mt, Direction.Down.ordinal(), false);
            down.setCoords(
                    0, 0, 0,
                    1, 0, 1,
                    0, 0, 1,                    
                    0, 0, 0,
                    1, 0, 0,
                    1, 0, 1                    
                );
            down.setTexCoords(
                0, 0,
                1, 1,
                0, 1,
                0, 1,  // the mitre
                0, 0,
                1, 0
                );
            down.setIndexes(0, 1, 2, 3, 4, 5);
            down.setupAlternates(); // for indexed and non-indexed materials
        } else {
            down = GeomPart.createFace(mt, Direction.Down);
        } 
        dirTemplates[5] = DefaultPartFactory.create(quad, down);

        GeomPart north = new GeomPart(mt, Direction.North.ordinal(), false);
        //        2
        //  3
        //  
        //  0     1
        north.setCoords(
            1, 0, 0,
            0, 0, 0,
            0, 1, 0,
            1, 0.5f, 0
            );
        if( skew ) {
            north.setTexCoords(
                0, 0.5f,
                1, 0,
                1, 1,
                0, 1                
                );
        } else {
            north.setTexCoords(
                0, 0,
                1, 0,
                1, 1,
                0, 0.5f);
        }
        north.setIndexes(0, 1, 2, 0, 2, 3);
        north.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[0] = DefaultPartFactory.create(sides, north);

        GeomPart west = new GeomPart(mt, Direction.West.ordinal(), false);
        //  3     
        //        2
        //  
        //  0     1
        west.setCoords(
            0, 0, 0,
            0, 0, 1,
            0, 0.5f, 1,
            0, 1, 0
            );
        if( skew ) {
            west.setTexCoords(
                0, 0,
                1, 0.5f,
                1, 1,
                0, 1                
                );
        } else {
            west.setTexCoords(
                0, 0,
                1, 0,
                1, 0.5f,
                0, 1);
        }
        west.setIndexes(0, 1, 2, 0, 2, 3);
        west.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[3] = DefaultPartFactory.create(sides, west);
 
        // Now the two little south and east triangles
        GeomPart east = new GeomPart(mt, Direction.East.ordinal(), false);
        //        2 
        //  
        //  0     1
        east.setCoords(
            1, 0, 1,
            1, 0, 0,
            1, 0.5f, 0
            );
        if( skew ) {
            east.setTexCoords(
                0, 1,
                1, 0.5f,
                1, 1
                );
        } else {
            east.setTexCoords(
                0, 0,
                1, 0,
                1, 0.5f
                );
        }
        east.setIndexes(0, 1, 2);
        east.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[2] = DefaultPartFactory.create(triangle, east);
        
        GeomPart south = new GeomPart(mt, Direction.South.ordinal(), false);
        //  2      
        //  
        //  0     1
        south.setCoords(
            0, 0, 1,
            1, 0, 1,
            0, 0.5f, 1
            );
        if( skew ) {
            south.setTexCoords(
                0, 0.5f,
                1, 1,
                0, 1
                );
        } else {
            south.setTexCoords(
                0, 0,
                1, 0,
                0, 0.5f
                );
        }
        south.setIndexes(0, 1, 2);
        south.setupAlternates(); // for indexed and non-indexed materials
        dirTemplates[1] = DefaultPartFactory.create(triangle, south);
        
 
 
        // Now for the two slopes
        Vector3f dirEast = new Vector3f(1, -0.5f, 0).normalizeLocal();
        Vector3f dirSouth = new Vector3f(0, -0.5f, 1).normalizeLocal();
        Vector3f norm = dirSouth.cross(dirEast).normalizeLocal(); 
        Vector3f normSouth = norm;
        Vector3f tanSouth = new Vector3f(1, 0.5f, 0);
        Vector3f normEast = normSouth; //new Vector3f(1, 1, 1).normalizeLocal();
        Vector3f tanEast = tanSouth; //new Vector3f(1, 0, 0);
 
        // South first
        GeomPart slope;
        slope = new GeomPart(mtInternal, -1, false);            
        slope.setCoords(
            0, 0.5f, 1,
            1, 0, 1,
            0, 1, 0
            );
        slope.setTexCoords(
            0, 0,
            1, 0,
            0, 1
            );
        slope.setNormals(FloatUtils.toFloatArray(3, normSouth));
        slope.setTangents(FloatUtils.toFloatArray(3, tanSouth));
        slope.setIndexes(0, 1, 2);
        internalParts.add(slope);            

        // Now east
        slope = new GeomPart(mtInternal, -1, false);            
        slope.setCoords(
            1, 0, 1,
            1, 0.5f, 0,
            0, 1, 0
            );
        if( mitre ) {
            slope.setTexCoords(
                0, 0,
                1, 0,
                1, 1
                );
        } else {
            slope.setTexCoords(
                1, 0,
                1, 1,
                0, 1
                );
        }
        slope.setNormals(FloatUtils.toFloatArray(3, normSouth));
        slope.setTangents(FloatUtils.toFloatArray(3, tanSouth));
        slope.setIndexes(0, 1, 2);
        internalParts.add(slope);            
            
        GeomPart[] partArray = null;
        DefaultPartFactory internalFactory = null;
        if( !internalParts.isEmpty() ) {
            partArray = internalParts.toArray(new GeomPart[0]);
            internalFactory = DefaultPartFactory.create(partArray); 
        }                      
        DefaultBlockFactory bf = DefaultBlockFactory.create(dirTemplates, internalFactory);
 
        // Future-Paul, sorry for hard-coding this ColliderType string here.           
        return new BlockType(name, bf, new ColliderType("wedge-corner", 0));
    }
}



