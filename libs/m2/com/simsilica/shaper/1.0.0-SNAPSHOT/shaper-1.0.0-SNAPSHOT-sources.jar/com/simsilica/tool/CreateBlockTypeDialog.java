/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;

import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;

import com.simsilica.mathd.Vec3d;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.DefaultCellRenderer;
import com.simsilica.lemur.style.ElementId;
import com.simsilica.lemur.value.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.config.*;

import com.simsilica.tool.block.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CreateBlockTypeDialog extends Container {

    static Logger log = LoggerFactory.getLogger(CreateBlockTypeDialog.class);

    private OptionPanelState options;
    private BlockSet blocks;
    private MaterialSet materials;
    private BlockNameEditor nameEditor;

    private BlockType blockType;  // the one we create

    private VersionedList<BlockTypeFactory> factories;
    private Selector<BlockTypeFactory> factorySelector;
    private VersionedReference<BlockTypeFactory> factoryRef;

    private Selector<String> materialSelector;

    private BlockTypeFactory factory;
    private Container parameters;
    private VersionedReference[] references;

    public CreateBlockTypeDialog( OptionPanelState options, BlockSet blocks, MaterialSet materials, VersionedList<BlockTypeFactory> factories ) {
        super(new BorderLayout());

        this.options = options;
        this.blocks = blocks;
        this.materials = materials;
        this.factories = factories;

        addChild(new Label("Create Block", new ElementId("window.title"), null), BorderLayout.Position.North);

        Container contents = addChild(new Container(), BorderLayout.Position.Center);
        this.nameEditor = contents.addChild(new BlockNameEditor());

        Container properties = contents.addChild(new Container());

        properties.addChild(new Label("Template:"));
        factorySelector = properties.addChild(new Selector<BlockTypeFactory>(factories), 1);
        factoryRef = factorySelector.createSelectedItemReference();
        properties.addChild(new Label("Material:"));
        materialSelector = properties.addChild(new Selector<String>(materials.getMaterialNames(),
                                                                    new MaterialConfigToString()), 1);

        this.parameters = contents.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));

        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)), BorderLayout.Position.South);
        buttons.addChild(new ActionButton(new CallMethodAction(this, "create")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));

        Vector3f pref = getPreferredSize();
        pref.x = Math.max(pref.x, 300);
        setPreferredSize(pref);
    }

    public BlockType getBlockType() {
        return blockType;
    }

    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);

        if( factoryRef.update() ) {
            setFactory(factoryRef.get());
        }
    }

    @SuppressWarnings("unchecked")
    protected void setFactory( BlockTypeFactory factory ) {
        if( this.factory == factory ) {
            return;
        }
        this.factory = factory;
        parameters.clearChildren();
        references = new VersionedReference[factory.getParameters().length];

        int index = 0;
        for( Parameter parm : factory.getParameters() ) {
            parameters.addChild(new Label(parm.getName()));
            if( parm.getType() == Vec3d.class ) {
                Vec3dEditor editor = parameters.addChild(new Vec3dEditor(), 1);
                editor.setObject((Vec3d)parm.getInitialValue());
                references[index] = editor.createReference();
            } else if( parm.getType() == Boolean.class ) {
                Checkbox checkbox = parameters.addChild(new Checkbox(""), 1);
                checkbox.setChecked((Boolean)parm.getInitialValue());
                references[index] = checkbox.getModel().createReference();
            } else if( parm.getType() == Double.class ) {
                double min = (Double)parm.getMinValue();
                double max = (Double)parm.getMaxValue();
                double val = (Double)parm.getInitialValue();
                double step = (Double)parm.getStepValue(0.01);
                RangedValueModel range = new DefaultRangedValueModel(min, max, val);
                SequenceModel<Double> model = SequenceModels.rangedSequence(range, step, 0.01);
                DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
                Spinner spinner = parameters.addChild(new Spinner(model, renderer), 1);
                spinner.setValueEditor(ValueEditors.doubleEditor("%.2f"));
                references[index] = spinner.getModel().createReference();
            } else if( parm.getType() == MaterialType.class ) {
                Selector<String> selector = new Selector<>(materials.getMaterialNames(),
                                                           new MaterialConfigToString());
                parameters.addChild(selector, 1);
                references[index] = selector.createSelectedItemReference();
            }
            index++;
        }
        // Let it recalculate by clearing our override
        setPreferredSize(null);
        Vector3f pref = getPreferredSize();
        pref.x = Math.max(pref.x, 300);
        setPreferredSize(pref);
        setSize(pref);
    }

    protected void create() {
        BlockName name = nameEditor.getBlockName();
        if( name.getBase().length() == 0 ) {
            options.show("Invalid Name", "Block names must have a base name");
            return;
        }
        BlockTypeFactory factory = factorySelector.getSelectedItem();
        if( name.getShape().length() == 0 ) {
            //name.setShape(factory.getBaseName());
            name = new BlockName(name.getBase(), factory.getBaseName(), name.getRotation());
        }

        if( blocks.get(name) != null ) {
            options.show("Invalid Name", "Block name already exists:" + name);
            return;
        }

        Object[] args = new Object[references.length];
        for( int i = 0; i < args.length; i++ ) {
            references[i].update();
            args[i] = references[i].get();
        }

        String materialName = materialSelector.getSelectedItem();
        BlockType newType = factory.create(materials, name, materialName, args);
        blocks.add(newType);

        this.blockType = newType;

        removeFromParent();
    }

    protected void cancel() {
        this.blockType = null;
        removeFromParent();
    }

    private static class MaterialConfigToString implements Function<String, String> {
        public String apply( String name ) {
            if( name == null ) {
                return "-none-";
            }
            return name;
        }
    }
}


