/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.SpringGridLayout;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.config.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidSetMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FluidSetMenuState.class);

    private VersionedReference<FluidSet> fluidRef;

    private Selector<FluidType> fluidSelector;
    private VersionedReference<FluidType> typeRef;
    private Spinner<Integer> levelSpinner;

    private FluidTypeEditor typeEditor;
    private VersionedReference<FluidType> editorRef;

    public FluidSetMenuState() {
    }

    public VersionedReference<Integer> getSelectedTypeRef() {
        // We don't want the selected item, but the selection index
        return fluidSelector.getListBox().getSelectionModel().createSelectionReference();
    }

    public VersionedReference<Integer> getLevelRef() {
        return levelSpinner.getModel().createReference();
    }

    public VersionedReference<FluidType> getFluidTypeRef() {
        return typeEditor.createReference();
    }

    @Override
    protected void initialize( Application app ) {
        this.fluidRef = getState(BlockSetMenuState.class).createFluidSetReference();

        Container fluids = new Container();

        Container props = fluids.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));

        props.addChild(new Label("Type:"));
        fluidSelector = new Selector<>(fluidRef.get().getTypes(),
                                       new TypeCellRenderer(new ElementId("selector.item"), null),
                                       null);
        fluidSelector = props.addChild(fluidSelector, 1);
        typeRef = fluidSelector.createSelectedItemReference();

        props.addChild(new Label("Level:"));
        List<Integer> levels = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
        levelSpinner = new Spinner<>(SequenceModels.listSequence(levels, 5));
        props.addChild(levelSpinner, 1);

        typeEditor = new FluidTypeEditor();
        typeEditor.setFluidSet(getState(BlockSetMenuState.class).getFluidSet());
        typeEditor.setMaterialSet(getState(BlockSetMenuState.class).getMaterialSet());
        editorRef = typeEditor.createReference();
        fluids.addChild(new RollupPanel("Type Editor", typeEditor, null));

        getState(BlockSetMenuState.class).getTabs().addTab("Fluids", fluids);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void update( float tpf ) {
        if( typeRef.update() ) {
            updateType(typeRef.get());
        }
    }

    protected void updateType( FluidType type ) {
        typeEditor.setFluidType(type);
    }

    public class TypeCellRenderer extends DefaultCellRenderer<FluidType> {

        public TypeCellRenderer( ElementId elementId, String style ) {
            super(elementId, style);
        }

        public Panel getView( FluidType value, boolean selected, Panel existing ) {
            Label result = (Label)super.getView(value, selected, existing);
            if( value == null ) {
                result.setText("-empty-");
            } else {
                result.setText(String.valueOf(value.getName()));
            }
            return result;
        }
    }
}
