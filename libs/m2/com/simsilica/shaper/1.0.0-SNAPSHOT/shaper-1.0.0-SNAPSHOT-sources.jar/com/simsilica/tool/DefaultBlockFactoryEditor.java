/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.lang.reflect.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.DefaultValueRenderer;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DefaultBlockFactoryEditor extends Container implements BlockFactoryEditor<DefaultBlockFactory> {

    static Logger log = LoggerFactory.getLogger(DefaultBlockFactoryEditor.class);

    private BlockSet blockSet;
    private DefaultBlockFactory blockFactory;
    private long version;
    private MaterialSet materialSet;

    private List<Direction> dirs = new ArrayList<>(Arrays.asList(Direction.values()));
    private Selector<Direction> dirSelector;

    private Map<Class, PartFactoryEditor> factoryEditors = new HashMap<>();
    private Map<String, Class> factoryClassNames = new HashMap<>();
    private Container factoryEditorContainer;

    private Container sideEditorContainer;

    private boolean sideEditorVisible;
    private Container sideEditor;
    private Label sideShape;
    private Spinner<Double> sideTrans;
    private VersionedReference<Double> sideTransRef;
    private static BackdoorAccess backdoorAccess = new BackdoorAccess();

    private PartFactory partFactory;
    private VersionedReference<Direction> dirRef;
    private VersionedReference<PartFactory> partFactoryChanges;

    public DefaultBlockFactoryEditor() {

        factoryEditors.put(DefaultPartFactory.class, new DefaultPartFactoryEditor());
        factoryClassNames.put("Default", DefaultPartFactory.class);

        dirs.add(null);
        dirSelector = new Selector<Direction>(new VersionedList<Direction>(dirs),
                                   ValueRenderers.toStringRenderer("Internal"));
        ///((DefaultValueRenderer)dirSelector.getValueRenderer()).setStringTransform(new DirToString());

        dirRef = dirSelector.createSelectedItemReference();

        Container properties = addChild(new Container());
        properties.setBackground(null);
        properties.addChild(new Label("Side:"));
        properties.addChild(dirSelector, 1);

        sideEditorContainer = addChild(new Container(new BorderLayout()));
        sideEditorContainer.setBackground(null);

        sideEditor = new Container();
        sideEditor.setBackground(null);
        sideEditor.addChild(new Label("Shape:"));
        sideShape = sideEditor.addChild(new Label("none"), 1);
        sideEditor.addChild(new Label("Trans.:"));

        SequenceModel<Double> transModel = SequenceModels.rangedSequence(new DefaultRangedValueModel(0, 1, 0), 0.05, 0.01);
        sideTransRef = transModel.createReference();
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
        sideTrans = sideEditor.addChild(new Spinner<Double>(transModel, renderer), 1);
        sideTrans.setValueEditor(ValueEditors.doubleEditor("%.2f"));

        factoryEditorContainer = addChild(new Container(new BorderLayout()));
        factoryEditorContainer.setBackground(null);
        updatePartEditor();
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public DefaultBlockFactory getObject() {
        return blockFactory;
    }

    @Override
    public VersionedReference<DefaultBlockFactory> createReference() {
        return new VersionedReference<>(this);
    }

    @Override
    public void setBlockSet( BlockSet blockSet ) {
        this.blockSet = blockSet;
        for( PartFactoryEditor editor : factoryEditors.values() ) {
            editor.setBlockSet(blockSet);
        }
    }

    @Override
    public void setMaterialSet( MaterialSet materialSet ) {
        this.materialSet = materialSet;
        for( PartFactoryEditor editor : factoryEditors.values() ) {
            editor.setMaterialSet(materialSet);
        }
    }

    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( dirRef.update() ) {
log.info("---------dir changed:" + dirRef.get());
            updatePartEditor();
            updateSideEditor();
        }
        if( sideTransRef.update() ) {
            setTrans(sideTransRef.get());
        }
        if( partFactoryChanges != null && partFactoryChanges.update() ) {
log.info("part factory changed");
            Direction dir = dirRef.get();
            if( dir != null ) {
                PartFactory[] dirParts = blockFactory.getDirParts();
                dirParts[dir.ordinal()] = partFactory;
            } else {
                blockFactory.setInternalParts(partFactory);
            }
            version++;
        }
    }

    protected void updateSideEditor() {
        Direction dir = dirRef.get();

log.info("updateSideEditor():" + dir);
        if( dir == null ) {
            sideEditorContainer.clearChildren();
            sideEditorVisible = false;
        } else {
            if( !sideEditorVisible ) {
                sideEditorContainer.addChild(sideEditor, BorderLayout.Position.Center);
                sideEditorVisible = true;
            }

            // Update the values
            sideShape.setText(String.valueOf(blockFactory.getShape(dir)));
            sideTrans.setValue(blockFactory.getTransparency(dir));
        }
    }

    protected void setTrans( Double trans ) {
        if( trans == null ) {
            return;
        }
        Direction dir = dirRef.get();
        if( dir == null ) {
            return;
        }
        if( blockFactory == null ) {
            return;
        }
        //blockFactory.setTransparency(dir, trans);
        backdoorAccess.setTransparency(blockFactory, dir, trans);
        version++;
    }

    protected void updatePartEditor() {

        Direction dir = dirRef.get();
        PartFactory factory = null;
        if( blockFactory != null ) {
            if( dir != null ) {
                PartFactory[] dirParts = blockFactory.getDirParts();
                factory = dirParts == null ? null : dirParts[dir.ordinal()];
            } else {
                factory = blockFactory.getInternalParts();
            }
        }
        setPartFactory(factory, dir);
    }

    protected void setPartFactory( PartFactory factory, Direction dir ) {
        if( partFactory == factory ) {
            return;
        }
        this.partFactory = factory;

        PartFactoryEditor factoryEditor = factory == null ? null : factoryEditors.get(factory.getClass());
        if( factoryEditor != null ) {
            factoryEditorContainer.addChild(factoryEditor.getEditor(), BorderLayout.Position.Center);
            factoryEditor.setPartFactory(partFactory, dir);
            partFactoryChanges = factoryEditor.createReference();
        } else {
            partFactoryChanges = null;
            factoryEditorContainer.clearChildren();
        }
    }

    @Override
    public void setBlockFactory( DefaultBlockFactory factory ) {
        this.blockFactory = factory;
        updatePartEditor();
        updateSideEditor();
    }

    @Override
    public DefaultBlockFactory getBlockFactory() {
        return blockFactory;
    }

    @Override
    public Panel getEditor() {
        return this;
    }

    private static class DirToString implements Function<Direction, String> {
        public String apply( Direction dir ) {
            return dir == null ? "Internal" : dir.toString();
        }
    }

    /**
     *  Sneaky way of changing the transparency values without requiring
     *  us to give up the final keyword... and without requiring us to keep
     *  a whole other "builder" object just for this.
     */
    private static class BackdoorAccess {
        private Field transField;
        private Field isTransField;

        public BackdoorAccess() {
            try {
                transField = DefaultBlockFactory.class.getDeclaredField("transparency");
                transField.setAccessible(true);

                isTransField = DefaultBlockFactory.class.getDeclaredField("isTransparent");
                isTransField.setAccessible(true);
            } catch( Exception e ) {
                throw new RuntimeException("Error looking up transparency fields", e);
            }
        }

        public void setTransparency( DefaultBlockFactory factory, Direction dir, double value ) {
            try {
                double[] trans = (double[])transField.get(factory);
                if( trans == null && value == 0 ) {
                    return;  // nothing would change
                }
                if( trans == null ) {
                    trans = new double[6];
                }
                trans[dir.ordinal()] = value;

                // recalculate the overall transparency flag
                boolean b = (trans[0] + trans[1] + trans[2]
                             + trans[3] + trans[4] + trans[5]) != 0;

                transField.set(factory, trans);
                isTransField.set(factory, b);

            } catch( Exception e ) {
                throw new RuntimeException("Error performing backdoor access", e);
            }
        }
    }
}

