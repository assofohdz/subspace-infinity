/*
 * $Id: AbstractNoiseElevationGenerator.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;


/**
 *  Base class for generators that generate terrain based on a random
 *  seed.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public abstract class AbstractNoiseElevationGenerator extends AbstractElevationGenerator
{
    protected PerlinNoise noise = new PerlinNoise();
    private int frequency = 256;
    private long seed;
    private boolean additive = false;
    private boolean affected = true;

    protected AbstractNoiseElevationGenerator( String name )
    {
        super( name );
    }

    public void setSeed( long seed )
    {
        if( this.seed == seed )
            return;
        this.seed = seed;
        invalidate();
    }

    public long getSeed()
    {
        return( seed );
    }

    public void setFrequency( int f )
    {
        if( this.frequency == f )
            return;
        this.frequency = f;
        invalidate();
    }

    public int getFrequency()
    {
        return( frequency );
    }

    public void setAdditive( boolean additive )
    {
        if( this.additive == additive )
            return;
        this.additive = additive;
        invalidate();
    }

    public boolean isAdditive()
    {
        return( additive );
    }

    public void setAffected( boolean affected )
    {
        if( this.affected == affected )
            return;
        this.affected = affected;
        invalidate();
    }

    public boolean isAffected()
    {
        return( affected );
    }


    /**
     *  Called to initialize any implementation specific structures
     *  before the map is generated.
     */
    protected void reinitialize()
    {
    }

    /**
     *  Overridden by subclasses to provide the predictable random
     *  value for the specified x, y, z.  The result should be properly
     *  scaled as necessary to directly fill in the elevation.
     *  pspeed:2020-03-08: despite what the above says, it appears that the
     *  generateElevations() call is what scales to offset and scale.
     */
    protected abstract double getElevation( double x, double y, double z );


    public double getLayeredElevation( double x, double y, double z ) {
        // In generateElevations() we apparently lie to the users of our result about
        // what actual scale and offset we use.  Going to see how badly that affects the results.

        double scale = 1.0 / frequency;

        double tx = x * scale;
        double ty = y * scale;
        double tz = 0;

        if( affected ) {
            tz = z;
        }

        // Another difference is that the generateElevations() way normalizes each
        // elevation to a scaled int... and we return the raw double.
        //if( !additive ) {
            return getElevation(tx, ty, tz);
        //}
        //return z + getElevation(tx, ty, tz);
    }

    /**
     *  Calls the implementation specific getValue() method to calculate
     *  each elevation point on the map.
     */
    protected ElevationData generateElevations( ElevationData result )
    {
        ElevationData source = getSourceData();
        int[][] sourceMap = source.getElevations();
        int mapSize = source.getMapSize();

        if( result == null )
            result = new ElevationData( mapSize );
        result.setBaseX( source.getBaseX() );
        result.setBaseY( source.getBaseY() );

        int sourceScale = source.getElevationScale();
        int sourceOffset = source.getElevationOffset();

        double elevationScale = getElevationScale();
        double elevationOffset = getElevationOffset();

        // If we're additive then our range is potentially
        // different than it would be by default
        int adjustedScale = sourceScale + (int)(elevationScale + elevationOffset);
        int adjustedOffset = sourceOffset - (int)elevationOffset;

        result.setElevationScale( adjustedScale );
        result.setElevationOffset( adjustedOffset );

        if( noise.getSeed() != getSeed() )
            noise.setSeed( getSeed() );

        // These will give us our original results which were wrong
        // but they still produced nice images.  I'm leaving it in case
        // I ever want to go back and see.
        //int sourceScale = source.getElevationScale() + source.getElevationOffset();
        //int sourceOffset = 0; //source.getElevationOffset();

        int baseX = source.getBaseX();
        int baseY = source.getBaseY();

        int[][] map = result.getElevations();
        double scale = 1.0 / frequency;

        reinitialize();

        for( int x = 0; x < mapSize; x++ )
            {
            for( int y = 0; y < mapSize; y++ )
                {
                double tx = (baseX + (double)x) * scale;
                double ty = (baseY + (double)y) * scale;
                double tz = 0;

                if( affected )
                    tz = (double)(sourceMap[y][x] - sourceOffset) / (double)sourceScale;

                if( !additive )
                    {
//if( y == 512 && x == 512 ) {
//    System.out.println("(" + tx + ", " + ty + ", " + tz + ") elev:" + getElevation(tx, ty, tz) + "  scale:" + elevationScale + "  offset:" + elevationOffset);
//}
                    map[y][x] = (int)Math.round( getElevation( tx, ty, tz ) * elevationScale + elevationOffset );
                    }
                else
                    {
//if( y == 512 && x == 512 ) {
//    System.out.println("(" + tx + ", " + ty + ", " + tz + ") source:" + sourceMap[y][x] + " elev:" + getElevation(tx, ty, tz) + "  scale:" + elevationScale + "  offset:" + elevationOffset);
//}
                    map[y][x] = sourceMap[y][x] + (int)Math.round( getElevation( tx, ty, tz ) * elevationScale + elevationOffset );
                    }
                }
            }

        return( result );
    }
}


