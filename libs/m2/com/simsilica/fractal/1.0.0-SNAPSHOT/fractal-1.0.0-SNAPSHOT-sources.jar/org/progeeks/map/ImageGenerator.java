/*
 * $Id: ImageGenerator.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.awt.Image;
import java.awt.image.*;
import java.util.*;

/**
 *  Geenrates an image for a set of elevations.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class ImageGenerator
{
    private ElevationData data;

    /**
     *  Image color view of the map.
     */
    private BufferedImage colorImage;

    /**
     *  Image view of the shadows for the map.
     */
    private BufferedImage shadowImage;

    /**
     *  Creates a generator that will generate images
     *  for the specified elevation data.
     */
    public ImageGenerator( ElevationData data )
    {
        this.data = data;
    }

    public void setElevationData( ElevationData data )
    {
        if( this.data == data )
            return;
        this.data = data;
        invalidate();
    }

    public int getMapSize()
    {
        return( data.getMapSize() );
    }

    public void invalidate()
    {
        colorImage = null;
        shadowImage = null;
    }

    protected void regenerateImage()
    {
        int[][] map = data.getElevations();
        int mapSize = data.getMapSize();

        if( colorImage == null )
            {
            colorImage = new BufferedImage( mapSize, mapSize, BufferedImage.TYPE_INT_ARGB );
            shadowImage = new BufferedImage( mapSize, mapSize, BufferedImage.TYPE_INT_ARGB );
            }

        int[] buffer = ((DataBufferInt)colorImage.getRaster().getDataBuffer()).getData();
        int[] shadow = ((DataBufferInt)shadowImage.getRaster().getDataBuffer()).getData();

        int pos = 0;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for( int y = 0; y < mapSize; y++ )
            {
            for( int x = 0; x < mapSize; x++ )
                {
                int val = map[y][x];
                if( val < min )
                    min = val;
                if( val > max )
                    max = val;

                /*val = val - minHeight;
                if( val < 0 )
                    val = 0;
                if( val < (-minHeight + 64) && val > (-minHeight - 64) )
                    val = 32768;
                else
                    val = val * 3;*/

                int color;
                if( val < -64 )
                    {
                    int v = Math.abs( val ) / 62;

                    color = 0xff000000 | (v);
                    }
                else if( val <= 64 )
                    {
                    color = 0xffffff00;
                    }
                else if( val < 5120 )
                    {
                    int v = val / 20;
                    v = 64 + v / 2;
                    color = 0xff000000 | (v << 8);
                    }
                else if( val < 10240 )
                    {
                    int v = (val - 5120) / 20;
                    int r = v / 2;
                    int g = 196 - v / 3;
                    int b = 0;
                    color = 0xff000000 | (r << 16) | (g << 8) | b;
                    }
                else
                    {
                    int v = (val - 10240) / 66;
                    int r = 128 + v / 2; //Math.min( 255, v * 3 / 2);
                    int g = Math.min( 155, 110 + v / 2 ); //196;// + v / 4;
                    int b = v;
                    color = 0xff000000 | (r << 16) | (g << 8) | b;
                    }

                int shadowValue;
                // Calculate a southeast slope
                int center = (val + map[y][x+1] + map[y+1][x] + map[y+1][x+1]) / 4;
                int slope = center - val;
                // Positive is highlight, negative is shadow
                if( slope >= 0 )
                    {
                    // Highlight will never be more than a certain cap
                    // and we're more sensitive to changes closer to straight
                    // up.
                    int v = slope;
                    if( v >= 256 )
                        v = 255;
                    if( val < 0 )
                        v = v >> 2;
                    shadowValue = (v << 24) | 0xffffff;
                    //shadowValue = (200 << 24) | 0xffffff;
                    }
                else
                    {
                    // Shadow will never be more than a certain cap
                    // and we're more sensitive to changes closer to straight
                    // up.
                    int v = -slope;
                    if( v >= 256 )
                        v = 255;
                    if( val < 0 )
                        v = v >> 2;
                    shadowValue = (v << 24);
                    //shadowValue = (200 << 24) | 0x000000;
                    }
                /*if( x < mapSize / 2 )
                    {
                    int v = (mapSize / 2) - x;
                    v = v / (mapSize / 512);
                    shadowValue = (v << 24) | 0xffffff;
                    }
                else
                    {
                    int v = x - (mapSize / 2);
                    v = v / (mapSize / 512);
                    shadowValue = (v << 24);
                    }*/
                shadow[pos] = shadowValue;
                buffer[pos++] = color;
                }
            }

        System.out.println( "Lowest point:" + min + "   Highest point:" + max );
    }

    /**
     *  Returns a color image representation of the map.
     */
    public Image getColorImage()
    {
        if( colorImage == null )
            regenerateImage();

        return( colorImage );
    }

    /**
     *  Returns an image representation of the shadows and highlights for the map.
     */
    public Image getShadowImage()
    {
        if( shadowImage == null )
            regenerateImage();

        return( shadowImage );
    }

    /**
     *  Returns a gray-scale image representing the height.
     */
   /* public Image getHeightImage()
    {
        if( invalid )
            {
            regenerateMap();
            regenerateImage();
            }

        BufferedImage image = new BufferedImage( mapSize, mapSize, BufferedImage.TYPE_USHORT_GRAY );

        short[] buffer = ((DataBufferUShort)image.getRaster().getDataBuffer()).getData();

        int pos = 0;
        for( int y = 0; y < mapSize; y++ )
            {
            for( int x = 0; x < mapSize; x++ )
                {
                int val = map[y][x];
                val = val - minHeight;
                if( val < 0 )
                    val = 0;
                buffer[pos++] = (short)val;
                }
            }

        return( image );
    }*/
}
