/*
 * $Id: Erosion.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator that performs an erosion operation on the
 *  previous layer.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class Erosion extends AbstractElevationGenerator
{
    private double filter = 0.5;

    public Erosion()
    {
        super( "Erosion Operator" );
    }

    public void setFilter( double filter )
    {
        if( this.filter == filter )
            return;
        this.filter = filter;
        invalidate();
    }

    public double getFilter()
    {
        return( filter );
    }

    protected ElevationData generateElevations( ElevationData result )
    {
        ElevationData source = getSourceData();
        int[][] sourceMap = source.getElevations();
        int mapSize = source.getMapSize();

        if( result == null )
            result = new ElevationData( mapSize );

        int[][] map = result.getElevations();

        // Erode left to right
        double d;
        for( int y = 0; y < mapSize; y++ )
            {
            d = map[y][0] = sourceMap[y][0];
            for( int x = 1; x < mapSize; x++ )
                {
                d = filter * d + (1 - filter) * sourceMap[y][x];
                map[y][x] = (int)Math.round(d);
                }
            }

        // Erode right to left
        for( int y = 0; y < mapSize; y++ )
            {
            d = sourceMap[y][mapSize-1];
            for( int x = mapSize - 1; x >= 0; x-- )
                {
                d = filter * d + (1 - filter) * map[y][x];
                map[y][x] = (int)Math.round(d);
                }
            }

        // Erode top to bottom
        for( int x = 0; x < mapSize; x++ )
            {
            d = sourceMap[0][x];
            for( int y = 1; y < mapSize; y++ )
                {
                d = filter * d + (1 - filter) * map[y][x];
                map[y][x] = (int)Math.round(d);
                }
            }

        // Erode bottom to top
        for( int x = 0; x < mapSize; x++ )
            {
            d = sourceMap[mapSize - 1][x];
            for( int y = mapSize - 1; y >= 0; y-- )
                {
                d = filter * d + (1 - filter) * map[y][x];
                map[y][x] = (int)Math.round(d);
                }
            }

        return( result );
    }
}


