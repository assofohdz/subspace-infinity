/*
 * $Id: ElevationData.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;


/**
 *  Contains the elevation data and map size information for an area.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class ElevationData
{
    private int[][] map;
    private int mapSize;
    private int scale = 15000;
    private int offset = -1500;
    private int baseX;
    private int baseY;

    public ElevationData( int mapSize )
    {
        this.mapSize = mapSize;
    }

    public void setBaseX( int x )
    {
        this.baseX = x;
    }

    public int getBaseX()
    {
        return baseX;
    }

    public void setBaseY( int y )
    {
        this.baseY = y;
    }

    public int getBaseY()
    {
        return baseY;
    }

    public int[][] getElevations()
    {
        if( map == null )
            map = new int[mapSize + 1][mapSize + 1];
        return( map );
    }

    public void setMapSize( int mapSize )
    {
        if( this.mapSize == mapSize )
            return;
        this.mapSize = mapSize;
        map = null;
    }

    public int getMapSize()
    {
        return( mapSize );
    }

    public void setElevationScale( int scale )
    {
        this.scale = scale;
    }

    public int getElevationScale()
    {
        return( scale );
    }

    public void setElevationOffset( int offset )
    {
        this.offset = offset;
    }

    public int getElevationOffset()
    {
        return( offset );
    }
}
