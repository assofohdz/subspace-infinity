/*
 * $Id: FractalSumElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator that uses the fractal sum algorithm.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class FractalSumElevations extends AbstractNoiseElevationGenerator
{
    private double minFreq = 1.0;
    private int    frequencyIterations = 5;

    public FractalSumElevations()
    {
        super( "Fractal Sum" );
    }

    public void setStartingFrequency( double d )
    {
        if( this.minFreq == d )
            return;
        this.minFreq = d;
        invalidate();
    }

    public double getStartingFrequency()
    {
        return( minFreq );
    }

    public void setFrequencyIterations( int i )
    {
        if( this.frequencyIterations == i )
            return;
        this.frequencyIterations = i;
        invalidate();
    }

    public int getFrequencyIterations( )
    {
        return( frequencyIterations );
    }

    protected double getElevation( double x, double y, double z )
    {
        double value = 0;

        double f = minFreq;
        for( int i = 0; i < frequencyIterations; i++ )
            {
            double sample = noise.getNoise( x * f, y * f, z * f ) / f;
            value += sample;
            f = f * 2;
            }

        return( value );
    }

}



