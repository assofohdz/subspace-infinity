/*
 * $Id: ElevationGenerator.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;


/**
 *  Generates elevation data from source data based on an
 *  internal implementation-specific algorithm.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public interface ElevationGenerator
{
    /**
     *  Marks the generated data as invalid so that it will
     *  be recalculated.
     */
    public void invalidate();

    /**
     *  Set to true if this generator should calcute its data
     *  and to false if it should just return its source as its
     *  result.
     */
    public void setEnabled( boolean enabled );

    /**
     *  Returns true if this generator will calculate its results
     *  or false if it will simply return its source data.
     */
    public boolean isEnabled();

    /**
     *  Returns the human readable name of this generator type.
     */
    public String getName();

    /**
     *  Returns true if this generator accepts source data.
     */
    public boolean acceptsSourceData();

    /**
     *  Sets the source data upon which this generator will
     *  operate upon.  May not be available for all generators.
     */
    public void setSourceData( ElevationData data );

    /**
     *  Returns the source data (if specified) that this generator
     *  will operate upon.
     */
    public ElevationData getSourceData();

    /**
     *  Returns the produced data from this generator.
     */
    public ElevationData getGeneratedData();
}
