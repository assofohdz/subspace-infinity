/*
 * $Id: MidpointDisplacementElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator that uses the midpoint displacement algorithm.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class MidpointDisplacementElevations extends AbstractElevationGenerator
{
    /**
     *  A roughness multiplier for the calculated random displacements.
     */
    private double roughness = 3;

    /**
     *  Sets the roughness reducation bias.
     */
    private int roughnessBias = 5;

    private int seed;

    private int preseedFactor = 2;

    private int drift = 4;


    public MidpointDisplacementElevations()
    {
        super( "Midpoint Displacement" );
    }

    public void setSeed( int seed )
    {
        if( this.seed == seed )
            return;
        this.seed = seed;
        invalidate();
    }

    public int getSeed()
    {
        return( seed );
    }

    public void setPreseedFrequency( int s )
    {
        int mapSize = getSourceData().getMapSize();
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        if( s > seedMax )
            s = seedMax;
        else if( s < 0 )
            s = 0;

        if( this.preseedFactor == s )
            return;
        this.preseedFactor = s;
        invalidate();
    }

    public int getPreseedFrequency()
    {
        return( preseedFactor );
    }

    public void setRoughnessScale( double r )
    {
        if( this.roughness == r )
            return;
        this.roughness = r;
        invalidate();
    }

    public double getRoughnessScale()
    {
        return( roughness );
    }

    public void setRoughnessBias( int bias )
    {
        if( this.roughnessBias == bias )
            return;
        this.roughnessBias = bias;
        invalidate();
    }

    public int getRoughnessBias()
    {
        return( roughnessBias );
    }

    public void setDrift( int drift )
    {
        if( this.drift == drift )
            return;
        this.drift = drift;
        invalidate();
    }

    public int getDrift()
    {
        return( drift );
    }

    protected int driftedAverage( int v1, int v2, int drift, Random rand )
    {
        int r = rand.nextInt(drift) + 1;
        int count = r;
        int total = v1 * r;

        r = rand.nextInt(drift) + 1;
        count += r;
        total += v2 * r;

        return( total / count );
    }

    protected int driftedAverage( int v1, int v2, int v3, int v4, int drift, Random rand )
    {
        int r = rand.nextInt(drift) + 1;
        int count = r;
        int total = v1 * r;

        r = rand.nextInt(drift) + 1;
        count += r;
        total += v2 * r;

        r = rand.nextInt(drift) + 1;
        count += r;
        total += v3 * r;

        r = rand.nextInt(drift) + 1;
        count += r;
        total += v4 * r;

        return( total / count );
    }

    protected ElevationData generateElevations( ElevationData result )
    {
        ElevationData source = getSourceData();
        int[][] sourceMap = source.getElevations();
        int mapSize = source.getMapSize();

        if( result == null )
            result = new ElevationData( mapSize );

        result.setElevationScale( getElevationScale() );
        result.setElevationOffset( getElevationOffset() );

        int sourceScale = source.getElevationScale();
        int sourceOffset = source.getElevationOffset();

        int scale = getElevationScale();
        int offset = getElevationOffset();

        int[][] map = result.getElevations();


        // Seed the same so that we can more easily test
        Random rand = new Random( getSeed() );

        // Standard diamond squares algorithm to seed the world.

        // First we'll seed the initial points so that we can
        // start our step size at 256.  These will be completely
        // independent random values.  We leave the border at MIN_HEIGHT
        // so that we create an island.

        // Fill the array with minimum heights
        for( int y = 0; y <= mapSize; y++ )
            Arrays.fill( map[y], offset );

        int heightRange = scale;

        // Use the map size to calculate the seed steps
        // seedStep = 2 ^ n
        // where n is the number of times 1024 can be divided
        // be two minus preseedFactor.
        // 2 ^ x = 1024
        // log2(1024) = x
        // ln(1024) / ln(2) = x
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        int seedStep = seedMax - preseedFactor;
        seedStep = (int)Math.pow( 2, seedStep );

        // Then seed the values
        for( int x = 0; x <= mapSize; x += seedStep )
            {
            for( int y = 0; y <= mapSize; y += seedStep )
                {
                if( y == 0 || x == 0 || x == mapSize || y == mapSize )
                    {
                    // Leave the borders at min height.
                    continue;
                    }

                if( sourceMap[y][x] != 0 )
                    map[y][x] = sourceMap[y][x];
                else
                    map[y][x] = offset + rand.nextInt( scale );
                }
            }

        double cos45 = Math.cos( Math.toRadians( 45 ) );

        // Now perform the diamond square sequences until we've
        // finished.
        int step = seedStep;
        double displacement = (scale / 2) * roughness;

        // How many iterations will we have?  It's the exponent
        // in the equation:
        // 2 ^ x = step
        // or... log2(step)
        double count = Math.log( step ) / Math.log( 2 );

        // In count iterations we want displacement to be 1 or 0.
        // In other words:
        // x ^ count = displacement.
        // logx(displacement) = count
        // ln(displacement) / ln(x) = count
        // 1 / ln(x) = count / ln(displacement)
        // ln(x) = ln(displacement) / count
        //
        // Since: ln(x) = y  is the same as e ^ y = x
        // Then:
        // e ^ (ln(displacement) / count) = x
        //count -= 6;
        count += roughnessBias;
        double displacementStep = Math.exp( Math.log(displacement) / count );

        boolean doElevFactor = false;

        while( step > 1 )
            {
            int halfStep = step / 2;
            int disp = (int)displacement;
            int halfDisp = disp / 2;

            for( int x = 0; x < mapSize; x += step )
                {
                for( int y = 0; y < mapSize; y += step )
                    {

                    // Since we always seed the outside edge we only need to calculate
                    // the right and lower side points.

                    int nw = map[y][x];
                    int ne = map[y][x + step];
                    int sw = map[y + step][x];
                    int se = map[y + step][x + step];

                    // Get the existing west and north
                    int w = map[y + halfStep][x];
                    int n = map[y][x + halfStep];

                    // Calculate the east point
                    //int average = (ne + se) / 2;
                    int average = driftedAverage( ne, se, drift, rand );
                    int rise = (disp > 0) ? rand.nextInt( disp ) - halfDisp : 0;
                    int e = average + rise;

                    // Calculate the south point
                    //average = (sw + se) / 2;
                    average = driftedAverage( sw, se, drift, rand );
                    rise = (disp > 0) ? rand.nextInt( disp ) - halfDisp : 0;
                    int s = average + rise;

                    // Calculate the center point as the average
                    // of all four midpoints.
                    //average = (n + s + e + w) / 4;
                    average = driftedAverage( n, s, e, w, drift, rand );
                    rise = (disp > 0) ? rand.nextInt( disp ) - halfDisp : 0;
                    int center = average + rise;

                    // Set the points
                    map[y + step][x + halfStep] = s;
                    map[y + halfStep][x + step] = e;
                    map[y + halfStep][x + halfStep] = center;
                    }
                }

            // Setup for next pass
            step = halfStep;
            displacement = displacement / displacementStep;
            }

        return( result );
    }
}


