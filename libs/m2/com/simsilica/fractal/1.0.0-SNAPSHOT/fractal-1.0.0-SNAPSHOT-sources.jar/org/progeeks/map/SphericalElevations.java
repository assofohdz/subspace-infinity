/*
 * $Id: SphericalElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator generates a big hump.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class SphericalElevations extends AbstractNoiseElevationGenerator
{
    public SphericalElevations()
    {
        super( "Spherical" );
        setFrequency( 1024 );
    }

    protected double getElevation( double x, double y, double z )
    {

//if( y == 0 )
//    System.out.println( "getElevations(" + x + ")" );
        // Basically compute the sine for x and y stretched over
        // the full period of the map... we'll use frequency for that

        // Since we want the full sine period 0 -> 1 -> 0
        // we'll need to adjust the x,y coordinates to go
        // from 0 to PI
        x = x * Math.PI;
        y = y * Math.PI;

        return( Math.sin(y) * Math.sin( x ) );
    }


}



