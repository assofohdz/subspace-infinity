/*
 * $Id: MultiFractalElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;


/**
 *  Elevation generator that uses a multi-fractal to calculate a result.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class MultiFractalElevations extends AbstractNoiseElevationGenerator
{
    private int heightScale = 15000;
    private double fractalIncrement = 0.5;
    private double lacunarity = 3.02;
    private int octaves = 6;
    private double offset = 0.31;
    private double gain = 4;

    private int maxOctaves = 128;
    private double[] exponents = new double[maxOctaves];


    public MultiFractalElevations()
    {
        super( "Multi-Fractal" );
        setFrequency( 512 );
        setElevationOffset( 0 );
    }

    protected void reinitialize()
    {
        for( int i = 0; i < maxOctaves; i++ )
            {
            exponents[i] = Math.pow( lacunarity, -i * fractalIncrement );
            }
    }

    public void setFractalIncrement( double d )
    {
        if( this.fractalIncrement == d )
            return;
        this.fractalIncrement = d;
        invalidate();
    }

    public double getFractalIncrement()
    {
        return( fractalIncrement );
    }

    /**
     *  Sets the gap between successive frequencies.
     */
    public void setLacunarity( double d )
    {
        if( this.lacunarity == d )
            return;
        this.lacunarity = d;
        invalidate();
    }

    public double getLacunarity()
    {
        return( lacunarity );
    }

    /**
     *  Sets the number of frequences in the fBm.
     */
    public void setOctaves( int d )
    {
        if( this.octaves == d )
            return;
        this.octaves = d;
        invalidate();
    }

    public int getOctaves()
    {
        return( octaves );
    }

    public void setGain( double d )
    {
        if( this.gain == d )
            return;
        this.gain = d;
        invalidate();
    }

    public double getGain()
    {
        return( gain );
    }

    /**
     *  Sets the base offset for the terrain above sea level.
     */
    public void setOffset( double d )
    {
        if( this.offset == d )
            return;
        this.offset = d;
        invalidate();
    }

    public double getOffset()
    {
        return( offset );
    }

    protected double getElevation( double x, double y, double z )
    {
        // Get the first octave of the function, later octaves
        // are weighted.
        double value = noise.getNoise( x, y, z ) + offset;
        double weight = gain * value;

        x *= lacunarity;
        y *= lacunarity;
        z *= lacunarity;

        // Inner loop of spectral construction where the
        // fractal is built
        int i;
        for( i = 1; weight > 0.001 && i < octaves; i++ )
            {
            // Prevent divergence
            if( weight > 1.0 )
                weight = 1.0;

            // Get the next higher frequence
            double signal = (noise.getNoise( x, y, z ) + offset) * exponents[i];

            // Add it in, weighted by the previous frequency's
            // local value
            value += weight * signal;

            // Update the (monotonically decreasing) weighting value
            weight *= gain * signal;

            x *= lacunarity;
            y *= lacunarity;
            z *= lacunarity;
            }

        // Take care of the remainder in "octaves"
        double remainder = octaves - (int)octaves;
        if( remainder != 0 )
            {
            // "i" and spacial frequence are preset in loop
            value += remainder * noise.getNoise( x, y, z ) * exponents[i];
            }

        return( value );
    }

}

