/*
 * $Id: AdaptiveDiamondSquaresElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2006, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator that uses the adaptive diamond squares algorithm.
 *  It's similar to a regular diamond squares but tends to make rough
 *  terrain rougher and smooth terrain smoother as the sub-division
 *  progresses.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class AdaptiveDiamondSquaresElevations extends AbstractElevationGenerator
{
    /**
     *  A roughness multiplier for the calculated random displacements.
     */
    private double roughness = 3;

    /**
     *  Sets the roughness reducation bias.
     */
    private int roughnessBias = 5;

    private int seed;

    private int preseedFactor = 2;

    private double attenuation = 1.0;
    private int curveFactor = 1;

    public AdaptiveDiamondSquaresElevations()
    {
        super( "Adaptive Diamond/Squares" );
        setElevationScale( 15000 + 1500 );
    }

    public void setSeed( int seed )
    {
        if( this.seed == seed )
            return;
        this.seed = seed;
        invalidate();
    }

    public int getSeed()
    {
        return( seed );
    }

    public void setPreseedFrequency( int s )
    {
        int mapSize = getSourceData().getMapSize();
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        if( s > seedMax )
            s = seedMax;
        else if( s < 0 )
            s = 0;

        if( this.preseedFactor == s )
            return;
        this.preseedFactor = s;
        invalidate();
    }

    public int getPreseedFrequency()
    {
        return( preseedFactor );
    }

    public void setRoughnessScale( double r )
    {
        if( this.roughness == r )
            return;
        this.roughness = r;
        invalidate();
    }

    public double getRoughnessScale()
    {
        return( roughness );
    }

    public void setRoughnessBias( int bias )
    {
        if( this.roughnessBias == bias )
            return;
        this.roughnessBias = bias;
        invalidate();
    }

    public int getRoughnessBias()
    {
        return( roughnessBias );
    }

    public void setAttenuation( double d )
    {
        if( this.attenuation == d )
            return;
        this.attenuation = d;
        invalidate();
    }

    public double getAttenuation()
    {
        return( attenuation );
    }

    public void setCurveFactor( int i )
    {
        if( this.curveFactor == i )
            return;
        this.curveFactor = i;
        invalidate();
    }

    public int getCurveFactor()
    {
        return( curveFactor );
    }

    private int getMax( int a, int b, int c, int d )
    {
        int max = a;
        if( max < b )
            max = b;
        if( max < c )
            max = c;
        if( max < d )
            max = d;
        return( max );
    }

    private int getMin( int a, int b, int c, int d )
    {
        int min = a;
        if( min > b )
            min = b;
        if( min > c )
            min = c;
        if( min > d )
            min = d;
        return( min );
    }

    private double getRoughnessScalar( int min, int max, int step, int displacement, int rise )
    {
        // We want to make terrain more wild if it is higher
        // or if the surface is already rough.  We want terrain
        // to settle down if it is low or already smooth... or
        // at least tend to.
        // Also, as we get to smaller steps we don't care so much
        // about this factor.  It's mainly useful in the begining
        // so we should scale our results appropriately

        double elevationFactor = (double)(max - getElevationOffset()) / getElevationScale();
        if( elevationFactor < 0.01 )
            elevationFactor = 0.01;
        elevationFactor = Math.pow( elevationFactor, curveFactor );
        elevationFactor *= attenuation;
        double roughFactor = (double)(max - min) / displacement;
        elevationFactor = Math.pow( elevationFactor, curveFactor );
        roughFactor *= attenuation;

        double stepRatio = 256.0 / step;

        // 0.0, 0.5, 0.75...
        // Should represent the amount of the original
        // rise that should be kept
        // Alternately, 1.0, 0.5, 0.25 is the amount of our "spin"
        // to include.
        // Not sure which is easier to factor in.
        // The idea is that as the step size decreases then we should
        // defer more to the original result, ie: get closer to returning
        // a 1.0
        double stepFactor = 1 - (step / 256.0);
        //stepFactor = Math.pow( stepFactor, attenuation );

        double result = Math.min( 1.0, elevationFactor * roughFactor + stepFactor );

        if( step == 128 || step == 64 )
            {
            System.out.println( "min:" + min + " max:" + max + " step:" + step + " disp:" + displacement + " rise:" + rise );
            System.out.println( "  e factor:" + elevationFactor );
            System.out.println( "  r factor:" + roughFactor );
            System.out.println( "  s ratio:" + stepRatio );
            System.out.println( "  s factor:" + stepFactor );
            System.out.println( "    :" + (elevationFactor * roughFactor) );
            System.out.println( "    :" + (elevationFactor * roughFactor * stepFactor) );
            System.out.println( "    :" + result );
            }

        //return( 1.0 );
        return( result );
    }

    protected ElevationData generateElevations( ElevationData result )
    {
        ElevationData source = getSourceData();
        int[][] sourceMap = source.getElevations();
        int mapSize = source.getMapSize();

        if( result == null )
            result = new ElevationData( mapSize );

        result.setElevationScale( getElevationScale() );
        result.setElevationOffset( getElevationOffset() );

        int sourceScale = source.getElevationScale();
        int sourceOffset = source.getElevationOffset();

        int scale = getElevationScale();
        int offset = getElevationOffset();

        int[][] map = result.getElevations();


        // Seed the same so that we can more easily test
        Random rand = new Random( getSeed() );

        // Standard diamond squares algorithm to seed the world.

        // First we'll seed the initial points so that we can
        // start our step size at 256.  These will be completely
        // independent random values.  We leave the border at MIN_HEIGHT
        // so that we create an island.

        // Fill the array with minimum heights
        for( int y = 0; y <= mapSize; y++ )
            Arrays.fill( map[y], offset );

        int heightRange = scale;
        int maxHeight = scale - offset;

        // Use the map size to calculate the seed steps
        // seedStep = 2 ^ n
        // where n is the number of times 1024 can be divided
        // be two minus preseedFactor.
        // 2 ^ x = 1024
        // log2(1024) = x
        // ln(1024) / ln(2) = x
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        int seedStep = seedMax - preseedFactor;
        seedStep = (int)Math.pow( 2, seedStep );

        // Then seed the values
        for( int x = 0; x <= mapSize; x += seedStep )
            {
            for( int y = 0; y <= mapSize; y += seedStep )
                {
                if( y == 0 || x == 0 || x == mapSize || y == mapSize )
                    {
                    // Leave the borders at min height.
                    continue;
                    }

                if( sourceMap[y][x] != 0 )
                    map[y][x] = sourceMap[y][x];
                else
                    map[y][x] = offset + rand.nextInt( scale );
                }
            }

        double cos45 = Math.cos( Math.toRadians( 45 ) );

        // Now perform the diamond square sequences until we've
        // finished.
        int step = seedStep;
        double displacement = (scale / 2) * roughness;

        // How many iterations will we have?  It's the exponent
        // in the equation:
        // 2 ^ x = step
        // or... log2(step)
        double count = Math.log( step ) / Math.log( 2 );

        // In count iterations we want displacement to be 1 or 0.
        // In other words:
        // x ^ count = displacement.
        // logx(displacement) = count
        // ln(displacement) / ln(x) = count
        // 1 / ln(x) = count / ln(displacement)
        // ln(x) = ln(displacement) / count
        //
        // Since: ln(x) = y  is the same as e ^ y = x
        // Then:
        // e ^ (ln(displacement) / count) = x
        //count -= 6;
        count += roughnessBias;
        double displacementStep = Math.exp( Math.log(displacement) / count );


        while( step > 1 )
            {
            int halfStep = step / 2;
            //double halfDisp = displacement / 2;

            // First do the squares by calculating a center
            // point height relative to the average of the
            // four corner heights.
            int squareDisp = (int)displacement;
            int halfSqDisp = squareDisp / 2;
            for( int x = 0; x < mapSize; x += step )
                {
                for( int y = 0; y < mapSize; y += step )
                    {
                    int nw = map[y][x];
                    int ne = map[y][x + step];
                    int sw = map[y + step][x];
                    int se = map[y + step][x + step];

                    int max = getMax( nw, ne, sw, se );
                    int min = getMin( nw, ne, sw, se );

                    int average = (nw + ne + sw + se) / 4;

                    // Factor the squares max slope into some kind
                    // of roughness that we'll use to attenuate the
                    // displacement.
                    int rise = (squareDisp > 0) ? rand.nextInt( squareDisp ) - halfSqDisp : 0;
                    double scalar = getRoughnessScalar( min, max, step, squareDisp, rise );
                    rise = (int)Math.round( rise * scalar );

                    map[y + halfStep][x + halfStep] = average + rise;
                    }
                }

            // We reduce the displacement for the diamond step because
            // the distance is shorter.
            // This first one makes for rougher more interesting terrain
            // but the tile points are more visible.  Easier to just up the bias
            // for more roughness.
            int diamondDisp = (int)Math.round(displacement * cos45);
            int halfDmdDisp = diamondDisp / 2;

            // Now calculate the diamonds to find the mid-points of the tile
            // edges.  This is the displacement of the average of two tile
            // corners and two tile centers from this pass.  We also wrap...
            // so when we go off the edge of the map we get values from the
            // opposite edge.
            for( int x = 0; x < mapSize; x += step )
                {
                for( int y = 0; y < mapSize; y += step )
                    {
                    // We have two diamonds per "tile"... the one
                    // extend right from the point and the one extending
                    // down.  We don't fill in values for the first row
                    // or column because we want our land to be bordered
                    // by sea.

                    int n, s, e, w, average, d, hd, rise;
                    int sampleCount, max, min;

                    // *********
                    // Do the diamond to the right of this index
                    // that extends into the tile above us
                    d = diamondDisp;
                    hd = halfDmdDisp;

                    if( y > 0 )
                        {
                        int previous = y - halfStep;
                        n = map[previous][x + halfStep];
                        s = map[y + halfStep][x + halfStep];
                        e = map[y][x + step];
                        w = map[y][x];
                        sampleCount = 4;

                        max = getMax( n, s, e, w );
                        min = getMin( n, s, e, w );
                        }
                    else
                        {
                        n = 0;
                        s = map[y + halfStep][x + halfStep];
                        e = map[y][x + step];
                        w = map[y][x];
                        sampleCount = 3;

                        // Add a fill-in for n to make sure we don't
                        // bias the results
                        max = getMax( s, s, e, w );
                        min = getMin( s, s, e, w );

                        // Dampen the displacement at the edges
                        d = d / 3;
                        }

                    average = (n + s + e + w) / sampleCount;
                    rise = (d > 0) ? rand.nextInt( d ) - hd : 0;
                    double scalar = getRoughnessScalar( min, max, step, d, rise );
                    rise = (int)Math.round( rise * scalar );

                    // Add some extra dampening at the leading edges
                    if( y == 0 )
                        {
                        if( average + rise > 0 )
                            rise = 0;
                        if( average > 0 )
                            average = 0;
                        }

                    map[y][x + halfStep] = average + rise;


                    // *********
                    // Do the tile to the bottom of us that extends into the
                    // tile to the left of us
                    d = diamondDisp;
                    hd = halfDmdDisp;

                    if( x > 0 )
                        {
                        int previous = x - halfStep;
                        n = map[y][x];
                        s = map[y + step][x];
                        e = map[y + halfStep][x + halfStep];
                        w = map[y + halfStep][previous];
                        sampleCount = 4;

                        max = getMax( n, s, e, w );
                        min = getMin( n, s, e, w );
                        }
                    else
                        {
                        n = map[y][x];
                        s = map[y + step][x];
                        e = map[y + halfStep][x + halfStep];
                        w = 0;
                        sampleCount = 3;

                        // Add a fill-in for w to make sure we don't
                        // bias the results
                        max = getMax( n, s, e, e );
                        min = getMin( n, s, e, e );

                        // Dampen the displacement at the edges
                        d = d / 3;
                        }

                    average = (n + s + e + w) / sampleCount;
                    rise = (d > 0) ? rand.nextInt( d ) - hd : 0;
                    scalar = getRoughnessScalar( min, max, step, d, rise );
                    rise = (int)Math.round( rise * scalar );

                    // Add some extra dampening at the leading edges
                    if( x == 0 )
                        {
                        if( average + rise > 0 )
                            rise = 0;
                        if( average > 0 )
                            average = 0;
                        }

                    map[y + halfStep][x] = average + rise;
                    }
                }

            // Setup for next pass
            step = halfStep;
            displacement = displacement / displacementStep;
            }

        return( result );
    }
}


