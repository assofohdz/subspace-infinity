/*
 * $Id: DiamondSquaresElevations.java 726 2011-02-19 17:28:15Z pspeed $
 *
 * Copyright (c) 2005, Paul Speed
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1) Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2) Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3) Neither the names "Progeeks", "Meta-JB", nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package org.progeeks.map;

import java.util.*;


/**
 *  Elevation generator that uses the diamond squares algorithm.
 *
 *  @version   $Revision: 726 $
 *  @author    Paul Speed
 */
public class DiamondSquaresElevations extends AbstractElevationGenerator
{
    /**
     *  A roughness multiplier for the calculated random displacements.
     */
    private double roughness = 3;

    /**
     *  Sets the roughness reducation bias.
     */
    private int roughnessBias = 5;

    private int seed;

    private int preseedFactor = 2;


    public DiamondSquaresElevations()
    {
        super( "Diamond/Squares" );
        setElevationScale( 15000 + 1500 );
    }

    public void setSeed( int seed )
    {
        if( this.seed == seed )
            return;
        this.seed = seed;
        invalidate();
    }

    public int getSeed()
    {
        return( seed );
    }

    public void setPreseedFrequency( int s )
    {
        int mapSize = getSourceData().getMapSize();
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        if( s > seedMax )
            s = seedMax;
        else if( s < 0 )
            s = 0;

        if( this.preseedFactor == s )
            return;
        this.preseedFactor = s;
        invalidate();
    }

    public int getPreseedFrequency()
    {
        return( preseedFactor );
    }

    public void setRoughnessScale( double r )
    {
        if( this.roughness == r )
            return;
        this.roughness = r;
        invalidate();
    }

    public double getRoughnessScale()
    {
        return( roughness );
    }

    public void setRoughnessBias( int bias )
    {
        if( this.roughnessBias == bias )
            return;
        this.roughnessBias = bias;
        invalidate();
    }

    public int getRoughnessBias()
    {
        return( roughnessBias );
    }

    protected ElevationData generateElevations( ElevationData result )
    {
        ElevationData source = getSourceData();
        int[][] sourceMap = source.getElevations();
        int mapSize = source.getMapSize();

        if( result == null )
            result = new ElevationData( mapSize );

        result.setElevationScale( getElevationScale() );
        result.setElevationOffset( getElevationOffset() );

        int sourceScale = source.getElevationScale();
        int sourceOffset = source.getElevationOffset();

        int scale = getElevationScale();
        int offset = getElevationOffset();

        int[][] map = result.getElevations();


        // Seed the same so that we can more easily test
        Random rand = new Random( getSeed() );

        // Standard diamond squares algorithm to seed the world.

        // First we'll seed the initial points so that we can
        // start our step size at 256.  These will be completely
        // independent random values.  We leave the border at MIN_HEIGHT
        // so that we create an island.

        // Fill the array with minimum heights
        for( int y = 0; y <= mapSize; y++ )
            Arrays.fill( map[y], offset );

        int heightRange = scale;
        int maxHeight = scale - offset;

        // Use the map size to calculate the seed steps
        // seedStep = 2 ^ n
        // where n is the number of times 1024 can be divided
        // be two minus preseedFactor.
        // 2 ^ x = 1024
        // log2(1024) = x
        // ln(1024) / ln(2) = x
        int seedMax = (int)Math.round( Math.log( mapSize ) / Math.log( 2 ) );
        int seedStep = seedMax - preseedFactor;
        seedStep = (int)Math.pow( 2, seedStep );

        // Then seed the values
        for( int x = 0; x <= mapSize; x += seedStep )
            {
            for( int y = 0; y <= mapSize; y += seedStep )
                {
                if( y == 0 || x == 0 || x == mapSize || y == mapSize )
                    {
                    // Leave the borders at min height.
                    continue;
                    }

                if( sourceMap[y][x] != 0 )
                    map[y][x] = sourceMap[y][x];
                else
                    map[y][x] = offset + rand.nextInt( scale );
                }
            }

        double cos45 = Math.cos( Math.toRadians( 45 ) );

        // Now perform the diamond square sequences until we've
        // finished.
        int step = seedStep;
        double displacement = (scale / 2) * roughness;

        // How many iterations will we have?  It's the exponent
        // in the equation:
        // 2 ^ x = step
        // or... log2(step)
        double count = Math.log( step ) / Math.log( 2 );

        // In count iterations we want displacement to be 1 or 0.
        // In other words:
        // x ^ count = displacement.
        // logx(displacement) = count
        // ln(displacement) / ln(x) = count
        // 1 / ln(x) = count / ln(displacement)
        // ln(x) = ln(displacement) / count
        //
        // Since: ln(x) = y  is the same as e ^ y = x
        // Then:
        // e ^ (ln(displacement) / count) = x
        //count -= 6;
        count += roughnessBias;
        double displacementStep = Math.exp( Math.log(displacement) / count );

        boolean doElevFactor = false;

        while( step > 1 )
            {
            int halfStep = step / 2;
            //double halfDisp = displacement / 2;

            // First do the squares by calculating a center
            // point height relative to the average of the
            // four corner heights.
            int squareDisp = (int)displacement;
            int halfSqDisp = squareDisp / 2;
            for( int x = 0; x < mapSize; x += step )
                {
                for( int y = 0; y < mapSize; y += step )
                    {
                    int nw = map[y][x];
                    int ne = map[y][x + step];
                    int sw = map[y + step][x];
                    int se = map[y + step][x + step];

                    int average = (nw + ne + sw + se) / 4;
                    int d = squareDisp;

                    // Modify the displacement so that rougher
                    // and higher terrain tends to get rougher and
                    // flatter and lower terrain tends to stay flatter.

                    // Right now we'll just do higher.
                    // As elevation approaches 0 we want the roughness
                    // to be less exagerated.  As elevation gets higher
                    // we want the displacement to be much more exagerated.
                    // I think we want to try a pow(2) curve.
                    if( doElevFactor )
                        {
                        int eFactor = (maxHeight * 2 / 3) + (average * 1 / 3);
                        d = (d * eFactor) / (maxHeight);
                        }
                    int hd = d >> 1;

                    int rise = (d > 0) ? rand.nextInt( d ) - hd : 0;
//if( x == 512 )
//    System.out.println( "sqr-> d:" + d + "  hd:" + hd + "  rise:" + rise + " nw:" + nw + " ne:" + ne + " sw:" + sw + " se:" + se + "  avg:" + average );
                    map[y + halfStep][x + halfStep] = average + rise;
                    }
                }

            // We reduce the displacement for the diamond step because
            // the distance is shorter.
            // This first one makes for rougher more interesting terrain
            // but the tile points are more visible.  Easier to just up the bias
            // for more roughness.
            //int diamondDisp = (int)Math.round(displacement);
            int diamondDisp = (int)Math.round(displacement * cos45);
            int halfDmdDisp = diamondDisp / 2;

            // Now calculate the diamonds to find the mid-points of the tile
            // edges.  This is the displacement of the average of two tile
            // corners and two tile centers from this pass.  We also wrap...
            // so when we go off the edge of the map we get values from the
            // opposite edge.
            for( int x = 0; x < mapSize; x += step )
                {
                for( int y = 0; y < mapSize; y += step )
                    {
                    // We have two diamonds per "tile"... the one
                    // extend right from the point and the one extending
                    // down.  We don't fill in values for the first row
                    // or column because we want our land to be bordered
                    // by sea.

                    if( y > 0 )
                        {
                        // Do the diamond to the right of us that extends into
                        // the tile above us
                        int previous = y - halfStep;
                        int n = map[previous][x + halfStep];
                        int s = map[y + halfStep][x + halfStep];
                        int e = map[y][x + step];
                        int w = map[y][x];

                        int average = (n + s + e + w) / 4;
                        int d = diamondDisp;

                        if( doElevFactor )
                            {
                            int eFactor = (maxHeight * 2 / 3) + (average * 1 / 3);
                            d = (d * eFactor) / (maxHeight);
                            }
                        int hd = d >> 1;

                        int rise = (d > 0) ? rand.nextInt( d ) - hd : 0;
//if( x == 512 )
//    System.out.println( "dmd1-> d:" + d + "  hd:" + hd + "  rise:" + rise  + " n:" + n + " s:" + s + " e:" + e + " w:" + w + "  avg:" + average );
                        map[y][x + halfStep] = average + rise;
                        }
                    else
                        {
                        // It's a partial but we'll also make sure that it is below
                        // sea level.  This ensures that we get an island while also
                        // keeping our islands from looking boxy
                        int s = map[y + halfStep][x + halfStep];
                        int e = map[y][x + step];
                        int w = map[y][x];

                        int average = (s + e + w) / 3;
                        int d = diamondDisp / 3; // dampened a bit at the edges
                        //int rise = (d > 0) ? rand.nextInt( d ) - (d/2) : 0;
                        int rise = (d > 0) ? rand.nextInt( d ) - (halfDmdDisp) : 0;
                        if( average + rise > 0 )
                            rise = 0;
                        if( average > 0 )
                            average = 0;
                        map[y][x + halfStep] = average + rise;
                        }

                    if( x > 0 )
                        {
                        // Do the tile to the bottom of us that extends into the
                        // tile to the left of us
                        int previous = x - halfStep;
                        int n = map[y][x];
                        int s = map[y + step][x];
                        int e = map[y + halfStep][x + halfStep];
                        int w = map[y + halfStep][previous];

                        int average = (n + s + e + w) / 4;

                        int d = diamondDisp;

                        if( doElevFactor )
                            {
                            int eFactor = (maxHeight * 2 / 3) + (average * 1 / 3);
                            d = (d * eFactor) / (maxHeight);
                            }

                        int hd = d >> 1;

                        int rise = (d > 0) ? rand.nextInt( d ) - hd : 0;
//if( x == 512 )
//    System.out.println( "dmd2-> d:" + d + "  hd:" + hd + "  rise:" + rise  + " n:" + n + " s:" + s + " e:" + e + " w:" + w + "  avg:" + average );
                        map[y + halfStep][x] = average + rise;
                        }
                    else
                        {
                        // It's a partial but we'll also make sure that it is below
                        // sea level.  This ensures that we get an island while also
                        // keeping our islands from looking boxy
                        int n = map[y][x];
                        int s = map[y + step][x];
                        int e = map[y + halfStep][x + halfStep];

                        int average = (n + s + e) / 3;
                        int d = diamondDisp / 3; // dampened a bit at the edges
                        //int rise = (d > 0) ? rand.nextInt( d ) - (d/2) : 0;
                        int rise = (d > 0) ? rand.nextInt( d ) - (halfDmdDisp) : 0;
                        if( average + rise > 0 )
                            rise = 0;
                        if( average > 0 )
                            average = 0;
                        map[y + halfStep][x] = average + rise;
                        }
                    }
                }

            // Setup for next pass
            step = halfStep;
            displacement = displacement / displacementStep;
            }

        return( result );
    }
}


