/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FractalUtils {
    static Logger log = LoggerFactory.getLogger(FractalUtils.class);
    
    /**
     *  Turn a specified value in an arbitrary range into the range of 0 to 1, unclamped. 
     */
    public static double normalize( double val, double min, double max ) {
        val = val - min;
        return val / (max - min);
    }    
    
    public static double clamp( double val, double min, double max ) {
        if( val < min ) {
            return min;
        }
        if( val > max ) {
            return max;
        }
        return val;
    }
    
    public static double reslope( double val, double exp, double min, double max ) {
        if( val <= min ) {
            return val;
        }
        if( val >= max ) {
            return val;
        }

        double range = max - min;
        double v = (val - min) / range;
        v = Math.pow(v, exp);
        return min + (v * range);
    }

    public static double mix( double value1, double value2, double mix ) {
        return value1 * (1.0 - mix) + value2 * mix;
    }
    
    public static double step( double edge, double val ) {            
        return val < edge ? 0 : 1;
    }
    
    public static double smoothStep( double edge1, double edge2, double val ) {
        val = (val - edge1) / (edge2 - edge1);
        if( val < 0 ) {
            //return 0;
            val = 0;
        } else if( val > 1 ) {
            //return 1;
            val = 1;
        }
        return val * val * (3.0 - 2.0 * val);
    }
}


