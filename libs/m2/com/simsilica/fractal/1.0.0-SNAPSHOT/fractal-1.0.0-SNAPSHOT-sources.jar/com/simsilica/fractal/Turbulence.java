/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import com.google.common.base.MoreObjects;

/**
 *  Similar to Turbulence except the absolute value of the noise
 *  is taken at each frequency iteration creating cloud-like seams
 *  in the resulting noise gradient.
 *
 *  @author    Paul Speed
 */
public class Turbulence implements Sampler {
 
    private Sampler noise;
    private double startingFrequency = 1.0;
    private int frequencyIterations = 5;
    private SamplerRange range = null;
    
    public Turbulence( Sampler noise ) {
        this(noise, 5);
    }

    public Turbulence( Sampler noise, int frequencyIterations ) {
        this.noise = noise;
        this.frequencyIterations = frequencyIterations; 
    }
    
    public void setStartingFrequency( double startingFrequency ) {
        this.startingFrequency = startingFrequency;
        this.range = null; 
    }
    
    public double getStartingFrequency() {
        return startingFrequency;
    }
    
    public void setFrequencyIterations( int frequencyIterations ) {
        this.frequencyIterations = frequencyIterations;
        this.range = null; 
    }
    
    public int getFrequencyIterations() {
        return frequencyIterations;
    }
    
    @Override
    public double getSample( double x, double y, double z ) {        
        double value = 0;
        double f = startingFrequency;
 
        for( int i = 0; i < frequencyIterations; i++ ) {
            double sample = Math.abs(noise.getSample(x * f, y * f, z * f)) / f;
            value += sample;
            f = f * 2;
        }
        
        return value;       
    }
    
    @Override
    public SamplerRange getRange() {
        if( range != null ) {
            return range;
        }

        double f = startingFrequency;
 
        double min = Math.abs(noise.getRange().getMin());
        double max = Math.max(min, Math.abs(noise.getRange().getMax()));
                
        double maxResult = 0;
        
        for( int i = 0; i < frequencyIterations; i++ ) {
            maxResult += max/f;
            f = f * 2;
        }
        return new SamplerRange(0, maxResult);        
    }
 
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("noise", noise)
            .add("startingFrequence", startingFrequency)
            .add("frequencyIterations", frequencyIterations)
            .toString();
    }
}

