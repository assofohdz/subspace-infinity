/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import javax.script.*;

import org.slf4j.*;

/**
 *  An elevation source that calls a groovy script for transformation.
 *  Convenient for prototyping but ultimately these should end up as
 *  concrete Java classes for performance, which are themselves likely
 *  a subclass of AbstractTransformSource.  The bindings passed to the
 *  script therefore match the projected fields of AbstractTransformSource
 *  to make it easier to cut-paste code from a script to a transform subclass.
 *
 *  @author    Paul Speed
 */
public class ScriptElevationSource implements ElevationSource {

    static Logger log = LoggerFactory.getLogger(ScriptElevationSource.class);

    private ElevationSource delegate;
    private double seaLevel = 64;
    private double maxElevation = 512 + 64;

    private ScriptEngine engine;
    private Bindings bindings;
    private CompiledScript transform;
    
    public ScriptElevationSource( ElevationSource delegate, String script ) {
        this.delegate = delegate;
        
        ScriptEngineManager factory = new ScriptEngineManager();
        this.engine = factory.getEngineByName("groovy");
        this.bindings = engine.createBindings();
        resetBindings();
        setScript(script);   
    }
    
    protected void resetBindings() {
        bindings.put("maxElevation", maxElevation);
        bindings.put("waterElevation", seaLevel);
    }  

    public void setScript( String script ) {
        try {
            this.transform = ((Compilable)engine).compile(script);
        } catch( ScriptException e ) {
            throw new IllegalArgumentException("Could not parse script:" + script, e);
        }
    }

    public double getElevation( double x, double y ) {
        double elevation = delegate.getElevation(x, y);
        try {
            bindings.put("y", elevation);
            Object result = transform.eval(bindings);
            if( result instanceof Number ) {
                elevation = ((Number)result).doubleValue();
            }
            return elevation;        
        } catch( ScriptException e ) {
            throw new RuntimeException("Error processing value:" + elevation, e);
        }
    }
}


