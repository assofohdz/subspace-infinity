/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import org.slf4j.*;

import com.google.common.base.MoreObjects;


/**
 *
 *
 *  @author    Paul Speed
 */
public class RidgeFractal implements Sampler {
    static Logger log = LoggerFactory.getLogger(RidgeFractal.class);
 
    private Sampler noise;
    private SamplerRange range;

    private double fractalIncrement = 0.5;
    private double lacunarity = 3.02;
    private int octaves = 6;
    private double offset = 0.86;
    private double threshold = 1.5;

    private int maxOctaves = 128;
    private double[] exponents = new double[maxOctaves];
 
    public RidgeFractal( Sampler noise ) {
        this.noise = noise;
        reinitialize();
    }
    
    protected void reinitialize() {
        for( int i = 0; i < maxOctaves; i++ ) {
            exponents[i] = Math.pow( lacunarity, -i * fractalIncrement );
        }
    }

    public void setFractalIncrement( double d ) {
        this.fractalIncrement = d;
        range = null;
    }

    public double getFractalIncrement() {
        return fractalIncrement;
    }

    /**
     *  Sets the gap between successive frequencies.
     */
    public void setLacunarity( double d ) {
        this.lacunarity = d;
        range = null;
    }

    public double getLacunarity() {
        return lacunarity;
    }

    /**
     *  Sets the number of frequences in the fBm.
     */
    public void setOctaves( int d ) {
        this.octaves = d;
        range = null;
    }

    public int getOctaves() {
        return octaves;
    }

    public void setOffset( double d ) {
        this.offset = d;
        range = null;
    }

    public double getOffset() {
        return offset;
    }

    @Override
    public double getSample( double x, double y, double z ) {

        // Get the first octave
        double signal = noise.getSample(x, y, z);

        // Get the absolute value of signal (this creates ridges)
        if( signal < 0.0 ) {
            signal = -signal;
        }

        // Invert and translate (note that "offset" should be ~= 1.0)
        signal = offset - signal;

        // Square the signal to increase sharpness of ridges
        signal *= signal;

        // Assign initial values
        double result = signal;
        double weight = 1.0;

        int i;
        for( i = 1; i < octaves; i++ ) {
            x *= lacunarity;
            y *= lacunarity;
            z *= lacunarity;

            // Weight successive contributions by previous signal
            weight = signal * threshold;

            if( weight > 1.0 )
                weight = 1.0;
            if( weight < 0.0 )
                weight = 0.0;

            signal = noise.getSample(x, y, z);

            if( signal < 0.0 )
                signal = -signal;

            signal = offset - signal;
            signal *= signal;

            // weight the contribution
            signal *= weight;

            result += signal * exponents[i];
        }

        return result;
    }

    @Override
    public SamplerRange getRange() {
        if( range != null ) {
            return range;
        }

        double min = noise.getRange().getMin();
        double max = noise.getRange().getMax();
        
        // Need to use the fractal calculation to figure out what real
        // min/max will be.  For now we will just estimate.
        // FIXME: implement proper range estimate
        
        return new SamplerRange(min, max);        
    }

    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("noise", noise)
            .add("fractalIncrement", fractalIncrement)
            .add("lacunarity", lacunarity)
            .add("octaves", octaves)
            .add("offset", offset)
            .add("threshold", threshold)
            .toString();
    }       
}


