/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import org.progeeks.map.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FractalElevationSource implements ElevationSource {

    private AbstractNoiseElevationGenerator[] generators;

    private ElevationData baseMap = new ElevationData(1024);
    private ElevationData resultData;
    
    private boolean flatten = false; 
    
    private int seaDepth = 64;
    private int maxTerrainHeight = 512;

    //private int seaDepth = 128;
    //private int maxTerrainHeight = 1024;

    public FractalElevationSource( AbstractNoiseElevationGenerator... generators ) {

        this.generators = generators;
        
        baseMap.setElevationOffset(0);
        baseMap.setElevationScale(1);
        generators[0].setSourceData(baseMap);

        ElevationData lastData = null;

        // Need to see if this is even needed anymore... and if so
        // see if we can slightly refactor the pg maps stuff to not
        // require it for purely random-sampled elevations.
        for( int i = 0; i < generators.length; i++ ) {
            ElevationGenerator eg = generators[i];
            if( lastData != null )
                eg.setSourceData( lastData );
            lastData = eg.getGeneratedData();
            eg.invalidate();
        }

        if( lastData == null ) {
            lastData = baseMap;
        }

        resultData = lastData;
    }

    public void setFlatten( boolean b ) {
        this.flatten = b;
    }

    /**
     *  Returns the raw fractal stacked value for the specified x/y.
     *  This has had no x,y resolution applied and applies no scaling
     *  on the results.
     */
    protected double getElevationRaw( double x, double y ) {

        // Note: here z is elevation like in most of the simulation/map world.
        double z = 0;
        int sourceScale = 1;
        int sourceOffset = 0;
        int sourceElevation = 0;

        for( AbstractNoiseElevationGenerator gen : generators ) {

            double scale = gen.getElevationScale();
            double offset = gen.getElevationOffset();

            int adjustedScale = sourceScale + (int)(scale + offset);
            int adjustedOffset = sourceOffset - (int)offset;

            double sourceZ = 0;
            if( gen.isAffected() ) {
                sourceZ = (z - sourceOffset)/sourceScale;
            }

            if( !gen.isAdditive() ) {
                z = (int)Math.round(gen.getLayeredElevation(x, y, sourceZ) * scale + offset);
            } else {
                z = sourceElevation + (int)Math.round(gen.getLayeredElevation(x, y, sourceZ) * scale + offset);
            }

            sourceScale = adjustedScale;
            sourceOffset = adjustedOffset;
            sourceElevation = (int)z;
        }

        return z;
    }

    public double getElevation( double x, double y ) {

/*if( x >= 0 && x <= 16 ) return 200;
if( y >= 0 && y <= 16 ) return 500;

if( Math.abs(x) >= 504 && Math.abs(x) <= 520 ) return 200;
if( Math.abs(y) >= 504 && Math.abs(y) <= 520 ) return 200;*/

        // This part should be parameterized
        //x = x - 512;
        //y = y - 512;
        x = (x/11.0) + 512;
        y = (y/11.0) + 512;

        //boolean flatten = false;

        double height = getElevationRaw(x, y);

        //int minElev = -64; // part below sea level
        //int maxElev = 512 + minElev; // part above sea level

        int minElev = -seaDepth; // part below sea level
        int maxElev = maxTerrainHeight + minElev; // part above sea level

        double maxMapElev = 20000.0;
        double minMapElev = -5000.0;

        if( height >= 0 ) {
            double t = height/maxMapElev; 
            double d = Math.min(1, t);
            if( t > 1 ) {
                d = d - (t - 1);
            }

            // flatten the curves a bit
            //double flatter = d * d; // * d;

            //d = (d + flatter) * 0.5;

            // One is too flat the other is not flat enough.  Probably we
            // want some remapped curve or something.  But let's see if we can
            // just change the domain of the flattening a bit.
            if( flatten && d < 0.5 ) {
                d = d * 2;
                d = d * d; // * d;
                // Commenting out the third * d does make the break between 0..0.5 and 0.5..1 a little
                // less obvious but it also unsmooths some of the low lands.
                // Maybe it's a good compromise until we can properly smooth some areas with the fractal
                // and work out a proper curve mapping.
                d = d * 0.5;
            }

            d = d * (maxElev - minElev) - minElev;
            return d;
        } else {
            //double d = 0; //Math.max(1, -height/1500.0) * minElev;
            //double d = Math.max(-minElev, height/1500.0 * minElev);
            double d = Math.min(1, height/minMapElev);

            d = 1 - d;
            //d = d * d * d * d * d; // exaggerate the curve
            //d = d * d * d; // exaggerate the curve
            //d = d * d;
            d = 1 - d;

            d = d * minElev - minElev;
            return d;
        }
    }
}


