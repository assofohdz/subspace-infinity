/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;


/**
 *
 *
 *  @author    Paul Speed
 */
public class SamplerRange {
    public static final SamplerRange INFINITY = new SamplerRange(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
    public static final SamplerRange POSITIVE_INFINITY = new SamplerRange(0, Double.POSITIVE_INFINITY);

    private double min;
    private double max;
    
    public SamplerRange( double min, double max ) {
        this.min = min;
        this.max = max;
    }
    
    public double getMin() {
        return min;
    }
    
    public double getMax() {
        return max;
    }

    public SamplerRange max( SamplerRange range ) {
        return new SamplerRange(Math.max(min, range.min), Math.max(max, range.max));
    }

    public SamplerRange add( SamplerRange range ) {
        // Add/subtract should be straight forward
        return new SamplerRange(min + range.min, max + range.max);
    }

    public SamplerRange subtract( SamplerRange range ) {
        // Add/subtract should be straight forward
        // Add, yes.  Subtract, no.  Negatives get added, positive
        // max may make min get smaller, etc.. 
        double a = min - range.min;
        double b = min - range.max;
        double c = max - range.min;
        double d = max - range.max; 
        return new SamplerRange(Math.min(Math.min(a, b), Math.min(c, d)),
                               Math.max(Math.max(a, b), Math.max(c, d)));
    }
 
    public SamplerRange mult( double val ) {
        return new SamplerRange(min * val, max * val);
    }
    
    public SamplerRange mult( SamplerRange range ) {
        // This is a strange one as the min/max spanning 0 can
        // do weird things.
        // There may be a short-circuit that allows fewer calculations
        // but this will catch everything.
        double a = min * range.min;
        double b = min * range.max;
        double c = max * range.min;
        double d = max * range.max;
        return new SamplerRange(Math.min(Math.min(a, b), Math.min(c, d)),
                               Math.max(Math.max(a, b), Math.max(c, d)));
    }

    public SamplerRange div( SamplerRange range ) {
        // Essentially just copying mult() and swapping the sign
        // as it makes my brain hurt to work out the combinatorics.
        double a = min / range.min;
        double b = min / range.max;
        double c = max / range.min;
        double d = max / range.max;
        return new SamplerRange(Math.min(Math.min(a, b), Math.min(c, d)),
                               Math.max(Math.max(a, b), Math.max(c, d)));
    }
    
    public static SamplerRange addRanges( Sampler... samplers ) {
        double min = samplers[0].getRange().min;
        double max= samplers[0].getRange().max;
        for( int i = 1; i < samplers.length; i++ ) {
            min += samplers[i].getRange().min;
            max += samplers[i].getRange().max;
        }
        return new SamplerRange(min, max); 
    }
    
    public static SamplerRange maxRanges( Sampler... samplers ) {
        double min = samplers[0].getRange().min;
        double max = samplers[0].getRange().max;
        for( int i = 1; i < samplers.length; i++ ) {
            min = Math.max(min, samplers[i].getRange().min);
            max = Math.max(max, samplers[i].getRange().max);
        }
        return new SamplerRange(min, max); 
    }
     
    @Override   
    public String toString() {
        return String.format("[%.1f, %.1f]", min, max); 
    }
}
