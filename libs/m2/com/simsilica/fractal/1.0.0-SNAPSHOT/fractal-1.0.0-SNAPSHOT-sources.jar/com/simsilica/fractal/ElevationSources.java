/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;


/**
 *  Default ElevationSource implementations.  Subject to change as we learn
 *  what's needed.
 *
 *  @author    Paul Speed
 */
public class ElevationSources {

    public static ElevationSource clamp( ElevationSource source, double min, double max ) {
        return new Clamp(source, min, max);
    }
 
    public static ElevationSource offset( ElevationSource source, double delta ) {
        return new Offset(source, delta);
    } 
 
    public static ElevationSource max( ElevationSource source1, ElevationSource source2 ) {
        return new MaxElevation(source1, source2);
    }
    
    /**
     *  Converts anything less than the threshold to the base value.
     */
    public static ElevationSource maxThreshold( ElevationSource source, double threshold, double replace ) {
        return new MaxThreshold(source, threshold, replace);
    }
 
    private static class MaxElevation implements ElevationSource {
        ElevationSource source1;
        ElevationSource source2;
        
        public MaxElevation( ElevationSource source1, ElevationSource source2 ) {
            if( source1 == null || source2 == null ) {
                throw new IllegalArgumentException("Delegate sources cannot be null");
            }
            this.source1 = source1;
            this.source2 = source2;
        }
        
        public double getElevation( double x, double y ) {
            return Math.max(source1.getElevation(x, y), source2.getElevation(x, y));
        }
    }
    
    private static class MaxThreshold implements ElevationSource {
        ElevationSource delegate;
        double threshold;
        double replace;
        
        public MaxThreshold( ElevationSource delegate, double threshold, double replace ) {
            if( delegate == null ) {
                throw new IllegalArgumentException("Delegate cannot be null");
            }
            this.delegate = delegate;
            this.threshold = threshold;
            this.replace = replace;
        } 
 
        public double getElevation( double x, double y ) {
            double val = delegate.getElevation(x, y);
            
            if( val < threshold ) {
                val = replace;
            }
            
            return val;
        }
    }  

    private static class Offset implements ElevationSource {
        ElevationSource delegate;
        double delta;
        
        public Offset( ElevationSource delegate, double delta ) {
            if( delegate == null ) {
                throw new IllegalArgumentException("Delegate cannot be null");
            }
            this.delegate = delegate;
            this.delta = delta;
        }
        
        public double getElevation( double x, double y ) {
            double val = delegate.getElevation(x, y);
            return val + delta;
        }
    }

    private static class Clamp implements ElevationSource {
        ElevationSource delegate;
        double min;
        double max;
        
        public Clamp( ElevationSource delegate, double min, double max ) {
            if( delegate == null ) {
                throw new IllegalArgumentException("Delegate cannot be null");
            }
            this.delegate = delegate;
            this.min = min;
            this.max = max;
        }
        
        public double getElevation( double x, double y ) {
            double val = delegate.getElevation(x, y);
            if( val < min ) {
                val = min;
            } else if( val > max ) {
                val = max;
            }
            return val; 
        }
    }
}
