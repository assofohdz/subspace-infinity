/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  Uses Voronoi style distance to random points to filter an input
 *  coordinate to the nearest feature point and uses that to sample
 *  the provided sampler.
 *
 *  @author    Paul Speed
 */
public class CellularFilter extends AbstractCellularSampler {
    static Logger log = LoggerFactory.getLogger(CellularNoise.class);

    private Sampler delegate;

    public CellularFilter( Sampler delegate ) {
        this(0, delegate);
    }

    public CellularFilter( long seed, Sampler delegate ) {
        super(seed, delegate.getRange());
        this.delegate = delegate;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("seed", getSeed())
            .add("delegate", delegate)
            .toString();
    }

    public double getSample( double x, double y, double z ) {
        double xf = x % 1.0;
        double zf = z % 1.0;
        double xCell = Math.floor(x);
        double zCell = Math.floor(z);

        double min = Double.POSITIVE_INFINITY;
        double xBest = 0;
        double zBest = 0;

        for( int i = -1; i <= 1; i++ ) {
            for( int j = -1; j <= 1; j++ ) {
                // Get the point in neighbor space... note it's
                // only fractional so we have to add back our offset.
                double xn = getRandomX(xCell + i, zCell + j) + i;
                double zn = getRandomZ(xCell + i, zCell + j) + j;

                // Now figure out the distance to our own point.
                double xd = xf - xn;
                double zd = zf - zn;

                double d = xd * xd + zd * zd;
                if( d < min ) {
                    min = d;
                    xBest = xn + xCell;
                    zBest = zn + zCell;
                }
            }
        }

        return delegate.getSample(xBest, 0, zBest);
    }
}
