/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import java.util.Random;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  A base class for turning sampler input into min distance feature
 *  data for random features.  There is a bit of math to go from x,z to
 *  a random feature point that is encapsulated here.
 *
 *  @author    Paul Speed
 */
public abstract class AbstractCellularSampler extends AbstractSampler {
    static Logger log = LoggerFactory.getLogger(CellularNoise.class);

    private long seed = 0;

    protected AbstractCellularSampler( long seed, double min, double max ) {
        super(min, max);
        this.seed = seed;
        initTable(seed);
    }

    protected AbstractCellularSampler( long seed, SamplerRange range ) {
        super(range);
        this.seed = seed;
        initTable(seed);
    }

    public long getSeed() {
        return seed;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("seed", seed)
            .toString();
    }

    /**
     *  A predictable random that can take a cell location in and return
     *  the consistent random point within that cell.  Note that the point
     *  is returned "cell relative", ie: just the fractional part.
     *  Translated from the random2() function in:
     *  https://thebookofshaders.com/12/
     */
    //protected Vec3d getPoint( double x, double z, Vec3d target ) {
    //    double dot1 = x * 127.1 + z * 311.7;
    //    double dot2 = x * 269.5 + z * 183.3;
    //    target.x = (Math.sin(dot1) * 43758.5453) % 1.0;
    //    target.z = (Math.sin(dot2) * 43758.5453) % 1.0;
    //    return target;
    //}

    // Split them out to avoid having a real object in the mix
 

    protected final double getOriginalRandomX( double x, double z ) {
        // Note: we modulo PI because Math.sin() may take 3-4x longer to run for
        // large numbers.  Doing this doesn't seem to change the value but increases
        // performance a LOT.
        double dot1 = (x * 127.1 + z * 311.7 + seed * 783.089) % Math.PI;
        return Math.abs((Math.sin(dot1) * 43758.5453) % 1.0);
    }

    protected final double getSimplifiedRandomX( double x, double z ) {
        // Note: we modulo PI because Math.sin() may take 3-4x longer to run for
        // large numbers.  Doing this doesn't seem to change the value but increases
        // performance a LOT.
        // 2023-02-23 - After taking this math apart a little more, the % PI
        // really does change the value because the noise we are interested in
        // is in the tiny bits.
        // Also, for some reason when I'm testing it now, the modulo is actually
        // slower than just passing it on to the sin(). 
        double dot1 = (x * 127.1 + z * 311.7 + seed * 783.089);// % Math.PI;
        double value = Math.sin(dot1) * 43758.5453;
        //if( value < 0 ) {
        //    value = -value;
        //}
        return value - (int)value; 
        //return Math.abs((Math.sin(dot1) * 43758.5453) % 1.0);
    }


    protected final double getOriginalRandomZ( double x, double z ) {
        double dot2 = (x * 269.5 + z * 183.3) % Math.PI;
        return Math.abs((Math.sin(dot2) * 43758.5453) % 1.0);
    }

    protected final double getSimplifiedRandomZ( double x, double z ) {
        // Without modulo, test scene loads in 2:43, in game at around the 1:00 mark.
        // With modulo, test scene loads in 3:30, in game at around the 1:05 mark.
        // Artistically speaking, one result seems no better than the other except
        // leaving out the modulo is technicaly "more correct" for the original algorithm.
        // I think for very extreme x or z it might be slower... but who can say?
        // Note: with no plateaus at all, that same scene loads in 1:06, in game about 0:24.
        double dot2 = (x * 269.5 + z * 183.3);// % Math.PI;
        double value = Math.sin(dot2) * 43758.5453;
        return value - (int)value; 
    }

    // We want to keep 53 bits of the long values to turn into doubles.
    // I borrowed that number from java.util.Random's nextDouble()
    private static final long DOUBLE_MASK = -1L >>> (64-53);
    private static final double DOUBLE_UNIT = (1.0 / (1L << 53)); 
    private static final int TABLE_SIZE = 65536;
    private static final int TABLE_MASK = 0xffff; //obviously must match table size    

    private final long[] randomTable = new long[TABLE_SIZE];
    
    private void initTable( long seed ) {
        // Let's see how many of these we have... size of the table is not free
        if( log.isTraceEnabled() ) {
            log.trace("initTable(" + seed + ")");
        }
        Random rand = new Random(seed);
        for( int i = 0; i < TABLE_SIZE; i++ ) {
            randomTable[i] = rand.nextLong();
        }
    }
    
    // Note: method still assumes that caller is chopping off the fraction of the arguments
    protected final double getRandomX( double x, double z ) {
        int index = (int)(x * 127.7 + z * 311.7);
        long val = randomTable[index & TABLE_MASK];

        // Rotate by the last 8 bits of x.  In the groovy tests, the size of the second
        // argument seemed to affect performance and 0xff seemed no worse than 0xffff
        // in actual results.        
        val = Long.rotateRight(val, (int)x & 0xff);

        // Turn the lower 53 bits into a double between 0 and 1.0
        return (val & DOUBLE_MASK) * DOUBLE_UNIT;        
    }
    
    // Note: method still assumes that caller is chopping off the fraction of the arguments
    protected final double getRandomZ( double x, double z ) {
        int index = (int)(x * 269.5 + z * 183.3);
        long val = randomTable[index & TABLE_MASK];
        
        val = Long.rotateRight(val, (int)z & 0xff);
        
        // Turn the lower 53 bits into a double between 0 and 1.0
        return (val & DOUBLE_MASK) * DOUBLE_UNIT;        
    }

}
