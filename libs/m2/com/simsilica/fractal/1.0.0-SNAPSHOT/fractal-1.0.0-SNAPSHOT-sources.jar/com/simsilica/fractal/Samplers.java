/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import java.util.Arrays;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.Vec3d;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Samplers {

    /**
     *  Creates a Sampler that returns a constant value.
     */
    public static Sampler constant( double value ) {
        return new Constant(value);
    }

    /**
     *  Creates a sampler that returns the dot product of the x,y,z value
     *  with the specified vector.
     */
    public static Sampler dot( Vec3d vec ) {
        return new Dot(vec);
    }

    /**
     *  Creates a sampler that returns the distance from the x,y,z value
     *  to the specified position.
     */
    public static Sampler distance( Vec3d pos ) {
        return new Distance(pos);
    }

    /**
     *  Creates a sampler that returns the distance from the x,y,z value
     *  to the specified position.
     */
    public static Sampler distance( double x, double y, double z ) {
        return distance(new Vec3d(x, y, z));
    }

    /**
     *  Creates a sampler that returns the abs() of whatever the delegate
     *  sampler returns.
     */
    public static Sampler abs( Sampler sampler ) {
        return new Abs(sampler);
    }

    /**
     *  Creates a sampler that returns 0 if the sampler value is less than
     *  the edge value and 1 otherwise.  This is similar to the GLSL step
     *  function except that it works continuously over the specified sampler.
     */
    public static Sampler step( double edge, Sampler sampler ) {
        return new Step(edge, sampler);
    }

    /**
     *  Creates a sampler that returns 0 if the sampler value is less than
     *  the edge value and 1 otherwise.  This is similar to the GLSL step
     *  function except that it works continuously over the specified sampler
     *  and the edge value is also continuous.
     */
    public static Sampler step( Sampler edge, Sampler sampler ) {
        return new ParamStep(edge, sampler);
    }

    /**
     *  Creates a sampler that returns 0 if the sampler value is less than
     *  the edge1 value and 1 if the value is greater than the edge2 value, with a
     *  smooth curve transition between.  This is similar to the GLSL smoothstep
     *  function except that it works continuously over the specified sampler.
     */
    public static Sampler smoothStep( double edge1, double edge2, Sampler sampler ) {
        return new SmoothStep(edge1, edge2, sampler);
    }

    /**
     *  Creates a sampler that returns 0 if the sampler value is less than
     *  the edge1 value and 1 if the value is greater than the edge2 value, with a
     *  smooth curve transition between.  This is similar to the GLSL smoothstep
     *  function except that it works continuously over the specified sampler
     *  and the edge value is also continuous.
     */
    public static Sampler smoothStep( Sampler edge1, Sampler edge2, Sampler sampler ) {
        return new ParamSmoothStep(edge1, edge2, sampler);
    }

    public static Sampler clamp( Sampler sampler, double min, double max ) {
        return new Clamp(sampler, min, max);
    }

    public static Sampler clamp( Sampler sampler, Sampler min, Sampler max ) {
        return new ParamClamp(sampler, min, max);
    }

    /**
     *  A form or clamping that will reflect the values outside of the range
     *  instead of simply clamping them.  For example, if max is 1.0 and the
     *  value is 1.1 then the overage is subtracted from 1.0 (overage = 1.1 - 1.0,
     *  result = 1.0 - overage) leaving 0.9.
     */
    public static Sampler reflect( Sampler sampler, double min, double max ) {
        return new Reflect(sampler, min, max);
    }

    public static Sampler reflect( Sampler sampler, Sampler min, Sampler max ) {
        return new ParamReflect(sampler, min, max);
    }

    /**
     *  Like clamp except anything outside of the range is brought down to 0;
     */
    public static Sampler clip( Sampler sampler, double min, double max ) {
        return new Clip(sampler, min, max);
    }

    public static Sampler clip( Sampler sampler, Sampler min, Sampler max ) {
        return new ParamClip(sampler, min, max);
    }

    public static Sampler modulo( Sampler sampler, double modulo ) {
        return new Modulo(sampler, modulo);
    }

    /**
     *  Returns a resampled view of the specified sampler scaled by xScale, yScale, and zScale.
     */
    public static Sampler resample( Sampler source, double xScale, double yScale, double zScale ) {
        return new Resampler(source, xScale, yScale, zScale);
    }

    public static Sampler resample( Sampler source, Sampler xScale, Sampler yScale, Sampler zScale ) {
        return new ParamResampler(source, xScale, yScale, zScale);
    }

    /**
     *  Returns an offset view of the specified sampler offset by xOffset, yOffset, and zOffset.
     */
    public static Sampler offset( Sampler source, double xOffset, double yOffset, double zOffset ) {
        return new Offset(source, xOffset, yOffset, zOffset);
    }

    public static Sampler offset( Sampler source, Sampler xOffset, Sampler yOffset, Sampler zOffset ) {
        return new ParamOffset(source, xOffset, yOffset, zOffset);
    }

    /**
     *  Returns a rescaled view of the specified sampler where all
     *  getSample() calls are scaled by the specified scale value.
     */
    public static Sampler scale( Sampler source, double scale ) {
        return new Scaler(source, scale);
    }

    public static Sampler scale( Sampler source, Sampler scale ) {
        // No difference between scale() and mult() in this case
        // except clarity.
        return new Multiply(source, scale);
    }

    /**
     *  Multiplies the output of one sampler by another.
     */
    public static Sampler mult( Sampler source1, Sampler source2 ) {
        return new Multiply(source1, source2);
    }

    public static Sampler div( Sampler source1, Sampler source2 ) {
        return new Divide(source1, source2);
    }

    public static Sampler add( Sampler source1, Sampler source2 ) {
        return new Add(source1, source2);
    }

    public static Sampler add( Sampler... sources ) {
        return new MultiAdd(sources);
    }

    public static Sampler subtract( Sampler source1, Sampler source2 ) {
        return new Subtract(source1, source2);
    }

    public static Sampler max( Sampler source1, Sampler source2 ) {
        return new Max(source1, source2);
    }

    public static Sampler max( Sampler... sources ) {
        return new MultiMax(sources);
    }

    public static Sampler pow( Sampler source, double pow ) {
        return new Pow(source, pow);
    }

    public static Sampler pow( Sampler source, Sampler pow ) {
        return new ParamPow(source, pow);
    }

    /**
     *  Like pow() except it always keeps the original sign of the
     *  source value.  This allows for flatting of lower values near 0
     *  and exaggerating higher values if the source is in range -1..1
     */
    public static Sampler reslope( Sampler source, double pow, double min, double max ) {
        return new Reslope(source, pow, min, max);
    }

    public static Sampler reslope( Sampler source, Sampler pow ) {
        return new ParamReslope(source, pow);
    }

    /**
     *  Returns the sine value for the value returned by the
     *  specified sampler for whatever input x,y,z value.  A common
     *  use case would be to pass dot(Vec3d.UNIT_X) or dot(Vec3d.UNIT_Z)
     *  as the theta sampler argument.
     */
    public static Sampler sin( Sampler theta ) {
        return new SinSampler(theta);
    }

    private static class Constant extends AbstractSampler {
        private double value;
        private SamplerRange range;

        public Constant( double value ) {
            super(value, value);
            this.value = value;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return value;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("value", value)
                .add("range", range)
                .toString();
        }
    }

    private static class Dot extends AbstractSampler {
        private Vec3d vec;

        public Dot( Vec3d vec ) {
            super(SamplerRange.INFINITY);
            this.vec = vec;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return vec.dot(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("vec", vec)
                .toString();
        }
    }

    private static class Distance extends AbstractSampler {
        private Vec3d pos;

        public Distance( Vec3d pos ) {
            super(SamplerRange.POSITIVE_INFINITY);
            this.pos = pos;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return pos.distance(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("pos", pos)
                .toString();
        }
    }

    private static class Abs extends AbstractSampler {
        private Sampler delegate;

        public Abs( Sampler delegate ) {
            super(0, delegate.getRange().getMax());
            this.delegate = delegate;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return Math.abs(delegate.getSample(x, y, z));
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .toString();
        }
    }

    private static class Step extends AbstractSampler {
        private Sampler delegate;
        private double edge;

        public Step( double edge, Sampler delegate ) {
            super(0, 1);
            this.delegate = delegate;
            this.edge = edge;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            return val < edge ? 0 : 1;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("edge", edge)
                .toString();
        }
    }

    private static class ParamStep extends AbstractSampler {
        private Sampler delegate;
        private Sampler edge;

        public ParamStep( Sampler edge, Sampler delegate ) {
            super(0, 1);
            this.delegate = delegate;
            this.edge = edge;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            double e = edge.getSample(x, y, z);
            return val < e ? 0 : 1;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("edge", edge)
                .toString();
        }
    }

    private static class SmoothStep extends AbstractSampler {
        private Sampler delegate;
        private double edge1;
        private double edge2;

        public SmoothStep( double edge1, double edge2, Sampler delegate ) {
            super(0, 1);
            this.delegate = delegate;
            this.edge1 = edge1;
            this.edge2 = edge2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            // From GLSL:
            // genType t;  /* Or genDType t; */
            // t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
            // return t * t * (3.0 - 2.0 * t);

            double val = delegate.getSample(x, y, z);
            val = (val - edge1) / (edge2 - edge1);
            if( val < 0 ) {
                val = 0;
            } else if( val > 1 ) {
                val = 1;
            }
            return val * val * (3.0 - 2.0 * val);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("edge1", edge1)
                .add("edge2", edge2)
                .toString();
        }
    }

    private static class ParamSmoothStep extends AbstractSampler {
        private Sampler delegate;
        private Sampler edge1;
        private Sampler edge2;

        public ParamSmoothStep( Sampler edge1, Sampler edge2, Sampler delegate ) {
            super(0, 1);
            this.delegate = delegate;
            this.edge1 = edge1;
            this.edge2 = edge2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            double e1 = edge1.getSample(x, y, z);
            if( val < e1 ) {
                return e1;
            }
            double e2 = edge2.getSample(x, y, z);

            val = (val - e1) / (e2 - e1);
            if( val < 0 ) {
                val = 0;
            } else if( val > 1 ) {
                val = 1;
            }
            return val * val * (3.0 - 2.0 * val);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("edge1", edge1)
                .add("edge2", edge2)
                .toString();
        }
    }

    // Note: I know this could be replaced with ParamResampler
    // and constant() arguments but I feel like having the flattened
    // version might be faster when we can get away with it.
    private static class Resampler extends AbstractSampler {
        private Sampler source;
        private double xScale;
        private double yScale;
        private double zScale;

        public Resampler( Sampler source, double xScale, double yScale, double zScale ) {
            // We might subsample or supersample y but we don't actually
            // change the range of results over source
            super(source.getRange());
            this.source = source;
            this.xScale = xScale;
            this.yScale = yScale;
            this.zScale = zScale;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return source.getSample(x * xScale, y * yScale, z * zScale);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source", source)
                .add("xScale", xScale)
                .add("yScale", yScale)
                .add("zScale", zScale)
                .toString();
        }
    }

    private static class ParamResampler extends AbstractSampler {
        private Sampler source;
        private Sampler xScale;
        private Sampler yScale;
        private Sampler zScale;

        public ParamResampler( Sampler source, Sampler xScale, Sampler yScale, Sampler zScale ) {
            // We might subsample or supersample y but we don't actually
            // change the range of results over source
            super(source.getRange());
            this.source = source;
            this.xScale = xScale;
            this.yScale = yScale;
            this.zScale = zScale;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double xs = xScale.getSample(x, y, z);
            double ys = yScale.getSample(x, y, z);
            double zs = zScale.getSample(x, y, z);
            return source.getSample(x * xs, y * ys, z * zs);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source", source)
                .add("xScale", xScale)
                .add("yScale", yScale)
                .add("zScale", zScale)
                .toString();
        }
    }

    // Note: I know this could be replaced with ParamOffset
    // and constant() arguments but I feel like having the flattened
    // version might be faster when we can get away with it.
    private static class Offset extends AbstractSampler {
        private Sampler source;
        private double xOffset;
        private double yOffset;
        private double zOffset;

        public Offset( Sampler source, double xOffset, double yOffset, double zOffset ) {
            // we sample from different locations but we don't change the range
            // of source
            super(source.getRange());
            this.source = source;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
            this.zOffset = zOffset;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return source.getSample(x + xOffset, y + yOffset, z + zOffset);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source", source)
                .add("xOffset", xOffset)
                .add("yOffset", yOffset)
                .add("zOffset", zOffset)
                .toString();
        }
    }

    private static class ParamOffset extends AbstractSampler {
        private Sampler source;
        private Sampler xOffset;
        private Sampler yOffset;
        private Sampler zOffset;

        public ParamOffset( Sampler source, Sampler xOffset, Sampler yOffset, Sampler zOffset ) {
            // we sample from different locations but we don't change the range
            // of source
            super(source.getRange());
            this.source = source;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
            this.zOffset = zOffset;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double xo = xOffset.getSample(x, y, z);
            double yo = yOffset.getSample(x, y, z);
            double zo = zOffset.getSample(x, y, z);
            return source.getSample(x + xo, y + yo, z + zo);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source", source)
                .add("xOffset", xOffset)
                .add("yOffset", yOffset)
                .add("zOffset", zOffset)
                .toString();
        }
    }

    // Note: I know this could be replaced with Multiplier
    // and a constant() argument but I feel like having the flattened
    // version might be faster when we can get away with it.
    private static class Scaler extends AbstractSampler {
        private Sampler source;
        private double scale;

        public Scaler( Sampler source, double scale ) {
            super(source.getRange().mult(scale));
            this.source = source;
            this.scale = scale;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return scale * source.getSample(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source", source)
                .add("scale", scale)
                .toString();
        }
    }

    private static class Multiply extends AbstractSampler {
        private Sampler source1;
        private Sampler source2;

        public Multiply( Sampler source1, Sampler source2 ) {
            super(source1.getRange().mult(source2.getRange()));
            this.source1 = source1;
            this.source2 = source2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double v = source1.getSample(x, y, z);
            if( v == 0 ) {
                return 0;
            }
            return v * source2.getSample(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source1", source1)
                .add("source2", source2)
                .toString();
        }
    }

    private static class Divide extends AbstractSampler {
        private Sampler source1;
        private Sampler source2;

        public Divide( Sampler source1, Sampler source2 ) {
            super(source1.getRange().div(source2.getRange()));
            this.source1 = source1;
            this.source2 = source2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double v = source1.getSample(x, y, z);
            if( v == 0 ) {
                return 0;
            }
            return v / source2.getSample(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source1", source1)
                .add("source2", source2)
                .toString();
        }
    }

    private static class Add extends AbstractSampler {
        private Sampler source1;
        private Sampler source2;

        public Add( Sampler source1, Sampler source2 ) {
            super(source1.getRange().add(source2.getRange()));
            this.source1 = source1;
            this.source2 = source2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return source1.getSample(x, y, z) + source2.getSample(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source1", source1)
                .add("source2", source2)
                .toString();
        }
    }

    private static class MultiAdd extends AbstractSampler {
        private Sampler[] samplers;

        public MultiAdd( Sampler[] samplers ) {
            super(SamplerRange.addRanges(samplers));
            this.samplers = samplers;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double result = 0;
            for( Sampler s : samplers ) {
                result += s.getSample(x, y, z);
            }
            return result;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("samplers", Arrays.asList(samplers))
                .toString();
        }
    }

    private static class Subtract extends AbstractSampler {
        private Sampler source1;
        private Sampler source2;

        public Subtract( Sampler source1, Sampler source2 ) {
            super(source1.getRange().subtract(source2.getRange()));
            this.source1 = source1;
            this.source2 = source2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return source1.getSample(x, y, z) - source2.getSample(x, y, z);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source1", source1)
                .add("source2", source2)
                .toString();
        }
    }

    private static class Pow extends AbstractSampler {
        private Sampler delegate;
        private double pow;

        public Pow( Sampler delegate, double pow ) {
            super(0, 1);
            this.delegate = delegate;
            this.pow = pow;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            return Math.pow(val, pow);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("pow", pow)
                .toString();
        }
    }

    private static class ParamPow extends AbstractSampler {
        private Sampler delegate;
        private Sampler pow;

        public ParamPow( Sampler delegate, Sampler pow ) {
            super(0, 1);
            this.delegate = delegate;
            this.pow = pow;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            double p = pow.getSample(x, y, z);
            return Math.pow(val, p);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("pow", pow)
                .toString();
        }
    }

    private static class Reslope extends AbstractSampler {
        private Sampler delegate;
        private double pow;
        private double min;
        private double max;

        public Reslope( Sampler delegate, double pow, double min, double max ) {
            super(0, 1);
            this.delegate = delegate;
            this.pow = pow;
            this.min = min;
            this.max = max;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            if( val <= min ) {
                return val;
            }
            if( val >= max ) {
                return val;
            }

            double range = max - min;
            double v = (val - min) / range;
            v = Math.pow(v, pow);

            return min + (v * range);

            //double result = Math.pow(val, pow) * Math.signum(val);
            //if( result > 0 && val < 0 || result < 0 && val > 0 ) {
            //    return -result;
            //}
            //return result;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("pow", pow)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class ParamReslope extends AbstractSampler {
        private Sampler delegate;
        private Sampler pow;

        public ParamReslope( Sampler delegate, Sampler pow ) {
            super(0, 1);
            this.delegate = delegate;
            this.pow = pow;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double val = delegate.getSample(x, y, z);
            double p = pow.getSample(x, y, z);
            double result = Math.pow(val, p);
            if( result > 0 && val < 0 || result < 0 && val > 0 ) {
                return -result;
            }
            return result;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("delegate", delegate)
                .add("pow", pow)
                .toString();
        }
    }

    private static class Max extends AbstractSampler {
        private Sampler source1;
        private Sampler source2;

        public Max( Sampler source1, Sampler source2 ) {
            super(source1.getRange().max(source2.getRange()));
            this.source1 = source1;
            this.source2 = source2;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            return Math.max(source1.getSample(x, y, z), source2.getSample(x, y, z));
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("source1", source1)
                .add("source2", source2)
                .toString();
        }
    }

    private static class MultiMax extends AbstractSampler {
        private Sampler[] samplers;

        public MultiMax( Sampler[] samplers ) {
            super(SamplerRange.maxRanges(samplers));
            this.samplers = samplers;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double result = Double.NEGATIVE_INFINITY;
            for( Sampler s : samplers ) {
                result = Math.max(result, s.getSample(x, y, z));
            }
            return result;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("samplers", Arrays.asList(samplers))
                .toString();
        }
    }

    private static class Clamp extends AbstractSampler {
        private Sampler sampler;
        private double min;
        private double max;

        public Clamp( Sampler sampler, double min, double max ) {
            super(min, max);
            this.sampler = sampler;
            this.min = min;
            this.max = max;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            if( val < min ) {
                return min;
            } else if( val > max ) {
                return max;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class ParamClamp extends AbstractSampler {
        private Sampler sampler;
        private Sampler min;
        private Sampler max;

        public ParamClamp( Sampler sampler, Sampler min, Sampler max ) {
            super(min.getRange().getMin(), max.getRange().getMax());
            this.sampler = sampler;
            this.min = min;
            this.max = max;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            double check = min.getSample(x, y, z);
            if( val < check ) {
                return check;
            }
            check = max.getSample(x, y, z);
            if( val > check ) {
                return check;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class Reflect extends AbstractSampler {
        private Sampler sampler;
        private double min;
        private double max;
        private double range;

        public Reflect( Sampler sampler, double min, double max ) {
            super(min, max);
            this.sampler = sampler;
            this.min = min;
            this.max = max;
            this.range = max - min;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            if( val < min ) {
                // Modulo with range to make sure we don't reflect
                // right out the top again
                double over = (min - val) % range;
                return min + over;
            } else if( val > max ) {
                double over = (val - max) % range;
                return max - over;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class ParamReflect extends AbstractSampler {
        private Sampler sampler;
        private Sampler min;
        private Sampler max;

        public ParamReflect( Sampler sampler, Sampler min, Sampler max ) {
            super(min.getRange().getMin(), max.getRange().getMax());
            this.sampler = sampler;
            this.min = min;
            this.max = max;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            double minVal = min.getSample(x, y, z);
            double maxVal = max.getSample(x, y, z);
            double range = maxVal - minVal;
            if( val < minVal ) {
                // Modulo with range to make sure we don't reflect
                // right out the top again
                double over = (minVal - val) % range;
                return minVal + over;
            } else if( val > maxVal ) {
                double over = (val - maxVal) % range;
                return maxVal - over;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class Modulo extends AbstractSampler {
        private Sampler sampler;
        private double modulo;

        public Modulo( Sampler sampler, double modulo ) {
            super(-modulo, modulo);
            this.sampler = sampler;
            this.modulo = modulo;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z) % modulo;
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("modulo", modulo)
                .toString();
        }
    }

    private static class Clip extends AbstractSampler {
        private Sampler sampler;
        private double min;
        private double max;

        public Clip( Sampler sampler, double min, double max ) {
            super(Math.min(0, min), Math.max(0, max));
            this.sampler = sampler;
            this.min = min;
            this.max = max;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            if( val < min ) {
                return 0;
            } else if( val > max ) {
                return 0;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class ParamClip extends AbstractSampler {
        private Sampler sampler;
        private Sampler min;
        private Sampler max;

        public ParamClip( Sampler sampler, Sampler min, Sampler max ) {
            super(Math.min(0, min.getRange().getMin()), Math.max(0, max.getRange().getMax()));
            this.sampler = sampler;
            this.min = min;
            this.max = max;
        }

        @Override
        public double getSample( double x, double y, double z ) {
            double val = sampler.getSample(x, y, z);
            double check = min.getSample(x, y, z);
            if( val < check ) {
                return 0;
            }
            check = max.getSample(x, y, z);
            if( val > check ) {
                return 0;
            }
            return val;
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("sampler", sampler)
                .add("min", min)
                .add("max", max)
                .toString();
        }
    }

    private static class SinSampler extends AbstractSampler {
        private Sampler theta;

        public SinSampler( Sampler theta ) {
            super(-1, 1);
            this.theta = theta;
        }

        @Override
        public final double getSample( double x, double y, double z ) {
            double value = theta.getSample(x, y, z);
            return Math.sin(value);
        }

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("theta", theta)
                .toString();
        }
    }
}
