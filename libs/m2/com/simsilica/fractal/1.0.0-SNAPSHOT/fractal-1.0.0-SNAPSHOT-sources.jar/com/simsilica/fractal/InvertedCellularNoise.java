/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fractal;

import org.slf4j.*;

/**
 *  A form of "cellular" noise using voronoi/worley noise, instead of
 *  returning the distance to the nearest feature, it returns the distance to
 *  the edge separating the two closest features.
 *
 *  @author    Paul Speed
 */
public class InvertedCellularNoise extends AbstractCellularSampler {
    static Logger log = LoggerFactory.getLogger(CellularNoise.class);
 
    private boolean simple = true;

    public InvertedCellularNoise() {
        this(0, true);
    } 
 
    public InvertedCellularNoise( long seed ) {
        this(seed, true);
    }

    public InvertedCellularNoise( boolean simple ) {
        this(0, simple);
    }
  
    public InvertedCellularNoise( long seed, boolean simple ) {
        super(seed, 0, 1);
        this.simple = simple;
    }

    public double getSample( double x, double y, double z ) {
        double xf = x % 1.0;
        double zf = z % 1.0;
        double xCell = Math.floor(x);
        double zCell = Math.floor(z);
 
//boolean debug = xCell == 1043520 && zCell == 1018112;

        // Each integer cell has its own feature.  We are trying to determine
        // in our cell, how far away we are from the line that separates our
        // feature from the nearest feature on the other side of us.  This
        // is a little different than the regular cellular stuff because we
        // could be much closer to some neighbor feature or we could be closest
        // to two features on the same side of us.
        //
        // Is it always going to be the case that the edge we are interested
        // in is between our cell and a neighor cell?  I don't think it's true.
        // Imagine the case where our feature is in the far corner and the
        // neighbor features near the opposite corner are very close to us.
        // We might be nearest to the line that splits those two features.
        //
        // If we are closer to two features on the same side of us... then aren't
        // we also closest to the edge between them?  Is that ever not the case?
        // I wish I had the math chops to prove it one way or the other... but let's 
        // see what it does.
        //
        // Actually, this article seems to agree with me on the approach: 
        // https://www.iquilezles.org/www/articles/voronoilines/voronoilines.htm
        //
        // They take it one step further to properly calculate what I was struggling
        // with.  Both the F2-F1 and the slightly more advanced approach produce results
        // that I can use for border detection.  If I use the actual distances for anything
        // then they look weird (though f2-f1 is 'better' for some things).
        // I will keep the article in my back pocket in case I want to implement proper
        // edge distances.  It uses a two pass approach: calculate the nearest point
        // then calculate the point nearest to that one... and it calculates the 
        // edge distance for every pair of points.
 
        double min = Double.POSITIVE_INFINITY;
        double nextMin = 0;
        double xBest = 0;
        double zBest = 0;
        double xNextBest = 0;
        double zNextBest = 0;
        
        
        // F2 - F1 is more straight forward, I guess.
        
        for( int i = -1; i <= 1; i++ ) {
            for( int j = -1; j <= 1; j++ ) {
                // Get the point in neighbor space... note it's
                // only fractional so we have to add back our offset.
                double xn = getRandomX(xCell + i, zCell + j) + i;
                double zn = getRandomZ(xCell + i, zCell + j) + j;
                
                // Now figure out the distance to our own point.
                double xd = xn - xf;
                double zd = zn - zf;
                
                double d = xd * xd + zd * zd;
                
                if( d < min ) {
                    nextMin = min;
                    xNextBest = xBest;
                    zNextBest = zBest;                    
                    min = d;
                    //xBest = xn;
                    //zBest = zn;
                    // If we keep the pixel-relative vector then our
                    // calculations later are easier
                    xBest = xd;
                    zBest = zd;
                } else if( d < nextMin ) {
                    nextMin = d;
                    //xNextBest = xn;
                    //zNextBest = zn;
                    xNextBest = xd;
                    zNextBest = zd;
                }
            }
        }        

        if( simple ) {
            return Math.abs(Math.sqrt(min) - Math.sqrt(nextMin));
        }

        // We want to know how far we are from the imaginary line between
        // best and nextBest.

        // Calculate a normalized vector between the two points
        double xDelta = (xNextBest - xBest);
        double zDelta = (zNextBest - zBest);
        double length = Math.sqrt(xDelta * xDelta + zDelta * zDelta);
        
        xDelta *= 1/length;
        zDelta *= 1/length;
        
        //
        //// And our relative vector from the base point of the line between
        //// the two points.
        //double xRel = xf - xBest;
        //double zRel = zf - zBest;
        //
        //// Dot product to project our point onto that line
        //double d = xRel * xDelta + zRel * zDelta;
        //
        //// length/2 is the midpoint of the line... so our distance
        //// to that is the distance to the orthogonal line between the two
        //// points.
        //return Math.abs(d - (length * 0.5));
        //
        // One of the nice things about having reinvented the wheel is that
        // we can factor back improvements from the pre-existing wheel.  In that
        // case, they showed that if we keep our best and next best vectors as
        // relative to our pixel coordinate then we don't need to subtract it
        // back out again like above.  They do some other funky short cuts that
        // I don't understand fully.
        // float d = dot(0.5*(a+b),normalize(b-a));
        //
        // a and b are both pixel-relative... so 0,0 is our pixel.  Ahah.
        // So the midpoint will also be pixel relative so dotting it with
        // normalized a->b is finding the distance of 0,0 from the midpoint.
        //
        double xmp = (xBest + xNextBest) * 0.5; 
        double zmp = (zBest + zNextBest) * 0.5; 
        double d = xmp * xDelta + zmp * zDelta; 
 
        // not sure how we're sure this is always positive and maybe we don't
        // care.       
        return d;
    }   
}
