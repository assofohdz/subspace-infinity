/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.*;

import com.google.common.collect.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Planner<A> {
    static Logger log = LoggerFactory.getLogger(Planner.class);

    private ActionRuleSet<A> rules;
    private PriorityQueue<Proposal<A>> pending = new PriorityQueue<>();
    private Proposal<A> result;

    //private Map<Map<String, Object>, String> visitedStates = new HashMap<>();
    private Map<Table<Object, Object, Object>, String> visitedStates = new HashMap<>();

    private Proposal<A> lastProposal;
    private List<Proposal<A>> lastBranches = new ArrayList<>();

    public Planner( ActionRuleSet<A> rules, PlanningContext rootContext, List<Condition> requirements ) {
        this.rules = rules;

        // Create the starting proposal with a dummy rule
        ActionRule<A> goal = new ActionRule<A>("goal").requires(requirements);
        pending.add(new Proposal<>(rootContext, goal));
    }

    protected Collection<ActionRule<A>> findActionRules( PlanningContext context, Condition condition ) {
//log.info("findActionRules(" + condition + ")");
        Set<ActionRule<A>> results = new HashSet<>();
        PropertyKey conditionKey = condition.getSourceKey();
        for( ActionRule<A> action : rules.getRules() ) {
//log.info("  checking:" + action.getName());
            for( ActionResult change : action.getChanges() ) {
//log.info("    checking:" + change + "  targetId:" + change.getTargetContextValue().getId());
                // notes on the branches below...
                // If we don't check the predicate for some conditions then we end up taking
                // a bunch of wrong paths that really pollute the space.  For example, if
                // "create dagger" wants to be at (Location(), "forge") then we end up hitting
                // every rule that could change the location, even if it doesn't take us to the
                // forge.
                // This is a legitimately real problem for rules that will pass values on from
                // other source values, though... which is why they skip the predicate.  However,
                // then they are just as likely to hit the same issue in a complicated rule set.
                //
                // The real problem was that I was getting wrong answers.  After some 'visit' checking
                // and stuff I had it down to only taking twice as many steps (throwing a bunch of
                // pending branches aways, of course) but was still getting the wrong answer as there
                // was an extra erroneous step at the beginning.  In an attempt to remove some noise,
                // I added a check to prevent a rule from branching back to itself.  (May ultimately
                // be a mistake.)  That has side-stepped the problem but I think not really solved it.
                //
                // After digging, notes on the issue are below.  The 'visit' check was too broad
                // and accidentally pruning paths we wanted to take... unfortunately, this balloons
                // the search space a LOT.  So I'm putting back the predicate checks for when we
                // can do them.
                if( false ) {
                    // If we bypass change.satisfiesCondition() then we should at least do the
                    // key compatibility test
                    if( !change.getTargetKey().contains(conditionKey) ) {
                        continue;
                    }

                    // For parameterized planning, we don't necessarily know the value yet, only
                    // that we've potentially changed it.
//log.info("        MATCH");
                    results.add(action);
                    break;
                } else {
                    if( change.satisfiesCondition(context, condition) ) {
//log.info("        MATCH");
                        results.add(action);
                        // We will only add a particular action one time anyway so we might as well
                        // break out of the changes loop
                        break;
                    }
//log.info("        condition not satisfied");
                }
            }
            if( action.hasExpansionTo(condition.getSourceKey()) ) {
                results.add(action);
            }
        }
        return results;
    }

    public Proposal<A> getResult() {
        return result;
    }

    public Proposal<A> getLastProposal() {
        return lastProposal;
    }

    public List<Proposal<A>> getLastBranches() {
        return lastBranches;
    }

    public List<A> getPlan() {
        return result == null ? null : result.getPlan();
    }

    public boolean isDone() {
        return result != null || pending.isEmpty();
    }

    public boolean step( int max ) {
        for( int i = 0; i < max; i++ ) {
            if( step() ) {
                return true;
            }
        }
        return false;
    }

    public boolean step( int max, AtomicInteger count ) {
        for( int i = 0; i < max; i++ ) {
            count.incrementAndGet();
            if( step() ) {
                return true;
            }
        }
        return false;
    }

    protected boolean visited( Proposal<A> proposal, boolean warn ) {
        PlanningContext context = proposal.getPlanningContext();
        //Map<String, Object> state = context.getFlattenedValues();
        Table<Object, Object, Object> state = context.getFlattenedProperties();
        // I have some concerns about whether we should be checking the whole path
        // or just the local name.  The whole path is definitely safer but it does
        // not prevent looping back and forth over the same states with no change to
        // show for it.
        if( true ) {
            //state.put("proposalPath", proposal.getPath());
            state.put(".", "proposalPath", proposal.getPath());
        } else {
            // This should prevent looping if we revisit the same exact rule with the
            // same exact state.
            //state.put("proposalName", proposal.getActionRule().getName());
            state.put(".", "proposalName", proposal.getActionRule().getName());
        }
        //if( true ) {
        //    state.put("proposalPlan", proposal.getPlan());
        //}
        // Either including the proposal path or the proposal plan makes the visit check let
        // lots of bad things in.  But also, just the proposal name is too broad because we
        // end up eliminating good paths in favor of worse ones just because the other path
        // happened to be shorter at the time but produced the same state.
        //
        // Here is an example:
        // been here before:{
        //      Holding(right)=hammer1,
        //      Temperature(rod1)=NULL,
        //      ContainerContents(chest1)=[],
        //      Holding(left)=rod1,
        //      ContainerContents(inventory1)=[],
        //      proposalName=GoToForge,
        //      Location()=NULL}
        //  path:goal/CreateDagger/HeatRod/GoToForge
        //
        //  existing:[get rod from inventory]
        //  history:
        //      goal,
        //      goal/GetRodFromInventory,
        //      goal,
        //      goal/GetRodFromChest,
        //      goal/GetRodFromChest/GoToForge
        //
        //  skipping:[get rod from inventory]
        //  history:
        //      goal,
        //      goal/CreateDagger,
        //      goal/CreateDagger/GetRodFromInventory,
        //      goal/CreateDagger,
        //      goal/CreateDagger/HeatRod,
        //      goal/CreateDagger/HeatRod/GoToForge
        //
        // The one we are skipping is actually the better one but it has more steps.
        //
        // With a full path visit check, it takes 378 steps to solve but solves it correctly.
        // With the name only path visit check, it taks 57 steps to come up with almost the right
        // answer.
        //
        // One thing I wonder before I go to bed: is there some way we can skip rules
        // that are already satisfied somehow?  GetRodFromChest should be skippable if we
        // already have the item in hand.  Also probably if things like "container not empty"
        // could be defined I wonder if that helps.  Right now there is nothing that would fill
        // a container.  But anyway, surely we shouldn't try to grab a rod from a chest if we are
        // already holding one.  But this is somehow different than the normal 'search the rules'
        // style requirement.  A filter maybe.  "Don't explore this rule if this other thing is
        // already true."
        // unless(new Condition(Hold(left), {it == rod}); or whatever.

//System.out.println("   state:" + state);
        String existing = visitedStates.get(state);
        if( existing != null ) {
            if( warn ) {
                log.warn("*************** been here before:" + state + " path:" + proposal.getPath() + " existing:" + existing + " skipping:" + proposal.getPlan() + " history:" + proposal.getHistoryString());
            }
            return true;
        }
        visitedStates.put(state, String.valueOf(proposal.getPlan()) + " history:" + proposal.getHistoryString());
        return false;
    }

    public boolean step() {
        if( isDone() ) {
            throw new IllegalStateException("No more proposals to check.");
        }

//System.out.println("----------------");
//for( Proposal<A> p : pending ) {
//    System.out.println("  pending:" + p.toStateString());
//}
        Proposal<A> proposal = pending.poll();
log.info("----------------------------");
log.info("looking at proposal for:" + proposal.toStateString());
        if( true ) {
            while( visited(proposal, true) ) {
                //log.info("Skipping:" + proposal.toStateString());
                proposal = pending.poll();
                if( proposal == null ) {
                    return true;
                }
            }
        }
log.info("  open:" + proposal.getOpenConditionsString());
        while( proposal.isSatisfied() ) {
log.info("    pre-pop context:" + proposal.getPlanningContext());
log.info("    plan so far:" + proposal.getPlan());
            List<Proposal<A>> nextProps = proposal.pop();
            if( nextProps == null ) {
                // We're done
                result = proposal;
log.info("    result history:" + proposal.getHistoryString());
                return true;
            }
            if( nextProps.isEmpty() ) {
                // No valid branches from here... we're not 'done' overall but definitely
                // done with this proposal.  It's a dead end.
log.info("    dead end");
                return false;
            }
            if( nextProps.size() > 1 ) {
log.info("    popped expansion count:" + nextProps.size());
                // We're in an expansion so we'll just put them back on the pending queue and exit
                pending.addAll(nextProps);
                return false;
            }
            Proposal<A> next = nextProps.get(0);
log.info("    popped:" + next.toStateString());
log.info("      open:" + proposal.getOpenConditionsString());
            // Else keep looking for the next branch point
            proposal = next;
        }
log.info("  effective proposal for:" + proposal.getPath());
        PlanningContext context = proposal.getPlanningContext();
log.info("  current context:" + context);
log.info("  plan so far:" + proposal.getPlan());
log.info("  history:" + proposal.getHistoryString());

        this.lastProposal = proposal;

        // We only want to branch once per action rule so keep track of which ones
        // we've already branched from.
        Set<ActionRule<A>> visited = new HashSet<>();
        if( false ) {
            // Pretty sure we should not revisit the rule that brought us here
            visited.add(proposal.getActionRule());
        }

        lastBranches.clear();
        proposal.getOpenConditions().clear();
        for( Condition condition : proposal.getRequirements() ) {
            // Is this condition already true?
            if( condition.evaluate(context) ) {
                continue;
            }
            proposal.getOpenConditions().add(condition);
            for( ActionRule<A> actionRule : findActionRules(context, condition) ) {

                // If we can determine that the rule wouldn't change anything in the
                // current context, can we skip it?

                if( visited.add(actionRule) ) {
log.info("  branch:" + actionRule.getName() + "  because of:" + condition);
                    List<Proposal<A>> branches = proposal.extend(actionRule);
for( Proposal<A> branch : branches ) {
    log.info("      :" + branch.getPath() + "  history:" + branch.getHistoryPath());
}
                    pending.addAll(branches);
                    lastBranches.addAll(branches);
                }
            }
        }

        // If there are no more pending proposals then we're done but didn't find
        // a result.
        return pending.isEmpty();
    }
}

