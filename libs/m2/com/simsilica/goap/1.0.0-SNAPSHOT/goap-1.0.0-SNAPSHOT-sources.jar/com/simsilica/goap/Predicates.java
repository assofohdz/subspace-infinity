/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.function.Predicate;

import org.slf4j.*;

/**
 *  Some prebuild predicate implementations that have better toString()
 *  implementations and maybe some better comparison semantics.
 *  (If we need a place for more advanced Predicate implementations then
 *   this also might be a good place.)
 *
 *  @author    Paul Speed
 */
public class Predicates {
    static Logger log = LoggerFactory.getLogger(Predicates.class);

    /**
     *  Wraps an existing predicate and gives it a 'name' that will
     *  be used as its toString() value.
     */
    public static <T> Predicate<T> named( String name, Predicate<T> delegate ) {
        return new Named<>(name, delegate);
    }

    public static <T> Predicate<T> eq( T value ) {
        return new Equals<>(value);
    }

    public static <T extends Comparable> Compare<T> lessThan( T value ) {
        return new Compare<>(-1, false, value);
    }

    public static <T extends Comparable> Compare<T> greaterThan( T value ) {
        return new Compare<>(1, false, value);
    }

    public static <T extends Comparable> Compare<T> lessThanOrEq( T value ) {
        return new Compare<>(-1, true, value);
    }

    public static <T extends Comparable> Compare<T> greaterThanOrEq( T value ) {
        return new Compare<>(1, true, value);
    }

    public static <T extends Collection> Empty<T> empty() {
        return new Empty<>();
    }

    public static <T> Not<T> not( Predicate<T> delegate ) {
        return new Not<>(delegate);
    }

    public static <T> Not<T> notNull() {
        return new Not<>(eq(null));
    }

    public static <T extends Collection> Not<T> notEmpty() {
        return new Not<>(empty());
    }

    private static class Not<T> implements Predicate<T> {
        private Predicate<T> delegate;

        public Not( Predicate<T> delegate ) {
            this.delegate = delegate;
        }

        @Override
        public boolean test( T o ) {
            return !delegate.test(o);
        }

        @Override
        public String toString() {
            return "!" + delegate;
        }
    }

    private static class Empty<T> implements Predicate<T> {
        @Override
        public boolean test( T o ) {
            if( !(o instanceof Collection) ) {
                return true;
            }
            return ((Collection)o).isEmpty();
        }

        @Override
        public String toString() {
            return "isEmpty()";
        }
    }

    private static class Compare<T extends Comparable> implements Predicate<T> {
        private int signum;
        private boolean equals;
        private T value;

        public Compare( int signum, boolean equals, T value ) {
            if( signum != 0 && signum != -1 && signum != 1 ) {
                throw new IllegalArgumentException("Signum must be -1, 0, or 1");
            }
            this.signum = signum;
            this.equals = equals;
            this.value = value;
        }

        @Override
        @SuppressWarnings("unchecked")
        public boolean test( T o ) {
            if( o == null ) {
                return false;
            }
            // Compare the value of the supplied object to the predicate's value.
            // a < b  would be Predicates.lessThan(b)... so the predicate's own value is the
            // RHS.
            int comp = o.compareTo(value);
            if( comp == 0 && equals ) {
                return true;
            }
            return Math.signum(comp) == signum;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            switch( signum ) {
                case 0:
                    sb.append("==");
                    break;
                case 1:
                    sb.append(">");
                    break;
                case -1:
                    sb.append("<");
                    break;
            }
            if( equals ) {
                sb.append("=");
            }
            sb.append(value);
            return sb.toString();
        }
    }

    private static class Equals<T> implements Predicate<T> {
        private T value;

        public Equals( T value ) {
            this.value = value;
        }

        @Override
        public boolean test( T o ) {
            return Objects.equals(value, o);
        }

        @Override
        public String toString() {
            return "==" + value;
        }
    }

    private static class Named<T> implements Predicate<T> {
        private String name;
        private Predicate<T> delegate;

        public Named( String name, Predicate<T> delegate ) {
            this.name = name;
            this.delegate = delegate;
        }

        @Override
        public boolean test( T o ) {
            return delegate.test(o);
        }

        @Override
        public String toString() {
            return name;
        }
    }

}
