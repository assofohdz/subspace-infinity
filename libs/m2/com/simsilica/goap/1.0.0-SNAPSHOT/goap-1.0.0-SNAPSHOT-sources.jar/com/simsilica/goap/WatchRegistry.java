/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

/**
 *  Debugging tool for watching for context changes to particular objects.
 *
 *  @author    Paul Speed
 */
public class WatchRegistry {
    static Logger log = LoggerFactory.getLogger(WatchRegistry.class);

    private ListMultimap<Object, PropertyKeyListener> objectWatchers
        = MultimapBuilder.hashKeys().arrayListValues().build();

    public WatchRegistry() {
    }

    public void watchObject( Object object, PropertyKeyListener listener ) {
        objectWatchers.put(object, listener);
    }

    public void valueChanged( ContextValue key, Object value ) {
        if( log.isTraceEnabled() ) {
            log.trace("valueChanged(" + key + ", " + value + ")");
        }
    }

    public void valueChanged( PropertyKey key, Object object, Object value ) {
        if( log.isTraceEnabled() ) {
            log.trace("valueChanged(" + key + ", " + object + ", " + value + ")");
        }
        if( !objectWatchers.isEmpty() ) {
            for( PropertyKeyListener l : objectWatchers.get(object) ) {
                l.propertyChanged(key, object, value);
            }
        }
    }

    public interface ContextValueListener {
        public void valueChanged( ContextValue key, Object value );
    }

    public interface PropertyKeyListener {
        public void propertyChanged( PropertyKey key, Object object, Object value );
    }
}
