/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.function.BiFunction;

import org.slf4j.*;

import com.google.common.collect.*;

/**
 *  Holds the state of the world at a particular planning level.
 *
 *  @author    Paul Speed
 */
public class PlanningContext {

    static Logger log = LoggerFactory.getLogger(PlanningContext.class);

    // Used to keep track of cases where the world query itself returned null
    // so that we don't keep quering and we avoid drifting state.
    // Once a planner looks up a particular key, we want it to stay that value
    // unless overridden by the plan itself.  This avoids paradoxes where
    // rule1 sees 'foo'==null while rule2 sees 'foo' == someNewValue.
    // Actually, we also use this to allow child contexts to set a value to null
    // that overrides the parent.
    private static final Object NULL = new Object() {
        @Override
        public String toString() {
            return "NULL";
        }
    };

    private Object world;
    private WatchRegistry watchRegistry;
    private PlanningContext parentContext;
    private Map<String, Object> values = new HashMap<>();
    private BiFunction<Object, Object, Object> worldPropertyResolver;
    private Table<Object, Object, Object> objectProperties = HashBasedTable.create();

    public PlanningContext( Object world ) {
        this(world, (i, j) -> null);
    }

    public PlanningContext( Object world, BiFunction<Object, Object, Object> worldPropertyResolver ) {
        this.watchRegistry = new WatchRegistry();
        this.world = world;
        this.worldPropertyResolver = worldPropertyResolver;
    }

    public PlanningContext( PlanningContext parentContext ) {
        this.watchRegistry = parentContext.watchRegistry;
        this.parentContext = parentContext;
        this.worldPropertyResolver = parentContext.worldPropertyResolver;
        this.world = parentContext.world;
    }

    public WatchRegistry getWatchRegistry() {
        return watchRegistry;
    }

    public Object getWorld() {
        return world;
    }

    public PlanningContext getParentContext() {
        return parentContext;
    }

    protected Object safeCast( Object object, ContextValue value ) {
        if( object == NULL ) {
            return null;
        }
        return object;
    }

    public Object getProperty( ContextValue objectKey ) {
        if( log.isTraceEnabled() ) {
            log.trace("getProperty(" + objectKey + ")");
        }
        String key = objectKey.getContextId();
        Object result = values.get(key);
        if( result == NULL ) {
            // At this level, the value is overridden with null
            return null;
        }
        if( result != null ) {
            return result;
        }
        if( parentContext != null ) {
            return parentContext.getProperty(objectKey);
        }
        // Lookup the initial value and add it to the root
        // ...if we are here then WE are the root.
        result = objectKey.getWorldValue(world, this);
        values.put(key, result == null ? NULL : result);
        return result;
    }

    public Object getProperty( PropertyKey key ) {
        if( log.isTraceEnabled() ) {
            log.trace("getProperty(" + key + ")");
        }
        Object obj = getProperty(key.getObjectKey());
        if( key.getPropertyId() == null ) {
            return obj;
        }
        if( obj == null ) {
            return null;
        }
        if( key.getPropertyId() == null ) {
            return obj;
        }

        // Resolve the property from its most recent context possible... which
        // might be more recent than the object itself.
        Object result = resolveProperty(obj, key.getPropertyId());
        if( result != null ) {
            return result;
        }

        // Else ask the world... but don't remember the result.
        result = worldPropertyResolver.apply(obj, key.getPropertyId());
        return result;
    }

    public Object getObjectProperty( Object object, Object property ) {
        if( log.isTraceEnabled() ) {
            log.trace("getObjectProperty(" + object + ", " + property + ")");
        }
        if( object == null ) {
            return null;
        }
        if( property == null ) {
            return object;
        }
        // Resolve the property from its most recent context possible... which
        // might be more recent than the object itself.
        Object result = resolveProperty(object, property);
        if( result != null ) {
            return result;
        }

        // Else ask the world... but don't remember the result.
        result = worldPropertyResolver.apply(object, property);
        return result;
    }

    public void setProperty( ContextValue objectKey, Object value ) {
        if( log.isTraceEnabled() ) {
            log.trace("setProperty(" + objectKey + ", " + value + ")");
        }
        String key = objectKey.getContextId();
        values.put(key, value == null ? NULL : value);
        watchRegistry.valueChanged(objectKey, value);
    }

    public void setProperty( PropertyKey key, Object value ) {
        if( log.isTraceEnabled() ) {
            log.trace("setProperty(" + key + ", " + value + ")");
        }
        if( key.getPropertyId() == null ) {
            setProperty(key.getObjectKey(), value);
            return;
        }
        Object object = getProperty(key.getObjectKey());
        if( object == null || object == NULL ) {
            throw new IllegalArgumentException("No existing object for ContextValue:" + key.getObjectKey());
        }

        objectProperties.put(object, key.getPropertyId(), value == null ? NULL : value);
        watchRegistry.valueChanged(key, object, value);
    }

    protected Object resolveProperty( Object object, Object property ) {
        // Random notes about the current implementation:
        // Because we use the contextValue's id as our row key
        // for the object properties table we get a few nice features and
        // a few hidden gotchas.
        // "Nice" feature is that all contextValue's that refer to the same object
        // will get the same planning-only property values.  This can be good when
        // things about Container have already been overridden and/or resolved and
        // it's also used as a Holding or a Target or something.  The planning properties
        // will move around with it.
        // The consequence is that even if we clear a particular context value
        // Holding = null that it will remember the properties of that object if
        // it's set back again.  I think because of the ways contexts layer that this
        // should be ok but it's something to note.  (Actually, it's the 'most correct', I'd argue.)
        //
        // Finally, and this is potentially the biggest hidden gotcha.  If a particular
        // "game object"'s .equals() changes while we are using it then we will start
        // resolving properties strangely.  Game objects have to be identity-stable
        // with respect to their .equals() and .hashCode().  For things like an EntityId
        // this is a given.  For things like a GameObject, it might feel strange.

        Object result = objectProperties.get(object, property);
        if( result == NULL ) {
            return null;
        }
        if( result != null ) {
            return result;
        }
        if( parentContext != null ) {
            // Else see if the parent has it
            return parentContext.resolveProperty(object, property);
        }
        return null;
    }

    protected Map<String, Object> collectFlattenedValues( Map<String, Object> target ) {
        if( parentContext != null ) {
            // Set stuff from the parentContext first
            parentContext.collectFlattenedValues(target);
        }
        // Then override with local values
        for( Map.Entry<String, Object> e : values.entrySet() ) {
            target.put(e.getKey(), e.getValue());
            if( e.getValue() == null ) {
                continue;
            }
        }

        return target;
    }

    protected Map<String, Object> getFlattenedValues() {
        Map<String, Object> flat = collectFlattenedValues(new HashMap<>());

        // Now that we have the flattened values resolve only the appropriate
        // flattened object values.
        Map<String, Object> result = new HashMap<>(flat);
        for( Map.Entry<String, Object> e : flat.entrySet() ) {
            Map<Object, Object> props = objectProperties.row(e.getValue());
            for( Map.Entry<Object, Object> prop : props.entrySet() ) {
                result.put(e.getKey() + "(" + e.getValue() + ")." + prop.getKey(), prop.getValue());
            }
        }

        return result;
    }


    protected Table<Object, Object, Object> collectFlattenedProperties( Table<Object, Object, Object> flat ) {
        if( flat == null ) {
            flat = HashBasedTable.create();
        }
        if( parentContext != null ) {
            parentContext.collectFlattenedProperties(flat);
        }

        // Then override them with the local versions.  If table has a putIfAbsent() style method
        // then we could do it the other way around but I don't think it saves any time.
        for( Map.Entry<String, Object> e : values.entrySet() ) {
            flat.put("/", e.getKey(), e.getValue());
        }
        flat.putAll(objectProperties);

        return flat;
    }

    public Table<Object, Object, Object> getFlattenedProperties() {
        return collectFlattenedProperties(null);
    }

    public boolean hasSameValues( PlanningContext context ) {
        // Create a full-state flattened values that includes all of the root values
        // as well as the object properties, even if they'd normally be hidden.
        Table<Object, Object, Object> us = getFlattenedProperties();
        Table<Object, Object, Object> them = context.getFlattenedProperties();
        //log.info("us:" + us);
        //log.info("them:" + them);
        return us.equals(them);
    }

    @Override
    public String toString() {
        Map<String, Object> collected = getFlattenedValues();
        return getClass().getSimpleName() + collected;
    }
}
