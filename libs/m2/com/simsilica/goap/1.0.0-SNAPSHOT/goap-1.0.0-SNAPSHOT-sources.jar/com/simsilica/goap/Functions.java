/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.function.Function;

import org.slf4j.*;

/**
 *  Some prebuild predicate implementations that have better toString()
 *  implementations and maybe some better comparison semantics.
 *  (If we need a place for more advanced Function implementations then
 *   this also might be a good place.)
 *
 *  @author    Paul Speed
 */
public class Functions {
    static Logger log = LoggerFactory.getLogger(Functions.class);

    /**
     *  Wraps an existing predicate and gives it a 'name' that will
     *  be used as its toString() value.
     */
    public static <T,R> Function<T,R> fNamed( String name, Function<T,R> delegate ) {
        return new Named<>(name, delegate);
    }

    public static <T> Function<T,T> constant( T value ) {
        return new ConstantValue<>(value);
    }

    public static Function<Long, Long> addNumber( Long add ) {
        return new AddLong(add);
    }

    public static Function<Integer, Integer> addNumber( Integer add ) {
        return new AddInteger(add);
    }

    private static class AddLong implements Function<Long, Long> {
        private Long add;

        public AddLong( Long add ) {
            this.add = add;
        }

        @Override
        public Long apply( Long o ) {
            return o.longValue() + add.longValue();
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            if( add > 0 ) {
                sb.append("+" + add);
            } else {
                sb.append(add);
            }
            return sb.toString();
        }
    }

    private static class AddInteger implements Function<Integer, Integer> {
        private Integer add;

        public AddInteger( Integer add ) {
            this.add = add;
        }

        @Override
        public Integer apply( Integer o ) {
            return o.intValue() + add.intValue();
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            if( add > 0 ) {
                sb.append("+" + add);
            } else {
                sb.append(add);
            }
            return sb.toString();
        }
    }

    private static class ConstantValue<T> implements Function<T,T> {
        private T value;

        public ConstantValue( T value ) {
            this.value = value;
        }

        @Override
        public T apply( T o ) {
            return value;
        }

        @Override
        public String toString() {
            return "(" + value + ")";
        }
    }

    private static class Named<T,R> implements Function<T,R> {
        private String name;
        private Function<T,R> delegate;

        public Named( String name, Function<T,R> delegate ) {
            this.name = name;
            this.delegate = delegate;
        }

        @Override
        public R apply( T o ) {
            return delegate.apply(o);
        }

        @Override
        public String toString() {
            return name;
        }
    }

}
