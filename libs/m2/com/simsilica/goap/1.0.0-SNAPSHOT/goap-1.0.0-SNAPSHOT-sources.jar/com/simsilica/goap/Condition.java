/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.Objects;
import java.util.function.Predicate;

import org.slf4j.*;

/**
 *  Combines a context lookup ID with the predicate that can evaluate it.
 *
 *  @author    Paul Speed
 */
public class Condition {
    static Logger log = LoggerFactory.getLogger(Condition.class);

    private PropertyKey sourceValue;
    private PropertyKey testValue;
    private Predicate predicate;

    protected Condition( PropertyKey sourceValue, PropertyKey testValue, Predicate predicate ) {
        this.sourceValue = sourceValue;
        this.testValue = testValue;
        this.predicate = predicate;

        if( testValue != null && predicate != null ) {
            throw new IllegalArgumentException("Cannot have both a test value and a predicate. "
                + " testValue:" + testValue + " predicate:" + predicate);
        }
    }

    public Condition( PropertyKey sourceValue, Predicate predicate ) {
        this(sourceValue, null, predicate);
    }

    public Condition( PropertyKey sourceValue, PropertyKey testValue ) {
        this(sourceValue, testValue, null);
    }

    public Condition( ContextValue sourceValue, Predicate predicate ) {
        this(new PropertyKey(sourceValue), null, predicate);
    }

    public Condition( ContextValue sourceValue, Object property, Predicate predicate ) {
        this(new PropertyKey(sourceValue, property), predicate);
    }

    public Condition( ContextValue sourceValue, ContextValue testValue ) {
        this(new PropertyKey(sourceValue), new PropertyKey(testValue), null);
    }

    public PropertyKey getSourceKey() {
        return sourceValue;
    }

    public PropertyKey getTestKey() {
        return testValue;
    }

    public Predicate getPredicate() {
        return predicate;
    }

    public boolean evaluate( PlanningContext context ) {
        if( log.isTraceEnabled() ) {
            log.trace("evaluate() contextValue:" + sourceValue + " = " + context.getProperty(sourceValue));
        }
        boolean result;
        if( testValue != null ) {
            Object obj1 = context.getProperty(sourceValue);
            Object obj2 = context.getProperty(testValue);
            if( log.isTraceEnabled() ) {
                log.trace("  obj1:" + obj1 + " obj2:" + obj2);
            }
            result = Objects.equals(obj1, obj2);
        } else {
            Object obj = context.getProperty(sourceValue);
            if( log.isTraceEnabled() ) {
                log.trace("  obj:" + obj);
            }
            result = predicate.test(obj);
        }
        return result;
    }

    @Override
    public String toString() {
        if( testValue != null ) {
            return getClass().getSimpleName() + "{" + sourceValue + ", " + testValue + "}";
        }
        return getClass().getSimpleName() + "{" + sourceValue + ", " + predicate + "}";
    }
}
