/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.Objects;

import org.slf4j.*;

/**
 *  Idenfities a specific property of an object or the object itself if the property
 *  ID is null.
 *
 *  @author    Paul Speed
 */
public class PropertyKey {
    static Logger log = LoggerFactory.getLogger(PropertyKey.class);

    private ContextValue objectKey;
    private Object propertyId;

    public PropertyKey( ContextValue objectKey ) {
        this(objectKey, null);
    }

    public PropertyKey( ContextValue objectKey, Object propertyId ) {
        this.objectKey = objectKey;
        this.propertyId = propertyId;
    }

    public ContextValue getObjectKey() {
        return objectKey;
    }

    public Object getPropertyId() {
        return propertyId;
    }

    /**
     *  Returns true if the specified key is the same as this key or is a property
     *  of this key, meaning this key does not have a propertyId but both keys have
     *  the same objectKey.
     */
    public boolean contains( PropertyKey key ) {
        if( !Objects.equals(objectKey.getContextId(), key.objectKey.getContextId()) ) {
            return false;
        }
        if( propertyId == null ) {
            // And key property Id will pass
            return true;
        }
        // Otherwise, the property IDs must match, too.
        return Objects.equals(propertyId, key.propertyId);
    }

    @Override
    public String toString() {
        if( propertyId != null ) {
            return objectKey.getContextId() + "." + propertyId;
        }
        return objectKey.getContextId();
    }
}
