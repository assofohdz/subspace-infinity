/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.function.*;

import com.google.common.base.MoreObjects;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ActionResult {
    static Logger log = LoggerFactory.getLogger(ActionResult.class);

    private static final Function IDENTITY = Function.identity();

    private PropertyKey targetKey;
    private PropertyKey sourceKey;
    private Function mutator = IDENTITY;
    private BiFunction<PlanningContext, Object, Object> combiner;

    protected ActionResult( PropertyKey targetKey ) {
        if( targetKey == null ) {
            throw new IllegalArgumentException("Target key cannot be null");
        }
        this.targetKey = targetKey;
        this.sourceKey = targetKey;
    }

    public ActionResult( PropertyKey targetKey, PropertyKey sourceKey, Function mutator ) {
        if( targetKey == null ) {
            throw new IllegalArgumentException("Target key cannot be null");
        }
        this.targetKey = targetKey;
        this.sourceKey = sourceKey == null ? targetKey : sourceKey;
        this.mutator = mutator;
    }

    public ActionResult(PropertyKey targetKey, Function mutator ) {
        this(targetKey, null, mutator);
    }

    public ActionResult(PropertyKey targetKey, PropertyKey sourceKey) {
        this(targetKey, sourceKey, IDENTITY);
    }

    public ActionResult(ContextValue targetKey, Function mutator ) {
        this(new PropertyKey(targetKey), null, mutator);
    }

    public ActionResult(ContextValue targetKey, ContextValue sourceKey) {
        this(new PropertyKey(targetKey), new PropertyKey(sourceKey), IDENTITY);
    }

    public ActionResult(ContextValue targetKey, ContextValue sourceKey, Function mutator ) {
        this(new PropertyKey(targetKey), new PropertyKey(sourceKey), mutator);
    }

    public static ActionResult set( PropertyKey targetKey ) {
        return new ActionResult(targetKey);
    }

    public static ActionResult set( ContextValue objectKey ) {
        return set(objectKey, null);
    }

    public static ActionResult set( ContextValue objectKey, Object propertyId ) {
        return new ActionResult(new PropertyKey(objectKey, propertyId));
    }

    public ActionResult to( PropertyKey sourceKey ) {
        if( sourceKey == null ) {
            throw new IllegalArgumentException("Source key cannot be null");
        }
        this.sourceKey = sourceKey;
        return this;
        //return new ActionResult(targetKey, sourceKey, IDENTITY);
    }

    public ActionResult to( ContextValue objectKey ) {
        return to(objectKey, null);
    }

    public ActionResult to( ContextValue objectKey, Object propertyId ) {
        return to(new PropertyKey(objectKey, propertyId));
    }

    public ActionResult mutate( Function function ) {
        this.mutator = function;
        return this;
        //return new ActionResult(targetKey, sourceKey, function);
    }

    public ActionResult remove( PropertyKey propertyKey ) {
        this.combiner = (context, val) -> {
            Object child = context.getProperty(propertyKey);
            if( child == null ) {
                log.warn("Child is null for:" + this);
                return val;
            }
            if( !(val instanceof Collection) ) {
                log.warn("Value is not a collection:" + val + " for:" + this);
                return val;
            }
            Collection col = cloneCollection((Collection)val);
            col.remove(child);
            return col;
        };
        return this;
    }

    public ActionResult remove( ContextValue objectKey ) {
        return remove(objectKey, null);
    }

    public ActionResult remove( ContextValue objectKey, Object propertyId ) {
        return remove(new PropertyKey(objectKey, propertyId));
    }

    public PropertyKey getTargetKey() {
        return targetKey;
    }

    public PropertyKey getSourceKey() {
        return sourceKey;
    }

    public Function getMutator() {
        return mutator;
    }

    @SuppressWarnings("unchecked")
    protected Collection cloneCollection( Collection c ) {
        if( c instanceof List ) {
            return new ArrayList(c);
        }
        if( c instanceof SortedSet ) {
            return new TreeSet(c);
        }
        if( c instanceof Set ) {
            return new HashSet(c);
        }
        // Best we can do
        log.warn("Unhandled collection type:" + c.getClass());
        return new ArrayList<>(c);
    }

    protected Object resolve( PlanningContext context ) {
        Object val = context.getProperty(sourceKey);
        val = mutator.apply(val);
        if( combiner != null ) {
            val = combiner.apply(context, val);
        }
        return val;
    }

    @SuppressWarnings("unchecked")
    public boolean satisfiesCondition( PlanningContext context, Condition condition ) {
        if( log.isTraceEnabled() ) {
            log.trace("satisfiesCondition(" + condition + ") " + sourceKey + " = " + context.getProperty(sourceKey));
        }
        if( !targetKey.contains(condition.getSourceKey()) ) {
            // No way these can ever match
            return false;
        }
        // This next test was to work around property to property setting not having enough
        // information to actually plug into the condition predicate.  May need to
        // re-examine once the PropertyKey conversion is fully done.  FIXME
        if( !Objects.equals(sourceKey.getObjectKey().getContextId(), targetKey.getObjectKey().getContextId()) ) {
            // It might satisfy the condition if the enclosing rules conditions
            // are met.
            return true;
        }
        Object val = resolve(context);
        if( log.isTraceEnabled() ) {
            log.trace("   mutated:" + val);
        }
        // If the condition wants to see a sub-property but the action result is pulling the raw object
        // then we need to adapt it.
        if( condition.getSourceKey().getPropertyId() != null && sourceKey.getPropertyId() == null ) {
            // Have to pull it out separately
            val = context.getObjectProperty(val, condition.getSourceKey().getPropertyId());
            if( log.isTraceEnabled() ) {
                log.trace("   resolved:" + val);
            }
        }
        return condition.getPredicate().test(val);
    }

    public void applyChange( PlanningContext context ) {
        Object val = resolve(context);
        context.setProperty(targetKey, val);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("targetKey", targetKey)
            .add("sourceKey", sourceKey)
            .add("mutator", mutator)
            .add("combiner", combiner)
            .toString();
    }
}


