/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.function.Function;

import com.google.common.base.MoreObjects;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ActionRule<A> {
    static Logger log = LoggerFactory.getLogger(ActionRule.class);

    private String name;
    private String abbreviated;
    private List<Condition> requirements = new ArrayList<>();
    private Function<PlanningContext, A> actionFactory;
    private List<ActionResult> changes = new ArrayList<>();
    private Map<PropertyKey, PropertyKey> expansions = new HashMap<>();
    private Function expandTransform;
    // Probably want some kind of validate method to make sure that indirect
    // action result context values are actually reflected in the requirements, too.

    public ActionRule( String name ) {
        this.name = name;
        this.abbreviated = abbreviate(name);
    }

    public static String abbreviate( String name ) {
        StringBuilder sb = new StringBuilder();
        boolean lastLower = false;
        for( int i = 0; i < name.length(); i++ ) {
            char c = name.charAt(i);
            if( Character.isLowerCase(c) ) {
                if( lastLower ) {
                    continue;
                }
                lastLower = true;
                sb.append(c);
            } else {
                sb.append(c);
                lastLower = false;
            }
        }
        return sb.toString();
    }

    public String getName() {
        return name;
    }

    public String getAbbreviatedName() {
        return abbreviated;
    }

    public Function<PlanningContext, A> getActionFactory() {
        return actionFactory;
    }

    public List<Condition> getRequirements() {
        return requirements;
    }

    public List<ActionResult> getChanges() {
        return changes;
    }

    public ActionRule<A> does( Function<PlanningContext, A> actionFactory ) {
        this.actionFactory = actionFactory;
        return this;
    }

    public ActionRule<A> requires( Collection<Condition> requirements ) {
        this.requirements.addAll(requirements);
        return this;
    }

    public ActionRule<A> requires( Condition... requirements ) {
        this.requirements.addAll(Arrays.asList(requirements));
        return this;
    }

    public ActionRule<A> changes( Collection<ActionResult> changes ) {
        this.changes.addAll(changes);
        return this;
    }

    public ActionRule<A> changes( ActionResult... changes ) {
        this.changes.addAll(Arrays.asList(changes));
        return this;
    }

    public ActionRule<A> expand( ContextValue from, ContextValue to ) {
        return expand(new PropertyKey(from), new PropertyKey(to));
    }

    public ActionRule<A> expand( PropertyKey from, ContextValue to ) {
        return expand(from, new PropertyKey(to));
    }

    public ActionRule<A> expand( ContextValue from, PropertyKey to ) {
        return expand(new PropertyKey(from), to);
    }

    public ActionRule<A> expand( PropertyKey from, PropertyKey to ) {
        this.expansions.put(from, to);
        return this;
    }

    public ActionRule<A> expand( ContextValue from, Function expandTransform, ContextValue to ) {
        return expand(new PropertyKey(from), expandTransform, new PropertyKey(to));
    }

    public ActionRule<A> expand( PropertyKey from, Function expandTransform, PropertyKey to ) {
        this.expandTransform = expandTransform;
        this.expansions.put(from, to);
        return this;
    }

    public boolean hasExpansionTo( PropertyKey to ) {
        for( PropertyKey v: expansions.values() ) {
            // If the value we write to somehow affects the test value
            if( v.contains(to) ) {
                return true;
            }
        }
        return false;
    }

    public Map<PropertyKey, PropertyKey> getExpansions() {
        return expansions;
    }

    public Function getExpandTransform() {
        return expandTransform;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getName())
            .add("name", name)
            .add("requirements", requirements)
            .add("actionFactory", actionFactory)
            .add("changes", changes)
            .add("expansions", expansions)
            .toString();
    }
}


