/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap.graph;

import java.io.PrintWriter;
import java.util.*;
import java.util.function.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.goap.*;

/**
 *  Temporary class to build a graph data structure from rulesets to make it
 *  easier to visualize or project into different output formats.  This is
 *  just until I have a proper graph library I'm happy with again.
 *
 *  @author    Paul Speed
 */
public class RuleGraph {
    static Logger log = LoggerFactory.getLogger(RuleGraph.class);

    private long nextId;
    private Map<Object, Node> nodeIndex = new HashMap<>();
    private Set<Node> nodes = new HashSet<>();
    private Set<Edge> edges = new HashSet<>();
    private SetMultimap<Node, Edge> inEdges = MultimapBuilder.hashKeys().hashSetValues().build();
    private SetMultimap<Node, Edge> outEdges = MultimapBuilder.hashKeys().hashSetValues().build();

    public RuleGraph() {
    }

    public Node createNode( Object key, String label ) {
        Node existing = nodeIndex.get(key);
        if( existing != null ) {
            return existing;
        }
        Node result = new Node(nextId++, label);
        nodeIndex.put(key, result);
        nodes.add(result);
        return result;
    }

    public Edge createEdge( Node node1, Node node2, String label ) {
        Edge result = new Edge(nextId++, node1, node2, label);
        if( !edges.add(result) ) {
            return result;
        }
        inEdges.put(result.node2, result);
        outEdges.put(result.node1, result);
        return result;
    }

    public static RuleGraph toGraph( ActionRuleSet<?> ruleSet ) {
        RuleGraph graph = new RuleGraph();

        Map<ActionRule, Node> rules = new HashMap<>();
        Map<Condition, Node> conditions = new HashMap<>();

        for( ActionRule<?> rule : ruleSet.getRules() ) {
            Node rn = graph.createNode(rule.getName(), rule.getName());
            rules.put(rule, rn);

            for( Condition cond : rule.getRequirements() ) {
                String key = "(" + cond.getSourceKey() + ", " + cond.getPredicate() + ")";
                Node cn = graph.createNode(key, key);
                graph.createEdge(cn, rn, "req");

                conditions.put(cond, cn);
            }
        }

        PlanningContext context = new PlanningContext(new HashMap<>());

        for( ActionRule<?> rule : ruleSet.getRules() ) {
            Node rn = rules.get(rule);

            for( ActionResult change : rule.getChanges() ) {
                PropertyKey v1 = change.getTargetKey();
                PropertyKey v2 = change.getSourceKey();
                Function f = change.getMutator();
                StringBuilder sb = new StringBuilder();
                sb.append(v1);
                if( v1 != v2 ) {
                    sb.append("=");
                    sb.append(v2);
                }
                if( f != Function.identity() ) {
                    sb.append("=");
                    sb.append(f);
                }
                String key = sb.toString();
                Node changeNode = graph.createNode(key, key);
                graph.createEdge(rn, changeNode, "change");

                // See if we feed any of the conditions
                for( Map.Entry<Condition, Node> e : conditions.entrySet() ) {
                    if( change.satisfiesCondition(context, e.getKey()) ) {
                        graph.createEdge(changeNode, e.getValue(), "affects");
                    }
                }
            }
        }

        return graph;
    }

    // For now, just bundled right in here.
    public void writeDot( PrintWriter out ) {
        out.println("digraph simple_directed_graph {");
        for( Node n : nodes ) {
            out.println("    " + n.id + " [label=\"" + n.label + "\"];");
        }
        out.println();

        for( Edge e : edges ) {
            out.print("    " + e.node1.id + " -> " + e.node2.id);
            if( e.label != null ) {
                out.println(" [label=\"" + e.label + "\"];");
            } else {
                out.println();
            }
        }

        out.println("}");
    }

    public static class Node {
        public long id;
        public String label;

        public Node( long id, String label ) {
            this.id = id;
            this.label = label;
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            Node other = (Node)o;
            if( id != other.id ) {
                return false;
            }
            if( !Objects.equals(label, other.label) ) {
                return false;
            }
            return true;
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, label);
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[id:" + id + ", label:" + label + "]";
        }
    }

    public static class Edge {
        public long id;
        public Node node1;
        public Node node2;
        public String label;

        public Edge( long id, Node node1, Node node2, String label ) {
            this.id = id;
            this.node1 = node1;
            this.node2 = node2;
            this.label = label;
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            Edge other = (Edge)o;
            if( !Objects.equals(node1, other.node1) ) {
                return false;
            }
            if( !Objects.equals(node2, other.node2) ) {
                return false;
            }
            return true;
        }

        @Override
        public int hashCode() {
            return Objects.hash(node1, node2);
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[node1:" + node1 + ", node2:" + node2 + "]";
        }
    }
}



