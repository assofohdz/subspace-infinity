/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.goap;

import java.util.*;
import java.util.function.Function;

import com.google.common.base.MoreObjects;

import org.slf4j.*;

/**
 *  A proposed plan in progress.
 *
 *  @author    Paul Speed
 */
public class Proposal<A> implements Comparable<Proposal<A>> {
    static Logger log = LoggerFactory.getLogger(Proposal.class);

    private Proposal<A> parent;
    private PlanningContext context;
    private ActionRule<A> actionRule;
    private List<A> plan;
    private int depth;
    private List<Proposal<A>> history = new ArrayList<>();
    private Set<Condition> openConditions = new HashSet<>();

    public Proposal( PlanningContext context, ActionRule<A> actionRule ) {
        this.context = context;
        this.actionRule = actionRule;
        this.plan = new ArrayList<>();
        this.history.add(this);
    }

    protected Proposal( Proposal<A> parent, PlanningContext context, List<Proposal<A>> history ) {
        this.parent = parent;
        this.context = context;
        if( parent != null ) {
            this.depth = parent.depth + 1;
        }
        this.history.addAll(history);
        this.history.add(this);
    }

    protected Proposal( Proposal<A> parent ) {
        this(parent, new PlanningContext(parent.context), parent.history);
    }

    protected String getPath() {
        if( parent != null ) {
            return parent.getPath() + "/" + actionRule.getName();
        }
        return actionRule.getName();
    }

    public Set<Condition> getOpenConditions() {
        return openConditions;
    }

    public String getOpenConditionsString() {
        StringBuilder sb = new StringBuilder();
        sb.append(actionRule.getName());
        sb.append("(");
        sb.append(openConditions);
        sb.append(")");
        if( parent != null ) {
            return parent.getOpenConditionsString() + "/" + sb;
        }
        return sb.toString();
    }

    public int getHeuristic() {
        if( parent != null ) {
            return parent.getHeuristic() + openConditions.size();
        }
        return openConditions.size();
    }

    public String toStateString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getHistoryPath());
        sb.append(" path:" + getPath());
        sb.append(" after:");
        sb.append(getPlan());
        sb.append(" cost:");
        sb.append(getEstimatedCost());
        sb.append(" h:");
        sb.append(getHeuristic());
        sb.append(" ");
        sb.append(context);
        return sb.toString();
    }

    public Proposal<A> getParent() {
        return parent;
    }

    public List<Proposal<A>> getHistory() {
        return history;
    }

    public String getHistoryPath() {
        StringBuilder sb = new StringBuilder();
        for( Proposal<A> prop : history ) {
            if( sb.length() > 0 ) {
                sb.append("/");
            }
            sb.append(prop.actionRule.getAbbreviatedName());
        }
        return sb.toString();
    }

    public String getHistoryString() {
        StringBuilder sb = new StringBuilder();
        for( Proposal<A> prop : history ) {
            if( sb.length() > 0 ) {
                sb.append(", ");
            }
            sb.append(prop.getPath());
        }
        return sb.toString();
    }

    public PlanningContext getPlanningContext() {
        return context;
    }

    public ActionRule<A> getActionRule() {
        return actionRule;
    }

    public boolean isSatisfied() {
        if( log.isTraceEnabled() ) {
            log.trace("isSatisfied() context:" + context);
        }
        // See if the current context meets the rule conditions
        for( Condition condition : actionRule.getRequirements() ) {
            if( !condition.evaluate(context) ) {
                if( log.isTraceEnabled() ) {
                    log.info("    missing:" + condition);
                }
                return false;
            }
        }
        openConditions.clear();
        return true;
    }

    public List<A> getPlan() {
        return plan;
    }

    public Collection<Condition> getRequirements() {
        if( actionRule == null ) {
            return Collections.emptyList();
        }
        return actionRule.getRequirements();
    }

    public List<Proposal<A>> pop() {
        if( parent == null ) {
            return null;
        }
        // We've determined that we can actually use this proposal step to improve
        // the parent's situation and we will assert its effects into our local
        // plan space.  Then we will return a new parent proposal with the additional
        // state.

        Map<PropertyKey, PropertyKey> expansions = actionRule.getExpansions();
        if( expansions.isEmpty() ) {
            // Simple no expansion case:
            return Arrays.asList(simplePop());
        }

        // Else we need to create expansions for each possible value
        List<Proposal<A>> results = new ArrayList<>();
        Function expandTransform = actionRule.getExpandTransform();
        for( Map.Entry<PropertyKey, PropertyKey> e : expansions.entrySet() ) {
            Object source;
//log.info("e:" + e + "  expandTransform:" + expandTransform);
            source = context.getProperty(e.getKey());
            if( expandTransform != null ) {
                // FIXME: remove once expand transforms are not a thing
//log.info("  source:" + source);
                source = expandTransform.apply(source);
//log.info("  mutated source:" + source);
//log.info("  source:" + source);
            }

            if( source instanceof Collection ) {
                for( Object val : (Collection)source ) {

                    // Create a new proposal that assumes the parent's action and conditions and
                    // stuff but has the latest context state and plan.
                    // I think we do still need to fork the context because there may be other
                    // planning branches that still have this proposal as their parent.
                    Proposal<A> popped = new Proposal<A>(parent.parent, new PlanningContext(context), history);
                    popped.actionRule = parent.actionRule;

                    // Apply the expansion
                    popped.context.setProperty(e.getValue(), val);
                    log.info("expanding... setting " + e.getValue() + " to:" + val);

                    // Now update the state of the new proposal to have the results of this action
                    popped.plan = new ArrayList<>(plan);
                    if( actionRule != null ) {
                        A action = actionRule.getActionFactory().apply(popped.context);
                        popped.plan.add(action);
                    }

                    log.info("  popped:" + popped.toStateString());

                    results.add(popped);
                }
            } else {
                throw new IllegalStateException("Expansion source is not a collection:" + e);
            }
        }

        return results;
    }

    protected Proposal<A> simplePop() {

        // Create a new proposal that assumes the parent's action and conditions and
        // stuff but has the latest context state and plan.
        // I think we do still need to fork the context because there may be other
        // planning branches that still have this proposal as their parent.
        Proposal<A> result = new Proposal<A>(parent.parent, new PlanningContext(context), history);
        result.actionRule = parent.actionRule;

        // Apply the results to the context before we run through the
        // action factories so that they can use the target and not have to use the source.
        for( ActionResult change : actionRule.getChanges() ) {
            //System.out.println("    applying:" + change);
            change.applyChange(result.context);
        }

        // Now update the state of the new proposal to have the results of this action
        result.plan = new ArrayList<>(plan);
        if( actionRule != null ) {
            // I think we should use the new wrapped context and should do it before
            // we apply the action results so that we see the state of the context 'right now'.
            // It actually may end up being better to pass 'context' but I will need some
            // real use-cases.  Right now, this instant, they will both have the same values.
            // I worry about the case where the factory holds a reference to the context.
            // (Ideally, it would also be a read-only context view.)
            // The above is no longer true as we apply the action results before creating
            // the rules.  Our result's context is now 'more accurate' for the actions.
            // And actually, now we supply both so that the action factory can see what
            // was before and what's after... which is the only way actions that replace
            // and object with another can really work.
            // ...well, we don't supply both because that makes wiring up closures harder
            // but the parent context should have the values before we changed them.
            A action = actionRule.getActionFactory().apply(result.context);
            result.plan.add(action);
        }

//        // Did this actually change anything over the original?
//        Map old = new HashMap();
//        context.collectValues(old);
//        Map now = new HashMap();
//        result.context.collectValues(now);
////log.info("old:" + old + "\nnew:" + now);
//        if( old.equals(now) ) {
//            log.warn("************** Rule did not actually change state:" + result.toStateString());
//        }

        return result;
    }

    public List<Proposal<A>> extend( ActionRule<A> actionRule ) {

        if( true ) {
            // See if history already has this rule with the same context we have now
            for( Proposal<A> his : history ) {
                if( !Objects.equals(his.actionRule, actionRule) ) {
                    continue;
                }

                // We've been to this action rule before... was the context the same
                if( context.hasSameValues(his.context) ) {
                    log.warn("Loop-back:" + actionRule.getName() + " in path:" + getPath() + "  history:" + getHistoryString());
                    return Collections.emptyList();
                }
            }
        }

        Proposal<A> result = new Proposal<>(this);
        result.actionRule = actionRule;
        result.plan = plan;
        return Arrays.asList(result);
    }

    public double getEstimatedCost() {
        // Including depth but note that if there are short 'already visited' paths
        // that keep coming up that we will perpetually keep trying them over and over
        // because their cost is always lower.
        // 2026-01-26 - I don't think depth is the right answer.  Or I guess I'm using
        // it as a heuristic which is ok... but we need to factor in history size
        // because that is the actual length of the path we have taken to get here.
        // Eventually the plan will have its own cost.
        int historySize = history.size();
        if( actionRule == null ) {
            return historySize + plan.size() + depth;
        }
        return historySize + plan.size() + 1 + depth;
    }

    public int compareTo( Proposal<A> other ) {
        if( true ) {
            double v1 = getEstimatedCost() + getHeuristic();
            double v2 = other.getEstimatedCost() + other.getHeuristic();
            return Double.compare(v1, v2);
        } else {
            return Double.compare(getEstimatedCost(), other.getEstimatedCost());
        }
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("context", context)
            .add("actionRule", actionRule)
            .add("plan", plan)
            .add("estimatedCost", getEstimatedCost())
            .toString();
    }
}

