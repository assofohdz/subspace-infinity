/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import java.util.List;
import java.util.LinkedList;
import javax.script.Bindings;
// a convenient interface even when not doing scripting.
import javax.script.SimpleBindings;

import org.slf4j.*;

/**
 *  The environment within which actions can be run.  This provides
 *  access to the available shared resources, the types, and the
 *  activator that is running the actions.
 *
 *  @author    Paul Speed
 */
public class ActionEnvironment<A, T> implements PromptProvider<A, T> {
    static Logger log = LoggerFactory.getLogger(ActionEnvironment.class);

    // When an action is run on this environment, we will push the environment
    // onto this stack so that anything in the thread can easily find the
    // current environment.
    private static ThreadLocal<LinkedList<ActionEnvironment>> envStack
            = new ThreadLocal<LinkedList<ActionEnvironment>>() {
                @Override
                protected LinkedList<ActionEnvironment> initialValue() {
                    return new LinkedList<>();
                }
            };

    private ObjectTypeRegistry<A, T> types;
    private A activator;
    private PromptProvider<A, T> promptProvider;
    private Bindings variables;

    public ActionEnvironment( ObjectTypeRegistry<A, T> types, A activator ) {
        this(types, activator, new SimpleBindings());
    }

    public ActionEnvironment( ObjectTypeRegistry<A, T> types, A activator, Bindings variables ) {
        this.types = types;
        this.activator = activator;
        this.variables = variables;
        resetDefaultProvider();
    }

    /**
     *  If an action is being run on this thread then this will return the current
     *  ActionEnvironment that is performing that action.  This is useful if deeper
     *  code wants to know the environment within which they are running without
     *  having passed that instance all the way down.
     */
    @SuppressWarnings("unchecked")
    public static <A, T> ActionEnvironment<A, T> getCurrentEnvironment() {
        return getCurrentEnvironment(true);
    }

    /**
     *  If an action is being run on this thread then this will return the current
     *  ActionEnvironment that is performing that action.  This is useful if deeper
     *  code wants to know the environment within which they are running without
     *  having passed that instance all the way down.
     */
    @SuppressWarnings("unchecked")
    public static <A, T> ActionEnvironment<A, T> getCurrentEnvironment( boolean failOnMiss ) {
        LinkedList<ActionEnvironment> stack = envStack.get();
        if( stack.isEmpty() ) {
            if( failOnMiss ) {
                throw new IllegalStateException("An action environment is not in scope.");
            }
            return null;
        }
        return (ActionEnvironment<A, T>)stack.getFirst();
    }

    public static <A, T> void pushCurrentEnvironment( ActionEnvironment<A, T> actionEnv ) {
        envStack.get().push(actionEnv);
    }

    public static <A, T> void popCurrentEnvironment( ActionEnvironment<A, T> actionEnv ) {
        ActionEnvironment check = envStack.get().pop();
        assert check == actionEnv : "Env stack consistency error";
    }

    public void runAction( T targetObject, String actionName, Object... parms ) {
        envStack.get().push(this);
        try {
            ActionContext<A, T> context = types.getContext(targetObject);
            context.run(this, actionName, parms);
        } finally {
            ActionEnvironment check = envStack.get().pop();
            assert check == this : "Env stack consistency error";
        }
    }

    public void runActionIfExists( T targetObject, String actionName, Object... parms ) {
        envStack.get().push(this);
        try {
            ActionContext<A, T> context = types.getContext(targetObject);
            context.runIfExists(this, actionName, parms);
        } finally {
            ActionEnvironment check = envStack.get().pop();
            assert check == this : "Env stack consistency error";
        }
    }

    public void showPrompt( T target, PromptType type, String prompt ) {
        if( promptProvider == null ) {
            throw new IllegalStateException("No prompt provider has been specified");
        }
        promptProvider.showPrompt(target, type, prompt);
    }

    public final void showOptions( T target, List<Option<T>> options ) {
        if( promptProvider == null ) {
            throw new IllegalStateException("No prompt provider has been specified");
        }
        promptProvider.showOptions(target, options);
    }

    public void showOptions( T target, List<Option<T>> options, Option<T> closeOption ) {
        if( promptProvider == null ) {
            throw new IllegalStateException("No prompt provider has been specified");
        }
        promptProvider.showOptions(target, options, closeOption);
    }

    public A getActivator() {
        return activator;
    }

    public ObjectTypeRegistry<A, T> getTypes() {
        return types;
    }

    public void setPromptProvider( PromptProvider<A, T> promptProvider ) {
        this.promptProvider = promptProvider;
        if( promptProvider == null ) {
            resetDefaultProvider();
        }
    }

    public PromptProvider<A, T> getPromptProvider() {
        return promptProvider;
    }

    public Bindings getVariables() {
        return variables;
    }

    @SuppressWarnings("unchecked")
    public <T> T getVar( String key, T defaultValue ) {
        Object result = variables.get(key);
        return result == null ? defaultValue : (T)result;
    }

    public void setVar( String key, Object value ) {
        if( value ==  null ) {
            variables.remove(key);
        } else {
            variables.put(key, value);
        }
    }

    // Final so we can call it from the constructor without issue
    @SuppressWarnings("unchecked")
    protected final void resetDefaultProvider() {
        // See if the activator can be a provider
        if( activator instanceof PromptProvider ) {
            this.promptProvider = (PromptProvider<A, T>)activator;
        }
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[activator:" + activator + "]";
    }
}

