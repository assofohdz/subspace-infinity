/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import java.util.Arrays;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  An option that can be used as response from a prompt by calling
 *  the appropriate action with the specified parameters.
 *
 *  @author    Paul Speed
 */
public class Option<T> {
    static Logger log = LoggerFactory.getLogger(Option.class);

    // Defaults to the prompt target if not set
    private T target;
    private String display;
    private String actionId;
    private Object[] parms;
 
    // For serialization
    private Option() {
    }
    
    public Option( String actionId, Object... parms ) {
        this(null, null, actionId, parms);
    }

    public Option( String display, String actionId, Object... parms ) {
        this(null, display, actionId, parms);
    }

    public Option( T target, String actionId, Object... parms ) {
        this(target, null, actionId, parms);
    }
    
    public Option( T target, String display, String actionId, Object... parms ) {
        this.target = target;
        this.display = display;
        this.actionId = actionId;
        this.parms = parms;
    }
 
    public T getTarget() {
        return target;
    }
    
    public String getDisplay() {
        return display == null ? toDisplay(actionId) : display;
    }
    
    public String getActionId() {
        return actionId;
    }
    
    public Object[] getParameters() {
        return parms;
    }
    
    protected String toDisplay( String id ) {
        StringBuilder sb = new StringBuilder();
        for( int i = 0; i < id.length(); i++ ) {
            char c = id.charAt(i);
            if( i == 0 ) {
                c = Character.toUpperCase(c);
            } else if( Character.isUpperCase(c) ) {
                sb.append(" ");
            }
            sb.append(c);
        }
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("target", target)
            .add("display", display)
            .add("actionId", actionId)
            .add("parameters", Arrays.asList(parms))
            .toString(); 
    }
}


