/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;
import com.google.common.primitives.Primitives;

/**
 *  Represent the type of object upon which we can run actions.  This
 *  is similar to a "class" in normal object-oriented terms.
 *
 *  @author    Paul Speed
 */
public class ObjectType<A, T> {
    static Logger log = LoggerFactory.getLogger(ObjectType.class);

    private String name;
    private ListMultimap<String, ObjectAction<A, T>> actionIndex;
    private Map<String, Object> vars = new HashMap<>();
    private Set<ObjectType<A, T>> superTypes = new LinkedHashSet<>();
    private Set<ObjectType<A, T>> flattenedTypes = null;
    private ListMultimap<String, ObjectAction<A, T>> flattenedIndex;

    @SafeVarargs
    public ObjectType( String name, ObjectAction<A, T>... actions ) {
        this(name, Arrays.asList(actions));
    }

    public ObjectType( String name, List<ObjectAction<A, T>> actions ) {
        this.name = name;
        this.actionIndex = MultimapBuilder.linkedHashKeys().arrayListValues().build();
        for( ObjectAction<A, T> action : actions ) {
            actionIndex.put(action.getName(), action);
        }
    }

    // Probably just temporary until we have a builder pattern
    public void addAction( ObjectAction<A, T> action ) {
        List<ObjectAction<A, T>> existing = actionIndex.get(action.getName());

        // See if there is an existing one we need to replace
        Class[] parms = action.getParamTypes();
        for( ListIterator<ObjectAction<A, T>> it = existing.listIterator(); it.hasNext(); ) {
            ObjectAction<A, T> check = it.next();
            if( hasEqualParameters(parms, check.getParamTypes()) ) {
                // Warn because in a lot of cases this might be a mistake.
                // It just so happens that in the case of live-updating, we want
                // this behavior.  Could maybe eventually be optional to allow it.
                log.warn("Replacing:" + check + " with:" + action);

                // Replace it
                it.set(action);

                // And if we already have a flattened index then replace it in there, too
                if( flattenedIndex != null ) {
                    List<ObjectAction<A, T>> index = flattenedIndex.get(action.getName());
                    int replace = index.indexOf(check);
                    if( replace >= 0 ) {
                        log.info("Replacing in flattened index at:" + replace);
                        index.set(replace, action);
                    }
                }

                // And we're done
                return;
            }
        }
        actionIndex.put(action.getName(), action);
    }

    // Probably just temporary until we have a builder pattern
    public void addSuperType( ObjectType<A, T> type ) {
        // FIXME: replace an action with the same name + parameters if
        // it already exists.
        superTypes.add(type);
    }

    public String getName() {
        return name;
    }

    public Iterable<ObjectType<A, T>> getSuperTypes() {
        return superTypes;
    }

    protected Set<ObjectType<A, T>> getFlattenedTypes() {
        if( log.isTraceEnabled() ) {
            log.trace("getFlattenedTypes()");
        }
        if( flattenedTypes != null ) {
            return flattenedTypes;
        }
        if( log.isTraceEnabled() ) {
            log.trace("Constructing flattened supertypes for:" + getName());
        }
        flattenedTypes = new LinkedHashSet<>(superTypes);
        LinkedList<ObjectType<A, T>> queue = new LinkedList<>();
        queue.addAll(superTypes);
        ObjectType<A, T> parent = null;
        while( (parent = queue.poll()) != null ) {
            if( log.isTraceEnabled() ) {
                log.trace("  expanding:" + parent.getName());
            }
            for( ObjectType<A, T> type : parent.superTypes ) {
                // We prevent cycles this way but might confuse the user.
                // Unfortunately, detecting cycles in a breadth first search
                // is non-trivial, I think.
                if( flattenedTypes.add(type) ) {
                    queue.addAll(parent.superTypes);
                }
            }
            flattenedTypes.addAll(parent.superTypes);
            queue.addAll(parent.superTypes);
        }
        return flattenedTypes;
    }

    protected boolean hasEqualParameters( Class[] parms1, Class[] parms2 ) {
        if( parms1.length != parms2.length ) {
            return false;
        }
        int size = parms1.length;
        for( int i = 0; i < size; i++ ) {
            if( !Objects.equals(parms1[i], parms2[i]) ) {
                return false;
            }
        }
        return true;
    }

    protected ListMultimap<String, ObjectAction<A, T>> getFlattenedIndex() {
        if( log.isTraceEnabled() ) {
            log.trace("getFlattenedIndex()");
        }
        if( flattenedIndex != null ) {
            return flattenedIndex;
        }
        if( log.isTraceEnabled() ) {
            log.trace("Constructing flattened action index for:" + getName());
        }

        flattenedIndex = MultimapBuilder.linkedHashKeys().arrayListValues().build();
        // Fill it with the local actions first
        flattenedIndex.putAll(actionIndex);

        if( log.isTraceEnabled() ) {
            log.trace("Existing actions:");
        }
        for( ObjectAction<A, T> a : flattenedIndex.values() ) {
            if( log.isTraceEnabled() ) {
                log.trace("  :" + a.getName() + Arrays.asList(a.getParamTypes()));
            }
        }

        // Then add the super type actions that don't already exist
        for( ObjectType<A, T> type : getFlattenedTypes() ) {
            if( log.isTraceEnabled() ) {
                log.trace("Grafting in actions from supertype:" + type.getName());
            }

            for( Map.Entry<String, ObjectAction<A, T>> e : type.actionIndex.entries() ) {
                List<ObjectAction<A, T>> existing = flattenedIndex.get(e.getKey());
                if( existing.isEmpty() ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("No overridden action with same name, deferring directly:" + e.getKey());
                    }
                    // Brand new, easy
                    flattenedIndex.put(e.getKey(), e.getValue());
                    continue;
                }

                // Else we need to see if we match parameters with something already there
                //List<Class> parms = Arrays.asList(e.getValue().getParamTypes());
                Class[] parms = e.getValue().getParamTypes();
                boolean found = false;
                for( ObjectAction<A, T> check : existing ) {
                    // For now we will use an exact match instead of the looser
                    // instanceof style checks for matches()... until we have a use
                    // case that suggests something better.
                    // Strongly discourage such rampant action overloading, though.
                    //List<Class> existingParms = Arrays.asList(check.getParamTypes());
                    //if( parms.equals(existingParms) ) {
                    if( hasEqualParameters(parms, check.getParamTypes()) ) {
                        if( log.isTraceEnabled() ) {
                            log.trace("Action already exists in subtype:" + check.getName() + Arrays.asList(check.getParamTypes()));
                        }
                        // Already exists... so stop
                        found = true;
                        break;
                    }
                }
                if( !found ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("No overridden action with same parameters, adding:" + e.getKey() + parms);
                    }
                    // Not overridden
                    flattenedIndex.put(e.getKey(), e.getValue());
                }
            }
        }

        if( log.isTraceEnabled() ) {
            log.trace("Final actions:");
        }
        for( ObjectAction<A, T> a : flattenedIndex.values() ) {
            if( log.isTraceEnabled() ) {
                log.trace("  :" + a.getName() + Arrays.asList(a.getParamTypes()));
            }
        }
        return flattenedIndex;
    }

    public Set<String> getActionNames() {
        Set<String> result = getFlattenedIndex().keySet();
        return Collections.unmodifiableSet(result);
    }

    public void setTypeVar( String name, Object value ) {
        vars.put(name, value);
    }

    @SuppressWarnings("unchecked")
    public <V> V getTypeVar( String name, V defaultValue ) {
        V result = (V)vars.get(name);
        if( result != null ) {
            return result;
        }
        // Check the super types
        for( ObjectType<A, T> type : getFlattenedTypes() ) {
            result = (V)type.vars.get(name);
            if( result != null ) {
                return result;
            }
        }
        return defaultValue;
    }

    /**
     *  Returns a list of "public" actions suitable for context menus,
     *  etc..  The first action is usually considered the "default action".
     */
    public List<ObjectAction<A, T>> getContextActions() {
        List<ObjectAction<A, T>> results = new ArrayList<>();
        Object[] noArgs = new Object[0];
        for( ObjectAction<A, T> action : getFlattenedIndex().values() ) {
            if( !matches(action.getParamTypes(), noArgs) ) {
                continue;
            }
            if( Character.isUpperCase(action.getName().charAt(0)) ) {
                results.add(action);
            }
        }
        return results;
    }

    public ObjectAction<A, T> findAction( String name, Object... args ) {
        if( log.isTraceEnabled() ) {
            log.trace("findAction(" + name + ", " + Arrays.asList(args) + ")");
        }
        for( ObjectAction<A, T> action : getFlattenedIndex().get(name) ) {
            if( matches(action.getParamTypes(), args) ) {
                return action;
            }
        }
        return null;
    }

    /**
     *  Finds the first matching action in this type's super types.  This does
     *  not include any local matching actions and will stop at the first matching
     *  action that it finds on a trip up the class hierarchy.
     */
    public ObjectAction<A, T> findSuperAction( ObjectAction<A, T> currentAction, Object... args ) {
        if( log.isTraceEnabled() ) {
            log.trace("findSuperAction(" + currentAction + ", " + Arrays.asList(args) + ")");
        }
        String name = currentAction.getName();
        // We  might be starting from the leaf type in which case anything we
        // find is valid... otherwise, we want to skip past the action we've already been running
        boolean found = actionIndex.get(name).contains(currentAction);
        for( ObjectType<A, T> type : getFlattenedTypes() ) {
            if( log.isTraceEnabled() ) {
                log.trace("checking type:" + type);
            }
            for( ObjectAction<A, T> action : type.actionIndex.get(name) ) {
                if( log.isTraceEnabled() ) {
                    log.trace("Checking action:" + action);
                }
                if( !matches(action.getParamTypes(), args) ) {
                    log.trace("Doesn't match parameters.");
                    continue;
                }
                if( !found ) {
                    log.trace("found the high watermark");
                    found = true;
                    continue;
                }
                // Else this is the first action past the one we've already run
                return action;
            }
        }
        return null;
    }

    /**
     *  Finds all of the matching actions in this type's super types.  This does
     *  not include any local matching actions.
     */
    public List<ObjectAction<A, T>> findSuperActions( ObjectAction<A, T> currentAction, Object... args ) {
        if( log.isTraceEnabled() ) {
            log.trace("findSuperActions(" + currentAction + ", " + Arrays.asList(args) + ")");
        }
        String name = currentAction.getName();
        boolean found = actionIndex.get(name).contains(currentAction);
        List<ObjectAction<A, T>> results = new ArrayList<>();
        for( ObjectType<A, T> type : getFlattenedTypes() ) {
            for( ObjectAction<A, T> action : type.actionIndex.get(name) ) {
                if( !matches(action.getParamTypes(), args) ) {
                    continue;
                }
                if( !found ) {
                    found = true;
                    continue;
                }
                results.add(action);
            }
        }
        return results;
    }

    public List<ObjectAction<A, T>> findNamedActions( String name ) {
        if( log.isTraceEnabled() ) {
            log.trace("findNamedActions(" + name + ")");
        }
        List<ObjectAction<A, T>> results = getFlattenedIndex().get(name);
        return Collections.unmodifiableList(results);
    }

    /**
     *  Returns all of the actions that can accept the specified arguments.
     */
    public List<ObjectAction<A, T>> findTypedActions( Object... args ) {
        if( log.isTraceEnabled() ) {
            log.trace("findTypedActions(" + Arrays.asList(args) + ")");
        }
        List<ObjectAction<A, T>> results = new ArrayList<>();
        for( ObjectAction<A, T> action : getFlattenedIndex().values() ) {
            if( matches(action.getParamTypes(), args) ) {
                results.add(action);
            }
        }
        return results;
    }

    @SuppressWarnings("unchecked")
    protected boolean matches( Class type, Object arg ) {
        if( type.isInstance(arg) ) {
            return true;
        }
        // Catch the case where the argument is an auto-boxed version
        // as this will be resolved during the call
        if( Primitives.wrap(type).isInstance(arg) ) {
            return true;
        }
        return false;
    }

    protected boolean matches( Class[] types, Object[] args ) {
        if( types.length != args.length ) {
            return false;
        }
        int count = types.length;
        for( int i = 0; i < count; i++ ) {
            if( args[i] == null ) {
                // It would fail an instance check but any type can be
                // null in an argument list.
                continue;
            }
            if( !matches(types[i], args[i]) ) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[name:" + name + "]";
    }
}
