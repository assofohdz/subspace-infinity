/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import org.slf4j.*;

import java.util.*;

/**
 *  This is an object upon which actions can be performed.  In
 *  "object-oriented" terms this would be the 'object' to ObjectType's
 *  class.
 *
 *  @author    Paul Speed
 */
public class ActionContext<A, T> {
    static Logger log = LoggerFactory.getLogger(ActionContext.class);

    private ObjectType<A, T> type;
    private T target;

    public ActionContext( ObjectType<A, T> type, T target ) {
        this.type = type;
        this.target = target;
    }

    public ObjectType<A, T> getType() {
        return type;
    }

    public T getTarget() {
        return target;
    }

    private Class[] toTypes( Object[] args ) {
        if( args == null ) {
            return null;
        }
        Class[] result = new Class[args.length];
        for( int i = 0; i < result.length; i++ ) {
            result[i] = args[i] == null ? null : args[i].getClass();
        }
        return result;
    }

    protected ObjectAction<A, T> resolveAction( boolean failFast, ObjectType<A, T> actionType,
                                                String actionName, Object... args ) {
        ObjectAction<A, T> action = actionType.findAction(actionName, args);
        if( action == null && failFast ) {
            throw new IllegalArgumentException("Action not found for:" + actionName
                                                + ", actionType:" + actionType
                                                + ", args:" + Arrays.asList(args)
                                                + ", types:" + Arrays.asList(toTypes(args))
                                                + "\n"
                                                + "Similar actions:" + actionType.findNamedActions(actionName)
                                                + "\n"
                                                + "All actions:" + actionType.getActionNames()
                                                );
        }
        return action;
    }

    public boolean hasAction( String actionName, Object... args ) {
        return resolveAction(false, type, actionName, args) != null;
    }

    // I think we should maybe deprecate/remove these env-accepting versions.
    // It would mean that the entry point to all actions would be the ActionEnvironment
    // and then additional calls inside that action would rely on the existing environment.
    // I'm willing to let these sit for a while in case that turns out to not be the
    // common case.  -pspeed:2024-01-02
    public boolean canRun( ActionEnvironment<A, T> env, String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(false, type, actionName, args);
        if( action == null ) {
            return false;
        }
        return action.canRun(env, this, args);
    }

    public boolean canRun( String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(false, type, actionName, args);
        if( action == null ) {
            return false;
        }
        return action.canRun(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    public boolean run( ActionEnvironment<A, T> env, String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(true, type, actionName, args);
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(env, this, args);
    }

    public boolean run( String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(true, type, actionName, args);
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    public boolean runIfExists( ActionEnvironment<A, T> env, String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(false, type, actionName, args);
        if( action == null ) {
            return false;
        }
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(env, this, args);
    }

    public boolean runIfExists( String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(false, type, actionName, args);
        if( action == null ) {
            return false;
        }
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    /**
     *  Allows running the action from a specific type from this context.  The
     *  type need not be part of this action's type hierarchy but will usually be
     *  one of the supertypes.
     */
    public boolean run( ActionEnvironment<A, T> env, ObjectType<A, T> altType, String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(true, altType, actionName, args);
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(env, this, args);
    }

    /**
     *  Allows running the action from a specific type from this context.  The
     *  type need not be part of this action's type hierarchy but will usually be
     *  one of the supertypes.
     */
    public boolean run( ObjectType<A, T> altType, String actionName, Object... args ) {
        ObjectAction<A, T> action = resolveAction(true, altType, actionName, args);
        // Note: we purposely do not recheck canRun() here.  Either the action
        // doesn't care or will have all of the information necessary to check again.
        // It's otherwise wasteful to call it again here.  If the action wants to
        // delegate to its own canRun() then that's its prerogative.
        return action.run(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    /**
     *  Runs the specified action on any super types of this context's main type, it
     *  will only run the first one encountered on the way up the chain.
     *  This is usually called from the action being run to call its overridden
     *  actions.
     *  Best to limit this to cases where the class hierarchy is clear as multiple
     *  inheritance can make execution priority a bit confusing.
     */
    public boolean superRun( ObjectAction<A, T> currentAction, Object... args ) {
        ObjectAction<A, T> action = type.findSuperAction(currentAction, args);
        if( action == null ) {
            throw new IllegalArgumentException("Super-action not found for:" + currentAction.getName()
                                                + ", actionType:" + type
                                                + ", args:" + Arrays.asList(args)
                                                + ", types:" + Arrays.asList(toTypes(args))
                                                );
        }
        return action.run(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    /**
     *  Runs the specified canRun on any super types of this context's main type, it
     *  will only run the first one encountered on the way up the chain.
     *  This is usually called from the action being run to call its overridden
     *  actions.
     *  Best to limit this to cases where the class hierarchy is clear as multiple
     *  inheritance can make execution priority a bit confusing.
     */
    public boolean superCanRun( ObjectAction<A, T> currentAction, Object... args ) {
        ObjectAction<A, T> action = type.findSuperAction(currentAction, args);
        if( action == null ) {
            throw new IllegalArgumentException("Super-action not found for:" + currentAction.getName()
                                                + ", actionType:" + type
                                                + ", args:" + Arrays.asList(args)
                                                + ", types:" + Arrays.asList(toTypes(args))
                                                );
        }
        return action.canRun(ActionEnvironment.getCurrentEnvironment(), this, args);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[type:" + type + ", target:" + target + "]";
    }
}


