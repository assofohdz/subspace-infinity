/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.google.common.cache.*;

/**
 *  The central entry point into the object action system providing the
 *  registry of all types as well as convenience methods for creating
 *  environments and ActionContext object wrappers.
 *
 *  @author    Paul Speed
 */
public class ObjectTypeRegistry<A, T> implements Iterable<ObjectType<A, T>> {
    static Logger log = LoggerFactory.getLogger(ObjectTypeRegistry.class);

    private Map<String, ObjectType<A, T>> typeIndex = new HashMap<>();
    private ObjectType<A, T> defaultType;

    private Function<T, String> typeNameResolver;

    private LoadingCache<T, ActionContext<A, T>> contextCache;

    public ObjectTypeRegistry() {
        // No maximum size because we basically never want objects
        // evicted unless they are no longer referencable.
        this.contextCache = CacheBuilder.newBuilder()
                        .weakValues()
                        .build(new CacheLoader<T, ActionContext<A, T>>() {
                                @Override
                                public ActionContext<A, T> load( T target ) {
                                    return createContext(target);
                                }
                            });
    }

    protected LoadingCache<T, ActionContext<A, T>> getContextCache() {
        return contextCache;
    }

    public Iterator<ObjectType<A, T>> iterator() {
        return Collections.unmodifiableCollection(typeIndex.values()).iterator();
    }

    public ObjectTypeRegistry<A, T> typeNameResolver( Function<T, String> typeNameResolver ) {
        this.typeNameResolver = typeNameResolver;
        return this;
    }

    public void setTypeNameResolver( Function<T, String> typeNameResolver ) {
        this.typeNameResolver = typeNameResolver;
    }

    public Function<T, String> getTypeNameResolver() {
        return typeNameResolver;
    }

    public ObjectType<A, T> registerType( ObjectType<A, T> type ) {
        String name = type.getName();
        if( typeIndex.containsKey(name) ) {
            throw new IllegalArgumentException("Type already exists for:" + name);
        }
        typeIndex.put(name, type);
        return type;
    }

    public ObjectType<A, T> replaceType( ObjectType<A, T> type ) {
        String name = type.getName();
        typeIndex.put(name, type);
        return type;
    }

    public boolean exists( String name ) {
        return typeIndex.containsKey(name);
    }

    public ObjectType<A, T> getType( String name ) {
        ObjectType<A, T> result = typeIndex.get(name);
        return result == null ? defaultType : result;
    }

    public void setDefaultType( ObjectType<A, T> defaultType ) {
        if( !exists(defaultType.getName()) ) {
            registerType(defaultType);
        }
        this.defaultType = defaultType;
    }

    public ObjectType<A, T> getDefaultType() {
        return defaultType;
    }

    public ActionEnvironment<A, T> createEnvironment( A activator ) {
        return new ActionEnvironment<>(this, activator);
    }

    public ObjectType<A, T> getType( T target ) {
        if( typeNameResolver == null ) {
            throw new IllegalStateException("No typeNameResolver configured");
        }
        // See if we already have an action context for this one
        ActionContext<A, T> context = contextCache.getIfPresent(target);
        if( context != null ) {
            // This prevents objects from changing their type while they have
            // an active context in the cache... which effectively prevents
            // weirdness if they do something to alter the result of typeNameResolver
            // while performing an action (say, deleting the entity or removing the
            // type component).
            // It also prevents legitimately trying to change an object's type at runtime
            // but I can't think of a non-confusing use-case for that today.
            return context.getType();
        }

        String typeName = typeNameResolver.apply(target);
        if( typeName == null ) {
            if( defaultType == null ) {
                throw new IllegalArgumentException("No type name resolved for:" + target);
            }
        }
        return getType(typeName);
    }

    /**
     *  Creates an ActionContext wrapper for the specified target object using
     *  the configured typeResolved to figure out which ObjectType to use.
     */
    public ActionContext<A, T> createContext( T target ) {
        if( typeNameResolver == null ) {
            throw new IllegalStateException("No typeNameResolver configured");
        }
        String typeName = typeNameResolver.apply(target);
        if( typeName == null ) {
            if( defaultType == null ) {
                throw new IllegalArgumentException("No type name resolved for:" + target);
            }
        }
        ObjectType<A, T> type = getType(typeName);
        if( type == null ) {
            throw new IllegalArgumentException("No type:" + typeName + " found for:" + target);
        }
        return createContext(type, target);
    }

    /**
     *  Creates an ActionContext wrapper for the specified target object and ObjectType.
     */
    public ActionContext<A, T> createContext( ObjectType<A, T> type, T target ) {
        log.info("Creating action context for:" + type + ", " + target);
        return new ActionContext<>(type, target);
    }

    /**
     *  Returns a possibly cached ActionContext wrapper for the specified target.
     *  If a previous call to getContext() has already returned an ActionContext for
     *  the target and that code is still holding a reference, then this method will
     *  return that object again.  As long as some live object is still holding
     *  a reference to that ActionContext then it will not get created again.
     *  Otherwise, the ActionContext is automatically garbage collected like any other
     *  object and will be removed from the cache.
     */
    public ActionContext<A, T> getContext( T target ) {
        return contextCache.getUnchecked(target);
    }
}


