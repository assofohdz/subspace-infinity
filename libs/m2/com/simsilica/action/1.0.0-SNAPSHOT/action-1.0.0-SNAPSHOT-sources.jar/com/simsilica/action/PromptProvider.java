/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.action;

import java.util.List;

/**
 *  (this may be a temporary home) Denotes a service/object that can
 *  provide user-input request capabilities to object actions, ie:
 *  prompts.  These prompts can accept user input of some kind and
 *  then call back actions on the object as appropriate.
 *
 *  @author    Paul Speed
 */
public interface PromptProvider<A, T> {
    /**
     *  Indicates that a particular type of prompt should be displayed
     *  with any of the prompt text specified.  For example, a dialog
     *  may have a text area at the top while a context/radial menu
     *  may only have a title.
     */
    public void showPrompt( T target, PromptType type, String prompt );

    /**
     *  Sets the options for a particular prompt type.  If no showPrompt()
     *  has previously been called for the target then the provider may
     *  default to one of the list/radial prompts.
     */
    public void showOptions( T target, List<Option<T>> options );

    /**
     *  Sets the options for a particular prompt type with an optional special
     *  closeOption that will be added to the end of the list but also called if
     *  the prompt is closed.
     *  If no showPrompt() has previously been called for the target then the provider may
     *  default to one of the list/radial prompts.
     */
    public void showOptions( T target, List<Option<T>> options, Option<T> closeOption );
}


