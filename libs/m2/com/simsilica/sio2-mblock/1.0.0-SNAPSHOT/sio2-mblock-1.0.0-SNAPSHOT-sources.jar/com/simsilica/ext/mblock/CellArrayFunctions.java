/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mblock;

import java.io.File;
import java.util.function.Function;

import org.slf4j.*;

import com.google.common.cache.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.db.CellArrayId;
import com.simsilica.mblock.db.CellArrayStorage;
import com.simsilica.mblock.io.BlocksFileFormat;
import com.simsilica.mblock.phys.*;
import com.simsilica.ext.mphys.*;
import com.simsilica.util.CacheTracker;

/**
 *  Some standard prebuild functions for converting Strings to CellArrays.
 *
 *  @author    Paul Speed
 */
public class CellArrayFunctions {
    static Logger log = LoggerFactory.getLogger(CellArrayFunctions.class);

    /**
     *  Loads a .blocks file as a resource.
     */
    public static Function<String, CellArray> blocksResource() {
        return new BlocksFunction(".blocks");
    }

    /**
     *  Loads a .blocks file as a file from a particular location.  It will
     *  pass if the file does not exist, letting it fall to the next function.
     */
    public static Function<String, CellArray> blocksFile( File root ) {
        return new BlocksFileFunction(root, ".blocks");
    }

    /**
     *  Loads a CellArray from CellArrayStorage by converting its name into a CellArrayId
     *  by chopping off the extension and anything prior to the last _.
     *  For example, with "foo_baz_12345676.ca" then 12345676 is treated as the cell array
     *  ID.
     */
    public static Function<String, CellArray> cellArrayStorage( Function<CellArrayId, CellArray> storage ) {
        return new CellArrayStorageFunction(".ca", storage);
    }

    public static Function<String, CellArray> chain( Function... delegates ) {
        return new CellArrayStorageFunctionChain(delegates);
    }

    /**
     *  Wraps the delegate function in a guava loading cache which makes sure that as
     *  long as some thread is holding a reference to the returned CellArray that it will
     *  not be reloaded.  This is mostly to easy file system hammering when lots of models
     *  are being loaded at once and may be less necessary once clients are caching the
     *  generated spatials, though the physics engine will still be loading the blocks, too.
     */
    public static Function<String, CellArray> singletonCache( Function<String, CellArray> delegate ) {
        return new SingletonCellArrayCache(delegate);
    }

    public static class SingletonCellArrayCache implements Function<String, CellArray> {
        private Function<String, CellArray> delegate;
        private LoadingCache<String, CellArray> cache;
        private CellArray nullObject = new CellArray(0);

        public SingletonCellArrayCache( Function<String, CellArray> delegate ) {
            this.delegate = delegate;
            this.cache = CacheBuilder.newBuilder()
                            .weakValues()
                            .recordStats()
                            .build(new CacheLoader<String,CellArray>() {
                                @Override
                                public CellArray load( String key ) {
                                    CellArray result = delegate.apply(key);
                                    return result == null ? nullObject : result;
                                }
                            });
            CacheTracker.track(cache, "SingletonCellArrayCache@" + System.identityHashCode(this), true);
        }

        public CellArray apply( String name ) {
            CellArray result = cache.getUnchecked(name);
            return result == nullObject ? null : result;
        }
    }

    public static class CellArrayStorageFunctionChain implements Function<String, CellArray> {
        private Function[] delegates;

        public CellArrayStorageFunctionChain( Function... delegates ) {
            this.delegates = delegates;
        }

        @SuppressWarnings("unchecked")
        public CellArray apply( String name ) {
            for( Function f : delegates ) {
                Object result = f.apply(name);
                if( result != null ) {
                    return (CellArray)result;
                }
            }
            return null;
        }
    }

    public static class CellArrayStorageFunction implements Function<String, CellArray> {
        private String extension;
        private Function<CellArrayId, CellArray> storage;

        public CellArrayStorageFunction( String extension, Function<CellArrayId, CellArray> storage ) {
            this.extension = extension;
            this.storage = storage;
        }

        protected CellArrayId nameToId( String name ) {
            // Convenient to allow prefix decorators.
            int split = name.lastIndexOf("_");
            if( split >= 0 ) {
                name = name.substring(split + 1);
            }
            return CellArrayId.fromFileName(name);
        }

        public CellArray apply( String name ) {
            if( !name.endsWith(extension) ) {
                return null;
            }
            CellArrayId id = nameToId(name);
            if( id == null ) {
                return null;
            }
            log.info("Loading from storage, cell array:" + id);
            return storage.apply(id);
        }
    }

    public static class BlocksFunction implements Function<String, CellArray> {
        private String extension;

        public BlocksFunction( String extension ) {
            this.extension = extension;
        }

        public CellArray apply( String name ) {
            if( !name.endsWith(extension) ) {
                return null;
            }
            try {
                log.info("Loading .blocks:" + name);
                return BlocksFileFormat.loadCellArray(name);
            } catch( Exception e ) {
                throw new RuntimeException("Error loading resource:" + name, e);
            }
        }
    }

    public static class BlocksFileFunction implements Function<String, CellArray> {
        private File root;
        private String extension;

        public BlocksFileFunction( File root, String extension ) {
            this.root = root;
            this.extension = extension;
        }

        public CellArray apply( String name ) {
            if( !name.endsWith(extension) ) {
                return null;
            }
            File file = new File(root, name);
            if( !file.exists() ) {
                return null;
            }
            try {
                log.info("Loading .blocks:" + file);
                return BlocksFileFormat.readBlocks(file, true).cells;
            } catch( Exception e ) {
                throw new RuntimeException("Error loading file:" + file, e);
            }
        }
    }
}


