/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mblock;

import java.util.*;

import org.slf4j.*;

import com.jme3.material.Material;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.*;
import com.jme3.scene.shape.*;
import com.jme3.scene.VertexBuffer.Type;

import com.simsilica.es.EntityId;
import com.simsilica.ext.mphys.debug.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;

import com.simsilica.lemur.GuiGlobals;

/**
 *  Descends down a body's parts hierarchy and adds debug shapes for
 *  each part.  Note: this does not automatically deal with animated parts
 *  but can be useful for debugging static (static at the time, anyway)
 *  part hierarchies.
 *
 *  @author    Paul Speed
 */
public class PartDebugShapeFactory implements DebugShapeFactory<MBlockShape> {

    static Logger log = LoggerFactory.getLogger(PartDebugShapeFactory.class);

    private Mesh axesMesh;
    private Geometry axesTemplate;
    private Mesh cogMesh;
    private Mesh boundsSphere;
    private ColorRGBA groupBoundsColor = new ColorRGBA(0.1f, 0.1f, 0.1f, 0.2f);
    private ColorRGBA partBoundsColor = new ColorRGBA(0, 1, 1, 0.25f);
    private ColorRGBA errorBoundsColor = new ColorRGBA(1, 0, 0, 0.8f);

    @Override
    public void initialize( BodyDebugState<MBlockShape> parent ) {
        // Create some template geometry
        float axesSize = 0.1f;
        axesMesh = new Mesh();
        axesMesh.setMode(Mesh.Mode.Lines);
        axesMesh.setBuffer(Type.Position, 3,
            new float[] {
                0, 0, 0, axesSize,  0,          0,
                0, 0, 0, 0,         axesSize,   0,
                0, 0, 0, 0,         0,          axesSize
            });
        axesMesh.setBuffer(Type.Color, 4,
            new float[] {
                1, 0, 0, 1, 1, 0, 0, 1,
                0, 1, 0, 1, 0, 1, 0, 1,
                0, 0, 1, 1, 0, 0, 1, 1
            });
        axesTemplate = new Geometry("axes", axesMesh);
        axesTemplate.setQueueBucket(Bucket.Translucent);
        Material mat = GuiGlobals.getInstance().createMaterial(new ColorRGBA(1, 1, 1, 0.5f), false).getMaterial();
        mat.setBoolean("VertexColor", true);
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        axesTemplate.setMaterial(mat);

        float cogSize = axesSize * 0.1f;
        cogMesh = new WireBox(cogSize, cogSize, cogSize);

        boundsSphere = new Sphere(24, 24, 1);

    }

    @Override
    public void terminate( BodyDebugState<MBlockShape> parent ) {
    }

    @Override
    public void addDebugShape( RigidBody<EntityId, MBlockShape> body, Node view, ColorRGBA temperature ) {

        log.info("body mass:" + body.shape.getMass());

        // So that we can adjust parts later, we'll keep track of them
        PartDebugView debugView = new PartDebugView();
        view.attachChild(debugView);

        //addDebugShape(body.shape.getPart(), body, debugView, temperature);
        updateDebugShape(body.shape.getPart(), body, debugView, null);
    }

    @Override
    public void updateDebugShape( RigidBody<EntityId, MBlockShape> body, Node view, ColorRGBA temperature ) {
        //updateDebugShape(body.shape.getPart(), body, view, 0);
        // Find the PartDebugView we created before.
        PartDebugView debugView = (PartDebugView)view.getChild("partDebugView");
        Set<Part> toRemove = new HashSet<>(debugView.axes.keySet());
        updateDebugShape(body.shape.getPart(), body, debugView, toRemove);
        debugView.removeParts(toRemove);
    }

    @Override
    public void addDebugShape( StaticBody<EntityId, MBlockShape> body, Node view, ColorRGBA temperature ) {

        // So that we can adjust parts later, we'll keep track of them
        PartDebugView debugView = new PartDebugView();
        view.attachChild(debugView);

        updateDebugShape(body.shape.getPart(), body, debugView, null);
    }

    @Override
    public void updateDebugShape( StaticBody<EntityId, MBlockShape> body, Node view, ColorRGBA temperature ) {
        // Find the PartDebugView we created before.
        PartDebugView debugView = (PartDebugView)view.getChild("partDebugView");
        Set<Part> toRemove = new HashSet<>(debugView.axes.keySet());
        updateDebugShape(body.shape.getPart(), body, debugView, toRemove);
        debugView.removeParts(toRemove);
    }

    protected void updateDebugShape( Part part, AbstractBody<EntityId, MBlockShape> body, PartDebugView view, Set<Part> toRemove ) {

        view.updatePart(part, body);
        if( toRemove != null ) {
            toRemove.remove(part);
        }
        if( part instanceof CellArrayPart ) {
            updateDebugShape((CellArrayPart)part, body, view, toRemove);
        } else if( part instanceof Group ) {
            updateDebugShape((Group)part, body, view, toRemove);
        }
    }

    protected void updateDebugShape( Group group, AbstractBody<EntityId, MBlockShape> body, PartDebugView view, Set<Part> toRemove ) {
        for( Part p : group.getChildren() ) {
            updateDebugShape(p, body, view, toRemove);
        }
    }

    protected void updateDebugShape( CellArrayPart part, AbstractBody<EntityId, MBlockShape> body, PartDebugView view, Set<Part> toRemove ) {
        //log.info("addDebugShape for:" + part);
    }

    @Override
    public void releaseDebugShape( RigidBody<EntityId, MBlockShape> body, Node view ) {
    }

    @Override
    public void releaseDebugShape( StaticBody<EntityId, MBlockShape> body, Node view ) {
    }

    private class PartDebugView extends Node {

        private Map<Part, Geometry> axes = new HashMap<>();
        private Map<Part, Geometry> spheres = new HashMap<>();

        public PartDebugView() {
            super("partDebugView");
        }

        public void removeParts( Iterable<Part> parts ) {
            for( Part p : parts ) {
                Geometry geom = axes.remove(p);
                if( geom != null ) {
                    geom.removeFromParent();
                }
                geom = spheres.remove(p);
                if( geom != null ) {
                    geom.removeFromParent();
                }
            }
        }

        public void updatePart( Part part, AbstractBody<EntityId, MBlockShape> body ) {

            Vec3d cog = body.shape.getMass().getCog();
            Vec3d partPos = part.getShapeRelativeCog().subtract(cog);
            Quatd rotation = part.getShapeRelativeOrientation();

            Geometry geom = axes.get(part);
            if( geom == null ) {
                geom = axesTemplate.clone();
                attachChild(geom);
                axes.put(part, geom);
            }
            geom.setLocalTranslation(partPos.toVector3f());
            geom.setLocalRotation(rotation.toQuaternion());

            double radius = part.getMass().getRadius();

            //log.info("part:" + part.getName() + "  cog:" + cog + "  part pos:" + partPos);

            ColorRGBA boundsColor;
            if( part instanceof CellArrayPart ) {
                boundsColor = partBoundsColor;
                CellArrayPart cellPart = (CellArrayPart)part;
                if( cellPart.getType() == CellArrayPart.Type.Blocks ) {
                    partPos = cellPart.getShapeRelativePosition().subtract(cog);
                }
            } else if( part instanceof Group ) {
                boundsColor = groupBoundsColor;
            } else {
                boundsColor = errorBoundsColor;
            }

            boolean showBoundsSphere = false;

            geom = spheres.get(part);
            if( geom == null ) {
                if( part instanceof CellArrayPart ) {
                    CellArrayPart cellPart = (CellArrayPart)part;
                    if( cellPart.getType() == CellArrayPart.Type.Sphere ) {
                        geom = new Geometry("partSphere", boundsSphere);
                        geom.setLocalScale((float)radius);
                    } else {
                        Vec3d min = new Vec3d(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                        Vec3d max = new Vec3d(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
                        cellPart.calculateCellBounds(min, max);
                        min.multLocal(cellPart.getScale());
                        max.multLocal(cellPart.getScale());

                        Box box = new Box(min.toVector3f(), max.toVector3f());
                        geom = new Geometry("boundingBox", box);
                    }
                } else {
                    geom = new Geometry("boundingSphere", boundsSphere);
                    if( showBoundsSphere ) {
                        geom.setLocalScale((float)radius);
                    } else {
                        geom.setLocalScale((float)0.00001f);
                    }
                }
                Material mat = GuiGlobals.getInstance().createMaterial(boundsColor, false).getMaterial();
                mat.getAdditionalRenderState().setWireframe(true);
                mat.getAdditionalRenderState().setLineWidth(5);
                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                geom.setMaterial(mat);
                geom.setQueueBucket(Bucket.Translucent);
                attachChild(geom);
                spheres.put(part, geom);
            } else {
                geom.getMaterial().setColor("Color", boundsColor);
                //geom.setLocalScale((float)radius);
            }

            geom.setLocalTranslation(partPos.toVector3f());
            geom.setLocalRotation(rotation.toQuaternion());
        }
    }
}


