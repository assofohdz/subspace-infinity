/*
 * $Id$
 * 
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mblock;

import org.slf4j.*;

import com.simsilica.es.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.db.CellArrayId;
import com.simsilica.mblock.db.CellArrayStorage;
import com.simsilica.mblock.io.BlocksFileFormat;
import com.simsilica.mblock.phys.*;
import com.simsilica.ext.mphys.*;

/**
 *  Creates MBlockShapes from .blocks file resources or .ca CellArrayStorage
 *  resources if one has been provided. 
 *
 *  @author    Paul Speed
 */
public class BlocksResourceShapeFactory implements ShapeFactory<MBlockShape> {
    static Logger log = LoggerFactory.getLogger(BlocksResourceShapeFactory.class);
 
    public BlocksResourceShapeFactory() {
    }
    
    public MBlockShape createShape( String name, double scale, Mass mass ) {
        log.info("createShape(" + name + ", " + scale + ", " + mass + ")");
        
        double m = mass == null ? 0 : mass.getMass();
        CellArray cells = loadCells(name);
        
        return MBlockShape.createShape(name, cells, scale, m);
    }
    
    protected CellArray loadCells( String name ) {
        try {
            log.info("loading:" + getClass().getResource(name));            
            return BlocksFileFormat.loadCellArray(name);
        } catch( Exception e ) {
            throw new RuntimeException("Error loading block resource:" + name, e);
        }
    }
}
