/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mblock;

import java.util.*;
import java.util.function.Function;
 
import org.slf4j.*;

import com.google.common.reflect.TypeToken;

import com.simsilica.es.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;
import com.simsilica.ext.mphys.*;

/**
 *  Uses a list of Suppliers in chop-chain style to convert a string
 *  to a CellArray.
 *
 *  @author    Paul Speed
 */
public class BlockShapeFactory implements ShapeFactory<MBlockShape> {
    static Logger log = LoggerFactory.getLogger(BlockShapeFactory.class);
    
    private DynArray<Function<String, CellArray>> delegates 
            = new DynArray<>(new TypeToken<Function<String, CellArray>>() {} ); 
 
    public BlockShapeFactory() {
    }
    
    public void addDelegate( Function<String, CellArray> delegate ) {
        this.delegates.add(delegate);
    }
    
    public List<Function<String, CellArray>> getDelegates() {
        return delegates;
    }
    
    public MBlockShape createShape( String name, double scale, Mass mass ) {
        if( log.isTraceEnabled() ) {
            log.trace("createShape(" + name + ", " + scale + ", " + mass + ")");
        }
        
        double m = mass == null ? 0 : mass.getMass();
        CellArray cells = loadCells(name);
        if( cells == null ) {
            return null;
        }
        
        return MBlockShape.createShape(name, cells, scale, m);
    }
    
    protected CellArray loadCells( String name ) {
        for( Function<String, CellArray> f : delegates.getArray() ) {
            CellArray result = f.apply(name);
            if( result != null ) {
                return result;
            }
        }
        return null;
    }
}
