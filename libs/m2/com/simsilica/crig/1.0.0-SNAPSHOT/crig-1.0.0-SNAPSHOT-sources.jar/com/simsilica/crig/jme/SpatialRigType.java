/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.anim.tween.*;
import com.jme3.anim.tween.action.*;
import com.jme3.export.binary.BinaryExporter;
import com.jme3.export.binary.BinaryImporter;
import com.jme3.scene.*;
import com.jme3.scene.shape.Quad;

import com.simsilica.mblock.phys.*;
import com.simsilica.ext.mphys.Mass;
import com.simsilica.ext.mphys.ShapeInfo;

import com.simsilica.crig.*;

/**
 *  RigType that wraps a JME spatial containing AnimComposer and SkinningControls.
 *
 *  @author    Paul Speed
 */
public class SpatialRigType implements RigType, Serializable {
    static Logger log = LoggerFactory.getLogger(SpatialRigType.class);

    static final long serialVersionUID = 42L;

    // Spatial is transient because we will have to save/load it ourselves
    private transient Spatial spatial;
    private List<ColliderInfo> colliders;
    private List<AttachmentInfo> attachments;
    private List<BlendInfo> blends;
    private List<RigTypeInitializer> initializers;
    private transient Map<String, VariationHandler> variationHandlers = new HashMap<>();
    private transient boolean initialized;

    public SpatialRigType( Spatial spatial,
                           List<ColliderInfo> colliders,
                           List<AttachmentInfo> attachments,
                           List<BlendInfo> blends,
                           List<RigTypeInitializer> initializers ) {
        this.spatial = spatial.clone();
        this.colliders = colliders;
        this.attachments = attachments;
        this.blends = blends;
        this.initializers = initializers;

        // Now, I believe we can nuke all of the rendering related stuff to
        // make our serialization lives a little easier.
        // In an ideal world, we'd have decomposed the animation into something
        // independent of JME... but that's a LOT of work.  In the mean time,
        // we can at least collapse out the parts that we know we won't use.
        // In the future, we could even collapse the node hierarchy to remove
        // any extra parents between spatial and the geometry with the controls
        // and perhaps even remove all other children.
        // In the mean time, we will remove the materials so that we don't
        // need assest and we will remove meshes so that we don't have a lot
        // of unneeded vertex buffer data.
        this.spatial.depthFirstTraversal(new SceneGraphVisitorAdapter() {
                public void visit( Geometry geom ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("Clearing mesh from:" + geom);
                    }
                    geom.setMaterial(null);

                    // Geometry doesn't let us completely clear the mesh
                    // and save/load from binary exporter will fail with a totally
                    // empty mesh.
                    geom.setMesh(new Quad(1, 1));
                }
            });
        initialize();
    }

    protected void setVariationHandler( String type, VariationHandler handler ) {
        variationHandlers.put(type, handler);
    }

    protected VariationHandler getVariationHandler( String type ) {
        return variationHandlers.get(type);
    }

    protected Set<String> getVariationTypes() {
        return variationHandlers.keySet();
    }

    protected List<RigTypeInitializer> getInitializers() {
        return initializers;
    }

    protected void initialize() {
        if( log.isTraceEnabled() ) {
            log.trace("initialize() initializers:" + initializers);
        }
        if( initialized ) {
            return;
        }
        this.variationHandlers = new HashMap<>();
        if( initializers == null ) {
            log.warn("Rig has no initializers:" + spatial.getKey() + " spatial:" + spatial);
        } else {
            for( RigTypeInitializer init : initializers ) {
                if( log.isTraceEnabled() ) {
                    log.trace("running:" + init);
                }
                init.initializeRigType(this);
            }
        }
        this.initialized = true;
    }

    public RigShape createShape( String name, double scale, Mass mass ) {
        initialize();

        // MBlockSpae/Part are not cloneable so for now we will recreate the shape
        // every time
        Spatial view = spatial.clone();
        view.setLocalScale((float)scale);
        final AnimComposer anim = AnimComposerRig.findControl(view, AnimComposer.class);
        if( anim == null ) {
            throw new IllegalArgumentException("View has no anim composer");
        }
        final SkinningControl skin = AnimComposerRig.findControl(view, SkinningControl.class);

        // For our clone, we want to carefully control updates and not
        // have any autoadvance.
        anim.setGlobalSpeed(0);

        double m = mass == null ? 0 : mass.getMass();

        Group root = new Group("rig");

        // For now we'll give all of the mass to the first collider shape
        boolean first = true;

        List<ColliderShape> shapes = new ArrayList<>();

        for( ColliderInfo c : colliders ) {
            if( log.isTraceEnabled() ) {
                log.trace("c:" + c);
            }

            if( skin.getArmature().getJoint(c.getJoint()) == null ) {
                log.warn("No joint found for:" + c.getJoint());
                continue;
            }
            Node att = skin.getAttachmentsNode(c.getJoint());
            double partMass = 0.01; // I'd rather give 0 but apparently that causes a crash
            if( first ) {
                partMass = m;
                first = false;
            }

            CellArrayPart part;
            if( c.getShape() == null ) {
                part = CellArrayPart.createSphere(c.getName(), c.getScale() * scale, partMass);
            } else {
                part = CellArrayPart.createShape(c.getName(), c.getShape(), c.getScale() * scale, partMass);
            }

            ColliderShape shape = new ColliderShape(c, att, part);
            shape.update();

            root.addChild(part);

            shapes.add(shape);
        }

        ColliderShape[] array = shapes.toArray(new ColliderShape[0]);

        List<AttachmentPointImpl> points = new ArrayList<>();
        if( attachments != null ) {
            for( AttachmentInfo a : attachments ) {
                if( log.isTraceEnabled() ) {
                    log.trace("a:" + a);
                }

                if( skin.getArmature().getJoint(a.getJoint()) == null ) {
                    log.warn("No joint found for:" + a.getJoint());
                    continue;
                }
                Node node = skin.getAttachmentsNode(a.getJoint());

                AttachmentPointImpl point = new AttachmentPointImpl(a, node);
                point.update();
                points.add(point);
            }
        }
        AttachmentPointImpl[] pointArray = points.toArray(new AttachmentPointImpl[0]);

        // It's possible that we could save ourselves some trouble by passing an
        // AttachmentControl on and no longer managing attachment points here
        CharacterRig delegate = new AnimComposerRig(anim, null);

        if( blends != null ) {
            for( BlendInfo blend : blends ) {
                if( log.isTraceEnabled() ) {
                    log.trace("blend:" + blend);
                }
                BlendAction ba = anim.actionBlended(blend.getName(), new LinearBlendSpace(0, 1),
                                                    blend.getBlendedActions());
                ba.getBlendSpace().setValue((float)blend.getDefaultBlend());
            }
        } else {
            log.warn("BlendInfo list is null, this might be an older serialized version");
        }

        return new AnimComposerShape(this, root, delegate,
                () -> {
                    //log.info("AnimComposerShape(" + name + ") anim/skin update");
                    anim.update(0.1f);
                    skin.update(0.1f);
                },
                array, pointArray);
    }

    /**
     *  Kind of a hack to make sure that a separately loaded Spatial
     *  can have its anim composer configured with any extra setup this
     *  rig requires.  This is because blended actions and stuff can't
     *  be saved with the Spatial.
     */
    public void configureSpatial( Spatial view ) {
        initialize();

        final AnimComposer anim = AnimComposerRig.findControl(view, AnimComposer.class);
        anim.setGlobalSpeed(0);
        if( blends != null ) {
            for( BlendInfo blend : blends ) {
                if( log.isTraceEnabled() ) {
                    log.trace("blend:" + blend);
                }
                BlendAction ba = anim.actionBlended(blend.getName(), new LinearBlendSpace(0, 1),
                                                    blend.getBlendedActions());
                ba.getBlendSpace().setValue((float)blend.getDefaultBlend());
            }
        } else {
            log.warn("BlendInfo list is null, this might be an older serialized version");
        }

        // And since we're here... maybe we can do some other stuff like
        // make attachment points available even for spatial users
        AttachmentControl existing = AnimComposerRig.findControl(view, AttachmentControl.class);
        if( existing != null ) {
            throw new IllegalArgumentException("View already has an attachment control.");
        }
        view.addControl(new AttachmentControl(this));
    }

    protected AttachmentInfo findAttachmentInfo( String name ) {
        if( attachments == null ) {
            return null;
        }
        for( AttachmentInfo att : attachments ) {
            if( Objects.equals(att.getName(), name) ) {
                return att;
            }
        }
        return null;
    }

    // Tricky magic to save/load the Spatial as part of regular Java
    // serialization
    private void readObject( ObjectInputStream stream ) throws IOException, ClassNotFoundException {
        stream.defaultReadObject();

        byte[] array = (byte[])stream.readObject();
        this.spatial = (Spatial)BinaryImporter.getInstance().load(array);
        if( log.isTraceEnabled() ) {
            log.trace("read spatial array size:" + array.length);
        }
    }

    private void writeObject( ObjectOutputStream stream ) throws IOException {
        stream.defaultWriteObject();

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        BinaryExporter.getInstance().save(spatial, bos);

        byte[] array = bos.toByteArray();
        stream.writeObject(array);
        if( log.isTraceEnabled() ) {
            log.trace("wrote spatial array size:" + array.length);
        }
    }
}
