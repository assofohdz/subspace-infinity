/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.sim;

import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.es.*;
import com.simsilica.ethereal.zone.ZoneManager;
import com.simsilica.mathd.*;

import com.simsilica.bpos.BodyPosition;
import com.simsilica.mblock.phys.MBlockShape;
import com.simsilica.ext.mphys.MPhysSystem;
import com.simsilica.ext.mphys.ObjectStatusAdapter;
import com.simsilica.ext.mphys.net.ZoneNetworkListener;
import com.simsilica.ext.mphys.net.ZoneNetworkSystem;
import com.simsilica.mphys.*;
import com.simsilica.sim.*;

import com.simsilica.crig.*;
import com.simsilica.crig.es.*;

/**
 *  Makes sure that animation state gets properly passed over the
 *  the network.
 *
 *  @author    Paul Speed
 */
public class CharacterAnimationSystem extends AbstractGameSystem {
    static Logger log = LoggerFactory.getLogger(CharacterAnimationSystem.class);

    // Note: the listener/entity management of this system is a little more
    // complicated than most systems because we only want to manage the
    // animation for loaded RigidBodies that have an AnimationConfig component
    // targeting them.  We don't want to manage all of the AnimationConfig entities
    // because there could be hundreds/thousands in the world while only a tiny
    // subset are actually active physics objects.
    // This means we need to watch for loaded rigid bodies and marry them to
    // animation configs.  We also need to watch AnimationConfigs in case they
    // are added/removed separately from the rigid body.
    // And then to be 100% accurate, we should also check for any existing bodies
    // when we start up... but for the moment we are doing to assume that we are
    // initialized before physics is started.  If future-me decides to dynamically
    // add the CharacterAnimationSystem post-startup then I appologize for not
    // implementing that piece.  2022-01-01

    private EntityData ed;
    private MPhysSystem<MBlockShape> physics;
    private PhysicsSpace<EntityId, MBlockShape> space;
    private ZoneManager zones;

    private ZoneNetworkObserver zoneObserver = new ZoneNetworkObserver();
    private PhysicsObserver physicsObserver = new PhysicsObserver();

    // Keep track of characters that we've removed so that the networking
    // can be updated, too.
    private Set<AnimatedCharacter> removeFromZones = new HashSet<>();

    private ConcurrentLinkedQueue<EntityChange> changes = new ConcurrentLinkedQueue<>();
    private EntityChangeObserver entityChangeObserver = new EntityChangeObserver();

    private Multimap<EntityId, AnimatedCharacter> bodyIndex = MultimapBuilder.hashKeys().hashSetValues().build();
    private Map<EntityId, AnimatedCharacter> charIndex = new HashMap<>();
    private DynArray<AnimatedCharacter> characters = new DynArray<>(AnimatedCharacter.class);

    public CharacterAnimationSystem() {
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize() {
        this.ed = getSystem(EntityData.class, true);
        this.physics = (MPhysSystem<MBlockShape>)getSystem(MPhysSystem.class, true);
        this.space = physics.getPhysicsSpace();

        this.zones = getSystem(ZoneNetworkSystem.class, true).getZones();
        getSystem(ZoneNetworkSystem.class, true).addZoneNetworkListener(zoneObserver);

        physics.getBinEntityManager().addObjectStatusListener(physicsObserver);
    }

    @Override
    protected void terminate() {
        getSystem(ZoneNetworkSystem.class, true).removeZoneNetworkListener(zoneObserver);
        physics.getBinEntityManager().removeObjectStatusListener(physicsObserver);
    }

    @Override
    public void start() {
        ((ObservableEntityData)ed).addEntityComponentListener(entityChangeObserver);
    }

    @Override
    public void update( SimTime time ) {
        // Apply any accumulated changes
        EntityChange change = null;
        while( (change = changes.poll()) != null ) {
            processChange(change);
        }

        //for( AnimatedCharacter ac : characters.getArray() ) {
        //    ac.updateTimes();
        //    log.info("Need to update:" + ac + "  rig:" + ac.times + "  mixes:" + ac.mixes);
        //}
    }

    @Override
    public void stop() {
        ((ObservableEntityData)ed).removeEntityComponentListener(entityChangeObserver);
    }

    protected void processChange( EntityChange change ) {
        if( change.getComponentType() != AnimationConfig.class ) {
            return;
        }

        AnimationConfig animConfig = (AnimationConfig)change.getComponent();
        if( animConfig == null ) {
            // It was removed
            AnimatedCharacter ac = charIndex.get(change.getEntityId());
            if( ac == null ) {
                // We weren't managing it anyway
                return;
            }

            // Remove it from the main body index
            if( bodyIndex.remove(ac.targetEntity, ac) ) {
                removeCharacter(ac);
            }
        } else {
            AnimatedCharacter ac = charIndex.get(change.getEntityId());
            if( ac == null ) {
                // It could be a new animated char added to an existing rigid body
                RigidBody<EntityId, MBlockShape> body = space.getBinIndex().getRigidBody(animConfig.getTarget());
                if( body != null ) {
                    addCharacter(animConfig.getTarget(), body, change.getEntityId());
                }
            } else {
                // Just update the component
                ac.update(animConfig);
            }
        }
    }

    protected void addCharacter( EntityId target, RigidBody<EntityId, MBlockShape> body, EntityId animId ) {
        if( log.isTraceEnabled() ) {
            log.trace("addAnimatedCharacter(" + target + ")");
        }
        AnimationConfig config = ed.getComponent(animId, AnimationConfig.class);
        AnimatedCharacter ac = new AnimatedCharacter(animId, config);
        ac.initialize(body);
        ac.updateState();

        characters.add(ac);
        bodyIndex.put(target, ac);
        charIndex.put(animId, ac);
    }

    protected void removeCharacter( AnimatedCharacter ac ) {
        if( log.isTraceEnabled() ) {
            log.trace("removeAnimatedCharacter(" + ac + ")");
        }
        characters.remove(ac);
        charIndex.remove(ac.animEntity);
        ac.release();
        removeFromZones.add(ac);
    }

    protected void updateNetworkData( long frameTime ) {

        // process the removals first, though it hardly matters
        if( !removeFromZones.isEmpty() ) {
            for( AnimatedCharacter ac : removeFromZones ) {
                // Note: it may be true that we have to send one last
                // update also.
                zones.remove(ac.animEntity.getId());
            }
            removeFromZones.clear();
        }

        for( AnimatedCharacter ac : characters.getArray() ) {

            // Make sure the state holders are up to date
            ac.updateTimesAndMixes();

            //log.info("ac target:" + ac.targetEntity.getId() + "  anim:" + ac.animEntity.getId() + "  times:" + ac.times);
            // Update the shared network object
            zones.updateEntity(
                ac.targetEntity.getId(),
                ac.animEntity.getId(),
                true,
                ac.times, ac.mixes,
                ac.body.getWorldBounds()
                );

            // The problem is that when we wrap we have to tween backwards
            // through time and it makes weird frame jumps.  The client can detect and
            // fix it if it looks for large time jumps.

            // For posterity we will update the BodyPosition but
            // nothing should be using it.  I just have a suspicion that
            // future-me might wonder why it isn't getting updates if dumping
            // the raw data some time in the future.
            ac.pos.addFrame(frameTime, ac.targetEntity, ac.times, ac.mixes, true);
        }
    }

    private class AnimatedCharacter implements RigListener {
        private EntityId targetEntity;
        private EntityId animEntity;
        private AnimationConfig config;
        private RigidBody<EntityId, MBlockShape> body;
        private RigShape rig;
        private Vec3d times = new Vec3d();
        private Quatd mixes = new Quatd();

        // We will keep a child body position for this entity so
        // that the simethereal networking has something to chomp on.
        private BodyPosition pos;

        public AnimatedCharacter( EntityId animEntity, AnimationConfig config ) {
            this.animEntity = animEntity;
            this.config = config;
            this.targetEntity = config.getTarget();

            // See if this entity already has a BodyPosition
            this.pos = ed.getComponent(animEntity, BodyPosition.class);
            if( pos == null ) {
                // Create it the same way that BodyPositionPublisher does for the
                // regular physics objects.
                pos = new BodyPosition(3);

                // With this, clients should be able to see the body position
                // also.
                ed.setComponent(animEntity, pos);
            }
        }

        public void initialize( RigidBody<EntityId, MBlockShape> body ) {
            this.body = body;
            this.rig = (RigShape)body.shape;
            rig.addRigListener(this);
        }

        public void release() {
            rig.removeRigListener(this);
            if( log.isTraceEnabled() ) {
                log.trace("Removing BodyPosition for:" + animEntity);
            }
            ed.removeComponent(animEntity, BodyPosition.class);

            // Clear references so that callers know we're done with this one
            rig = null;
            pos = null;
        }

        public void updateState() {
            int timeIndex = 0;
            int mixIndex = 0;
            for( LayerConfig lc : config.getLayers() ) {
                times.set(timeIndex++, rig.getTime(lc.getLayer()));
                String action = rig.getLayerAction(lc.getLayer());
                mixes.set(mixIndex++, lc.getPart(action));
            }
            for( MixConfig mc : config.getMixes() ) {
                mixes.set(mixIndex++, rig.getMix(mc.getBlendName()));
            }
        }

        public void update( AnimationConfig config ) {
            if( !Objects.equals(this.config.getTarget(), config.getTarget()) ) {
                // Should never happen... but just in case
                throw new UnsupportedOperationException("Rehoming an AnimationConfig is not supported, targetEntity:" + targetEntity + " old:" + this.config + " new:" + config);
            }
            this.config = config;
            updateState();
        }

        @Override
        public void mixChanged( String blendId, double value ) {
        }

        public void updateTimesAndMixes() {
            int timeIndex = 0;
            int mixIndex = 0;
            for( LayerConfig lc : config.getLayers() ) {
                times.set(timeIndex++, rig.getTime(lc.getLayer()));
                mixIndex++;
            }
            for( MixConfig mc : config.getMixes() ) {
                mixes.set(mixIndex++, rig.getMix(mc.getBlendName()));
            }
        }

        // Not used?
        public void timeChanged( String layer, double time ) {
            int index = 0;
            for( LayerConfig lc : config.getLayers() ) {
                if( Objects.equals(layer, lc.getLayer()) ) {
                    times.set(index, time);
                }
                index++;
            }
        }

        @Override
        public void layerActionChanged( String layer, String action ) {
            int index = 0;
            for( LayerConfig lc : config.getLayers() ) {
                if( Objects.equals(layer, lc.getLayer()) ) {
                    mixes.set(index, lc.getPart(action));
                }
                index++;
            }
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[target:" + targetEntity + "]";
        }
    }

    /**
     *  In case animation config components are added/removed independently
     *  of RigidBody lifecycle, we will catch the changes and then look for
     *  related bodies if they exist.
     */
    private class EntityChangeObserver implements EntityComponentListener {

        @Override
        public void componentChange( EntityChange change ) {
            // We only care about a few components and we should quickly
            // short-circuit otherwise to avoid lag
            Class type = change.getComponentType();
            if( type != AnimationConfig.class ) {
                return;
            }
            // Queue the change for processing on the game loop thread.
            changes.add(change);
        }
    }

    /**
     *  Watches for loaded and unloaded bodies so that we
     *  can manage any animations they might have.
     */
    private class PhysicsObserver extends ObjectStatusAdapter<MBlockShape> {
        public PhysicsObserver() {
        }

        @Override
        public void objectLoaded( EntityId entity, RigidBody<EntityId, MBlockShape> body ) {

            if( log.isTraceEnabled() ) {
                log.trace("objectLoaded(" + entity + ") body shape:" + body.shape);
            }

            // Ideally we'd try to match up any body with any entity that
            // had the AnimationConfig... but AnimationConfigs are not attached directly
            // to their target and realistically if a body doesn't have a rig shape then
            // we can't manage it anyway.
            if( !(body.shape instanceof RigShape) ) {
                return;
            }

            if( log.isTraceEnabled() ) {
                log.trace("Searching for anim config entities for:" + entity);
            }

            // Find any animation character entities that might point to this entity
            ComponentFilter<AnimationConfig> filter = Filters.fieldEquals(AnimationConfig.class, "target", entity);
            for( EntityId animId : ed.findEntities(filter, AnimationConfig.class) ) {
                addCharacter(entity, body, animId);
            }
        }

        @Override
        public void objectUnloaded( EntityId entity, RigidBody<EntityId, MBlockShape> body ) {
            if( log.isTraceEnabled() ) {
                log.trace("objectUnloaded(" + entity + ")");
            }

            if( !(body.shape instanceof RigShape) ) {
                return;
            }
            for( AnimatedCharacter ac : bodyIndex.removeAll(entity) ) {
                removeCharacter(ac);
            }
        }
    }

    /**
     *  Need to send our animation updates only between begindUpdate and endUpdate()
     *  so we will do it at endUpdate()
     */
    private class ZoneNetworkObserver implements ZoneNetworkListener {
        private long frameTime;

        public void beginUpdate( long frameTime ) {
            this.frameTime = frameTime;
        }

        public void endUpdate() {
//            log.info("endUpdate()");
            updateNetworkData(frameTime);
        }
    }


}


