/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig;

import java.io.Serializable;
import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Defines the parameters of a blended set of actions.
 *  (This really only exists because JME doesn't provide a way
 *  to bake this into the animation.)
 *
 *  @author    Paul Speed
 */
public class BlendInfo implements Serializable {
    static Logger log = LoggerFactory.getLogger(BlendInfo.class);

    static final long serialVersionUID = 42L;

    private String name;
    private String[] actions;
    private double defaultBlend;

    public BlendInfo() {
    }

    public BlendInfo( String name ) {
        this.name = name;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setBlendedActions( String... actions ) {
        this.actions = actions;
    }
    
    public String[] getBlendedActions() {
        return actions;
    }

    public void setDefaultBlend( double defaultBlend ) {
        this.defaultBlend = defaultBlend;
    }
    
    public double getDefaultBlend() {
        return defaultBlend;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[name=" + getName() + ", defaultBlend=" + defaultBlend + ", blendedActions=" + Arrays.asList(actions) + "]";
    }
}

