/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import org.slf4j.*;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial;

import com.simsilica.mathd.Quatd;
import com.simsilica.mathd.Vec3d;
import com.simsilica.mblock.phys.Part;

import com.simsilica.crig.*;

/**
 *  Links an joint + collider info to a MBlockShape Part.
 *
 *  @author    Paul Speed
 */
public class ColliderShape {
    static Logger log = LoggerFactory.getLogger(ColliderShape.class);

    private ColliderInfo info;
    private Part target;
    private Spatial source;

    public ColliderShape( ColliderInfo info, Spatial source, Part target ) {
        this.info = info;
        this.source = source;
        this.target = target;
    }

    public void update() {
        Vec3d offset = info.getOffset();
        Quatd orient = info.getOrientation();
        
        // For models that are scaled differently overall then the offsets
        // need to be similary scaled into local space before reversing... else
        // they won't line up.  It's possible that we could/should bake this
        // scaling into the info offsets but it's also possible that the model
        // itself could have joint scales.  When that happens we'll have to
        // examine if it makes more sense to bake in a global scale or have
        // these autoscale (I suspect that we _don't_ want them to autoscale
        // since we are using them as collision shapes but it really depends
        // on whether the use-case is shape keys or animated scales.)
        // -pspeed:2022-04-30
        offset = offset.divide(new Vec3d(source.getWorldScale()));
        Vector3f local = source.localToWorld(offset.toVector3f(), null);
        Quaternion localRot = source.getWorldRotation().mult(orient.toQuaternion());

        if( log.isTraceEnabled() ) {
            log.trace("updating part:" + target.getName() + "  to:" + local);
        }

        target.setLocalPosition(new Vec3d(local));
        target.setLocalOrientation(new Quatd(localRot));
    }
}

