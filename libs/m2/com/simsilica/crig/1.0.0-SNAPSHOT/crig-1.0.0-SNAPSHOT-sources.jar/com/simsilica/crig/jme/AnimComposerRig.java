/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.anim.tween.*;
import com.jme3.anim.tween.action.*;
import com.jme3.scene.*;
import com.jme3.scene.control.*;

import com.simsilica.crig.*;

/**
 *  JME-specific implementation of the CharacterRig interface
 *  that talks to a JME AnimComposer control
 *
 *  @author    Paul Speed
 */
public class AnimComposerRig implements CharacterRig {
    static Logger log = LoggerFactory.getLogger(AnimComposerRig.class);

    private AnimComposer anim;
    private AttachmentControl attachments;
    private double originalSpeed;

    // The one thing that JME can't tell us
    private Map<String, String> layerActions = new HashMap<>();

    // Ugh, and this either
    private Map<String, Double> mixValues = new HashMap<>();

    // Keep track of what is already set
    private Map<String, Integer> variationValues = new HashMap<>();

    /**
     *  Creates a CharacterRig that delegates to the specified AnimComposer.
     *  Note that the global speed of the anim composer is set to 0 so that
     *  animations can be properly time-controlled.  Call release() to set
     *  the speed back to its previous value if the rig is no longer needed
     *  and regular animations should resume.
     *  This presumes that the anim composer is being regularly updated separately
     *  from this rig, ie: control.update() is being called as appropriate.
     */
    public AnimComposerRig( AnimComposer anim, AttachmentControl attachments ) {
        this.anim = anim;
        this.attachments = attachments;
        this.originalSpeed = anim.getGlobalSpeed();
        anim.setGlobalSpeed(0);
    }

    public static AnimComposerRig createRig( Spatial s ) {
        // We assume the spatial is loaded with all of the correct animations
        // already.
        // Note: if we ever need more of the rig config info on the client
        // then we'll have to get more creative.  Currently, the typical
        // pattern is that the server will load a RigShape and the client
        // will load a RigShape then load the model separately... then shuffle
        // the anim composer around.  The rig shape on the server doesn't have
        // any real geometry and we just use it for the skeleton.
        // As of today, the only thing we post-config on the AnimComposer
        // are the blend actions... and those can be accessed through the AnimComposer
        // thereafter.  Hopefully in call cases we can treat this like any other
        // spatial on the client and can avoid any real 'rig'.
        AnimComposer anim = findControl(s, AnimComposer.class);
        if( anim == null ) {
            throw new IllegalArgumentException("Spatial has no AnimComposer:" + s);
        }
        return new AnimComposerRig(anim, findControl(s, AttachmentControl.class));
    }

    public static <T extends Control> T findControl( Spatial s, Class<T> type ) {
        return findControl("", s, type);
    }

    public static <T extends Control> T findControl( String indent, Spatial s, Class<T> type ) {
        T result = s.getControl(type);
        if( log.isTraceEnabled() ) {
            log.trace(indent + "Spatial:" + s + "  result:" + result);
        }
        if( result != null ) {
            return result;
        }
        if( s instanceof Node ) {
            for( Spatial child : ((Node)s).getChildren() ) {
                result = findControl(indent + "    ", child, type);
                if( result != null ) {
                    return result;
                }
            }
        }
        return null;
    }

    public AnimComposer getAnimComposer() {
        return anim;
    }

    public void release() {
        anim.setGlobalSpeed((float)originalSpeed);
    }

    @Override
    public void setMix( String blendId, double value ) {
        Action action = anim.getAction(blendId);
        if( action == null ) {
            log.warn("No action for blendId:" + blendId);
            return;
        }
        if( !(action instanceof BlendAction) ) {
            log.warn("Action is not a blend action for blendId:" + blendId + " action:" + action);
            return;
        }
        ((BlendAction)action).getBlendSpace().setValue((float)value);
        mixValues.put(blendId, value);
    }

    @Override
    public double getMix( String blendId ) {
        Double val = mixValues.get(blendId);
        return val == null ? -1 : val;
        //Action action = anim.getAction(blendId);
        //if( action == null ) {
        //    log.warn("No action for blendId:" + blendId);
        //    return -1;
        //}
        //if( !(action instanceof BlendAction) ) {
        //    log.warn("Action is not a blend action for blendId:" + blendId + " action:" + action);
        //    return -1;
        //}
        //return ((BlendAction)action).getBlendSpace().getValue();
        // JME can't tell us.
    }

    @Override
    public void setTime( String layerId, double time ) {
        if( layerId == null ) {
            layerId = AnimComposer.DEFAULT_LAYER;
        }
        AnimLayer layer = anim.getLayer(layerId);
        if( layer.getCurrentAction() != null ) {
            layer.setTime(time);
        } else {
            log.warn("setTime(" + layerId + ", " + time + ") No current action for layer.");
        }
    }

    @Override
    public double getTime( String layerId ) {
        if( layerId == null ) {
            layerId = AnimComposer.DEFAULT_LAYER;
        }
        AnimLayer layer = anim.getLayer(layerId);
        return layer == null ? -1 : layer.getTime();
    }

    @Override
    public void setLayerAction( String layerId, String actionId ) {
        if( layerId == null ) {
            layerId = AnimComposer.DEFAULT_LAYER;
        }
        if( actionId == null ) {
            anim.removeCurrentAction(layerId);
            layerActions.remove(layerId);
        } else {
            if( !anim.hasAction(actionId) && !anim.hasAnimClip(actionId) ) {
                log.error("Rig does not have action:" + actionId + " rig:" + this);
                return;
            }
            Object temp = anim.setCurrentAction(actionId, layerId);
            if( log.isTraceEnabled() ) {
                log.trace("animAction:" + temp);
                AnimLayer layer = anim.getLayer(layerId);
                log.trace("current action:" + layer.getCurrentAction());
            }
            layerActions.put(layerId, actionId);
        }
    }

    @Override
    public String getLayerAction( String layerId ) {
        if( layerId == null ) {
            layerId = AnimComposer.DEFAULT_LAYER;
        }
        return layerActions.get(layerId);
    }

    @Override
    public boolean hasAction( String action ) {
        if( anim.hasAction(action) ) {
            return true;
        }
        return anim.hasAnimClip(action);
    }

    @Override
    public double getLayerDuration( String layerId ) {
        if( layerId == null ) {
            layerId = AnimComposer.DEFAULT_LAYER;
        }
        AnimLayer layer = anim.getLayer(layerId);
        if( log.isTraceEnabled() ) {
            log.trace("getLayerDuration(" + layerId + ") layer:" + layer);
            log.trace("current action:" + layer.getCurrentAction());
        }
        if( layer.getCurrentAction() == null ) {
            return 0;
        }
        return layer.getCurrentAction().getLength();
    }

    @Override
    public AttachmentPoint getAttachmentPoint( String name ) {
        // We implement this in the shape wrapper for JME rigs
        //throw new UnsupportedOperationException();
        // Except it's super useful to be able to get the attachment
        // point as long as we keep them up-to-date
        return attachments == null ? null : attachments.getAttachment(name);
    }

    @Override
    public boolean setVariation( String type, int index ) {
        Integer existing = variationValues.put(type, index);
        if( existing != null && existing == index ) {
            return false;
        }
        if( attachments == null ) {
            log.error("Can't find rig type for:" + this + "  animComposer:" + anim);
            return false;
        }
        VariationHandler handler = attachments.getRigType().getVariationHandler(type);
        if( handler == null ) {
            log.warn("No handler for type:" + type + " spatial:" + getSpatialDebugString()
                    + ", supported:" + attachments.getRigType().getVariationTypes()
                    + ", initalizers:" + attachments.getRigType().getInitializers());
            return false;
        }
        return handler.setVariationType(this, type, index);
    }

    @Override
    public boolean hasVariation( String type ) {
        return attachments.getRigType().getVariationHandler(type) != null;
    }

    protected String getSpatialDebugString() {
        if( anim == null ) {
            return "No anim composer";
        }
        Spatial s = anim.getSpatial();
        if( s == null ) {
            return "No spatial";
        }
        return "{name:" + s.getName() + ", key:" + s.getKey() + ")";
    }

    @Override
    public int getVariation( String type ) {
        Integer existing = variationValues.get(type);
        return existing == null ? -1 : existing;
    }

}

