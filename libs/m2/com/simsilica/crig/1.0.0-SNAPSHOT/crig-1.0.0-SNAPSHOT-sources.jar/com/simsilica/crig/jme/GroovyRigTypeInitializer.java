/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.function.Function;
import javax.script.*;

import org.slf4j.*;

import com.google.common.io.Resources;

/**
 *  Runs the specified groovy script as a rig type initializer using
 *  the standard JSR223 script bindings.
 *
 *  @author    Paul Speed
 */
public class GroovyRigTypeInitializer implements RigTypeInitializer, Serializable {
    static Logger log = LoggerFactory.getLogger(GroovyRigTypeInitializer.class);
    static final long serialVersionUID = 42L;

    private static ScriptEngine engine;
    private static Bindings globalBindings;
    static {
        ScriptEngineManager mgr = new ScriptEngineManager();
        engine = mgr.getEngineByExtension("groovy");
        log.info("Engine:" + engine);
        if( engine == null ) {
            throw new RuntimeException("No groovy script engine found");
        }
        globalBindings = engine.createBindings();
    }
    private static Function<String, String> resourceResolver = (name) -> {
        URL u = Resources.getResource(name);
        try {
            return Resources.toString(u, StandardCharsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading resource:" + u, e);
        }
    };

    private String scriptResource;
    private transient String script;

    public GroovyRigTypeInitializer( String scriptResource ) {
        this.scriptResource = scriptResource;
    }

    public static void setResourceResolver( Function<String, String> resourceResolver ) {
        GroovyRigTypeInitializer.resourceResolver = resourceResolver;
    }

    protected String getScript() {
        if( script == null ) {
            script = resourceResolver.apply(scriptResource);
        }
log.info("script:\n" + script);
        return script;
    }

    @Override
    public void initializeRigType( SpatialRigType rigType ) {
        log.info("initializeRigType(" + scriptResource + ")");
        Bindings bindings = engine.createBindings();
        bindings.putAll(globalBindings);
        String logName = scriptResource;
        if( logName.endsWith(".groovy") ) {
            logName = logName.substring(0, logName.length() - ".groovy".length());
        }
        bindings.put("log", LoggerFactory.getLogger("rigTypeInitializer." + logName));
        bindings.put("rigType", rigType);
        try {
            engine.eval(getScript(), bindings);
        } catch( ScriptException e ) {
            log.error("Error running script:\n" + getScript());
            throw new RuntimeException("Error running script:" + scriptResource, e);
        }
    }
}
