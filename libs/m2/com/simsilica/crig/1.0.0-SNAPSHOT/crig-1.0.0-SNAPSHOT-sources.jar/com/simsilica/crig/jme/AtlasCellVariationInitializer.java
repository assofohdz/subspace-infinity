/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import java.io.Serializable;
import java.util.Objects;

import org.slf4j.*;

import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.shader.VarType;

import com.simsilica.crig.*;

/**
 *  Standardized initializer and variant handler for resetting the
 *  atlas parameters for a model.  This allows having multiple skins
 *  in the same texture selectable by atlas cell parameters.
 *
 *  This presumes that the materials have already been setup to
 *  take a single TextureOffset Vector2 material parameter.
 *
 *  @author    Paul Speed
 */
public class AtlasCellVariationInitializer implements RigTypeInitializer, Serializable {
    static Logger log = LoggerFactory.getLogger(AtlasCellVariationInitializer.class);

    static final long serialVersionUID = 42L;

    private String variantName;
    private String materialName;
    private String materialParameter;
    private int atlasWidth;
    private int atlasHeight;

    private AtlasCellVariationInitializer() {
        // For JSON serialization
    }

    public AtlasCellVariationInitializer( String variantName, String materialName, String materialParameter, int atlasSize ) {
        this(variantName, materialName, materialParameter, atlasSize, atlasSize);
    }

    public AtlasCellVariationInitializer( String variantName, String materialName, String materialParameter, int atlasWidth, int atlasHeight ) {
        this.variantName = variantName;
        this.materialName = materialName;
        this.materialParameter = materialParameter;
        this.atlasWidth = atlasWidth;
        this.atlasHeight = atlasHeight;
    }

    public void initializeRigType( SpatialRigType rigType ) {
        rigType.setVariationHandler(variantName,
                    new Handler(variantName, materialName, materialParameter, atlasWidth, atlasHeight));
    }

    public static class Handler implements VariationHandler, Serializable {
        static final long serialVersionUID = 42L;

        private String variantName;
        private String materialName;
        private String materialParameter;
        private int atlasWidth;
        private int atlasHeight;

        public Handler( String variantName, String materialName, String materialParameter, int atlasWidth, int atlasHeight ) {
            this.variantName = variantName;
            this.materialName = materialName;
            this.materialParameter = materialParameter;
            this.atlasWidth = atlasWidth;
            this.atlasHeight = atlasHeight;
        }

        @Override
        public boolean setVariationType( AnimComposerRig rig, String name, int index ) {

            Spatial spatial = rig.getAnimComposer().getSpatial();

            int row = index / atlasWidth;
            int col = index % atlasWidth;
            Vector2f offset = new Vector2f(col/(float)atlasWidth, row/(float)atlasHeight);

            if( log.isTraceEnabled() ) {
                log.trace("setVariationType(" + name + ", " + index + ") row:" + row + ", col:" + col + ", offset:" + offset);
            }

            if( materialName == null ) {
                // Just set material parameter override because it applies to all of them
                MatParamOverride existing = findOverride(spatial, materialParameter);
                if( existing != null ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("removing:" + existing);
                    }
                    spatial.removeMatParamOverride(existing);
                }
                MatParamOverride mp = new MatParamOverride(VarType.Vector2, materialParameter, offset);
                if( log.isTraceEnabled() ) {
                    log.trace("adding:" + mp);
                }
                spatial.addMatParamOverride(mp);
            } else {
                // Traverse to find materials with the expected name
                spatial.depthFirstTraversal(new SceneGraphVisitorAdapter() {
                    @Override
                    public void visit( Geometry geom ) {
                        if( log.isTraceEnabled() ) {
                            log.trace("visit(" + geom + ")");
                        }
                        Material mat = geom.getMaterial();
                        if( log.isTraceEnabled() ) {
                            log.trace("material:" + mat + "  name:" + mat.getName());
                        }
                        if( !Objects.equals(materialName, mat.getName()) ) {
                            return;
                        }
                        if( log.isTraceEnabled() ) {
                            log.trace("Setting " + materialParameter + " to:" + offset);
                        }
                        mat.setVector2(materialParameter, offset);
                    }
                });
            }

            return true;
        }

        protected MatParamOverride findOverride( Spatial spatial, String name ) {
            for( MatParamOverride mp : spatial.getLocalMatParamOverrides().getArray() ) {
                if( name.equals(mp.getName()) ) {
                    return mp;
                }
            }
            return null;
        }
    }
}
