/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig;

import java.io.Serializable;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  An attachment point on a rig type.
 *
 *  @author    Paul Speed
 */
public class AttachmentInfo implements Serializable {
    static Logger log = LoggerFactory.getLogger(AttachmentInfo.class);

    static final long serialVersionUID = 42L;

    private String name;
    private String joint;
    private Vec3d offset = new Vec3d();
    private Quatd orientation = new Quatd();

    public AttachmentInfo() {
    }

    public AttachmentInfo( String name ) {
        this.name = name;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setJoint( String joint ) {
        this.joint = joint;
    }

    public String getJoint() {
        return joint;
    }

    public void setOffset( Vec3d offset ) {
        this.offset.set(offset);
    }

    public Vec3d getOffset() {
        return offset;
    }

    public void setOrientation( Quatd orientation ) {
        this.orientation.set(orientation);
    }

    public Quatd getOrientation() {
        return orientation;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + getName() + ":" + getJoint() + "]";
    }
}
