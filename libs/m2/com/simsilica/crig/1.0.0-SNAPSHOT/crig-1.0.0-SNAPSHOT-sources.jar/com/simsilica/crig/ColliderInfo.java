/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig;

import java.io.Serializable;

import org.slf4j.*;

import com.simsilica.mblock.CellArray;

/**
 *  A special kind of attachment holding collider shape information.
 *
 *  @author    Paul Speed
 */
public class ColliderInfo extends AttachmentInfo implements Serializable {
    static Logger log = LoggerFactory.getLogger(ColliderInfo.class);

    static final long serialVersionUID = 42L;

    private CellArray shape;
    private double scale = 0.1;

    public ColliderInfo() {
    }

    @Override
    public String getName() {
        String name = super.getName();
        return name == null ? getJoint() : name;
    }

    public void setShape( CellArray shape ) {
        this.shape = shape;
    }

    public CellArray getShape() {
        return shape;
    }

    public void setScale( double scale ) {
        this.scale = scale;
    }

    public double getScale() {
        return scale;
    }

    public String toString() {
        return getClass().getSimpleName() + "[" + getJoint() + ":" + getShape() + "]";
    }
}
