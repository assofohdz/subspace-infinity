/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.es;

import java.util.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class LayerConfig {
    static Logger log = LoggerFactory.getLogger(LayerConfig.class);
    private String layer;
    private String[] actions;

    protected LayerConfig() {
    }

    public LayerConfig( String layer, String... actions ) {
        this.layer = layer;
        this.actions = actions;
    }

    public String getLayer() {
        return layer;
    }

    public String[] getActions() {
        return actions;
    }

    public int indexOf( String action ) {
        int i = 0;
        for( String s : actions ) {
            if( Objects.equals(s, action) ) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public double getPart( String action ) {
        double size = actions.length;
        if( size <= 1 ) {
            return 0;
        }
        int i = 0;
        for( String s : actions ) {
            if( Objects.equals(s, action) ) {
//log.info("getPart(" + action + ") = " + (i/size));
                return i/size;
            }
            i++;
        }
        return -1;
    }

    public String getAction( double part ) {
        if( part < 0 ) {
            return null;
        }
        // Add a tiny amount to the part value because transfer errors
        // will sometimes make it too small for truncation.  0.1 should
        // be fine to add as long as we don't have more than 8 or 9 actions.
        int i = (int)((part + 0.1) * actions.length);
//log.info("getAction(" + part + ") = " + actions[i] + "(" + i + ")");

        // 2022-12-10 - Looking at this today, I'm wondering if we should
        // have just added half a 1/size of slop to 'part' in the first
        // place.  If the 'transfer errors' are large enough to move that
        // value to the wrong index then we did not have enough precision
        // to store it in the first place.
        // I'm not going to fix it today because I think the right fix
        // would incorporate writing some unit tests that simulate the
        // appropriate precision loss and getAction(getPart("foo")).
        // FIXME - add (1/size * 0.5) to part values.

        return actions[i];
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[layer:" + layer + ", actions:" + Arrays.asList(actions) + "]";
    }
}


