/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mblock.phys.Group;

import com.simsilica.crig.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class AnimComposerShape extends RigShape {
    static Logger log = LoggerFactory.getLogger(AnimComposerShape.class);

    private RigType rigType;
    private CharacterRig delegate;
    private Runnable update;
    private ColliderShape[] shapes;
    private AttachmentPointImpl[] attachments;
    private Map<String, AttachmentPointImpl> attachmentIndex = new HashMap<>();

    public AnimComposerShape( RigType rigType, Group root, CharacterRig delegate, Runnable update,
                              ColliderShape[] shapes, AttachmentPointImpl[] attachments ) {
        super(root);
        this.rigType = rigType;
        this.delegate = delegate;
        this.update = update;
        this.shapes = shapes;
        this.attachments = attachments;
        for( AttachmentPointImpl att : attachments ) {
            attachmentIndex.put(att.getInfo().getName(), att);
        }
    }

    @Override
    public RigType getRigType() {
        return rigType;
    }

    public CharacterRig getDelegate() {
        return delegate;
    }

    @Override
    public void update() {
        update.run();
        for( ColliderShape shape : shapes ) {
            shape.update();
        }
        // Caller needs to update the attachments if it's actually
        // using them.
        //for( AttachmentPointImpl att : attachments ) {
        //    att.update();
        //}
    }

    @Override
    public void setMix( String blendId, double value ) {
        delegate.setMix(blendId, value);
        fireMixChanged(blendId, value);
    }

    @Override
    public double getMix( String blendId ) {
        return delegate.getMix(blendId);
    }

    @Override
    public void setTime( String layerId, double time ) {
        delegate.setTime(layerId, time);
    }

    @Override
    public double getTime( String layer ) {
        return delegate.getTime(layer);
    }

    @Override
    public void setLayerAction( String layerId, String actionId ) {
        delegate.setLayerAction(layerId, actionId);
        fireLayerActionChanged(layerId, actionId);
    }

    @Override
    public String getLayerAction( String layer ) {
        return delegate.getLayerAction(layer);
    }

    @Override
    public boolean hasAction( String action ) {
        return delegate.hasAction(action);
    }

    @Override
    public double getLayerDuration( String layerId ) {
        return delegate.getLayerDuration(layerId);
    }

    @Override
    public AttachmentPoint getAttachmentPoint( String name ) {
        return attachmentIndex.get(name);
    }

    @Override
    public boolean setVariation( String type, int index ) {
        return delegate.setVariation(type, index);
    }

    @Override
    public int getVariation( String type ) {
        return delegate.getVariation(type);
    }

    @Override
    public boolean hasVariation( String type ) {
        return delegate.hasVariation(type);
    }
}

