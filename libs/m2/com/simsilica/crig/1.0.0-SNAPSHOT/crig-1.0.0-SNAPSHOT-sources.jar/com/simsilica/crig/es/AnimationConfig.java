/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.es;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.es.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class AnimationConfig implements EntityComponent {
    static Logger log = LoggerFactory.getLogger(AnimationConfig.class);

    private EntityId target;
    private LayerConfig[] layers;
    private MixConfig[] mixes;

    protected AnimationConfig() {
    }

    public AnimationConfig( EntityId target, Object... config ) {
        this.target = target;

        int layerCount = 0;
        int mixCount = 0;
        for( Object o : config ) {
            if( o instanceof LayerConfig ) {
                layerCount++;
            } else if( o instanceof MixConfig ) {
                mixCount++;
            }
        }
        this.layers = new LayerConfig[layerCount];
        this.mixes = new MixConfig[mixCount];

        layerCount = 0;
        mixCount = 0;
        for( Object o : config ) {
            if( o instanceof LayerConfig ) {
                layers[layerCount++] = (LayerConfig)o;
            } else if( o instanceof MixConfig ) {
                mixes[mixCount++] = (MixConfig)o;
            }
        }
    }

    public EntityId getTarget() {
        return target;
    }

    public LayerConfig[] getLayers() {
        return layers;
    }

    public MixConfig[] getMixes() {
        return mixes;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("target", target)
            .add("layers", Arrays.asList(layers))
            .add("mixes", Arrays.asList(mixes))
            .toString();
    }
}

/*
LayerConfig {
    String layer;
    String[] actions;  // rounded from a quat element
}

MixConfig {
    String blend;
}

AnimationConfig {
    LayerConfig[] layers;
    MixConfig[] mixes;
}
*/
