/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig;

import java.io.*;
import java.util.zip.*;

import org.slf4j.*;

/**
 *  Utilities for saving/loading rig type data.
 *
 *  @author    Paul Speed
 */
public class RigProtocol {
    static Logger log = LoggerFactory.getLogger(RigProtocol.class);

    private static long version = 42;

    public static void saveRigType( RigType rigType, File file ) throws IOException {
        FileOutputStream fOut = new FileOutputStream(file);
        GZIPOutputStream gzip = new GZIPOutputStream(fOut);
        try( ObjectOutputStream out = new ObjectOutputStream(gzip) ) {
            out.writeLong(version);
            out.writeObject(rigType);
        }
    }

    public static RigType loadRigType( File file ) throws IOException {
        FileInputStream fIn = new FileInputStream(file);        
        return loadRigType(fIn);
    }

    public static RigType loadRigType( String resource ) throws IOException {
        InputStream in = RigProtocol.class.getResourceAsStream(resource);
        if( in == null ) {
            throw new IOException("Resource not found:" + resource);
        }             
        return loadRigType(in);
    }

    public static RigType loadRigType( InputStream rawIn ) throws IOException {
        GZIPInputStream gzip = new GZIPInputStream(rawIn);
        try( ObjectInputStream in = new ObjectInputStream(gzip) ) {
            long version = in.readLong();
            return (RigType)in.readObject();
        } catch( ClassNotFoundException e ) {
            throw new RuntimeException("Missing class reading rig binary", e);
        }
    }
}

