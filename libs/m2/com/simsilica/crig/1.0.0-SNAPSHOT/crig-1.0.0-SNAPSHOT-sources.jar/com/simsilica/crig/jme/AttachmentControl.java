/*
 * $Id$
 *
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig.jme;

import org.slf4j.*;

import java.util.*;

import com.jme3.anim.*;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.*;
import com.jme3.scene.control.*;
import com.jme3.util.clone.Cloner;

import com.simsilica.crig.*;

/**
 *  Makes AttachmentPoints available on the spatials that were configured
 *  for a particular rig type.  This lets even an AnimComposerRig return
 *  attachment points that the client can use.
 *
 *  @author    Paul Speed
 */
public class AttachmentControl extends AbstractControl {
    static Logger log = LoggerFactory.getLogger(AttachmentControl.class);

    private SpatialRigType rigType;
    private SkinningControl skin;

    // Keep track of the requested AttachmentPoints so that we
    // only update what we have to
    private Map<String, AttachmentPointImpl> attachmentIndex = new HashMap<>();

    public AttachmentControl( SpatialRigType rigType ) {
        this.rigType = rigType;
    }

    protected SpatialRigType getRigType() {
        return rigType;
    }

    public AttachmentPoint getAttachment( String name ) {
        if( skin == null ) {
            // Maybe should be a warning if we think if skin as optional
            throw new UnsupportedOperationException("This spatial has no skin and cannot calculate attachments.");
        }
        AttachmentPointImpl result = attachmentIndex.get(name);
        if( result != null ) {
            return result;
        }

        // Else we'll create one
        AttachmentInfo info = rigType.findAttachmentInfo(name);
        if( info == null ) {
            throw new IllegalArgumentException("No attachment info found for:" + name);
        }

        if( log.isTraceEnabled() ) {
            log.trace("Configuring attachment for:" + info);
        }
        if( skin.getArmature().getJoint(info.getJoint()) == null ) {
            log.warn("No joint found for:" + info.getJoint() + " attachment:" + info + " rigType:" + rigType);
            // Create an empty attachment point that's just a direct
            // child of this spatial
            result = new AttachmentPointImpl(info, getSpatial());
        } else {
            // Get the joint
            Node node = skin.getAttachmentsNode(info.getJoint());
            result = new AttachmentPointImpl(info, node);
        }
        attachmentIndex.put(name, result);
        return result;
    }

    public void setSpatial( Spatial spatial ) {
        super.setSpatial(spatial);
        this.skin = AnimComposerRig.findControl(spatial, SkinningControl.class);
    }

    @Override
    protected void controlUpdate( float tpf ) {
    }

    @Override
    public void cloneFields( Cloner cloner, Object original ) {
        super.cloneFields(cloner, original);

        this.attachmentIndex = new HashMap<>();

        // We'll be good citizens and clone the skin so we are fully compatible
        // with cloning
        this.skin = cloner.clone(skin);

        // Note: it's ok to share rig type as that's a shared configuration
    }

    @Override
    protected void controlRender( RenderManager rm, ViewPort vp ) {
    }
}
