/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.crig;

import org.slf4j.*;

import com.simsilica.mphys.DynArray;
import com.simsilica.mblock.phys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public abstract class RigShape extends MBlockShape implements CharacterRig {
    static Logger log = LoggerFactory.getLogger(RigShape.class);

    private DynArray<RigListener> listeners = new DynArray<>(RigListener.class);

    protected RigShape( Part part ) {
        super(part);
    }

    public void addRigListener( RigListener l ) {
        listeners.add(l);
    }

    public void removeRigListener( RigListener l ) {
        listeners.remove(l);
    }

    public abstract RigType getRigType();

    public abstract void update();

    protected void fireMixChanged( String blendId, double value ) {
        for( RigListener l : listeners.getArray() ) {
            l.mixChanged(blendId, value);
        }
    }

    protected void fireLayerActionChanged( String layer, String action ) {
        for( RigListener l : listeners.getArray() ) {
            l.layerActionChanged(layer, action);
        }
    }
}

