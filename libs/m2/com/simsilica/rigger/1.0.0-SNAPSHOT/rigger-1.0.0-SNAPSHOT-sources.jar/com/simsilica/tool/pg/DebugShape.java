/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import org.slf4j.*;

import com.jme3.math.ColorRGBA;

import com.google.common.base.*;

import com.simsilica.es.*;
import com.simsilica.mathd.*;

/**
 *  A debug shape that can be set to an entity.
 *
 *  @author    Paul Speed
 */
public class DebugShape implements EntityComponent {
    static Logger log = LoggerFactory.getLogger(DebugShape.class);

    public enum Type { Arrow, Sphere, Box };

    private String layer;
    private Type type;
    private Vec3d size;
    private ColorRGBA color;
    private boolean lit;
    private boolean wireframe;

    public DebugShape( String layer, Type type, Vec3d size, ColorRGBA color, boolean lit ) {
        this(layer, type, size, color, lit, false);
    }

    public DebugShape( String layer, Type type, Vec3d size, ColorRGBA color, boolean lit, boolean wireframe ) {
        this.layer = layer;
        this.type = type;
        this.size = size;
        this.color = color;
        this.lit = lit;
        this.wireframe = wireframe;
    }

    public static DebugShape createArrow( String layer, Vec3d tip, ColorRGBA color ) {
        return new DebugShape(layer, Type.Arrow, tip, color, false);
    }

    public static DebugShape createBox( String layer, Vec3d extents, ColorRGBA color, boolean lit ) {
        return new DebugShape(layer, Type.Box, extents, color, lit);
    }

    public static DebugShape createSphere( String layer, double radius, ColorRGBA color, boolean lit ) {
        return new DebugShape(layer, Type.Sphere, new Vec3d(radius, 0, 0), color, lit);
    }

    public static DebugShape createBox( String layer, Vec3d extents, ColorRGBA color, boolean lit, boolean wireframe ) {
        return new DebugShape(layer, Type.Box, extents, color, lit, wireframe);
    }

    public static DebugShape createSphere( String layer, double radius, ColorRGBA color, boolean lit, boolean wireframe ) {
        return new DebugShape(layer, Type.Sphere, new Vec3d(radius, 0, 0), color, lit, wireframe);
    }

    public String getLayer() {
        return layer;
    }

    public Type getType() {
        return type;
    }

    public Vec3d getSize() {
        return size;
    }

    public ColorRGBA getColor() {
        return color;
    }

    public boolean isLit() {
        return lit;
    }

    public boolean isWireframe() {
        return wireframe;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("layer", layer)
            .add("type", type)
            .add("size", size)
            .add("color", color)
            .add("lit", lit)
            .add("wireframe", wireframe)
            .toString();
    }
}
