/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

/**
 *  Keeps track of a certain backlog of edit history
 *  allowing undo/redo.
 *
 *  @author    Paul Speed
 */
public class EditHistory {
    static Logger log = LoggerFactory.getLogger(EditHistory.class);
 
    // The top entry will always be empty waiting for the next
    // edit unless we are moving forward/back through undo/redo
    // Whatever the case, the next new edit will set the edit field
    // of top, set top.next to null, and create a new top.
    private Entry top = new Entry(null);
    private Entry bottom = top;
    private int size;
    private int maxSize;
 
    public EditHistory( int maxSize ) {
        this.maxSize = maxSize;
    }
 
    public Edit getLastEdit() {
        return top.previous == null ? null : top.previous.edit;
    }
    
    public void clear() {
        top = new Entry(null);
        bottom = top;
        size = 0;
    }
 
    public void addEdit( Edit edit ) {
        log.info("Playing edit:" + edit);
        
        // Play it
        edit.doEdit();
 
        if( top.edit != null ) {
            log.info("Replacing edit:" + top.edit);
        }
 
        // Add it to the top of the stack   
        Entry oldNext = top.next;
        top.edit = edit;
        top.next = new Entry(top);
        size++;
        
        // Advance the top
        top = top.next;
        
        // We we chopped off playback then adjust the size accordingly
        decrementSize(oldNext);
        int test = calculateSize();
        if( test != size ) {
            log.warn("Stack size got out of sync somewhere");
            size = test;
        }
        while( size > maxSize ) {
            if( bottom.next == null ) {
                log.warn("Bottom of stack reached before running out of size");
                break;
            }
            // Need to trim off the bottom
            bottom = bottom.next;
            bottom.previous = null;
            log.info("Trimming old edit:" + bottom.edit);
            size--;
        } 
    }
    
    public int size() {
        return size;
    }

    public boolean canUndo() {
        return top.previous != null;
    }
 
    public boolean undo() {
        if( top.previous == null ) {
            return false;
        }
        top = top.previous;
        log.info("Undo:" + top.edit);
        top.edit.undoEdit();
        return true;
    }
    
    public boolean canRedo() {
        return top.edit != null;
    }

    public boolean redo() {
        if( top.edit == null ) {
            return false;
        }
        log.info("Redo:" + top.edit);
        top.edit.doEdit();
        if( top.next == null ) {
            log.warn("Fell off end of redo stack somehow");
            top.next = new Entry(top);
            size++;
        }
        top = top.next;
        return true;
    }
    
    protected int calculateSize() {
        int count = 0;
        for( Entry e = bottom; e != null; e = e.next ) {
            if( e.edit != null ) {
                count++;
            }
        }
        return count;
    }
    
    protected void decrementSize( Entry entry ) {
        // If we were passed top then we still decrement
        // by at least one because that means we replaced
        // an edit... and will be adding one again immediately.
        while( entry != null ) {
            size--;
            if( entry.edit != null ) {
                log.info("Dropping old fork edit:" + entry.edit);
            }
            entry = entry.next;
        }
    }
    
    public List<Edit> getHistory( int count ) {
        List<Edit> results = new ArrayList<>();
        Entry entry = top;
        for( int i = 0; i < count; i++ ) {
            if( entry.previous == null ) {
                break;
            }
            entry = entry.previous;
            results.add(entry.edit);
        }
        return results;
    }
    
    public List<Edit> getPlayback( int count ) {
        List<Edit> results = new ArrayList<>();
        Entry entry = top;
        for( int i = 0; i < count; i++ ) {
            if( entry.edit == null ) {
                break;
            }
            results.add(entry.edit);
            if( entry.next == null ) {
                // In general, there should always be one empty entry on top
                log.warn("Edit stack consistency error getting playback buffer"); 
            } else {
                entry = entry.next;
            }
        }
        return results;
    }
    
    private class Entry {
        Entry previous;
        Entry next;
        Edit edit;
        
        public Entry( Entry previous ) {
            this.previous = previous;
        }
    }    
}
