/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.bounding.BoundingBox;
import com.jme3.math.*;
import com.jme3.scene.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ModelInfoState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ModelInfoState.class);

    private Node viewRoot = new Node("modelInfoViewRoot");
    private VersionedReference<TabbedPanel.Tab> tabRef;
    private VersionedReference<Rig> rigRef;
    private VersionedReference<SourceModelInfo> modelRef;
    private VersionedReference<TargetModelInfo> targetModelRef;
    private Rig rig;
    private RigInfo rigInfo;

    private Container window;
    private Label sourceModelLabel;
    private Label sourceRootLabel;
    private Label sizeLabel;
    private ListBox<String> scriptList;

    private Label targetModelLabel;
    private Label targetRootLabel;
    private ListBox<String> targetScriptList;

    private ProbeEditor probeEditor;
    private ProbeView probeView;
    private VersionedReference<ProbeInfo> probeRef;

    public ModelInfoState() {
    }

    @Override
    protected void initialize( Application app ) {
        this.tabRef = getState(ToolState.class).getTabs().getSelectionModel().createReference();

        rigRef = getState(RigViewState.class, true).createRigReference();

        window = new Container();
        getState(ToolState.class).getTabs().addTab("Model", window);

        window.addChild(new Label("Source"));
        Container props = window.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        props.addChild(new Label("Model:"));
        sourceModelLabel = props.addChild(new Label(""), 1);

        props.addChild(new Label("Root:"));
        sourceRootLabel = props.addChild(new Label(""), 1);

        props.addChild(new Label("Size:"));
        sizeLabel = props.addChild(new Label(""), 1);

        scriptList = window.addChild(new ListBox<>(new VersionedList<String>()));

        window.addChild(new Label("Target"));
        props = window.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        props.addChild(new Label("Model:"));
        targetModelLabel = props.addChild(new Label(""), 1);

        props.addChild(new Label("Root:"));
        targetRootLabel = props.addChild(new Label(""), 1);

        targetScriptList = window.addChild(new ListBox<>(new VersionedList<String>()));

        window.addChild(new Label("Physics Probe"));

        this.probeEditor = window.addChild(new ProbeEditor());
        this.probeView = new ProbeView();

        resetRig(rigRef.get());
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
    }

    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    @Override
    public void update( float tpf ) {
        if( rigRef != null && rigRef.update() ) {
            resetRig(rigRef.get());
        }
        if( modelRef != null && modelRef.update() ) {
            updateSourceFields();
        }
        if( targetModelRef != null && targetModelRef.update() ) {
            updateTargetFields();
        }
        if( tabRef.update() ) {
            setProbeEnabled(isOurTabVisible());
        }
    }

    protected boolean isOurTabVisible() {
        return tabRef.get() != null && tabRef.get().getContents() == window;
    }

    protected void setProbeEnabled( boolean enabled ) {
        if( enabled ) {
            if( viewRoot.getParent() == null ) {
                getRoot().attachChild(viewRoot);
            }
            resetProbePosition();
        } else {
            viewRoot.removeFromParent();
        }
    }

    protected void resetRig( Rig rig ) {
        if( rig == null ) {
            modelRef = null;
            targetModelRef = null;
            return;
        }
        this.rig = rig;
        this.rigInfo = rig.getRigInfo();
        this.modelRef = rigInfo.getSourceModel().createReference();
        this.targetModelRef = rigInfo.getTargetModel().createReference();
        this.probeRef = rigInfo.getProbe().createReference();
        updateSourceFields();
        updateTargetFields();
        updateProbeFields();
    }

    protected void updateProbeFields() {
        log.info("updateProbeEditor()");
        if( rigInfo == null ) {
            probeEditor.setProbe(null);
            probeView.setProbe(null);
            probeView.removeFromParent();
        } else {
            probeEditor.setProbe(rigInfo.getProbe());
            probeView.setProbe(rigInfo.getProbe());
            viewRoot.attachChild(probeView);
            resetProbePosition();
        }
    }

    protected void updateSourceFields() {
        if( modelRef == null ) {
            sourceModelLabel.setText("");
            sourceRootLabel.setText("");
            sizeLabel.setText("");
            scriptList.getModel().clear();
        } else {
            SourceModelInfo model = modelRef.get();
            sourceModelLabel.setText(model.getModel());
            sourceRootLabel.setText(model.getSourceRoot());

            BoundingBox bb = rig.getBoundingBox();
            Vector3f size = bb.getMax(null).subtract(bb.getMin(null));
            sizeLabel.setText(String.format("x:%.02f y:%.02f z:%.02f", size.x, size.y, size.z));

            scriptList.getModel().clear();
            scriptList.getModel().addAll(model.getScripts());
        }
    }

    protected void updateTargetFields() {
        if( targetModelRef == null ) {
            targetModelLabel.setText("");
            targetRootLabel.setText("");
            targetScriptList.getModel().clear();
        } else {
            TargetModelInfo target = rigInfo.getTargetModel();
            targetModelLabel.setText(target.getModel());
            targetRootLabel.setText(target.getTargetRoot());

            targetScriptList.getModel().clear();
            targetScriptList.getModel().addAll(target.getScripts());
        }
    }

    protected void resetProbePosition() {
        if( rig ==  null ) {
            return;
        }
        SkinningControl skin = rig.getSkinningControl();
        double min = Double.POSITIVE_INFINITY;
        for( ColliderInfo ci : rigInfo.getColliders() ) {
            log.info("Checking:" + ci);
            Node bone = skin.getAttachmentsNode(ci.getJoint());
            log.info("  local:" + bone.getLocalTranslation() + " world:" + bone.getWorldTranslation());
            if( "sphere".equals(ci.getShape()) ) {
                // Easy to handle
                double bottom = bone.getWorldTranslation().y - ci.getScale();
                min = Math.min(bottom, min);
            }
        }
        log.info("Min:" + min);
        probeView.setLocalTranslation(0, (float)-min, 0);
    }
}
