/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.io.*;
import com.google.gson.*;

import com.jme3.anim.*;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.control.Control;

import com.jme3.export.binary.BinaryExporter;


import com.simsilica.jmec.*;
import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;

import com.simsilica.crig.RigProtocol;
import com.simsilica.crig.RigShape;
import com.simsilica.crig.RigType;
import com.simsilica.crig.jme.GroovyRigTypeInitializer;

/**
 *
 *
 *  @author    Paul Speed
 */
public class RigViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(RigViewState.class);

    private Node viewRoot = new Node("viewRoot");

    private VersionedHolder<RigInfo> rigInfo = new VersionedHolder<>();
    private VersionedHolder<Rig> rig = new VersionedHolder<>();

    private VersionedReference<AttachmentInfo> selectedAttachmentRef;
    private VersionedReference<AttachmentInfo> attRef;

    private Node selectionAxes;

    public RigViewState() {
        // Hard coded for a sec
        //RigInfo rig = new RigInfo();
        //rig.setModel("models/puppet/scene.gltf");
        //rig.setSourceModel(new SourceModelInfo("models/puppet/scene.gltf", "models/puppet"));
        //rig.setSourceModel(new SourceModelInfo("models/puppet2/puppet-edited.gltf", "models/puppet2"));
        //rig.setModel("models/dog1/scene.gltf.j3o");
        //rig.setSourceModel(new SourceModelInfo("models/female/Models/human-female/human-female-low4.gltf.j3o",
        //                                       "models/female/"));
        //rig.setSourceModel(new SourceModelInfo("models/me/me-rigged.gltf",
        //rig.setSourceModel(new SourceModelInfo("models/me/me-animated.gltf",
        //rig.setSourceModel(new SourceModelInfo("models/me/me-animated-mapped4.gltf",
        //                                       "models/me/"));
        //rig.upgrade();
        //rigInfo.setObject(rig);
        GroovyRigTypeInitializer.setResourceResolver((name) -> {
            File file = new File("./src/main/resources", name);
            try {
                return Files.toString(file, Charsets.UTF_8);
            } catch( IOException e ) {
                throw new RuntimeException("Error loading:" + file, e);
            }
        });

    }

    public void setRigInfo( RigInfo info ) {
        rigInfo.setObject(info);
        loadModel();
        selectionAxes.removeFromParent();
    }

    public RigInfo getRigInfo() {
        return rigInfo.getObject();
    }

    public Rig getRig() {
        return rig.getObject();
    }

    public VersionedReference<Rig> createRigReference() {
        return rig.createReference();
    }

    public VersionedReference<RigInfo> createRigInfoReference() {
        return rigInfo.createReference();
    }

    public Spatial getModel() {
        return rig.getObject().getView();
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected void compileBinary() {
        log.info("compileBinary()");
        saveRigType();
        saveModel();
    }

    protected void saveRigType() {
        RigInfo ri = getRigInfo();
        String f = ri.getTargetModel().getModel();
        if( !f.toLowerCase().endsWith(".rt") ) {
            f = f + ".rt";
        }
        if( ri.getTargetModel().getTargetRoot() != null ) {
            f = ri.getTargetModel().getTargetRoot() + "/" + f;
        }
        File file = new File(RiggerConfig.getInstance().getRigBinaryDir(), f);
        if( !file.getParentFile().exists() ) {
            file.getParentFile().mkdirs();
        }
        copyRigTypeInitScripts(ri);

        log.info("Write to:" + file);
        RigType rigType = getRig().getRigType();

        try {
            RigProtocol.saveRigType(rigType, file);
            log.info("Saved:" + file);
        } catch( Exception e ) {
            log.error("Error writing binary:" + file, e);
            getState(OptionPanelState.class).showError("Error writing:" + file, e);
        }

        try {
            RigType test = RigProtocol.loadRigType(file);

            // See if it can create a shape
            RigShape shape = test.createShape(null, 1, null); //new ShapeInfo(), new Mass(1));

            log.info("Created test shape:" + shape);

        } catch( Exception e ) {
            log.error("Error reading back binary:" + file, e);
            getState(OptionPanelState.class).showError("Error in readback for:" + file, e);
        }
    }

    protected void saveModel() {

        RigInfo ri = getRigInfo();

        // We'll use JMEC to write things out once setup.
        // We don't need to load it so we won't call convert(), we'll
        // just run the processors.
        Convert jmec = new Convert();
        File sourceRoot = RiggerConfig.getInstance().getFile(ri.getSourceModel().getSourceRoot());
        jmec.setSourceRoot(sourceRoot);

        jmec.setTargetRoot(RiggerConfig.getInstance().getModelBinaryDir());
        jmec.setTargetAssetPath(ri.getTargetModel().getTargetRoot());

        for( String s : ri.getSourceModel().getScripts() ) {
            try {
                File scriptFile = RiggerConfig.getInstance().getFile(s);
                ModelScript script = new ModelScript(jmec, s, Files.toString(scriptFile, Charsets.UTF_8));
                jmec.addModelScript(script);
            } catch( Exception e ) {
                log.error("Error loading script:" + s, e);
            }
        }

        String targetName = ri.getTargetModel().getModel();
        if( targetName != null ) {
            jmec.addModelScript(new ModelScript(jmec, "rename.groovy", "model.modelName = '" + targetName + "';"));
        }

        for( String s : ri.getTargetModel().getScripts() ) {
            try {
                File scriptFile = RiggerConfig.getInstance().getFile(s);
                ModelScript script = new ModelScript(jmec, s, Files.toString(scriptFile, Charsets.UTF_8));
                jmec.addModelScript(script);
            } catch( Exception e ) {
                log.error("Error loading script:" + s, e);
            }
        }

        File modelFile = RiggerConfig.getInstance().getFile(ri.getSourceModel().getModel());
        ModelInfo modelInfo = null;
        try {
            modelInfo = jmec.convert(modelFile);
        } catch( IOException e ) {
            log.error("Error saving j3o", e);
            getState(OptionPanelState.class).showError("Error saving j3o", e);
        }

        for( String s : ri.getTargetModel().getCleanupScripts() ) {
            try {
                log.info("Running cleanup script:" + s);
                File scriptFile = RiggerConfig.getInstance().getFile(s);
                ModelScript script = new ModelScript(jmec, s, Files.toString(scriptFile, Charsets.UTF_8));
                script.apply(modelInfo);
            } catch( Exception e ) {
                log.error("Error running cleanup script:" + s, e);
            }
        }

        copyRigTypeInitScripts(ri);

        //String root = getRigInfo().getTargetModel().getTargetRoot();
        //String f = getRigInfo().getTargetModel().getModel();
        //if( root != null ) {
        //    f = root + "/" + f;
        //}
        //File file = new File(RiggerConfig.getInstance().getBinaryDir(), f);
        //if( !file.getParentFile().exists() ) {
        //    file.getParentFile().mkdirs();
        //}
        //try {
        //    com.jme3.scene.Spatial model = getRig().getOriginalModel();
        //    BinaryExporter.getInstance().save(model, file);
        //    log.info("Saved:" + file);
        //} catch( IOException e ) {
        //    log.error("Error saving j3o:" + file, e);
        //    getState(OptionPanelState.class).showError("Error saving j3o:" + file, e);
        //}
    }

    protected void copyRigTypeInitScripts( RigInfo ri ) {

        // Copy any scripts
        File scriptTargetDir = RiggerConfig.getInstance().getFile(ri.getSourceModel().getSourceRoot());
        for( RigTypeInitializerInfo initInfo : ri.getInitializers() ) {
            if( !(initInfo instanceof GroovyRigTypeInitializerInfo) ) {
                continue;
            }
            GroovyRigTypeInitializerInfo info = (GroovyRigTypeInitializerInfo)initInfo;
            File srcDir = RiggerConfig.getInstance().getFile(info.getSourcePath());
            File scriptFile = new File(srcDir, info.getScriptName());
            File targetDir = new File(RiggerConfig.getInstance().getModelBinaryDir(), info.getTargetPath());
            File targetFile = new File(targetDir, info.getScriptName());
            try {
                log.info("copying:" + scriptFile + " to:" + targetFile);
                Files.copy(scriptFile, targetFile);
            } catch( Exception e ) {
                log.error("Error copying script:" + scriptFile + " to:" + targetFile, e);
            }
        }
    }

    protected void loadModel() {

        Convert jmec = new Convert();
        RigInfo ri = rigInfo.getObject();
        File f = RiggerConfig.getInstance().getFile(ri.getSourceModel().getModel());
        //File sourceRoot = f.getParentFile();
        File sourceRoot = RiggerConfig.getInstance().getFile(ri.getSourceModel().getSourceRoot());
        jmec.setSourceRoot(sourceRoot);

        Spatial spatial = jmec.getAssetReader().loadModel(f);
log.info("loaded model:" + spatial);
        ModelInfo info = new ModelInfo(sourceRoot, f.getName(), spatial);

        for( String s : ri.getSourceModel().getScripts() ) {
            try {
                File scriptFile = RiggerConfig.getInstance().getFile(s);
                ModelScript script = new ModelScript(jmec, s, Files.toString(scriptFile, Charsets.UTF_8));
                jmec.addModelScript(script);
            } catch( Exception e ) {
                log.error("Error loading script:" + s, e);
            }
        }
        jmec.runProcessors(info);

        Probe probe = new Probe();
        probe.setShowControls(true);
        probe.setShowAllMaterialParameters(true);
        probe.apply(info);

        rig.setObject(new Rig(rigInfo.getObject(), spatial));
        selectedAttachmentRef = rig.getObject().createSelectedAttachmentReference();
        updateSelection(selectedAttachmentRef.get());

        LayerComparator.setLayer(spatial, 2);

        viewRoot.detachAllChildren();
        viewRoot.attachChild(spatial);

        //AnimComposer anim = findAnim(s);
        //
        //if( anim != null ) {
        //    log.info("anim clip names:" + anim.getAnimClipsNames());
        //    if( anim.getAnimClipsNames().contains("Idle") ) {
        //        anim.setCurrentAction("Idle");
        //    }
        //}
        //
        //AnimComposerDebug.writeJson(anim, new File("anim.json"));
        //
        //SkinningControl skin = findControl(s, SkinningControl.class);
        //AnimComposerDebug.writeJson(skin, new File("skin.json"));
    }

    //protected AnimComposer findAnim( Spatial s ) {
    //    AnimComposer result = s.getControl(AnimComposer.class);
    //    if( result != null ) {
    //        return result;
    //    }
    //    if( s instanceof Node ) {
    //        for( Spatial child : ((Node)s).getChildren() ) {
    //            result = findAnim(child);
    //            if( result != null ) {
    //                return result;
    //            }
    //        }
    //    }
    //    return null;
    //}

    //public static <T extends Control> T findControl( Spatial s, Class<T> type ) {
    //    T result = s.getControl(type);
    //    if( result != null ) {
    //        return result;
    //    }
    //    if( s instanceof Node ) {
    //        for( Spatial child : ((Node)s).getChildren() ) {
    //            result = findControl(child, type);
    //            if( result != null ) {
    //                return result;
    //            }
    //        }
    //    }
    //    return null;
    //}

    @Override
    protected void initialize( Application app ) {
        selectionAxes = new Node("selected");
        ColorRGBA[] colors = new ColorRGBA[] { ColorRGBA.Red, ColorRGBA.Green, ColorRGBA.Blue };
        float size = 0.25f;
        Geometry opaque = GeomUtils.createAxis(size, colors[0], colors[1], colors[2]);
        selectionAxes.attachChild(opaque);

        for( int i = 0; i < colors.length; i++ ) {
            colors[i] = colors[i].clone();
            colors[i].a = 0.3f;
        }
        Geometry alpha = GeomUtils.createAxis(size, colors[0], colors[1], colors[2]);
        alpha.setQueueBucket(Bucket.Translucent);
        alpha.getMaterial().getAdditionalRenderState().setDepthTest(false);
        alpha.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        selectionAxes.attachChild(alpha);


        getRoot().attachChild(selectionAxes);

        //loadModel();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
    }

    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( selectedAttachmentRef != null && selectedAttachmentRef.update() ) {
            updateSelection(selectedAttachmentRef.get());
        }
        if( attRef != null && attRef.update() ) {
            updateJointSelection();
        }
    }

    protected void updateSelection( AttachmentInfo attachment ) {
        log.info("updateSelection(" + attachment + ")");
        if( attachment == null ) {
            attRef = null;
            return;
        }
        attRef = attachment.createReference();
        updateJointSelection();
    }

    protected void updateJointSelection() {
        if( attRef == null ) {
            selectionAxes.removeFromParent();
            return;
        }
log.info("rig:" + rig.getObject());
        Node node = rig.getObject().getAttachmentNode(attRef.get().getJoint());
log.info("att node:" + node);
        if( node == null ) {
            selectionAxes.removeFromParent();
            return;
        }
        Vector3f rescale = node.getWorldScale().clone();
        rescale.x = 1/rescale.x;
        rescale.y = 1/rescale.y;
        rescale.z = 1/rescale.z;
log.info("rescale:" + rescale);
        selectionAxes.setLocalScale(rescale);
        node.attachChild(selectionAxes);
        selectionAxes.setLocalTranslation(attRef.get().getOffset().toVector3f().multLocal(rescale));
        selectionAxes.setLocalRotation(attRef.get().getOrientation().toQuaternion());
    }
}
