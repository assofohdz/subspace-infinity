/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.asset.*;
import com.jme3.math.*;
import com.jme3.texture.*;
import com.jme3.texture.image.*;

/**
 *  Runtime fabric object containing the textures, colors, etc.
 *  necessary to render a swatch of fabric to a target.
 *
 *  @author    Paul Speed
 */
public class Fabric {
    static Logger log = LoggerFactory.getLogger(Fabric.class);
     
    private static final ColorRGBA DEFAULT_NORMAL = new ColorRGBA(0.5f, 0.5f, 1, 1);
    
    private FabricInfo info;
    private ImageSource baseSource;
    private ImageSource normalSource;
    private ImageSource metalRoughSource;
    private ImageSource specularSource;
    
    public Fabric( FabricInfo info, AssetManager assets ) {
        this.baseSource = loadTexture(assets, info.getBaseTexture(), info.getBaseColor(), null);
        this.normalSource = loadTexture(assets, info.getNormalTexture(), new ColorRGBA(1, 1, 1, 1), 
                                        DEFAULT_NORMAL);
        // r = ao, g = rough, b = metal
        ColorRGBA metalRough = new ColorRGBA(0, (float)info.getRoughness(), (float)info.getMetallic(), 1);
        this.metalRoughSource = loadTexture(assets, info.getMetallicRoughnessTexture(),
                                            metalRough, null);
                                            
//        ColorRGBA specular = new ColorRGBA(1, 1, 1, 1);
        ColorRGBA defaultSpecular = new ColorRGBA(0.25f, 0.25f, 0.25f, 0.25f);
        if( info.getSpecularColor() != null ) {
            defaultSpecular = null;
        }
        this.specularSource = loadTexture(assets, info.getSpecularTexture(), info.getSpecularColor(), defaultSpecular);
    }
 
    protected static ImageSource loadTexture( AssetManager assets, String texture, 
                                              ColorRGBA mult, ColorRGBA fallback ) {
                                              
        if( texture != null ) {
            // We unflip them because of how we copy them... not sure exactly
            // why but if we don't do this then the fabrics are upside down
            // which is most noticable for things like the base skin.
            // It may be related to how the image is in RAM.  -pspeed:2022-04-29
            Texture t = assets.loadTexture(new TextureKey(texture, false));
            if( mult != null ) {
                return ImageSources.mult(ImageSources.texture(t), mult);
            } else {
                return ImageSources.texture(t);
            }            
        }
        if( fallback != null ) {
            if( mult != null ) {
                return ImageSources.color(fallback.mult(mult));
            } else {
                return ImageSources.color(fallback);
            }
        }
        return ImageSources.color(mult);
    }
    
    public FabricInfo getInfo() {
        return info;
    }
    
    protected int clamp( int val, int min, int max ) {
        if( val < min ) {
            return min;
        }
        if( val > max ) {
            return max;
        }
        return val;
    }
    
    // For various approaches, on normal blending see here:
    // https://blog.selfshadow.com/publications/blending-in-detail/    
    protected ColorRGBA combineNormals( ColorRGBA base, ColorRGBA detail ) {
        // Straight add and normalize... not great
        //Vector3f result = new Vector3f(base.r * 2 - 1, base.g * 2 - 1, base.b * 2 - 1);
        //result.addLocal(detail.r * 2 - 1, detail.g * 2 - 1, detail.b * 2 - 1);
        //result.normalizeLocal();
        //return new ColorRGBA((result.x + 1) * 0.5f, (result.y + 1) * 0.5f, (result.z + 1) * 0.5f, base.a);
        
        // UDN Blending
        // float3 r = normalize(float3(n1.xy + n2.xy, n1.z));
        Vector3f result = new Vector3f(base.r * 2 - 1, base.g * 2 - 1, base.b * 2 - 1);
        result.x += detail.r * 2 - 1;
        result.y += detail.g * 2 - 1;
        result.normalizeLocal();
        return new ColorRGBA((result.x + 1) * 0.5f, (result.y + 1) * 0.5f, (result.z + 1) * 0.5f, base.a);
    }
 
    public void paint( ClothingPainter target, int x, int y, ImageSource shape ) {
        ColorRGBA mask = new ColorRGBA();
        ColorRGBA base = new ColorRGBA();
        ColorRGBA normal = new ColorRGBA();
        ColorRGBA metalRough = new ColorRGBA();
        ColorRGBA specular = new ColorRGBA();
        
        for( int i = 0; i < 32; i++ ) {
            for( int j = 0; j < 32; j++ ) {
                int u = x + i;
                int v = y + j;
                
                mask = shape.getPixel(i, (31-j), mask);
                if( mask.a == 0 ) {
                    // Don't render the transparent ones at all
                    continue;
                }
                               
                base = baseSource.getPixel(u, v, base);
                normal = normalSource.getPixel(u, v, normal);
                base.a = base.a * mask.a * normal.a;
                metalRough = metalRoughSource.getPixel(u, v, metalRough);
                metalRough.a = base.a;
                specular = specularSource.getPixel(u, v, specular);

                //metalRough = new ColorRGBA(0, 0.5f, 0, 0);
                
                normal = combineNormals(mask, normal);

                target.paint(u, v, base, normal, metalRough, specular);                                
            }
        }
    }
    
    public void paint( ImageRaster baseTarget, ImageRaster normalTarget, ImageRaster metalRoughTarget,
                       ImageRaster specularTarget, 
                       int x, int y, ImageSource shape ) {
        
        ColorRGBA mask = new ColorRGBA();
        ColorRGBA base = new ColorRGBA();
        ColorRGBA normal = new ColorRGBA();
        ColorRGBA metalRough = new ColorRGBA();
        ColorRGBA specular = new ColorRGBA();
        
        for( int i = 0; i < 32; i++ ) {
            for( int j = 0; j < 32; j++ ) {
                int u = x + i;
                int v = y + j;
                
                mask = shape.getPixel(i, (31-j), mask);
                if( mask.a == 0 ) {
                    // Don't render the transparent ones at all
                    continue;
                }
                               
                base = baseSource.getPixel(u, v, base);
                normal = normalSource.getPixel(u, v, normal);
                metalRough = metalRoughSource.getPixel(u, v, metalRough);
                specular = specularSource.getPixel(y, v, specular);

                //metalRough = new ColorRGBA(0, 0.5f, 0, 0);
                
                normal = combineNormals(mask, normal);

                u = clamp(u, 0, baseTarget.getWidth()-1);                               
                v = clamp(v, 0, baseTarget.getHeight()-1);                               
                baseTarget.setPixel(u, v, base);
                normalTarget.setPixel(u, v, normal);
                metalRoughTarget.setPixel(u, v, metalRough);
                specularTarget.setPixel(u, v, specular);
            }
        }
    }          
}


