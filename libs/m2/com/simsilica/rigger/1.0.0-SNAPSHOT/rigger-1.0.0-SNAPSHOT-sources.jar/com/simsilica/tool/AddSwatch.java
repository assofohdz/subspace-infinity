/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class AddSwatch implements Edit {
    static Logger log = LoggerFactory.getLogger(AddSwatch.class);
    
    private ClothingBuilder clothingBuilder;
    
    private int x;
    private int y;
    private int shape;
    private int fabric;
 
    private boolean added;
    
    public AddSwatch( ClothingBuilder clothingBuilder, int x, int y, int shape, int fabric ) {
        this.clothingBuilder = clothingBuilder;
        this.x = x;
        this.y = y;
        this.shape = shape;
        this.fabric = fabric;
    }  

    @Override
    public String toDisplay() {
        return "(" + x + ", " + y + ") + " + shape + ":" + fabric;
    }
    
    @Override
    public void doEdit() {
        added = clothingBuilder.addSwatch(x, y, shape, fabric);    
    }
    
    @Override
    public void undoEdit() {
        if( added ) {
            clothingBuilder.removeSwatch(x, y);   
        }
    }    
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + toDisplay() + "]";
    }    
}


