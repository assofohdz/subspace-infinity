/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.scene.*;

import com.simsilica.bpos.*;
import com.simsilica.es.*;
import com.simsilica.ext.mphys.*;
import com.simsilica.lemur.LayerComparator;
import com.simsilica.mblock.phys.*;

import com.simsilica.crig.*;
import com.simsilica.crig.jme.*;

/**
 *  Visualizes the entities with position and shape info.
 *
 *  @author    Paul Speed
 */
public class ModelViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ModelViewState.class);

    private EntityData ed;
    private ModelContainer models;
    private AnimationContainer animations;
    private StaticModelContainer staticModels;
    private ShapeFactory<MBlockShape> shapeFactory;
    private PgSpatialFactory modelFactory;

    private Node modelRoot;

    public ModelViewState( PgSpatialFactory modelFactory ) {
        this.modelFactory = modelFactory;
    }

    public Spatial createIndicator( String name, double scale ) {
        MBlockShape shape = shapeFactory.createShape(name, scale, null);
        Spatial spatial = modelFactory.createModel(new EntityId(-1), name, shape, null, scale, null);
        return spatial;
    }

    public Spatial getModel( EntityId id ) {
        ModelView view = models.getObject(id);
        if( view == null ) {
            view = staticModels.getObject(id);
        }
        if( view == null ) {
            return null;
        }
        if( view.spatial == null ) {
            return null;
        }
        return view.spatial;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {
        this.ed = getState(GameSystemState.class).get(EntityData.class, true);
        this.shapeFactory = getState(GameSystemState.class).get(ShapeFactory.class, true);
        this.models = new ModelContainer(ed);
        this.animations = new AnimationContainer(ed);
        this.staticModels = new StaticModelContainer(ed);

        this.modelRoot = new Node("modelRoot");
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        models.start();
        animations.start();
        staticModels.start();
        getState(WorldViewState.class).getWorldRoot().attachChild(modelRoot);
    }

    @Override
    protected void onDisable() {
        staticModels.stop();
        animations.stop();
        models.stop();
        modelRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        models.update();
        animations.update();
        staticModels.update();
        for( ModelView view : models.getArray() ) {
            view.update();
        }
    }

    protected class ModelView {
        private Entity entity;
        private ShapeInfo shapeInfo;
        private MBlockShape shape;
        private Spatial spatial;
        private AnimComposerRig rig;

        public ModelView( Entity entity ) {
            this.entity = entity;
        }

        public void updateData() {
            setShapeInfo(entity.get(ShapeInfo.class));
            //SpawnPosition pos = entity.get(SpawnPosition.class);
            BodyPosition pos = entity.get(BodyPosition.class);
            if( pos != null ) {
                spatial.setLocalTranslation(pos.getLastLocation().toVector3f());
                spatial.setLocalRotation(pos.getLastOrientation().toQuaternion());
            } else {
                SpawnPosition sPos = entity.get(SpawnPosition.class);
                spatial.setLocalTranslation(sPos.getLocation().toVector3f());
                spatial.setLocalRotation(sPos.getOrientation().toQuaternion());
            }
        }

        public void update() {
            //if( rig != null ) {
            //    rig.setTime(null, 0);
            //}
        }

        protected void setShapeInfo( ShapeInfo shapeInfo ) {
            if( this.shapeInfo == shapeInfo ) {
                return;
            }
            log.info("update shape for:" + entity.getId() + " to:" + shapeInfo.toString(ed));
            this.shapeInfo = shapeInfo;
            if( this.spatial != null ) {
                this.spatial.removeFromParent();
                this.rig = null;
            }

            // Mass doesn't matter for the view... but we'll grab it just in case
            Mass mass = ed.getComponent(entity.getId(), Mass.class);
            String name = shapeInfo.getShapeName(ed);
            this.shape = shapeFactory.createShape(name, shapeInfo.getScale(), mass);
            this.spatial = modelFactory.createModel(entity.getId(), name, shape, mass, shapeInfo.getScale(), null);
            LayerComparator.setLayer(spatial, 1);

            if( shape instanceof RigShape ) {
                this.rig = AnimComposerRig.createRig(spatial);
                //rig.setLayerAction(null, "Idle");
                //rig.setTime(null, 0.0);
            } else {
                this.rig = null;
            }

            modelRoot.attachChild(spatial);
        }

        public void release() {
            spatial.removeFromParent();
        }
    }

    protected class AnimView {
        private Entity entity;
        private ModelView model;
        private CharAnimation anim;

        public AnimView( Entity entity ) {
            this.entity = entity;
        }

        public void updateData() {
            if( model == null ) {
                model = models.getObject(entity.getId());
            }
            if( model == null ) {
                log.warn("No anim model for:" + entity);
                return;
            }
            CharAnimation a = entity.get(CharAnimation.class);
            if( model.rig != null ) {
                if( anim == null || !Objects.equals(anim.getAction(), a.getAction()) ) {
                    log.info("setLayerAction(" + a.getAction() + ")");
                    model.rig.setLayerAction(null, a.getAction());
                }
                //log.info(entity.getId() + ":setTime(" + a.getTime() + ")");
                model.rig.setTime(null, a.getTime());
                this.anim = a;
            } else {
                this.anim = null;
            }
        }

        public void release() {
        }
    }

    protected class ModelContainer extends EntityContainer<ModelView> {
        public ModelContainer( EntityData ed ) {
            super(ed, BodyPosition.class, ShapeInfo.class);
        }

        protected ModelView[] getArray() {
            return (ModelView[])super.getArray();
        }

        protected ModelView addObject( Entity entity ) {
            log.info("model added:" + entity.getId());
            ModelView result = new ModelView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( ModelView object, Entity entity ) {
            //log.info("model updated:" + entity.getId());
            object.updateData();
        }

        protected void removeObject( ModelView object, Entity entity ) {
            log.info("model removed:" + entity.getId());
            object.release();
        }
    }

    protected class AnimationContainer extends EntityContainer<AnimView> {
        public AnimationContainer( EntityData ed ) {
            super(ed, CharAnimation.class);
        }

        protected AnimView addObject( Entity entity ) {
            log.info("animation added:" + entity.getId());
            AnimView result = new AnimView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( AnimView object, Entity entity ) {
            object.updateData();
        }

        protected void removeObject( AnimView object, Entity entity ) {
            log.info("model removed:" + entity.getId());
            object.release();
        }
    }

    protected class StaticModelContainer extends EntityContainer<ModelView> {
        public StaticModelContainer( EntityData ed ) {
            super(ed, SpawnPosition.class, ShapeInfo.class, Mass.class);
            setFilter(Filters.fieldEquals(Mass.class, "mass", 0.0));
        }

        protected ModelView[] getArray() {
            return (ModelView[])super.getArray();
        }

        protected ModelView addObject( Entity entity ) {
            log.info("static model added:" + entity.getId());
            ModelView result = new ModelView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( ModelView object, Entity entity ) {
            //log.info("model updated:" + entity.getId());
            object.updateData();
        }

        protected void removeObject( ModelView object, Entity entity ) {
            log.info("static model removed:" + entity.getId());
            object.release();
        }
    }
}
