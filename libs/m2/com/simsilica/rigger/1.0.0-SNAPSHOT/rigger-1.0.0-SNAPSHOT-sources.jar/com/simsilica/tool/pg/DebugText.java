/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import org.slf4j.*;

import com.google.common.base.*;

import com.jme3.math.ColorRGBA;

import com.simsilica.es.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DebugText implements EntityComponent {
    static Logger log = LoggerFactory.getLogger(DebugText.class);

    private String layer;
    private String text;
    private double size;
    private ColorRGBA color;
    private boolean translucent;

    public DebugText( String layer, String text, double size, ColorRGBA color, boolean translucent ) {
        this.layer = layer;
        this.text = text;
        this.size = size;
        this.color = color;
        this.translucent = translucent;
    }

    public String getLayer() {
        return layer;
    }

    public String getText() {
        return text;
    }

    public double getSize() {
        return size;
    }

    public ColorRGBA getColor() {
        return color;
    }

    public boolean isTranslucent() {
        return translucent;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("layer", layer)
            .add("text", text)
            .add("size", size)
            .add("color", color)
            .add("translucent", translucent)
            .toString();
    }
}
