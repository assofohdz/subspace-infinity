/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.math.*;
import com.jme3.post.FilterPostProcessor;
import com.jme3.post.ssao.SSAOFilter;
import com.jme3.shadow.DirectionalLightShadowFilter;
import com.jme3.system.AppSettings;

import com.simsilica.fx.LightingState;
import com.simsilica.fx.shadow.DropShadowFilter;

import com.simsilica.lemur.props.PropertyPanel;


/**
 *
 *  @author    Paul Speed
 */
public class RiggerPostProcessingState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(RiggerPostProcessingState.class);

    private FilterPostProcessor fpp;
    //private DirectionalLightShadowFilter shadows1;
    private DropShadowFilter shadows2;
    private float shadowStrength = 0.3f;

    //private ColorRGBA lightColor = ColorRGBA.White;
    //private float lightStrength = 0.75f;

    //private SSAOFilter ssao;

    private PropertyPanel settings;

    public RiggerPostProcessingState() {
    }

    public PropertyPanel getSettings() {
        return settings;
    }

    //public void setEnableShadows( boolean b ) {
    //    shadows1.setEnabled(b);
    //    if( b && shadows2.isEnabled() ) {
    //        shadows2.setEnabled(false);
    //    }
    //}
    //
    //public boolean getEnableShadows() {
    //    return shadows1.isEnabled();
    //}

    public void setEnableDropShadows( boolean b ) {
        shadows2.setEnabled(b);
        //if( b && shadows1.isEnabled() ) {
        //    shadows1.setEnabled(false);
        //}
    }

    public boolean getEnableDropShadows() {
        return shadows2.isEnabled();
    }

    public void setShadowStrength( float f ) {
        if( this.shadowStrength == f ) {
            return;
        }
        this.shadowStrength = f;
        resetShadowStrength();
    }

    public float getShadowStrength() {
        return shadowStrength;
    }

    //public void setEnableSsao( boolean b ) {
    //    ssao.setEnabled(b);
    //}
    //
    //public boolean getEnableSsao() {
    //    return ssao.isEnabled();
    //}
    //
    //public void setLightStrength( float f ) {
    //    if( this.lightStrength == f ) {
    //        return;
    //    }
    //    this.lightStrength = f;
    //    resetLightStrength();
    //}
    //
    //public float getLightStrength() {
    //    return lightStrength;
    //}

    protected void resetShadowStrength() {
        //shadows1.setShadowIntensity(shadowStrength);
        shadows2.setShadowIntensity(shadowStrength);
    }

    //protected void resetLightStrength() {
    //    getState(LightingState.class).setSunColor(lightColor.mult(lightStrength));
    //    getState(LightingState.class).setAmbient(lightColor.mult(lightStrength * 0.5f));
    //}

    @Override
    protected void initialize( Application app ) {

        AssetManager assets = app.getAssetManager();

        fpp = new FilterPostProcessor(assets);
        AppSettings appSettings = app.getContext().getSettings();
        if( appSettings.getSamples() != 0 ) {
            fpp.setNumSamples(appSettings.getSamples());
        }

        shadows2 = new DropShadowFilter();
        shadows2.setEnabled(true);
        fpp.addFilter(shadows2);

        //shadows1 = new DirectionalLightShadowFilter(assets, 4096, 4);
        //shadows1.setShadowIntensity(0.3f);
        //shadows1.setLight(getState(LightingState.class).getSun());
        //shadows1.setEnabled(false);
        //fpp.addFilter(shadows1);

        //ssao = new SSAOFilter();
        //ssao.setEnabled(false);
        //fpp.addFilter(ssao);

        settings = new PropertyPanel("glass");

        //settings.addBooleanProperty("Shadows", this, "enableShadows");
        settings.addBooleanProperty("Drop Shadows", this, "enableDropShadows");
        settings.addFloatProperty("Shadow Strength (*)", this, "shadowStrength", 0, 1, 0.05f);
        //settings.addFloatProperty("Time of Day", getState(LightingState.class), "timeOfDay", -0.1f, 1.1f, 0.01f);
        //settings.addFloatProperty("Sun Orientation", getState(LightingState.class), "orientation", 0f, FastMath.TWO_PI, 0.01f);
        //settings.addFloatProperty("Sun Strength", this, "lightStrength", 0, 2, 0.1f);

        //settings.addBooleanProperty("SSAO", this, "enableSsao");
        //settings.addFloatProperty("Bias", ssao, "bias", 0, 1, 0.05f);
        //settings.addFloatProperty("Intensity", ssao, "intensity", 0.1f, 10, 0.1f);
        //settings.addFloatProperty("sampleRadius", ssao, "sampleRadius", 0, 10, 0.1f);
        //settings.addFloatProperty("scale", ssao, "scale", 0, 1, 0.05f);

        //resetShadowStrength();
        //resetLightStrength();

        getState(MainMenuState.class).getTabs().addTab("Post-proc", settings);

    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getApplication().getViewPort().addProcessor(fpp);
    }

    @Override
    public void update( float tpf ) {
    }

    @Override
    protected void onDisable() {
        getApplication().getViewPort().removeProcessor(fpp);
    }
}
