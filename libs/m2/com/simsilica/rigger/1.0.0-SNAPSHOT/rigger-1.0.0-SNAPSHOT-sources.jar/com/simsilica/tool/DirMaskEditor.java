/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;

import com.simsilica.mblock.DirectionMasks;

/**
 *  Allows editing of a direction mask by toggling on/off
 *  checkboxes.
 *
 *  @author    Paul Speed
 */
public class DirMaskEditor extends Container {
    static Logger log = LoggerFactory.getLogger(DirMaskEditor.class);
 
    private Checkbox[] checks = new Checkbox[4];
    
    public DirMaskEditor() {
        super(new SpringGridLayout(Axis.Y, Axis.X, FillMode.ForcedEven, FillMode.ForcedEven)); 
        
        checks[0] = addChild(new Checkbox("N"), 0, 1);   
        checks[1] = addChild(new Checkbox("S"), 2, 1);   
        checks[2] = addChild(new Checkbox("E"), 1, 2);   
        checks[3] = addChild(new Checkbox("W"), 1, 0);   
    }
    
    public int getDirMask() {
        int result = 0;
        if( checks[0].isChecked() ) {
            result = result | DirectionMasks.NORTH_MASK;
        }
        if( checks[1].isChecked() ) {
            result = result | DirectionMasks.SOUTH_MASK;
        }
        if( checks[2].isChecked() ) {
            result = result | DirectionMasks.EAST_MASK;
        }
        if( checks[3].isChecked() ) {
            result = result | DirectionMasks.WEST_MASK;
        }
        
        return result;            
    }
}
