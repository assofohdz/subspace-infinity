/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.*;

import com.google.common.base.Function;
import com.google.common.io.Files;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.TextureKey;
import com.jme3.collision.*;
import com.jme3.input.MouseInput;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.scene.mesh.*;
import com.jme3.texture.*;
import com.jme3.texture.image.*;
import com.jme3.util.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.TabbedPanel.Tab;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.ElementId;
import com.simsilica.lemur.value.DefaultValueRenderer;

import com.simsilica.mathd.*;

import com.simsilica.jmec.*;

import com.simsilica.mblock.*;

import com.simsilica.tool.io.*;

/**
 *  Select and edit clothing.  At least I hope so.
 *
 *  @author    Paul Speed
 */
public class ClothingState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ClothingState.class);

    private VersionedReference<Rig> rigRef;
    private Rig rig;
    private RigInfo rigInfo;

    private boolean tabEnabled;
    private Container window;
    private VersionedReference<Tab> selectedTabRef;
    private boolean clothingEnabled = false;
    private String originalAction = null;

    private PaintListener paintListener = new PaintListener();

    private ClothingPainter clothingPainter;

    // For now we will load textures directly but eventually we
    // will want something configurable, I think.
    private AssetReader assetReader;

    private ClothingBuilder clothingBuilder;
    private VersionedReference<ClothingBuilder> builderRef;
    private boolean[][] filledCells;
    private boolean[][] changedCells;

    private EditHistory history = new EditHistory(500);
    private Edit lastEdit;  // when this is different than history, we know we have unsaved changes

    private VersionedList<FabricInfo> fabricInfos = new VersionedList<>();
    private Selector<FabricInfo> fabricSelector;
    private VersionedReference<Integer> selectedFabricRef;
    private FabricInfo currentFabricInfo;
    private Fabric currentFabric;
    private int currentFabricIndex = -1;

    // r = ao, g = rough, b = metal
    private ColorRGBA defaultMetalRough = new ColorRGBA(0, 0.5f, 0, 0);

    private DirMaskEditor dirMaskEditor;

    private SwatchIndex shapeIndex = new SwatchIndex();
    private CellSelector shapeSelector;
    private List<Fabric> fabrics = new ArrayList<>();

    //private CellSelector clothingCellSelector;

    private ClothingFormat clothingFormat;

    private List<Geometry> geometryList = new ArrayList<>();

    private File currentFile;
    private FileDialog fileDialog;

    private Container fileSaveDialog;
    private TextField fileEntry;

    private boolean yFlip = false;

    public ClothingState() {
    }

    public static ColorRGBA parseColor( String s ) {
        int r = Integer.parseInt(s.substring(1, 3), 16);
        int g = Integer.parseInt(s.substring(3, 5), 16);
        int b = Integer.parseInt(s.substring(5, 7), 16);

        //return ColorRGBA.fromRGBA255(r, g, b, 255);
// public static ColorRGBA fromRGBA255(int r, int g, int b, int a) {
        return new ColorRGBA(r/255f, g/255f, b/255f, 1);
    }

    protected void clear() {
        if( lastEdit != history.getLastEdit() ) {
            getState(OptionPanelState.class).show("Clear All Clothing", "Really clear clothing?",
                                                new CallMethodAction("Yes", this, "resetWorkspace"),
                                                new EmptyAction("No"),
                                                new EmptyAction("Cancel")
                                                );
        } else {
            resetWorkspace();
        }
    }

    protected List<String> getFileList() {
        List<String> results = new ArrayList<>();

        File root = RiggerConfig.getInstance().getFile("clothing");
        if( !root.exists() ) {
            root.mkdirs();
        }

        for( File f : root.listFiles() ) {
            if( f.isDirectory() ) {
                continue;
            }
            if( !f.getName().endsWith(".clothing") ) {
                continue;
            }
            results.add(toName(f));
        }

        return results;
    }

    public void open() {
        System.out.println("open()");
        if( lastEdit != history.getLastEdit() ) {
            getState(OptionPanelState.class).show("Abandon Changes?",
                                                "Really abandon current changes?",
                                                new CallMethodAction("Yes", this, "selectFile"),
                                                new EmptyAction("No"),
                                                new EmptyAction("Cancel"));
        } else {
            selectFile();
        }
    }

    protected void selectFile() {
        log.info("selectFile()");
        fileDialog = new FileDialog("Open Workspace", getFileList(), "Load", () -> openFile());
        GuiGlobals.getInstance().getPopupState().centerInGui(fileDialog);
        GuiGlobals.getInstance().getPopupState().showModalPopup(fileDialog);
    }

    protected void openFile() {
        log.info("openFile:" + fileDialog.getSelectedFile());
        if( fileDialog.getSelectedFile() == null ) {
            return;
        }
        File f = toFile(fileDialog.getSelectedFile());
        doOpen(f);
    }

    public void save() {
        log.info("save()");
        if( currentFile == null ) {
            saveAs();
            return;
        }
        doSave(currentFile);
    }

    protected void saveAs() {
        log.info("saveAs()");

        if( currentFile != null ) {
            fileEntry.setText(toName(currentFile));
        }

        Vector3f pref = fileSaveDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileSaveDialog.setLocalTranslation(loc);

        GuiGlobals.getInstance().getPopupState().showModalPopup(fileSaveDialog);
    }

    protected void cancelSave() {
        fileSaveDialog.removeFromParent();
    }

    protected String toName( File f ) {
        return Files.getNameWithoutExtension(f.getName());
    }

    protected File toFile( String name ) {
        if( !name.endsWith(".clothing") ) {
            name += ".clothing";
        }
        return RiggerConfig.getInstance().getFile("clothing/" + name);
    }

    protected void saveFile() {
        fileSaveDialog.removeFromParent();

        String name = fileEntry.getText();
        File file = toFile(name);
        if( file.exists() ) {
            getState(OptionPanelState.class).show("Overwrite?",
                                                "Really overwrite existing file:" + name + "?",
                                                new CallMethodAction("Yes", this, "doSave"),
                                                new CallMethodAction("No", this, "saveAs"),
                                                new EmptyAction("Cancel"));
        } else {
            doSave(file);
        }
    }

    protected void doOpen( File file ) {
        try {
            if( file.exists() ) {
                log.info("Loading:" + file);
                clothingBuilder.setCells(readCells(file));
                this.currentFile = file;
                history.clear();
                repaint(true);
            }
        } catch( IOException e ) {
            log.error("Error reading cells", e);
        }
    }

    protected void doSave() {
        String name = fileEntry.getText();
        File file = toFile(name);
        doSave(file);
    }

    protected void doSave( File file ) {
        try {
            log.info("Saving:" + file);
            if( file.getParentFile() != null && !file.getParentFile().exists() ) {
                file.getParentFile().mkdirs();
            }
            saveCells(file, clothingBuilder.getCells());
            this.currentFile = file;
            this.lastEdit = history.getLastEdit();
        } catch( IOException e ) {
            log.error("Error saving cells", e);
        }
    }

    protected void addClothingFromTemplate() {
        CreateClothingDialog dialog = new CreateClothingDialog(this, clothingBuilder, history,
                                                               fabricInfos, clothingFormat);
        getState(PopupState.class).centerInGui(dialog);
        getState(PopupState.class).showModalPopup(dialog);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void initialize( Application app ) {
        rigRef = getState(RigViewState.class, true).createRigReference();

        this.clothingBuilder = new ClothingBuilder(32, 32, 32); // lots of layers for now
        this.builderRef = clothingBuilder.createReference();
        this.clothingPainter = new ClothingPainter();

        this.filledCells = new boolean[32][32];
        this.changedCells = new boolean[32][32];

        fileSaveDialog = new Container();
        fileSaveDialog.addChild(new Label("Save As...", new ElementId("title.label")));
        fileEntry = fileSaveDialog.addChild(new TextField("MyFile"));
        Container buttons = fileSaveDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Save", this, "saveFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", this, "cancelSave")));

        window = new Container();
        getState(ToolState.class).getTabs().addTab("Clothing", window);

        Container actions = window.addChild(new Container());
        actions.addChild(new ActionButton(new CallMethodAction("Reset Clothing", this, "clear")));
        actions.addChild(new ActionButton(new CallMethodAction("Open Clothing...", this, "open")));
        actions.addChild(new ActionButton(new CallMethodAction("Save Clothing", this, "save")));
        actions.addChild(new ActionButton(new CallMethodAction("Save As Clothing...", this, "saveAs")));
        actions.addChild(new Label(" "));
        actions.addChild(new ActionButton(new CallMethodAction(this, "addClothingFromTemplate")));

        Container properties = window.addChild(new Container());

        properties.addChild(new Label("Fabric:"));
        fabricSelector = properties.addChild(new Selector<>(fabricInfos));
        Function<FabricInfo, String> func = (fabricInfo) -> fabricInfo == null ? "None" : fabricInfo.getName();
        fabricSelector.setValueRenderer(new DefaultValueRenderer(func));
        selectedFabricRef = fabricSelector.getSelectionModel().createSelectionReference();

        selectedTabRef = getState(ToolState.class).getTabs().getSelectionModel().createReference();

        window.addChild(new Label("Hard edges:"));
        dirMaskEditor = window.addChild(new DirMaskEditor());
        dirMaskEditor.setInsetsComponent(new DynamicInsetsComponent(0, 0, 0, 1));

        window.addChild(new Label("Shapes:"));

        this.assetReader = new AssetReader(RiggerConfig.getInstance().getProjectDir());

        // Load the atlas of base shapes
        Texture baseShapeAtlas = assetReader.getAssetManager().loadTexture("textures/shapes.png");
        ImageSource atlasSource = ImageSources.texture(baseShapeAtlas);

        // Atlas indexes are based on the shapes.png texture
        SwatchShape shape;
        shape = new SwatchShape("full", 0, 7);
        shape.addEdges(Direction.North, Direction.South, Direction.East, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-n", 1, 7);
        shape.addEdges(Direction.North, Direction.East, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-w", 2, 7);
        shape.addEdges(Direction.North, Direction.South, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-s", 3, 7);
        shape.addEdges(Direction.South, Direction.East, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-e", 4, 7);
        shape.addEdges(Direction.North, Direction.East, Direction.South);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-ns", 5, 7);
        shape.addEdges(Direction.North, Direction.South);
        shapeIndex.add(shape);

        shape = new SwatchShape("halfbar-ew", 6, 7);
        shape.addEdges(Direction.East, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("square", 7, 7);
        shapeIndex.add(shape);

        shape = new SwatchShape("frayed-n", 2, 2);
        shape.addEdges(Direction.North, Direction.East, Direction.West);
        shapeIndex.add(shape);
        shape = new SwatchShape("frayed-w", 3, 2);
        shape.addEdges(Direction.North, Direction.South, Direction.West);
        shapeIndex.add(shape);
        shape = new SwatchShape("frayed-s", 4, 2);
        shape.addEdges(Direction.South, Direction.East, Direction.West);
        shapeIndex.add(shape);
        shape = new SwatchShape("frayed-e", 5, 2);
        shape.addEdges(Direction.North, Direction.East, Direction.South);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-nw", 0, 6);
        shape.addEdges(Direction.North, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-ne", 1, 6);
        shape.addEdges(Direction.North, Direction.East);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-sw", 0, 5);
        shape.addEdges(Direction.South, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-se", 1, 5);
        shape.addEdges(Direction.South, Direction.East);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-n", 2, 6);
        shape.addEdges(Direction.North);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-w", 3, 6);
        shape.addEdges(Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-s", 4, 6);
        shape.addEdges(Direction.South);
        shapeIndex.add(shape);

        shape = new SwatchShape("tri-e", 5, 6);
        shape.addEdges(Direction.East);
        shapeIndex.add(shape);

        shape = new SwatchShape("sm-tri-nw", 0, 2);
        shape.addEdges(Direction.North, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("sm-tri-ne", 1, 2);
        shape.addEdges(Direction.North, Direction.East);
        shapeIndex.add(shape);

        shape = new SwatchShape("sm-tri-sw", 0, 1);
        shape.addEdges(Direction.South, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("sm-tri-se", 1, 1);
        shape.addEdges(Direction.South, Direction.East);
        shapeIndex.add(shape);


        shape = new SwatchShape("button-n", 2, 5);
        shapeIndex.add(shape);
        shape = new SwatchShape("button-w", 3, 5);
        shapeIndex.add(shape);
        shape = new SwatchShape("button-s", 4, 5);
        shapeIndex.add(shape);
        shape = new SwatchShape("button-e", 5, 5);
        shapeIndex.add(shape);
        shape = new SwatchShape("button", 6, 5);
        shapeIndex.add(shape);

        shape = new SwatchShape("buckle", 0, 4);
        // We want the buckle to always have edges all around... so we'll
        // force them.
        shape.setForcedMask(SwatchShape.dirsToMask(Direction.North, Direction.South, Direction.East, Direction.West));
        shapeIndex.add(shape);

        shape = new SwatchShape("buckle-n", 1, 4);
        shape.addEdges(Direction.North);
        // Force the east/west edges to generate
        shape.setForcedMask(SwatchShape.dirsToMask(Direction.East, Direction.West));
        shapeIndex.add(shape);
        shape = new SwatchShape("buckle-w", 2, 4);
        shape.addEdges(Direction.West);
        shape.setForcedMask(SwatchShape.dirsToMask(Direction.North, Direction.South));
        shapeIndex.add(shape);
        shape = new SwatchShape("buckle-s", 3, 4);
        shape.addEdges(Direction.South);
        shape.setForcedMask(SwatchShape.dirsToMask(Direction.East, Direction.West));
        shapeIndex.add(shape);
        shape = new SwatchShape("buckle-e", 4, 4);
        shape.addEdges(Direction.East);
        shape.setForcedMask(SwatchShape.dirsToMask(Direction.North, Direction.South));
        shapeIndex.add(shape);

        shape = new SwatchShape("laces", 7, 5);
        shape.addEdges(Direction.North);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-e", 5, 4);
        shape.addEdges(Direction.East);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-ew", 6, 4);
        shape.addEdges(Direction.East, Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-w", 7, 4);
        shape.addEdges(Direction.West);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-n", 6, 6);
        shape.addEdges(Direction.North);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-s", 7, 6);
        shape.addEdges(Direction.South);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-diag1", 0, 3);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag1-e", 2, 3);
        shape.addEdges(Direction.East);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag1-w", 3, 3);
        shape.addEdges(Direction.West);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag1-s", 6, 3);
        shape.addEdges(Direction.South);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag1-n", 6, 2);
        shape.addEdges(Direction.North);
        shapeIndex.add(shape);

        shape = new SwatchShape("laces-diag2", 1, 3);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag2-e", 4, 3);
        shape.addEdges(Direction.East);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag2-w", 5, 3);
        shape.addEdges(Direction.West);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag2-s", 7, 3);
        shape.addEdges(Direction.South);
        shapeIndex.add(shape);
        shape = new SwatchShape("laces-diag2-n", 7, 2);
        shape.addEdges(Direction.North);
        shapeIndex.add(shape);


        shapeIndex.buildVariants(atlasSource);

        // Create a texture from just the base shapes for the selector to use
        Texture t = new Texture2D(ImageUtils.createImage(Image.Format.ABGR8, 32*8, 32*8));
        ImageRaster selectorRaster = ImageRaster.create(t.getImage());

        // Paint the base shapes to the selector raster as well
        // as the master shape raster... copied from the source atlas
        List<SwatchShape> baseShapes = shapeIndex.getBaseShapes();
        for( int i = 0; i < baseShapes.size(); i++ ) {
            SwatchShape ss = baseShapes.get(i);
            Vec3i cell = ss.getSourceCell();

            int xShape = cell.x;
            int yShape = cell.y;
            ImageSource source = ImageSources.subimage(atlasSource, xShape * 32, yShape * 32, 32, 32);

            // Selector target is based on 8x8 raster.
            int xCell = i % 8;
            int yCell = 7 - (i / 8);
            ImageUtils.paint(source, selectorRaster, xCell * 32, yCell * 32);
        }


        shapeSelector = window.addChild(new CellSelector(t, 8, 8, 32));

        // Just so we can see what it looks like:
        //clothingCellSelector = window.addChild(new CellSelector(clothingPainter.getBaseTexture(), 32, 32, 8));

        FabricInfo fabric;
        fabric = new FabricInfo("base");
        //fabric.setBaseColor(parseColor("#d6bbab"));
        //fabric.setBaseColor(parseColor("#ffffff"));
        fabric.setBaseTexture("textures/BaseSkin.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.6);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("bleached-linen");
        fabric.setBaseColor(parseColor("#c8c5bb"));
        fabric.setNormalTexture("textures/burlap-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("linen");
        fabric.setBaseColor(parseColor("#bdaf93"));
        fabric.setNormalTexture("textures/burlap-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave");
        fabric.setBaseColor(parseColor("#bdaf93"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-red");
        fabric.setBaseColor(parseColor("#af3636"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-red");
        fabric.setBaseColor(parseColor("#6a0404"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-green");
        fabric.setBaseColor(parseColor("#3d752f"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-green");
        fabric.setBaseColor(parseColor("#063e06"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-blue");
        fabric.setBaseColor(parseColor("#4d6995"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-blue");
        fabric.setBaseColor(parseColor("#040e17"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-yellow");
        fabric.setBaseColor(parseColor("#cfc86d"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-yellow");
        fabric.setBaseColor(parseColor("#5c5716"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-pink");
        fabric.setBaseColor(parseColor("#b66992"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-pink");
        fabric.setBaseColor(parseColor("#850c5f"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-orange");
        fabric.setBaseColor(parseColor("#c77932"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-orange");
        fabric.setBaseColor(parseColor("#9f3c0c"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-purple");
        fabric.setBaseColor(parseColor("#8045a7"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("weave-dark-purple");
        fabric.setBaseColor(parseColor("#310e48"));
        fabric.setNormalTexture("textures/weave4-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);


        fabric = new FabricInfo("heavy-weave");
        fabric.setBaseColor(parseColor("#bdaf93"));
        fabric.setNormalTexture("textures/cloth1-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("textile");
        fabric.setBaseColor(parseColor("#bdaf93"));
        fabric.setNormalTexture("textures/heavy-weave-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("green-plaid");
        fabric.setBaseTexture("textures/green-plaid.png");
        fabric.setNormalTexture("textures/heavy-weave-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("red-plaid");
        fabric.setBaseTexture("textures/red-plaid.png");
        fabric.setNormalTexture("textures/heavy-weave-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("blue-plaid");
        fabric.setBaseTexture("textures/blue-plaid.png");
        fabric.setNormalTexture("textures/heavy-weave-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.9);
        fabricInfos.add(fabric);


        fabric = new FabricInfo("leather");
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setNormalTexture("textures/leather-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("dark-leather");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setNormalTexture("textures/leather-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.6);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("black-leather");
        fabric.setBaseColor(new ColorRGBA(0.05f, 0.05f, 0.05f, 1));
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setNormalTexture("textures/leather-normals.png");
        fabric.setMetallic(0);
        fabric.setRoughness(0.6);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("rough-leather");
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setNormalTexture("textures/ROCK6-norm.jpg");
        fabric.setMetallic(0);
        fabric.setRoughness(0.65);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("suede");
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setMetallic(0);
        fabric.setRoughness(1);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("dark-suede");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setMetallic(0);
        fabric.setRoughness(1);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("black-suede");
        fabric.setBaseColor(new ColorRGBA(0.05f, 0.05f, 0.05f, 1));
        fabric.setBaseTexture("textures/leather-gradient.jpg");
        fabric.setMetallic(0);
        fabric.setRoughness(1);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("steel");
        fabric.setBaseTexture("textures/medium-steel.jpg");
        fabric.setMetallic(1);
        fabric.setRoughness(0.3);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("metal");
        fabric.setBaseTexture("textures/metal-base.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("rusted-metal");
        fabric.setBaseTexture("textures/rust-base.png");
        fabric.setNormalTexture("textures/rust-normals.png");
        fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(1);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("chainmail");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseTexture("textures/metal-base.png");
        fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("dark-chainmail");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.25f, 0.25f, 0.25f, 1));
        fabric.setBaseTexture("textures/metal-base.png");
        fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("test-grid");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        fabric.setSpecularTexture("Textures/color-grid.png");
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-test");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        fabric.setSpecularTexture("Textures/specular-test.png");
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-25");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setSpecularTexture("textures/specular-test.png");
        fabric.setSpecularColor(new ColorRGBA(1, 1, 1, 0.25f));
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-50");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setSpecularTexture("textures/specular-test.png");
        fabric.setSpecularColor(new ColorRGBA(1, 1, 1, 0.5f));
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-75");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setSpecularTexture("textures/specular-test.png");
        fabric.setSpecularColor(new ColorRGBA(1, 1, 1, 0.75f));
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-100");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setSpecularTexture("textures/specular-test.png");
        fabric.setSpecularColor(new ColorRGBA(1, 1, 1, 1f));
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        fabric = new FabricInfo("specular-0");
        //fabric.setBaseTexture("textures/chainmail1024.png");
        fabric.setBaseColor(new ColorRGBA(0.5f, 0.5f, 0.5f, 1));
        //fabric.setBaseTexture("textures/metal-base.png");
        //fabric.setNormalTexture("textures/chainmail1024-normals.png");
        //fabric.setSpecularTexture("textures/specular-test.png");
        fabric.setSpecularColor(new ColorRGBA(1, 1, 1, 0.0f));
        //fabric.setMetallicRoughnessTexture("textures/rust-mr.png");
        fabric.setMetallic(1);
        fabric.setRoughness(0.5);
        fabricInfos.add(fabric);

        for( FabricInfo info : fabricInfos ) {
            fabrics.add(new Fabric(info, assetReader.getAssetManager()));
        }

        // We don't really want "base" to show up in the list since we don't let
        // users actually paint with it.
        fabricInfos.remove(0);

        clothingFormat = new ClothingFormat(fabricInfos, shapeIndex);

        resetWorkspace();

        File temp = currentFile;
        File f = new File("last.clothing");
        if( f.exists() ) {
            doOpen(f);
        }
        currentFile = temp;

        resetRig(rigRef.get());
    }

    @Override
    protected void cleanup( Application app ) {
        try {
            saveCells(new File("last.clothing"), clothingBuilder.getCells());
        } catch( IOException e ) {
            log.error("Error saving cells", e);
        }
        try {
            // Just for debugging/testing, we'll save the images, too.
            ImageUtils.writeImage(new File("test-base.png"), clothingPainter.getBaseTexture());
            ImageUtils.writeImage(new File("test-normal.png"), clothingPainter.getNormalTexture());
            ImageUtils.writeImage(new File("test-mr.png"), clothingPainter.getMetalRoughnessTexture());
        } catch( Exception e ) {
            log.error("Error writing test images", e);
        }
    }

    @Override
    protected void onEnable() {
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.addDelegate(MainAppFunctions.F_SAVE, this, "save");
        inputMapper.addDelegate(MainAppFunctions.F_UNDO, this, "undo");
        inputMapper.addDelegate(MainAppFunctions.F_REDO, this, "redo");
    }

    @Override
    protected void onDisable() {
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.removeDelegate(MainAppFunctions.F_SAVE, this, "save");
        inputMapper.removeDelegate(MainAppFunctions.F_UNDO, this, "undo");
        inputMapper.removeDelegate(MainAppFunctions.F_REDO, this, "redo");
    }

    @Override
    public void update( float tpf ) {
        if( rigRef.update() ) {
            resetRig(rigRef.get());
        }
        if( selectedTabRef.update() ) {
            tabChanged(selectedTabRef.get());
        }
        if( selectedFabricRef.update() ) {
            setFabric(selectedFabricRef.get());
        }
        if( builderRef.update() ) {
            repaint(false);
        }

        // Heavy handed for now
        for( Geometry geom : geometryList ) {
            geom.getMesh().clearCollisionData();
            geom.getMesh().createCollisionData();
        }
    }

    protected void saveCells( File f, CellArray cells ) throws IOException {
        clothingFormat.writeCells(new FileOutputStream(f), cells);
    }

    protected CellArray readCells( File f ) throws IOException {
        return clothingFormat.readCells(new FileInputStream(f));
    }

    protected void setFabric( int fabricIndex ) {
        if( this.currentFabricIndex == fabricIndex ) {
            return;
        }
        this.currentFabricIndex = fabricIndex;
        this.currentFabricInfo = fabricInfos.get(fabricIndex);

        this.currentFabric = new Fabric(currentFabricInfo, assetReader.getAssetManager());
    }

    public void undo() {
        history.undo();
        repaint(true);
    }

    public void redo() {
        history.redo();
        repaint(true);
    }

    protected void resetWorkspace() {
        clothingBuilder.clear();
        history.clear();

        try {
            CellArray cells = clothingFormat.readCells(getClass().getResourceAsStream("/Clothing/female-underwear1.clothing"));
            clothingBuilder.setCells(cells);
        } catch( IOException e ) {
            log.error("Error reading cells", e);
        }

        repaint(true);
    }

    protected void repaint( boolean forceReset ) {
        long start = System.nanoTime();
        for( int i = 0; i < 32; i++ ) {
            for( int y = 0; y < 32; y++ ) {
                int j = y;
                if( yFlip ) {
                    j = 31 - y;
                }

                if( !forceReset && !changedCells[i][j] ) {
                    continue;
                }

                int bottom = clothingBuilder.getValue(i, j, 0);
                if( forceReset || bottom != 0 || (filledCells[i][j] && bottom == 0) ) {
                    // If we had a value here before or there is a value here
                    // now... or we are forcing a reset... then paint skin as a base.
                    //ImageSource shape = shapeSources.get(0);
                    ImageSource shape = shapeIndex.getShapeSource(0);
                    Fabric fabric = fabrics.get(0);
                    fabric.paint(clothingPainter, i * 32, j * 32, shape);

                    // This prevents us from constantly repainting skin
                    // in cells that have not changed.
                }
                filledCells[i][j] = bottom != 0;
                changedCells[i][j] = false;

                for( int k = 0; k < 32; k++ ) {
                    int value = clothingBuilder.getValue(i, j, k);
                    if( value == 0 ) {
                        // Nothing left to paint here
                        break;
                    }
                    //ImageSource shape = shapeSources.get(ClothingBuilder.toShape(value));
                    ImageSource shape = shapeIndex.getShapeSource(ClothingBuilder.toShape(value));
                    Fabric fabric = fabrics.get(ClothingBuilder.toFabric(value));
                    fabric.paint(clothingPainter, i * 32, j * 32, shape);
                }
            }
        }
        long end = System.nanoTime();
        log.info("repainted in " + ((end - start)/1000000.0) + " ms");
    }

    protected void clickCell( int xCell, int yCell, int x, int y, int buttonIndex ) {
        log.info("paintCell(" + xCell + ", " + yCell + ", " + buttonIndex + ")");
        if( xCell > 32 || yCell > 32 ) {
            return;
        }

        //clothingCellSelector.setSelectedCell(new Vec3i(xCell, yCell, 0));

        Vec3i shapeCell = shapeSelector.getSelectedCell();
        int xShape = 0;
        int yShape = 0;
        if( shapeCell != null ) {
            xShape = shapeCell.x;
            //yShape = 7 - shapeCell.y;
            yShape = shapeCell.y;
        }
        int index = yShape * 8 + xShape;
        log.info("index:" + index + "  cell:" + shapeCell);
        SwatchShape shape = shapeIndex.getBaseShape(index);

        // Calculate the variant by looking around at what the
        // immediate neighbors will be.
        //int dirMask = 0;
        //int layer = clothingBuilder.getLevel(xCell, yCell);
        //for( Direction dir : shape.getEdges() ) {
        //    int val = clothingBuilder.
        //}

        int dirMask = dirMaskEditor.getDirMask();
        log.info("dir mask:" + dirMask);

        // Constrain it to the possible directions for this shape
        int constraint = SwatchShape.dirsToMask(shape.getEdges());
        log.info("contraint:" + constraint);
        int variantMask = constraint & dirMask;
        log.info("variantMask:" + variantMask);

        Integer variant = shape.getVariantIndex(variantMask); //0);
        if( variant == null ) {
            log.info("No variant 0 found in:" + shape.getVariants());
            variant = 0;
        }

        if( buttonIndex == MouseInput.BUTTON_RIGHT ) {
            //clothingBuilder.addSwatch(xCell, yCell, variant, currentFabricIndex);
            history.addEdit(new AddSwatch(clothingBuilder, xCell, yCell, variant, currentFabricIndex + 1));
        } else if( buttonIndex == MouseInput.BUTTON_LEFT ) {
            //clothingBuilder.removeSwatch(xCell, yCell);
            history.addEdit(new RemoveSwatch(clothingBuilder, xCell, yCell));
        } else if( buttonIndex == MouseInput.BUTTON_MIDDLE ) {
            history.addEdit(new RemoveSwatch(clothingBuilder, xCell, yCell));
            history.addEdit(new AddSwatch(clothingBuilder, xCell, yCell, variant, currentFabricIndex + 1));
            //clothingBuilder.removeSwatch(xCell, yCell);
            //clothingBuilder.addSwatch(xCell, yCell, variant, currentFabricIndex);
        }
        changedCells[xCell][yCell] = true;
    }

    protected void resetRig( Rig rig ) {
        if( rig == null ) {
            return; // for now there will always be a rig
        }
        this.rig = rig;
        this.rigInfo = rig.getRigInfo();


//Float Glossiness : 1.0
//Float EmissivePower : 3.0
//Vector4 BaseColor : 1.0 1.0 1.0 1.0
//Float ParallaxHeight : 0.05
//Float Metallic : 0.0
//Boolean BackfaceShadows : false
//Float Roughness : 0.5
//Float NormalType : -1.0
//Vector4 Emissive : 0.0 0.0 0.0 1.0
//Float EmissiveIntensity : 2.0
//Vector4 Specular : 1.0 1.0 1.0 1.0

        // For whatever reason, the blender tangents don't work properly
        com.jme3.util.TangentBinormalGenerator.generate(rig.getView());

        geometryList.clear();

        AtomicBoolean newStyle = new AtomicBoolean();

        // Just set it blindly for now
        rig.getView().depthFirstTraversal(new SceneGraphVisitorAdapter() {
                public void visit( Geometry geom ) {
                    //log.info("Geometry:" + geom);
                    geometryList.add(geom);
                    if( true ) {
log.info("Material:" + geom.getMaterial());
                        if( "SkinAndClothes".equals(geom.getMaterial().getName()) ) {
                            newStyle.set(true);
                        }
                        if( geom.getMaterial().getParamsMap().containsKey("BaseColorMap") ) {

                            Texture existing = geom.getMaterial().getParamValue("BaseColorMap");
log.info("Existing base map:" + existing);
                            if( existing == null || "Grid-x.png".equals(existing.getName())
                                //|| "SkinAndClothes".equals(geom.getMaterial().getName())
                                || "BaseSkin.png".equals(existing.getName()) ) {
                                log.info("Setting up clothing texture.");

                                geom.getMaterial().setTexture("BaseColorMap", clothingPainter.getBaseTexture());
                                geom.getMaterial().setTexture("NormalMap", clothingPainter.getNormalTexture());
                                geom.getMaterial().setTexture("MetallicRoughnessMap", clothingPainter.getMetalRoughnessTexture());

                                // Let the texture 100% control it
                                geom.getMaterial().setFloat("Metallic", 1);
                                geom.getMaterial().setFloat("Roughness", 1);
                            } else {

                                log.info("Material values:");
                                for( Map.Entry e : geom.getMaterial().getParamsMap().entrySet() ) {
                                    log.info("    " + e);
                                }
                                //log.info("NormalMap:" + geom.getMaterial().getParamValue("NormalMap"));
                                //log.info("MetallicRoughnessMap:" + geom.getMaterial().getParamValue("MetallicRoughnessMap"));
                                //log.info("Metallic:" + geom.getMaterial().getParamValue("Metallic"));
                                //log.info("Roughness:" + geom.getMaterial().getParamValue("Roughness"));
                                //geom.getMaterial().setFloat("Metallic", 0);
                                //geom.getMaterial().setFloat("Roughness", 1);
                                //geom.getMaterial().clearParam("NormalMap");
                                //geom.getMaterial().clearParam("MetallicRoughnessMap");
                            }
                        } else if( geom.getMaterial().getParamsMap().containsKey("DiffuseMap") ) {
                            Texture existing = geom.getMaterial().getParamValue("DiffuseMap");
log.info("Existing diffuse map:" + existing);
                            if( existing == null || "Grid-x.png".equals(existing.getName())
                                || "SkinAndClothes".equals(geom.getMaterial().getName()) ) {
                                log.info("Setting up clothing texture.");

                                geom.getMaterial().setTexture("DiffuseMap", clothingPainter.getBaseTexture());
                                geom.getMaterial().setTexture("NormalMap", clothingPainter.getNormalTexture());
                                geom.getMaterial().setTexture("SpecularMap", clothingPainter.getSpecularTexture());

                                // Let the texture 100% control it
                                //geom.getMaterial().setFloat("Metallic", 1);
                                //geom.getMaterial().setFloat("Roughness", 1);
                            } else {

                                log.info("Material values:");
                                for( Map.Entry e : geom.getMaterial().getParamsMap().entrySet() ) {
                                    log.info("    " + e);
                                }
                                //log.info("NormalMap:" + geom.getMaterial().getParamValue("NormalMap"));
                                //log.info("MetallicRoughnessMap:" + geom.getMaterial().getParamValue("MetallicRoughnessMap"));
                                //log.info("Metallic:" + geom.getMaterial().getParamValue("Metallic"));
                                //log.info("Roughness:" + geom.getMaterial().getParamValue("Roughness"));
                                //geom.getMaterial().setFloat("Metallic", 0);
                                //geom.getMaterial().setFloat("Roughness", 1);
                                //geom.getMaterial().clearParam("NormalMap");
                                //geom.getMaterial().clearParam("MetallicRoughnessMap");
                            }
                        }
                    } else {
                        geom.getMaterial().setTexture("BaseColorMap", null);
                        geom.getMaterial().setColor("BaseColor", ColorRGBA.Blue);
                        geom.getMaterial().setFloat("Metallic", 0);
                        geom.getMaterial().setFloat("Roughness", 1);
                    }
                }
            });

        if( newStyle.get() ) {
            log.info("Setting clothing to 'flipped' mode.");
            //clothingPainter.setFlipY(true);
            yFlip = true;
        } else {
            yFlip = false;
        }

        // Fill the whole thing with the base fabric
        setFabric(0);
        repaint(true);

        setClothingEnabled(tabEnabled);
    }

    protected void tabChanged( Tab tab ) {
        tabEnabled = (window == tab.getContents());
        if( rig != null ) {
            setClothingEnabled(tabEnabled);
        }
        getState(ColliderViewState.class).setCollidersEnabled(!tabEnabled);
    }

    protected void setClothingEnabled( boolean clothingEnabled ) {
        if( this.clothingEnabled == clothingEnabled ) {
            return;
        }
        this.clothingEnabled = clothingEnabled;
        if( clothingEnabled ) {
            CursorEventControl.addListenersToSpatial(rig.getView(), paintListener);
            originalAction = rig.getCurrentAction();
            if( rig.getClipNames().contains("default pose") ) {
                rig.setCurrentAction("default pose");
            }
        } else {
            CursorEventControl.removeListenersFromSpatial(rig.getView(), paintListener);
            if( originalAction != null ) {
                rig.setCurrentAction(originalAction);
            }
        }
    }

    private class PaintListener extends DefaultCursorListener {

        private CollisionResult collision = null;

        protected void click( CursorButtonEvent event, Spatial target, Spatial capture ) {
            log.info("event:" + event);

            if( collision == null ) {
                return;
            }
            // But where did we click on the texture?  Tricksy hobbitses.
            int ti = collision.getTriangleIndex();
            Mesh mesh = collision.getGeometry().getMesh();
            Vector3f cp = collision.getGeometry().worldToLocal(collision.getContactPoint(), null);

            Vector2f bary = MeshUtils.getBarycentricCoord(mesh, ti, cp);
            Vector2f uv = MeshUtils.getTextureCoordinate(mesh, ti, bary);

            int x = (int)Math.round(clothingPainter.getWidth() * uv.x);
            int y = (int)Math.round(clothingPainter.getHeight() * uv.y);

            log.info("texture coord:" + uv + "   xy:" + x + ", " + y);

            int xCell = x / 32;
            int yCell = y / 32;

            log.info("cell:" + xCell + ", " + yCell);

            clickCell(xCell, yCell, x, y, event.getButtonIndex());
        }

        //public void cursorButtonEvent( CursorButtonEvent event, Spatial target, Spatial capture ) {
            //log.info("button event:" + event.isPressed() + "  collsion:" + event.getCollision());
        //}

        public void cursorExited( CursorMotionEvent event, Spatial target, Spatial capture ) {
            collision = null;
        }

        public void cursorMoved( CursorMotionEvent event, Spatial target, Spatial capture ) {
            //log.info("mouse event collsion:" + event.getCollision());
            collision = event.getCollision();
        }
    }
}
