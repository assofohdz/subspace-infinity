/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.function.Consumer;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.scene.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.style.ElementId;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PickState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PickState.class);

    private Node worldRoot;
    private Node pickRoot = new Node("pickRoot");
    private CursorObserver cursorObserver = new CursorObserver();

    private Container prompt;
    private Label message;

    private PickCallback<?> currentCallback;

    public PickState() {
        setEnabled(false);
    }

    public <T> void pick( String prompt, PickIndicator<T> indicator, Consumer<T> callback ) {
        cancelCurrent();
        message.setText(prompt);
        this.currentCallback = new PickCallback<T>(indicator, callback);
        setEnabled(true);
    }

    protected Node getGuiRoot() {
        return ((SimpleApplication)getApplication()).getGuiNode();
    }

    @Override
    protected void initialize( Application app ) {
        this.worldRoot = getState(WorldViewState.class).getWorldRoot();

        //this.prompt = new Container(new ElementId("window"));
        this.prompt = new Container();
        this.message = prompt.addChild(new Label("message", new ElementId("title.label")));
        message.setInsets(new Insets3f(5, 5, 5, 5));
        prompt.addChild(new ActionButton(new CallMethodAction("Cancel", this, "cancelCurrent")));
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        CursorEventControl.addListenersToSpatial(worldRoot, cursorObserver);
        worldRoot.attachChild(pickRoot);

        float w = getApplication().getCamera().getWidth();
        Vector3f pref = prompt.getPreferredSize();
        Vector3f pos = new Vector3f(w * 0.5f, pref.y + 5, 0);
        pos.x -= pref.x * 0.5f;
        prompt.setLocalTranslation(pos);
        getGuiRoot().attachChild(prompt);
    }

    @Override
    protected void onDisable() {
        prompt.removeFromParent();
        cancelCurrent();
        CursorEventControl.removeListenersFromSpatial(worldRoot, cursorObserver);
        pickRoot.removeFromParent();
    }

    protected void cancelCurrent() {
        if( currentCallback != null ) {
            currentCallback.cancel();
        }
        this.currentCallback = null;
        setEnabled(false);
    }

    protected class PickCallback<T> {
        private PickIndicator<T> indicator;
        private Consumer<T> callback;
        private T lastPick;
        private boolean executed;

        public PickCallback( PickIndicator<T> indicator, Consumer<T> callback ) {
            this.indicator = indicator;
            this.callback = callback;
        }

        public void place( CursorMotionEvent event ) {
            this.lastPick = indicator.place(pickRoot, event);
        }

        public void execute() {
            if( lastPick != null ) {
                callback.accept(lastPick);
                executed = true;
                setEnabled(false);
            }
        }

        public void cancel() {
            indicator.release();
            if( !executed ) {
                callback.accept(null);
            }
        }
    }

    protected class CursorObserver implements CursorListener {
        @Override
        public void cursorButtonEvent( CursorButtonEvent event, Spatial target, Spatial capture ) {
            if( !event.isPressed() ) {
                if( event.getButtonIndex() == 0 ) {
                    if( currentCallback != null ) {
                        currentCallback.execute();
                    }
                } else {
                    cancelCurrent();
                }
            }
        }

        @Override
        public void cursorEntered( CursorMotionEvent event, Spatial target, Spatial capture ) {
        }

        @Override
        public void cursorExited( CursorMotionEvent event, Spatial target, Spatial capture ) {
        }

        @Override
        public void cursorMoved( CursorMotionEvent event, Spatial target, Spatial capture ) {
            if( currentCallback != null ) {
                currentCallback.place(event);
            }
        }
    }
}


