/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;

/**
 *  UI element that lets the user manage the list of attachments
 *  for a rig.
 *
 *  @author    Paul Speed
 */
public class AttachmentManager extends Container {
    static Logger log = LoggerFactory.getLogger(AttachmentManager.class);
    
    private Rig rig;
    private RigInfo rigInfo;
    private VersionedList<String> jointNames = new VersionedList<>();
    private VersionedReference<AttachmentInfo> selectedAttachmentRef;

    private ListBox<AttachmentInfo> attachmentList;
    private VersionedReference<Integer> listSelectionRef;

    private Container editorHolder;   
    private AttachmentEditor attachmentEditor;
    private VersionedReference<AttachmentInfo> attRef;
    
    public AttachmentManager() {
        attachmentList = addChild(new ListBox<AttachmentInfo>());
        listSelectionRef = attachmentList.getSelectionModel().createSelectionReference();
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("New", this, "addAttachment")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeAttachment")));

        editorHolder = addChild(new Container());
        editorHolder.setBackground(null);
        attachmentEditor = new AttachmentEditor(jointNames);        
    }

    public void setRig( Rig rig ) {
        if( this.rig == rig ) {
            return;
        }
        this.rig = rig;
        if( rig == null ) {
            rigInfo = null;
            jointNames.clear();
            selectedAttachmentRef = null;
            attachmentList.setModel(new VersionedList<AttachmentInfo>());
            attachmentEditor.setAttachment(null);
        } else {
            rigInfo = rig.getRigInfo();
            
            attachmentList.setModel(rigInfo.getAttachments());
            
            jointNames.clear();
            jointNames.addAll(rig.getJointNames());
             
            selectedAttachmentRef = rig.createSelectedAttachmentReference();
        }
    }
    
    public Rig getRig() {
        return rig;
    }
    
    protected void addAttachment() {
        int index = rigInfo.getAttachments().size(); 
        AttachmentInfo item = new AttachmentInfo("att_" + index);
        rigInfo.getAttachments().add(item);
        
        attachmentList.getSelectionModel().setSelection(index);
    }
    
    protected void removeAttachment() {
        rigInfo.getAttachments().remove(attachmentList.getSelectedItem());
    }
 
    protected void selectAttachment() {
        AttachmentInfo item = attachmentList.getSelectedItem();
        rig.setSelectedAttachment(item);
        attRef = item == null ? null : item.createReference(); 
    }
 
    protected void editAttachment() {        
        AttachmentInfo item = selectedAttachmentRef.get();
        log.info("editAttachment():" + item);
        int index = rigInfo.getAttachments().indexOf(item);
        Integer selection = attachmentList.getSelectionModel().getSelection();
        selection = selection == null ? -1 : selection;
        if( selection != index ) {
            attachmentList.getSelectionModel().setSelection(index);   
        }
        attachmentEditor.setAttachment(item);
        if( item == null ) {
            attachmentEditor.removeFromParent();
        } else {
            editorHolder.addChild(attachmentEditor);
        }
    }
    
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        if( listSelectionRef.update() ) {
            selectAttachment();
        }
        if( selectedAttachmentRef != null && selectedAttachmentRef.update() ) {
            editAttachment();
        }
        if( attRef != null && attRef.update() ) {
            log.info("refresh list");
            // Cheating a bit because we know this will refresh the list
            // view... and by the time it won't maybe there will be an API
            // for it.
            GridPanel grid = attachmentList.getGridPanel();
            grid.setVisibleRows(grid.getVisibleRows());            
        }
    }
}
