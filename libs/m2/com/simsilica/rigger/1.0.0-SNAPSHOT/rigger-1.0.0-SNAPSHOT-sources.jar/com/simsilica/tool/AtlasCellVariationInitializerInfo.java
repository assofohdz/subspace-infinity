/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.lemur.core.VersionedList;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;

import com.simsilica.crig.jme.AtlasCellVariationInitializer;
import com.simsilica.crig.jme.RigTypeInitializer;

/**
 *
 *
 *  @author    Paul Speed
 */
public class AtlasCellVariationInitializerInfo implements RigTypeInitializerInfo<AtlasCellVariationInitializerInfo> {

    static Logger log = LoggerFactory.getLogger(AtlasCellVariationInitializerInfo.class);

    private String variantName;
    private String materialName;
    private String materialParameter;
    private int atlasWidth;
    private int atlasHeight;
    private transient long version;

    public AtlasCellVariationInitializerInfo() {
    }

    public RigTypeInitializer convert() {
        return new AtlasCellVariationInitializer(variantName, materialName, materialParameter, atlasWidth, atlasHeight);
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public AtlasCellVariationInitializerInfo getObject() {
        return this;
    }

    @Override
    public VersionedReference<AtlasCellVariationInitializerInfo> createReference() {
        return new VersionedReference<>(this);
    }

    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("variantName", variantName)
            .add("materialName", materialName)
            .add("materialParameter", materialParameter)
            .add("atlasWidth", atlasWidth)
            .add("atlasHeight", atlasHeight)
            .toString();
    }
}


