/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.*;
import com.simsilica.mathd.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MovementAnimationTable extends Container {
    static Logger log = LoggerFactory.getLogger(MovementAnimationTable.class);
 
    private VersionedList<MovementAnimation> animation;
    private List<Row> rows = new ArrayList<>();
 
    // Need add, remove, and resort
 
    private VersionedList<String> clipNames;   
    
    public MovementAnimationTable() {
    }

    public void setClipNames( VersionedList<String> clipNames ) {
        this.clipNames = clipNames;
        for( Row row : rows ) {
            row.clip.setModel(clipNames);
        }
    }
    
    public void setList( VersionedList<MovementAnimation> animation ) {
        if( this.animation == animation ) {
            return;
        }
        this.animation = animation;
        updateComponents();
    }
 
    public VersionedList<MovementAnimation> getList() {
        return animation;
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        for( Row row : rows ) {
            row.update(tpf);
        }
    }
 
    protected void updateComponents() {
        clearChildren();
        
        addChild(new Label("Animation:"));
        addChild(new Label("Velocity:"), 1);
        addChild(new Label("Scale:"), 2);
 
        if( animation == null ) {
            return;
        }
                
        for( MovementAnimation anim : animation ) {
            Row row = new Row(anim);
            rows.add(row);
            
            addChild(row.clip);
            addChild(row.velocity, 1);
            addChild(row.scale, 2);
        }
    }   
    
    private class Row {
        private MovementAnimation animation;
    
        private Selector<String> clip;
        private VersionedReference<String> clipRef;        
        private Vec3dEditor velocity;
        private VersionedReference<Vec3d> velocityRef;
        private Spinner<Double> scale;
        private VersionedReference<Double> scaleRef;
        
        public Row( MovementAnimation animation ) {
            this.animation = animation;
            
            clip = new Selector<String>(clipNames);
            clip.setSelectedItem(animation.getAnimation());
            clipRef = clip.createSelectedItemReference();
            
            velocity = new Vec3dEditor(Axis.X, -10, 10, 0.1, 0.01);
            velocity.setObject(animation.getBaseVelocity());
            velocityRef = velocity.createReference();
            
            SequenceModel<Double> model 
                = SequenceModels.rangedSequence(
                        new DefaultRangedValueModel(0, 10, 0), 
                        0.1, 0.01);
            
            DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
            
            scale = new Spinner<>(model, renderer);
            scale.setValueEditor(ValueEditors.doubleEditor("%.2f"));   
            scale.setValue(animation.getScale());
            scaleRef = scale.getModel().createReference(); 
        }
        
        public void update( float tpf ) {
            if( clipRef.update() ) {
                animation.setAnimation(clipRef.get());
            }
            if( velocityRef.update() ) {
                animation.setBaseVelocity(velocityRef.get());
            }
            if( scaleRef.update() ) {
                animation.setScale(scaleRef.get());
            }
        }
    }
}
