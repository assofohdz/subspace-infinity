/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.input.event.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.Texture.MagFilter;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.style.*;
import com.simsilica.mathd.*;

/**
 *  Given an image of cells, this allows interaction with the cells
 *  as well as cell selection.  This will be used for shape selection
 *  and possibly also raw array editing.
 *
 *  @author    Paul Speed
 */
public class CellSelector extends Container {
    static Logger log = LoggerFactory.getLogger(CellSelector.class);
 
    private static final ColorRGBA TRANSPARENT = new ColorRGBA(0, 0, 0, 1);
 
    private Texture background;   
    private int width;
    private int height;
    private int cellSize;
    private Vec3i[][] cells;
    private ArrayGridModel<Vec3i> cellGridModel;
    private CellAdapter cellPanels;
    private GridPanel grid;

    private VersionedHolder<Vec3i> selectedType = new VersionedHolder<>(new Vec3i(0, 0, 0));
    private VersionedReference<Vec3i> selectionRef = selectedType.createReference();
    private Vec3i lastCell = null;
    
    public CellSelector( Texture background, int width, int height, int cellSize ) {
        super(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.None));
        this.background = background;
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;
 
        cells = new Vec3i[height][width];
        for( int i = 0; i < width; i++ ) {
            for( int j = 0; j < height; j++ ) {
                cells[j][i] = new Vec3i(i, j, 0);
            }
        } 
        cellGridModel = new ArrayGridModel<>(cells);
        cellPanels = new CellAdapter(cellGridModel);
        grid = addChild(new GridPanel(cellPanels));
        grid.setVisibleSize(width, height);
        
        grid.setBackground(new QuadBackgroundComponent(background));
        
        resetSelection();
    }
        
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( selectionRef.update() ) {
            resetSelection();
        }
    }
    
    public void setSelectedCell( Vec3i cell ) {
        selectedType.setObject(cell);
    }
    
    public Vec3i getSelectedCell() {
        return selectedType.getObject();
    }
    
    private void resetSelection() {
        if( lastCell != null ) {
            Panel p = cellPanels.getPanel(lastCell);
            ((TbtQuadBackgroundComponent)p.getBackground()).setColor(TRANSPARENT);    
        }
        this.lastCell = selectionRef.get();
        if( lastCell != null ) {
            Panel p = cellPanels.getPanel(lastCell);
            ((TbtQuadBackgroundComponent)p.getBackground()).setColor(ColorRGBA.White);    
        }        
    }

    private class PaletteListener extends DefaultMouseListener {
    
        private Vec3i cell;
        
        public PaletteListener( Vec3i cell ) {
            this.cell = cell;
        }
    
        protected void click( MouseButtonEvent event, Spatial target, Spatial capture ) {
            setSelectedCell(cell);
        }        
    }
    
    private class CellAdapter extends GridModelWrapper<Vec3i, Panel> {
 
        private Panel[][] panels;
 
        public CellAdapter( ArrayGridModel<Vec3i> delegate ) {
            super(delegate);
 
            this.panels = new Panel[height][width];
            
            // Pre-create our panels
            for( int i = 0; i < width; i++ ) {
                for( int j = 0; j < height; j++ ) {
                    Panel p = panels[j][i] = new Panel();
                
                    p.setPreferredSize(new Vector3f(cellSize, cellSize, 1));
                    p.setInsets(new Insets3f(0, 0, 0, 0));
                
                    // We have to have a background if we want clicks.  It has to be 
                    // transparent if we want to show the underlying palette image
                    Texture border = GuiGlobals.getInstance().loadTexture("com/simsilica/lemur/icons/border.png", false, false);
                    TbtQuadBackgroundComponent bg = TbtQuadBackgroundComponent.create(border, 1, 2, 2, 6, 6, 0, false);  
                    //QuadBackgroundComponent bg = new QuadBackgroundComponent(border); 
                
                    // We'll use a textured quad that is transparent so that we can
                    // turn on the texture for selection.
                    bg.setColor(TRANSPARENT);
                    p.setBackground(bg);

                    MouseEventControl.addListenersToSpatial(p, new PaletteListener(new Vec3i(i, j, 0)));
                }
            }
        }
        
        public Panel getPanel( Vec3i cell ) {
            return panels[cell.y][cell.x];
        }
        
        @Override
        public Panel getCell( int row, int col, Panel existing ) {        
            if( existing != null ) {
                return existing;
            }
            Vec3i cell = getDelegate().getCell(row, col, null);
            if( cell == null ) {
                return null;
            }
            
            return panels[row][col];
        } 

        @Override
        public void setCell( int row, int col, Panel value ) {
        }         
    } 
    
}

/**



public class ToolPanelState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ToolPanelState.class);

    private static final ColorRGBA TRANSPARENT = new ColorRGBA(0, 0, 0, 0);

    private Container toolPanel;

    private int typeRows = 10;
    private int typeColumns = 8;
    private Integer[][] blockTypes = new Integer[typeRows][typeColumns];
    private ArrayGridModel<Integer> typesGrid = new ArrayGridModel<>(blockTypes);
    private BlockTypeAdapter blockPanels; 
    private GridPanel typeGrid;

    //private MiniBlockTool miniBlockTool;

    private VersionedHolder<Integer> selectedType = new VersionedHolder<>(1);
    private VersionedReference<Integer> selectionRef = selectedType.createReference();
    private int lastColor = 0;
    private QuadBackgroundComponent selector;
    private QuadBackgroundComponent toolSelector;

    private ColorRGBA toolSelectedColor = new ColorRGBA(0.5f, 0.9f, 0.9f, 0.75f);  
    private ColorRGBA toolUnselectedColor = new ColorRGBA(0.4f, 0.6f, 0.6f, 0.4f); 
    private Tool currentTool;
    private Tool[] tools;
    private ActionButton[] toolButtons;
    private int toolIndex = 0;

    public ToolPanelState() {
    
        // Preload the palette of block types
        for( int i = 0; i < typeRows; i++ ) {
            for( int j = 0; j < typeColumns; j++ ) {
                blockTypes[i][j] = 1 + i * typeColumns + j;
            }
        }
    }
 
    protected void selectMiniTool() {
        toolIndex = 0;
        refreshTool();
    }
    
    protected void select2x2Tool() {
        toolIndex = 1;
        refreshTool();
    }
    
    protected void select4x4Tool() {
        toolIndex = 2;
        refreshTool();
    }    
 
    protected void setBlockType( int type ) {
        for( Tool tool : tools ) {
            tool.setBlockType(type);
        }
        selectedType.setObject(type);
    }
    
    protected Node getGuiNode() {
        return ((Main)getApplication()).getGuiNode();
    }
    
    @Override
    protected void initialize( Application app ) {
 
        //this.miniBlockTool = new MiniBlockTool();
    
        toolPanel = new Container();
        RollupPanel rollup = toolPanel.addChild(new RollupPanel("Palette", null));
         
        blockPanels = new BlockTypeAdapter(typesGrid);        
        typeGrid = new GridPanel(blockPanels);
        typeGrid.setVisibleSize(typeRows, typeColumns);
        rollup.setContents(typeGrid); 
 
        GuiGlobals globals = GuiGlobals.getInstance();    
        Texture palette = globals.loadTexture("Textures/palette1-plus.png", false, false);
        palette.setMagFilter(MagFilter.Nearest);
        QuadBackgroundComponent bg = new QuadBackgroundComponent(palette);
        typeGrid.setBackground(bg);
        
        //getState(CursorState.class).setTool(miniBlockTool);
 
        Container toolTypes = new Container();
        toolPanel.addChild(new RollupPanel("Tools", toolTypes, null));
 
        toolButtons = new ActionButton[] {
            new ActionButton(new CallMethodAction("", this, "selectMiniTool")),
            new ActionButton(new CallMethodAction("", this, "select2x2Tool")),
            new ActionButton(new CallMethodAction("", this, "select4x4Tool"))
        };
 
 
        float iconScale = 0.5f;
        toolButtons[0].setIcon(new IconComponent("Textures/mini-block-icon.png", iconScale, 0, 0, 0.01f, false));
        toolButtons[1].setIcon(new IconComponent("Textures/2x2-block-icon.png", iconScale, 0, 0, 0.01f, false));
        toolButtons[2].setIcon(new IconComponent("Textures/4x4-block-icon.png", iconScale, 0, 0, 0.01f, false));
 
        toolTypes.addChild(toolButtons[0]);
        toolTypes.addChild(toolButtons[1], 1);        
        toolTypes.addChild(toolButtons[2], 2);        
 
        tools = new Tool[] {
            new MiniBlockTool(),
            new MultiBlockTool(2, 2, 2),
            new MultiBlockTool(4, 4, 4)
        };
 
        refreshTool();
    }
 
    protected void refreshTool() {
        for( int i = 0; i < toolButtons.length; i++ ) {
            ActionButton b = toolButtons[i];
            if( i == toolIndex ) {
                ((ColoredComponent)b.getBackground()).setColor(toolSelectedColor);
            } else {
                ((ColoredComponent)b.getBackground()).setColor(toolUnselectedColor);    
            }
        }            
        currentTool = tools[toolIndex];
        //toolButtons[toolIndex].setBorder(toolSelector);
        getState(CursorState.class).setTool(currentTool);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getGuiNode().attachChild(toolPanel);
        
        Vector3f pref = toolPanel.getPreferredSize();
        
        toolPanel.setLocalTranslation(getApplication().getCamera().getWidth() - pref.x - 16, 
                                      getApplication().getCamera().getHeight() - 16,
                                      0);
                                      
        //setBlockType(65);                                      
    }
    
    @Override
    public void update( float tpf ) {
        if( selectionRef.update() ) {
            resetSelection();
        }
    }
    
    @Override
    protected void onDisable() {
        toolPanel.removeFromParent();
    }
 
    private void resetSelection() {
        if( lastColor != 0 ) {
            Panel p = blockPanels.getPanel(lastColor);
            ((QuadBackgroundComponent)p.getBackground()).setColor(TRANSPARENT);    
        }
        this.lastColor = selectionRef.get();
        if( lastColor != 0 ) {
            Panel p = blockPanels.getPanel(lastColor);
            ((QuadBackgroundComponent)p.getBackground()).setColor(ColorRGBA.White);    
        }        
    }
    
    private class PaletteListener extends DefaultMouseListener {
    
        private int blockType;
        
        public PaletteListener( int blockType ) {
            this.blockType = blockType;
        }
    
        protected void click( MouseButtonEvent event, Spatial target, Spatial capture ) {
            setBlockType(blockType);
        }        
    }
    
    private class BlockTypeAdapter extends GridModelWrapper<Integer, Panel> {
 
        private Panel[] panels = new Panel[typeRows * typeColumns];
 
        public BlockTypeAdapter( ArrayGridModel<Integer> delegate ) {
            super(delegate);
            
            // Pre-create our panels
            for( int i = 0; i < panels.length; i++ ) {
                panels[i] = new Panel();

                panels[i].setPreferredSize(new Vector3f(16, 16, 1));
                panels[i].setInsets(new Insets3f(0, 0, 1, 1));

                // We have to have a background if we want clicks.  It has to be 
                // transparent if we want to show the underlying palette image
                Texture border = GuiGlobals.getInstance().loadTexture("com/simsilica/lemur/icons/border.png", false, false);            
                QuadBackgroundComponent bg = new QuadBackgroundComponent(border); 
                
                // We'll use a textured quad that is transparent so that we can
                // turn on the texture for selection.
                bg.setColor(TRANSPARENT);
                panels[i].setBackground(bg);

                MouseEventControl.addListenersToSpatial(panels[i], new PaletteListener(i + 1));
            }
        }
        
        public Panel getPanel( int type ) {
            return panels[type-1];
        }
        
        @Override
        public Panel getCell( int row, int col, Panel existing ) {        
            if( existing != null ) {
                return existing;
            }
            Integer type = getDelegate().getCell(row, col, null);
            if( type == null ) {
                return null;
            }
            
            return panels[type-1];
        } 

        @Override
        public void setCell( int row, int col, Panel value ) {
        }         
    } 
}
*/
