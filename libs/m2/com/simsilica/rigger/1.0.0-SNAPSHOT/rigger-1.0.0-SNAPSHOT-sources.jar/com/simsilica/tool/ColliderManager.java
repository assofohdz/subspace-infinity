/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.google.common.collect.Iterables;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;

/**
 *  UI element that lets the user manage the list of colliders
 *  for a rig.
 *
 *  @author    Paul Speed
 */
public class ColliderManager extends Container {
    static Logger log = LoggerFactory.getLogger(ColliderManager.class);
    
    private Rig rig;
    private RigInfo rigInfo;
    private VersionedReference<ColliderInfo> selectedColliderRef;

    private ListBox<ColliderInfo> colliderList;
    private VersionedReference<Integer> listSelectionRef;

    private Container editorHolder;   
    private ColliderEditor colliderEditor;
    private VersionedReference<ColliderInfo> attRef;
    
    public ColliderManager() {
        colliderList = addChild(new ListBox<ColliderInfo>());
        listSelectionRef = colliderList.getSelectionModel().createSelectionReference();
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("New", this, "addCollider")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeCollider")));

        editorHolder = addChild(new Container());
        editorHolder.setBackground(null);
        colliderEditor = new ColliderEditor();        
    }

    public void setRig( Rig rig ) {
        if( this.rig == rig ) {
            return;
        }
        this.rig = rig;
        if( rig == null ) {
            rigInfo = null;
            selectedColliderRef = null;
            colliderList.setModel(new VersionedList<ColliderInfo>());
            colliderEditor.setCollider(null);
        } else {
            rigInfo = rig.getRigInfo();
            
            colliderList.setModel(rigInfo.getColliders());
 
            colliderEditor.setJointNames(rig.getJointNames());
            colliderEditor.setShapeNames(rig.getColliders().getShapeNames());           
             
            selectedColliderRef = rig.createSelectedColliderReference();
        }
    }
    
    public Rig getRig() {
        return rig;
    }
    
    protected void addCollider() {
        int index = rigInfo.getColliders().size(); 
        ColliderInfo item = new ColliderInfo();
        item.setShape("sphere");
        item.setJoint(Iterables.getFirst(rig.getJointNames(), null));
        rigInfo.getColliders().add(item);
        
        colliderList.getSelectionModel().setSelection(index);
    }
    
    protected void removeCollider() {
        rigInfo.getColliders().remove(colliderList.getSelectedItem());
    }
 
    protected void selectCollider() {
        ColliderInfo item = colliderList.getSelectedItem();
        rig.setSelectedCollider(item);
        attRef = item == null ? null : item.createReference(); 
    }
 
    protected void editCollider() {        
        ColliderInfo item = selectedColliderRef.get();
        log.info("editCollider():" + item);
        int index = rigInfo.getColliders().indexOf(item);
        Integer selection = colliderList.getSelectionModel().getSelection();
        selection = selection == null ? -1 : selection;
        if( selection != index ) {
            colliderList.getSelectionModel().setSelection(index);   
        }
        colliderEditor.setCollider(item);
        if( item == null ) {
            colliderEditor.removeFromParent();
        } else {
            editorHolder.addChild(colliderEditor);
        }
    }
    
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        if( listSelectionRef.update() ) {
            selectCollider();
        }
        if( selectedColliderRef != null && selectedColliderRef.update() ) {
            editCollider();
        }
        if( attRef != null && attRef.update() ) {
            log.info("refresh list");
            // Cheating a bit because we know this will refresh the list
            // view... and by the time it won't maybe there will be an API
            // for it.
            GridPanel grid = colliderList.getGridPanel();
            grid.setVisibleRows(grid.getVisibleRows());            
        }
    }
}
