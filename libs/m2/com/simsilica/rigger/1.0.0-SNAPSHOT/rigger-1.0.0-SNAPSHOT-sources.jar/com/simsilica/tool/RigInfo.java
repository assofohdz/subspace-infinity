/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import com.google.common.io.Files;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedList;

/**
 *  Represents the config data associated with a model's rig.
 *
 *  @author    Paul Speed
 */
public class RigInfo {
    static Logger log = LoggerFactory.getLogger(RigInfo.class);

    private SourceModelInfo sourceModel;
    private TargetModelInfo targetModel;
    private VersionedList<AttachmentInfo> attachments = new VersionedList<>();
    private VersionedList<ColliderInfo> colliders = new VersionedList<>();
    private VersionedList<OverlayInfo> overlays = new VersionedList<>();
    private VersionedList<BlendConfig> blends = new VersionedList<>();
    private VersionedList<RigTypeInitializerInfo> initializers = new VersionedList<>();

    private VersionedList<MovementMode> movementModes;

    private ProbeInfo probe;

    public RigInfo() {
    }

    public void upgrade() {
        if( targetModel == null ) {
            String base = Files.getNameWithoutExtension(sourceModel.getModel());
            targetModel = new TargetModelInfo(base + ".rig", "Models");
        }
        if( blends == null ) {
            blends = new VersionedList<>();
        }
        if( initializers == null ) {
            initializers = new VersionedList<>();
        }
        if( probe == null ) {
            probe = new ProbeInfo();
        }
    }

    public void setSourceModel( SourceModelInfo sourceModel ) {
        log.info("setSourceModel(" + sourceModel + ")");
        this.sourceModel = sourceModel;
    }

    public SourceModelInfo getSourceModel() {
        return sourceModel;
    }

    public TargetModelInfo getTargetModel() {
        return targetModel;
    }

    public VersionedList<AttachmentInfo> getAttachments() {
        return attachments;
    }

    public VersionedList<ColliderInfo> getColliders() {
        return colliders;
    }

    public VersionedList<OverlayInfo> getOverlays() {
        return overlays;
    }

    public VersionedList<BlendConfig> getBlends() {
        return blends;
    }

    public VersionedList<RigTypeInitializerInfo> getInitializers() {
        return initializers;
    }

    public VersionedList<MovementMode> getMovementModes() {
        if( movementModes == null ) {
            movementModes = new VersionedList<>();
            movementModes.add(MovementMode.createDefault("Walk", "Idle", "Walk"));
        }
        return movementModes;
    }

    public ProbeInfo getProbe() {
        return probe;
    }
}
