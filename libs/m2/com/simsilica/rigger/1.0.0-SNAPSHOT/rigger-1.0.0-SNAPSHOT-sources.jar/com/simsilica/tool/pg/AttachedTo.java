/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import org.slf4j.*;

import com.google.common.base.*;

import com.simsilica.es.*;
import com.simsilica.mathd.*;

/**
 *  An object that is attached to another object.
 *
 *  @author    Paul Speed
 */
public class AttachedTo implements EntityComponent {
    static Logger log = LoggerFactory.getLogger(AttachedTo.class);

    private EntityId parent;
    private String attachPoint;
    private Vec3d offset;
    private Quatd rotation;

    public AttachedTo( EntityId parent, String attachPoint, Vec3d offset, Quatd rotation ) {
        this.parent = parent;
        this.attachPoint = attachPoint;
        this.offset = offset;
        this.rotation = rotation;
    }

    public AttachedTo( EntityId parent, Vec3d offset ) {
        this(parent, null, offset, null);
    }

    public static ComponentFilter<AttachedTo> parentFilter( EntityId parent ) {
        return Filters.fieldEquals(AttachedTo.class, "parent", parent);
    }

    public EntityId getParent() {
        return parent;
    }

    public String getAttachPoint() {
        return attachPoint;
    }

    public Vec3d getOffset() {
        return offset;
    }

    public Quatd getRotation() {
        return rotation;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("parent", parent)
            .add("attachPoint", attachPoint)
            .add("offset", offset)
            .add("rotation", rotation)
            .toString();
    }
}
