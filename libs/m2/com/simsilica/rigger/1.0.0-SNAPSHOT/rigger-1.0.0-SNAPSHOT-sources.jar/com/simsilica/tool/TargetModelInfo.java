/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedList;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TargetModelInfo implements VersionedObject<TargetModelInfo> {
    static Logger log = LoggerFactory.getLogger(TargetModelInfo.class);
 
    private transient long version;
    
    private String model;
    private String rig;
    private String targetRoot;
    
    private VersionedList<String> scripts = new VersionedList<>();
    private VersionedList<String> cleanupScripts = new VersionedList<>();
    
    public TargetModelInfo() {
    }
    
    public TargetModelInfo( String model, String targetRoot ) {
        this.model = model;
        this.targetRoot = targetRoot;
    }
 
    @Override
    public TargetModelInfo getObject() {
        return this;
    }
 
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public VersionedReference<TargetModelInfo> createReference() {
        return new VersionedReference<>(this);
    }
    
    public void setModel( String model ) {
        this.model = model;
        version++;
    }
    
    public String getModel() {
        return model;
    }

    //public void setRig( String rig ) {
    //    this.rig = rig;
    //    version++;
    //}
    //
    //public String getRig() {
    //    return rig;
    //}
    
    public void setTargetRoot( String targetRoot ) {
        this.targetRoot = targetRoot;
        version++;
    }
    
    public String getTargetRoot() {
        return targetRoot;
    }
    
    public void setScripts( List<String> scripts ) {
        if( this.scripts == scripts ) {
            return;
        }
        this.scripts.clear();
        this.scripts.addAll(scripts);
    }
    
    public VersionedList<String> getScripts() {
        return scripts;
    }

    public void setCleanupScripts( List<String> cleanupScripts ) {
        if( this.cleanupScripts == cleanupScripts ) {
            return;
        }
        this.cleanupScripts.clear();
        this.cleanupScripts.addAll(cleanupScripts);
    }
    
    public VersionedList<String> getCleanupScripts() {
        return cleanupScripts;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + model + "]";
    }    
}
