/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.Vector3f;
import com.jme3.export.binary.BinaryExporter;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.SpringGridLayout;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.tool.io.*;

import com.simsilica.crig.RigProtocol;
import com.simsilica.crig.RigType;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FileMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FileMenuState.class);

    private Container fileMenu;

    private String fileName;
    private int lastSavedCount;

    private Container fileSaveDialog;
    private TextField fileEntry;

    private Container fileLoadDialog;
    private ListBox<String> files;

    private File rootDir = RiggerConfig.getInstance().getProjectDir();

    // Used when we've saved during the "Exit" workflow and should then just leave.
    private boolean exitOnSave;

    public FileMenuState() {
        if( !rootDir.exists() ) {
            rootDir.mkdirs();
        }
    }

    public Container getMenu() {
        return fileMenu;
    }

    protected File toFile( String f ) {
        if( f == null ) {
            return null;
        }
        if( !f.toLowerCase().endsWith(".rig") ) {
            f += ".rig";
        }
        File file = new File(rootDir, f);
        return file;
    }

    protected String stripExtension( String f ) {
        if( f == null ) {
            return null;
        }
        if( !f.toLowerCase().endsWith(".rig") ) {
            f = f.substring(0, f.length() - 4);
        }
        return f;
    }

    //public void newFile() {
    //    System.out.println("newFile()");
    //
    //    if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
    //        getState(OptionPanelState.class).show("Clear Rig?",
    //                                            "Really clear current rig?",
    //                                            new CallMethodAction("Yes", this, "clear"),
    //                                            new EmptyAction("No"),
    //                                            new EmptyAction("Cancel"));
    //    } else {
    //        // nothing to do but we'll clear anyway
    //        clear();
    //    }
    //}
    //
    //protected void clear() {
    //    System.out.println("clear()");
    //    lastSavedCount = 0;
    //    fileName = null;
    //}

    public void open() {
        System.out.println("open()");
        //if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
        //    getState(OptionPanelState.class).show("Abandon Changes?",
        //                                        "Really abandon current changes?",
        //                                        new CallMethodAction("Yes", this, "selectFile"),
        //                                        new EmptyAction("No"),
        //                                        new EmptyAction("Cancel"));
        //} else {
            selectFile();
        //}
    }

    public void save() {
        System.out.println("save()");
        if( fileName == null ) {
            saveAs();
        } else {
            saveRig(fileName);
        }
    }

    public void saveAs() {
        System.out.println("saveAs()");

        if( fileName != null ) {
            fileEntry.setText(fileName);
        }

        Vector3f pref = fileSaveDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileSaveDialog.setLocalTranslation(loc);

        GuiGlobals.getInstance().getPopupState().showModalPopup(fileSaveDialog);
    }

    public void exit() {
        //if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
        //    exitOnSave = true;
        //    getState(OptionPanelState.class).show("Save Changes?",
        //                                        "Save changes before exiting?",
        //                                        new CallMethodAction("Save", this, "save"),
        //                                        new CallMethodAction("Save As", this, "saveAs"),
        //                                        new CallMethodAction("Exit", getApplication(), "stop"),
        //                                        new CallMethodAction("Cancel", this, "cancelExit"));
        //} else {
            getApplication().stop();
        //}
    }

    protected void cancelExit() {
        exitOnSave = false;
    }

    protected void cancelSave() {
        exitOnSave = false;
        fileSaveDialog.removeFromParent();
    }

    public List<String> getRigFiles() {
        List<String> objects = new ArrayList<>();
        for( String s : rootDir.list() ) {
            if( !s.toLowerCase().endsWith(".rig") ) {
                continue;
            }
            s = s.substring(0, s.length() - ".rig".length());
            objects.add(s);
        }
        return objects;
    }

    protected void selectFile() {
        System.out.println("selectFile()");

        // Update the file list
        List<String> objects = getRigFiles();

        files.getModel().clear();
        files.getModel().addAll(objects);
        files.getSelectionModel().clear();

        Vector3f pref = fileLoadDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileLoadDialog.setLocalTranslation(loc);

        GuiGlobals.getInstance().getPopupState().showModalPopup(fileLoadDialog);
    }

    protected void saveCurrentFile() {
        System.out.println("Save current file:" + fileEntry.getText());
        fileSaveDialog.removeFromParent();

        String name = fileEntry.getText();
        File file = toFile(name);
        if( file.exists() ) {
            getState(OptionPanelState.class).show("Overwrite?",
                                                "Really overwrite existing file:" + name + "?",
                                                new CallMethodAction("Yes", this, "saveRig"),
                                                new CallMethodAction("No", this, "saveAs"),
                                                new CallMethodAction("Cancel", this, "cancelExit"));
        } else {
            saveRig(name);
        }
    }

    // CallMethodAction won't let us supply our own parameters so we have to
    // double dip
    protected void saveRig() {
        saveRig(fileEntry.getText());
    }

    protected void saveRig( String f ) {
        System.out.println("Save rig:" + f);
        fileName = f;
        File file = toFile(f);

        System.out.println("Write to:" + file);
        try {
            RigInfoJson.store(getState(RigViewState.class).getRigInfo(), file);
            //lastSavedCount = getState(BlockState.class).getChangeCount();

            if( exitOnSave ) {
                exit();
            }
        } catch( Exception e ) {
            log.error("Error saving file:" + file, e);
            getState(OptionPanelState.class).showError("Error saving:" + file, e);
        }
    }

    protected void loadSelectedFile() {
        System.out.println("loadSelectedFile()");
        fileLoadDialog.removeFromParent();

        Integer selection = files.getSelectionModel().getSelection();
        if( selection == null ) {
            getState(OptionPanelState.class).show("Not Loaded",
                                                  "Object not loaded.  No file was selected.");
            return;
        }

        String s = files.getModel().get(selection);
        loadFile(s);
    }

    public RigInfo loadRigInfo( String s ) {
        log.info("loadFile(" + s + ")");
        return RigInfoJson.load(toFile(s));
    }

    protected void loadFile( String s ) {
        log.info("loadFile(" + s + ")");
        File file = toFile(s);
        try {
            RigInfo info = RigInfoJson.load(file);
            getState(RigViewState.class).setRigInfo(info);
            lastSavedCount = 0;
            fileName = s;
        } catch( Exception e ) {
            log.error("Error reading file:" + file, e);
            getState(OptionPanelState.class).showError("Error reading:" + file, e);
        }
    }

    protected void compileBinary() {
        getState(RigViewState.class).compileBinary();
    }

    @Override
    protected void initialize( Application app ) {
        fileMenu = new Container();
        getState(MainMenuState.class).getTabs().addTab("File", fileMenu);

        //fileMenu.addChild(new ActionButton(new CallMethodAction("New", this, "newFile")));
        //fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction("Open Rig...", this, "open")));
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction("Save Rig", this, "save")));
        fileMenu.addChild(new ActionButton(new CallMethodAction("Save As Rig...", this, "saveAs")));
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "compileBinary")));
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "exit")));


        // A simple file dialog that just prompts for a file name
        fileSaveDialog = new Container();
        fileSaveDialog.addChild(new Label("Save As...", new ElementId("title.label")));
        fileEntry = fileSaveDialog.addChild(new TextField("MyFile"));
        Container buttons = fileSaveDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Save", this, "saveCurrentFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", this, "cancelSave")));


        // A simple file selection dialog that just displays a list of all
        // .blocks files and allows selection
        fileLoadDialog = new Container();
        Label title = fileLoadDialog.addChild(new Label("Load Object", new ElementId("title.label")));

        // Set the preferred width of the title so that the whole box is nice and wide
        Vector3f pref = title.getPreferredSize();
        pref.x = Math.max(pref.x, 200);
        title.setPreferredSize(pref);

        files = fileLoadDialog.addChild(new ListBox<String>());
        files.setVisibleItems(10);
        buttons = fileLoadDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Load", this, "loadSelectedFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", fileLoadDialog, "removeFromParent")));

        //InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        //inputMapper.addDelegate(MainAppFunctions.F_NEW, this, "newFile");
        //inputMapper.addDelegate(MainAppFunctions.F_OPEN, this, "open");
        //inputMapper.addDelegate(MainAppFunctions.F_SAVE, this, "save");
        //inputMapper.addDelegate(MainAppFunctions.F_SAVE_AS, this, "saveAs");
        //inputMapper.addDelegate(MainAppFunctions.F_EXIT, this, "exit");
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        //getApplication().enqueue( () -> {
        //    loadFile("robot.rig");
        //});
    }

    @Override
    protected void onDisable() {
    }
}


