/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;
import java.util.function.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.collision.CollisionResult;
import com.jme3.math.*;
import com.jme3.scene.*;

import com.simsilica.es.*;
import com.simsilica.ext.mphys.*;
import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class PlaygroundEditorState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PlaygroundEditorState.class);

    private static Map<String, Function<CharacterDriver, String>> mobSuppliers = new LinkedHashMap<>();
    private static Map<String, Consumer<CharacterDriver>> mobActions = new LinkedHashMap<>();
    private static boolean settingsInvalid;
    private static Map<String, Runnable> globalActions = new LinkedHashMap<>();
    private static boolean globalActionsInvalid;

    private EntityData ed;
    private PhysicsSpace phys;
    private CharacterSystem characters;

    private Container main;
    private VersionedList<String> rigs;
    private Selector<String> rigSelector;

    private MobContainer mobs;
    private Container mobViews;
    private boolean mobsInvalid = true;

    private Container globalActionsContainer;

    public PlaygroundEditorState( Container main, VersionedList<String> rigs ) {
        this.main = main;
        this.rigs = rigs;
    }

    public static void setMobValue( String name, Function<CharacterDriver, String> value ) {
        mobSuppliers.put(name, value);
        settingsInvalid = true;
    }

    public static void setMobAction( String name, Consumer<CharacterDriver> action ) {
        mobActions.put(name, action);
        settingsInvalid = true;
    }

    public static void setGlobalAction( String name, Runnable action ) {
        globalActions.put(name, action);
        globalActionsInvalid = true;
    }

    @Override
    protected void initialize( Application app ) {
        this.ed = getState(GameSystemState.class).get(EntityData.class, true);
        this.phys = getState(GameSystemState.class).get(PhysicsSpace.class, true);
        this.characters = getState(GameSystemState.class).get(CharacterSystem.class, true);
        this.mobs = new MobContainer(ed);

        setMobValue("Pos", (agent) -> {
                if( agent == null || agent.getRigidBody() == null ) {
                    return null;
                }
                Vec3d pos = agent.getRigidBody().position;
                return String.format("%.03f, %.03f, %.03f", pos.x, pos.y, pos.z);
            });
        setMobAction("Delete", (agent) -> ed.removeEntity(agent.getId()));

        Container rootActions = new Container();
        main.addChild(new RollupPanel("Actions", rootActions, null));
        globalActionsContainer = rootActions.addChild(new Container());
        rigSelector = rootActions.addChild(new Selector<>(rigs));
        rootActions.addChild(new ActionButton(new CallMethodAction("Create MOB", this, "createMob")), 1);

        mobViews = main.addChild(new Container());
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        mobs.start();
    }

    @Override
    protected void onDisable() {
        mobs.stop();
    }

    @Override
    public void update( float tpf ) {
        mobs.update();
        for( MobView view : mobs.getArray() ) {
            view.update();
        }
        if( mobsInvalid ) {
            refreshMobViews();
        }
        if( settingsInvalid ) {
            refreshMobSettings();
        }
        if( globalActionsInvalid ) {
            refreshGlobalActions();
        }
    }

    protected void createMob() {
        log.info("createMob()");

        //String name = "mythruna-girl/mythruna-girl.rig";
        String name = rigSelector.getSelectedItem();
        double scale = 1.0;
        Spatial indicator = getState(ModelViewState.class).createIndicator(name, scale);
        getState(PickState.class).pick("Select a MOB Location", new MobIndicator(indicator), (pick) -> {
                log.info("picked:" + pick);
                if( pick == null ) {
                    return;
                }

                EntityId mob = ed.createEntity();
                ed.setComponents(mob,
                    //new SpawnPosition(phys.getGrid(), pick.location.add(0, 1, 0)),
                    new SpawnPosition(phys.getGrid(), pick.location.add(0, 0, 0)),
                    ShapeInfo.create(name, scale, ed),
                    new CharacterType(name),
                    new Mass(50)
                );
            });
    }

    protected void refreshMobViews() {
        mobsInvalid = false;
        mobViews.clearChildren();
        for( MobView view : mobs.getArray() ) {
            mobViews.addChild(view);
        }
    }

    protected void refreshMobSettings() {
        settingsInvalid = false;
        for( MobView view : mobs.getArray() ) {
            view.updateContents();
        }
    }

    protected void refreshGlobalActions() {
        globalActionsInvalid = false;
        globalActionsContainer.clearChildren();
        for( Map.Entry<String, Runnable> action : globalActions.entrySet() ) {
            Button button = new Button(action.getKey());
            button.addClickCommands((s) -> {
                try {
                    action.getValue().run();
                } catch( Exception e ) {
                    log.error("Error running action:" + action, e);
                }
            });
            globalActionsContainer.addChild(button);
        }
    }

    protected class MobIndicator implements PickIndicator<WorldPick> {

        private Spatial spatial;

        public MobIndicator( Spatial spatial ) {
            this.spatial = spatial;
        }

        protected WorldPick getHit( CursorMotionEvent event ) {
            // Is it a valid hit?
            CollisionResult collision = event.getCollision();
            if( collision == null ) {
                return null;
            }
            float up = collision.getContactNormal().dot(Vector3f.UNIT_Y);
            if( up < 0.7 ) {
                // Not flat enough
                return null;
            }
            return new WorldPick(collision.getContactPoint().mult(4), collision.getContactNormal());
        }

        public WorldPick place( Node root, CursorMotionEvent event ) {
            //log.info("place(" + event + ")");
            WorldPick pick = getHit(event);
            if( pick == null ) {
                spatial.removeFromParent();
                return null;
            }

            //log.info("pick:" + pick);
            spatial.setLocalTranslation(pick.location.toVector3f());
            root.attachChild(spatial);

            return pick;
        }

        public void release() {
            log.info("release");
            spatial.removeFromParent();
        }
    }

    protected class ValueView {
        Function<CharacterDriver, String> converter;
        String lastValue;
        Label label;

        public ValueView( Function<CharacterDriver, String> converter ) {
            this.converter = converter;
            this.label = new Label("");
        }

        public void update( CharacterDriver driver ) {
            String value = converter.apply(driver);
            if( Objects.equals(lastValue, value) ) {
                return;
            }
            label.setText(value);
        }
    }

    protected class ActionView {
        private MobView parent;
        private ActionButton button;
        private Consumer<CharacterDriver> action;

        public ActionView( String name, MobView parent, Consumer<CharacterDriver> action ) {
            this.parent = parent;
            this.button = new ActionButton(new CallMethodAction(name, this, "execute"));
            this.action = action;
        }

        protected void execute() {
            if( parent.driver != null ) {
                try {
                    action.accept(parent.driver);
                } catch( Exception e ) {
                    // Should do an error popup
                    log.error("Error running:" + button.getText(), e);
                }
            }
        }
    }

    protected class MobView extends RollupPanel {
        private Entity entity;
        private Container valuePanel;
        private Container controls;
        private Container actionPanel;
        private CharacterDriver driver;
        private ValueView[] values;
        private ActionView[] actions;

        private RangedValueModel speed = new DefaultRangedValueModel(0, 1, 1);
        private VersionedReference<Double> speedRef = speed.createReference();
        private Label speedLabel;
        private Slider speedSlider;

        public MobView( Entity entity ) {
            super("MOB:" + entity.getId().getId(), null);
            this.entity = entity;
            this.speedLabel = new Label("Speed: 1.00");
            this.speedSlider = new Slider(speed);

            Container contents = new Container();
            valuePanel = contents.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.Last)));
            controls = contents.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.Last)));

            controls.addChild(speedLabel);
            controls.addChild(speedSlider, 1);

            actionPanel = contents.addChild(new Container());
            setContents(contents);

            updateContents();
        }

        public void update() {
            if( driver == null ) {
                // Try to get it
                this.driver = characters.getDriver(entity.getId());
                driver.setSpeed(speed.getValue());
            }
            if( driver == null ) {
                return;
            }
            for( ValueView value : values ) {
                value.update(driver);
            }
            if( speedRef.update() ) {
                double value = speed.getValue();
                speedLabel.setText(String.format("Speed: %.02f", value));
                driver.setSpeed(value);
            }
        }

        protected void updateData() {
        }

        protected void updateContents() {
            valuePanel.clearChildren();
            this.values = new ValueView[mobSuppliers.size()];
            int index = 0;
            for( Map.Entry<String, Function<CharacterDriver, String>> e : mobSuppliers.entrySet() ) {
                values[index] = new ValueView(e.getValue());
                valuePanel.addChild(new Label(e.getKey() + ":"));
                valuePanel.addChild(values[index].label, 1);
                index++;
            }
            actionPanel.clearChildren();
            this.actions = new ActionView[mobActions.size()];
            index = 0;
            for( Map.Entry<String, Consumer<CharacterDriver>> e : mobActions.entrySet() ) {
                actions[index++] = new ActionView(e.getKey(), this, e.getValue());
            }

            float maxWidth = 300;
            float width = 0;
            Container row = null;
            for( int i = 0; i < actions.length; i++ ) {
                width += actions[i].button.getPreferredSize().x;
                if( width >= maxWidth || row == null ) {
                    row = actionPanel.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.None, FillMode.None)));
                    width = 0;
                }
                row.addChild(actions[i].button);
            }
        }

        protected void release() {
            removeFromParent();
        }
    }

    protected class MobContainer extends EntityContainer<MobView> {
        public MobContainer( EntityData ed ) {
            super(ed, CharacterType.class);
        }

        protected MobView[] getArray() {
            return (MobView[])super.getArray();
        }

        @Override
        protected MobView addObject( Entity entity ) {
            MobView result = new MobView(entity);
            updateObject(result, entity);
            mobsInvalid = true;
            return result;
        }

        @Override
        protected void updateObject( MobView view, Entity entity ) {
            view.updateData();
        }

        @Override
        protected void removeObject( MobView view, Entity entity ) {
            view.release();
        }
    }
}
