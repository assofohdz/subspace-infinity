/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.io;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import org.slf4j.*;

import com.google.common.base.Charsets;

import com.simsilica.mblock.*;
import com.simsilica.tool.*;

/**
 *  Simple test-based clothing data format.
 *
 *  @author    Paul Speed
 */
public class ClothingFormat {
    static Logger log = LoggerFactory.getLogger(ClothingFormat.class);

    private static Pattern TRIPLE = Pattern.compile("%\\w+:\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)");
    private static Pattern VALUE = Pattern.compile("%\\w+:\\s*(\\w+)\\s*=\\s*(.+)");
    private static Pattern NUM_PAIR = Pattern.compile("(\\d+):(\\d+)");
    
    private List<FabricInfo> fabrics;
    private SwatchIndex swatchIndex;
    
    public ClothingFormat( List<FabricInfo> fabrics, SwatchIndex swatchIndex ) {
        this.fabrics = fabrics;
        this.swatchIndex = swatchIndex;
    }

    public CellArray readCells( InputStream rawIn ) throws IOException {

        Reader rIn = new InputStreamReader(rawIn, Charsets.UTF_8);
        BufferedReader in = new BufferedReader(rIn);
        try {        
            String line = null;
            
            CellArray cells = null;
            CellArray target = null;
 
            // We only support files that supply at least sizes...
            // if trim is specified then we also prefer min/max as well.
            int sizeX = 0;
            int sizeY = 0;
            int sizeZ = 0; 
 
            int minX = 0;
            int minY = 0;
            int minZ = 0;
            int maxX = 0;
            int maxY = 0; 
            int maxZ = 0; 
            int y = 0;
            int z = 0;
            while( (line = in.readLine()) != null ) {
                line = line.trim();
                if( line.startsWith("#") || line.startsWith("//") ) {
                    continue;
                }
                
                // Process the directives
                if( line.startsWith("%Clothing version") ) {
                    if( !line.equals("%Clothing version 1") ) {
                        throw new IOException("Unsupported version:" + line);
                    }
                } else if( line.startsWith("%order") ) {
                    if( !line.equals("%order: z, y, x") ) {
                        throw new IOException("Unsupported order:" + line);
                    }
                } else if( line.startsWith("%compression") ) {                
                    if( !line.equals("%compression: none") ) {
                        throw new IOException("Unsupported compression:" + line);
                    }
                } else if( line.startsWith("%fabric:") ) {
                    // ignore for now
                } else if( line.startsWith("%swatch:") ) {
                } else if( line.startsWith("%size") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in size directive:" + line);
                    }
                    sizeX = sizes[0];
                    sizeY = sizes[1];
                    sizeZ = sizes[2];
                    target = cells = new CellArray(sizeX, sizeY, sizeZ);
                } else if( line.startsWith("%min:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in min directive:" + line);
                    }
                    minX = sizes[0];
                    minY = sizes[1];
                    minZ = sizes[2];
                    y = minY;
                    z = minZ;
                } else if( line.startsWith("%max:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in max directive:" + line);
                    }
                    maxX = sizes[0];
                    maxY = sizes[1];
                    maxZ = sizes[2];
                } else if( line.startsWith("%z:") ) {
                    z = Integer.parseInt(line.substring("%z:".length()));
                    y = minY;
                } else if( line.startsWith("%") ) {
                    throw new IOException("Unhandled directive:" + line);
                } else {
                    // It's data
                    String[] tokens = line.split(",\\s*");
                    for( int i = 0; i < tokens.length; i++ ) {
                        int[] values = parsePair(tokens[i]);
                        int value = ClothingBuilder.toCell(values[1], values[0]);
                        target.setCell(minX + i, y, z, value);
                    }
                    y++;
                }
            }
            return cells;
        } finally {
            in.close();
        } 
    }

    public void writeCells( OutputStream rawOut, CellArray cells ) throws IOException {
    
        Map<Integer, String> fabricNames = new HashMap<>();
        Map<Integer, SwatchIndex.SwatchData> swatches = new HashMap<>(); 
    
        OutputStreamWriter sOut = new OutputStreamWriter(rawOut, Charsets.UTF_8);
        PrintWriter out = new PrintWriter(sOut);
        try {
            int sizeX = cells.getSizeX();
            int sizeY = cells.getSizeY();
            int sizeZ = cells.getSizeZ();
            
            int minX = sizeX;
            int minY = sizeY;
            int minZ = sizeZ;
            int maxX = 0;
            int maxY = 0;
            int maxZ = 0;

            // Build the index and min/max sizes            
            for( int x = 0; x < sizeX; x++ ) {
                for( int y = 0; y < sizeY; y++ ) {
                    for( int z = 0; z < sizeZ; z++ ) {
                        int val = cells.getCell(x, y, z);
                        if( val == 0 ) {
                            continue;
                        }

                        minX = Math.min(minX, x);
                        maxX = Math.max(maxX, x);
                        minY = Math.min(minY, y);
                        maxY = Math.max(maxY, y);
                        minZ = Math.min(minZ, z);
                        maxZ = Math.max(maxZ, z);
                        
                        int shapeIndex = ClothingBuilder.toShape(val);
                        int fabricIndex = ClothingBuilder.toFabric(val); 

                        FabricInfo info = fabrics.get(fabricIndex - 1);
                        fabricNames.put(fabricIndex, info.getName());
                        
                        swatches.put(shapeIndex, swatchIndex.getSwatchData(shapeIndex));
                    }
                }
            }
            if( minX == sizeX ) {
                minX = 0;
            }
            if( minY == sizeY ) {
                minY = 0;
            }
            if( minZ == sizeZ ) {
                minZ = 0;
            }
            
            out.println("%Clothing version 1");
            out.println("%size: " + sizeX + ", " + sizeY + ", " + sizeZ);
            out.println("%order: z, y, x");
            out.println("%compression: none");
            for( Map.Entry<Integer, String> e : fabricNames.entrySet() ) {
                out.println("%fabric:" + e.getKey() + "=" + e.getValue());
            }
            for( Map.Entry<Integer, SwatchIndex.SwatchData> e : swatches.entrySet() ) {
                out.println("%swatch:" + e.getKey() + "=" 
                             + e.getValue().getCell() + ", " 
                             + e.getValue().getDirMask() + ", " 
                             + e.getValue().getShape().getName());
            } 
            out.println("%min: " + minX + ", " + minY + ", " + minZ);
            out.println("%max: " + maxX + ", " + maxY + ", " + maxZ);            
            for( int z = minZ; z <= maxZ; z++ ) {
                out.println("%z:" + z);
                for( int y = minY; y <= maxY; y++ ) {
                    for( int x = minX; x <= maxX; x++ ) {
                        int val = cells.getCell(x, y, z);
                        int shape = ClothingBuilder.toShape(val);
                        int fabric = ClothingBuilder.toFabric(val); 
                        out.print(fabric + ":" + shape);
                        if( x < maxX ) {
                            out.print(", ");
                        }
                    }
                    out.println();
                }                 
            }
            
        } finally {
            out.close();
        }            
    }
    
    
    private static int[] parseTriple( String s ) {
        Matcher m = TRIPLE.matcher(s);
        if( !m.matches() ) {
            return null;
        }
        int[] result = new int[3];
        for( int i = 0; i < result.length; i++ ) {
            result[i] = Integer.parseInt(m.group(i+1));
        }
        return result;
    }    

    private static String[] parseValue( String s ) {
        Matcher m = VALUE.matcher(s);
        if( !m.matches() ) {
            return null;
        }
        String[] result = new String[2];
        for( int i = 0; i < result.length; i++ ) {
            result[i] = m.group(i+1);
        }
        return result;
    }    
    
    private static int[] parsePair( String s ) {
        Matcher m = NUM_PAIR.matcher(s);
        if( !m.matches() ) {
            return null;
        }
        int[] result = new int[2];
        result[0] = Integer.parseInt(m.group(1));
        result[1] = Integer.parseInt(m.group(2));
        return result;
    }              
}

/**
public class BlocksFileFormat {
    
    static Logger log = LoggerFactory.getLogger(BlocksFileFormat.class);

    private static Pattern TRIPLE = Pattern.compile("%\\w+:\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)");
    private static Pattern VALUE = Pattern.compile("%\\w+:\\s*(\\w+)\\s*=\\s*(.+)");
    private static Pattern NUM_PAIR = Pattern.compile("(\\d+):(\\d+)");

    private BlocksFileFormat() {
    }       
        
    public static CellArray loadCellArray( String resource ) throws IOException {
log.info("loadCellArray(" + resource + ")");    
        InputStream in = BlocksFileFormat.class.getResourceAsStream(resource);
        if( in == null ) {
            throw new IOException("Resource not found:" + resource);
        }
        return loadCellArray(in);
    }

    public static CellArray loadCellArray( InputStream rawIn ) throws IOException {

        // Not as efficient memory-wise (copies buffers), etc. but covers fluids, 
        // etc. that would have been hard to cover without extra garbage anyway        
        BlockObject blocks = readBlocks(rawIn, true);
        return blocks.cells;

        //CellArray cells = null;
        //
        //Reader rIn = new InputStreamReader(rawIn, Charsets.UTF_8);
        //BufferedReader in = new BufferedReader(rIn);
        //try {
        //    String line = null;
        //    
        //    // We only support files that supply min/max values and 
        //    // that's what we'll use to size our array.
        //    int sizeX = 0;
        //    int sizeY = 0;
        //    int sizeZ = 0;
        //    
        //    int minX = 0;
        //    int minY = 0;
        //    int minZ = 0;
        //    int maxX = 0; 
        //    int maxY = 0; 
        //    int maxZ = 0; 
        //    int y = 0;
        //    int z = 0;
        //    while( (line = in.readLine()) != null ) {
        //        line = line.trim();
        //        if( line.startsWith("#") || line.startsWith("//") ) {
        //            continue;
        //        }
        //        
        //        // Process the directives
        //        if( line.startsWith("%BlockEd version") ) {
        //            if( !line.equals("%BlockEd version 1") ) {
        //                throw new IOException("Unsupported version:" + line);
        //            }
        //        } else if( line.startsWith("%order") ) {
        //            if( !line.equals("%order: y, z, x") ) {
        //                throw new IOException("Unsupported order:" + line);
        //            }
        //        } else if( line.startsWith("%compression") ) {                
        //            if( !line.equals("%compression: none") ) {
        //                throw new IOException("Unsupported compression:" + line);
        //            }                    
        //        } else if( line.startsWith("%size") ) {
        //            int[] sizes = parseTriple(line);
        //            if( sizes == null ) {
        //                throw new IOException("Bad format in size directive:" + line);
        //            }
        //            sizeX = sizes[0];
        //            sizeY = sizes[1];
        //            sizeZ = sizes[2];
        //        } else if( line.startsWith("%min:") ) {
        //            int[] sizes = parseTriple(line);
        //            if( sizes == null ) {
        //                throw new IOException("Bad format in min directive:" + line);
        //            }
        //            minX = sizes[0];
        //            minY = sizes[1];
        //            minZ = sizes[2];
        //            y = minY;
        //            z = minZ;
        //        } else if( line.startsWith("%max:") ) {
        //            int[] sizes = parseTriple(line);
        //            if( sizes == null ) {
        //                throw new IOException("Bad format in max directive:" + line);
        //            }
        //            maxX = sizes[0];
        //            maxY = sizes[1];
        //            maxZ = sizes[2];
        //        } else if( line.startsWith("%y:") ) {
        //            y = Integer.parseInt(line.substring("%y:".length()));
        //            z = minZ;
        //        } else if( line.startsWith("%") ) {
        //            throw new IOException("Unhandled directive:" + line);
        //        } else {
        //            if( cells == null ) {
        //                cells = new CellArray(maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1);
        //            }
        //            // It's data
        //            String[] tokens = line.split(",\\s*");
        //            for( int i = 0; i < tokens.length; i++ ) {
        //                int value = Integer.parseInt(tokens[i]);
        //                cells.setCell(i, y - minY, z - minZ, value);
        //            }
        //            z++;
        //        }
        //    }
        //    
        //    MaskUtils.calculateSideMasks(cells);        
        //} finally {
        //    in.close();
        //} 
        //
        //return cells;               
    }   
        
    public static void writeBlocks( BlockObject blocks, OutputStream rawOut ) throws IOException {
        writeBlocks(rawOut, blocks.cells, blocks.fluids);
    } 
    
    private static void writeBlocks( OutputStream rawOut, CellArray cells, CellArray fluids ) throws IOException {

        Map<Integer, String> nameIndex = new TreeMap<>();
        Map<Integer, String> fluidNameIndex = new TreeMap<>();
     
        OutputStreamWriter sOut = new OutputStreamWriter(rawOut, Charsets.UTF_8);
        PrintWriter out = new PrintWriter(sOut);
        try {
            int sizeX = cells.getSizeX();
            int sizeY = cells.getSizeY();
            int sizeZ = cells.getSizeZ();
            
            // Find the lowest x, y, z with actual values.  We'll use
            // this as an offset.  Do the same for max.  It really makes a difference
            // on the file size to bound the shape to just a block that's filled.
            int minX = sizeX;
            int minY = sizeY;
            int minZ = sizeZ;
            int maxX = 0;
            int maxY = 0;
            int maxZ = 0;
            int fminX = sizeX;
            int fminY = sizeY;
            int fminZ = sizeZ;
            int fmaxX = 0;
            int fmaxY = 0;
            int fmaxZ = 0;
            for( int x = 0; x < sizeX; x++ ) {
                for( int y = 0; y < sizeY; y++ ) {
                    for( int z = 0; z < sizeZ; z++ ) {
                        int val = cells.getCell(x, y, z); 
                        int type = MaskUtils.getType(val);
                        if( type != 0 ) {
                            minX = Math.min(minX, x);
                            maxX = Math.max(maxX, x);
                            minY = Math.min(minY, y);
                            maxY = Math.max(maxY, y);
                            minZ = Math.min(minZ, z);
                            maxZ = Math.max(maxZ, z);
                            
                            BlockType bt = BlockTypeIndex.get(type);
                            nameIndex.put(type, bt.getName().toString());
                        }
                        val = fluids.getCell(x, y, z);
                        type = FluidUtils.getType(val);
                        if( type != 0 ) {
                            fminX = Math.min(fminX, x);
                            fmaxX = Math.max(fmaxX, x);
                            fminY = Math.min(fminY, y);
                            fmaxY = Math.max(fmaxY, y);
                            fminZ = Math.min(fminZ, z);
                            fmaxZ = Math.max(fmaxZ, z);
                            
                            FluidType ft = FluidTypeIndex.get(type);
                            fluidNameIndex.put(type, ft.getName().toString());
                        }
                    }
                }
            }
 
            out.println("%BlockEd version 1");
            out.println("%size: " + sizeX + ", " + sizeY + ", " + sizeZ);
            out.println("%order: y, z, x");
            out.println("%compression: none");
            for( Map.Entry<Integer, String> e : nameIndex.entrySet() ) {
                out.println("%type:" + e.getKey() + "=" + e.getValue());
            } 
            for( Map.Entry<Integer, String> e : fluidNameIndex.entrySet() ) {
                out.println("%fluidType:" + e.getKey() + "=" + e.getValue());
            } 
            out.println("%min: " + minX + ", " + minY + ", " + minZ);
            out.println("%max: " + maxX + ", " + maxY + ", " + maxZ);            
            for( int y = minY; y <= maxY; y++ ) {
                out.println("%y:" + y);
                for( int z = minZ; z <= maxZ; z++ ) {
                    for( int x = minX; x <= maxX; x++ ) {
                        int val = cells.getCell(x, y, z); 
                        int type = MaskUtils.getType(val);
                        out.print(type);
                        if( x < maxX ) {
                            out.print(", ");
                        }
                    }
                    out.println();
                }                 
            }
            
            out.println("%fluidMin: " + fminX + ", " + fminY + ", " + fminZ);
            out.println("%fluidMax: " + fmaxX + ", " + fmaxY + ", " + fmaxZ);
            for( int y = fminY; y <= fmaxY; y++ ) {
                out.println("%yFluid:" + y);
                for( int z = fminZ; z <= fmaxZ; z++ ) {
                    for( int x = fminX; x <= fmaxX; x++ ) {
                        int val = fluids.getCell(x, y, z); 
                        int type = FluidUtils.getType(val);
                        int level = FluidUtils.getLevel(val);
                        out.print(type + ":" + level);
                        if( x < fmaxX ) {
                            out.print(", ");
                        }
                    }
                    out.println();
                } 
            }
                
        } finally {
            out.close();
        }
    }
    
    public static BlockObject readBlocks( InputStream rawIn, boolean trim ) throws IOException { 
 
        Reader rIn = new InputStreamReader(rawIn, Charsets.UTF_8);
        BufferedReader in = new BufferedReader(rIn);
        try {        
            String line = null;
            
            CellArray cells = null;
            CellArray fluids = null;
            
            // We only support files that supply at least sizes...
            // if trim is specified then we also prefer min/max as well.
            int sizeX = 0;
            int sizeY = 0;
            int sizeZ = 0;
 
            Map<Integer, String> typeIndex = new HashMap<>();
            Map<Integer, Integer> remap = new HashMap<>();
            Map<Integer, String> fTypeIndex = new HashMap<>();
            Map<Integer, Integer> fRemap = new HashMap<>();

            CellArray target = cells;
            boolean isFluid = false; 
            
            int minX = 0;
            int minY = 0;
            int minZ = 0;
            int maxX = 0;
            int maxY = 0; 
            int maxZ = 0; 
            int fminX = 0;
            int fminY = 0;
            int fminZ = 0;
            int fmaxX = 0;
            int fmaxY = 0;
            int fmaxZ = 0;
            int y = 0;
            int z = 0;
            while( (line = in.readLine()) != null ) {
                line = line.trim();
                if( line.startsWith("#") || line.startsWith("//") ) {
                    continue;
                }
                
                // Process the directives
                if( line.startsWith("%BlockEd version") ) {
                    if( !line.equals("%BlockEd version 1") ) {
                        throw new IOException("Unsupported version:" + line);
                    }
                } else if( line.startsWith("%order") ) {
                    if( !line.equals("%order: y, z, x") ) {
                        throw new IOException("Unsupported order:" + line);
                    }
                } else if( line.startsWith("%compression") ) {                
                    if( !line.equals("%compression: none") ) {
                        throw new IOException("Unsupported compression:" + line);
                    }
                } else if( line.startsWith("%type:") ) {
                    String[] words = parseValue(line);
                    int type = Integer.parseInt(words[0]);
                    typeIndex.put(type, words[1]);
                    BlockName name = BlockName.parse(words[1]);
                    log.info("block name:" + name);
                    int index = BlockTypeIndex.findType(name);
                    log.info("index:" + index);
                    if( type != index ) {
                        remap.put(type, index);
                    }
                } else if( line.startsWith("%fluidType:") ) {
                    String[] words = parseValue(line);
                    int type = Integer.parseInt(words[0]);
                    fTypeIndex.put(type, words[1]);
                    FluidName name = new FluidName(words[1]);
                    log.info("fluid name:" + name);
                    int index = FluidTypeIndex.findType(name);
                    log.info("index:" + index);
                    if( type != index ) {
                        fRemap.put(type, index);
                    }
                } else if( line.startsWith("%size") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in size directive:" + line);
                    }
                    sizeX = sizes[0];
                    sizeY = sizes[1];
                    sizeZ = sizes[2];
                    cells = new CellArray(sizeX, sizeY, sizeZ);
                } else if( line.startsWith("%min:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in min directive:" + line);
                    }
                    minX = sizes[0];
                    minY = sizes[1];
                    minZ = sizes[2];
                    y = minY;
                    z = minZ;
                } else if( line.startsWith("%max:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in max directive:" + line);
                    }
                    maxX = sizes[0];
                    maxY = sizes[1];
                    maxZ = sizes[2];
                } else if( line.startsWith("%fluidMin:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in min directive:" + line);
                    }
                    fminX = sizes[0];
                    fminY = sizes[1];
                    fminZ = sizes[2];
                    y = minY;
                    z = minZ;
                } else if( line.startsWith("%fluidMax:") ) {
                    int[] sizes = parseTriple(line);
                    if( sizes == null ) {
                        throw new IOException("Bad format in max directive:" + line);
                    }
                    fmaxX = sizes[0];
                    fmaxY = sizes[1];
                    fmaxZ = sizes[2];
                } else if( line.startsWith("%y:") ) {
                    y = Integer.parseInt(line.substring("%y:".length()));
                    z = minZ;
                    target = cells;
                    isFluid = false;                    
                } else if( line.startsWith("%yFluid:") ) {
                    if( fluids == null ) {
                        fluids = new CellArray(sizeX, sizeY, sizeZ);
                    }
                    y = Integer.parseInt(line.substring("%yFluid:".length()));
                    z = minZ;
                    target = fluids;
                    isFluid = true;                    
                } else if( line.startsWith("%") ) {
                    throw new IOException("Unhandled directive:" + line);
                } else {
                    // It's data
                    String[] tokens = line.split(",\\s*");
                    for( int i = 0; i < tokens.length; i++ ) {
                        if( isFluid ) {
                            int[] values = parsePair(tokens[i]);
                            Integer override = fRemap.get(values[0]);
                            if( override != null ) {
                                values[0] = override;
                            }
                            int value = FluidUtils.setLevel(values[0], values[1]);
                            target.setCell(fminX + i, y, z, value);
                        } else {
                            int value = Integer.parseInt(tokens[i]);
                            Integer override = remap.get(value);
                            if( override != null ) {
                                value = override;
                            }
                            target.setCell(minX + i, y, z, value);
                        }
                    }
                    z++;
                }
            }
 
log.info("remap:" + remap);            
log.info("fremap:" + fRemap);            
            MaskUtils.calculateSideMasks(cells);
            if( fluids != null ) {
                FluidUtils.calculateSideMasks(fluids, cells);
            }
 
            if( trim ) {
                // Did we even get a fluid layer
                if( fluids != null ) {
                    minX = Math.min(minX, fminX);
                    minY = Math.min(minY, fminY);
                    minZ = Math.min(minZ, fminZ);
                    maxX = Math.max(maxX, fmaxX);
                    maxY = Math.max(maxY, fmaxY);
                    maxZ = Math.max(maxZ, fmaxZ);
                }
 
                int xs = (maxX - minX) + 1;                
                int ys = (maxY - minY) + 1;                
                int zs = (maxZ - minZ) + 1;                
                cells = CellUtils.trim(cells, minX, minY, minZ, xs, ys, zs);
                if( fluids != null ) {
                    fluids = CellUtils.trim(fluids, minX, minY, minZ, xs, ys, zs);
                }            
            }
            
            return new BlockObject(cells, fluids);
        } finally {
            in.close();
        } 
               
    }


}
*/
