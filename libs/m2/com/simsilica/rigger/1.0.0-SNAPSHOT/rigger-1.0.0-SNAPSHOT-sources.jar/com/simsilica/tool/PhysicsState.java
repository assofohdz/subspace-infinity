/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.scene.*;


import com.simsilica.es.*;
import com.simsilica.es.base.DefaultEntityData;
import com.simsilica.es.common.*;
import com.simsilica.ext.mblock.SphereFactory;
import com.simsilica.ext.mphys.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.config.DefaultBlockSet;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mblock.phys.collision.*;
import com.simsilica.mphys.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.DefaultLeafWorld;
import com.simsilica.mworld.db.*;
import com.simsilica.sim.*;
import com.simsilica.sim.common.*;

import com.simsilica.crig.*;
import com.simsilica.crig.jme.*;

/**
 *  A sort of hacked together physics space for animation testing.
 *
 *  @author    Paul Speed
 */
public class PhysicsState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PhysicsState.class);

    private GameSystemManager systems;
    private EntityData ed;
    private MPhysSystem<MBlockShape> mphys;
    private PhysicsSpace<EntityId, MBlockShape> phys;
    
    private Grid grid = new Grid(100, 0, 100);

    private Rig rig;
    private RigShapeFactory rigShapeFactory;
    private EntityId rigEntity;
    private RigidBody<EntityId, MBlockShape> rigBody;
    private Vec3d rigVelocity = new Vec3d();

    // Spatial specific stuff... all in one state, this one.
    private Node modelRoot;
    private ShapeFactoryRegistry<MBlockShape> shapeFactory;
    private RigType rigType;
    private SpatialFactory modelFactory;
    private Map<EntityId, Spatial> views = new HashMap<>();
    private Map<EntityId, RigidBody<EntityId, MBlockShape>> bodies = new HashMap<>();

    private Map<Part, Spatial> rigViewIndex;

    private MovementMode mode;
    private RigShape shapeRig;
    private AnimDriver animDriver;

    public PhysicsState() {
        setEnabled(false);
    }

    public RigShape getShapeRig() {
        return shapeRig;
    }

    public Node getModelRoot() {
        return modelRoot;
    }

    public void setRigVelocity( Vec3d velocity ) {
        rigVelocity.set(velocity);
    }

    public Vec3d getRigPosition() {
        return rigBody == null ? new Vec3d() : rigBody.position;
    }

    public void setRig( Rig rig ) {
        this.rig = rig;
    }

    public void setMovementMode( MovementMode mode ) {
        this.mode = mode;
        if( rigBody != null ) {
            ((RigDriver)rigBody.getControlDriver()).setMovementMode(mode);
        }
    }

    public String getCurrentAction() {
        return animDriver == null ? null : animDriver.getCurrentAction();
    }

    public double getCurrentTime() {
        return animDriver == null ? 0 : animDriver.getTime();
    }

    @Override
    protected void initialize( Application app ) {
        DefaultBlockSet dbs = new DefaultBlockSet(app.getAssetManager(),
                                                  "Textures/palette1.png", "Textures/palette2.png",
                                                  "Textures/bad.jpg");

        this.systems = new GameSystemManager();
        this.ed = new DefaultEntityData();

        systems.register(EntityData.class, ed);
        systems.addSystem(new DecaySystem());

        // Need a shape factory to turn ShapeInfo components into
        // MBlockShapes.
        shapeFactory = new ShapeFactoryRegistry<>();
        shapeFactory.registerFactory("sphere", new SphereFactory());
        rigShapeFactory = new RigShapeFactory();
        shapeFactory.registerFactory("rig", rigShapeFactory);
        //shapeFactory.setDefaultFactory(new BlocksResourceShapeFactory(ed));
        systems.register(ShapeFactory.class, shapeFactory);

        // And give that to an EntityBodyFactory, for the moment without any
        // customization
        EntityBodyFactory<MBlockShape> bodyFactory = new EntityBodyFactory<>(ed,
                                                                             new Vec3d(0, -10, 0),
                                                                             shapeFactory);

        // Just create a test world for now
        LeafDb leafDb = new LeafDbCache(new TestLeafDb());
        World world = new DefaultLeafWorld(leafDb, 256);
        systems.register(World.class, world);

        mphys = new MPhysSystem<MBlockShape>(grid, bodyFactory);
        Collider[] colliders = new ColliderFactories(true).createColliders(BlockTypeIndex.getTypes());
        mphys.setCollisionSystem(new MBlockCollisionSystem<EntityId>(world, colliders));
        //mphys.addPhysicsListener(new PositionUpdater(ed));

        systems.register(MPhysSystem.class, mphys);
        systems.register(PhysicsSpace.class, mphys.getPhysicsSpace());
        systems.register(EntityBodyFactory.class, bodyFactory);
        this.phys = mphys.getPhysicsSpace();

        GeometryFactory geomFactory = new GeometryFactory(dbs.getMaterials().getMaterials());
        this.modelFactory = new SpatialFactory(geomFactory);

        this.modelRoot = new Node("modelRoot");
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        if( !systems.isInitialized() ) {
            systems.initialize();

            // BinEntityManager doesn't exist until the systems are initialized
            PhysicsObserver po = new PhysicsObserver();
            phys.addPhysicsListener(po);
            mphys.getBinEntityManager().addObjectStatusListener(po);
        }
        if( !systems.isStarted() ) {
            systems.start();
        }

        //List<com.simsilica.crig.ColliderInfo> colliders = new ArrayList<>();
        //for( ColliderInfo info : rig.getRigInfo().getColliders() ) {
        //    colliders.add(info.convert(rig.getColliders()));
        //}
        this.rigType = rig.getRigType(); //new SpatialRigType(rig.getView(), colliders);

        long gameTime = systems.getStepTime().getTime();

        // Force the unpause
        systems.getStepTime().setCurrentTime(gameTime);

        EntityId test = ed.createEntity();
        ed.setComponents(test,
                new SpawnPosition(phys.getGrid(), 0.5, 85, 0.5),
                ShapeInfo.create("sphere", 1, ed),
                new Mass(10),
                Decay.duration(systems.getStepTime().getTime(), systems.getStepTime().toSimTime(15))
                );

        test = ed.createEntity();
        ed.setComponents(test,
                new SpawnPosition(phys.getGrid(), 5, 75, 6),
                ShapeInfo.create("sphere", 0.1, ed),
                new Mass(10)//,
                //Decay.duration(systems.getStepTime().getTime(), systems.getStepTime().toSimTime(15))
                );

        if( rigEntity == null ) {
            rigEntity = ed.createEntity();
        }
        ed.setComponents(rigEntity,
                new SpawnPosition(phys.getGrid(), 5, 66, 5),
                //ShapeInfo.create("sphere", 0.25, ed),
                ShapeInfo.create("rig", 1, ed),
                new Mass(60)
                );
    }

    @Override
    public void update( float tpf ) {


        systems.update();

        // We don't want our local zone to go to sleep so we'll just keep
        // activating it
        mphys.getBinEntityManager().tempActivate(new Vec3d(0, 0, 0));

        //log.info("time:" + systems.getStepTime().getTime());

        if( rigBody != null ) {
            // Update all of the views to be relative to the rig
            for( Map.Entry<EntityId, Spatial> e : views.entrySet() ) {
                Spatial view = e.getValue();
                RigidBody<EntityId, MBlockShape> body = bodies.get(e.getKey());
                if( body == null ) {
                    log.warn("No body for view:" + e);
                } else {

                    // First need to know the shape origin's position
                    Vec3d pos = body.shape.getWorldShapeOrigin(body);

                    // Calculate the position relative to the avatar for the model
                    Vec3d relative = pos.subtract(rigBody.position.x, 64, rigBody.position.z);

                    // Make sure that the relative position is warped to the 10x10 box
                    // centered around the player
                    if( relative.x < -5 ) {
                        relative.x += 10;
                    } else if( relative.x > 5 ) {
                        relative.x -= 10;
                    }
                    if( relative.z < -5 ) {
                        relative.z += 10;
                    } else if( relative.z > 5 ) {
                        relative.z -= 10;
                    }

                    //log.info("body:" + body.position + "  relative:" + relative);
                    view.setLocalTranslation(relative.toVector3f());

                    view.setLocalRotation(body.orientation.toQuaternion());
                }
            }

            for( Map.Entry<Part, Spatial> e : rigViewIndex.entrySet() ) {
                Spatial s = e.getValue();
                Part child = e.getKey();
                s.setLocalTranslation(child.getShapeRelativePosition().toVector3f());
                s.setLocalRotation(child.getShapeRelativeOrientation().toQuaternion());
            }
        }
    }

    @Override
    protected void onDisable() {
    }

    protected void addModel( EntityId id, RigidBody<EntityId, MBlockShape> body ) {
        Map<Part, Spatial> index = new HashMap<>();
        if( id == rigEntity ) {
            rigBody = body;
            rigBody.setControlDriver(new RigDriver(mode));
        }
        Mass mass = ed.getComponent(id, Mass.class);
        Spatial model = modelFactory.createModel(id, body.shape, mass, index);
        model.setLocalTranslation(body.position.toVector3f());
        views.put(id, model);
        bodies.put(id, body);
        modelRoot.attachChild(model);

        if( id == rigEntity ) {
            rigViewIndex = index;
        }
    }

    protected void removeModel( EntityId id ) {
        Spatial model = views.remove(id);
        bodies.remove(id);
        if( model != null ) {
            model.removeFromParent();
        }
    }

    private class PhysicsObserver extends ObjectStatusAdapter<MBlockShape>
                                  implements PhysicsListener<EntityId, MBlockShape> {

        @Override
        public void startFrame( long frameTime, double stepSize ) {
        }

        @Override
        public void update( RigidBody<EntityId, MBlockShape> body ) {
//log.info("update:" + body);
            // Clamp body positions within the limited 10x10 world space
            body.position.x = body.position.x % 10;
            if( body.position.x < 0 ) {
                body.position.x += 10;
            }
            body.position.z = body.position.z % 10;
            if( body.position.z < 0 ) {
                body.position.z += 10;
            }
        }

        @Override
        public void endFrame() {
        }

        @Override
        public void objectLoaded( EntityId entity, RigidBody<EntityId, MBlockShape> body ) {
log.info("Loaded:" + entity);
            addModel(entity, body);
        }

        @Override
        public void objectUnloaded( EntityId entity, RigidBody<EntityId, MBlockShape> body ) {
log.info("Unloaded:" + entity);
            removeModel(entity);
        }
    }

    private class AnimDriver {
        private RigShape cRig;
        private double time;
        private String action;
        private double speed;
        private double length;

        public AnimDriver( RigShape cRig ) {
            this.cRig = cRig;
        }

        public void setCurrentAction( String action, double speed ) {
            this.speed = speed;
            if( Objects.equals(this.action, action) ) {
                return;
            }
            this.time = 0;
            this.action = action;
            if( action != null ) {
                cRig.setLayerAction(null, action);
                length = cRig.getLayerDuration(null);
            }
        }

        public String getCurrentAction() {
            return action;
        }

        public double getTime() {
            return time;
        }

        public void setSpeed( double speed ) {
            this.speed = speed;
        }

        public void update( double tpf ) {
            if( action == null ) {
                return;
            }
            time += tpf * speed;
            time = time % length;
            if( time < 0 ) {
                time = (time + length) % length;
            }
            cRig.setTime(null, time);
            cRig.update();
        }
    }

    private class RigDriver extends AbstractControlDriver<EntityId, MBlockShape> {
        private double[] angles = new double[3];

        // Stuff for the physics animation
        private MovementMode mode;
        private MovementAnimation currentAnim;
        private AnimDriver animDriver;
        private Vec3d localVelocity = new Vec3d();
        private Vec3d lastVelocity = new Vec3d(1000, 1000, 1000);

        public RigDriver( MovementMode mode ) {
            this.mode = mode;
        }

        public void setMovementMode( MovementMode mode ) {
            this.mode = mode;
        }

        @Override
        public void initialize( RigidBody<EntityId, MBlockShape> body ) {
            super.initialize(body);
            if( body.shape instanceof RigShape ) {
                this.animDriver = new AnimDriver((RigShape)body.shape);
                PhysicsState.this.animDriver = animDriver;
            }
        }

        protected void resetAnimation( Vec3d velocity ) {
            if( mode == null ) {
                return;
            }

            // Try to find the best movement animation that fits our
            // velocity.  Not as straight forward as one might think.

            // This should be a strategy object because selecting animation
            // parameters is easily game specific.  It would also let us use
            // different ones for different character types, swap in low fidelity
            // versions, etc..

            double speed = velocity.length();
            double forward = velocity.dot(Vec3d.UNIT_Z);

            MovementAnimation best = null;
            double maxDot = -1;

            for( MovementAnimation ma : mode.getBasicAnimation() ) {
                double length = ma.getBaseVelocity().length();
                double dot = 0;
                if( length != 0 ) {
                    dot = ma.getBaseVelocity().divide(length).dot(velocity);
                }
                if( dot > length && best != null ) {
                    // We are going faster than this animation's base velocity
                    // and we already have a 'best'... so we'll ignore this one
                    // and keep looking.
                    continue;
                }
                if( dot > maxDot ) {
                    maxDot = dot;
                    best = ma;
                }
            }

            if( best == null ) {
                log.warn("No animation found for:" + velocity);
                return;
            }

            log.info("best:" + best);
            double animSpeed = best.getScale();
            if( maxDot != 0 ) {
                animSpeed *= maxDot / best.getBaseVelocity().length();
            }

            animDriver.setCurrentAction(best.getAnimation(), animSpeed);
            currentAnim = best;
        }

        protected void killVerticalRotation( RigidBody<EntityId, MBlockShape> body ) {
            // Kill any non-yaw orientation
            body.orientation.toAngles(angles);
            if( angles[0] != 0 || angles[2] != 0 ) {
                angles[0] = 0;
                angles[2] = 0;
                body.orientation.fromAngles(angles);
            }

            // Kill any non-yaw velocity
            Vec3d rot = body.getRotationalVelocity();
            if( rot.x != 0 || rot.z != 0 ) {
                rot.x = 0;
                //rot.y *= 0.95; // Let's see if we can dampen the spinning
                rot.z = 0;

                // Don't really need to set it back but just in case
                body.setRotationalVelocity(rot);
            }
        }

        @Override
        public void update( long frameTime, double step ) {
//log.info("Body y:" + getBody().position.y);
            RigidBody<EntityId, MBlockShape> body = getBody();
            killVerticalRotation(body);

            body.orientation.set(0, 0, 0, 1);

            double y = body.getLinearVelocity().y;
            body.setVelocity(rigVelocity.x, y, rigVelocity.z);
            body.wakeUp(true);

            // Update the animation based on current movement, etc.
            // Doing this here would let us use IK or whatever other
            // tricks might someday be at our disposal to pose the
            // character.
            // Figure out the velocity relative to our direction
            localVelocity = body.orientation.mult(body.getLinearVelocity(), localVelocity);
            if( lastVelocity.distanceSq(localVelocity) > (0.05 * 0.05) ) {
log.info("lastVelocity:"+ lastVelocity + " new velocity:" + localVelocity + " distance:" + lastVelocity.distanceSq(localVelocity));
                lastVelocity.set(localVelocity);
                resetAnimation(localVelocity);
            }
            animDriver.update(step);
        }
    }

    private class ColliderView {
        Spatial root;
        ColliderInfo info;
        Node attachment;
        CellArrayPart part;

        public ColliderView( Spatial root, ColliderInfo info, Node attachment, CellArrayPart part ) {
            this.root = root;
            this.info = info;
            this.attachment = attachment;
            this.part = part;
        }

        public void update() {
            Vec3d offset = info.getOffset();
            Quatd orient = info.getOrientation();
            Vector3f local = attachment.localToWorld(offset.toVector3f(), null);
            root.worldToLocal(local, local);

            Quaternion localRot = attachment.getWorldRotation().mult(orient.toQuaternion());
            localRot = root.getWorldRotation().inverse().mult(localRot);

            part.setLocalPosition(new Vec3d(local));
            part.setLocalOrientation(new Quatd(localRot));
        }
    }

    private class RigShapeFactory implements ShapeFactory<MBlockShape> {

        @Override
        public MBlockShape createShape( String name, double scale, Mass mass ) {
            if( rig == null ) {
                double m = mass == null ? 0 : mass.getMass();
                return new MBlockShape(CellArrayPart.createSphere(0.15, m));
            }

            //shapeRig = MBlockShapeRig.createShape(rig, mass);
            //return shapeRig;
            return rigType.createShape(name, scale, mass);
        }
    }

}


