/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.bpos.*;
import com.simsilica.crig.*;
import com.simsilica.es.*;
import com.simsilica.es.base.*;
import com.simsilica.ext.mphys.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mblock.phys.collision.*;
import com.simsilica.mphys.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.DefaultWorld;
import com.simsilica.mworld.db.*;
import com.simsilica.sim.*;
import com.simsilica.sim.common.*;


/**
 *  Controls the life-cycle of the GameSystemManager and provides some
 *  facilities for hot-swapping game systems.  This is setup to start/stop
 *  the systems when the state is attached.  setEnabled(false) will just
 *  pause the systems.
 *
 *  @author    Paul Speed
 */
public class GameSystemState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(GameSystemState.class);

    private static final long IDEAL_FRAME_NANOS = 1000000000L / 60L;

    private GameSystemManager systems = new GameSystemManager();
    private EntityData ed;
    private WorldSettings worldSettings;
    private ShapeFactoryRegistry<MBlockShape> shapeFactory;
    private boolean paused;

    public GameSystemState( WorldSettings worldSettings, ShapeFactoryRegistry<MBlockShape> shapeFactory ) {
        this.ed = new DefaultEntityData();
        this.worldSettings = worldSettings;
        this.shapeFactory = shapeFactory;
    }

    public <T> T get( Class<T> type ) {
        return get(type, false);
    }

    public <T> T get( Class<T> type, boolean failOnMiss ) {
        return systems.get(type, failOnMiss);
    }

    public GameSystemManager getGameSystems() {
        return systems;
    }

    public void setPaused( boolean paused ) {
        if( this.paused == paused ) {
            return;
        }
        this.paused = paused;
        if( !paused ) {
            rebaseTime(0);
        }
    }

    public boolean isPaused() {
        return paused;
    }

    public void singleStep() {
        if( !paused ) {
            return;
        }
        rebaseTime(IDEAL_FRAME_NANOS);
        systems.update();
    }

    protected void rebaseTime( long frameTime ) {
        // Note: the physics engine is using a fixed tpf so this really doesn't
        // matter... but I also feel better letting all of the systems have accurate
        // tpf even when single-stepping.
        long nanos = System.nanoTime();
        long back = nanos - frameTime;
        SimTime time = systems.getStepTime();
        if( back < time.getTime() ) {
            back = time.getTime();
        }
        time.update(back);
        time.update(nanos);
    }

    @Override
    protected void initialize( Application app ) {
        log.info("initialize()");

        systems.register(EntityData.class, ed);

        // Useful for the decay system to always be at one end of the
        // list of services or the other... we'll just 'first' because it's easier
        // to control here.
        systems.addSystem(new DecaySystem());

        // Add our standard systems.... these could have been done from another
        // state, too.
        setupWorld();
        setupPhysics();

        systems.register(CharacterSystem.class, new CharacterSystem());

        log.info("initializing game systems.");
        systems.initialize();

        log.info("starting game systems.");
        systems.start();


        if( false ) {
            // Add some temporary test objects
            EntityId test = ed.createEntity();
            ed.setComponents(test,
                    new SpawnPosition(systems.get(PhysicsSpace.class).getGrid(), 0, 10, 0),
                    ShapeInfo.create("sphere", 1, ed),
                    new Mass(10)//,
                    //Decay.duration(systems.getStepTime().getTime(), systems.getStepTime().toSimTime(15))
                    );

            test = ed.createEntity();
            ed.setComponents(test,
                    new SpawnPosition(systems.get(PhysicsSpace.class).getGrid(), Math.random(), 12, Math.random()),
                    ShapeInfo.create("sphere", 0.25, ed),
                    new Mass(1)//,
                    //Decay.duration(systems.getStepTime().getTime(), systems.getStepTime().toSimTime(15))
                    );

            test = ed.createEntity();
            ed.setComponents(test,
                    new SpawnPosition(systems.get(PhysicsSpace.class).getGrid(), 1, 10, 2),
                    ShapeInfo.create("mythruna-girl/mythruna-girl.rig", 1, ed),
                    //ShapeInfo.create("human/female/human-female.rig", 1, ed),
                    new Mass(50)
                    );
        }
    }

    @Override
    protected void cleanup( Application app ) {
        log.info("cleanup()");
        log.info("stopping game systems.");
        systems.stop();
        log.info("terminating game systems.");
        systems.terminate();
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void update( float tpf ) {
        if( paused ) {
            return;
        }
        //log.info("update");
        systems.update();
    }

    protected void setupWorld() {
        // The max height of the world / 32
        int maxHeight = 64;

        //int dirt = BlockTypeIndex.findType(new BlockName("base7", "cube"));
        //int grass = BlockTypeIndex.findType(new BlockName("base31", "cube"));
        //log.info("dirt:" + dirt + "  grass:" + grass);

        int depth = worldSettings.groundDepth;
        int dirt = worldSettings.groundType;
        int grass = worldSettings.topType;
        log.info("depth:" + depth + " dirt:" + dirt + "  grass:" + grass);

        InMemoryColumnDb memDb = new InMemoryColumnDb(new Vec3i(), 2, maxHeight, (col) -> {
            // Just a bit of ground in the bottom
            LeafData leaf = col.getLeafData(0);
            for( int i = 0; i < 32; i++ ) {
                for( int j = 0; j < depth; j++ ) {
                    for( int k = 0; k < 32; k++ ) {
                        if( j < depth - 1 ) {
                            leaf.setCell(i, j, k, dirt);
                        } else {
                            //if( i != k ) {
                                leaf.setCell(i, j, k, grass);
                            //}
                        }
                    }
                }
            }
        });

        // First layer will calculate the masks and initial straight-down sun lighting
        ColumnDb cdb = new PostProcColumnDb(
                    memDb,
                    new MaskPostProcessor(),
                    new InitialSunlightProcessor()
                );

        // Next layer will build neighborhoods of the above to propagate a columns
        // lighting to itself. (which may pass through neighbors)
        cdb = new PostProcColumnDb(cdb, new InternalLightingProcessor());

        // And then the next layer will use neighborhoods of internally lit columns
        // to propagate lighting from outside a column into that column
        cdb = new PostProcColumnDb(cdb, new LightingPostProcessor());

        ColumnDb colDb = new ObservableColumnDbAdapter(cdb);

        DefaultWorld world = new DefaultWorld(colDb, null, null, null, maxHeight);
        world.initialize();
        systems.register(World.class, world);

        // Here we could poke our initial data set in.
        if( worldSettings.initialStructure != null ) {
            CellArray cells = worldSettings.initialStructure.cells;
            Vec3i size = cells.getSize();
            Vec3i offset = size.clone();
            offset.x /= -2;
            offset.y = worldSettings.groundDepth + worldSettings.structureOffset;
            offset.z /= -2;
            for( int i = 0; i < size.x; i++ ) {
                for( int j = 0; j < size.y; j++ ) {
                    for( int k = 0; k < size.z; k++ ) {
                        int block = MaskUtils.getType(cells.getCell(i, j, k));
                        //log.info("setWorldCell(" + offset.add(i, j, k).toVec3d() + ", " + block + ")");
                        world.setWorldCell(offset.add(i, j, k).toVec3d(), block);
                    }
                }
            }
        }
    }

    protected void setupPhysics() {
        // Need a shape factory to turn ShapeInfo components into MBlockShapes.
        //ShapeFactoryRegistry<MBlockShape> shapeFactory = createShapeFactory();
        systems.register(ShapeFactory.class, shapeFactory);

        // And give that to an EntityBodyFactory, for the moment without any
        // customization
        EntityBodyFactory<MBlockShape> bodyFactory = new EntityBodyFactory<MBlockShape>(
                                                                ed,
                                                                // Default gravity
                                                                new Vec3d(0, -10, 0),
                                                                shapeFactory) {
                protected RigidBody<EntityId, MBlockShape> createRigidBody( EntityId id,
                                                                    SpawnPosition pos, ShapeInfo info,
                                                                    Mass mass, Gravity gravity ) {
                    RigidBody<EntityId, MBlockShape> result = super.createRigidBody(id, pos, info, mass, gravity);
                    log.info("created body for:" + id + "  driver:" + result.getControlDriver());
                    if( result.shape instanceof RigShape ) {
                        //result.setControlDriver(new CharacterDriver(ed, type));
                        // Give it just an initial driver to keep it from falling over
                        if( result.getControlDriver() != null ) {
                            result.setControlDriver(new UprightDriver<>());
                        }
                    }
                    return result;
                }
            };

        // The grid for the zones
        Grid grid = new Grid(100, 0, 100);

        MPhysSystem<MBlockShape> mphys = new MPhysSystem<>(grid, bodyFactory);

        World world = systems.get(World.class, true);
        Collider[] colliders = new ColliderFactories(true).createColliders(BlockTypeIndex.getTypes());
        mphys.setCollisionSystem(new MBlockCollisionSystem<EntityId>(world, colliders));
        systems.register(MPhysSystem.class, mphys);
        final PhysicsSpace phys = mphys.getPhysicsSpace();
        systems.register(PhysicsSpace.class, phys);
        systems.register(EntityBodyFactory.class, bodyFactory);

        // Because we don't have any fancy network layers or multithreading going on
        // we can just send the body updates directly to SpawnPosition updates.
        mphys.addPhysicsListener(new PhysicsListener<EntityId, MBlockShape>() {
                public void update( RigidBody<EntityId, MBlockShape> body ) {
                    Vec3d modelPos = body.shape.getWorldShapeOrigin(body);

                    BodyPosition bPos =  new BodyPosition(3);
                    bPos.addFrame(System.nanoTime(), modelPos, body.orientation, true);
                    ed.setComponent(body.id, bPos);
                    SpawnPosition pos = new SpawnPosition(phys.getGrid(), body.position, body.orientation);
                    ed.setComponent(body.id, pos);
                }
            });
    }
}


