/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.nio.*;

import org.slf4j.*;

import com.jme3.math.*;
import com.jme3.texture.*;
import com.jme3.texture.image.*;
import com.jme3.util.BufferUtils;


/**
 *  Holds the set of textures for 'CPU rendering' clothing versus
 *  shader-rendering clothing.
 *
 *  @author    Paul Speed
 */
public class ClothingPainter {
    static Logger log = LoggerFactory.getLogger(ClothingPainter.class);

    private Image baseImage;
    private Image normalImage;
    private Image metalRoughImage;
    private Image specularImage;
    private Texture baseTexture;
    private Texture normalTexture;
    private Texture metalRoughTexture;
    private Texture specularTexture;
    private ImageRaster baseRaster;
    private ImageRaster normalRaster;
    private ImageRaster metalRoughRaster;
    private ImageRaster specularRaster;

    private boolean yFlip = false;

    public ClothingPainter() {
        this.baseImage = createImage(1024, 1024);
        this.normalImage = createImage(1024, 1024);
        this.metalRoughImage = createImage(1024, 1024);
        this.specularImage = createImage(1024, 1024, true);
        this.baseTexture = new Texture2D(baseImage);
        this.normalTexture = new Texture2D(normalImage);
        this.metalRoughTexture = new Texture2D(metalRoughImage);
        this.specularTexture = new Texture2D(specularImage);
        this.baseRaster = ImageRaster.create(baseImage);
        this.normalRaster = ImageRaster.create(normalImage);
        this.metalRoughRaster = ImageRaster.create(metalRoughImage);
        this.specularRaster = ImageRaster.create(specularImage);

        // The normal map will be totally bogus if we don't fill
        // in some default values.  For the other rasters we'll let
        // the caller decide what default is.
        ColorRGBA defaultNormal = new ColorRGBA(0.5f, 0.5f, 1, 0);
        fillRaster(normalRaster, defaultNormal);
    }

    public void setFlipY( boolean yFlip ) {
        this.yFlip = yFlip;
    }

    public static Image createImage( int width, int height ) {
        return createImage(width, height, false);
    }

    public static Image createImage( int width, int height, boolean supportAlpha ) {
        int bytes = supportAlpha ? 4 : 3;
        int size = width * height * bytes;
        ByteBuffer data = BufferUtils.createByteBuffer(size);
        if( supportAlpha ) {
            return new Image(Image.Format.ABGR8, width, height, data, ColorSpace.Linear);
        } else {
            return new Image(Image.Format.BGR8, width, height, data, ColorSpace.Linear);
        }
    }

    private ColorRGBA getPixel( ImageRaster raster, int x, int y ) {
        if( yFlip ) {
            return raster.getPixel(x, 1023-y);
        } else {
            return raster.getPixel(x, y);
        }
    }

    private void setPixel( ImageRaster raster, int x, int y, ColorRGBA value ) {
        if( yFlip ) {
            raster.setPixel(x, 1023-y, value);
        } else {
            raster.setPixel(x, y, value);
        }
    }

    public static void fillRaster( ImageRaster raster, ColorRGBA value ) {
        int width = raster.getWidth();
        int height = raster.getHeight();
        for( int i = 0; i < width; i++ ) {
            for( int j = 0; j < width; j++ ) {
                raster.setPixel(i, j, value);
            }
        }
    }

    public int getWidth() {
        return 1024;
    }

    public int getHeight() {
        return 1024;
    }

    protected int clamp( int val, int min, int max ) {
        if( val < min ) {
            return min;
        }
        if( val > max ) {
            return max;
        }
        return val;
    }

    public void paint( int x, int y, ColorRGBA base, ColorRGBA normal, ColorRGBA metalRough, ColorRGBA specular ) {
        x = clamp(x, 0, getWidth()-1);
        y = clamp(y, 0, getHeight()-1);
        if( base.a < 1 ) {
            ColorRGBA existing = getPixel(baseRaster, x, y);
            existing.interpolateLocal(base, base.a);
            setPixel(baseRaster, x, y, existing);
        } else {
            setPixel(baseRaster, x, y, base);
        }
        setPixel(normalRaster, x, y, normal);
        if( metalRough.a < 1 ) {
            ColorRGBA existing = getPixel(metalRoughRaster, x, y);
            existing.interpolateLocal(metalRough, metalRough.a);
            setPixel(metalRoughRaster, x, y, existing);
        } else {
            setPixel(metalRoughRaster, x, y, metalRough);
        }
        setPixel(specularRaster, x, y, specular);
    }

    public Texture getBaseTexture() {
        return baseTexture;
    }

    public Texture getNormalTexture() {
        return normalTexture;
    }

    public Texture getMetalRoughnessTexture() {
        return metalRoughTexture;
    }

    public Texture getSpecularTexture() {
        return specularTexture;
    }
}

