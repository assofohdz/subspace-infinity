/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class OverlayEditor extends Container {
    static Logger log = LoggerFactory.getLogger(OverlayEditor.class);
 
    private OverlayInfo overlay;
    private TextField nameField;
    //private Selector<String> jointField;
    //private Vec3dEditor offsetEditor;
    //private EulerRotationEditor orientEditor;
    
    private VersionedReference nameRef;
    //private VersionedReference<String> jointRef;
    //private VersionedReference<Vec3d> offsetRef;
    //private VersionedReference<Quatd> orientRef;
        
    public OverlayEditor( VersionedList<String> jointNames ) {
        Container props = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        props.addChild(new Label("Name:"));
        nameField = props.addChild(new TextField(""), 1);
        nameRef = nameField.getDocumentModel().createReference();
        
        //props.addChild(new Label("Joint:"));
        //jointField = props.addChild(new Selector<String>(jointNames), 1);
        //jointRef = jointField.createSelectedItemReference();
        //
        //props.addChild(new Label("Offset:"));
        //offsetEditor = props.addChild(new Vec3dEditor(Axis.X, -1, 1, 0.01, 0.01), 1);
        //offsetRef = offsetEditor.createReference();
        //
        //props.addChild(new Label("Orient:"));
        //orientEditor = props.addChild(new EulerRotationEditor(Axis.X), 1);
        //orientRef = orientEditor.createReference();
    }
    
    public void setOverlay( OverlayInfo overlay ) {
        this.overlay = overlay;
        resetFields();
    }
    
    public OverlayInfo getOverlay() {
        return overlay;
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( nameRef.update() ) {
            overlay.setName(nameField.getText());
        }
        //if( jointRef.update() ) {
        //    overlay.setJoint(jointRef.get());
        //}
        //if( offsetRef.update() ) {
        //    overlay.setOffset(offsetRef.get());
        //}
        //if( orientRef.update() ) {
        //    overlay.setOrientation(orientRef.get());
        //}
        
    }
    
    protected void resetFields() {
        if( overlay == null ) {
            nameField.setText("");
            //jointField.setSelectedItem(null);
            //offsetEditor.setObject(new Vec3d());
            //orientEditor.setObject(new Quatd());
        } else {
            nameField.setText(overlay.getName());
            //jointField.setSelectedItem(overlay.getJoint());
            //offsetEditor.setObject(overlay.getOffset());
            //orientEditor.setObject(overlay.getOrientation());
        }
    }
}
