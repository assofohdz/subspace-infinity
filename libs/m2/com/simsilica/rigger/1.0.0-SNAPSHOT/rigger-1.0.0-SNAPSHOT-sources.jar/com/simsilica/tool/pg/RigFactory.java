/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.cache.*;

import com.simsilica.crig.*;
import com.simsilica.es.EntityData;
import com.simsilica.ext.mphys.Mass;
import com.simsilica.ext.mphys.ShapeFactory;
import com.simsilica.ext.mphys.ShapeInfo;
import com.simsilica.mblock.phys.MBlockShape;

/**
 *  A ShapeFactory for .rig objects.
 *
 *  @author    Paul Speed
 */
public class RigFactory implements ShapeFactory<MBlockShape> {
    static Logger log = LoggerFactory.getLogger(RigFactory.class);

    private File root;
    private LoadingCache<String, RigType> rigTypes;

    public RigFactory( File root ) {
        this.root = root;
        this.rigTypes = CacheBuilder.newBuilder()
            .maximumSize(100)
            .build(new CacheLoader<String, RigType>() {
                    @Override
                    public RigType load( String key ) {
                        return loadRigType(key);
                    }
                });
    }

    public MBlockShape createShape( String shapeName, double scale, Mass mass ) {
        if( log.isTraceEnabled() ) {
            log.trace("createShape(" + shapeName + ", " + scale + ", " + mass + ")");
        }

        if( !shapeName.endsWith(".rig") ) {
            return null;
        }

        RigType rigType = rigTypes.getUnchecked(shapeName);
        if( rigType == null ) {
            // Shouldn't happen
            throw new RuntimeException("Rig not found:" + shapeName);
        }

        RigShape shape = rigType.createShape(shapeName, scale, mass);
        shape.setLayerAction(null, "default pose");
        shape.setTime(null, 0.0);
        return shape;
    }

    protected String rigNameToType( String name ) {
        return name + ".rt";
    }

    protected RigType loadRigType( String name ) {
        String rtName = rigNameToType(name);
        try {
            File f = new File(root, rtName);
            log.info("Loading rig type:" + f);
            return RigProtocol.loadRigType(f);
        } catch( Exception e ) {
            throw new RuntimeException("Error loading rig type:" + rtName, e);
        }
    }
}


