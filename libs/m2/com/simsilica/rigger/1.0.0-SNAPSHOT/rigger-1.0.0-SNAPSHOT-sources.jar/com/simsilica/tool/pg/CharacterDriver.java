/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;

import org.slf4j.*;

import com.simsilica.crig.*;
import com.simsilica.crig.sim.AnimPump;
import com.simsilica.es.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.phys.MBlockShape;
import com.simsilica.mphys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CharacterDriver extends AbstractControlDriver<EntityId, MBlockShape> {
    static Logger log = LoggerFactory.getLogger(CharacterDriver.class);

    public static ScriptableDriver delegate;

    private EntityData ed;
    private CharacterType type;
    private double[] angles = new double[3];
    private EntityId id;
    private RigShape rig;
    private AnimPump animPump;
    private double speed;

    public CharacterDriver( EntityData ed, EntityId id ) {
        this.ed = ed;
        this.id = id;
    }

    public EntityId getId() {
        return id;
    }

    public RigidBody<EntityId,MBlockShape> getRigidBody() {
        return super.getBody();
    }

    public void setSpeed( double speed ) {
        this.speed = speed;
        if( delegate != null ) {
            try {
                delegate.setSpeed(this, speed);
            } catch( Exception e ) {
                log.error("Error calling delegate", e);
                delegate = null;
            }
        }
    }

    public void setType( CharacterType type ) {
        log.info("setType(" + type + ")");
        this.type = type;
    }

    public CharacterType getType() {
        return type;
    }

    @Override
    public void initialize( RigidBody<EntityId,MBlockShape> body ) {
        super.initialize(body);
        //this.id = body.id;
        if( !Objects.equals(id, body.id) ) {
            throw new IllegalArgumentException("Body id:" + body.id + " does not match driver ID:" + id);
        }
        this.rig = (RigShape)body.shape;

        this.animPump = new AnimPump(rig, null);
        animPump.setCurrentAction("Idle", 1);
        rig.update();
    }

    @Override
    public void terminate( RigidBody<EntityId,MBlockShape> body ) {
        super.terminate(body);
    }

    /**
     *  Default implementation does nothing.
     */
    @Override
    public void newContact( Contact<EntityId,MBlockShape> contact ) {
        if( delegate != null ) {
            try {
                delegate.newContact(this, contact);
            } catch( Exception e ) {
                log.error("Error calling delegate", e);
                delegate = null;
            }
        }
    }

    public void update( long frameTime, double step ) {

        // Kill any non-yaw orientation
        RigidBody<EntityId,MBlockShape> body = getBody();
        body.orientation.toAngles(angles);
        if( angles[0] != 0 || angles[2] != 0 ) {
            angles[0] = 0;
            angles[2] = 0;
            body.orientation.fromAngles(angles);
        }

        Vec3d rot = body.getRotationalVelocity();
        if( rot.x != 0 || rot.z != 0 ) {
            rot.x = 0;
            //rot.y *= 0.95; // Let's see if we can dampen the spinning
            rot.z = 0;

            // Don't really need to set it back but just in case
            body.setRotationalVelocity(rot);
        }

        if( delegate != null ) {
            try {
                delegate.update(this, frameTime, step);
            } catch( Exception e ) {
                log.error("Error calling delegate", e);
                delegate = null;
            }
        } else {
            //rig.setTime(null, 0.0);
            //    public void setTime( double time ) {
            //animPump.setTime(0.0);
        }

        animPump.update(step);
        rig.update();
        ed.setComponent(id, new CharAnimation(animPump.getCurrentAction(), animPump.getTime()));

//System.out.println("******** UprightDriver body temp:" + body.getTemperature());
//body.setTemperature(1);
        body.wakeUp(true);
    }
}


