/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.io.*;
import com.google.gson.*;

import com.jme3.anim.*;
import com.jme3.anim.interpolator.*;
import com.jme3.animation.*;
import com.jme3.math.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class AnimComposerDebug {
    static Logger log = LoggerFactory.getLogger(AnimComposerDebug.class);
    
    private static Gson animGson = createAnimGson();
    private static Gson skinGson = createSkinGson();
    
    private static Gson createAnimGson() {
    
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        gsonBuilder.serializeSpecialFloatingPointValues();
        
        IndexedExclusionStrategy index = new IndexedExclusionStrategy();                   
        gsonBuilder.addSerializationExclusionStrategy(index);
 
        gsonBuilder.registerTypeAdapter(CompactQuaternionArray.class, new JsonSerializer<CompactQuaternionArray>() {
                public JsonElement serialize( CompactQuaternionArray src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {
                    JsonArray result = new JsonArray();
                    for( Quaternion q : src.toObjectArray() ) {
                        //result.add(String.valueOf(q));
                        result.add(context.serialize(q));
                    }
                    return result; 
                } 
            });
        gsonBuilder.registerTypeAdapter(CompactVector3Array.class, new JsonSerializer<CompactVector3Array>() {
                public JsonElement serialize( CompactVector3Array src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {
                    JsonArray result = new JsonArray();
                    for( Vector3f v : src.toObjectArray() ) {
                        //result.add(String.valueOf(v));
                        result.add(context.serialize(v));
                    }
                    return result; 
                } 
            });
        gsonBuilder.registerTypeAdapter(AnimInterpolator.class, new JsonSerializer<AnimInterpolator>() {
                public JsonElement serialize( AnimInterpolator src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    String val = AnimComposerDebug.toString(src);
                    return new JsonPrimitive(val);
                } 
            });
        gsonBuilder.registerTypeAdapter(Vector3f.class, new JsonSerializer<Vector3f>() {
                public JsonElement serialize( Vector3f src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive("vec3" + src);
                } 
            });
        gsonBuilder.registerTypeAdapter(Quaternion.class, new JsonSerializer<Quaternion>() {
                public JsonElement serialize( Quaternion src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive("quat" + src);
                } 
            });
        gsonBuilder.registerTypeAdapter(Joint.class, new JsonSerializer<Joint>() {
                public JsonElement serialize( Joint src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive("joint[" + src.getName() + "@" + src.getId() + "]");
                } 
            });
        gsonBuilder.registerTypeAdapter(Class.class, new JsonSerializer<Class>() {
                public JsonElement serialize( Class src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive(String.valueOf(src));
                } 
            });
        gsonBuilder.registerTypeAdapter(Matrix4f.class, new JsonSerializer<Matrix4f>() {
                public JsonElement serialize( Matrix4f src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    JsonArray result = new JsonArray();
                    result.add("[" + src.m00 + "][" + src.m01 + "][" +  src.m02 + "][" + src.m03 + "]");
                    result.add("[" + src.m10 + "][" + src.m11 + "][" +  src.m12 + "][" + src.m13 + "]");
                    result.add("[" + src.m20 + "][" + src.m21 + "][" +  src.m22 + "][" + src.m23 + "]");
                    result.add("[" + src.m30 + "][" + src.m31 + "][" +  src.m32 + "][" + src.m33 + "]");
                    return result;
                } 
            });

 
        return gsonBuilder.create();           
    }

    private static Gson createSkinGson() {
    
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        gsonBuilder.serializeSpecialFloatingPointValues();
        
        IndexedExclusionStrategy index = new IndexedExclusionStrategy();                   
        gsonBuilder.addSerializationExclusionStrategy(index);
 
        gsonBuilder.registerTypeAdapter(CompactQuaternionArray.class, new JsonSerializer<CompactQuaternionArray>() {
                public JsonElement serialize( CompactQuaternionArray src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {
                    JsonArray result = new JsonArray();
                    for( Quaternion q : src.toObjectArray() ) {
                        //result.add(String.valueOf(q));
                        result.add(context.serialize(q));
                    }
                    return result; 
                } 
            });
        gsonBuilder.registerTypeAdapter(CompactVector3Array.class, new JsonSerializer<CompactVector3Array>() {
                public JsonElement serialize( CompactVector3Array src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {
                    JsonArray result = new JsonArray();
                    for( Vector3f v : src.toObjectArray() ) {
                        //result.add(String.valueOf(v));
                        result.add(context.serialize(v));
                    }
                    return result; 
                } 
            });
        gsonBuilder.registerTypeAdapter(AnimInterpolator.class, new JsonSerializer<AnimInterpolator>() {
                public JsonElement serialize( AnimInterpolator src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    String val = AnimComposerDebug.toString(src);
                    return new JsonPrimitive(val);
                } 
            });
        gsonBuilder.registerTypeAdapter(Vector3f.class, new JsonSerializer<Vector3f>() {
                public JsonElement serialize( Vector3f src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive("vec3" + src);
                } 
            });
        gsonBuilder.registerTypeAdapter(Quaternion.class, new JsonSerializer<Quaternion>() {
                public JsonElement serialize( Quaternion src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive("quat" + src);
                } 
            });
        gsonBuilder.registerTypeAdapter(Class.class, new JsonSerializer<Class>() {
                public JsonElement serialize( Class src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    return new JsonPrimitive(String.valueOf(src));
                } 
            });
        gsonBuilder.registerTypeAdapter(Matrix4f.class, new JsonSerializer<Matrix4f>() {
                public JsonElement serialize( Matrix4f src, java.lang.reflect.Type typeOfSrc, JsonSerializationContext context ) {                
                    JsonArray result = new JsonArray();
                    String format = "[%9.05f, %9.05f, %9.05f, %9.05f]"; 
                    result.add(String.format(format, src.m00, src.m01, src.m02, src.m03)); 
                    result.add(String.format(format, src.m10, src.m11, src.m12, src.m13)); 
                    result.add(String.format(format, src.m20, src.m21, src.m22, src.m23)); 
                    result.add(String.format(format, src.m30, src.m31, src.m32, src.m33)); 
                    return result;
                } 
            });
 
        return gsonBuilder.create();           
    }
    
    /**
     *  Writes essentially unreadable JSON for debug/viewing purposes.
     */   
    public static void writeJson( AnimComposer anim, File f ) {
         
        try {
            log.info("Storing:" + f);
            FileWriter out = new FileWriter(f);
            try {
                animGson.toJson(anim, out);
            } finally {
                out.close();
            } 
        } catch( java.io.IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }

    /**
     *  Writes essentially unreadable JSON for debug/viewing purposes.
     */   
    public static void writeJson( SkinningControl skin, File f ) {
         
        try {
            log.info("Storing:" + f);
            FileWriter out = new FileWriter(f);
            try {
                skinGson.toJson(skin, out);
            } finally {
                out.close();
            } 
        } catch( java.io.IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }

    public static String toString( AnimInterpolator ai ) {
        //if( ai == AnimInterpolators.NLerp ) {
        //    return "NLerp";
        //}
        //if( ai == AnimInterpolators.SLerp ) {
        //    return "SLerp";
        //}
        //if( ai == AnimInterpolators.SQuad ) { 
        //    return "SQuad";
        //}
        //if( ai == AnimInterpolators.LinearVec3f ) {
        //    return "LinearVec3f";
        //}
        return String.valueOf(ai);
    }
     
    public static class IndexedExclusionStrategy implements ExclusionStrategy {
        public boolean shouldSkipClass(Class<?> clazz) {
            log.info("shouldSkipClass(" + clazz + ")");
            // Temporarily skip arrays to find our endless loop
            //if( clazz.isArray() ) {
            //    log.info("  skipping:" + clazz);
            //    return true;
            //}
            if( clazz == com.jme3.scene.Spatial.class ) {
                log.info("  skipping Spatial.class");
                return true;
            }
            if( com.jme3.scene.Spatial.class.isAssignableFrom(clazz) ) {
                log.info("  skipping:" + clazz);
                return true;
            }
            if( String.valueOf(clazz).indexOf("com.jme3.scene.Spatial") >= 0 ) {
                log.info("  skipping Spatial inner class/enum");
                return true;
            }
            // If we do all of that, I don't know why we also need these
            if( clazz == com.jme3.light.LightList.class ) {
                log.info("  skipping:" + clazz);
                return true;
            }   
            if( clazz == com.jme3.light.Light.class ) {
                log.info("  skipping:" + clazz);
                return true;
            }   
            return false;
        }

        public boolean shouldSkipField(FieldAttributes f) {
            log.info("shouldSkipField(" 
                    + "declaredType:" + f.getDeclaredType() 
                    + ", declaredClass:" + f.getDeclaredClass()
                    + ", declaringClass:" + f.getDeclaringClass() 
                    + ", name:" + f.getName() + ")");
            if( f.hasModifier(java.lang.reflect.Modifier.STATIC) ) {
                log.info("  skipping static field");
                return true;
            }
            if( f.getDeclaringClass() == com.jme3.scene.control.AbstractControl.class
                && "spatial".equals(f.getName()) ) {
                log.info("  skipping control 'spatial'");
                return true;                        
            }
            // Avoid an endless recursive loop
            if( "com.jme3.anim.AnimComposer$Layer".equals(f.getDeclaringClass().getName())
                && "ac".equals(f.getName()) ) {
                log.info("  skipping Layer.ac");
                return true;                        
            }
            String id = f.getDeclaringClass().getName() + ":" + f.getName();
            log.info("checking:" + id);
            if( "com.jme3.anim.interpolator.FrameInterpolator:translationReader".equals(id) ) {
                return true;
            } 
            if( "com.jme3.anim.interpolator.FrameInterpolator:rotationReader".equals(id) ) {
                return true;
            } 
            if( "com.jme3.anim.interpolator.FrameInterpolator:scaleReader".equals(id) ) {
                return true;
            } 
            if( "com.jme3.anim.interpolator.FrameInterpolator:timesReader".equals(id) ) {
                return true;
            } 
            if( "com.jme3.anim.interpolator.FrameInterpolator:transforms".equals(id) ) {
                return true;
            } 
            if( "com.jme3.anim.SkinningControl:targets".equals(id) ) {
                return true;
            }
            if( "com.jme3.anim.Joint:parent".equals(id) ) {
                return true;
            }            
            return false;
        }                
    }    
}

