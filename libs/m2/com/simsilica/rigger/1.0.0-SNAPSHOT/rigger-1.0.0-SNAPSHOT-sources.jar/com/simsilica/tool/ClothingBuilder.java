/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

import com.simsilica.mblock.*;

/**
 *  Kind of a placeholder until I figure out what I actually need
 *  but this is to encapsulate the overall clothing CellArray
 *  and mapping to textures that can be used on the rig.
 *
 *  @author    Paul Speed
 */
public class ClothingBuilder implements VersionedObject<ClothingBuilder> {
    static Logger log = LoggerFactory.getLogger(ClothingBuilder.class);
    
    private CellArray swatches;
    private int[][] levels;
    private long version;
    
    public ClothingBuilder( int width, int height, int layers ) {
        this.swatches = new CellArray(width, height, layers);
        this.levels = new int[width][height];
    }

    public static int toCell( int shape, int fabric ) {
        return (shape << 16) | fabric;
    }

    public static int toShape( int value ) {
        return (value >> 16) & 0xffff;
    }
    
    public static int toFabric( int value ) {
        return value & 0xffff;
    }

    public void clear() {
        swatches.clear(0);
        for( int i = 0; i < 32; i++ ) {
            for( int j = 0; j < 32; j++ ) {
                levels[i][j] = 0;
            }
        }
    }

    public int getValue( int x, int y, int layer ) {
        return swatches.getCell(x, y, layer);
    }

    public void setCells( CellArray source ) {
        if( source == null ) {
            return;
        }
        swatches.set(source);
        
        // Calculate the levels
        for( int i = 0; i < 32; i++ ) {
            for( int j = 0; j < 32; j++ ) {
                int level = 0;                
                for( int k = 0; k < 32; k++ ) {
                    if( swatches.getCell(i, j, k) != 0 ) {
                        level++;
                    }
                }
                levels[i][j] = level;
            }
        }
    }

    public CellArray getCells() {
        return swatches;
    }
    
    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public ClothingBuilder getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<ClothingBuilder> createReference() {
        return new VersionedReference<>(this);
    }
    
    public int getLayer( int x, int y ) {
        return levels[x][y];
    }

    public boolean addSwatch( int x, int y, int shape, int fabric ) {
        log.info("addSwatch(" + x + ", " + y + ", " + shape + ", " + fabric + ")");
        if( x < 0 || x >= 32 || y < 0 || y >= 32 ) {
            return false;
        }
        int value = toCell(shape, fabric);
        return addValue(x, y, value);
    }
    
    protected boolean addValue( int x, int y, int value ) {
 
        int layer = levels[x][y];
        if( layer >= 32 ) {
            return false;
        }
        
        // If it's the same as the existing shape then assume it's a mistake
        if( layer > 0 && swatches.getCell(x, y, layer-1) == value ) {
            return false;
        }
        
        swatches.setCell(x, y, layer, value);
        version++;
        levels[x][y] = layer + 1;
        return true; 
    }
    
    public int removeSwatch( int x, int y ) {
        log.info("removeSwatch(" + x + ", " + y + ")");
        int layer = levels[x][y];
        if( layer <= 0 ) {
            return 0;
        }
        layer--;
        int existing = swatches.getCell(x, y, layer);
        if( existing != 0 ) {
            swatches.setCell(x, y, layer, 0);
            version++;
        }
        levels[x][y] = layer;
        return existing;
    }    
}

