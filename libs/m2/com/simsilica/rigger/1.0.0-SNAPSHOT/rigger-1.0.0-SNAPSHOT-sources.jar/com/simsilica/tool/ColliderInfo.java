/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ColliderInfo implements VersionedObject<ColliderInfo> {
    static Logger log = LoggerFactory.getLogger(ColliderInfo.class);

    private transient long version;

    private String shape;
    private double scale = 0.1;
    private String joint;
    private Vec3d offset = new Vec3d();
    private Quatd orientation = new Quatd();

    public ColliderInfo() {
    }

    public com.simsilica.crig.ColliderInfo convert( ColliderShapes shapes ) {
        com.simsilica.crig.ColliderInfo result = new com.simsilica.crig.ColliderInfo();
        result.setShape(shapes.getCells(shape));
        result.setScale(scale);
        result.setJoint(joint);
        result.setOffset(offset);
        result.setOrientation(orientation);
        return result;
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public ColliderInfo getObject() {
        return this;
    }

    @Override
    public VersionedReference<ColliderInfo> createReference() {
        return new VersionedReference<>(this);
    }

    public void setShape( String shape ) {
        this.shape = shape;
        version++;
    }

    public String getShape() {
        return shape;
    }

    public void setScale( double scale ) {
        this.scale = scale;
        version++;
    }

    public double getScale() {
        return scale;
    }

    public void setJoint( String joint ) {
        this.joint = joint;
        version++;
    }

    public String getJoint() {
        return joint;
    }

    public void setOffset( Vec3d offset ) {
        this.offset.set(offset);
        version++;
    }

    public Vec3d getOffset() {
        return offset;
    }

    public void setOrientation( Quatd orientation ) {
        this.orientation.set(orientation);
        version++;
    }

    public Quatd getOrientation() {
        return orientation;
    }

    public String toString() {
        return "ColliderInfo[" + joint + ":" + shape + "]";
    }
}
