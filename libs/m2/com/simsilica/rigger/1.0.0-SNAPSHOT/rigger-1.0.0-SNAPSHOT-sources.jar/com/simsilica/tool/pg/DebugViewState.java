/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.control.BillboardControl;
import com.jme3.scene.shape.*;
import com.jme3.scene.debug.Arrow;
import com.jme3.util.SafeArrayList;

import com.simsilica.bpos.*;
import com.simsilica.es.*;
import com.simsilica.ext.mphys.*;
import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DebugViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(DebugViewState.class);

    private Node debugRoot = new Node("debugRoot");
    private EntityData ed;

    private Container main;
    private Container toggles;

    private float lineWidth = 2;

    private Map<String, Layer> layerIndex = new HashMap<>();
    private VersionedList<Layer> layers = new VersionedList<>();
    private VersionedReference<List<Layer>> layersRef = layers.createReference();
    private SafeArrayList<Layer> layerArray = new SafeArrayList<>(Layer.class);

    private RootContainer roots;
    private StaticRootContainer staticRoots;
    private AttachmentContainer attachments;
    private DebugShapeContainer shapes;
    private DebugTextContainer labels;
    private BatchNode shapeBatch = new BatchNode("shapeBatch");
    private boolean needsRebatch = false;

    private Map<EntityId, RootView> rootIndex = new HashMap<>();

    private Set<RootView> newRoots = new HashSet<>();

    private float translucentAlpha = 0.1f;

    public DebugViewState( Container main ) {
        this.main = main;
        this.toggles = new Container();
        RollupPanel rollup = main.addChild(new RollupPanel("Layer Toggles", toggles, null));
        rollup.setOpen(false);
    }

    public void setLineWidth( float lineWidth ) {
        this.lineWidth = lineWidth;
    }

    public float getLineWidth() {
        return lineWidth;
    }

    public Layer getLayer( String layer ) {
        return getLayer(layer, false);
    }

    public VersionedList<Layer> getLayers() {
        return layers;
    }

    protected Layer getLayer( String layer, boolean create ) {
        if( layer == null ) {
            return null;
        }
        Layer result = layerIndex.get(layer);
        if( result == null && create ) {
            result = new Layer(layer);
            layerIndex.put(layer, result);
            layers.add(result);
            layerArray.add(result);
        }
        return result;
    }

    @Override
    protected void initialize( Application app ) {
        this.ed = getState(GameSystemState.class).get(EntityData.class, true);
        this.roots = new RootContainer(ed);
        this.staticRoots = new StaticRootContainer(ed);
        this.attachments = new AttachmentContainer(ed);
        this.shapes = new DebugShapeContainer(ed);
        this.labels = new DebugTextContainer(ed);

        debugRoot.attachChild(shapeBatch);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        roots.start();
        staticRoots.start();
        attachments.start();
        shapes.start();
        labels.start();
        getState(WorldViewState.class).getWorldRoot().attachChild(debugRoot);
    }

    @Override
    protected void onDisable() {
        labels.stop();
        shapes.stop();
        attachments.stop();
        roots.stop();
        staticRoots.stop();
        debugRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        roots.update();
        staticRoots.update();
        attachments.update();
        shapes.update();
        labels.update();

        if( layersRef.update() ) {
            updateLayers();
        }

        if( !newRoots.isEmpty() ) {
            hookupRoots(newRoots);
            newRoots.clear();
        }

        for( RootView root : roots.getArray() ) {
            root.update();
        }
        for( RootView root : staticRoots.getArray() ) {
            root.update();
        }

        for( AttachmentView attachment : attachments.getArray() ) {
            attachment.update();
        }

        if( needsRebatch ) {
            //log.info("batch()");
            shapeBatch.batch();
            needsRebatch = false;
        }

        for( Layer layer : layerArray.getArray() ) {
            layer.update();
        }
    }

    protected void hookupRoots( Set<RootView> roots ) {
        // When new roots are added, we need to see if there are any attachments
        // that already refer to those enties and force them to hook up
        for( RootView root : roots ) {
            for( AttachmentView attachment : attachments.getArray() ) {
                if( attachment.parent != null || attachment.att == null ) {
                    continue;
                }
                if( Objects.equals(attachment.att.getParent(), root.entityId) ) {
                    //log.info("Hooking up attachment:" + attachment);
                    attachment.updateData();
                }
            }
        }
    }

    protected void updateLayers() {
        toggles.clearChildren();
        for( Layer layer : layers ) {
            //Checkbox check = new Checkbox(layer.getName());
            //check.setModel(layer);
            toggles.addChild(layer.checkbox);
        }
    }

    protected Spatial createShape( EntityId id, DebugShape shape ) {
        Mesh mesh;
        Vec3d size = shape.getSize();
        boolean wire = false;
        switch( shape.getType() ) {
            case Arrow:
                mesh = new Arrow(size.toVector3f());
                wire = true;
                break;
            case Box:
                mesh = new Box((float)size.x, (float)size.y, (float)size.z);
                break;
            case Sphere:
            default:
                mesh = new Sphere(8, 12, (float)size.x);
                break;
        }
        Geometry geom = new Geometry(shape.getType() + ":" + id, mesh);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(shape.getColor(), shape.isLit()).getMaterial());
        if( shape.getColor().a < 1 ) {
            geom.setQueueBucket(Bucket.Transparent);
            LayerComparator.setLayer(geom, 5);
            geom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        }
        if( shape.isWireframe() ) {
            geom.getMaterial().getAdditionalRenderState().setWireframe(true);
            wire = true;
        }
        if( wire ) {
            geom.getMaterial().getAdditionalRenderState().setLineWidth(lineWidth);
        }
        if( !Vector3f.isValidVector(geom.getWorldBound().getCenter()) ) {
            log.error("Bad geom:" + geom + " for shape:" + shape);
        }
        return geom;
    }

    protected RootView getRootView( EntityId id, boolean create ) {
        RootView result = rootIndex.get(id);
        if( result == null && create ) {
            result = new RootView(id);
            rootIndex.put(id, result);
        }
        return result;
    }

    protected ParentView getParentView( EntityId id ) {
        //ParentView result = roots.getObject(id);
        ParentView result = rootIndex.get(id);
        if( result != null ) {
            return result;
        }
        return attachments.getObject(id);
    }

    public static class Layer implements CheckboxModel {
        private String name;
        private VersionedHolder<Boolean> visible;
        private VersionedList<LayeredView> children = new VersionedList<>();
        private VersionedReference<List<LayeredView>> childRef = children.createReference();
        private Checkbox checkbox;

        public Layer( String name ) {
            this.name = name;
            this.visible = new VersionedHolder<>(true);
            this.checkbox = new Checkbox(name);
            checkbox.setModel(this);
        }

        public String getName() {
            return name;
        }

        @Override
        public long getVersion() {
            return visible.getVersion();
        }

        @Override
        public Boolean getObject() {
            return visible.getObject();
        }

        @Override
        public VersionedReference<Boolean> createReference() {
            return visible.createReference();
        }

        public void setVisible( boolean visible ) {
            if( this.visible.updateObject(visible) ) {
                for( LayeredView view : children ) {
                    view.setVisible(visible);
                }
            }
        }

        public boolean isVisible() {
            return visible.getObject();
        }

        public boolean isChecked() {
            return isVisible();
        }

        public void setChecked( boolean b ) {
            setVisible(b);
        }

        public int getObjectCount() {
            return children.size();
        }

        protected void update() {
            if( childRef.update() ) {
                checkbox.setText(String.format("%s (%,d)", name, children.size()));
            }
        }

        protected void addChild( LayeredView view ) {
            children.add(view);
        }

        protected void removeChild( LayeredView view ) {
            children.remove(view);
        }
    }

    protected interface ParentView {
        public Node acquire( Object holder );
        public void release( Object holder );
    }

    // Anything with a position that might get something attached to it.
    protected class RootView implements ParentView {
        private EntityId entityId;
        private BodyPosition bPos;
        private SpawnPosition staticPos;
        private Node root;
        private int useCount;

        public RootView( EntityId entityId ) {
            this.entityId = entityId;
            newRoots.add(this);
        }

        @Override
        public Node acquire( Object holder ) {
            useCount++;
            if( root == null ) {
                root = new Node("root:" + entityId);
                //debugRoot.attachChild(root);
                shapeBatch.attachChild(root);
                needsRebatch = true;
                //updateData();
                updatePosition();
            }
            return root;
        }

        @Override
        public void release( Object holder ) {
            useCount--;
            if( useCount <= 0 && root != null ) {
                root.removeFromParent();
                needsRebatch = true;
                root = null;
            }
        }

        public void update() {
        }

        protected void updatePosition() {
            if( root == null ) {
                return;
            }
            if( bPos != null ) {
                root.setLocalTranslation(bPos.getLastLocation().toVector3f());
                root.setLocalRotation(bPos.getLastOrientation().toQuaternion());
            }
            if( staticPos != null ) {
                root.setLocalTranslation(staticPos.getLocation().toVector3f());
                root.setLocalRotation(staticPos.getOrientation().toQuaternion());
            }
        }

        protected void update( BodyPosition bPos ) {
            this.bPos = bPos;
            updatePosition();
        }

        protected void update( SpawnPosition staticPos ) {
            this.staticPos = staticPos;
            updatePosition();
        }

        //protected void updateData( Entity entity ) {
        //    BodyPosition pos = entity.get(BodyPosition.class);
        //    if( pos != null ) {
        //
        //    }
        //    if( root == null ) {
        //        return;
        //    }
        //    BodyPosition pos = entity.get(BodyPosition.class);
        //    if( pos == null ) {
        //        return;
        //    }
        //    root.setLocalTranslation(pos.getLastLocation().toVector3f());
        //    root.setLocalRotation(pos.getLastOrientation().toQuaternion());
        //}

        protected void remove() {
            if( root != null ) {
                root.removeFromParent();
            }
            newRoots.remove(this);
            rootIndex.remove(entityId);
        }

        protected void checkRemove() {
            if( bPos == null && staticPos == null ) {
                remove();
            }
        }
    }

    protected class AttachmentView implements ParentView {
        private Entity entity;
        private ParentView parent;
        private AttachedTo att;
        private Node parentNode;
        private Node root;
        private int useCount;
        private List<Object> holders = new ArrayList<>();

        public AttachmentView( Entity entity ) {
            this.entity = entity;
            this.root = new Node("attachment:" + entity.getId());
        }

        @Override
        public Node acquire( Object holder ) {
            useCount++;
            holders.add(holder);
            return root;
        }

        @Override
        public void release( Object holder ) {
            holders.remove(holder);
            useCount--;
        }

        public void update() {
        }

        protected void setParent( ParentView parent ) {
            //log.info("AttachmentView.setParent(" + parent + ")");
            if( this.parent == parent ) {
                return;
            }
            if( this.parent != null ) {
                parent.release(entity.getId());
                parentNode = null;
                root.removeFromParent();
                //log.info("AttachmentView.setParent() attachmentView:" + entity.getId() + " removed");
            }
            this.parent = parent;
            if( this.parent != null ) {
                parentNode = parent.acquire(entity.getId());
                parentNode.attachChild(root);
                //log.info("AttachmentView.setParent() attachmentView:" + entity.getId() + " attached at:" + root.getWorldTranslation());
            }
        }

        protected void updateData() {
            this.att = entity.get(AttachedTo.class);
            setParent(getParentView(att.getParent()));

            if( att.getOffset() != null ) {
                root.setLocalTranslation(att.getOffset().toVector3f());
            } else {
                root.setLocalTranslation(Vector3f.ZERO);
            }
            if( useCount > 0 ) {
                //log.info("AttachmentView.updateDate() attachmentView:" + entity.getId() + " local:" + root.getLocalTranslation() + " world:" + root.getWorldTranslation());
                //log.info("holders:" + holders);
            }
            if( att.getRotation() != null ) {
                root.setLocalRotation(att.getRotation().toQuaternion());
            } else {
                root.setLocalRotation(Quaternion.IDENTITY);
            }
        }

        protected void remove() {
            //log.info("AttachmentView.remove()");
            root.removeFromParent();
            if( this.parent != null ) {
                parent.release(entity.getId());
            }
        }
    }

    protected abstract class LayeredView {
        private Layer layer;
        private boolean visible = true;

        protected void setLayer( String layerName ) {
            if( this.layer != null ) {
                this.layer.removeChild(this);
            }
            this.layer = DebugViewState.this.getLayer(layerName, true);
            if( this.layer != null ) {
                this.layer.addChild(this);
                setVisible(layer.isVisible());
            }
        }

        public void setVisible( boolean visible ) {
            if( this.visible == visible ) {
                return;
            }
            this.visible = visible;
            updateVisibility();
       }

        public Layer getLayer() {
            return layer;
        }

        public boolean isVisible() {
            return visible;
        }

        protected void updateVisibility() {
            if( visible ) {
                onVisible();
            } else {
                onInvisible();
            }
        }

        protected abstract void onVisible();
        protected abstract void onInvisible();
    }

    protected class ShapeView extends LayeredView {
        private Entity entity;
        private ParentView parent;
        private Node parentNode;
        private Spatial shape;
        private Spatial transShape;
        private boolean visible = true;

        public ShapeView( Entity entity ) {
            this.entity = entity;
        }

        protected void setParent( ParentView parent ) {
            if( this.parent == parent ) {
                return;
            }
            if( this.parent != null ) {
                //parent.release();
                parentNode = null;
                onInvisible();
            }
            this.parent = parent;
            if( this.parent != null ) {
                //parentNode = parent.acquire(entity.getId());
                updateVisibility();
            }
        }

        protected void setShape( Spatial shape ) {
            if( this.shape == shape ) {
                return;
            }
            if( this.shape != null ) {
                this.shape.removeFromParent();
                this.transShape.removeFromParent();
                this.transShape = null;
            }
            this.shape = shape;
            if( this.shape != null ) {
                if( shape instanceof Geometry ) {
                    Geometry geom = (Geometry)shape.clone(true);
                    geom.setQueueBucket(Bucket.Translucent);
                    Material mat = geom.getMaterial();
                    mat.getAdditionalRenderState().setDepthTest(false);
                    mat.getAdditionalRenderState().setDepthWrite(false);
                    mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

                    MatParam colorParam = mat.getParam("Diffuse");
                    if( colorParam == null ) {
                        colorParam = mat.getParam("Color");
                    }
                    ColorRGBA existing = (ColorRGBA)colorParam.getValue();
                    ColorRGBA trans = existing.clone();
                    trans.a *= translucentAlpha;
                    colorParam.setValue(trans);

                    this.transShape = geom;
                }
                updateVisibility();
            }
        }

        protected void updateData() {
            setParent(getParentView(entity.getId()));
            DebugShape debugShape = entity.get(DebugShape.class);
            setLayer(debugShape.getLayer());
            setShape(createShape(entity.getId(), debugShape));
        }

        @Override
        protected void onVisible() {
            if( parentNode == null ) {
                parentNode = parent.acquire(entity.getId());
            }
            if( shape == null ) {
                return;
            }
            if( parentNode != null ) {
                parentNode.attachChild(shape);
                //log.info("attached:" + shape + " to parent:" + parentNode + " at world:" + shape.getWorldTranslation());
                if( transShape != null ) {
                    parentNode.attachChild(transShape);
                }
                needsRebatch = true;
            }
        }

        @Override
        protected void onInvisible() {
            if( this.parent != null ) {
                parent.release(entity.getId());
                parentNode = null;
            }
            if( this.shape != null ) {
                //log.info("detaching:" + shape + " from parent:" + shape.getParent());
                shape.removeFromParent();
                needsRebatch = true;
            }
            if( this.transShape != null ) {
                transShape.removeFromParent();
            }
        }

        protected void remove() {
            setVisible(false);
            setLayer(null);
        }
    }

    protected class TextView extends LayeredView {
        private Entity entity;
        private ParentView parent;
        private Node parentNode;
        private Node labelNode; // so billboarding works right, ugh
        private Label label;

        public TextView( Entity entity ) {
            this.entity = entity;
            this.label = new Label("");
            label.setInsets(null);
            //label.setBackground(new QuadBackgroundComponent(ColorRGBA.Red));

            this.labelNode = new Node("label:" + entity.getId());
            labelNode.attachChild(label);
            labelNode.addControl(new BillboardControl());
        }

        protected void setParent( ParentView parent ) {
            if( this.parent == parent ) {
                return;
            }
            if( this.parent != null ) {
                onInvisible();
            }
            this.parent = parent;
            if( this.parent != null ) {
                updateVisibility();
            }
        }

        protected void updateData() {
            setParent(getParentView(entity.getId()));
            DebugText dt = entity.get(DebugText.class);
            setLayer(dt.getLayer());
            label.setText(dt.getText());
            label.setFontSize((float)dt.getSize());
            label.setColor(dt.getColor());
            Vector3f pref = label.getPreferredSize();
            label.setLocalTranslation(-pref.x * 0.5f, 0, 0);
        }

        @Override
        protected void onVisible() {
            if( parentNode == null ) {
                parentNode = parent.acquire(entity.getId());
            }
            if( labelNode == null ) {
                return;
            }
            if( parentNode != null ) {
                parentNode.attachChild(labelNode);
            }
        }

        @Override
        protected void onInvisible() {
            if( this.parent != null ) {
                parent.release(entity.getId());
                parentNode = null;
            }
            if( labelNode != null ) {
                labelNode.removeFromParent();
            }
        }

        protected void remove() {
            setVisible(false);
            setLayer(null);
        }
    }

    protected class RootContainer extends EntityContainer<RootView> {
        public RootContainer( EntityData ed ) {
            super(ed, BodyPosition.class);
        }

        public RootView[] getArray() {
            return super.getArray();
        }

        protected RootView addObject( Entity entity ) {
            //log.info("addRoot(" + entity + ")");
            //RootView result = new RootView(entity);
            RootView result = getRootView(entity.getId(), true);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( RootView object, Entity entity ) {
            //object.updateData();
            object.update(entity.get(BodyPosition.class));
        }

        protected void removeObject( RootView object, Entity entity ) {
            //log.info("removeRoot(" + entity + ")");
            //object.remove();
            object.update((BodyPosition)null);
            object.checkRemove();
        }
    }

    protected class StaticRootContainer extends EntityContainer<RootView> {
        public StaticRootContainer( EntityData ed ) {
            super(ed, SpawnPosition.class);
        }

        public RootView[] getArray() {
            return super.getArray();
        }

        protected RootView addObject( Entity entity ) {
            //log.info("addStaticRoot(" + entity + ")");
            //RootView result = new RootView(entity);
            RootView result = getRootView(entity.getId(), true);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( RootView object, Entity entity ) {
            //object.updateData();
            object.update(entity.get(SpawnPosition.class));
        }

        protected void removeObject( RootView object, Entity entity ) {
            //log.info("removeRoot(" + entity + ")");
            //object.remove();
            object.update((SpawnPosition)null);
            object.checkRemove();
        }
    }

    protected class AttachmentContainer extends EntityContainer<AttachmentView> {
        public AttachmentContainer( EntityData ed ) {
            super(ed, AttachedTo.class);
        }

        public AttachmentView[] getArray() {
            return super.getArray();
        }

        protected AttachmentView addObject( Entity entity ) {
            //log.info("addAttachment(" + entity + ")");
            AttachmentView result = new AttachmentView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( AttachmentView object, Entity entity ) {
            object.updateData();
        }

        protected void removeObject( AttachmentView object, Entity entity ) {
            //log.info("removeAttachment(" + entity + ")");
            object.remove();
        }
    }

    protected class DebugShapeContainer extends EntityContainer<ShapeView> {
        public DebugShapeContainer( EntityData ed ) {
            super(ed, DebugShape.class);
        }

        public ShapeView[] getArray() {
            return super.getArray();
        }

        protected ShapeView addObject( Entity entity ) {
            //log.info("addDebugShape(" + entity + ")");
            ShapeView result = new ShapeView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( ShapeView object, Entity entity ) {
            object.updateData();
        }

        protected void removeObject( ShapeView object, Entity entity ) {
            //log.info("removeDebugShape(" + entity + ")");
            object.remove();
        }
    }

    protected class DebugTextContainer extends EntityContainer<TextView> {
        public DebugTextContainer( EntityData ed ) {
            super(ed, DebugText.class);
        }

        public TextView[] getArray() {
            return super.getArray();
        }

        protected TextView addObject( Entity entity ) {
            //log.info("addDebugText(" + entity + ")");
            TextView result = new TextView(entity);
            updateObject(result, entity);
            return result;
        }

        protected void updateObject( TextView object, Entity entity ) {
            object.updateData();
        }

        protected void removeObject( TextView object, Entity entity ) {
            object.remove();
        }
    }
}
