/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.CellArray;

import com.simsilica.tool.io.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class CreateClothingDialog extends Container {
    static Logger log = LoggerFactory.getLogger(CreateClothingDialog.class);
 
    private ClothingState parent;
 
    private List<FabricInfo> fabrics;   
    private ClothingBuilder target;
    private EditHistory history;
    private ClothingFormat clothingFormat;
 
    private Selector<File> templateSelector;
    private Selector<FabricInfo> fabricSelector;    
    
    public CreateClothingDialog( ClothingState parent, ClothingBuilder target, EditHistory history, VersionedList<FabricInfo> fabrics, ClothingFormat clothingFormat ) {
        this.parent = parent;
        this.target = target;
        this.history = history;
        this.fabrics = fabrics;
        this.clothingFormat = clothingFormat;

        addChild(new Label("Create Clothing", new ElementId("window.title"), null));
            
        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        
        properties.addChild(new Label("Template:"));
        templateSelector = properties.addChild(new Selector<File>(new VersionedList<File>(findTemplates())), 1);
        
        properties.addChild(new Label("Fabric:"));
        fabricSelector = properties.addChild(new Selector<FabricInfo>(fabrics), 1);

        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "create")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));
    }
 
    protected void create() {
        File f = templateSelector.getSelectedItem();
        if( f == null ) {
            return;
        }
        try {
            CellArray cells = clothingFormat.readCells(new FileInputStream(f));
            
            log.info("Loaded:" + cells);
            
            int replace = fabricSelector.getSelectionModel().getSelection() + 1;
            
            CompositeEdit edit = new CompositeEdit();
            
            for( int i = 0; i < 32; i++ ) {
                for( int j = 0; j < 32; j++ ) {
                    for( int k = 0; k < 32; k++ ) {
                        int value = cells.getCell(i, j, k);
                        if( value == 0 ) {
                            break;
                        }
                        int shape = ClothingBuilder.toShape(value);
                        int fabric = ClothingBuilder.toFabric(value);
                        
                        // Right now there is no intellgence... just switch
                        // all non-0 fabrics to the selected one
                         
                        //target.addSwatch(i, j, shape, replace);
                        edit.addEdit(new AddSwatch(target, i, j, shape, replace)); 
                    }
                }
            }
 
            history.addEdit(edit);
            
            parent.repaint(true);
            
            removeFromParent();                        
        } catch( IOException e ) {
            String msg = "Error loading:" + f;  
            log.error(msg, e);  
            //getState(OptionPanelState.class).showError(msg, e);           
        } 
    }
    
    public void cancel() {
        removeFromParent();
    }
    
    public static List<File> findTemplates() {
        File root = RiggerConfig.getInstance().getProjectDir();
        root = new File(root, "templates");
        
        List<File> results = new ArrayList<>();
        for( File f : root.listFiles() ) {
            if( f.isDirectory() ) {
                continue;
            }
            if( !f.getName().endsWith(".clothing") ) {
                continue;
            }
            results.add(f);
        }
        
        return results;
    }
}
