/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.*;


/**
 *  Holds the different configuration information about a mode of
 *  movement (like walk, swim, fly, crouch, crawl, etc.).
 *
 *  @author    Paul Speed
 */
public class MovementMode implements VersionedObject<MovementMode> {
    static Logger log = LoggerFactory.getLogger(MovementMode.class);
 
    private long version;
    
    private String name;
    private VersionedList<MovementAnimation> basic = new VersionedList<>();
    private VersionedList<MovementAnimation> mix = new VersionedList<>();
    
    public MovementMode() {
    }
 
    public MovementMode( String name ) {
        this.name = name;
    }

    public static MovementMode createDefault( String name, String idleAnimation, String walkAnimation ) {
        MovementMode result = new MovementMode(name);
        result.basic.add(MovementAnimation.createDefault(idleAnimation, 0));
        result.basic.add(MovementAnimation.createDefault(walkAnimation, 1));
        return result;
    }
    
    public void setName( String name ) {
        this.name = name;
        version++;
    }
    
    public String getName() {
        return name;
    }
 
    public VersionedList<MovementAnimation> getBasicAnimation() {
        return basic;
    }

    public VersionedList<MovementAnimation> getMixAnimation() {
        return mix;
    }
    
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public MovementMode getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<MovementMode> createReference() {
        return new VersionedReference<>(this);
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + name + "]";
    }
}
