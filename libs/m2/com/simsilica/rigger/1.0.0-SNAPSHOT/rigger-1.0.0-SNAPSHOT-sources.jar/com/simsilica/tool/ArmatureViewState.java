/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.anim.*;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;

/**
 *  Shows the joints and "bones" connecting them.
 *
 *  @author    Paul Speed
 */
public class ArmatureViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ArmatureViewState.class);

    private VersionedReference<Rig> rigRef;
    private Rig rig;

    private Node modelRoot;
    private SkinningControl skin;
    private Armature armature;

    private Map<Joint, View> viewIndex = new HashMap<>();
    private SafeArrayList<View> views = new SafeArrayList<>(View.class);
    private View selectedView;

    public ArmatureViewState() {
        setEnabled(false);
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected void setRig( Rig rig ) {
        if( this.rig == rig ) {
            return;
        }
        this.rig = rig;
        this.skin = rig == null ? null : rig.getSkinningControl();
        this.armature = skin == null ? null : skin.getArmature();

        if( rig != null ) {
            Spatial rigView = skin.getSpatial();
            modelRoot.setLocalTranslation(rigView.getWorldTranslation());
            modelRoot.setLocalRotation(rigView.getWorldRotation());
            modelRoot.setLocalScale(rigView.getWorldScale());
        }

        resetViews();
    }

    @Override
    protected void initialize( Application app ) {
        modelRoot = new Node("modelRoot");
        getRoot().attachChild(modelRoot);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        rigRef = getState(RigViewState.class, true).createRigReference();
        setRig(rigRef.get());
    }

    @Override
    protected void onDisable() {
        rigRef = null;
        setRig(null);
    }

    @Override
    public void update( float tpf ) {
        if( rigRef.update() ) {
            setRig(rigRef.get());
        }
        if( rig == null ) {
            return;
        }
        for( View view : views.getArray() ) {
            view.update();
        }
    }

    protected void resetViews() {
        viewIndex.clear();
        for( View view : views ) {
            view.release();
        }
        views.clear();
 
        if( armature == null ) {
            return;
        }
        for( Joint joint : armature.getJointList() ) {
            View view = new View(joint);
            viewIndex.put(joint, view);
            views.add(view);
        }       
    }        

    protected Spatial createJointView( String name, ColorRGBA color ) {
        Node result = new Node("JointHolder:" + name);
        Material material = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        material.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

        Geometry geom = new Geometry("Joint", new Box(0.01f, 0.01f, 0.01f));
        geom.setMaterial(material);
        result.attachChild(geom);
        
        geom.setQueueBucket(Bucket.Translucent);                      
        material.getAdditionalRenderState().setDepthTest(false);

        return result;
    }

    protected Geometry createBoneView( String name, Mesh boneMesh, ColorRGBA color ) {
        //Node result = new Node("BoneHolder:" + name);
        Material material = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        material.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

        Geometry geom = new Geometry("Bone", boneMesh);
        geom.setMaterial(material);
        //result.attachChild(geom);
        
        geom.setQueueBucket(Bucket.Translucent);                      
        material.getAdditionalRenderState().setDepthTest(false);

        return geom;
    }

    private class View {
        Joint joint;
        Node holder;
        ColorRGBA color = new ColorRGBA(1f, 1f, 0, 0.5f);
        ColorRGBA boneColor = new ColorRGBA(1f, 0.5f, 0, 0.5f);
        Spatial jointView;
        Geometry boneView;
        com.jme3.scene.shape.Line boneMesh;
        
        public View( Joint joint ) {
            this.joint = joint;
            this.holder = new Node("JointHolder:" + joint.getName());
            modelRoot.attachChild(holder);
 
            this.jointView = createJointView(joint.getName(), color);
            holder.attachChild(jointView);
            
            boneMesh = new com.jme3.scene.shape.Line(new Vector3f(), new Vector3f());
            this.boneView = createBoneView(joint.getName(), boneMesh, boneColor);
            holder.attachChild(boneView);
            
            if( joint.getParent() == null ) {
                boneColor.set(0.1f, 0.1f, 0.1f, 0.5f);
            }
            
            update();           
        }

        public void update() {
            Transform xform = joint.getModelTransform();
            jointView.setLocalTranslation(xform.getTranslation());
            jointView.setLocalRotation(xform.getRotation());
            jointView.setLocalScale(xform.getScale());
 
            Joint parent = joint.getParent();
            Vector3f start = xform.getTranslation();
            Vector3f end = new Vector3f();
            if( parent != null ) {
                end = parent.getModelTransform().getTranslation();
            }
            boneMesh.updatePoints(start, end); 
            boneMesh.updateBound();
            boneView.updateModelBound();
        }
               
        public void release() {
            holder.removeFromParent();
        }
    }
}
