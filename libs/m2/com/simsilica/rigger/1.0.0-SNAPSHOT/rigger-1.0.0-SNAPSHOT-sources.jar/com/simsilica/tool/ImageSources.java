/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.math.ColorRGBA;
import com.jme3.texture.*;
import com.jme3.texture.image.*;

/**
 *  Common ImageSources.
 *
 *  @author    Paul Speed
 */
public class ImageSources {
    static Logger log = LoggerFactory.getLogger(ImageSources.class);
    
    public static ImageSource<ColorRGBA> color( ColorRGBA color ) {
        return new ColorImageSource(color);
    }

    public static ImageSource<Texture> texture( Texture texture ) {
        return new TextureImageSource(texture);
    }

    public static ImageSource<ImageRaster> raster( ImageRaster raster ) {
        return new RasterImageSource(raster);
    }
    
    public static ImageSource<ImageSource> subimage( ImageSource source, int x, int y, int width, int height ) {
        return new SubimageSource(source, x, y, width, height);
    }
    
    public static ImageSource<ImageSource> mult( ImageSource source, ColorRGBA mult ) {
        return new MultiplySource(source, mult);
    }      
    
    private static abstract class AbstractImageSource<T> implements ImageSource<T> {
        private T data;
        
        public AbstractImageSource( T data ) {
            this.data = data;
        }
 
        @Override       
        public final T getSourceData() {
            return data;
        }
 
        @Override           
        public String toString() {
            return getClass().getSimpleName() + "[" + data + "]";
        }
    }
 
    private static class MultiplySource extends AbstractImageSource<ImageSource> {
        private ColorRGBA mult;
        
        public MultiplySource( ImageSource source, ColorRGBA mult ) {
            super(source);
            this.mult = mult;
        }
        
        @Override
        public int getWidth() {
            return getSourceData().getWidth();
        }
        
        @Override
        public int getHeight() {
            return getSourceData().getHeight();
        }
        
        @Override
        public ColorRGBA getPixel( int x, int y ) {
            ColorRGBA result = getSourceData().getPixel(x, y);
            return result.mult(mult);
        }       

        @Override
        public ColorRGBA getPixel( int x, int y, ColorRGBA store ) {
            ColorRGBA result = getSourceData().getPixel(x, y, store);
            return result.mult(mult);
        }       
    }    
 
    private static class SubimageSource extends AbstractImageSource<ImageSource> {
        private int xOrigin;
        private int yOrigin;
        private int width;
        private int height;
        
        public SubimageSource( ImageSource source, int xOrigin, int yOrigin, int width, int height ) {
            super(source);
            this.xOrigin = xOrigin;
            this.yOrigin = yOrigin;
            this.width = width;
            this.height = height;
        }
        
        @Override
        public int getWidth() {
            return width;
        }
        
        @Override
        public int getHeight() {
            return height;
        }
        
        @Override
        public ColorRGBA getPixel( int x, int y ) {
            x = x % width;
            y = y % height;
            return getSourceData().getPixel(xOrigin + x, yOrigin + y);
        }       

        @Override
        public ColorRGBA getPixel( int x, int y, ColorRGBA store ) {
            x = x % width;
            y = y % height;
            return getSourceData().getPixel(xOrigin + x, yOrigin + y, store);
        }       
    }
    
    private static class ColorImageSource extends AbstractImageSource<ColorRGBA> {
    
        public ColorImageSource( ColorRGBA color ) {
            super(color);
        }
 
        @Override
        public int getWidth() {
            return 1;
        }
        
        @Override
        public int getHeight() {
            return 1;
        }
        
        @Override
        public ColorRGBA getPixel( int x, int y ) {
            return getPixel(x, y, new ColorRGBA());
        }       

        @Override
        public ColorRGBA getPixel( int x, int y, ColorRGBA store ) {
            if( store == null ) {
                store = new ColorRGBA();
            }
            store.set(getSourceData());
            return store;
        }       
    }
    
    private static class TextureImageSource extends AbstractImageSource<Texture> {
 
        private ImageRaster raster;
    
        public TextureImageSource( Texture texture ) {
            super(texture);
            this.raster = ImageRaster.create(texture.getImage());
        }
 
        @Override
        public int getWidth() {
            return raster.getWidth();
        }
        
        @Override
        public int getHeight() {
            return raster.getHeight();
        }
        
        @Override
        public ColorRGBA getPixel( int x, int y ) {
            // We could also have paid attention to the wrap setting
            // of the texture but I know my only usecases.
            x = x % raster.getWidth();
            y = y % raster.getHeight();
            return raster.getPixel(x, y);
        }       

        @Override
        public ColorRGBA getPixel( int x, int y, ColorRGBA store ) {
            x = x % raster.getWidth();
            y = y % raster.getHeight();
            return raster.getPixel(x, y, store);
        }       
    }

    private static class RasterImageSource extends AbstractImageSource<ImageRaster> {
 
        public RasterImageSource( ImageRaster raster ) {
            super(raster);
        }
 
        @Override
        public int getWidth() {
            return getSourceData().getWidth();
        }
        
        @Override
        public int getHeight() {
            return getSourceData().getHeight();
        }
        
        @Override
        public ColorRGBA getPixel( int x, int y ) {
            // We could also have paid attention to the wrap setting
            // of the texture but I know my only usecases.
            x = x % getSourceData().getWidth();
            y = y % getSourceData().getHeight();
            return getSourceData().getPixel(x, y);
        }       

        @Override
        public ColorRGBA getPixel( int x, int y, ColorRGBA store ) {
            x = x % getSourceData().getWidth();
            y = y % getSourceData().getHeight();
            return getSourceData().getPixel(x, y, store);
        }       
    }
}


