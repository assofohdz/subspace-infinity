/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;
import java.util.function.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.KeyInput;
import com.jme3.material.Material;

import com.simsilica.ext.mblock.PartDebugShapeFactory;
import com.simsilica.ext.mphys.*;
import com.simsilica.ext.mphys.debug.*;
import com.simsilica.input.*;
import com.simsilica.lemur.Container;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedList;
import com.simsilica.lemur.input.*;
import com.simsilica.mathd.*;
import com.simsilica.mblock.geom.GeometryFactory;
import com.simsilica.mblock.phys.MBlockShape;
import com.simsilica.state.*;

import com.simsilica.tool.OrbitCameraState;

/**
 *  The main app state that runs all of the physics playground stuff.
 *
 *  @author    Paul Speed
 */
public class PhysicsPlaygroundState extends CompositeAppState {

    static Logger log = LoggerFactory.getLogger(PhysicsPlaygroundState.class);

    public static final String GROUP = "Playground";
    public static final FunctionId F_CANCEL = new FunctionId(GROUP, "Cancel");

    private boolean paused;
    private Map<String, Runnable> initializers = new LinkedHashMap<>();
    private boolean initialized;
    private MovementState movement = new MovementState();
    private MovementTarget movementOverride;

    private List<Supplier<Boolean>> tasks = new ArrayList<>();

    public PhysicsPlaygroundState( Container container,
                                   VersionedList<String> rigs,
                                   GeometryFactory geomFactory,
                                   PgSpatialFactory modelFactory,
                                   ShapeFactoryRegistry<MBlockShape> shapeFactory,
                                   WorldSettings worldSettings ) {
        super(
            new GameSystemState(worldSettings, shapeFactory),
            new WorldViewState(geomFactory, 2), // 5x5 area
            new ModelViewState(modelFactory),
            new DebugViewState(container),
            new PlaygroundEditorState(container, rigs)
        );
        // Starts out disabled until something sets a movement handler
        movement.setEnabled(false);
        movement.setWalkSpeed(1.0);
        movement.setRunSpeed(2.0);
    }

    public GameSystemState getGameSystems() {
        return getChild(GameSystemState.class);
    }

    public void setInitializer( String id, Runnable callback ) {
        Runnable existing = initializers.remove(id);
        // Could potentially run cleanup or something.

        initializers.put(id, callback);
        if( initialized ) {
            try {
                callback.run();
            } catch( Exception e ) {
                log.error("Error running:" + id + " " + callback, e);
            }
        }
    }

    public void setMovementTarget( MovementTarget target ) {
        log.info("setMovementTarget(" + target + ")");
        if( movementOverride instanceof AutoCloseable ) {
            try {
                ((AutoCloseable)movementOverride).close();
            } catch( Exception e ) {
                log.error("Error closing movement override", e);
            }
        }
        this.movementOverride = target;
        movement.setMovementTarget(target == null ? null : new CameraWrapper(target), true);
        log.info("movement state enabled:" + movement.isEnabled());
        resetOrbitState();
    }

    protected void resetOrbitState() {
        OrbitCameraState orbitState = getState(OrbitCameraState.class);
        log.info("resetOrbitState()" + orbitState);
        if( orbitState == null ) {
            return;
        }
        // Mutually exclusive
        orbitState.setEnabled(!movement.isEnabled());
        log.info("movement state enabled:" + movement.isEnabled());
        log.info("orbit state enabled?:" + orbitState.isEnabled());
    }

    public void addTask( Supplier<Boolean> task ) {
        tasks.add(task);
    }

    public void clearTasks() {
        tasks.clear();
    }

    public void setPaused( boolean paused ) {
        if( this.paused == paused ) {
            return;
        }
        this.paused = paused;

        // Game systems that should pause
        getChild(GameSystemState.class).setPaused(paused);
        //getChild(GameSystemState.class).setEnabled(!paused);
    }

    public boolean isPaused() {
        return paused;
    }

    public void singleStep() {
        getChild(GameSystemState.class).singleStep();
    }

    public void setPhysicsDebugEnabled( boolean debugPhysics ) {
        if( getState(BodyDebugState.class) != null ) {
            getState(BodyDebugState.class).setEnabled(debugPhysics);
        }
    }

    public void setContactDebugEnabled( boolean debugContacts ) {
        if( getState(ContactDebugState.class) != null ) {
            getState(ContactDebugState.class).setEnabled(debugContacts);
        }
    }

    public void cancel() {
        log.info("cancel()");
        setMovementTarget(null);
        log.info("movement state enabled:" + movement.isEnabled());

        // Shouldn't have to do this
        GuiGlobals.getInstance().setCursorEventsEnabled(true);
        getApplication().getInputManager().setCursorVisible(true);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {
        log.info("initialize()");

        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.map(F_CANCEL, KeyInput.KEY_ESCAPE);

        inputMapper.addDelegate(F_CANCEL, this, "cancel");

        addChild(new PickState(), true);
        addChild(movement, true);

        resetOrbitState();

        MPhysSystem<MBlockShape> mphys = getState(GameSystemState.class, true).get(MPhysSystem.class);
        BodyDebugState<MBlockShape> bodyDebug = new BodyDebugState<>(mphys);
        bodyDebug.addDebugShapeFactory(new PartDebugShapeFactory());
        bodyDebug.setEnabled(true);
        bodyDebug.getObjectRoot().setLocalScale(0.25f);
        addChild(bodyDebug, true);

        ContactDebugState contactDebug = new ContactDebugState(mphys.getPhysicsSpace());
        contactDebug.getContactRoot().setLocalScale(0.25f);
        addChild(contactDebug, true);

        runInitializers();
    }

    @Override
    protected void cleanup( Application app ) {
        log.info("terminate()");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        getChild(GameSystemState.class).setEnabled(!paused);
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.activateGroup(GROUP);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.deactivateGroup(GROUP);
    }

    protected void runInitializers() {
        for( Runnable r : initializers.values() ) {
            try {
                r.run();
            } catch( Exception e ) {
                log.error("Error running:" + r, e);
            }
        }
        initialized = true;
    }

    @Override
    public void update( float tpf ) {
        if( !tasks.isEmpty() ) {
            for( Iterator<Supplier<Boolean>> it = tasks.iterator(); it.hasNext(); ) {
                Supplier<Boolean> task = it.next();
                try {
                    Boolean b = task.get();
                    if( !Boolean.TRUE.equals(b) ) {
                        log.info("Task is done:" + task);
                        it.remove();
                    }
                } catch( Exception e ) {
                    log.error("Error running:" + task, e);
                    log.error("removing.");
                    it.remove();
                }
            }
        }
    }

    private class CameraWrapper implements MovementTarget {
        private MovementTarget delegate;

        public CameraWrapper( MovementTarget delegate ) {
            this.delegate = delegate;
        }

        public void initialize( MovementState state ) {
            delegate.initialize(state);
        }

        public void terminate( MovementState state ) {
            delegate.terminate(state);
        }

        public void move( Quatd rotation, Vec3d movementForces, double tpf ) {
            delegate.move(rotation, movementForces, tpf);
        }

        public void setRotation( Quatd rotation ) {
            delegate.setRotation(rotation);
        }

        public Quatd getRotation() {
            return delegate.getRotation();
        }
    }
}


/*
PlaygroundMenuState:
    -in the regular rigger 'tool' package
    -adds itself to the tool tabs
    -interacts with the larger rigger tool
    -enables/disables the main playground state

PhysicsPlaygroundState:
    -in a separate phys package or 'playground' package
    -a composite state that holds all of the other child states

WorldSettings:
    -knows where the bset, fset, mset files are
    -needs to also be able to load them as class resources
    -could have the list of world block initializers

GameSystemState:
    -separated out to work as a sort of example
    -manages the game system manager
    -sets up all of the initial game systems
    -could have the list of world block initializers
    -probably needs some hot-swap support for systems
    -shape factory
        -spheres
        -block objects
        -rigs

WorldViewState:
    -gets the world from the game systems in the game systems state
    -needs to know the materials from the mset file
    -needs a geometry factory

ModelViewState:
    -needs the entity system
    -needs a spatial factory... which in turn probably needs a geometry factory
    -spatial factory probably needs to be able to load file-based assets and
        remove old ones from the cache, etc.


...somewhere we need to be able to setup game objects.
Would be nice if it had some way of cleaning out the old ones when we
refresh the initializer.  Perhaps we can provide the entity data object
to it so we can wrap it and keep track of the entities that it created?

*/
