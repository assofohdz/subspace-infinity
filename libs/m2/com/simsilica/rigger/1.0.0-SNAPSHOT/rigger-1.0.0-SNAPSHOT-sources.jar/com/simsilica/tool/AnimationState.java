/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.anim.tween.action.BlendAction;
import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.scene.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.value.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class AnimationState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(AnimationState.class);

    private VersionedReference<Rig> rigRef;
    private Rig rig;
    private RigInfo rigInfo;

    private Container window;
    private VersionedReference<TabbedPanel.Tab> tabRef;

    private VersionedReference<Boolean> collidersOpen;

    private Checkbox showArmature;
    private VersionedReference<Boolean> showArmatureRef;

    private VersionedList<String> clipNames = new VersionedList<>();
    private Selector<String> clipSelector;
    private VersionedReference<String> clipRef;
    private Spinner<Double> blend;
    private VersionedReference<Double> blendRef;

    private AttachmentManager attachmentMgr;
    private ColliderManager colliderMgr;
    private OverlayManager overlayMgr;

    public AnimationState() {
    }

    @Override
    protected void initialize( Application app ) {

        rigRef = getState(RigViewState.class, true).createRigReference();

        window = new Container();
        getState(ToolState.class).getTabs().addTab("Rig", window);
        tabRef = getState(ToolState.class).getTabs().getSelectionModel().createReference();

        showArmature = window.addChild(new Checkbox("Show Armature"));
        showArmature.setChecked(getState(ArmatureViewState.class).isEnabled());
        showArmatureRef = showArmature.getModel().createReference();

        Container panel = window.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        panel.addChild(new Label("Clip:"));
        clipSelector = panel.addChild(new Selector<String>(clipNames), 1);
        clipRef = clipSelector.createSelectedItemReference();

        panel.addChild(new Label("Blend:"));

        SequenceModel<Double> model = SequenceModels.rangedSequence(
                                                    new DefaultRangedValueModel(0, 1, 0),
                                                    0.1, 0.01);
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
        blend = panel.addChild(new Spinner<Double>(model, renderer), 1);
        blend.setValueEditor(ValueEditors.doubleEditor("%.2f"));
        blend.setEnabled(false);
        blendRef = model.createReference();

        attachmentMgr = new AttachmentManager();
        RollupPanel attRollup = window.addChild(new RollupPanel("Attachments", attachmentMgr, null));

        colliderMgr = new ColliderManager();
        RollupPanel collRollup = window.addChild(new RollupPanel("Colliders", colliderMgr, null));
        collidersOpen = collRollup.getOpenModel().createReference();

        overlayMgr = new OverlayManager();
        RollupPanel overlayRollup = window.addChild(new RollupPanel("Action Overlays", overlayMgr, null));

        resetRig(rigRef.get());
    }

    protected void resetRig( Rig rig ) {
        attachmentMgr.setRig(rig);
        colliderMgr.setRig(rig);
        overlayMgr.setRig(rig);

        if( rig == null ) {
            return; // for now there will always be a rig
        }
        this.rig = rig;
        this.rigInfo = rig.getRigInfo();

        clipNames.clear();
        clipNames.addAll(rig.getClipNames());
        for( BlendConfig blend : rigInfo.getBlends() ) {
            clipNames.add(blend.getName());
        }
        clipSelector.setSelectedItem(null);
        clipSelector.setSelectedItem("Idle");
    }

    protected void tabVisible() {
        if( rig != null ) {
            rig.setCurrentAction(clipRef.get());
        }
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    public void update( float tpf ) {
        if( rigRef.update() ) {
            resetRig(rigRef.get());
        }
        if( tabRef.update() ) {
            if( tabRef.get() != null && tabRef.get().getContents() == window ) {
                tabVisible();
            }
        }
        if( clipRef.update() ) {
            // Set the animation
            String clip = clipRef.get();
            rig.setCurrentAction(clip);
            if( rig.isBlendable(clip) ) {
                blend.setEnabled(true);
                rig.setBlendFactor(clip, blend.getValue());
            } else {
                blend.setEnabled(false);
            }
        }
        if( blendRef.update() ) {
            String clip = clipRef.get();
            if( rig.isBlendable(clip) ) {
                rig.setBlendFactor(clip, blend.getValue());
            }
        }
        if( collidersOpen.update() ) {
            getState(ColliderViewState.class).setEnabled(collidersOpen.get());
        }
        if( showArmatureRef.update() ) {
            getState(ArmatureViewState.class).setEnabled(showArmatureRef.get());
        }
    }

    @Override
    protected void onDisable() {
    }
}
