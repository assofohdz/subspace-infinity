/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.Box;
import com.jme3.scene.debug.WireBox;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedReference;

/**
 *  Visualization of the ProbeInfo
 *
 *  @author    Paul Speed
 */
public class ProbeView extends Node {
    static Logger log = LoggerFactory.getLogger(ProbeView.class);

    private ProbeInfo probe;
    private VersionedReference<ProbeInfo> probeRef;
    private Node boxes;

    public ProbeView() {
        super("ProbeView");
        this.boxes = new Node("boxes");
        attachChild(boxes);
    }

    @Override
    public void updateLogicalState( float tpf ) {
        if( probeRef.update() ) {
            updateView();
        }
    }

    public void setProbe( ProbeInfo probe ) {
        if( this.probe == probe ) {
            return;
        }
        this.probe = probe;
        if( probe != null ) {
            this.probeRef = probe.createReference();
        }
        updateView();
    }

    protected void updateView() {
        log.info("updateView()");

        // Not efficient but quick and effective
        boxes.detachAllChildren();

        int stepDown = probe.getStepDownLayers();
        int ground = stepDown + probe.getGroundLayers();
        int stepUp = ground + probe.getStepUpLayers();
        int jump = stepUp + probe.getJumpLayers();

        int size = probe.getSize();
        int layers = probe.getLayers();
        double rigHeight = probe.getRigHeight();

        // Ground should be barely clipping the feet... so we'll consider everything
        // about that the 'character height'.
        double scale = rigHeight / Math.max(1, layers - ground);
        boxes.setLocalScale((float)scale);

        // The boxes should be (by default) centered over their own origin
        double xzOffset = -(size * 0.5 * scale);
        double yOffset = probe.getYOffset() - (layers * 0.5 * scale);
        boxes.setLocalTranslation((float)xzOffset, (float)yOffset, (float)xzOffset);

        GuiGlobals globals = GuiGlobals.getInstance();
        float extent = 0.495f;
        WireBox box = new WireBox(extent, extent, extent);
        //Box box = new Box(extent, extent, extent);


log.info("down:" + stepDown + " ground:" + ground + " up:" + stepUp + " jump:" + jump);

        for( int x = 0; x < size; x++ ) {
            for( int z = 0; z < size; z++ ) {
                for( int y = 0; y < layers; y++ ) {
                    Geometry geom = new Geometry(x + ", " + y + ", " + z, box);
                    geom.setLocalTranslation(x, y, z);
                    geom.move(extent, extent, extent);
                    ColorRGBA color = ColorRGBA.Red;
                    if( y < stepDown ) {
                        color = ColorRGBA.Blue;
                    } else if( y < ground ) {
                        color = ColorRGBA.Green;
                    } else if( y < stepUp ) {
                        color = ColorRGBA.Magenta;
                    } else if( y < jump ) {
                        color = ColorRGBA.Orange;
                    }
                    geom.setMaterial(globals.createMaterial(color, false).getMaterial());
                    boxes.attachChild(geom);
log.info("geom:" + geom + " at:" + geom.getWorldBound());
                }
            }
        }

    }

}


/*
createHumanFemaleProbeShape = { name, mobScale ->
    double m = 0.0;
    double charHeight = 1.65;
    double blockScale = charHeight / 8;
    CellArray cells = new CellArray(2, 11, 2);
    cells.clear(1);

    // Drop check contacts
    int layer = 0;
    cells.setCell(0, layer, 0, 2);
    cells.setCell(1, layer, 0, 2);
    cells.setCell(0, layer, 1, 2);
    cells.setCell(1, layer, 1, 2);

    layer++
    cells.setCell(0, layer, 0, 2);
    cells.setCell(1, layer, 0, 2);
    cells.setCell(0, layer, 1, 2);
    cells.setCell(1, layer, 1, 2);

    // Ground contacts
    layer++
    cells.setCell(0, layer, 0, 5);
    cells.setCell(1, layer, 0, 5);
    cells.setCell(0, layer, 1, 5);
    cells.setCell(1, layer, 1, 5);

    // Step up contacts
    layer++;
    cells.setCell(0, layer, 1, 3);
    cells.setCell(1, layer, 1, 3);
    cells.setCell(0, layer, 0, 3);
    cells.setCell(1, layer, 0, 3);

    layer++;
    cells.setCell(0, layer, 1, 3);
    cells.setCell(1, layer, 1, 3);
    cells.setCell(0, layer, 0, 3);
    cells.setCell(1, layer, 0, 3);

    layer++;
    cells.setCell(0, layer, 1, 3);
    cells.setCell(1, layer, 1, 3);
    cells.setCell(0, layer, 0, 3);
    cells.setCell(1, layer, 0, 3);

    // Jump up contacts
    layer++;
    cells.setCell(0, layer, 1, 4);
    cells.setCell(1, layer, 1, 4);
    cells.setCell(0, layer, 0, 4);
    cells.setCell(1, layer, 0, 4);

    layer++;
    cells.setCell(0, layer, 1, 4);
    cells.setCell(1, layer, 1, 4);
    cells.setCell(0, layer, 0, 4);
    cells.setCell(1, layer, 0, 4);

    MaskUtils.calculateSideMasks(cells);
    MBlockShape shape = MBlockShape.createShape(name, cells, mobScale * blockScale, m);
    double blockSize = blockScale * mobScale;
    double yOffset = mobScale * 0.35;

log.info("yOffset:" + yOffset + "  mobScale:" + mobScale + "  blockScale:" + blockScale + " blockSize:" + blockSize + "  cells height:" + (cells.size.y * blockScale * mobScale));
// yOffset:0.3325  mobScale:0.95  blockScale:0.20625 blockSize:0.1959375  cells height:2.1553124999999995
    return new QueryShape(shape:shape, cogOffset:new Vec3d(0, yOffset, 0), scale:(mobScale * blockScale));
}
*/
