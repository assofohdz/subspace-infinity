/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;
import java.util.function.*;

import org.slf4j.*;

import com.jme3.asset.AssetManager;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.shader.VarType;
import com.jme3.texture.*;

import com.simsilica.es.*;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.mathd.*;

import com.simsilica.crig.*;
import com.simsilica.crig.jme.*;
import com.simsilica.mphys.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.ext.mphys.*;

/**
 *  Convenience methods for creating Spatials from
 *  shapes.
 *
 *  @author    Paul Speed
 */
public class PgSpatialFactory {
    static Logger log = LoggerFactory.getLogger(PgSpatialFactory.class);

    private AssetManager assets;
    private GeometryFactory geomFactory;

    // technically origin and not CoG anymore
    private boolean debugCoG = true;

    private BiConsumer<MBlockShape, Map<Part, Spatial>> modelListener;

    public PgSpatialFactory( AssetManager assets, GeometryFactory geomFactory ) {
        this.assets = assets;
        this.geomFactory = geomFactory;
    }

    public void setModelListener( BiConsumer<MBlockShape, Map<Part, Spatial>> modelListener ) {
        this.modelListener = modelListener;
    }

    public Spatial createModel( EntityId id, String name, MBlockShape shape, Mass mass, double scale, Map<Part, Spatial> index ) {
log.info("createModel(" + id + ", " + name + ")");
        if( modelListener != null && index == null ) {
            index = new HashMap<>();
        }

        if( shape instanceof RigShape ) {
            return createRigModel(id, name, (RigShape)shape, mass, scale, index);
        }

        Part part = shape.getPart();
        Spatial result = createPartSpatial(id, part, index);

        //Spatial result;
        //if( part instanceof CellArrayPart ) {
        //    result = createPartSpatial(id, (CellArrayPart)part, true, mass);
        //    if( index != null ) {
        //        index.put(part, result);
        //    }
        //} else if( part instanceof Group ) {
        //    result = createPartSpatial(id, (Group)part, mass, index);
        //} else {
        //    throw new IllegalArgumentException("Unhandled part type:" + shape.getPart());
        //}

        if( modelListener != null ) {
            modelListener.accept(shape, index);
        }
        return result;
    }

    protected Spatial createPartSpatial( EntityId id, Part part, Map<Part, Spatial> index ) {
        if( part instanceof CellArrayPart ) {
            return createCellArrayPart(id, (CellArrayPart)part, index);
        } else if( part instanceof Group ) {
            return createGroupPart(id, (Group)part, index);
        } else {
            throw new IllegalArgumentException("Unhandled part type:" + part);
        }
    }

    protected Spatial createGroupPart( EntityId id, Group group, Map<Part, Spatial> index ) {
        //log.info("createGroupPart(" + group + ")");
        Node node = new Node(group.getName());
        for( Part child : group.getChildren() ) {
            Spatial spatial = createPartSpatial(id, child, index);
            node.attachChild(spatial);
        }

        node.setLocalTranslation(group.getLocalPosition().toVector3f());
        node.setLocalRotation(group.getLocalOrientation().toQuaternion());

        if( debugCoG ) {
            node.attachChild(createBox(0.1f, ColorRGBA.Orange));
        }

        if( index != null ) {
            index.put(group, node);
        }
        return node;
    }




//    /**
//     *  Creates a root-level spatial for the specified root group.
//     */
//    protected Spatial createPartSpatial( EntityId id, Group group, Mass mass, Map<Part, Spatial> index ) {
//log.info("createRootPartSpatial(" + id + ", " + group + ")");
//        Node node = new Node("Object:" + id);
//        if( debugCoG ) {
//            node.attachChild(createBox(0.1f, ColorRGBA.Orange));
//        }
//
//        if( index != null ) {
//            index.put(group, node);
//        }
//
//        // The root level will need to be positioned relative to the rigid body
//        // which is positioned at CoG relative to model space.  So we need to offset
//        // negative CoG.
//        Node cogOffset = new Node("CoG:" + id);
//        node.attachChild(cogOffset);
//        //Vec3d cog = group.getMass().getCog();
//        //cogOffset.move((float)-cog.x, (float)-cog.y, (float)-cog.z);
//        createPartSpatial(cogOffset, id, group, mass, index);
//
//        // Maybe someday when we have all the time in the world and are sitting
//        // on a beach somewhere worrying about ways to micro-optimize, we can
//        // see about flattening this extra hierarchy.  Though, do note that
//        // the group hierarchy is already flat... because that's how I roll.
//
//        return node;
//    }


    protected Spatial createCellArrayPart( EntityId id, CellArrayPart part, Map<Part, Spatial> index ) {

        if( part.getType() == CellArrayPart.Type.Sphere ) {
            Spatial result = createSphere(id, (float)part.getMass().getRadius(), null);
            if( index != null ) {
                index.put(part, result);
            }
            return result;
        }

        //log.info("createCellArrayPart(" + part.getName() + ")");
        Node parts = new Node("parts:" + part.getName());

        //// Let's see if we can get them to self-light at least.
        //CellArray cells = part.getCells();
        //CellArray lights = new CellArray(cells.getSizeX(), cells.getSizeY(), cells.getSizeZ());
        //
        //LightUtils.recalculateLighting(cells, lights, 0, 0, 0, lights.getSizeX(), lights.getSizeY(), lights.getSizeZ());
        //CellData safeLights = new SafeCellData(lights, LightUtils.DIRECT_SUN);
        //
        //geomFactory.generateBlocks(parts, cells, safeLights, true);

        geomFactory.generateBlocks(parts, part.getCells(), new ConstantCellData(LightUtils.DIRECT_SUN), true);


        if( part.getName().endsWith(".carved.blocks") ) {
            log.info("Carving part:" + part.getName());
            float carveScale = (float)(1.0/part.getScale());
            parts.addMatParamOverride(new MatParamOverride(VarType.Float, "CarveScale", carveScale));
        }

        parts.setLocalScale((float)part.getScale());
        parts.setLocalTranslation(part.getLocalPosition().toVector3f());
        parts.setLocalRotation(part.getLocalOrientation().toQuaternion());

        parts.setShadowMode(ShadowMode.CastAndReceive);

        //if( debugJoints ) {
        //    parts.attachChild(SpatialUtils.createDebugBox("box:" + part.getName(), 0.01f, ColorRGBA.Pink));
        //}

        if( index != null ) {
            index.put(part, parts);
        }
        parts.setUserData("oid", id.getId());
        return parts;
    }

    ///**
    // *  Creates a root-level spatial for the specified root part.
    // */
    //protected Spatial createPartSpatial( EntityId id, CellArrayPart part, boolean isRoot, Mass mass ) {
    //    if( part.getCells() == null ) {
    //        return createSphere(id, (float)part.getMass().getRadius(), mass);
    //    }
    //    log.info("createPartSpatial(" + id + ", " + part + ", " + isRoot + ", " + mass + ")");
    //
    //    Node node = new Node("Object:" + id);
    //    Node parts = new Node("Parts:" + id);
    //    node.attachChild(parts);
    //
    //    //geomIndex.generateBlocks(parts, part.getCells());
    //    geomFactory.generateBlocks(parts, part.getCells(), new ConstantCellData(LightUtils.DIRECT_SUN), true);
    //
    //    if( part.getName().endsWith(".carved.blocks") ) {
    //        log.info("Carving part:" + part.getName());
    //        float carveScale = (float)(1.0/part.getScale());
    //        parts.addMatParamOverride(new MatParamOverride(VarType.Float, "CarveScale", carveScale));
    //    }
    //
    //    // If we are the root level then we'll need a cog shift
    //    // to match with the rigid body
    //    if( isRoot ) {
    //        BodyMass bm = part.getMass();
    //
    //        // The position of the object is its CoG... which means
    //        // we need to offset our model's origin by it.  It should
    //        // already be scaled and everything... just need to negate it.
    //        //Vector3f cogOffset = bm.getCog().toVector3f().negate();
    //
    //        // We need to sort out what the center should be.  Directly out of generateBlocks()
    //        // the geometry is all relative to the corner.   See cog-offset.txt
    //        //parts.move(cogOffset);
    //
    //        if( debugCoG ) {
    //            node.attachChild(createBox(0.05f, ColorRGBA.Red));
    //        }
    //    }
    //
    //    parts.setLocalScale((float)part.getScale());
    //    parts.setShadowMode(ShadowMode.CastAndReceive);
    //
    //    node.setUserData("oid", id.getId());
    //
    //    return node;
    //}

//    /**
//     *  Creates a child spatial for the specified child group.
//     */
//    protected Spatial createPartSpatial( Node parent, EntityId id, Group group, Mass mass, Map<Part, Spatial> index ) {
//log.info("createPartSpatial(" + parent + ", " + id + ", " + group + ")");
//        for( Part child : group.getChildren() ) {
//            if( child instanceof CellArrayPart ) {
//                Spatial ps = createPartSpatial(id, (CellArrayPart)child, false, mass);
//                ps.setLocalTranslation(child.getShapeRelativePosition().toVector3f());
//                ps.setLocalRotation(child.getShapeRelativeOrientation().toQuaternion());
//                parent.attachChild(ps);
//                if( index != null ) {
//                    index.put(child, ps);
//                }
//            } else if( child instanceof Group ) {
//                createPartSpatial(parent, id, (Group)child, mass, index);
//            } else {
//                throw new IllegalArgumentException("Unhandled part type:" + child);
//            }
//        }
//        return parent;
//    }



    public Spatial createSphere( EntityId id, float radius, Mass mass ) {
        Sphere mesh = new Sphere(24, 24, radius);
        mesh.setTextureMode(Sphere.TextureMode.Projected);
        mesh.scaleTextureCoordinates(new Vector2f(4, 2));
        Geometry geom = new Geometry("Object:" + id, mesh);

        if( mass != null && mass.getMass() != 0 ) {
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(new ColorRGBA(0, 0.6f, 0.6f, 1), true).getMaterial());

            Texture texture = GuiGlobals.getInstance().loadTexture("Interface/grid-shaded-labeled.png", true, true);
            geom.getMaterial().setTexture("DiffuseMap", texture);
        } else {
            // Just a flat green
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(new ColorRGBA(0.2f, 0.6f, 0.2f, 1), true).getMaterial());
        }

        geom.setShadowMode(ShadowMode.CastAndReceive);

        geom.setUserData("oid", id.getId());
        return geom;
    }

    protected Geometry createBox( float size, ColorRGBA color ) {
        Box box = new Box(size, size, size);
        Geometry geom = new Geometry("box", box);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(color, false).getMaterial());
        geom.getMaterial().getAdditionalRenderState().setWireframe(true);

        return geom;
    }


    protected Spatial createRigModel( EntityId id, String name, RigShape shape, Mass mass, double scale, Map<Part, Spatial> index ) {

        String assetName = name + ".j3o";
        //String assetName = "Models/" + name + ".j3o";
        Spatial spatial = assets.loadModel(assetName);
        spatial.setShadowMode(ShadowMode.CastAndReceive);
        spatial.setUserData("oid", id.getId());
        spatial.setLocalScale((float)scale);

        ((SpatialRigType)shape.getRigType()).configureSpatial(spatial);

        return spatial;
    }

}

