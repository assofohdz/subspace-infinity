/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;
import com.jme3.texture.*;
import com.jme3.texture.image.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;


/**
 *  Index of SwatchShapes and the ImageSources that can be used
 *  to copy them into rasters and such.
 *
 *  @author    Paul Speed
 */
public class SwatchIndex {
    static Logger log = LoggerFactory.getLogger(SwatchIndex.class);
    
    private List<SwatchShape> baseShapes = new ArrayList<>();
    private List<SwatchData> shapes = new ArrayList<>();

    private Image shapeAtlas = ImageUtils.createImage(Image.Format.ABGR8, 32 * 16, 32 * 16); 
    private ImageRaster shapeRaster = ImageRaster.create(shapeAtlas);
    private ImageSource shapeSource = ImageSources.raster(shapeRaster);

    public SwatchIndex() {
    }
 
    public List<SwatchShape> getBaseShapes() {
        return baseShapes;
    }
 
    public SwatchShape getBaseShape( int index ) {
        return baseShapes.get(index);
    }
    
    public ImageSource getShapeSource( int index ) {
        return shapes.get(index).source;
    }
 
    public List<SwatchData> getSwatchData() {
        return Collections.unmodifiableList(shapes);
    }
 
    public SwatchData getSwatchData( int index ) {
        return shapes.get(index);
    }
 
    public Vec3i getShapeCell( int index ) {
        return shapes.get(index).cell;
    } 
    
    public SwatchShape add( SwatchShape shape ) {
        baseShapes.add(shape);
        return shape;
    }
    
    public void buildVariants( ImageSource sourceAtlas ) {
        
        for( SwatchShape shape : baseShapes ) {
            List<Direction> dirs = shape.getEdges();
            
            // To make sure we hit all of the various
            // on/offs of the dirs, we'll cheat and go through
            // all 16 possibilities and skip the ones that could
            // never be for this shape. 
            int dirMask = SwatchShape.dirsToMask(dirs);
            for( int i = 0; i < 16; i++ ) {
                if( (i & dirMask) != i ) {
                    // Not a possible variant
                    // All objects will have at least a 0 variant
                    continue;
                }
                
                SwatchData data = new SwatchData(shape, i);
                shape.setVariantIndex(i, shapes.size());
                shapes.add(data);
            }
        }

        log.info("Total shapes:" + shapes.size());
        
        // Now go through all of the shapes and copy their
        // image data into the appropriate cell, calculate normals, etc..
        for( int i = 0; i < shapes.size(); i++ ) {
            SwatchData data = shapes.get(i);
            Vec3i cell = data.baseShape.getSourceCell();
            int forcedMask = data.baseShape.getForcedMask(); 
                       
            ImageSource source = ImageSources.subimage(sourceAtlas, cell.x * 32, cell.y * 32, 32, 32);            
            int xCell = i % 16;
            int yCell = i / 16;
            data.cell = new Vec3i(xCell, yCell, 0);
            ImageUtils.paint(source, shapeRaster, xCell * 32, yCell * 32);
            
            calculateNormals(shapeRaster, xCell * 32, yCell * 32, data.dirMask | forcedMask); 
            
            data.source = ImageSources.subimage(shapeSource, xCell * 32, yCell * 32, 32, 32); 
        }        
    }
 
    protected void calculateNormals( ImageRaster raster, int xBase, int yBase, int dirMask ) {
    
        Vector3f[][] normals = new Vector3f[32][32];
        int[][] counts = new int[raster.getWidth()][raster.getHeight()];
 
        float intensity = 2; //0.5f;
        
        // First calculate the horizontal normals
        for( int j = 0; j < 32; j++ ) {
            int y = j;
            float last;
            // From left to right
            if( (dirMask & DirectionMasks.WEST_MASK) != 0 ) {
                // Make sure we draw an edge if there is anything in the first position
                last = 0;
            } else {
                // Make sure there is no change 
                last = raster.getPixel(xBase + 0, yBase + y).a;
            }
            Vector3f lastNormal = null;
            for( int i = 0; i < 32; i++ ) {
                float alpha = raster.getPixel(xBase + i, yBase + y).a;
                // Don't bother calculating a normal if we won't ever
                // render it anyway
                if( alpha > 0 ) {
                    float delta = alpha - last;
                    //if( delta < 0 ) {
                    //    continue;
                    //}

                    // We need a normal here
                    // Calculate based on slope... but it's a bit tricky.
                    // We want delta = 0 to be straight up and delta 1
                    // to be some angle... ~45 degrees.  (Technically it
                    // should be a shelf directly horizontal but that doesn't
                    // work well with our directional averaging.
                    // Flat:
                    //      delta = 0 -> z = 1  x = 0
                    // Downhill:
                    //      delta < 0 -> z = +0..1  x = +0..1
                    // delta > 0 -> z = +0..1  x = -0..1
                    //
                    // __|~~~~|__
                    //
                    // ^^\^^^^/^^
                    // 
                    // z = 1 - abs(delta)
                    // x = -delta
                    // 
                    // ...would be the pure way.  But we'll cut x in half to make
                    // things a bit more 'vertical'
                    Vector3f normal;
                    if( Math.abs(delta) < 0.001 && lastNormal != null ) {
                        normal = lastNormal;
                        lastNormal = null;
                    } else {
                        normal = new Vector3f(-delta * intensity, 0, 1 - Math.abs(delta)).normalizeLocal();
                        lastNormal = normal;
                    }     
                    //Vector3f normal = new Vector3f(-delta, 0, 1 - Math.abs(delta)).normalizeLocal();
                    //Vector3f normal;
                    //if( delta < 0.2 ) {
                    //    normal = new Vector3f(0, 0, 1);
                    //} else {
                    //    normal = new Vector3f(-1, 0, 1).normalizeLocal();
                    //}     
                    if( normals[i][j] == null ) {
                        normals[i][j] = normal.clone();
                    } else {
                        normals[i][j].addLocal(normal);
                    }
                    counts[i][j]++;                    
                }
                last = alpha;
            }
            
            // From right to left
            if( (dirMask & DirectionMasks.EAST_MASK) != 0 ) {
                last = 0;
            } else {
                last = raster.getPixel(xBase + 31, yBase + y).a;
            }
            lastNormal = null;
            for( int i = 31; i >= 0; i-- ) {
                float alpha = raster.getPixel(xBase + i, yBase + y).a;
                // Don't bother calculating a normal if we won't ever
                // render it anyway
                if( alpha > 0 ) {
                    float delta = alpha - last;
                    //if( delta < 0 ) {
                    //    continue;
                    //}
                    Vector3f normal;
                    if( Math.abs(delta) < 0.001 && lastNormal != null ) {
                        normal = lastNormal;
                        lastNormal = null;
                    } else {
                        normal = new Vector3f(delta * intensity, 0, 1 - Math.abs(delta)).normalizeLocal();
                        lastNormal = normal;
                    }     
                    if( normals[i][j] == null ) {
                        normals[i][j] = normal.clone();
                    } else {
                        normals[i][j].addLocal(normal);
                    }
                    counts[i][j]++;
                }
                last = alpha;
            }
        }
        
        // Now calcalculate vertical normals... remember we are upside down
        for( int i = 0; i < 32; i++ ) {
            float last;
            // From bottom to top 
            if( (dirMask & DirectionMasks.SOUTH_MASK) != 0 ) {
                last = 0;
            } else {
                last = raster.getPixel(xBase + i, yBase + 0).a;
            }
            Vector3f lastNormal = null;
            for( int j = 0; j < 32; j++ ) {
                float alpha = raster.getPixel(xBase + i, yBase + j).a;
                // Don't bother calculating a normal if we won't ever
                // render it anyway
                if( alpha > 0 ) {
                    float delta = alpha - last;
                    //if( delta < 0 ) {
                    //    continue;
                    //}
                    Vector3f normal;
                    if( Math.abs(delta) < 0.001 && lastNormal != null ) {
                        normal = lastNormal;
                        lastNormal = null;
                    } else {
                        normal = new Vector3f(0, -delta * intensity, 1 - Math.abs(delta)).normalizeLocal();
                        lastNormal = normal;
                    }     
                    if( normals[i][j] == null ) {
                        normals[i][j] = normal.clone();
                    } else {
                        normals[i][j].addLocal(normal);
                    }
                    counts[i][j]++;
                }
                last = alpha;
            }
            
            // From top to bottom
            if( (dirMask & DirectionMasks.NORTH_MASK) != 0 ) {
                last = 0;
            } else {
                last = raster.getPixel(xBase + i, yBase + 31).a;
            }
            lastNormal = null;
            for( int j = 31; j >= 0; j-- ) {
                float alpha = raster.getPixel(xBase + i, yBase + j).a;
                // Don't bother calculating a normal if we won't ever
                // render it anyway
                if( alpha > 0 ) {
                    float delta = alpha - last;
                    //if( delta < 0 ) {
                    //    continue;
                    //}
                    Vector3f normal;
                    if( Math.abs(delta) < 0.001 && lastNormal != null ) {
                        normal = lastNormal;
                        lastNormal = null;
                    } else {
                        normal = new Vector3f(0, delta * intensity, 1 - Math.abs(delta)).normalizeLocal();
                        lastNormal = normal;
                    }     
                    if( normals[i][j] == null ) {
                        normals[i][j] = normal.clone();
                    } else {
                        normals[i][j].addLocal(normal);
                    }
                    counts[i][j]++;
                }
                last = alpha;
            }
        }
        
        
        // Move them to the raster averaging as we go
        for( int i = 0; i < 32; i++ ) {
            for( int j = 0; j < 32; j++ ) {
                Vector3f normal = normals[i][j];
                if( normal == null ) {
                    normal = new Vector3f(0, 0, 1);
                } else {
                    normal.divideLocal(counts[i][j]);
                }
                ColorRGBA existing = raster.getPixel(xBase + i, yBase + j); 
                existing.r = ((normal.x * 0.5f) + 0.5f);
                existing.g = ((normal.y * 0.5f) + 0.5f);
                existing.b = ((normal.z * 0.5f) + 0.5f);
                Vector3f v1 = new Vector3f(existing.r, existing.g, existing.b);
                v1.multLocal(2, -2, 2);
                v1.subtractLocal(1, -1, 1);
                raster.setPixel(xBase + i, yBase + j, existing);
            }
        }        
    }
 
    public class SwatchData {
        private SwatchShape baseShape;
        private ImageSource source;
        private Vec3i cell;
        private int dirMask;
        
        public SwatchData( SwatchShape baseShape, int dirMask ) {
            this.baseShape = baseShape;
            this.dirMask = dirMask;
        }
        
        public SwatchShape getShape() {
            return baseShape;
        }
        
        public Vec3i getCell() {
            return cell;
        }
        
        public int getDirMask() {
            return dirMask;
        }
        
        public ImageSource getImageSource() {
            return source;
        }        
    }   
}
