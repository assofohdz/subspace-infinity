/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;

import org.slf4j.*;

import com.simsilica.es.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mphys.*;
import com.simsilica.sim.*;

/**
 *  Matches CharacterType to CharacterDriver and whatever else.
 *
 *  @author    Paul Speed
 */
public class CharacterSystem extends AbstractGameSystem {
    static Logger log = LoggerFactory.getLogger(CharacterSystem.class);

    private EntityData ed;
    private PhysicsSpace<EntityId, MBlockShape> phys;
    private CharContainer characters;

    private Set<CharacterDriver> pending = new HashSet<>();

    public CharacterSystem() {
    }

    public CharacterDriver getDriver( EntityId id ) {
        return characters.getObject(id);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize() {
        this.ed = getSystem(EntityData.class, true);
        this.phys = (PhysicsSpace<EntityId, MBlockShape>)getSystem(PhysicsSpace.class, true);
        this.characters = new CharContainer(getSystem(EntityData.class, true));
    }

    @Override
    protected void terminate() {
    }

    @Override
    public void start() {
        characters.start();
    }

    @Override
    public void update( SimTime time ) {
        characters.update();
        if( !pending.isEmpty() ) {
            for( Iterator<CharacterDriver> it = pending.iterator(); it.hasNext(); ) {
                CharacterDriver driver = it.next();
                if( attach(driver) ) {
                    it.remove();
                }
            }
        }
    }

    @Override
    public void stop() {
        characters.stop();
    }

    protected boolean attach( CharacterDriver driver ) {
        // See if the physics engine already has a body for this entity
        RigidBody<EntityId, MBlockShape> body = phys.getBinIndex().getRigidBody(driver.getId());
        if( body != null ) {
            body.setControlDriver(driver);
            body.wakeUp();
            // Because the physics space may have deactivated the object because it
            // went to sleep before but is keeping track of it as an 'inactive object'.
            // So we'll still find it in the physics space but it won't be getting updates
            // unless it's reactivated
            phys.getBinIndex().activate(body);
            return true;
        }
        return false;
    }

    protected class CharContainer extends EntityContainer<CharacterDriver> {
        public CharContainer( EntityData ed ) {
            super(ed, CharacterType.class);
        }

        @Override
        protected CharacterDriver addObject( Entity entity ) {
            CharacterDriver driver = new CharacterDriver(ed, entity.getId());
            updateObject(driver, entity);
            if( !attach(driver) ) {
                pending.add(driver);
            }
            return driver;
        }

        @Override
        protected void updateObject( CharacterDriver object, Entity entity ) {
            object.setType(entity.get(CharacterType.class));
        }

        @Override
        protected void removeObject( CharacterDriver object, Entity entity ) {
        }
    }
}
