/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.awt.image.*;
import java.io.*;
import java.nio.*;
import javax.imageio.ImageIO;

import org.slf4j.*;

import com.jme3.math.*;
import com.jme3.texture.*;
import com.jme3.texture.image.*;
import com.jme3.system.*;
import com.jme3.texture.plugins.AWTLoader;
import com.jme3.util.*;
import jme3tools.converters.ImageToAwt;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ImageUtils {
    static Logger log = LoggerFactory.getLogger(ImageUtils.class);

    public static Image createImage( Image.Format format, int width, int height ) {
        int bytes = format.getBitsPerPixel() / 8;
        int size = width * height * bytes;
        ByteBuffer data = BufferUtils.createByteBuffer(size);
        return new Image(format, width, height, data, ColorSpace.Linear);
    }

    public static void writeImage( File f, int width, int height, ByteBuffer data ) throws IOException {
        FileOutputStream out = new FileOutputStream(f);
        try {
            JmeSystem.writeImageFile(out, "png", data, width, height);
        } finally {
            out.close();
        }
    }

    public static void writeImage( File f, Texture texture ) throws IOException {
        writeImage(f, texture.getImage());
    }

    public static void writeImage( File f, Image image ) throws IOException {
        BufferedImage bimg = ImageToAwt.convert(image, false, true, 0);
        ImageIO.write(bimg, "PNG", f);
    }

    public static Image loadImage( File f ) {
        if( !f.exists() ) {
            return null;
        }
        try {
            BufferedImage bimg = ImageIO.read(f);
            return new AWTLoader().load(bimg, false);
        } catch( IOException e ) {
            log.error("Error reading:" + f, e);
            return null;
        }
    }

    public static void paint( ImageSource source, ImageRaster target, int x, int y ) {
        for( int i = 0; i < source.getWidth(); i++ ) {
            for( int j = 0; j < source.getHeight(); j++ ) {
                ColorRGBA pixel = source.getPixel(i, j);
                target.setPixel(x + i, y + j, pixel);
            }
        }
    }

    public static void copy( ImageRaster source, ImageRaster target, int skip, boolean average ) {
        // For now just straight copy it
        for( int i = 0; i < target.getWidth(); i++ ) {
            for( int j = 0; j < target.getHeight(); j++ ) {
                ColorRGBA pixel;
                if( average ) {
                    pixel = new ColorRGBA(0,0,0,0);
                    // Average the colors
                    int count = 0;
                    for( int x = 0; x < skip; x++ ) {
                        for( int y = 0; y < skip; y++ ) {
                            pixel.addLocal(source.getPixel(i * skip + x, j * skip + y));
                            count++;
                        }
                    }
                    pixel.multLocal(1f/count);
                } else {
                    pixel = source.getPixel(i * skip, j * skip);
                }
                target.setPixel(i, j, pixel);
            }
        }
    }

    public static void fillRaster( ImageRaster raster, ColorRGBA value ) {
        int width = raster.getWidth();
        int height = raster.getHeight();
        for( int i = 0; i < width; i++ ) {
            for( int j = 0; j < width; j++ ) {
                raster.setPixel(i, j, value);
            }
        }
    }

    public static void box( ImageRaster out, int x, int y, int size, ColorRGBA color ) {
        for( int i = 0; i < size; i++ ) {
            for( int j = 0; j < size; j++ ) {
                out.setPixel(x + i, j + y, color);
            }
        }
    }

    public static void makeTestImage() {
        // Just making a temporary shape index to see if there are
        // interesting combinations that I will miss and to easily index
        // the ones that I know I will want.
        // Makes a neat picture but the vast majority of combinations
        // we do not care about.  Which also makes indexing them spatially
        // less relevant.  Better to just add cases to cells as we think of
        // them.
        int width = 512;
        int size = width * width * 4;
        ByteBuffer data = BufferUtils.createByteBuffer(size);
        Image image = new Image(Image.Format.RGBA8, width, width, data, ColorSpace.Linear);
        ImageRaster raster = ImageRaster.create(image);

        ColorRGBA on = new ColorRGBA(1, 1, 1, 1);
        ColorRGBA off = new ColorRGBA(0, 0, 0, 0);

        int b = 8;

        for( int i = 0; i < 256; i++ ) {
            int xCell = i % 16;
            int yCell = i / 16;
            int x = xCell * 32;
            int y = yCell * 32;
            box(raster, x, y, 32, on);
            box(raster, x+1, y+1, 30, off);

            // Always a center dot
            box(raster, x+2 + b, y+2 + b, b-1, on);

            // 0x1  0x2  0x4
            // 0x8       0x10
            // 0x20 0x40 0x80
            if( (i & 0x1) != 0 ) {
                box(raster, x+2, y+2, b-1, on);
            }
            if( (i & 0x2) != 0 ) {
                box(raster, x+2 + b, y+2, b-1, on);
            }
            if( (i & 0x4) != 0 ) {
                box(raster, x+2 + b + b, y+2, b-1, on);
            }

            if( (i & 0x8) != 0 ) {
                box(raster, x+2, y+2 + b, b-1, on);
            }
            if( (i & 0x10) != 0 ) {
                box(raster, x+2 + b + b, y+2 + b, b-1, on);
            }

            if( (i & 0x20) != 0 ) {
                box(raster, x+2, y+2 + b + b, b-1, on);
            }
            if( (i & 0x40) != 0 ) {
                box(raster, x+2 + b, y+2 + b + b, b-1, on);
            }
            if( (i & 0x80) != 0 ) {
                box(raster, x+2 + b + b, y+2 + b + b, b-1, on);
            }
        }

        try {
            data.rewind();
            writeImage(new File("shape-index.png"), width, width, data);
        } catch( IOException e ) {
            log.error("Error writing shape index", e);
        }
    }
}
