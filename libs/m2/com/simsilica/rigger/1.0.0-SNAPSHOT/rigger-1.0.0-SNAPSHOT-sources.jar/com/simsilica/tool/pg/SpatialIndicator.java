/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import org.slf4j.*;

import com.jme3.collision.*;
import com.jme3.math.*;
import com.jme3.scene.*;

import com.simsilica.lemur.event.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SpatialIndicator implements PickIndicator<WorldPick> {
    static Logger log = LoggerFactory.getLogger(SpatialIndicator.class);

    private Spatial spatial;

    private WorldPick lastPick;

    public SpatialIndicator( Spatial spatial ) {
       this.spatial = spatial;
    }

    protected boolean isSelf( Geometry geom ) {
        for( Spatial s = geom; s != null; s = s.getParent() ) {
            if( s == spatial ) {
                return true;
            }
        }
        return false;
    }

    protected WorldPick getHit( CursorMotionEvent event ) {
        // Is it a valid hit?
        CollisionResult collision = event.getCollision();
        if( collision == null ) {
            return null;
        }
        // If we've picked ourselves then just return the last pick
        if( isSelf(collision.getGeometry()) ) {
            return lastPick;
        }

        float up = collision.getContactNormal().dot(Vector3f.UNIT_Y);
        if( up < 0.7 ) {
            // Not flat enough
            return null;
        }
        return new WorldPick(collision.getContactPoint().mult(4), collision.getContactNormal());
    }

    public WorldPick place( Node root, CursorMotionEvent event ) {
        //log.info("place(" + event + ")");
        WorldPick pick = getHit(event);
        if( pick == null ) {
            spatial.removeFromParent();
            return null;
        }

        lastPick = pick;

        //log.info("pick:" + pick);
        spatial.setLocalTranslation(pick.location.toVector3f());
        root.attachChild(spatial);

        return pick;
    }

    public void release() {
        spatial.removeFromParent();
    }
}

