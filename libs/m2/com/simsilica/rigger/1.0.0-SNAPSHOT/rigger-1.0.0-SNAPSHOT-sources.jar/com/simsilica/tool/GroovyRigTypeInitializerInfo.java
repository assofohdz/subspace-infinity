/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedList;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;

import com.simsilica.crig.jme.GroovyRigTypeInitializer;
import com.simsilica.crig.jme.RigTypeInitializer;

/**
 *
 *
 *  @author    Paul Speed
 */
public class GroovyRigTypeInitializerInfo implements RigTypeInitializerInfo<GroovyRigTypeInitializerInfo> {
    static Logger log = LoggerFactory.getLogger(GroovyRigTypeInitializerInfo.class);

    private transient long version;
    private String sourcePath;
    private String targetPath;
    private String scriptName;

    public GroovyRigTypeInitializerInfo() {
    }

    public RigTypeInitializer convert() {
        if( targetPath.endsWith("/") ) {
            return new GroovyRigTypeInitializer(targetPath + scriptName);
        } else {
            return new GroovyRigTypeInitializer(targetPath + "/" + scriptName);
        }
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public GroovyRigTypeInitializerInfo getObject() {
        return this;
    }

    @Override
    public VersionedReference<GroovyRigTypeInitializerInfo> createReference() {
        return new VersionedReference<>(this);
    }

    public void setSourcePath( String sourcePath ) {
        this.sourcePath = sourcePath;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public void setTargetPath( String targetPath ) {
        this.targetPath = targetPath;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setScriptName( String scriptName ) {
        this.scriptName = scriptName;
        version++;
    }

    public String getScriptName() {
        return scriptName;
    }

    public String toString() {
        return getClass().getSimpleName() + "[" + scriptName + "]";
    }
}
