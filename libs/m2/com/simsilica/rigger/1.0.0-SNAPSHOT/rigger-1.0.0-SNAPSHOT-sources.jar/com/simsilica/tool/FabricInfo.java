/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.math.ColorRGBA;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;

/**
 *  Information about a particular type of fabric that can be
 *  used to construct clothing layers.  The term 'fabric' is used
 *  loosely here.
 *
 *  @author    Paul Speed
 */
public class FabricInfo implements VersionedObject<FabricInfo> {
    static Logger log = LoggerFactory.getLogger(FabricInfo.class);
 
    private transient long version;
    
    private String name;
    
    private double thickness;
    
    private String baseTexture;
    private ColorRGBA baseColor;
    
    private String normalTexture;
    private String metallicRoughnessTexture;
    private double metallic;
    private double roughness;
 
    private ColorRGBA specularColor;
    private String specularTexture;
    
    private ColorRGBA emissionColor;
    private String emissionTexture;
 
    // Custom format for edge normals for the different corners
    // and shape types.  Probably this will be standard but maybe
    // we want different edge looks for some materials.
    private String edgeTexture;
 
    public FabricInfo() {
    } 
       
    public FabricInfo( String name ) {
        this.name = name;
    }

    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public FabricInfo getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<FabricInfo> createReference() {
        return new VersionedReference<>(this);
    }
 
    public void setName( String name ) {
        this.name = name;
        version++;
    }
    
    public String getName() {
        return name;
    } 

    public void setThickness( double thickness ) {
        this.thickness = thickness;
    }
    
    public double getThickness() {
        return thickness;
    }

    public void setBaseTexture( String baseTexture ) {
        this.baseTexture = baseTexture;
    }
    
    public String getBaseTexture() {
        return baseTexture;
    }
       
    public void setBaseColor( ColorRGBA baseColor ) {
        this.baseColor = baseColor;
        version++;
    }
       
    public ColorRGBA getBaseColor() {
        return baseColor;
    }
       
    public void setNormalTexture( String normalTexture ) {
        this.normalTexture = normalTexture;
        version++;
    }
    
    public String getNormalTexture() {
        return normalTexture;
    }
    
    public void setMetallicRoughnessTexture( String metallicRoughnessTexture ) {
        this.metallicRoughnessTexture = metallicRoughnessTexture;
        version++;
    }
    
    public String getMetallicRoughnessTexture() {
        return metallicRoughnessTexture;
    }
    
    public void setSpecularTexture( String specularTexture ) {
        this.specularTexture = specularTexture;
        version++;
    }
    
    public String getSpecularTexture() {
        return specularTexture;
    }
 
    public void setSpecularColor( ColorRGBA specularColor ) {
        this.specularColor = specularColor;
    }
    
    public ColorRGBA getSpecularColor() {
        return specularColor;
    }
    
    public void setMetallic( double metallic ) {
        this.metallic = metallic;
        version++;
    }
    
    public double getMetallic() {
        return metallic;
    }
    
    public void setRoughness( double roughness ) {
        this.roughness = roughness;
        version++;
    }
     
    public double getRoughness() {
        return roughness;
    }
     
    public void setEmissionColor( ColorRGBA emissionColor ) {
        this.emissionColor = emissionColor;
        version++;
    }
    
    public ColorRGBA getEmissionColor() {
        return emissionColor;
    }
    
    public void setEmissionTexture( String emissionTexture ) {
        this.emissionTexture = emissionTexture;
        version++;
    }
    
    public String getEmissionTexture() {
        return emissionTexture;
    }
    
    public void setEdgeTexture( String edgeTexture ) {
        this.edgeTexture = edgeTexture;
        version++;
    }
    
    public String getEdgeTexture() {
        return edgeTexture;
    }
    
    @Override
    public String toString() {
        return "FabricInfo[" + name + "]";
    }

}

/*
        // Alpha threshold for fragment discarding
        Float AlphaDiscardThreshold (AlphaTestFallOff)

        //metalness of the material
        Float Metallic : 1.0
        //Roughness of the material
        Float Roughness : 1.0        
        // Base material color
        Color BaseColor : 1.0 1.0 1.0 1.0
        // The emissive color of the object
        Color Emissive        
        // the emissive power
        Float EmissivePower : 3.0        
        // the emissive intensity
        Float EmissiveIntensity : 2.0

        // BaseColor map
        Texture2D BaseColorMap

        // Metallic map
        Texture2D MetallicMap -LINEAR
        
        // Roughness Map
        Texture2D RoughnessMap -LINEAR

        //Metallic and Roughness are packed respectively in the b and g channel of a single map
        // r: unspecified
        // g: Roughness
        // b: Metallic
        Texture2D MetallicRoughnessMap -LINEAR
        
        // Texture of the emissive parts of the material
        Texture2D EmissiveMap

        // Normal map
        Texture2D NormalMap -LINEAR

        //The type of normal map: -1.0 (DirectX), 1.0 (OpenGl)
        Float NormalType : -1.0

        // For Spec gloss pipeline
        Boolean UseSpecGloss
        Texture2D SpecularMap
        Texture2D GlossinessMap
        Texture2D SpecularGlossinessMap
        Color Specular : 1.0 1.0 1.0 1.0
        Float Glossiness : 1.0

        // Parallax/height map
        Texture2D ParallaxMap -LINEAR

        //Set to true if parallax map is stored in the alpha channel of the normal map
        Boolean PackedNormalParallax   

        //Sets the relief height for parallax mapping
        Float ParallaxHeight : 0.05       

        //Set to true to activate Steep Parallax mapping
        Boolean SteepParallax

        //Horizon fade
        Boolean HorizonFade

*/


