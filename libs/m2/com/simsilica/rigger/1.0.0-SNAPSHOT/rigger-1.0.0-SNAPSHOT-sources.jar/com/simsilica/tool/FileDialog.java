/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FileDialog extends Container {
    static Logger log = LoggerFactory.getLogger(FileDialog.class);
    
    public static final ElementId BASE_ID = new ElementId("file.dialog");
 
    private ListBox<String> fileList;
    private String selectedFile;
 
    private Runnable close;
    
    public FileDialog( String titleText, List<String> files, String actionName, Runnable close ) {
        super(null, true, BASE_ID.child("container"), null);
        this.close = close;
 
        Label title = addChild(new Label(titleText, BASE_ID.child("title.label")));

        // Set the preferred width of the title so that the whole box is nice and wide
        Vector3f pref = title.getPreferredSize();
        pref.x = Math.max(pref.x, 200);
        title.setPreferredSize(pref);
 
        fileList = addChild(new ListBox<String>(new VersionedList<>(files)));
        fileList.setVisibleItems(10);
 
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction(actionName, this, "ok")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", this, "cancel")));
    }
    
    public String getSelectedFile() {
        return selectedFile;
    }
    
    protected void ok() {
        this.selectedFile = fileList.getSelectedItem();
        removeFromParent();
        close.run();
    }
    
    protected void cancel() {
        this.selectedFile = null;
        removeFromParent();
        close.run();
    }    
}


