/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.Direction;

/**
 *  Information about a particular type of swatch shape.
 *
 *  @author    Paul Speed
 */
public class SwatchShape {
    static Logger log = LoggerFactory.getLogger(SwatchShape.class);
    
    private String name;
    private Vec3i sourceCell;
    private List<Direction> edges;
    private int forcedMask;
 
    // There should be a variant for each combination of non-bordering
    // edges.  The baseCell has no edge normals.  Each variant has some
    // combination of edge normals.   
    //private List<Integer> variants;
 
    private Map<Integer, Integer> variants = new HashMap<>();
    
    private SwatchShape() {
    }
     
    public SwatchShape( String name, int xSourceCell, int ySourceCell ) {
        this.name = name;
        this.sourceCell = new Vec3i(xSourceCell, ySourceCell, 0);
        this.edges = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    
    public Vec3i getSourceCell() {
        return sourceCell;
    }
 
    public void addEdges( Direction... dirs ) {
        edges.addAll(Arrays.asList(dirs));
        Collections.sort(edges);
    }
 
    public List<Direction> getEdges() {
        return edges;
    }
    
    //public List<Integer> getVariants() {
    //    return variants;
    //}    
    
    public static int dirsToMask( Direction... dirs ) {
        // Dir masks in this case aren't suitable for packing
        // cells but they are fine for a simple integer key
        int result = 0;
        for( Direction d : dirs ) {
            result = result | d.getBitMask();
        }
        return result;
    } 

    public static int dirsToMask( Collection<Direction> dirs ) {
        // Dir masks in this case aren't suitable for packing
        // cells but they are fine for a simple integer key
        int result = 0;
        for( Direction d : dirs ) {
            result = result | d.getBitMask();
        }
        return result;
    } 
    
    public void setForcedMask( int dirMask ) {
        this.forcedMask = dirMask;
    }
    
    public int getForcedMask() {
        return forcedMask;
    }
    
    public void setVariantIndex( int dirMask, int index ) {
        variants.put(dirMask, index); 
    }

    public Integer getVariantIndex( Direction... dirs ) {
        return getVariantIndex(dirsToMask(dirs));
    }
    
    public Integer getVariantIndex( int dirMask ) {
        return variants.get(dirMask);
    } 

    public Map<Integer, Integer> getVariants() {
        return variants;
    }   
}

