/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.function.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.value.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ProbeEditor extends Container {
    static Logger log = LoggerFactory.getLogger(ProbeEditor.class);

    private ProbeInfo probe;
    private IntegerEditor size;
    private IntegerEditor layers;
    private IntegerEditor stepDownLayers;
    private IntegerEditor groundLayers;
    private IntegerEditor stepUpLayers;
    private IntegerEditor jumpLayers;
    private DoubleEditor rigHeight;
    private DoubleEditor yOffset;

    public ProbeEditor() {
        Container props = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        Container sub = props.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        sub.addChild(new Label("Size:"));
        this.size = new IntegerEditor(1, 16, 1);
        sub.addChild(size.editor, 1);

        sub.addChild(new Label("Layers:"));
        this.layers = new IntegerEditor(1, 16, 1);
        sub.addChild(layers.editor, 1);

        sub = props.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));

        sub.addChild(new Label("Step down layers:"));
        this.stepDownLayers = new IntegerEditor(1, 16, 1);
        sub.addChild(stepDownLayers.editor, 1);

        sub.addChild(new Label("Ground layers:"));
        this.groundLayers = new IntegerEditor(1, 16, 1);
        sub.addChild(groundLayers.editor, 1);

        sub.addChild(new Label("Step up layers:"));
        this.stepUpLayers = new IntegerEditor(1, 16, 1);
        sub.addChild(stepUpLayers.editor, 1);

        sub.addChild(new Label("Jump layers:"));
        this.jumpLayers = new IntegerEditor(1, 16, 1);
        sub.addChild(jumpLayers.editor, 1);

        sub = props.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        sub.addChild(new Label("Rig Height:"));
        this.rigHeight = new DoubleEditor(0.1, 4, 0.05, 0.01);
        sub.addChild(rigHeight.editor, 1);

        sub.addChild(new Label("Y Offset:"));
        this.yOffset = new DoubleEditor(0, 4, 0.01, 0.01);
        sub.addChild(yOffset.editor, 1);
    }

    public void setProbe( ProbeInfo probe ) {
        log.info("setProbe(" + probe + ")");
        this.probe = probe;
        resetFields();
    }

    public ProbeInfo getProbe() {
        return probe;
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        boolean changed = false;
        if( size.update() ) {
            changed = true;
        }
        if( layers.update() ) {
            changed = true;
        }
        if( stepDownLayers.update() ) {
            changed = true;
        }
        if( groundLayers.update() ) {
            changed = true;
        }
        if( stepUpLayers.update() ) {
            changed = true;
        }
        if( jumpLayers.update() ) {
            changed = true;
        }
        if( rigHeight.update() ) {
            changed = true;
        }
        if( yOffset.update() ) {
            changed = true;
        }
    }

    protected void resetFields() {
        if( probe == null ) {
            size.getter(() -> 1).setter( (i) -> {});
            layers.getter(() -> 2).setter( (i) -> {});
            stepDownLayers.getter(() -> 1).setter( (i) -> {});
            groundLayers.getter(() -> 1).setter( (i) -> {});
            stepUpLayers.getter(() -> 1).setter( (i) -> {});
            jumpLayers.getter(() -> 1).setter( (i) -> {});
            rigHeight.getter(() -> 1.5).setter( (d) -> {});
            yOffset.getter(() -> 0.0).setter( (d) -> {});
        } else {
            size.getter(probe::getSize).setter(probe::setSize);
            layers.getter(probe::getLayers).setter(probe::setLayers);
            stepDownLayers.getter(probe::getStepDownLayers).setter(probe::setStepDownLayers);
            groundLayers.getter(probe::getGroundLayers).setter(probe::setGroundLayers);
            stepUpLayers.getter(probe::getStepUpLayers).setter(probe::setStepUpLayers);
            jumpLayers.getter(probe::getJumpLayers).setter(probe::setJumpLayers);
            rigHeight.getter(probe::getRigHeight).setter(probe::setRigHeight);
            yOffset.getter(probe::getYOffset).setter(probe::setYOffset);
        }
    }

    private class IntegerEditor {
        Spinner<Double> editor;
        SequenceModel<Double> model;
        VersionedReference<Double> valueRef;
        Supplier<Integer> getter;
        Consumer<Integer> setter;

        public IntegerEditor( int min, int max, int step ) {
            this.model = SequenceModels.rangedSequence(
                        new DefaultRangedValueModel(min, max, 0),
                        step, 1);
            this.valueRef = model.createReference();
            DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.0f", "error");

            this.editor = new Spinner<>(model, renderer);
            editor.setValueEditor(ValueEditors.doubleEditor("%.0f"));
        }

        public IntegerEditor getter( Supplier<Integer> getter ) {
            this.getter = getter;
            if( getter != null ) {
                model.setObject((double)getter.get());
            }
            return this;
        }

        public IntegerEditor setter( Consumer<Integer> setter ) {
            this.setter = setter;
            return this;
        }

        public boolean update() {
            if( valueRef.update() ) {
                if( setter != null ) {
                    setter.accept((int)(double)model.getObject());
                }
                return true;
            }
            return false;
        }
    }

    private class DoubleEditor {
        Spinner<Double> editor;
        SequenceModel<Double> model;
        VersionedReference<Double> valueRef;
        Supplier<Double> getter;
        Consumer<Double> setter;

        public DoubleEditor( double min, double max, double step, double precision ) {
            this.model = SequenceModels.rangedSequence(
                        new DefaultRangedValueModel(min, max, 0),
                        step, precision);
            this.valueRef = model.createReference();
            DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");

            this.editor = new Spinner<>(model, renderer);
            editor.setValueEditor(ValueEditors.doubleEditor("%.2f"));
        }

        public DoubleEditor getter( Supplier<Double> getter ) {
            this.getter = getter;
            if( getter != null ) {
                model.setObject(getter.get());
            }
            return this;
        }

        public DoubleEditor setter( Consumer<Double> setter ) {
            this.setter = setter;
            return this;
        }

        public boolean update() {
            if( valueRef.update() ) {
                if( setter != null ) {
                    setter.accept(model.getObject());
                }
                return true;
            }
            return false;
        }
    }
}
