/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.text.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MovementModeEditor extends Container {
    static Logger log = LoggerFactory.getLogger(MovementModeEditor.class);
 
    private MovementMode mode;
    
    private TextField nameEditor;
    private VersionedReference<DocumentModel> nameRef;
 
    private MovementAnimationTable basicAnimation;
    private MovementAnimationTable mixAnimation;
    
    public MovementModeEditor() {
        
        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        properties.addChild(new Label("Name:"));
        nameEditor = properties.addChild(new TextField(""), 1);
        nameRef = nameEditor.getDocumentModel().createReference();    
    
        addChild(new Label("Basic:"));
        basicAnimation = addChild(new MovementAnimationTable());
        
        addChild(new Label("Mix:"));
        mixAnimation = addChild(new MovementAnimationTable()); 
    }

    public void setClipNames( VersionedList<String> clipNames ) {
        basicAnimation.setClipNames(clipNames);
        mixAnimation.setClipNames(clipNames);
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
 
        if( mode == null ) {
            return;
        }        
        
        if( nameRef.update() ) {
            mode.setName(nameEditor.getText());
            log.info("new mode name:" + mode.getName());
        }        
    }    
    
    public void setMovementMode( MovementMode mode ) {  
        if( this.mode == mode ) {
            return;
        }
        this.mode = mode;
        updateComponents();
    }
    
    public MovementMode getMovementMode() {
        return mode;
    }
    
    protected void updateComponents() {
        if( mode == null ) {
            nameEditor.setText("");
            basicAnimation.setList(null);
            mixAnimation.setList(null);
        } else {
            nameEditor.setText(mode.getName());
            basicAnimation.setList(mode.getBasicAnimation());
            mixAnimation.setList(mode.getMixAnimation());
        }
    }       
}


