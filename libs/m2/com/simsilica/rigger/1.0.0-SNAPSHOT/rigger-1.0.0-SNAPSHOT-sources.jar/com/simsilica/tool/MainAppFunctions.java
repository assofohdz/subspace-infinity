/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.input.KeyInput;
import com.simsilica.lemur.input.Button;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MainAppFunctions {

    public static final FunctionId F_HELP = new FunctionId("Help");

    public static final FunctionId F_NEW = new FunctionId("New");
    public static final FunctionId F_OPEN = new FunctionId("Open");
    public static final FunctionId F_SAVE = new FunctionId("Save");
    public static final FunctionId F_SAVE_AS = new FunctionId("Save As");
    public static final FunctionId F_EXIT = new FunctionId("Exit");

    public static final FunctionId F_UNDO = new FunctionId("Undo");
    public static final FunctionId F_REDO = new FunctionId("Redo");

    public static void initializeDefaultMappings( InputMapper inputMapper ) {

        inputMapper.map(F_HELP, KeyInput.KEY_F1);

        inputMapper.map(F_NEW, KeyInput.KEY_N, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_OPEN, KeyInput.KEY_O, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_SAVE, KeyInput.KEY_S, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_SAVE_AS, KeyInput.KEY_A, KeyInput.KEY_LCONTROL);
        //inputMapper.map(F_EXIT, KeyInput.KEY_ESCAPE);

        inputMapper.map(F_UNDO, KeyInput.KEY_Z, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_UNDO, KeyInput.KEY_Z, KeyInput.KEY_RCONTROL);

        inputMapper.map(F_REDO, KeyInput.KEY_Y, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_REDO, KeyInput.KEY_Y, KeyInput.KEY_RCONTROL);
    }
}
