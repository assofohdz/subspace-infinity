/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.BufferUtils;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.phys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class PartUtils {
    static Logger log = LoggerFactory.getLogger(PartUtils.class);
 
    private static Sphere sphere = new Sphere(8, 8, 1);
    
    // Putting this here for now
    public static Geometry createWire( CellArrayPart part ) {

        float scale = (float)part.getScale();
        float radius = (float)part.getRadius();
        
        if( part.getType() == CellArrayPart.Type.Sphere ) {
            // The easy case
            Geometry geom = new Geometry(part.getName(), sphere);
            geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.White, false).getMaterial());
            geom.setLocalScale(radius);
            geom.getMaterial().getAdditionalRenderState().setWireframe(true);
            return geom;      
        }
             
        //// Just make a box for testing
        //log.info(" size:" + size + "  radius:" + radius);        
        ////Box box = new Box(size, size, size);
        //Box box = new Box(radius, radius, radius);
        //Geometry geom = new Geometry("test", box);
        //geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Blue, false).getMaterial());
        //return geom;
        
        
        // Build up the part's faces as unique edges.
        // Because we only deal with raw blocks here it's easy enough.
        ListMultimap<Edge, String> map = MultimapBuilder.hashKeys().arrayListValues().build();
        
        CellArray cells = part.getCells();
        int xSize = cells.getSizeX(); 
        int ySize = cells.getSizeY(); 
        int zSize = cells.getSizeZ();
//log.info("size:" + xSize + ", " + ySize + ", " + zSize);         
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int val = cells.getCell(i, j, k);
                    //log.info("[" + i + "][" + j + "][" + k + "] = " + val);
                    int mask = MaskUtils.getSideMask(val);
                    for( Direction dir : Direction.values() ) {
                        if( (dir.getBitMask() & mask) != 0 ) {
                            // Emit the edges
 
                            // Wasteful to create this every time
                            GeomPart gp = GeomPart.createFace(new MaterialType("waste"), dir);
                            float[] coords = gp.getCoords();
                            Vec3d v1 = round(new Vec3d(i + coords[0], j + coords[1], k + coords[2]));
                            Vec3d v2 = round(new Vec3d(i + coords[3], j + coords[4], k + coords[5]));
                            Vec3d v3 = round(new Vec3d(i + coords[6], j + coords[7], k + coords[8]));
                            Vec3d v4 = round(new Vec3d(i + coords[9], j + coords[10], k + coords[11]));
                            
                            Edge e1 = new Edge(v1, v2, dir.getVec3i().toVec3d());
                            Edge e2 = new Edge(v2, v3, dir.getVec3i().toVec3d());
                            Edge e3 = new Edge(v3, v4, dir.getVec3i().toVec3d());
                            Edge e4 = new Edge(v4, v1, dir.getVec3i().toVec3d());
 
                            // We only want the unique edges so we'll keep track
                            // of how many times we hit a particular edge by just
                            // keeping a list                           
                            map.put(e1, "");
                            map.put(e2, "");
                            map.put(e3, "");
                            map.put(e4, "");
                        }
                    }
                }
            }
        }
        //log.info("Map size:" + map.size());
        
        List<Vector3f> verts = new ArrayList<>();
        for( Edge edge : map.keySet() ) {
            List<String> list = map.get(edge);
            //log.info("edge:" + edge.v1 + " -> " + edge.v2 + "  normal:" + edge.normal + "  count:" + list.size());
            if( list.size() > 1 ) {
                continue;
            }
            verts.add(edge.v1.toVector3f());
            verts.add(edge.v2.toVector3f());
        }
 
        //log.info("Vert count:" + verts.size());
        
        Vector3f[] array = verts.toArray(new Vector3f[0]); 
        Mesh mesh = new Mesh();        
        mesh.setMode(Mesh.Mode.Lines);        
        mesh.setBuffer(VertexBuffer.Type.Position, 3, BufferUtils.createFloatBuffer(array));
        mesh.updateBound();

        Geometry geom = new Geometry(part.getName(), mesh);
        geom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.White, false).getMaterial());
        geom.setLocalScale(scale);
        geom.getMaterial().getAdditionalRenderState().setWireframe(true);
        return geom;
    }
    
    private static Vec3d round( Vec3d v ) {
        v.x = Math.round(v.x);
        v.y = Math.round(v.y);
        v.z = Math.round(v.z);
        return v;
    }
    
    private static class Edge {
        Vec3d v1;
        Vec3d v2;
        Vec3d normal;
        
        public Edge( Vec3d v1, Vec3d v2, Vec3d normal ) {
        
            // Sort the verts for consistent ordering between
            // edges
            if( v1.hashCode() < v2.hashCode() ) {
                this.v1 = v1;
                this.v2 = v2;
            } else {
                this.v1 = v2;
                this.v2 = v1;
            }
        
            this.normal = normal;
        }
 
        public int hashCode() {
            return Objects.hash(v1, v2, normal);
        }
        
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            Edge other = (Edge)o;
            if( !Objects.equals(other.v1, v1) ) {
                return false;
            }
            if( !Objects.equals(other.v2, v2) ) {
                return false;
            }
            if( !Objects.equals(other.normal, normal) ) {
                return false;
            }
            return true;
        }
    }   
}
