/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;
import com.google.gson.*;


/**
 *  Config settings for the Rigger tool.
 *
 *  @author    Paul Speed
 */
public class RiggerConfig {

    public static final String CONFIG_FILE = "rigger.config";
    public static final String DEFAULT_PROJECT_DIR = ".";
    public static final String DEFAULT_BINARY_DIR = "binaries";
    public static final String DEFAULT_RIG_BINARY_DIR = "binaries/rigs";
    public static final String DEFAULT_MODEL_BINARY_DIR = "binaries/Models";
    public static final String DEFAULT_SCRIPT_DIR = "init-scripts";
    public static final String DEFAULT_BLOCKS_FILE = "blocks.bset";
    public static final String DEFAULT_FLUIDS_FILE = "fluids.fset";
    public static final String DEFAULT_MATERIALS_FILE = "materials.mset";
    public static final String DEFAULT_MODS_DIR = "mods";

    static Logger log = LoggerFactory.getLogger(RiggerConfig.class);

    private String projectDir;
    private String scriptDir;
    private String binaryDir;
    private String rigBinaryDir;
    private String modelBinaryDir;
    private String blocksFile;
    private String fluidsFile;
    private String materialsFile;
    private String modsDir;

    private Map<String, Object> startupSettings;

    private static RiggerConfig instance;

    public RiggerConfig() {
    }

    protected void initializeDefaults() {
        this.projectDir = DEFAULT_PROJECT_DIR;
        this.scriptDir = DEFAULT_SCRIPT_DIR;
        this.blocksFile = DEFAULT_BLOCKS_FILE;
        this.fluidsFile = DEFAULT_FLUIDS_FILE;
        this.materialsFile = DEFAULT_MATERIALS_FILE;
        this.modsDir = DEFAULT_MODS_DIR;
        this.startupSettings = new HashMap<>();
    }

    protected boolean upgrade() {
        boolean changed = false;
        if( rigBinaryDir == null ) {
            if( binaryDir != null ) {
                rigBinaryDir = modelBinaryDir + "/rigs";
            } else {
                rigBinaryDir = DEFAULT_RIG_BINARY_DIR;
            }
            File f = getFile(rigBinaryDir);
            if( !f.exists() ) {
                f.mkdirs();
            }
            changed = true;
        }
        if( modelBinaryDir == null ) {
            if( binaryDir != null ) {
                modelBinaryDir = modelBinaryDir + "/Models";
            } else {
                modelBinaryDir = DEFAULT_MODEL_BINARY_DIR;
            }
            File f = getFile(modelBinaryDir);
            if( !f.exists() ) {
                f.mkdirs();
            }
            changed = true;
        }
        if( scriptDir == null ) {
            scriptDir = DEFAULT_SCRIPT_DIR;
            changed = true;
        }
        if( modsDir == null ) {
            modsDir = DEFAULT_MODS_DIR;
            changed = true;
        }
        if( startupSettings == null ) {
            this.startupSettings = new HashMap<>();
            changed = true;
        }
        if( blocksFile == null ) {
            blocksFile = DEFAULT_BLOCKS_FILE;
            changed = true;
        }
        if( fluidsFile == null ) {
            this.fluidsFile = DEFAULT_FLUIDS_FILE;
            changed = true;
        }
        if( materialsFile == null ) {
            this.materialsFile = DEFAULT_MATERIALS_FILE;
            changed = true;
        }

        //if( binaryDir == null ) {
        //    binaryDir = DEFAULT_BINARY_DIR;
        //    File f = getFile(binaryDir);
        //    if( !f.exists() ) {
        //        f.mkdirs();
        //    }
        //}
        return changed;
    }

    public File getProjectDir() {
        return new File(projectDir);
    }

    public File getScriptsDir() {
        File result = new File(projectDir, scriptDir);
        if( !result.exists() ) {
            result.mkdirs();
        }
        return result;
    }

    public File getModsDir() {
        File result = new File(projectDir, modsDir);
        if( !result.exists() ) {
            result.mkdirs();
        }
        return result;
    }

    //public File getBinaryDir() {
    //    return getFile(binaryDir);
    //}

    public File getRigBinaryDir() {
        return getFile(rigBinaryDir);
    }

    public File getModelBinaryDir() {
        return getFile(modelBinaryDir);
    }

    public File getBlocksFile() {
        return new File(projectDir + "/" + blocksFile);
    }

    public File getFluidsFile() {
        return new File(projectDir + "/" + fluidsFile);
    }

    public File getMaterialsFile() {
        return new File(projectDir + "/" + materialsFile);
    }

    public File getFile( String name ) {
        return new File(getProjectDir(), name);
    }

    @SuppressWarnings("unchecked")
    public <T> T getStartupSetting( String key, T defaultValue ) {
        if( startupSettings.containsKey(key) ) {
            return (T)startupSettings.get(key);
        }
        return defaultValue;
    }

    public int getStartupSettingInt( String key, int defaultValue ) {
        if( !startupSettings.containsKey(key) ) {
            return defaultValue;
        }
        Number result = getStartupSetting(key, null);
        if( result == null ) {
            return defaultValue;
        }
        return result.intValue();
    }

    public Map<String, Object> getStartupSettings() {
        return startupSettings;
    }

    public static RiggerConfig getInstance() {
        if( instance == null ) {
            try {
                instance = load(new File(CONFIG_FILE));
                if( instance.upgrade() ) {
                    store(instance, new File(CONFIG_FILE));
                }
            } catch( Exception e ) {
                log.error("Error loading config file.  Initializing defaults", e);
            }
        }
        if( instance == null ) {
            instance = new RiggerConfig();
            instance.initializeDefaults();
            File f = new File(CONFIG_FILE);
            if( !f.exists() ) {
                store(instance, new File(CONFIG_FILE));
            }
        }
        return instance;
    }

    public static RiggerConfig load( File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return gson.fromJson(json, RiggerConfig.class);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }

    public static void store( RiggerConfig config, File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + f);
            String json = gson.toJson(config);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }
}

