/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MovementAnimation implements VersionedObject<MovementAnimation> {
    static Logger log = LoggerFactory.getLogger(MovementAnimation.class);
 
    private long version;
    
    private String animation;
    private Vec3d baseVelocity = new Vec3d();
    private double scale = 1.0;
    
    public MovementAnimation() {
    }
    
    public static MovementAnimation createDefault( String animation, double speed ) {
        MovementAnimation result = new MovementAnimation();
        result.animation = animation;
        result.baseVelocity.set(0, 0, speed);
        return result;
    }
    
    public void setAnimation( String animation ) {
        this.animation = animation;
        version++;
    }
    
    public String getAnimation() {
        return animation;
    }
 
    public void setBaseVelocity( Vec3d v ) {
        baseVelocity.set(v);
        version++;
    }
 
    public Vec3d getBaseVelocity() {
        return baseVelocity;
    }
    
    public void setScale( double scale ) {
        this.scale = scale;
        version++;
    }
    
    public double getScale() {
        return scale;
    }
    
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public MovementAnimation getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<MovementAnimation> createReference() {
        return new VersionedReference<>(this);
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[animation:" + animation + ", baseVelocity:" + baseVelocity + ", scale:" + scale + "]";
    }
}
