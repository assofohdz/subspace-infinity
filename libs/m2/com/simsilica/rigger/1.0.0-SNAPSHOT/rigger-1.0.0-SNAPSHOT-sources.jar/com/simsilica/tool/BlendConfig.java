/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedList;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;

import com.simsilica.crig.BlendInfo;

/**
 *  Editable/saveable wrapper for a crig BlendInfo.
 *
 *  @author    Paul Speed
 */
public class BlendConfig implements VersionedObject<BlendConfig> {
    static Logger log = LoggerFactory.getLogger(BlendConfig.class);
 
    private transient long version;
 
    private String name;
    private VersionedList<String> blendedActions = new VersionedList<>();
    private double defaultBlend;
    
    public BlendConfig() {
    }

    public BlendConfig( String name ) {
        this.name = name;
    }
    
    public BlendInfo createBlendInfo() {
        BlendInfo result = new BlendInfo(name);
        result.setBlendedActions(blendedActions.toArray(new String[0]));
        result.setDefaultBlend(defaultBlend); 
        return result;
    }
 
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public BlendConfig getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<BlendConfig> createReference() {
        return new VersionedReference<>(this);
    }
    
    public void setName( String name ) {
        this.name = name;
        version++;
    }
    
    public String getName() {
        return name;
    }
    
    public VersionedList<String> getBlendedActions() {
        return blendedActions;
    }
    
    public void setDefaultBlend( double defaultBlend ) {
        this.defaultBlend = defaultBlend;
        version++;
    }
    
    public double getDefaultBlend() {
        return defaultBlend;
    }
    
    public String toString() {
        return "BlendConfig[" + name + "]";
    }
}
