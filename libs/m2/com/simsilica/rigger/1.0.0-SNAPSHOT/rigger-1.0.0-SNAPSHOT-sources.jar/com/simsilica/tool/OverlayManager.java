/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;

/**
 *  UI element that lets the user manage the list of overlays
 *  for a rig.
 *
 *  @author    Paul Speed
 */
public class OverlayManager extends Container {
    static Logger log = LoggerFactory.getLogger(OverlayManager.class);
    
    private Rig rig;
    private RigInfo rigInfo;
    private VersionedList<String> jointNames = new VersionedList<>();
    private VersionedReference<OverlayInfo> selectedOverlayRef;

    private ListBox<OverlayInfo> overlayList;
    private VersionedReference<Integer> listSelectionRef;

    private Container editorHolder;   
    private OverlayEditor overlayEditor;
    private VersionedReference<OverlayInfo> attRef;
    
    public OverlayManager() {
        overlayList = addChild(new ListBox<OverlayInfo>());
        listSelectionRef = overlayList.getSelectionModel().createSelectionReference();
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("New", this, "addOverlay")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeOverlay")));

        editorHolder = addChild(new Container());
        editorHolder.setBackground(null);
        overlayEditor = new OverlayEditor(jointNames);       
        
        // It would be good to be able to see not only the names of the joints
        // we could mask but the joints actually affected by the selected animations. 
    }

    public void setRig( Rig rig ) {
        if( this.rig == rig ) {
            return;
        }
        this.rig = rig;
        if( rig == null ) {
            rigInfo = null;
            jointNames.clear();
            selectedOverlayRef = null;
            overlayList.setModel(new VersionedList<OverlayInfo>());
            overlayEditor.setOverlay(null);
        } else {
            rigInfo = rig.getRigInfo();
            
            overlayList.setModel(rigInfo.getOverlays());
            
            jointNames.clear();
            jointNames.addAll(rig.getJointNames());
             
            selectedOverlayRef = rig.createSelectedOverlayReference();
        }
    }
    
    public Rig getRig() {
        return rig;
    }
    
    protected void addOverlay() {
        int index = rigInfo.getOverlays().size(); 
        OverlayInfo item = new OverlayInfo("att_" + index);
        rigInfo.getOverlays().add(item);
        
        overlayList.getSelectionModel().setSelection(index);
    }
    
    protected void removeOverlay() {
        rigInfo.getOverlays().remove(overlayList.getSelectedItem());
    }
 
    protected void selectOverlay() {
        OverlayInfo item = overlayList.getSelectedItem();
        rig.setSelectedOverlay(item);
        attRef = item == null ? null : item.createReference(); 
    }
 
    protected void editOverlay() {        
        OverlayInfo item = selectedOverlayRef.get();
        log.info("editOverlay():" + item);
        int index = rigInfo.getOverlays().indexOf(item);
        Integer selection = overlayList.getSelectionModel().getSelection();
        selection = selection == null ? -1 : selection;
        if( selection != index ) {
            overlayList.getSelectionModel().setSelection(index);   
        }
        overlayEditor.setOverlay(item);
        if( item == null ) {
            overlayEditor.removeFromParent();
        } else {
            editorHolder.addChild(overlayEditor);
        }
    }
    
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        if( listSelectionRef.update() ) {
            selectOverlay();
        }
        if( selectedOverlayRef != null && selectedOverlayRef.update() ) {
            editOverlay();
        }
        if( attRef != null && attRef.update() ) {
            log.info("refresh list");
            // Cheating a bit because we know this will refresh the list
            // view... and by the time it won't maybe there will be an API
            // for it.
            GridPanel grid = overlayList.getGridPanel();
            grid.setVisibleRows(grid.getVisibleRows());            
        }
    }
}
