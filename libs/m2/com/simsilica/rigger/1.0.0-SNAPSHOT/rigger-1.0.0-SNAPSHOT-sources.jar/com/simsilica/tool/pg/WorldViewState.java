/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.pg;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.scene.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.geom.GeometryFactory;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.LightNeighborhood;
import com.simsilica.thread.*;

/**
 *  Views a fixed size area of a World and keeps it up-to-date with
 *  world changes.
 *
 *  @author    Paul Speed
 */
public class WorldViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(WorldViewState.class);

    private GeometryFactory geomFactory;
    private JobState workers;
    private World world;
    private Vec3i center;
    private int radius;
    private WorldObserver worldListener;

    private Map<LeafId, LeafView> leafViews = new ConcurrentHashMap<>();
    private Node worldRoot;

    public WorldViewState( GeometryFactory geomFactory, int radius ) {
        this(geomFactory, new Vec3i(), radius);
    }

    public WorldViewState( GeometryFactory geomFactory, Vec3i center, int radius ) {
        this.geomFactory = geomFactory;
        this.center = center;
        this.radius = radius;
    }

    public Node getWorldRoot() {
        return worldRoot;
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    @Override
    protected void initialize( Application app ) {
        this.worldRoot = new Node("worldRoot");
        worldRoot.setLocalScale(0.25f);
        this.workers = getState(JobState.class);
        this.world = getState(GameSystemState.class).get(World.class, true);
        world.addLeafChangeListener(worldListener);

        // Build out the leaf views
        int yMax = world.getMaxY() / LeafId.SIZE;
        for( int x = -radius; x <= radius; x++ ) {
            for( int y = 0; y < yMax; y++ ) {
                for( int z = -radius; z <= radius; z++ ) {
                    LeafId leafId = LeafId.fromWorld(center.add(x * LeafId.SIZE, y * LeafId.SIZE, z * LeafId.SIZE));
                    LeafView view = new LeafView(leafId);
                    leafViews.put(leafId, view);
                    view.enqueueIfNeeded();
                }
            }
        }
    }

    @Override
    protected void cleanup( Application app ) {
        world.removeLeafChangeListener(worldListener);
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(worldRoot);
    }

    @Override
    protected void onDisable() {
        worldRoot.removeFromParent();
    }

    protected class LeafView implements Job {
        private Vec3i worldPos;
        private LeafId leafId;
        private LeafData leaf;
        private FluidData fluid;
        private LightData light;
        private LightNeighborhood lightData;
        private boolean changed;
        private boolean enqueued;

        private AtomicReference<Node> built = new AtomicReference<>();
        private Node lastBuilt;

        public LeafView( LeafId leafId ) {
            this.leafId = leafId;
            this.worldPos = leafId.getWorld(null);
            this.changed = true; // haven't loaded any data yet
        }

        public synchronized void markChanged() {
            this.changed = true;
            enqueueIfNeeded();
        }

        public synchronized void enqueueIfNeeded() {
            if( enqueued || !changed ) {
                return;
            }
            this.enqueued = true;
            workers.execute(this, 100);
        }

        public void runOnWorker() {
            synchronized( this ) {
                enqueued = false;
                changed = false;
            }
            this.leaf = world.getLeaf(leafId);
            log.info(this + " got data:" + leaf);
            synchronized(leaf) {
                this.fluid = world.getFluid(leafId);
                if( leaf.isEmpty() && fluid.isEmpty() ) {
                    built.set(null);
                    return;
                }

                this.light = world.getLight(leafId);
                this.lightData = new LightNeighborhood(world, light);

                // Create a new guaranteed unconnected node for our parts
                Node temp = new Node("Parts:" + leafId);
                if( !leaf.isEmpty() ) {
                    geomFactory.generateBlocks(temp, leaf.getRawCells(), lightData, true);
                }
                if( !fluid.isEmpty() ) {
                    Node fluidNode = new Node("Fluid:"+ leafId);
                    temp.attachChild(fluidNode);
                    geomFactory.generateFluid(fluidNode, fluid.getRawCells(), leaf.getRawCells(), lightData, true);
                }

                temp.setLocalTranslation(worldPos.toVector3f());
                built.set(temp);
            }
        }

        public double runOnUpdate() {
            log.info(this + " runOnUpdate()");

            if( lastBuilt != null ) {
                lastBuilt.removeFromParent();
            }

            lastBuilt = built.get();
            if( lastBuilt != null ) {
                worldRoot.attachChild(lastBuilt);
            }

            return 1;
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[" + leafId.getWorld(null) + "]";
        }
    }

    protected class WorldObserver implements LeafChangeListener {
        public void leafChanged( LeafChangeEvent event ) {
            LeafView view = leafViews.get(event.getLeafId());
            if( view != null ) {
                view.markChanged();
            }
        }
    }
}
