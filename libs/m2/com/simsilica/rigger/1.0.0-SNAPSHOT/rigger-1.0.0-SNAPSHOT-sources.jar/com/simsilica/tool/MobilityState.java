/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.scene.*;
import com.jme3.scene.shape.Quad;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.component.*;
import com.simsilica.mathd.*;

import com.simsilica.crig.*;
import com.simsilica.crig.jme.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MobilityState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(MobilityState.class);

    private VersionedReference<Rig> rigRef;
    private Rig rig;
    private RigInfo rigInfo;

    private Container window;
    private VersionedReference<TabbedPanel.Tab> tabRef;

    private VersionedReference<Boolean> collidersOpen;

    private VersionedList<String> clipNames = new VersionedList<>();
    //private Selector<String> clipSelector;
    //private VersionedReference<String> clipRef;

    private Selector<MovementMode> modeSelector;
    private VersionedReference<MovementMode> selectedModeRef;
    private MovementModeEditor modeEditor;

    // Currently selected animation info
    private MovementAnimation movementAnim;

    // Physics related stuff
    private PhysicsState physics;
    private boolean tabVisible = false;
    private VersionedHolder<Vec3d> position = new VersionedHolder<>(new Vec3d(5, 0, 5));
    private Movement movement = new Movement();
    private Vec3dEditor velocityEditor;
    private VersionedReference<Vec3d> velocityRef;
    private Quad grid;

    private Node modelRoot;

    private CharacterRig cRig;
    //private AnimDriver animDriver = new AnimDriver();
    
    public MobilityState() {
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    @Override
    protected void initialize( Application app ) {

        rigRef = getState(RigViewState.class, true).createRigReference();
        physics = getState(PhysicsState.class, true);
        this.modelRoot = physics.getModelRoot();

        window = new Container();
        getState(ToolState.class).getTabs().addTab("Movement", window);

        tabRef = getState(ToolState.class).getTabs().getSelectionModel().createReference();

        //Container panel = window.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        //panel.addChild(new Label("Clip:"));
        //clipSelector = panel.addChild(new Selector<String>(clipNames), 1);
        //clipRef = clipSelector.createSelectedItemReference();

        Container panel = new Container();
        window.addChild(new RollupPanel("Animation", panel, null));
        Container properties = panel.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        properties.addChild(new Label("Mode:"));
        modeSelector = properties.addChild(new Selector<MovementMode>(), 1);
        selectedModeRef = modeSelector.createSelectedItemReference();

        modeEditor = panel.addChild(new MovementModeEditor());
        modeEditor.setClipNames(clipNames);

        Container movementPanel = new Container();
        RollupPanel movementRollup = window.addChild(new RollupPanel("Simulated Movement", movementPanel, null));
        movementPanel.addChild(new Label("Velocity:"));
        velocityEditor = movementPanel.addChild(new Vec3dEditor(Axis.X, -10, 10, 0.1, 0.01));
        velocityRef = velocityEditor.createReference();

        resetRig(rigRef.get());

        this.grid = getState(GridState.class, true).getQuad();

        //movement.setVelocity(0, 0, 1);
    }

    protected void resetRig( Rig rig ) {
        if( rig == null ) {
            return; // for now there will always be a rig
        }
        this.rig = rig;
        this.rigInfo = rig.getRigInfo();

        clipNames.clear();
        clipNames.addAll(rig.getClipNames());
        //clipSelector.setSelectedItem(null);
        //clipSelector.setSelectedItem("Idle");

        modeSelector.setModel(rigInfo.getMovementModes());
    }

    protected void tabVisible() {
        tabVisible = true;
        //rig.setCurrentAction(clipRef.get());
        //resetAnimation();
        physics.setMovementMode(selectedModeRef.get());
        //cRig = new SpatialCharacterRig(rig.getView());
        cRig = AnimComposerRig.createRig(rig.getView());
        physics.setRig(rig);
        physics.setEnabled(true);
        getRoot().attachChild(modelRoot);
    }

    protected void tabInvisible() {
        if( cRig != null ) {
            ((AnimComposerRig)cRig).release();
            modelRoot.removeFromParent();
        }
        physics.setEnabled(false);
        tabVisible = false;
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    public void update( float tpf ) {
        if( rigRef.update() ) {
            resetRig(rigRef.get());
        }
        if( tabRef.update() ) {
            if( tabRef.get() != null && tabRef.get().getContents() == window ) {
                tabVisible();
            } else {
                tabInvisible();
            }
        }
        //if( clipRef.update() ) {
        //    // Set the animation
        //    rig.setCurrentAction(clipRef.get());
        //}
        if( selectedModeRef.update() ) {
            modeEditor.setMovementMode(selectedModeRef.get());
            physics.setMovementMode(selectedModeRef.get());
            //resetAnimation();
        }

        if( velocityRef.update() ) {
            movement.setVelocity(velocityRef.get());
            //resetAnimation();
        }

        if( tabVisible ) {
            integrate(tpf);
        }
    }

    @Override
    protected void onDisable() {
    }

    //protected void resetAnimation() {
    //    MovementMode mode = modeEditor.getMovementMode();
    //    if( mode == null ) {
    //        return;
    //    }
    //
    //    // From the current animation set pick the best one and
    //    // mix them appropriately, etc.
    //
    //    double speed = movement.getVelocity().length();
    //    double forward = movement.getVelocity().dot(Vec3d.UNIT_Z);
    //
    //    // We want to find the best where our speed doesn't
    //    // exceed its base velocity... unless we are faster than
    //    // all of them in which case we'll just pick the max.
    //    // For now I'll do it in two passes because it's easier but
    //    // it could be done in one pass.
    //    MovementAnimation best = null;
    //    double maxDot = -1;
    //    for( MovementAnimation ma : mode.getBasicAnimation() ) {
    //        double length = ma.getBaseVelocity().length();
    //        double dot = 0;
    //        if( length != 0 ) {
    //            dot = ma.getBaseVelocity().divide(length).dot(movement.getVelocity());
    //        }
    //        // So now 'dot' will have how much of this ma's direction
    //        // we are heading in.
    //        if( dot > length ) {
    //            // We are going faster than this animation's base and so we
    //            // will see if there is a better one
    //            continue;
    //        }
    //        if( dot > maxDot ) {
    //            maxDot = dot;
    //            best = ma;
    //        }
    //    }
    //    if( best == null ) {
    //        // Just find the biggest
    //        for( MovementAnimation ma : mode.getBasicAnimation() ) {
    //            double dot = ma.getBaseVelocity().dot(movement.getVelocity());
    //            if( dot > maxDot ) {
    //                maxDot = dot;
    //                best = ma;
    //            }
    //        }
    //    }
    //
    //    log.info("best:" + best);
    //    double animSpeed = best.getScale();
    //    if( maxDot != 0 ) {
    //        animSpeed *= maxDot / best.getBaseVelocity().length();
    //    }
    //
    //    //rig.setCurrentAction(best.getAnimation(), animSpeed);
    //    animDriver.setCurrentAction(best.getAnimation(), animSpeed);
    //
    //    movementAnim = best;
    //}

    protected void integrate( double tpf ) {

        //if( movementAnim != null ) {
        //    double length = movementAnim.getBaseVelocity().length();
        //    double dot = 0;
        //    if( length != 0 ) {
        //        dot = movementAnim.getBaseVelocity().divide(length).dot(movement.getVelocity());
        //    }
        //    double animSpeed = movementAnim.getScale();
        //    if( dot != 0 ) {
        //        animSpeed = animSpeed * dot / movementAnim.getBaseVelocity().length();
        //    }
        //    //rig.setSpeed(animSpeed);
        //    animDriver.setSpeed(animSpeed);
        //}
        //animDriver.update(tpf);

        cRig.setLayerAction(null, physics.getCurrentAction());
        cRig.setTime(null, physics.getCurrentTime());

        //Vec3d pos = position.getObject();
        //pos.addLocal(movement.getVelocity().mult(tpf));
        //pos.x = pos.x % 10;
        //pos.z = pos.z % 10;
        //position.setObject(pos);
        Vec3d pos = physics.getRigPosition();

        physics.setRigVelocity(movement.getVelocity());

        // Reset the grid coordinates
        float u = (float)(1 + (pos.x / 10));
        float v = (float)(2 - (pos.z / 10));
        grid.setBuffer(VertexBuffer.Type.TexCoord, 2,
                        new float[]{u, v,
                                    u + 1, v,
                                    u + 1, v + 1,
                                    u, v + 1});

        //modelRoot.setLocalTranslation((float)-pos.x, -64, (float)-pos.z);
    }

    //private class AnimDriver {
    //    private double time;
    //    private String action;
    //    private double speed;
    //    private double length;
    //
    //    public AnimDriver() {
    //    }
    //
    //    public void setCurrentAction( String action, double speed ) {
    //        this.speed = speed;
    //        if( Objects.equals(this.action, action) ) {
    //            return;
    //        }
    //        this.time = 0;
    //        this.action = action;
    //        if( action != null ) {
    //            cRig.setLayerAction(null, action);
    //            length = cRig.getLayerDuration(null);
    //            physics.getShapeRig().setLayerAction(null, action);
    //        }
    //    }
    //
    //    public void setSpeed( double speed ) {
    //        this.speed = speed;
    //    }
    //
    //    public void update( double tpf ) {
    //        if( action == null ) {
    //            return;
    //        }
    //        time += tpf * speed;
    //        time = time % length;
    //        if( time < 0 ) {
    //            time = (time + length) % length;
    //        }
    //        cRig.setTime(null, time);
    //        physics.getShapeRig().setTime(null, time);
    //        physics.getShapeRig().update();
    //    }
    //}
}


