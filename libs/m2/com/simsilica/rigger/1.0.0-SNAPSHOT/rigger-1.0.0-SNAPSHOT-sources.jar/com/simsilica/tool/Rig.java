/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.anim.*;
import com.jme3.anim.tween.action.Action;
import com.jme3.anim.tween.action.BlendAction;
import com.jme3.anim.tween.action.LinearBlendSpace;
import com.jme3.bounding.BoundingBox;
import com.jme3.scene.*;
import com.jme3.scene.control.Control;

import com.simsilica.lemur.core.*;

import com.simsilica.crig.*;
import com.simsilica.crig.jme.*;

/**
 *  Combines the RigInfo with the runtime data structures of the
 *  armature, etc..
 *
 *  @author    Paul Speed
 */
public class Rig {
    static Logger log = LoggerFactory.getLogger(Rig.class);

    private RigInfo info;

    // Stick this here for now so everything can have it...
    // plus there is the chance the rigs might have custom shapes
    private ColliderShapes colliders = new ColliderShapes();

    // For now just the JME model, controls, etc.
    private Spatial model;
    private Spatial originalModel;
    private AnimComposer anim;
    private SkinningControl skin;
    private String currentAction;
    private Action animAction;
    private double currentSpeed;

    private VersionedHolder<AttachmentInfo> selectedAttachment = new VersionedHolder<>();
    private VersionedHolder<ColliderInfo> selectedCollider = new VersionedHolder<>();
    private VersionedHolder<OverlayInfo> selectedOverlay = new VersionedHolder<>();

    public Rig( RigInfo info, Spatial model ) {
        this.info = info;
        this.originalModel = model.clone();
        this.model = model;
        this.anim = AnimComposerRig.findControl(model, AnimComposer.class);
        this.skin = AnimComposerRig.findControl(model, SkinningControl.class);

        if( skin != null ) {
            // We need to know where we're clicking
            skin.setHardwareSkinningPreferred(false);
            // ...though it doesn't seem to matter unless we clear the collision
            // data all the time.
        }

        // Setup any of the preconfigured blends
        for( BlendConfig blend : info.getBlends() ) {
            log.info("Applyling loaded blend:" + blend);
            BlendAction ba = anim.actionBlended(blend.getName(), new LinearBlendSpace(0, 1),
                                                blend.getBlendedActions().toArray(new String[0]));
            ba.getBlendSpace().setValue((float)blend.getDefaultBlend());
        }
    }

    public AnimComposer getAnimComposer() {
        return anim;
    }

    public SkinningControl getSkinningControl() {
        return skin;
    }

    public RigInfo getRigInfo() {
        return info;
    }

    public Spatial getView() {
        return model;
    }

    public Spatial getOriginalModel() {
        return originalModel;
    }

    public RigType getRigType() {
        List<com.simsilica.crig.ColliderInfo> colliders = new ArrayList<>();
        for( ColliderInfo info : getRigInfo().getColliders() ) {
            colliders.add(info.convert(getColliders()));
        }
        List<com.simsilica.crig.AttachmentInfo> attachments = new ArrayList<>();
        for( AttachmentInfo info : getRigInfo().getAttachments() ) {
            attachments.add(info.convert());
        }
        List<BlendInfo> blends = new ArrayList<>();
        for( BlendConfig config : getRigInfo().getBlends() ) {
            blends.add(config.createBlendInfo());
        }
        List<RigTypeInitializer> initializers = new ArrayList<>();
        for( RigTypeInitializerInfo info : getRigInfo().getInitializers() ) {
            initializers.add(info.convert());
        }
        return new SpatialRigType(originalModel, colliders, attachments, blends, initializers);
    }

    public BoundingBox getBoundingBox() {
        return (BoundingBox)model.getWorldBound();
    }

    public ColliderShapes getColliders() {
        return colliders;
    }

    public Node getAttachmentNode( String joint ) {
        if( skin.getArmature().getJoint(joint) == null ) {
            return null;
        }
        return skin.getAttachmentsNode(joint);
    }

    public void setSelectedAttachment( AttachmentInfo info ) {
        selectedAttachment.updateObject(info);
    }

    public AttachmentInfo getSelectedAttachment() {
        return selectedAttachment.getObject();
    }

    public VersionedReference<AttachmentInfo> createSelectedAttachmentReference() {
        return selectedAttachment.createReference();
    }

    public void setSelectedCollider( ColliderInfo info ) {
        selectedCollider.updateObject(info);
    }

    public ColliderInfo getSelectedCollider() {
        return selectedCollider.getObject();
    }

    public VersionedReference<ColliderInfo> createSelectedColliderReference() {
        return selectedCollider.createReference();
    }

    public void setSelectedOverlay( OverlayInfo info ) {
        selectedOverlay.updateObject(info);
    }

    public OverlayInfo getSelectedOverlay() {
        return selectedOverlay.getObject();
    }

    public VersionedReference<OverlayInfo> createSelectedOverlayReference() {
        return selectedOverlay.createReference();
    }


    public Set<String> getClipNames() {
        return anim == null ? Collections.emptySet() : anim.getAnimClipsNames();
    }


    public void setCurrentAction( String action ) {
        setCurrentAction(action, 1.0);
    }

    public void setCurrentAction( String action, double speed ) {
log.info("setCurrentAction(" + action + ", " + speed + ")");
        if( action != null ) {
            if( !Objects.equals(currentAction, action) ) {
                // New animation, guaranteed to also need to set the speed.
                this.animAction = anim.setCurrentAction(action);
log.info("animAction:"+ animAction);
                this.currentSpeed = speed;
                animAction.setSpeed(speed);
            } else if( animAction != null ) {
                // Only set the speed if it has changed
                if( speed != currentSpeed ) {
                    this.currentSpeed = speed;
                    animAction.setSpeed(speed);
                }
            }
        }
        this.currentAction = action;
        this.currentSpeed = speed;
    }

    public boolean isBlendable( String action ) {
        return anim.action(action) instanceof BlendAction;
    }

    public void setBlendFactor( String action, double value ) {
        Action a = anim.action(action);
        if( a instanceof BlendAction ) {
            ((BlendAction)a).getBlendSpace().setValue((float)value);
        }
    }

    public void setSpeed( double speed ) {
        if( this.currentSpeed == speed ) {
            return;
        }
log.info("setSpeed(" + speed + ")");
        this.currentSpeed = speed;
        if( animAction != null ) {
            animAction.setSpeed(currentSpeed);
        }
    }

    public double getSpeed() {
        return currentSpeed;
    }

    public String getCurrentAction() {
        return currentAction;
    }

    public Set<String> getJointNames() {
        Set<String> results = new TreeSet<>();
        if( skin == null ) {
            return results;
        }
        collectJointNames(skin.getArmature(), results);
        return results;
    }

    protected static void collectJointNames( Armature armature, Set<String> results ) {
        for( Joint j : armature.getJointList() ) {
            results.add(j.getName());
        }
    }

    public static <T extends Control> T findControl( Spatial s, Class<T> type ) {
        T result = s.getControl(type);
        if( result != null ) {
            return result;
        }
        if( s instanceof Node ) {
            for( Spatial child : ((Node)s).getChildren() ) {
                result = findControl(child, type);
                if( result != null ) {
                    return result;
                }
            }
        }
        return null;
    }

}
