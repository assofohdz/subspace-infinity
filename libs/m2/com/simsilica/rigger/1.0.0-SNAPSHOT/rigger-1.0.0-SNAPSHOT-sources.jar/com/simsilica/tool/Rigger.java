/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import java.io.*;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.io.ByteStreams;

import com.jme3.app.*;
import com.jme3.app.state.ScreenshotAppState;
import com.jme3.light.*;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;
import com.jme3.system.AppSettings;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.QuadBackgroundComponent;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.*;

import com.simsilica.fx.LightingState;
import com.simsilica.fx.sky.SkyState;
import com.simsilica.fx.sky.SkySettingsState;

import com.simsilica.input.MovementState;
import com.simsilica.state.*;
import com.simsilica.thread.JobState;
import com.simsilica.util.LogAdapter;

import com.simsilica.mblock.geom.*;

/**
 *  Tool for rigging character models for physics, etc..
 *
 *  @author    Paul Speed
 */
public class Rigger extends SimpleApplication {

    static Logger log = LoggerFactory.getLogger(Rigger.class);

    // Stuff to auto-extract
    private static final String[] SAMPLES = {
        "/models/mythruna-girl/female-parts-hair1-gray-DiffuseMap.png",
        "/models/mythruna-girl/female-parts-hair1-gray-NormalMap.png",
        "/models/mythruna-girl/femaleSkin-1024.png",
        "/models/mythruna-girl/femaleSkin-mrh-1.png",
        "/models/mythruna-girl/femaleSkin-mrh-1024.png",
        "/models/mythruna-girl/femaleSkin-norms.png",
        "/models/mythruna-girl/Grid-x.png",
        "/models/mythruna-girl/license.txt",
        "/models/mythruna-girl/mythruna-girl.rig.j3o",
        "/Templates/boots.clothing",
        "/Templates/female-underwear1.clothing",
        "/Templates/pants-low.clothing",
        "/Templates/pants-short.clothing",
        "/Templates/pants.clothing",
        "/Templates/shirt-long.clothing",
        "/Templates/shirt-short.clothing",
        "/Templates/underwear1.clothing",
        "/Templates/underwear2.clothing",
        "/Templates/underwear3.clothing",
        "/Templates/vest-short.clothing",
        "/Templates/vest.clothing",
        "/textures/BaseSkin.png",
        "/textures/blue-plaid.png",
        "/textures/burlap-normals.png",
        "/textures/chainmail1024-normals.png",
        "/textures/cloth1-normals.png",
        "/textures/cross-hatch-grid.png",
        "/textures/green-plaid.png",
        "/textures/heavy-weave-normals.png",
        "/textures/leather-gradient.jpg",
        "/textures/leather-normals.png",
        "/textures/medium-steel.jpg",
        "/textures/metal-base.png",
        "/textures/red-plaid.png",
        "/textures/ROCK6-norm.jpg",
        "/textures/rust-base.png",
        "/textures/rust-mr.png",
        "/textures/rust-normals.png",
        "/textures/shapes.png",
        "/textures/weave4-normals.png",
        "/mythruna-girl.rig"
    };

    public static void main( String... args ) throws Exception {

        LogAdapter.initialize();

        RiggerConfig config = RiggerConfig.getInstance();
        for( String resource : SAMPLES ) {
            File target = config.getFile(resource);
            if( target.exists() ) {
                continue;
            }
            log.info("Extracting:" + resource + " to:" + target);
            if( !target.getParentFile().exists() ) {
                target.getParentFile().mkdirs();
            }

            try( InputStream in = Rigger.class.getResourceAsStream("/samples" + resource) ) {
                FileOutputStream out = new FileOutputStream(target);
                ByteStreams.copy(in, out);
            }
        }

        Rigger main = new Rigger();
        AppSettings settings = new AppSettings(true);

        // Set some defaults that will get overwritten if
        // there were previously saved settings from the last time the user
        // ran.
        settings.setWidth(1280);
        settings.setHeight(720);
        settings.setVSync(true);
        settings.setGammaCorrection(false);

        settings.load("MOSS-Rigger Tool");
        settings.load("MOSS-Rigger Tool - " + RiggerConfig.getInstance().getProjectDir());
        settings.setTitle("MOSS-Rigger Tool - " + RiggerConfig.getInstance().getProjectDir());

        settings.setUseJoysticks(true);

        main.setSettings(settings);

        main.start();
    }

    public Rigger() {
        super(new StatsAppState(), new DebugKeysAppState(), new BasicProfilerState(false),
              new JobState(4),
              new DebugHudState(),
              new MemoryDebugState(),
              new DebugNormalsState(),
              new CameraState(45, 0.01f, 1000),
              //new MovementState(), // from SiO2
              new OptionPanelState(), // from Lemur
              new OrbitCameraState(3.5f),
              new LightingState(),
              new SkyState(true),
              new SkySettingsState(),
              new MainMenuState("Rigger"),
              new FileMenuState(),
              new EnvironmentSettingsState(),
              new RiggerPostProcessingState(),
              new GridState(),
              new ToolState(),
              new RigViewState(),
              new ColliderViewState(),
              new ArmatureViewState(),
              new AnimationState(),
              new PhysicsState(),
              new MobilityState(),
              new ClothingState(),
              new ModelInfoState(),
              new PlaygroundMenuState(),
              new CommandConsoleState(),
              //new RiggerScriptState(),
              new ModManagerState(),
              new HelpState(),
              new ScreenshotAppState("", System.currentTimeMillis()));
    }

    public void simpleInitApp() {

        // Get rid of the default close mapping in InputManager
        if( inputManager.hasMapping(INPUT_MAPPING_EXIT) ) {
            inputManager.deleteMapping(INPUT_MAPPING_EXIT);
        }

        setPauseOnLostFocus(false);
        setDisplayFps(false);
        setDisplayStatView(false);

        GuiGlobals.initialize(this);

        GuiGlobals globals = GuiGlobals.getInstance();

        BaseStyles.loadGlassStyle();
        globals.getStyles().setDefaultStyle("glass");

        InputMapper inputMapper = globals.getInputMapper();
        MainMenuState.initializeDefaultMappings(inputMapper);
        OrbitCameraFunctions.initializeDefaultMappings(inputMapper);

        MainAppFunctions.initializeDefaultMappings(inputMapper);

        // Some manual styling for the debug HUD
        Styles styles = globals.getStyles();

        Attributes attrs = styles.getSelector(DebugHudState.CONTAINER_ID, "glass");
        attrs.set("background", null);

        attrs = styles.getSelector(DebugHudState.NAME_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("textHAlignment", HAlignment.Right);
        attrs.set("insets", new Insets3f(0, 0, 0, 0));

        attrs = styles.getSelector(DebugHudState.VALUE_ID, "glass");
        attrs.set("color", ColorRGBA.White);
        attrs.set("background", new QuadBackgroundComponent(new ColorRGBA(0, 0, 0, 0.5f)));
        attrs.set("insets", new Insets3f(0, 0, 0, 0));
        //attrs.set("textHAlignment", HAlignment.Right);


        globals.setCursorEventsEnabled(false);

        SkyState sky = stateManager.getState(SkyState.class);
        sky.getGroundColor().set(0.3f, 0.5f, 0.1f, 1);
        //sky.setShowGroundDisc(false);
        //sky.setFlatShaded(true);

        // Set the time of day
        LightingState lighting = stateManager.getState(LightingState.class);
        //lighting.setSunColor(ColorRGBA.White.clone().mult(1.5f));
        //lighting.setAmbient(ColorRGBA.White.clone());
        lighting.setSunColor(ColorRGBA.White.clone());
        lighting.setAmbient(ColorRGBA.White.clone()); //.mult(0.75f));

        ModManagerState modState = stateManager.getState(ModManagerState.class);
        modState.setModRoot(RiggerConfig.getInstance().getModsDir());
        modState.setGlobalBinding("config", RiggerConfig.getInstance());
        modState.setGlobalBinding("gui", getGuiNode());
        modState.setGlobalBinding("tools", stateManager.getState(ToolState.class));
    }


}


