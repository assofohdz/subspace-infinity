/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;

/**
 *  Shows the active colliders and current selection.
 *
 *  @author    Paul Speed
 */
public class ColliderViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ColliderViewState.class);

    private VersionedReference<Rig> rigRef;
    private Rig rig;

    private VersionedReference<List<ColliderInfo>> collidersRef;
    private VersionedReference<ColliderInfo> selectedRef; // the selection
    private VersionedReference<ColliderInfo> colliderRef; // the object itself

    private Node selectionCursor;

    private Map<ColliderInfo, View> viewIndex = new HashMap<>();
    private SafeArrayList<View> views = new SafeArrayList<>(View.class);
    private View selectedView;

    private boolean collidersEnabled = true;

    public ColliderViewState() {
    }

    public void setCollidersEnabled( boolean enabled ) {
        if( collidersEnabled == enabled ) {
            return;
        }
        this.collidersEnabled = enabled;
        resetCollidersEnabled();
    }
    
    protected void resetCollidersEnabled() {       
        for( View view : views.getArray() ) {
            view.setEnabled(collidersEnabled);
        }
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected void setRig( Rig rig ) {
        if( this.rig == rig ) {
            return;
        }
        this.rig = rig;

        // Clear the old views no matter what
        viewIndex.clear();
        for( View view : views ) {
            view.release();
        }
        views.clear();

        if( rig != null ) {
            collidersRef = rig.getRigInfo().getColliders().createReference();
            selectedRef = rig.createSelectedColliderReference();

            updateViews(collidersRef.get());
            updateSelection(selectedRef.get());
            updateCursor();
            resetCollidersEnabled();
        } else {
            collidersRef = null;
            selectedRef = null;
            updateSelection(null);
            updateCursor();
        }
    }

    @Override
    protected void initialize( Application app ) {
        selectionCursor = new Node("selectedCollider");
        ColorRGBA[] colors = new ColorRGBA[] { ColorRGBA.Red, ColorRGBA.Green, ColorRGBA.Blue };
        float size = 0.25f;
        Geometry opaque = GeomUtils.createAxis(size, colors[0], colors[1], colors[2]);
        selectionCursor.attachChild(opaque);

        for( int i = 0; i < colors.length; i++ ) {
            colors[i] = colors[i].clone();
            colors[i].a = 0.3f;
        }
        Geometry alpha = GeomUtils.createAxis(size, colors[0], colors[1], colors[2]);
        alpha.setQueueBucket(Bucket.Translucent);
        alpha.getMaterial().getAdditionalRenderState().setDepthTest(false);
        alpha.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        selectionCursor.attachChild(alpha);


    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        rigRef = getState(RigViewState.class, true).createRigReference();
        setRig(rigRef.get());
    }

    @Override
    protected void onDisable() {
        rigRef = null;
        setRig(null);
    }

    @Override
    public void update( float tpf ) {
        if( rigRef.update() ) {
            setRig(rigRef.get());
        }
        if( rig == null ) {
            return;
        }
        if( collidersRef.update() ) {
            updateViews(collidersRef.get());
        }
        if( selectedRef.update() ) {
            updateSelection(selectedRef.get());
        }
        if( colliderRef != null && colliderRef.update() ) {
            updateCursor();
        }
        for( View view : views.getArray() ) {
            view.update();
        }
    }

    protected void updateSelection( ColliderInfo collider ) {
        log.info("updateSelection(" + collider + ")");
        if( collider == null ) {
            colliderRef = null;
            return;
        }
        colliderRef = collider.createReference();
        updateCursor();
    }

    protected void updateCursor() {
        if( selectedView != null ) {
            selectedView.setColor(ColorRGBA.Gray);
        }
        if( colliderRef == null ) {
            selectionCursor.removeFromParent();
            return;
        }
        ColliderInfo collider = colliderRef.get();
        Node node = rig.getAttachmentNode(collider.getJoint());
        if( node == null ) {
            selectionCursor.removeFromParent();
            return;
        }
        node.attachChild(selectionCursor);
        selectionCursor.setLocalTranslation(collider.getOffset().toVector3f());
        selectionCursor.setLocalRotation(collider.getOrientation().toQuaternion());

        selectedView = viewIndex.get(collider);
        if( selectedView != null ) {
            selectedView.setColor(ColorRGBA.Yellow);
        }
    }

    protected void updateViews( List<ColliderInfo> list ) {
        // Figure out which views go away and which are new
        Set<ColliderInfo> toRemove = new HashSet<>(viewIndex.keySet());

        for( ColliderInfo info : list ) {
            // We have it, don't remove it
            toRemove.remove(info);

            View view = viewIndex.get(info);
            if( view == null ) {
                // A new view
                view = new View(info);
                viewIndex.put(info, view);
                views.add(view);
            }
        }

        for( ColliderInfo remove : toRemove ) {
            View view = viewIndex.remove(remove);
            if( view != null ) {
                view.release();
                views.remove(view);
            }
        }
    }

    protected Geometry createDebugView( Part part ) {
        //log.info("createDebugView(" + part + ")");
        return PartUtils.createWire((CellArrayPart)part);
    }

    private class View {
        ColliderInfo info;
        VersionedReference<ColliderInfo> infoRef;
        Node holder;
        Vector3f rescale = new Vector3f(1, 1, 1);
        String joint;
        String shape;
        double scale;
        Part part;
        boolean enabled = true;
        Geometry geom1;        
        Geometry geom2;
        ColorRGBA color = ColorRGBA.Gray;

        public View( ColliderInfo info ) {
            this.info = info;
            this.infoRef = info.createReference();
            // Simplifies a bunch of logic if we can swap out the
            // shape geom separately from attaching to the joint.
            this.holder = new Node("colliderHolder");
            updateShape();
            updateJoint();
        }

        public void setEnabled( boolean enabled ) {
            if( this.enabled == enabled ) {
                return;
            }
            this.enabled = enabled;
            if( enabled ) {
                //holder.setCullHint(Spatial.CullHint.Inherit);
                holder.attachChild(geom1);
                holder.attachChild(geom2);
            } else {
                //holder.setCullHint(Spatial.CullHint.Always);
                geom1.removeFromParent();
                geom2.removeFromParent();
            }
        }
        
        public boolean isEnabled() {
            return enabled;
        }

        public void setColor( ColorRGBA color ) {
            if( Objects.equals(this.color, color) ) {
                return;
            }
            this.color = color;
            geom2.getMaterial().setColor("Color", color);
            ColorRGBA trans = color.clone();
            trans.a = 0.25f;
            geom1.getMaterial().setColor("Color", trans);
        }

        protected void updateShape() {
            if( Objects.equals(shape, info.getShape()) && info.getScale() == scale ) {
                return;
            }
            this.shape = info.getShape();
            this.scale = info.getScale();
            this.part = rig.getColliders().createShape(shape, scale, 0.1);

            if( geom1 != null ) {
                // remove the old one
                geom1.removeFromParent();
                geom2.removeFromParent();
            }
            this.geom1 = createDebugView(part);
            this.geom2 = geom1.clone(true);
            geom2.getMaterial().setColor("Color", color);
            if( enabled ) {
                holder.attachChild(geom1);
                holder.attachChild(geom2);
            }
            geom1.setQueueBucket(Bucket.Translucent);
            geom1.getMaterial().getAdditionalRenderState().setDepthTest(false);
            geom1.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
            ColorRGBA trans = color.clone();
            trans.a = 0.25f;
            geom1.getMaterial().setColor("Color", trans);
        }

        protected void updateJoint() {
            if( !Objects.equals(joint, info.getJoint()) ) {
                this.joint = info.getJoint();
                Node node = rig.getAttachmentNode(joint);
                node.attachChild(holder);

                rescale = node.getWorldScale().clone();
                rescale.x = 1/rescale.x;
                rescale.y = 1/rescale.y;
                rescale.z = 1/rescale.z;
                holder.setLocalScale(rescale);
            }

//log.info("rescale:" + rescale);
            holder.setLocalTranslation(info.getOffset().toVector3f().multLocal(rescale));
            holder.setLocalRotation(info.getOrientation().toQuaternion());
        }

        public void update() {
            if( infoRef.update() ) {
                updateShape();
                updateJoint();
            }
            // We'll crib off of attachment nodes for now
            // so no other updates are needed.
        }

        public void release() {
            holder.removeFromParent();
        }
    }
}
