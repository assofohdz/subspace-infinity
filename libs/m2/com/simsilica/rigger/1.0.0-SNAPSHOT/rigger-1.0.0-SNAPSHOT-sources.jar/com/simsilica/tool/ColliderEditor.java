/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ColliderEditor extends Container {
    static Logger log = LoggerFactory.getLogger(ColliderEditor.class);
 
    private ColliderInfo collider;
    private VersionedList<String> jointNames = new VersionedList<>();
    private VersionedList<String> shapeNames = new VersionedList<>();
    private Selector<String> jointField;
    private Selector<String> shapeField;
    private Spinner<Double> scaleField;
    private Vec3dEditor offsetEditor;
    private EulerRotationEditor orientEditor;
    
    private VersionedReference<String> jointRef;
    private VersionedReference<String> shapeRef;
    private VersionedReference<Double> scaleRef;
    private VersionedReference<Vec3d> offsetRef;
    private VersionedReference<Quatd> orientRef;
        
    public ColliderEditor() {
        this.jointNames = new VersionedList<>();
        this.shapeNames = new VersionedList<>(); 
    
        Container props = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Even, FillMode.Last)));
        
        props.addChild(new Label("Joint:"));
        jointField = props.addChild(new Selector<String>(jointNames), 1);
        jointRef = jointField.createSelectedItemReference();

        props.addChild(new Label("Shape:"));
        shapeField = props.addChild(new Selector<String>(shapeNames), 1);
        shapeRef = shapeField.createSelectedItemReference();
 
        props.addChild(new Label("Scale:"));
        SequenceModel<Double> scaleModel 
            = SequenceModels.rangedSequence(
                new DefaultRangedValueModel(0.05, 0.5, 0.1), 0.01, 0.01);
        scaleRef = scaleModel.createReference();                
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.2f", "error");
        scaleField = props.addChild(new Spinner<>(scaleModel, renderer), 1);
        scaleField.setValueEditor(ValueEditors.doubleEditor("%.2f"));            
        
        props.addChild(new Label("Offset:"));
        offsetEditor = props.addChild(new Vec3dEditor(Axis.X, -1, 1, 0.01, 0.01), 1);
        offsetRef = offsetEditor.createReference();

        props.addChild(new Label("Orient:"));
        orientEditor = props.addChild(new EulerRotationEditor(Axis.X), 1);
        orientRef = orientEditor.createReference();
    }
    
    public void setJointNames( Collection<String> jointNames ) {
        this.jointNames.clear();
        this.jointNames.addAll(jointNames);
    }
    
    public void setShapeNames( Collection<String> shapeNames ) {
        this.shapeNames.clear();
        this.shapeNames.addAll(shapeNames);
    }    
    
    public void setCollider( ColliderInfo collider ) {
        this.collider = collider;
        resetFields();
    }
    
    public ColliderInfo getCollider() {
        return collider;
    }
 
    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( jointRef.update() ) {
            collider.setJoint(jointRef.get());
        }
        if( shapeRef.update() ) {
            collider.setShape(shapeRef.get());
        }
        if( scaleRef.update() ) {
            collider.setScale(scaleField.getValue());
        }
        if( offsetRef.update() ) {
            collider.setOffset(offsetRef.get());
        }
        if( orientRef.update() ) {
            collider.setOrientation(orientRef.get());
        }
    }
    
    protected void resetFields() {
        if( collider == null ) {
            jointField.setSelectedItem(null);
            shapeField.setSelectedItem(null);
            offsetEditor.setObject(new Vec3d());
            orientEditor.setObject(new Quatd());
        } else {
            jointField.setSelectedItem(collider.getJoint());
            shapeField.setSelectedItem(collider.getShape());
            scaleField.getModel().setObject(collider.getScale());
            offsetEditor.setObject(collider.getOffset());
            orientEditor.setObject(collider.getOrientation());
        }
    }
}
