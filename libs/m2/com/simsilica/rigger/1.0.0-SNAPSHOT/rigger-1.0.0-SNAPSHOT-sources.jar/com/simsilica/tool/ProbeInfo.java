/*
 * $Id$
 *
 * Copyright (c) 2026, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;


/**
 *  Information about a physics probe defined for the rig.  This
 *  is a rough approximation of the rig that can be used for physics queries
 *  for path finding and/or environment navigation.
 *
 *  @author    Paul Speed
 */
public class ProbeInfo implements VersionedObject<ProbeInfo> {
    static Logger log = LoggerFactory.getLogger(ProbeInfo.class);

    private transient long version;

    private int size = 1;
    private int layers = 4;
    private int stepDownLayers = 1;
    private int groundLayers = 1;
    private int stepUpLayers = 1;
    private int jumpLayers = 1;

    private double yOffset = 0.0;
    private double rigHeight = 1.5;

    public ProbeInfo() {
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public ProbeInfo getObject() {
        return this;
    }

    @Override
    public VersionedReference<ProbeInfo> createReference() {
        return new VersionedReference<>(this);
    }

    public void setSize( int size ) {
        if( this.size == size ) {
            return;
        }
        this.size = size;
        version++;
    }

    public int getSize() {
        return size;
    }

    public void setLayers( int layers ) {
        if( this.layers == layers ) {
            return;
        }
        this.layers = layers;
        version++;
    }

    public int getLayers() {
        return layers;
    }

    public void setStepDownLayers( int stepDownLayers ) {
log.info("setStepDownLayers(" + stepDownLayers + ")");
        if( this.stepDownLayers == stepDownLayers ) {
            return;
        }
        this.stepDownLayers = stepDownLayers;
        version++;
    }

    public int getStepDownLayers() {
        return stepDownLayers;
    }

    public void setGroundLayers( int groundLayers ) {
        if( this.groundLayers == groundLayers ) {
            return;
        }
        this.groundLayers = groundLayers;
        version++;
    }

    public int getGroundLayers() {
        return groundLayers;
    }

    public void setStepUpLayers( int stepUpLayers ) {
        if( this.stepUpLayers == stepUpLayers ) {
            return;
        }
        this.stepUpLayers = stepUpLayers;
        version++;
    }

    public int getStepUpLayers() {
        return stepUpLayers;
    }

    public void setJumpLayers( int jumpLayers ) {
        if( this.jumpLayers == jumpLayers ) {
            return;
        }
        this.jumpLayers = jumpLayers;
        version++;
    }

    public int getJumpLayers() {
        return jumpLayers;
    }

    public void setRigHeight( double rigHeight ) {
        if( this.rigHeight == rigHeight ) {
            return;
        }
        this.rigHeight = rigHeight;
        version++;
    }

    public double getRigHeight() {
        return rigHeight;
    }

    public void setYOffset( double yOffset ) {
        if( this.yOffset == yOffset ) {
            return;
        }
        this.yOffset = yOffset;
        version++;
    }

    public double getYOffset() {
        return yOffset;
    }

    public String toString() {
        return getClass().getSimpleName() + "[size:" + size + ", layers:" + layers + ", rigHeight:" + rigHeight + ", yOffset:" + yOffset + "]";
    }
}


