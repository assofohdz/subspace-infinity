/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.config.*;
import com.simsilica.mblock.phys.*;

/**
 *  A registry of available collider shapes.
 *
 *  @author    Paul Speed
 */
public class ColliderShapes {
    static Logger log = LoggerFactory.getLogger(ColliderShapes.class);

    private Map<String, CellArray> blocks = new LinkedHashMap<>();

    public ColliderShapes() {
        // Prebuild some shapes

        // Make sure our block type index has at least the one solid type
        if( !BlockTypeIndex.isInitialized() ) {
            DefaultBlockSet.initializeBlockTypes();
        }

        blocks.put("sphere", null);
        blocks.put("cube", cells(1, 1, 1, 1));
        blocks.put("block-1x2x1", cells(1, 2, 1, 1));
        blocks.put("block-1x3x1", cells(1, 3, 1, 1));
        blocks.put("block-1x4x1", cells(1, 4, 1, 1));
        blocks.put("block-1x5x1", cells(1, 5, 1, 1));
        blocks.put("block-2x2x1", cells(2, 2, 1, 1));
        blocks.put("block-2x3x1", cells(2, 3, 1, 1));
        blocks.put("block-2x4x1", cells(2, 4, 1, 1));
    }

    public Set<String> getShapeNames() {
        return blocks.keySet();
    }

    public CellArray getCells( String name ) {
        return blocks.get(name);
    }

    public CellArrayPart createShape( String name, double scale, double mass ) {
        CellArray array = blocks.get(name);
        if( array == null ) {
            return CellArrayPart.createSphere(name, scale, mass);
        }
        return CellArrayPart.createShape(name, array, scale, mass);
    }

    private static CellArray cells( int x, int y, int z, int value ) {
        CellArray array = new CellArray(x, y, z);
        array.clear(value);
        MaskUtils.calculateSideMasks(array);
        return array;
    }
}
