/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.material.Material;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.props.*;
import com.simsilica.lemur.value.*;

import com.simsilica.ext.mblock.BlockShapeFactory;
import com.simsilica.ext.mblock.CellArrayFunctions;
import com.simsilica.ext.mblock.SphereFactory;
import com.simsilica.ext.mphys.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.config.MaterialRegistry;
import com.simsilica.mblock.geom.GeometryFactory;
import com.simsilica.mblock.io.*;
import com.simsilica.mblock.phys.MBlockShape;

import com.simsilica.tool.pg.*;

/**
 *  The adapter between the PhysicsPlaygroundState and the rest of the
 *  rigger application.
 *
 *  @author    Paul Speed
 */
public class PlaygroundMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PlaygroundMenuState.class);

    private Container window;
    private VersionedReference<TabbedPanel.Tab> tabRef;

    private PhysicsPlaygroundState playground;

    private Map<String, Material> materials;
    private GeometryFactory geomFactory;
    private PgSpatialFactory modelFactory;

    private VersionedList<TypeEntry> cubeTypes;
    private Spinner<Integer> worldDepth;
    private Selector<TypeEntry> topType;
    private Selector<TypeEntry> groundType;
    private Selector<File> initialStructure;
    private Spinner<Integer> structureOffset;

    private VersionedList<File> structures;
    private VersionedList<String> rigs;

    private Action simulationAction;
    private Action pauseAction;
    private Action singleStepAction;

    private PropertyPanel debugSettings;
    private boolean debugPhysics = false;
    private boolean debugContacts = false;

    private Container playgroundEditor;

    private Map<String, Runnable> initializers = new LinkedHashMap<>();
    private ShapeFactoryRegistry<MBlockShape> shapeFactory;
    private CompositeShapeFactory<MBlockShape> chain;
    private Function<String, CellArray> loadersCache;

    public PlaygroundMenuState() {
    }

    public ShapeFactoryRegistry<MBlockShape> getShapeFactory() {
        return shapeFactory;
    }

    public CompositeShapeFactory<MBlockShape> getShapeFactoryChain() {
        return chain;
    }

    public Function<String, CellArray> getLoadersCache() {
        return loadersCache;
    }

    public boolean isPhysicsDebugEnabled() {
        return debugPhysics;
    }

    public void setPhysicsDebugEnabled( boolean debugPhysics ) {
        if( this.debugPhysics == debugPhysics ) {
            return;
        }
        this.debugPhysics = debugPhysics;
        if( playground != null ) {
            playground.setPhysicsDebugEnabled(debugPhysics);
        }
    }

    public boolean isContactDebugEnabled() {
        return debugContacts;
    }

    public void setContactDebugEnabled( boolean debugContacts ) {
        if( this.debugContacts == debugContacts ) {
            return;
        }
        this.debugContacts = debugContacts;
        if( playground != null ) {
            playground.setContactDebugEnabled(debugContacts);
        }
    }

    public void setTopType( BlockName name ) {
        int index = BlockTypeIndex.findType(name);
        for( TypeEntry entry : cubeTypes ) {
            if( entry.index == index ) {
                topType.setSelectedItem(entry);
                return;
            }
        }
    }

    public void setGroundType( BlockName name ) {
        int index = BlockTypeIndex.findType(name);
        for( TypeEntry entry : cubeTypes ) {
            if( entry.index == index ) {
                groundType.setSelectedItem(entry);
                return;
            }
        }
    }

    public void setInitializer( String id, Runnable callback ) {
        initializers.put(id, callback);
        if( playground != null ) {
            playground.setInitializer(id, callback);
        }
    }

    protected void initializeBlockTypeIndex( AssetManager assets ) {
        try {
            File bFile = RiggerConfig.getInstance().getBlocksFile();
            File fFile = RiggerConfig.getInstance().getFluidsFile();
            File mFile = RiggerConfig.getInstance().getMaterialsFile();

            try( InputStream in = new FileInputStream(bFile) ) {
                BlockTypeIndex.load(in);
            }
            try( InputStream in = new FileInputStream(fFile) ) {
                FluidTypeIndex.load(in);
            }

            try( InputStream in = new FileInputStream(mFile) ) {
                this.materials = MaterialRegistry.loadCompiledMaterials(assets, in);
            }
            this.geomFactory = new GeometryFactory(materials);
        } catch( IOException e ) {
            throw new RuntimeException("Error initializing block type index", e);
        }
    }

    protected void loadCubeTypes() {
        BlockType[] array = BlockTypeIndex.getTypes();
        cubeTypes = new VersionedList<>();
        for( int i = 0; i < array.length; i++ ) {
            BlockType type = array[i];
            if( type == null ) {
                continue;
            }
            if( "cube".equals(type.getName().getShape()) ) {
                cubeTypes.add(new TypeEntry(i, type));
            }
        }
    }

    protected void loadStructures() {
        structures = new VersionedList<>();
        File dir = RiggerConfig.getInstance().getFile("blocks-files");
        log.info("Scanning for structures in:" + dir);
        if( !dir.exists() ) {
            return;
        }
        for( File f : dir.listFiles() ) {
            if( f.isDirectory() ) {
                continue;
            }
            if( !f.getName().endsWith(".blocks") ) {
                continue;
            }
            structures.add(f);
        }
    }

    protected void loadRigs() {
        rigs = new VersionedList<>();

        FileMenuState files = getState(FileMenuState.class, true);
        List<String> rigFiles = files.getRigFiles();
        for( String s : rigFiles ) {
            try {
                // Load the file so that we can get its full target
                RigInfo rigInfo = files.loadRigInfo(s);
                TargetModelInfo target = rigInfo.getTargetModel();
                String rigPath = target.getTargetRoot() + "/" + target.getModel();
                rigs.add(rigPath);
            } catch( Exception e ) {
                log.warn("Error loading rig for:" + s, e);
            }
        }

        log.info("Found rigs:" + rigs);
    }

    @Override
    protected void initialize( Application app ) {

        File modelDir = RiggerConfig.getInstance().getModelBinaryDir();
        app.getAssetManager().registerLocator(modelDir.getPath(), com.jme3.asset.plugins.FileLocator.class);

        // We need to make sure that the block types have been initialized
        initializeBlockTypeIndex(app.getAssetManager());
        loadCubeTypes();
        loadStructures();
        loadRigs();

        this.shapeFactory = createShapeFactory();

        // May not be able to avoid creating this as part of app startup but
        // I'd like to make this app state the cleanest adapter possible.
        // From a scripting perspective, it would be better if the app state
        // already existed, though.
        // Actually, we want to be able to attach and detach it to start/stop
        // the simulation.  So we have to manage it hear anyway.
        //this.playground = new PhysicsPlaygroundState();
        // And we'll wait to create it until then, too.

        this.window = new Container();
        getState(ToolState.class).getTabs().addTab("Playground", window);
        this.tabRef = getState(ToolState.class).getTabs().getSelectionModel().createReference();

        window.addChild(new Label("World Settings"));
        Container container = window.addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.Last)));

        container.addChild(new Label("Ground depth:"));
        worldDepth = container.addChild(
                                    new Spinner<Integer>(
                                        SequenceModels.listSequence(
                                            Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
                                        )
                                    ),
                                    1);
        worldDepth.setValue(4);

        container.addChild(new Label("Ground top:"));
        topType = container.addChild(new Selector<TypeEntry>(cubeTypes), 1);
        container.addChild(new Label("Ground:"));
        groundType = container.addChild(new Selector<TypeEntry>(cubeTypes), 1);

        container.addChild(new Label("Init structure:"));
        initialStructure = container.addChild(new Selector<File>(structures), 1);
        initialStructure.setValueRenderer(new DefaultValueRenderer<File>((f) -> f.getName()));

        container.addChild(new Label("Struct offset:"));
        structureOffset = container.addChild(
                                    new Spinner<Integer>(
                                        SequenceModels.listSequence(
                                            Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1)
                                        )
                                    ),
                                    1);

        window.addChild(new Label("Simulation"));

        this.simulationAction = new CallMethodAction("Start Simulation", this, "toggleSimulation");
        this.pauseAction = new CallMethodAction("Pause Simulation", this, "togglePause");
        pauseAction.setEnabled(false);
        this.singleStepAction = new CallMethodAction("", this, "singleStep");
        singleStepAction.setEnabled(false);

        Container simButtons = window.addChild(new Container(new SpringGridLayout(Axis.X,Axis.Y)));
        simButtons.addChild(new ActionButton(simulationAction));
        simButtons.addChild(new ActionButton(pauseAction));
        simButtons.addChild(new ActionButton(singleStepAction));

        debugSettings = window.addChild(new PropertyPanel(null));
        debugSettings.addBooleanProperty("Body Debug", this, "physicsDebugEnabled");
        debugSettings.addBooleanProperty("Contact Debug", this, "contactDebugEnabled");


        playgroundEditor = window.addChild(new Container());
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void update( float tpf ) {
        if( tabRef.update() && playground != null ) {
            playground.setEnabled(isOurTabVisible());
            getState(RigViewState.class).setEnabled(!isOurTabVisible());
        }
    }

    protected boolean isOurTabVisible() {
        return tabRef.get() != null && tabRef.get().getContents() == window;
    }

    protected void resetSimButtons() {
        if( playground != null ) {
            simulationAction.setName("Stop Simulation");
            if( playground.isPaused() ) {
                pauseAction.setName("Resume Simulation");
                singleStepAction.setName("Step");
            } else {
                pauseAction.setName("Pause Simulation");
                singleStepAction.setName("");
            }
            pauseAction.setEnabled(true);
            singleStepAction.setEnabled(true);
        } else {
            simulationAction.setName("Start Simulation");
            pauseAction.setName("Pause Simulation");
            pauseAction.setEnabled(false);
            singleStepAction.setName("");
            singleStepAction.setEnabled(false);
        }
    }

    protected WorldSettings getWorldSettings() {
        WorldSettings result = new WorldSettings();
        result.groundDepth = worldDepth.getValue();
        result.topType = topType.getSelectedItem().index;
        result.groundType = groundType.getSelectedItem().index;
        result.initialStructure = loadStructure(initialStructure.getSelectedItem());
        result.structureOffset = structureOffset.getValue();
        if( result.groundDepth + result.structureOffset < 1 ) {
            result.structureOffset = 1 + -result.groundDepth;
        }

        return result;
    }

    protected BlockObject loadStructure( File f ) {
        if( f == null ) {
            return null;
        }
        try {
            return BlocksFileFormat.readBlocks(f, true);
        } catch( IOException e ) {
            throw new RuntimeException("Error reading blocks file:" + f, e);
        }
    }

    @SuppressWarnings("unchecked")
    protected ShapeFactoryRegistry<MBlockShape> createShapeFactory() {
        ShapeFactoryRegistry<MBlockShape> shapeFactory = new ShapeFactoryRegistry<>();
        shapeFactory.registerFactory("sphere", new SphereFactory());
        //shapeFactory.registerFactory("characterBlocks", (name, scale, mass) -> {
        //        double m = mass == null ? 0.0 : mass.getMass();
        //        CellArray cells = new CellArray(1, 3, 1);
        //        cells.setCell(0, 0, 0, 1);
        //        cells.setCell(0, 1, 0, 2);
        //        cells.setCell(0, 2, 0, 3);
        //        MaskUtils.calculateSideMasks(cells);
        //        return MBlockShape.createShape(name, cells, scale, m);
        //    });

        // Build a chop-chain for the various types of shapes we expect to have
        this.chain = new CompositeShapeFactory<>();
        shapeFactory.setDefaultFactory(chain);

        // Need something to load the rigs here
        chain.addDelegate(new RigFactory(RiggerConfig.getInstance().getRigBinaryDir()));

        // Different ways to load block shapes
        BlockShapeFactory blockFactory = new BlockShapeFactory();
        chain.addDelegate(blockFactory);

        File blocksRoot = RiggerConfig.getInstance().getFile("blocks-models");
        if( !blocksRoot.exists() ) {
            log.info("Creating:" + blocksRoot);
            blocksRoot.mkdirs();
        }
        Function<String, CellArray> loaders = CellArrayFunctions.chain(
                CellArrayFunctions.blocksFile(blocksRoot),
                CellArrayFunctions.blocksResource()
            );
        this.loadersCache = CellArrayFunctions.singletonCache(loaders);
        blockFactory.addDelegate(loadersCache);

        return shapeFactory;
    }

    protected void toggleSimulation() {
        if( playground == null ) {
            this.modelFactory = new PgSpatialFactory(getApplication().getAssetManager(), geomFactory);

            this.playground = new PhysicsPlaygroundState(
                playgroundEditor,
                rigs,
                geomFactory,
                modelFactory,
                shapeFactory,
                getWorldSettings());

            log.info("game systems:" + playground.getGameSystems());
            //getState(RiggerScriptState.class).setBinding("systems", playground.getGameSystems().getGameSystems());
            getState(ModManagerState.class).getModManager().setGlobalBinding("systems", playground.getGameSystems().getGameSystems());
            getApplication().getStateManager().attach(playground);
            getApplication().enqueue( () -> {
                playground.setPhysicsDebugEnabled(debugPhysics);
                playground.setContactDebugEnabled(debugContacts);
                for( Map.Entry<String, Runnable> init : initializers.entrySet() ) {
                    playground.setInitializer(init.getKey(), init.getValue());
                }
            });
        } else {
            getApplication().getStateManager().detach(playground);
            //getState(RiggerScriptState.class).setBinding("systems", null);
            getState(ModManagerState.class).getModManager().setGlobalBinding("systems", null);
            playground = null;
        }
        resetSimButtons();
    }

    protected void togglePause() {
        if( playground == null ) {
            return;
        }
        playground.setPaused(!playground.isPaused());
        resetSimButtons();
        //if( playground.isPaused() ) {
        //    pauseAction.setName("Resume Simulation");
        //} else {
        //    pauseAction.setName("Pause Simulation");
        //}
    }

    protected void singleStep() {
        if( playground == null ) {
            return;
        }
        playground.singleStep();
    }

    private class TypeEntry {
        int index;
        BlockType type;

        public TypeEntry( int index, BlockType type ) {
            this.index = index;
            this.type = type;
        }

        @Override
        public String toString() {
            return String.valueOf(type.getName());
        }
    }
}


