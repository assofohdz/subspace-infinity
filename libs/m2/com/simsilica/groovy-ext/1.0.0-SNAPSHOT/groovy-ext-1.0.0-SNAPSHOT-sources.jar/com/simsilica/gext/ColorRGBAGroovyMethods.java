/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.gext;

import java.util.List;

import org.slf4j.*;

import org.codehaus.groovy.runtime.typehandling.GroovyCastException;

import com.jme3.math.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class ColorRGBAGroovyMethods {
    static Logger log = LoggerFactory.getLogger(ColorRGBAGroovyMethods.class);
    
    public static ColorRGBA plus( ColorRGBA v1, ColorRGBA v2 ) {
        return v1.add(v2);
    } 

    public static ColorRGBA plus( ColorRGBA v1, List<Number> v2 ) {
        if( v2.isEmpty() ) {
            return v1;
        }
        ColorRGBA result = new ColorRGBA(v1);
        result.r += v2.get(0).floatValue();
        result.g += v2.size() > 1 ? v2.get(1).floatValue() : 0;
        result.b += v2.size() > 2 ? v2.get(2).floatValue() : 0;
        result.a += v2.size() > 3 ? v2.get(3).floatValue() : 0;
        return result;
    } 
 
    public static ColorRGBA minus( ColorRGBA v1, ColorRGBA v2 ) {
        ColorRGBA result = new ColorRGBA(v1);
        result.r -= v2.r;
        result.g -= v2.g;
        result.b -= v2.b;
        result.a -= v2.a;
        return result;
    } 

    public static ColorRGBA minus( ColorRGBA v1, List<Number> v2 ) {
        if( v2.isEmpty() ) {
            return v1;
        }
        ColorRGBA result = new ColorRGBA(v1);
        result.r -= v2.get(0).floatValue();
        result.g -= v2.size() > 1 ? v2.get(1).floatValue() : 0;
        result.b -= v2.size() > 2 ? v2.get(2).floatValue() : 0;
        result.a -= v2.size() > 3 ? v2.get(3).floatValue() : 0;
        return result;
    }
     
    public static ColorRGBA multiply( Number n, ColorRGBA v ) {
        return v.mult(n.floatValue());
    }
       
    public static ColorRGBA multiply( ColorRGBA v, Number n ) {
        return v.mult(n.floatValue());
    }

    public static ColorRGBA multiply( ColorRGBA v1, ColorRGBA v2 ) {
        return v1.mult(v2);
    }

    public static ColorRGBA multiply( ColorRGBA v1, List<Number> v2 ) {
        if( v2.isEmpty() ) {
            return v1;
        }
        ColorRGBA result = new ColorRGBA(v1);
        result.r *= v2.get(0).floatValue();
        result.g *= v2.size() > 1 ? v2.get(1).floatValue() : 1;
        result.b *= v2.size() > 2 ? v2.get(2).floatValue() : 1;
        result.a *= v2.size() > 3 ? v2.get(3).floatValue() : 1;
        return result;
    }

    public static ColorRGBA div( ColorRGBA v, Number n ) {
        return v.mult(1/n.floatValue());
    }

    public static ColorRGBA div( ColorRGBA v1, ColorRGBA v2 ) {
        ColorRGBA result = new ColorRGBA(v1);
        result.r /= v2.r;
        result.g /= v2.g;
        result.b /= v2.b;
        result.a /= v2.a;
        return result;
    }

    public static ColorRGBA div( ColorRGBA v1, List<Number> v2 ) {
        if( v2.isEmpty() ) {
            return v1;
        }        
        ColorRGBA result = new ColorRGBA(v1);
        result.r /= v2.get(0).floatValue();
        result.g /= v2.size() > 1 ? v2.get(1).floatValue() : 1;
        result.b /= v2.size() > 2 ? v2.get(2).floatValue() : 1;
        result.a /= v2.size() > 3 ? v2.get(3).floatValue() : 1;
        return result;
    }
    
    public static Object asType( ColorRGBA v, Class type ) {
        if( type == ColorRGBA.class ) {
            return v;
        }
        throw new GroovyCastException("Cannot convert:" + v + " to:" + type);
    }
    
}
