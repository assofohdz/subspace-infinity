/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.gext;

import java.util.List;

import org.slf4j.*;

import org.codehaus.groovy.runtime.typehandling.GroovyCastException;

import com.simsilica.mathd.*;

/**
 *  Groovy extension methods for Vec3d.
 *
 *  @author    Paul Speed
 */
public class Vec3iGroovyMethods {
    static Logger log = LoggerFactory.getLogger(Vec3iGroovyMethods.class);
    
    public static Vec3i plus( Vec3i v1, Vec3i v2 ) {
        return v1.add(v2);
    } 

    public static Vec3i minus( Vec3i v1, Vec3i v2 ) {
        return v1.subtract(v2);
    } 

    public static Vec3i multiply( Integer n, Vec3i v ) {        
        return v.mult(n);
    }

    public static Vec3d multiply( Number n, Vec3i v ) {        
        return v.toVec3d().multLocal(n.doubleValue());
    }
       
    public static Vec3i multiply( Vec3i v, Integer n ) {
        return v.mult(n);
    }

    public static Vec3d multiply( Vec3i v, Number n ) {
        return v.toVec3d().multLocal(n.doubleValue());
    }

    public static Vec3i multiply( Vec3i v1, Vec3i v2 ) {
        return new Vec3i(v1.x * v2.x, v1.y * v2.y, v1.z * v2.z);
    }

    public static Vec3d div( Vec3i v, Number n ) {
        return v.toVec3d().divideLocal(n.doubleValue());
    }

    public static Object asType( Vec3i v, Class type ) {
        if( type == Vec3i.class ) {
            return v;
        }
        if( type == Vec3d.class ) {
            return v.toVec3d();
        }
        throw new GroovyCastException("Cannot convert:" + v + " to:" + type);
    }   
}
