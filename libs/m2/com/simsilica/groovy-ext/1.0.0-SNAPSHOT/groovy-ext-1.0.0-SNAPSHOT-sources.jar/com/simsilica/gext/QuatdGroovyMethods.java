/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.gext;

import java.util.List;

import org.slf4j.*;

import org.codehaus.groovy.runtime.typehandling.GroovyCastException;

import com.simsilica.mathd.*;

/**
 *  Groovy extension methods for Quatd.
 *
 *  @author    Paul Speed
 */
public class QuatdGroovyMethods {
    static Logger log = LoggerFactory.getLogger(QuatdGroovyMethods.class);

    public static Quatd plus( Quatd q1, Quatd q2 ) {
        return q1.add(q2);
    }

    public static Quatd plus( Quatd q1, List<Number> q2 ) {
        if( q2.isEmpty() ) {
            return q1;
        }
        double x = q2.get(0).doubleValue();
        double y = q2.size() > 1 ? q2.get(1).doubleValue() : 0;
        double z = q2.size() > 2 ? q2.get(2).doubleValue() : 0;
        double w = q2.size() > 3 ? q2.get(3).doubleValue() : 0;
        return q1.add(new Quatd(x, y, z, w));
    }

    public static Quatd minus( Quatd q1, Quatd q2 ) {
        return q1.subtract(q2);
    }

    public static Quatd minus( Quatd q1, List<Number> q2 ) {
        if( q2.isEmpty() ) {
            return q1;
        }
        double x = q2.get(0).doubleValue();
        double y = q2.size() > 1 ? q2.get(1).doubleValue() : 0;
        double z = q2.size() > 2 ? q2.get(2).doubleValue() : 0;
        double w = q2.size() > 3 ? q2.get(3).doubleValue() : 0;
        return q1.subtract(new Quatd(x, y, z, w));
    }

    public static Quatd multiply( Quatd q1, Quatd q2 ) {
        return q1.mult(q2);
    }

    public static Object multiply( Quatd q1, List<Number> q2 ) {
        if( q2.size() == 3 ) {
            // Assume vec3d
            double x = q2.get(0).doubleValue();
            double y = q2.get(1).doubleValue();
            double z = q2.get(2).doubleValue();
            return q1.mult(new Vec3d(x, y, z));
        } else if( q2.size() == 4 ) {
            // Assume a quat
            double x = q2.get(0).doubleValue();
            double y = q2.get(1).doubleValue();
            double z = q2.get(2).doubleValue();
            double w = q2.get(3).doubleValue();
            return q1.mult(new Quatd(x, y, z, w));
        } else {
            throw new GroovyCastException("Cannot convert:" + q2 + " to a Vec3d or a Quatd.");
        }
    }

    public static Vec3d multiply( Quatd q, Vec3d v ) {
        return q.mult(v);
    }

    public static Vec3d multiply( Quatd q, Vec3i v ) {
        return q.mult(v.toVec3d());
    }

    public static Object asType( Quatd v, Class type ) {
        if( type == Quatd.class ) {
            return v;
        }
        throw new GroovyCastException("Cannot convert:" + v + " to:" + type);
    }
}
