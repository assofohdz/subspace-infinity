/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mgen;

import org.slf4j.*;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.Direction;

/**
 *
 *
 *  @author    Paul Speed
 */
public class PartUtils {
    static Logger log = LoggerFactory.getLogger(PartUtils.class);

    // Easy to make a 4-bit reflection table
    private static int[] xReflections = new int[] {
            0b0000, // 0000
            0b1000, // 0001
            0b0100, // 0010
            0b1100, // 0011
            0b0010, // 0100
            0b1010, // 0101
            0b0110, // 0110
            0b1110, // 0111
            0b0001, // 1000
            0b1001, // 1001
            0b0101, // 1010
            0b1101, // 1011
            0b0011, // 1100
            0b1011, // 1101
            0b0111, // 1110
            0b1111  // 1111
        };

    // Because Java string formatter doesn't do binary and we want padded strings
    private static String[] maskStrings = new String[] {
            "0000",
            "0001",
            "0010",
            "0011",
            "0100",
            "0101",
            "0110",
            "0111",
            "1000",
            "1001",
            "1010",
            "1011",
            "1100",
            "1101",
            "1110",
            "1111"
        };

    private static int[][] maskBits = new int[][] {
            {0,0,0,0},
            {0,0,0,1},
            {0,0,1,0},
            {0,0,1,1},
            {0,1,0,0},
            {0,1,0,1},
            {0,1,1,0},
            {0,1,1,1},
            {1,0,0,0},
            {1,0,0,1},
            {1,0,1,0},
            {1,0,1,1},
            {1,1,0,0},
            {1,1,0,1},
            {1,1,1,0},
            {1,1,1,1}
        };


    /**
     *  Converts the specified mask into a 4x4 array of cells where
     *  1 = bit on, 0 = bit off.  The array is indexed as [x][y]
     */
    public static int[][] maskToCells( int mask ) {
        int[] rows = splitRows(mask);
        int[][] result = new int[4][4];
        for( int y = 0; y < 4; y++ ) {
            int row = rows[y];
            int[] bits = maskBits[row];
            for( int x = 0; x < 4; x++ ) {
                result[x][y] = bits[x];
            }
        }
        return result;
    }

    public static int cellsToMask( int[][] cells ) {
        int[] rows = new int[4];
        for( int y = 0; y < 4; y++ ) {
            int x0 = cells[0][y];
            int x1 = cells[1][y];
            int x2 = cells[2][y];
            int x3 = cells[3][y];
            rows[y] = (x0 << 3) | (x1 << 2) | (x2 << 1) | x3;
        }
        return combineRows(rows);
    }

    public static Vec3i[] rotate( Vec3i size, Vec3i[] array, int rotate ) {
        if( array == null ) {
            return null;
        }
        if( rotate == 0 ) {
            return array;
        }
        rotate = rotate % 4;
        if( rotate < 0 ) {
            rotate += 4;
        }

        // Need to figure out where each location would be if the
        // cell array was rotated in place.
        Vec3i[] results = new Vec3i[array.length];

        for( int i = 0; i < array.length; i++ ) {
            Vec3i v = array[i];

            // Don't need to get fancy
            switch( rotate ) {
                case 1:
                    results[i] = new Vec3i(size.x - v.z - 1, v.y, v.x);
                    break;
                case 2:
                    results[i] = new Vec3i(size.x - v.x - 1, v.y, size.z - v.z - 1);
                    break;
                case 3:
                    results[i] = new Vec3i(v.z, v.y, size.z - v.x - 1);
                    break;
            }
        }

        return results;
    }


    public static Vec3i[] xMirror( Vec3i size, Vec3i[] array ) {
        if( array == null ) {
            return null;
        }

        // Need to figure out where each location would be if the
        // cell array was rotated in place.
        Vec3i[] results = new Vec3i[array.length];

        for( int i = 0; i < array.length; i++ ) {
            Vec3i v = array[i];
            results[i] = new Vec3i(size.x - v.x - 1, v.y, v.z);
        }

        return results;
    }

    public static Vec3i[] zMirror( Vec3i size, Vec3i[] array ) {
        if( array == null ) {
            return null;
        }

        // Need to figure out where each location would be if the
        // cell array was rotated in place.
        Vec3i[] results = new Vec3i[array.length];

        for( int i = 0; i < array.length; i++ ) {
            Vec3i v = array[i];
            results[i] = new Vec3i(v.x, v.y, size.z - v.z - 1);
        }

        return results;
    }

    /**
     *  Treats the mask as a 4x4 array of bits and rotates it by the
     *  specified 90 degree increment, 0 = none, 1 = 90, 2 = 180, etc..
     */
    public static int rotate( int mask, int rotate ) {
        rotate = rotate % 4;
        if( rotate < 0 ) {
            rotate += 4;
        }
        if( rotate == 0 ) {
            return mask;
        }
        if( rotate == 2 ) {
            // A 180 degree is the same as x/y reflected
            return xReflect(yReflect(mask));
        }
        // 0,0 is at the bottom, conceptually
        // rotate 90: target[y][3-x] = source[x][y]
        // rotate -90: target[3-y][x] = source[x][y]
        int[][] cells = maskToCells(mask);
        int[][] result = new int[4][4];
        for( int x = 0; x < 4; x++ ) {
            for( int y = 0; y < 4; y++ ) {
                 if( rotate == 1 ) {
                    result[y][3-x] = cells[x][y];
                } else {
                    result[3-y][x] = cells[x][y];
                }
            }
        }
        return cellsToMask(result);
        //int[] rows = new int[4];
        //for( int y = 0; y < 4; y++ ) {
        //    int x0 = result[0][y];
        //    int x1 = result[1][y];
        //    int x2 = result[2][y];
        //    int x3 = result[3][y];
        //    rows[y] = (x0 << 3) | (x1 << 2) | (x2 << 2) | x3;
        //}
        //return combineRows(rows);
    }

    public static int xReflect( int mask ) {
        int[] rows = splitRows(mask);
        for( int i = 0; i < 4; i++ ) {
            rows[i] = xReflections[rows[i]];
        }
        return combineRows(rows);
    }

    public static int yReflect( int mask ) {
        int[] rows = splitRows(mask);
        return combineRows(rows[3], rows[2], rows[1], rows[0]);
    }

    /**
     *  Rotates a whole direction set as appropriate and returns a new masks array.
     */
    public static int[] rotate( int[] masks, int rotate ) {
        if( masks == null ) {
            throw new IllegalArgumentException("Masks cannot be null");
        }
        rotate = rotate % 4;
        if( rotate < 0 ) {
            rotate += 4;
        }
        if( rotate == 0 ) {
            return masks;
        }
        int[] results = new int[6];

        // The cardinal directions are weird because some 90 degree
        // turns can simply be moved and some need to be reflected.
        // 180 degree turns always need to be reflected.  Since this
        // is not performance critical code, we'll just use a direct
        // one:one mapping and only rotate 90 at a time.
        int[] source = masks;
        for( int i = 0; i < rotate; i++ ) {

            // Negative to negative, just move it
            results[Direction.North.ordinal()] = source[Direction.West.ordinal()];

            // Negative to positive, flip
            results[Direction.East.ordinal()] = xReflect(source[Direction.North.ordinal()]);

            // Positive to positive
            results[Direction.South.ordinal()] = source[Direction.East.ordinal()];

            // Negative to nevative
            results[Direction.West.ordinal()] = xReflect(source[Direction.South.ordinal()]);

            if( i + 1 < rotate ) {
                // Still at least one more pass to go so shuffle
                source = results;
                results = new int[6];
            }
        }

        // Top and bottom actually need to be rotated
        results[4] = rotate(masks[4], rotate);
        results[5] = rotate(masks[5], rotate);

        return results;
    }

    public static int[] xReflect( int[] masks ) {
        int[] results = new int[6];

        // Just swap east and west
        results[Direction.East.ordinal()] = masks[Direction.West.ordinal()];
        results[Direction.West.ordinal()] = masks[Direction.East.ordinal()];

        // North, south, up, and down need to be reflected on the x axis
//log.info("North Test:");
//log.info("Normal:\n" + maskToString(masks[Direction.North.ordinal()]));
//log.info("xReflect:\n" + maskToString(xReflect(masks[Direction.North.ordinal()])));
        results[Direction.North.ordinal()] = xReflect(masks[Direction.North.ordinal()]);
        results[Direction.South.ordinal()] = xReflect(masks[Direction.South.ordinal()]);
        results[Direction.Up.ordinal()] = xReflect(masks[Direction.Up.ordinal()]);
        results[Direction.Down.ordinal()] = xReflect(masks[Direction.Down.ordinal()]);

        return results;
    }

    public static int[] zReflect( int[] masks ) {
        int[] results = new int[6];

        // Just swap north and south
        results[Direction.North.ordinal()] = masks[Direction.South.ordinal()];
        results[Direction.South.ordinal()] = masks[Direction.North.ordinal()];

        // East and west need to be reflected on the x-axis
        results[Direction.East.ordinal()] = xReflect(masks[Direction.East.ordinal()]);
        results[Direction.West.ordinal()] = xReflect(masks[Direction.West.ordinal()]);

        // North and south need to be reflected on their 'y' axis, ie: z
        results[Direction.Up.ordinal()] = yReflect(masks[Direction.Up.ordinal()]);
        results[Direction.Down.ordinal()] = yReflect(masks[Direction.Down.ordinal()]);

        return results;
    }


    public static int[] splitRows( int mask ) {
        int r0 = mask & 0xf;
        int r1 = (mask >> 4) & 0xf;
        int r2 = (mask >> 8) & 0xf;
        int r3 = (mask >> 12) & 0xf;
        return new int[] { r0, r1, r2, r3 };
    }

    public static int combineRows( int[] rows ) {
        return combineRows(rows[0], rows[1], rows[2], rows[3]);
    }

    public static int combineRows( int r0, int r1, int r2, int r3 ) {
        return (r3 << 12) | (r2 << 8) | (r1 << 4) | r0;
    }

    public static String maskToString( int mask ) {
        StringBuilder sb = new StringBuilder();
        int[] rows = splitRows(mask);
        for( int i = 3; i >= 0; i-- ) {
            if( sb.length() > 0 ) {
                sb.append("\n");
            }
            int row = rows[i];
            sb.append(maskStrings[row]);
        }
        return sb.toString();
    }
}
