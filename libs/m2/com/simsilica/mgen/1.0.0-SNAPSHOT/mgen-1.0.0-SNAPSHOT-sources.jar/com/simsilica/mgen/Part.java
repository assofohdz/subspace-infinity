/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mgen;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Part implements Insertable {
    static Logger log = LoggerFactory.getLogger(Part.class);

    private Vec3i offset;
    private CellArray cells;
    private int[] openMasks;
    private int[] requiredMasks;
    private Vec3i[] preserved;
    private int marks;
    private boolean impassable;
    private Set<String> tags;

    public Part( Set<String> tags, CellArray cells, int xOffset, int yOffset, int zOffset,
                 int[] openMasks, int[] requiredMasks, Vec3i[] preserved,
                 boolean impassable ) {
        this(tags, cells, new Vec3i(xOffset, yOffset, zOffset),
             openMasks, requiredMasks, preserved, impassable);
    }

    public Part( Set<String> tags, CellArray cells, Vec3i offset,
                 int[] openMasks, int[] requiredMasks, Vec3i[] preserved,
                 boolean impasable ) {
        this.tags = tags;
        this.cells = cells;
        this.offset = offset;
        this.openMasks = openMasks;
        this.requiredMasks = requiredMasks;
        this.impassable = impassable;
        this.preserved = preserved;
    }

    public Set<String> getTags() {
        return tags;
    }

    public boolean hasTag( String tag ) {
        return tags.contains(tag);
    }

    public boolean hasAny( Iterable<String> any ) {
        for( String s : any ) {
            if( tags.contains(s) ) {
                return true;
            }
        }
        return false;
    }

    public boolean hasAll( Collection<String> all ) {
        return tags.containsAll(all);
    }

    public int[] getOpenMasks() {
        return openMasks;
    }

    public int[] getRequiredMasks() {
        return requiredMasks;
    }

    public Vec3i getOffset() {
        return offset;
    }

    public Vec3i getSize() {
        return cells.getSize();
    }

    public CellArray getCells() {
        return cells;
    }

    public void setMarks( int marks ) {
        this.marks = marks;
    }

    public int getMarks() {
        return marks;
    }

    public void setImpassable( boolean impassable ) {
        this.impassable = impassable;
    }

    public boolean isImpassable() {
        return impassable;
    }

    public void setPreservedCells( Vec3i... preserved ) {
        this.preserved = preserved;
    }

    public Vec3i[] getPreservedCells() {
        return preserved;
    }

    public void insert( CellArray target, int x, int y, int z, IntCombiner combiner ) {
        CellUtils.copy(cells, 0, 0, 0,
                       target, x - offset.x, y - offset.y, z - offset.z,
                       cells.getSizeX(), cells.getSizeY(), cells.getSizeZ(),
                       combiner);
    }

    public void complete( CellArray target, int x, int y, int z, IntCombiner combiner ) {
        if( preserved == null || preserved.length == 0 ) {
            return;
        }
        for( Vec3i v : preserved ) {
            int type = cells.getCell(v.x, v.y, v.z);
log.info("Reasserting type:" + type + "  from:" + v);
            target.setCell(x - offset.x + v.x, y - offset.y + v.y, z - offset.z + v.z, type);
        }
    }

    public Part rotate( int rot ) {
        rot = rot % 4;
        if( rot < 0 ) {
            rot += 4;
        }
        if( getOpenMasks() == null ) {
            throw new IllegalStateException("Trying to rotate part with no open masks:" + this);
        }
        if( getRequiredMasks() == null ) {
            throw new IllegalStateException("Trying to rotate part with no required masks:" + this);
        }

        // For now, there isn't much to transform
        switch( rot ) {
            case 0:
                return this;
            case 1:
                return new Part(tags, CellUtils.rotate(cells, 1), 0, offset.y, offset.x,
                                PartUtils.rotate(getOpenMasks(), 1),
                                PartUtils.rotate(getRequiredMasks(), 1),
                                PartUtils.rotate(cells.getSize(), preserved, 1),
                                impassable);
            case 2:
                return new Part(tags, CellUtils.rotate(cells, 2), 0, offset.y, 0,
                                PartUtils.rotate(getOpenMasks(), 2),
                                PartUtils.rotate(getRequiredMasks(), 2),
                                PartUtils.rotate(cells.getSize(), preserved, 2),
                                impassable);
            case 3:
                return new Part(tags, CellUtils.rotate(cells, 3), offset.z, offset.y, 0,
                                PartUtils.rotate(getOpenMasks(), 3),
                                PartUtils.rotate(getRequiredMasks(), 3),
                                PartUtils.rotate(cells.getSize(), preserved, 3),
                                impassable);
        }
        return null;
    }

    public Part mirrorX() {
        return new Part(tags, CellUtils.mirrorX(cells), 0, offset.y, offset.z,
                        PartUtils.xReflect(getOpenMasks()),
                        PartUtils.xReflect(getRequiredMasks()),
                        PartUtils.xMirror(cells.getSize(), preserved),
                        impassable);
    }

    public Part mirrorZ() {
        return new Part(tags, CellUtils.mirrorZ(cells), offset.x, offset.y, 0,
                        PartUtils.zReflect(getOpenMasks()),
                        PartUtils.zReflect(getRequiredMasks()),
                        PartUtils.zMirror(cells.getSize(), preserved),
                        impassable);
    }

    @Override
    public String toString() {
        return "Part[" + tags + "]";
    }
}

