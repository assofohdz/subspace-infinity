/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mgen;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Building implements Insertable {
    static Logger log = LoggerFactory.getLogger(Building.class);

    private int xSize;
    private int ySize;
    private int zSize;
    private Slot[][][] slots;
    private int[] floorHeights;
    private int[] floorSpacings;
    private boolean[] locks;
    private int gridSpacing;

    public Building( int xSize, int ySize, int zSize ) {
        this.xSize = xSize;
        this.ySize = ySize;
        this.zSize = zSize;
        this.slots = new Slot[xSize][ySize][zSize];
        this.floorHeights = new int[ySize];
        this.floorSpacings = new int[ySize];
        this.locks = new boolean[ySize];
        setupConnectivity();
    }

    public int getSizeX() {
        return xSize;
    }

    public int getSizeY() {
        return ySize;
    }

    public int getSizeZ() {
        return zSize;
    }

    public void lock( int floor ) {
        locks[floor] = true;
    }

    public void unlock( int floor ) {
        locks[floor] = false;
    }

    public void setFloorHeight( int floor, int blockHeight ) {
        floorHeights[floor] = blockHeight;
    }

    public int getFloorHeight( int floor ) {
        return floorHeights[floor];
    }

    public void setFloorSpacing( int floor, int gridSpacing ) {
        floorSpacings[floor] = gridSpacing;
    }

    public int getFloorSpacing( int floor ) {
        return floorSpacings[floor];
    }

    protected void setupConnectivity() {
        for( int x = 0; x < xSize; x++ ) {
            for( int y = 0; y < ySize; y++ ) {
                for( int z = 0; z < zSize; z++ ) {
                    Slot slot = slots[x][y][z] = new Slot();

                    // Create the up connectivity, hook up the down connectivity
                    // to the lower layer
                    slot.set(Direction.Up, new Connectivity());
                    if( y > 0 ) {
                        slot.set(Direction.Down, slots[x][y-1][z].get(Direction.Up));
                    } else {
                        // Logic is easier if we force connectivity at the borders.
                        // And maybe it lets us force border requirements someday like
                        // doorways or windows in specific places or whatever.
                        slot.set(Direction.Down, new Connectivity());
                    }

                    // And similar for east/west, north/south
                    slot.set(Direction.East, new Connectivity());
                    if( x > 0 ) {
                        slot.set(Direction.West, slots[x-1][y][z].get(Direction.East));
                    } else {
                        slot.set(Direction.West, new Connectivity());
                    }
                    slot.set(Direction.South, new Connectivity());
                    if( z > 0 ) {
                        slot.set(Direction.North, slots[x][y][z-1].get(Direction.South));
                    } else {
                        slot.set(Direction.North, new Connectivity());
                    }
                }
            }
        }
    }

    public void setPart( int x, int y, int z, Part part ) {
        if( locks[y] ) {
            throw new IllegalArgumentException("Floor is locked:" + x + ", " + y + ", " + z);
        }

        Slot slot = slots[x][y][z];
        slot.part = part;

//log.info("setPart(" + x + ", " + y + ", " + z + ", " + part + ")");

        // Update the connectivity
        // Note: we assume that canFit() was already checked
        int[] required = part.getRequiredMasks();
        int[] open = part.getOpenMasks();

        for( int i = 0; i < 6; i++ ) {
            Connectivity conn = slot.dirs[i];
//if( i < 4 ) {
//    log.info("---[" + i + "] open:\n" + PartUtils.maskToString(conn.openMask)
//            + "\nrequired:\n" + PartUtils.maskToString(conn.requiredMask));
//    log.info("  part open:\n" + PartUtils.maskToString(open[i])
//            + "\nrequired:\n" + PartUtils.maskToString(required[i]));
//}
            // We'll combine them which will be useful for open path
            // traversal.  Required probably could/should be just blown
            // away each time, though.
            conn.openMask = conn.openMask & open[i];
            conn.requiredMask = conn.requiredMask | required[i];
        }
    }

    public Part getPart( int x, int y, int z ) {
        return slots[x][y][z].part;
    }

    public Part clearPart( int x, int y, int z ) {
        if( locks[y] ) {
            throw new IllegalArgumentException("Floor is locked:" + x + ", " + y + ", " + z);
        }

        Slot slot = slots[x][y][z];
        if( slot.part == null ) {
            return null;
        }
        Part result = slot.part;
        slot.part = null;

        // Reset the open and requirements masks in all directions
        for( int i = 0; i < 6; i++ ) {
            Connectivity conn = slot.dirs[i];
            Direction dir = Direction.values()[i];
            Vec3i v = new Vec3i(x, y, z).add(dir.getVec3i());
            if( v.x < 0 || v.x >= xSize
                || v.y < 0 || v.y >= ySize
                || v.z < 0 || v.z >= zSize ) {
                // We're off the edge, Just reset the masks
                conn.openMask = 0xffffffff;
                conn.requiredMask = 0;
                continue;
            }

            Part p = getPart(v.x, v.y, v.z);
            if( p == null ) {
                // We're off the edge, Just reset the masks
                conn.openMask = 0xffffffff;
                conn.requiredMask = 0;
                continue;
            }

            Direction rev = dir.reverse();
            conn.openMask = p.getOpenMasks()[rev.ordinal()];
            conn.requiredMask = p.getRequiredMasks()[rev.ordinal()];
        }
        return result;
    }

    public int getOpenMask( int x, int y, int z, int dir ) {
        Slot slot = slots[x][y][z];
        return slot.dirs[dir].openMask;
    }

    /**
     *  Returns true if the specified slot has connectivity requirements.
     */
    public boolean hasRequirements( int x, int y, int z ) {
        Slot slot = slots[x][y][z];
        for( Connectivity conn : slot.dirs ) {
            if( conn.requiredMask != 0 ) {
                return true;
            }
        }
        return false;
    }

    public boolean canFit( int x, int y, int z, Part part ) {
        Slot slot = slots[x][y][z];
        if( slot.part != null ) {
            // Already a part here
            return false;
        }

        int[] requiredMasks = part.getRequiredMasks();
        int[] openMasks = part.getOpenMasks();

        // Check the connectors
        for( int i = 0; i < 6; i++ ) {
            int open = slot.dirs[i].openMask;
            int req = requiredMasks[i];
            // See if the part's requirements match the current opening.
            if( (req & open) != req ) {
                // Reject this direction
//log.info("[" + i + "] slot open:\n" + PartUtils.maskToString(open)
//        + "      part req:\n" + PartUtils.maskToString(req));
                return false;
            }
            // See if the parts opening matches the current requirements
            open = openMasks[i];
            req = slot.dirs[i].requiredMask;
            if( (req & open) != req ) {
                // Reject this direction
//log.info("[" + i + "] part open:\n" + PartUtils.maskToString(open)
//        + "      slot req:\n" + PartUtils.maskToString(req));
                return false;
            }
        }

        return true;
    }

    public void insert( CellArray target, int x, int y, int z, IntCombiner combiner ) {
        // For the moment we'll hard code the y step
        // Note: doing the y loop on the outside will probably
        // make the combiner more sensible, I think.
        int yTarget = y;
        for( int j = 0; j < ySize; j++ ) {
            int gridSpacing = floorSpacings[j];
            if( gridSpacing == 0 ) {
                gridSpacing = 4;
            }
            for( int i = 0; i < xSize; i++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    Part p = getPart(i, j, k);
                    if( p == null ) {
                        continue;
                    }
                    p.insert(target, x + (i * gridSpacing), yTarget, z + (k * gridSpacing), combiner);
                }
            }
            if( floorHeights[j] == 0 ) {
                yTarget += 2;
            } else {
                yTarget += floorHeights[j];
            }
        }

        yTarget = y;
        for( int j = 0; j < ySize; j++ ) {
            int gridSpacing = floorSpacings[j];
            if( gridSpacing == 0 ) {
                gridSpacing = 4;
            }
            for( int i = 0; i < xSize; i++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    Part p = getPart(i, j, k);
                    if( p == null ) {
                        continue;
                    }
                    p.complete(target, x + (i * gridSpacing), yTarget, z + (k * gridSpacing), combiner);
                }
            }
            if( floorHeights[j] == 0 ) {
                yTarget += 2;
            } else {
                yTarget += floorHeights[j];
            }
        }
    }

    /**
     *  Tries to replace the current part with a new part that has the
     *  same connectivity information but opens up in the specified direction.
     *  Note: it does not necessarily open the back-channel.
     */
    public void openPath( int x, int y, int z, int dir, List<Part> parts, Random rand ) {
        if( locks[y] ) {
            throw new IllegalArgumentException("Floor is locked:" + x + ", " + y + ", " + z);
        }

        Slot slot = slots[x][y][z];

        if( slot.dirs[dir].openMask != 0 ) {
            // Already open in that direction to some extent
            return;
        }

        // Make sure that we are at least as open as before
        int[] required = new int[4];
        for( int d = 0; d < 4; d++ ) {
            required[d] = slot.dirs[d].openMask;
//log.info("  required[" + d + "] = " + required[d]);
        }
        required[dir] = 0xffffffff;

        clearPart(x, y, z);

        // Find a new random part with the same old connectivity
        // information plus the new one.
        int index = rand.nextInt(parts.size());
        for( int j = 0; j < parts.size(); j++ ) {
            Part p = parts.get((index + j) % parts.size());
            int[] masks = p.getOpenMasks();
            if( masks[dir] == 0 ) {
                // Not better than what we have
                continue;
            }
            if( !canFit(x, y, z, p) ) {
                // Won't fit in other ways
                continue;
            }
//log.info("    Checking part:" + p);
            // See if this part is open enough
            boolean matches = true;
            for( int d = 0; d < 4; d++ ) {
                if( required[d] != 0 && (masks[d] & required[d]) == 0 ) {
//log.info("      dir:" + d + "  mask:" + masks[d] + "  req:" + required[d]);
                    matches = false;
                    break;
                }
            }
            if( !matches ) {
                continue;
            }
            // We found a winner
log.info("  reset(" + x + ", " + y + ", " + z + "):" + p);
            setPart(x, y, z, p);
            return;
        }

        log.info("No matching part found.");
    }

    private class Connectivity {
        int openMask = 0xffffffff;
        int requiredMask = 0x0;
    }

    private class Slot {
        Connectivity[] dirs = new Connectivity[6];
        Part part;

        public Slot() {
        }

        public void set( Direction dir, Connectivity conn ) {
            dirs[dir.ordinal()] = conn;
        }

        public Connectivity get( Direction dir ) {
            return dirs[dir.ordinal()];
        }
    }
}

