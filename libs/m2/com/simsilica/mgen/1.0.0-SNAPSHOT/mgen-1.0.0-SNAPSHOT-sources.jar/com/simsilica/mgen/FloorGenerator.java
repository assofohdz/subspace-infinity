/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mgen;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *  Encapsulates everything necessary to write a set of random floor-specific
 *  parts into a Building's parts array.
 *
 *  @author    Paul Speed
 */
public class FloorGenerator {
    static Logger log = LoggerFactory.getLogger(FloorGenerator.class);

    private int xSize;
    private int zSize;
    private int blockHeight;
    private int gridSpacing;
    private Vec3i offset;
    private PartList[][] parts;
    private List<String> requires;
    private List<String> limit;

    public FloorGenerator( int xSize, int zSize, Vec3i offset, int blockHeight, int gridSpacing, List<String> requires, List<String> limit ) {
        this.xSize = xSize;
        this.zSize = zSize;
        this.blockHeight = blockHeight;
        this.gridSpacing = gridSpacing;
        this.offset = offset;
        this.requires = requires;
        this.limit = limit;
        this.parts = new PartList[xSize][zSize];
    }

    public void shuffle( Random rand ) {
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                PartList pl = parts[i][j];
                if( pl == null || pl.parts == null || pl.parts.isEmpty() ) {
                    continue;
                }
                Collections.shuffle(pl.parts, rand);
            }
        }
    }

    public int getSizeX() {
        return xSize;
    }

    public int getSizeZ() {
        return zSize;
    }

    public Vec3i getOffset() {
        return offset;
    }

    public int getBlockHeight() {
        return blockHeight;
    }

    public int getGridSpacing() {
        return gridSpacing;
    }

    public void setParts( int x, int z, List<Part> parts ) {
        this.parts[x][z] = new PartList(parts);
    }

    public List<Part> getParts( int x, int z ) {
        PartList slot = parts[x][z];
        return slot == null ? null : slot.parts;
    }

    public void addPart( int x, int z, Part part ) {
        if( part == null ) {
            return;
        }
        if( parts[x][z] == null ) {
            parts[x][z] = new PartList(new ArrayList<>());
        }
        parts[x][z].parts.add(part);
    }

    public void generateFloor( Building building, int level, Random rand ) {

log.info("generateFloor(" + building + ", " + level + ")");
if( offset.y != 0 ) {
    log.info("  real floor:" + (offset.y + level) + ")");
}

        // Setup some working data structures for keeping track
        // of the maximum number of certain tags as well as whether
        // we should now exclude them.
        //List<String> min = requires == null ? Collections.emptyList() : new ArrayList<>(requires);
        //List<String> max = limit == null ? Collections.emptyList() : new ArrayList<>(limit);
        //Set<String> exclude = new HashSet<>();
        TagRequirements tagReqs = new TagRequirements(requires, limit);

        building.setFloorHeight(level + offset.y, blockHeight);
        building.setFloorSpacing(level + offset.y, gridSpacing);

log.info("Building available slot list and checking for connectivity requirements...");
        // Create a list of all available slots that we can then
        // randomize.  We'll pull items off the back as we use them.
        List<Vec3i> availableSlots = new ArrayList<>();
        int y = level + offset.y;
        for( int x = 0; x < xSize; x++ ) {
            for( int z = 0; z < zSize; z++ ) {
                if( parts[x][z] == null ) {
                    continue;
                }
                if( building.getPart(offset.x + x, y, offset.z + z) != null ) {
                    // Something else already filled it
                    continue;
                }
                if( building.hasRequirements(offset.x + x, y, offset.z + z) ) {
log.info("Trying to prefill slot:" + x + ", " + y + ", " + z);

                    // Then we should try to fill this one first
                    List<Part> parts = getParts(x, z);

                    // Start from a random location
                    int index = rand.nextInt(parts.size());

                    // Find the first part that has the tag starting at that slot
                    Part found = null;
                    for( int i = 0; i < parts.size(); i++ ) {
                        Part p = parts.get(index);
                        if( tagReqs.isExcluded(p) ) {
                            // Have to check the excludes else we might
                            // accidentally put in a second stair way or something.
                            index = (index + 1) % parts.size();
                            continue;
                        }
                        // See if the part can fit
                        if( building.canFit(offset.x + x, y, offset.z + z, p) ) {
log.info("  set part:" + p);
                            building.setPart(offset.x + x, y, offset.z + z, p);
                            found = p;
                            break;
                        }
                        index = (index + 1) % parts.size();
                    }
                    if( found != null ) {
                        // See if the part satisfies a requirement
                        tagReqs.markUsed(found);
/*
                        if( !min.isEmpty() ) {
                            Set<String> alreadyUsed = new HashSet<>();
                            for( Iterator<String> it = min.iterator(); it.hasNext(); ) {
                                String req = it.next();
                                if( !alreadyUsed.add(req) ) {
                                    continue;
                                }
                                if( found.hasTag(req) ) {
log.info("Satisfied requirement:" + req);
                                    it.remove();
                                }
                            }
                        }

                        if( !max.isEmpty() ) {
                            // Check to see if we've used any of our limits
                            for( String tag : found.getTags() ) {
                                if( max.remove(tag) ) {
log.info("Used one:" + tag + " with:" + found + "  in slot:" + x + ", " + z);
                                    if( !max.contains(tag) ) {
log.info("Used them all:" + tag);
                                        exclude.add(tag);
                                    }
                                }
                            }
                        }
*/
                        // We already filled the slot now
                        continue;
                    } else {
                        log.warn("No valid part for:" + x + ", " + y + ", " + z);
                        log.warn("  ...offset:" + (offset.x + x) + ", " + (y) + ", " + (offset.z + z));

                        // For now, log why
                        for( int i = 0; i < parts.size(); i++ ) {
                            Part p = parts.get(index);
                            if( tagReqs.isExcluded(p) ) {
                                log.warn("  excluded:" + p);
                            }
                            // See if the part can fit
                            if( !building.canFit(offset.x + x, y, offset.z + z, p) ) {
                                log.warn("  can't fit:" + p);
                            }
                            index = (index + 1) % parts.size();
                        }
                    }
                }
                if( parts[x][z] != null ) {
                    availableSlots.add(new Vec3i(x, y, z));
                }
            }
        }
        Collections.shuffle(availableSlots, rand);

log.info("filled so far:");
for( int x = 0; x < xSize; x++ ) {
    for( int z = 0; z < zSize; z++ ) {
        Part part = building.getPart(x, y, z);
        if( part == null ) {
            continue;
        }
        log.info("[" + x + "][" + y + "] = " + part);
    }
}

log.info("Filling in the min requirements...");
//log.info("min:" + min + "   max:" + max + "   exclude:" + exclude);
log.info("" + tagReqs);
        // First take care of the things that we require, if any
        //if( !min.isEmpty() ) {
        if( tagReqs.hasMinRequirements() ) {
            int maxTries = availableSlots.size();

            //for( int reqIndex = 0; reqIndex < min.size(); reqIndex++ ) {
            //    String req = min.get(reqIndex);
            String req = null;
            while( (req = tagReqs.getFirstReq()) != null ) {
log.info("Filling requirement:" + req);
                // Pick a random slot
                Vec3i loc = availableSlots.remove(availableSlots.size()-1);
log.info("Trying slot:" + loc);
                // Wouldn't have been available if there weren't parts already.
                List<Part> parts = this.parts[loc.x][loc.z].parts;
                // Start from a random location
                int index = rand.nextInt(parts.size());

                Part part = null;

                // Find the first part that has the tag starting at that slot
                for( int i = 0; i < parts.size(); i++ ) {
                    Part p = parts.get(index);
                    if( p.hasTag(req) ) {

                        // See if the part can fit
                        if( building.canFit(offset.x + loc.x, loc.y, offset.z + loc.z, p) ) {
log.info("  preset[" + loc + "]:" + p);
                            building.setPart(offset.x + loc.x, loc.y, offset.z + loc.z, p);
                            part = p;
                            break;
                        }
                    }
                    index = (index + 1) % parts.size();
                }
                //if( building.getPart(offset.x + loc.x, loc.y, offset.z + loc.z) == null ) {
                if( part == null ) {
                    log.warn("Could not find part for requirement:" + req + " in parts:" + parts);
                    // Add the slot back and try the next one
                    //reqIndex--;
                    availableSlots.add(0, loc);
                    maxTries--;
                    if( maxTries <= 0 ) {
                        throw new RuntimeException("Exceeded available slots trying to fill requirement:" + req);
                    }
                    continue;
                } else {
                    maxTries = availableSlots.size();
                }

                tagReqs.markUsed(part);

/*                if( max.remove(req) ) {
log.info("Used one:" + req + " with:" + building.getPart(loc.x, loc.y, loc.z) + "  in slot:" + loc);
                    if( !max.contains(req) ) {
                        // We ran out... so don't use anymore later
log.info("Used them all:" + req);
                        exclude.add(req);
                    }
                }*/
            }
        }

log.info("filled so far:");
for( int x = 0; x < xSize; x++ ) {
    for( int z = 0; z < zSize; z++ ) {
        Part part = building.getPart(x, y, z);
        if( part == null ) {
            continue;
        }
        log.info("[" + x + "][" + y + "] = " + part);
    }
}

log.info("Filling in the rest...");
//log.info("min:" + min + "   max:" + max + "   exclude:" + exclude);
log.info("" + tagReqs);
        // Now go through the rest of the available slots
        for( Vec3i loc : availableSlots ) {
            int x = loc.x;
            int z = loc.z;

            List<Part> parts = this.parts[loc.x][loc.z].parts;

            // Find the first non-excluded part starting at a random index
            int start = rand.nextInt(parts.size());
            for( int i = 0; i < parts.size(); i++ ) {
                int index = (start + i) % parts.size();
                Part p = parts.get(index);
                if( tagReqs.isExcluded(p) ) {
                //if( p.hasAny(exclude) ) {
                    continue;
                }
                if( !building.canFit(offset.x + loc.x, loc.y, offset.z + loc.z, p) ) {
//log.info("  part can't fit " + loc + " = " + p);
                    continue;
                }
log.info("  set" + loc + ":" + p);
                building.setPart(offset.x + loc.x, loc.y, offset.z + loc.z, p);
//log.info("[" + loc + "] = " + p);

                tagReqs.markUsed(p);

                /*if( !max.isEmpty() ) {
                    // Check to see if we've used any of our limits
                    for( Iterator<String> it = max.iterator(); it.hasNext(); ) {
                        String s = it.next();
                        if( p.hasTag(s) ) {
                            it.remove();
log.info("Used one:" + s + " with:" + p + "  in slot:" + x + ", " + z);
                            if( !max.contains(s) ) {
                                // We ran out... so don't use anymore later
log.info("Used them all:" + s);
                                exclude.add(s);
                            }
                        }
                    }
                }*/
                break;
            }
        }

        // Make sure that all locations connect and still follow the rules
        //connect(building, level, rand);
        // For testing, we'll make it a separate call temporarily.
    }

    public void connect( Building building, int level, Random rand ) {
        // Seed a pending list with a starting location.
        // We'll just arbitrarily find the first non-empty slot
        // as we fill in the unvisited set.
        int y = level + offset.y;
        LinkedList<Vec3i> pending = new LinkedList<>();
        Set<Vec3i> unvisited = new HashSet<>();
        Vec3i start = null;
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                Part part = building.getPart(i, y, j);
                if( part != null && !part.isImpassable() ) {
                    Vec3i v = new Vec3i(i, y, j);
                    unvisited.add(v);
                    if( start == null ) {
                        // Note: while we could have just grabbed the first entry
                        // in the set, eventually we may go with a marker array
                        // instead of a set and then that wouldn't work.
                        start = v;
                    }
                }
            }
        }
        if( start == null ) {
            log.warn("Building is empty:" + building);
            return;
        }

        // TODO: swap out visited/unvisited sets for an array
        // of markers.  Actually, given the collection shuffling we do
        // it may not be as efficient as one thinks to convert to markers.
        Set<Vec3i> visited = new HashSet<>();

        // Find the connected slots
        pending.add(start);
        markConnectivity(building, pending, unvisited, visited);
        log.info(unvisited.size() + " disconnected slots");

        if( unvisited.isEmpty() ) {
            // The floor is already connected
            return;
        }

        // As long as we still have unvisited cells then try to randomly connect
        // some unvisited areas.
        LinkedList<Vec3i> connect =  new LinkedList<>(unvisited);
        while( !connect.isEmpty() ) {
            // Even if we can't connect it to something, we shouldn't try it
            // again in the future until we revisit... and then we'll reseed
            // the connect list.
            Vec3i loc = connect.removeFirst();

            // Start from a random direction
            int dirOffset = rand.nextInt(4);
            for( int i = 0; i < 4; i++ ) {
                int d = (dirOffset + i) % 4;
                Direction dir = Direction.values()[d];
                Vec3i v = loc.add(dir.getVec3i());
                if( !visited.contains(v) ) {
                    // Connecting to it does not improve things because it's
                    // also not visited
                    continue;
                }

                // See which part of the two parts that make this connection
                // we need to replace.
                // Note: it could be both so we'll check both and process
                // both, not if/else
                Part p;
                int open;

                // Check where we're coming from first because we already
                // have that direction
                p = building.getPart(offset.x + loc.x, loc.y, offset.z + loc.z);
                if( p != null ) {
                    open = p.getOpenMasks()[d];
                    if( open == 0 ) {
log.info("Opening forward from:" + loc + "  dir:" + dir);
                        // This is convenient but it also ignores required tags like doors and
                        // stairs and might swap them out.
                        // TODO: move openPath() to this class where it has the info needed.
                        building.openPath(offset.x + loc.x, loc.y, offset.z + loc.z, d, getParts(loc.x, loc.z), rand);
                    }
                }

                // Then check where we were going
                int rev = dir.reverse().ordinal();
                p = building.getPart(offset.x + v.x, v.y, offset.z + v.z);
                if( p != null ) {
                    open = p.getOpenMasks()[rev];
                    if( open == 0 ) {
log.info("Opening back from:" + v + "  dir:" + dir.reverse());
                        building.openPath(offset.x + v.x, v.y, offset.z + v.z, rev, getParts(v.x, v.z), rand);
                    }
                }

                // loc is connected now so we should be able to rerun the pending loop
                pending.add(loc);
                break;
            }

            if( pending.isEmpty() ) {
                // We didn't find anything at that slot... so try another one next pass
                continue;
            }

            // Otherwise, we have new connectivity to calculate
            markConnectivity(building, pending, unvisited, visited);

            if( unvisited.isEmpty() ) {
                // We're done
                break;
            }
            // Else prep for the next pass to find an appropriate unvisited to
            // connet.
            connect =  new LinkedList<>(unvisited);
        }
    }

    protected void markConnectivity( Building building, LinkedList<Vec3i> pending, Set<Vec3i> unvisited, Set<Vec3i> visited ) {

        while( !pending.isEmpty() ) {
            Vec3i loc = pending.removeFirst();
log.info("visit:" + loc);
            unvisited.remove(loc);
            if( !visited.add(loc) ) {
                continue;
            }

            for( int d = 0; d < 4; d++ ) {
                int open = building.getOpenMask(offset.x + loc.x, loc.y, offset.z + loc.z, d);
                if( open == 0 ) {
                    // It's blocked
                    continue;
                }

                Direction dir = Direction.values()[d];
                Vec3i v = loc.add(dir.getVec3i());
                if( visited.contains(v) ) {
                    // Already went this direction
                    continue;
                }

                if( v.x < 0 || v.x >= xSize
                    || v.z < 0 || v.z >= zSize ) {
                    // Could keep track of these if we wanted to
                    log.info("Exit at:" + loc + " in direction:" + dir);
                    continue;
                }
                if( building.getPart(offset.x + v.x, v.y, offset.z + v.z) == null ) {
                    // Could keep track of these if we wanted to
                    log.info("Exit at:" + loc + " in direction:" + dir);
                    continue;
                }

                pending.add(v);
            }
        }
    }

    private class PartList {
        List<Part> parts;

        public PartList( List<Part> parts ) {
            this.parts = parts;
        }
    }

    /**
     *  Keeps track of the current tag requirements as different parts
     *  use them up.
     */
    private class TagRequirements {
        private List<String> min;
        private Set<String> max;
        private Set<String> exclude = new HashSet<>();

        public TagRequirements( List<String> requires, List<String> limit ) {
            this.min = requires == null ? Collections.emptyList() : new ArrayList<>(requires);
            this.max = limit == null ? Collections.emptySet() : new HashSet<>(limit);
        }

        public String getFirstReq() {
            if( min.isEmpty() ) {
                return null;
            }
            return min.get(0);
        }

        public boolean isExcluded( Part part ) {
            return part.hasAny(exclude);
        }

        public boolean hasMinRequirements() {
            return !min.isEmpty();
        }

        public void markUsed( Part part ) {
            // Need to go through each of the part's tags and settle up
            // with min/max
            for( String tag : part.getTags() ) {
                min.remove(tag);
                if( max.remove(tag) ) {
                    if( !max.contains(tag) ) {
                        // We've run out of this tag so add it to the excludes set
                        exclude.add(tag);
                    }
                }
            }
        }

        @Override
        public String toString() {
            return getClass().getSimpleName() + "[min:" + min + ", max:" + max + ", exclude:" + exclude + "]";
        }
    }
}


