/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mgen;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BuildingGenerator {
    static Logger log = LoggerFactory.getLogger(BuildingGenerator.class);
    
    // Tags we can use to find buildlings with particular features
    // or themes.
    private Set<String> tags;
    private Vec3i size = new Vec3i();
    private int blockHeight = 0;
    private FloorGenerator[] generators;
    
    public BuildingGenerator( Set<String> tags, FloorGenerator... generators ) {
        this.tags = tags;
        this.generators = generators;
        
        // Calculate the sizes
        int[] floorHeights = new int[generators.length]; // may be bigger than required
        for( int i = 0; i < generators.length; i++ ) {
            FloorGenerator generator = generators[i];
 
            Vec3i offset = generator.getOffset();
            
            size.x = Math.max(size.x, generator.getSizeX() + offset.x);
            size.y = Math.max(size.y, i + offset.y + 1); 
            size.z = Math.max(size.z, generator.getSizeZ() + offset.z);
 
            int floor = i + offset.y;
            if( floor < 0 ) {
                throw new IllegalArgumentException("Negative floor offfset:" + (i + offset.y) + " for floor:" + i + "  offset:" + offset); 
            }
            floorHeights[floor] = Math.max(floorHeights[floor], generator.getBlockHeight());
        }
        
        for( int h : floorHeights ) {
            blockHeight += h;
        }
    }

    public Set<String> getTags() {
        return tags;
    }

    public Vec3i getSize() {
        return size;
    }
    
    public int getBlockHeight() {
        return blockHeight;
    }
    
    public void shuffle( Random rand ) {
        for( FloorGenerator gen : generators ) {
            if( gen != null ) {
                gen.shuffle(rand);
            }
        }
    }
    
    public Building generate( Random rand ) {
log.info("generate()");
log.info("size:" + size);
        Building building = new Building(size.x, size.y, size.z);
log.info("floor generators:" + Arrays.asList(generators));         
        for( int i = 0; i < generators.length; i++ ) {
            FloorGenerator gen = generators[i];
            if( gen != null ) {
                gen.generateFloor(building, i, rand);
                gen.connect(building, i, rand);
            }
        }
        return building;
    }     
}


