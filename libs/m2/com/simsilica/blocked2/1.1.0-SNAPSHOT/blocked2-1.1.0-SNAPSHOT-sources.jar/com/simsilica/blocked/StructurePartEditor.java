/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.Vec3iEditor;

/**
 *  
 *
 *  @author    Paul Speed
 */
public class StructurePartEditor extends Container {
    static Logger log = LoggerFactory.getLogger(StructurePartEditor.class);
    
    private VersionedList<String> tags = new VersionedList<>();
    private ListBox<String> tagList;
    private StructurePartInfo part;
    private VersionedReference<StructurePartInfo> partRef; 
    
    private Checkbox impassable;
    private Vec3iEditor offsetEditor;
    private Spinner<Double> frequencyEditor;
    
    private VersionedReference<Boolean> impassableRef;
    private VersionedReference<Double> frequencyRef;
    private VersionedReference<Vec3i> offsetRef;
 
    private Label[] openLabels;
    private Label[] requiredLabels; 
    
    public StructurePartEditor() { 

        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("Frequency:"));
 
        SequenceModel<Double> model = SequenceModels.rangedSequence(
                                                new DefaultRangedValueModel(1, 20, 0), 
                                                1, 1);
        frequencyRef = model.createReference();
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.0f", "error");       
        frequencyEditor = properties.addChild(new Spinner<>(model, renderer), 1);
        frequencyEditor.setValueEditor(ValueEditors.doubleEditor("%.0f"));
        
        properties.addChild(new Label("Offset:"));        
        offsetEditor = properties.addChild(new Vec3iEditor(), 1);
        offsetRef = offsetEditor.createReference();

        Container flags = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        impassable = flags.addChild(new Checkbox("Impassable"));
        impassableRef = impassable.getModel().createReference();
    
        addChild(new Label("Tags:"));
        tagList = addChild(new ListBox<>(tags));
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "addTags")));        
        buttons.addChild(new ActionButton(new CallMethodAction(this, "removeTag")));
        
        addChild(new Label("Masks:"));
        Container masks = addChild(new Container());

        openLabels = new Label[6];
        requiredLabels = new Label[6];
        masks.addChild(new Label("Open:"), 1);
        masks.addChild(new Label("Req.:"), 2);
        for( int d = 0; d < 6; d++ ) {
            Direction dir = Direction.values()[d];
            masks.addChild(new Label(dir.toString()));
            openLabels[d] = masks.addChild(new Label("0"), 1);
            requiredLabels[d] = masks.addChild(new Label("0"), 2);
        }        
        
    }
 
    public void setObject( StructurePartInfo part ) {
        if( part == null ) {
            partRef = null;
        } else {
            partRef = part.createReference();
        }
        this.part = part;
        refreshEditor();
    }
    
    public StructurePartInfo getObject() {
        return part;
    }
    
    protected void addTags() {
        GetStringDialog dialog = new GetStringDialog("Add Tags", "Tags:", "", (tags) -> {
                addTags(tags);
            });
        dialog.show();    
    }
    
    protected void addTags( String tags ) {
        if( part != null ) {
            String[] array = tags.split("\\s*,\\s*");
            for( String s : array ) {
                part.addTag(s);
            }
        }
    }
    
    protected void removeTag() {
        removeTag(tagList.getSelectedItem());
    }
    
    protected void removeTag( String tag ) {
        if( part != null ) {
            part.removeTag(tag);
        }
    }
 
    @Override   
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( partRef != null && partRef.update() ) {
            refreshEditor();
        }
        if( part != null ) {
            if( impassableRef.update() ) {
                part.setImpassable(impassableRef.get());
            }
            if( offsetRef.update() ) {
                part.setOffset(offsetRef.get());
            }
            if( frequencyRef.update() ) {
                double d = frequencyRef.get();
                part.setFrequency((int)d); 
            }
        }
    }    
    
    protected void refreshEditor() {
        tags.clear();
        if( part != null ) {        
            tags.addAll(part.getTags());
            impassable.setChecked(part.isImpassable());
            offsetEditor.setObject(part.getOffset().clone());
            frequencyEditor.setValue((double)part.getFrequency());
        }
        refreshMasks();
    }
    
    protected void refreshMasks() {
        int[] open = part == null ? null : part.getOpenMasks();
        int[] req = part == null ? null : part.getRequiredMasks();
                
        for( int d = 0; d < 6; d++ ) {
            String s1 = open == null ? "-" : Integer.toBinaryString(open[d]);
            String s2 = req == null ? "-" : Integer.toBinaryString(req[d]);
            openLabels[d].setText(s1);
            requiredLabels[d].setText(s2);
        } 
    }
}


