/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.event.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.Texture.MagFilter;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.input.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.blocked.tool.*;

/**
 *  Composite UI element that allows raw fluid type selection.
 *
 *  @author    Paul Speed
 */
public class FluidSelector extends Container {
    static Logger log = LoggerFactory.getLogger(FluidSelector.class);

    private VersionedList<String> typeNames = new VersionedList<>();
    private VersionedList<Integer> levels = new VersionedList<>();  

    private Selector<String> typeSelector;
    private VersionedReference<String> typeRef;
    private Spinner<Integer> levelSpinner;
    private VersionedReference<Integer> levelRef;
 
    private VersionedHolder<FluidInfo> fluid = new VersionedHolder<>(new FluidInfo(null,0));
    
    public FluidSelector() {
 
        typeNames.add("water");
        typeNames.add("lava");
        typeNames.add("keep");
        typeNames.add("required");
        levels.add(1);  // Note that in actual fluid levels this is '0'
        levels.add(2);
        levels.add(3);
        levels.add(4);
        levels.add(5);
        levels.add(6);
        levels.add(7);
        levels.add(8);
        
        addChild(new Label("Type:"));
        typeSelector = addChild(new Selector(typeNames), 1);
        typeRef = typeSelector.createSelectedItemReference();
 
        addChild(new Label("Level:"));
        levelSpinner = addChild(new Spinner(SequenceModels.listSequence(levels)), 1);
        levelRef = levelSpinner.getModel().createReference();        
    }    
 
    public FluidInfo getFluidInfo() {
        return fluid.getObject();
    }
    
    public VersionedReference<FluidInfo> createFluidInfoReference() {
        return fluid.createReference();
    }
    
    public void nextLevel() {
        levelSpinner.nextValue();
    }
    
    public void previousLevel() {
        levelSpinner.previousValue();
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        boolean changed = false;
        if( typeRef.update() ) {
            changed = true;
        }
        if( levelRef.update() ) {
            changed = true;
        }
        if( changed ) {
            //updateTypeSelection();
            fluid.updateObject(new FluidInfo(typeRef.get(), levelRef.get()));
        }
    }
 
    
}


