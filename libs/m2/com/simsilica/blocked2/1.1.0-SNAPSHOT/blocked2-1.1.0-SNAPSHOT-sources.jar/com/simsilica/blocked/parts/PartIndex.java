/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mgen.Part;

/**
 *
 *
 *  @author    Paul Speed
 */
public class PartIndex {
    static Logger log = LoggerFactory.getLogger(PartIndex.class);
    
    private Map<StructurePartInfo, Map<PartTransform, Part>> index = new HashMap<>();
        
    public PartIndex() {
    }
        
    public Map<PartTransform, Part> getTransforms( StructurePartInfo info ) {
        Map<PartTransform, Part> parts = index.get(info);
        return parts == null ? Collections.emptyMap() : parts;
    }
        
    public void indexPart( StructurePartInfo info, Part part ) {
        Map<PartTransform, Part> parts = index.get(info);
        if( parts == null ) {
            parts = new HashMap<>();
            index.put(info, parts);
        } else if( !parts.isEmpty() ) {
            parts.clear();
        }
 
        Part original = part;
        Part rot90 = original.rotate(1); 
        Part mirrorX = original.mirrorX();
        Part mirrorZ = original.mirrorZ();
        Part rot90MirrorX = rot90.mirrorX();
        // This last one is a special case where the offset gets
        // wiped out.  This is because I don't actually do the math
        // for the 'origin' and adjust by rotated cell, etc. and just kludged some
        // offset substitution.  Continuing the trend by fixing it 'in post'
        rot90MirrorX.getOffset().x = original.getOffset().z;
 
        parts.put(PartTransform.None, original);
        parts.put(PartTransform.Rot90, rot90);
        parts.put(PartTransform.Rot180, original.rotate(2));
        parts.put(PartTransform.Rot270, original.rotate(3));
        parts.put(PartTransform.MirrorX, mirrorX);
        parts.put(PartTransform.MirrorZ, mirrorZ);
        parts.put(PartTransform.Rot90MirrorX, rot90MirrorX);
        parts.put(PartTransform.Rot90MirrorZ, rot90.mirrorZ());
    }
}

