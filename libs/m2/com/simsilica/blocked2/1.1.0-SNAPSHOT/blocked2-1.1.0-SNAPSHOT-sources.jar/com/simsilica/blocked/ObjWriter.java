/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Charsets;

import com.jme3.math.*;
import com.jme3.scene.*;

/**
 *  Writes JME spatial data out as a simplified version of
 *  Wavefront's OBJ format.  Right now I'm doing this for 3D printing
 *  so won't be including materials, textures, normals, etc..
 *
 *  @author    Paul Speed
 */
public class ObjWriter {

    static Logger log = LoggerFactory.getLogger(ObjWriter.class);

    private PrintWriter out;

    private Map<Vector3f, Integer> verts = new HashMap<>();
    private int baseIndex = 0;
    private int faceCount = 0;

    public ObjWriter( File f ) throws IOException {
        FileOutputStream fOut = new FileOutputStream(f);
        this.out = new PrintWriter(new OutputStreamWriter(fOut, Charsets.UTF_8));
    }

    public void write( Spatial spatial ) {
        log.info("Writing:" + spatial);
        if( spatial instanceof Node ) {
            Node n = (Node)spatial;
            for( Spatial s : n.getChildren() ) {
                write(s);
            }
        } else if( spatial instanceof Geometry ) {
            write((Geometry)spatial);
        } else {
            log.error("Unhandled type for:" + spatial);
        }
    }

    private int vertIndex = 0;
    private boolean optimize = true;

    private int writeVertex( Vector3f vert ) {
        if( optimize ) {
            Integer index = verts.get(vert);
            if( log.isTraceEnabled() ) {
                log.trace("writeVertex(" + vert + ")  index:" + index);
            }
            if( index != null ) {
                return index;
            }
            index = verts.size();
            if( log.isTraceEnabled() ) {
                log.trace("index:" + index);
            }
            // Have to clone the key because we reuse the verts during the loop that calls us
            verts.put(vert.clone(), index);
            out.println("v " + vert.x + " " + vert.y + " " + vert.z);
            return index;
        } else {
            out.println("v " + vert.x + " " + vert.y + " " + vert.z);
            return vertIndex++;
        }
    }

    public void write( Geometry geom ) {
        log.info("Writing geometry:" + geom);

        out.println("# Geometry:" + geom.getName());

        // Let each object have its own vertex list
        baseIndex += verts.size();
        verts.clear();

        Mesh mesh = geom.getMesh();

        // Do it the slow cheater way
        Vector3f v1 = new Vector3f();
        Vector3f v2 = new Vector3f();
        Vector3f v3 = new Vector3f();

        int count = mesh.getTriangleCount();
        for( int i = 0; i < count; i++ ) {
            mesh.getTriangle(i, v1, v2, v3);
            int index1 = writeVertex(v1) + baseIndex + 1;
            int index2 = writeVertex(v2) + baseIndex + 1;
            int index3 = writeVertex(v3) + baseIndex + 1;

            out.println("# face:" + (++faceCount) + "  verts:" + v1 + ", " + v2 + ", " + v3);
            out.println("f " + index1 + " " + index2 + " " + index3);
        }
        out.println();
    }

    public void close() throws IOException {
        out.close();
    }
}
