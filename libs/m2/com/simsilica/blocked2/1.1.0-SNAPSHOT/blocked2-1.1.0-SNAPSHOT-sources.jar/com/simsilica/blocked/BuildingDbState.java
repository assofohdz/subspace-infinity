/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.*;
import com.simsilica.lemur.style.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

// For testing stuff
//import com.simsilica.mblock.*;
//import com.simsilica.mblock.io.*;



/**
 *
 *
 *  @author    Paul Speed
 */
public class BuildingDbState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BuildingDbState.class);

    private Container window;

    private BuildingsDatabase buildingsDb;
    private ListBox<BuildingTemplate> buildingsList;

    private VersionedReference<List<BuildingTemplate>> buildingsRef;
    private VersionedList<BuildingTemplate> filteredList = new VersionedList<>();
    private BuildingFilter filter = new BuildingFilter();

    private TextField filterEditor;

    private VersionedReference<Integer> selectionRef;
    private BuildingTemplate selectedBuilding;
    private VersionedReference<BuildingTemplate> selectedBuildingRef;
    private BuildingTemplateEditor buildingEditor;

    public BuildingDbState() {        
    }

    public void createBuilding() {
        log.info("Create building");
 
        GetStringDialog dialog = new GetStringDialog("Create Building", "Name:", "", (name) -> {
                doCreate(name.trim());
            });
        dialog.show();
    }
    
    protected void doCreate( String name ) {    
        //String name = partName.getText().trim();
        if( Strings.isNullOrEmpty(name) ) {
            return;
        }
        BuildingTemplate building = buildingsDb.createBuilding(name);
        
        // Make sure the filtered list has the lastest building if it matches
        // the filter.
        resetFilteredList();
        int index = filteredList.indexOf(building);
        if( index >= 0 ) {
            buildingsList.getSelectionModel().setSelection(index);
        }
        buildingsDb.save();
        focus();
    }

    public void copyBuilding() {
        log.info("Copy building");
        if( selectedBuilding == null ) {
            return;
        }
 
        GetStringDialog dialog = new GetStringDialog("Copy Building", "Name:", "", (name) -> {
                doCopy(name.trim());
            });
        dialog.show();
    }
    
    protected void doCopy( String name ) {    
        //String name = partName.getText().trim();
        if( selectedBuilding == null ) {
            return;
        }
        if( Strings.isNullOrEmpty(name) ) {
            return;
        }
        BuildingTemplate building = buildingsDb.copyBuilding(name, selectedBuilding);
        
        // Make sure the filtered list has the lastest building if it matches
        // the filter.
        resetFilteredList();
        int index = filteredList.indexOf(building);
        if( index >= 0 ) {
            buildingsList.getSelectionModel().setSelection(index);
        }
        buildingsDb.save();
        focus();
    }
    
    protected void deleteBuilding() {
        log.info("Delete building");
        if( selectedBuilding == null ) {
            return;
        }
        getState(OptionPanelState.class).show("Delete?", 
                                              "Really delete building:" + selectedBuilding.getName() + "?", 
                                              new CallMethodAction("Yes", this, "doDeleteBuilding"),
                                              new EmptyAction("No"),
                                              new EmptyAction("Cancel"));
    }

    protected void doDeleteBuilding() {
        if( selectedBuilding == null ) {
            return;
        }
        buildingsDb.deleteBuilding(selectedBuilding);
    }
    
 
    public void focus() {
        TabbedPanel tabs = getState(ToolPanelState.class).getTabs(); 
        for( TabbedPanel.Tab tab : tabs.getTabs() ) {
            if( tab.getContents() == window ) {
                tabs.setSelectedTab(tab);
                break;
            }
        }
    }

    protected void setSelectedBuilding( BuildingTemplate building ) {
        if( building == selectedBuilding ) {
            return;
        }
        selectedBuilding = building;
        buildingEditor.setObject(building);
        if( selectedBuilding != null ) {
            selectedBuildingRef = building.createReference();
        } else {
            selectedBuildingRef = null;
        }
    }    
    
    @Override
    protected void initialize( Application app ) {
        buildingsDb = BuildingsDatabase.create(BlockEdConfig.getInstance().getStructureDbDir());
        buildingsRef = buildingsDb.getBuildings().createReference();

        window = new Container();
        getState(ToolPanelState.class).getTabs().addTab("Buildings DB", window);
        
        Container container;
        window.addChild(new Label("Buildings:"));
        container = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.First, FillMode.Last)));
        filterEditor = container.addChild(new TextField(""));
        container.addChild(new ActionButton(new CallMethodAction("Filter", this, "parseFilter")));

        //buildingsList = window.addChild(new ListBox<>(buildingsDb.getBuildings()));
        buildingsList = window.addChild(new ListBox<>(filteredList));
        buildingsList.setCellRenderer(new BuildingTemplateRenderer());
        selectionRef = buildingsList.getSelectionModel().createSelectionReference();

        Container buttons = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Create", this, "createBuilding")));
        buttons.addChild(new ActionButton(new CallMethodAction("Copy", this, "copyBuilding")));
        buttons.addChild(new ActionButton(new CallMethodAction("Delete", this, "deleteBuilding")));
        window.addChild(new ActionButton(new CallMethodAction("Test Building", this, "testBuilding")));
        window.addChild(new ActionButton(new CallMethodAction("Test Random", this, "testRandom")));
 
//log.info("partsList cell renderer:" + partsList.getCellRenderer());
//log.info("element ID:" + ((DefaultCellRenderer)partsList.getCellRenderer()).getElementId()); 
 
        container = new Container();
        window.addChild(new RollupPanel("Building:", container, null));
        
        buildingEditor = container.addChild(new BuildingTemplateEditor(getState(FloorDbState.class).getFloorTemplates()));
        
        buttons = container.addChild(new Container());
        //buttons.addChild(new ActionButton(new CallMethodAction("Test Building", this, "testBuilding")));
           
        resetFilteredList();
    }
    
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        if( buildingsRef.update() ) {
            resetFilteredList();
        }
        if( selectionRef.update() ) {
            setSelectedBuilding(buildingsList.getSelectedItem());
        }
        if( selectedBuildingRef != null && selectedBuildingRef.update() ) {
            buildingsDb.save();
            log.info("save db");
            buildingsList.getModel().add(null);
            buildingsList.getModel().remove(null);
        }
    }
    
    protected void testBuilding() throws Exception {
        if( selectedBuilding == null ) {
            return;
        }
        getState(PartDbState.class).testBuilding(selectedBuilding);
    }
    
    protected void testRandom() throws Exception {
        Random rand = new Random();
        int index = rand.nextInt(buildingsRef.get().size());
        BuildingTemplate building = buildingsRef.get().get(index);
        log.info("Testing:" + building);
        getState(PartDbState.class).testBuilding(building);
    }
    
    protected void parseFilter() {        
        String text = filterEditor.getText().trim();
        filter.clear();           
        String[] tags = text.split("\\s*,\\s*");
        for( String tag : tags ) {
            tag = tag.trim();
            if( tag.length() > 0 ) {
                if( tag.charAt(0) == '!' ) {
                    filter.exclude(tag.substring(1));
                } else {
                    filter.include(tag);
                }
            }
        }
        resetFilteredList();
    }
    
    protected void resetFilteredList() {
        BuildingTemplate selected = buildingsList.getSelectedItem();
        filteredList.clear();
        for( BuildingTemplate building : buildingsDb.getBuildings() ) {
            if( filter.apply(building) ) {
                filteredList.add(building);
            }
        }         
        int i = filteredList.indexOf(selected);
        if( i >= 0 ) {
            buildingsList.getSelectionModel().setSelection(i);
        } else {
            buildingsList.getSelectionModel().clear();
        }
    }  

    private class BuildingTemplateRenderer extends DefaultValueRenderer<BuildingTemplate> {
        public BuildingTemplateRenderer() {
            super(null, null);            
        }
 
        @Override
        protected String valueToString( BuildingTemplate building ) {
            if( building == null ) {
                return null;
            }
            String result = building.getName();
            return result;
        }
    }
    
    private class BuildingFilter implements Predicate<BuildingTemplate> {
        private Set<String> include = new HashSet<>();
        private Set<String> exclude = new HashSet<>();
    
        public void include( String tag ) {
            include.add(tag);
        }
        
        public void exclude( String tag ) {
            exclude.add(tag);
        }
    
        public void clear() {
            include.clear();
            exclude.clear();
        }

        public boolean apply( BuildingTemplate info ) {
            if( info == null ) {
                return false;
            }
            if( info.hasAny(exclude) ) {
                return false;
            }
            if( include.isEmpty() ) {
                return true;
            }
            return info.hasAll(include);
        } 
    }
    
}

