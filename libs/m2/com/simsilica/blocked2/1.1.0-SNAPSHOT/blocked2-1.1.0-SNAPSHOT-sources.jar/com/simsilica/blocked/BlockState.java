/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.nio.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.light.*;
import com.jme3.math.*;
import com.jme3.material.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.shader.VarType;
import com.jme3.texture.*;
import com.jme3.util.BufferUtils;
import com.jme3.util.TangentBinormalGenerator;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;

import com.simsilica.fx.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;
import com.simsilica.mblock.config.*;

import com.simsilica.tool.DebugNormalsState;
import com.simsilica.tool.GridState;


/**
 *
 *
 *  @author    Paul Speed
 */
public class BlockState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BlockState.class);

    private float scale = 0.25f;
    private int cellArraySize;
    private CellArray cells;
    private CellArray lightData;
    private CellArray fluidData;
    private CellData safeLightData;

    private Map<String, Material> materials;
    private GeometryFactory geomFactory;

    private Node blocks;
    private Node fluid;
    private float localLight = 1;

    private boolean smoothLighting = true;

    private boolean showWireFrame;

    private boolean invalid = true;

    // For now, in lieu of an undo stack, we'll at least keep track of
    // how many changes since the last reset
    private int changeCount;

    public BlockState() {
        this(10);
    }

    public BlockState( int gridSize ) {
        this.cellArraySize = gridSize * 4;
        this.cells = new CellArray(cellArraySize);
        this.lightData = new CellArray(cellArraySize);
        this.fluidData = new CellArray(cellArraySize);
        this.safeLightData = new SafeCellData(lightData, LightUtils.DIRECT_SUN);
        clearBlocks();
    }

    public void setWireFrame( boolean showWireFrame ) {
        if( this.showWireFrame == showWireFrame ) {
            return;
        }
        this.showWireFrame = showWireFrame;
        for( Material m : materials.values() ) {
            m.getAdditionalRenderState().setWireframe(showWireFrame);
        }
    }

    public boolean getWireFrame() {
        return showWireFrame;
    }

    public void setLocalLight( float localLight ) {
        this.localLight = localLight;
        if( blocks != null ) {
            MatParamOverride mo = new MatParamOverride(VarType.Float, "LocalLightStrength", localLight);
            blocks.addMatParamOverride(mo);
            fluid.addMatParamOverride(mo);
        }
    }

    public float getLocalLight() {
        return localLight;
    }

    public void drawCircle() {
        double radius = cellArraySize*0.5;
        drawCircle(new Vec3d(radius, 0, radius), radius - 0.5);
        drawCircle(new Vec3d(radius, 0, radius), radius - 2.5);
        drawCircle(new Vec3d(radius, 0, radius), radius - 5.5);
        drawCircle(new Vec3d(radius, 0, radius), radius - 9.5);
    }

    public void drawCircle( Vec3d loc, double radius ) {
        System.out.println("drawCircle(" + loc + ", " + radius + ")");
        // We'll do it the stupid way because I want it centered in the
        // square and I'm not willing to throw away time on adapting
        // Bresenham's circle drawing algorithm to support mid-pixel
        // coordinates.
        double aDelta = 1;  // 1 degree should be MORE than small enough
        for( double a = 0; a < 360; a++ ) {
            double rads = Math.toRadians(a);
            double x = Math.cos(rads) * radius;
            double y = Math.sin(rads) * radius;
            int xi = (int)Math.floor(Math.round(loc.x + x - 0.5));
            int yi = (int)Math.floor(Math.round(loc.z + y - 0.5));
            cells.setCell(xi, 0, yi, 1);
        }

        MaskUtils.calculateSideMasks(cells);
        FluidUtils.calculateSideMasks(fluidData, cells);
        //FluidUtils.calculateFluidSlopes(fluidData, cells);
        invalidate();
        changeCount++;
    }

    public Spatial getBlocksSpatial() {
        return blocks;
    }

    public Spatial getFluidSpatial() {
        return fluid;
    }

    // Really just provided for save/load support to have access
    public CellArray getCells() {
        return cells;
    }

    public CellArray getFluidData() {
        return fluidData;
    }

    public int getChangeCount() {
        return changeCount;
    }

    public void resetChangeCount() {
        changeCount = 0;
    }

    public void invalidate() {
        invalid = true;
    }

    public Vector3f getWorldPosition( Vec3i loc ) {
        Vector3f pos = new Vector3f(loc.x + 0.5f, loc.y + 0.5f, loc.z + 0.5f);
        return blocks.localToWorld(pos, null);
    }

    public Vec3i getEmptyLocation( Vector3f worldPos, Vector3f normal ) {
        Vector3f local = blocks.worldToLocal(worldPos, null);
        Vec3i result = new Vec3i((int)local.x, (int)local.y, (int)local.z);

        // If there is a block there then we need to move along the normal
        if( cells.getCell(result.x, result.y, result.z, 0) != 0 ) {
            result.x += (int)normal.x;
            result.y += (int)normal.y;
            result.z += (int)normal.z;
        } else if( fluidData.getCell(result.x, result.y, result.z, 0) != 0 ) {
            result.x += (int)normal.x;
            result.y += (int)normal.y;
            result.z += (int)normal.z;
        }

        return result;
    }

    public Vec3i getBlockLocation( Vector3f worldPos, Vector3f normal ) {
        Vector3f local = blocks.worldToLocal(worldPos, null);
        Vec3i result = new Vec3i((int)local.x, (int)local.y, (int)local.z);

        // If there is a block there then we need to move along the normal
        if( cells.getCell(result.x, result.y, result.z, -1) == 0 ) {
            result.x -= (int)normal.x;
            result.y -= (int)normal.y;
            result.z -= (int)normal.z;
        } else if( fluidData.getCell(result.x, result.y, result.z, 0) != 0 ) {
            result.x += (int)normal.x;
            result.y += (int)normal.y;
            result.z += (int)normal.z;
        }

        return result;
    }

    public void setBlock( Vec3i loc, int value ) {
log.info("setBlock(" + loc + ", " + value + ")");
        int existing = MaskUtils.getType(cells.getCell(loc.x, loc.y, loc.z, -1));
        // Note: this only works because (today) masked cell values won't
        // ever set the sign bit.
log.info("existing:" + existing);
        if( existing < 0 || existing == value ) {
            return;
        }

        cells.setCell(loc.x, loc.y, loc.z, value);

        // The above is not working right now... and the below is fast enough in
        // this context so we'll use it until I can investigate further.
        // 2021-01-31 - Reading this comment, I think I took out the single block
        //              mask call at some point because it wasn't working.
        MaskUtils.calculateSideMasks(cells);

        // See if the block is solid and if so then we need to
        // clear any fluids here also.
        BlockType type = BlockTypeIndex.get(value);
        if( type != null && type.isSolid() ) {
            // Note: it's ok if it someday turns out that 'isSolid'
            // doesn't really mean solid-solid with respect to fluids.
            // This is good enough and will cover most cases and it's
            // not that hard to put the fluid back.
            fluidData.setCell(loc.x, loc.y, loc.z, 0);
        }

        // Changing a block might change fluid masks, too.
        FluidUtils.calculateSideMasks(fluidData, cells);
        //FluidUtils.calculateFluidSlopes(fluidData, cells);
        invalidate();
        changeCount++;
    }

    public int getBlock( Vec3i loc ) {
        return cells.getCell(loc.x, loc.y, loc.z, -1);
    }

    public void setFluid( Vec3i loc, int value ) {
log.info("setFluid(" + loc + ", " + value + ")");
        // Fluids can be negative and still be valid because of the
        // way their masks are built.  We'll use the 'value' as the default
        // and kill two birds with one stone.  If the location is outside
        // of the bounds then it will look like it's already set to the value
        // we want.
        int existing = fluidData.getCell(loc.x, loc.y, loc.z, value);
        if( existing == value ) {
            return;
        }

        fluidData.setCell(loc.x, loc.y, loc.z, value);

        FluidUtils.calculateSideMasks(fluidData, cells);
        //FluidUtils.calculateFluidSlopes(fluidData, cells);

        invalidate();
        changeCount++;
    }

    public int getFluid( Vec3i loc ) {
        return fluidData.getCell(loc.x, loc.y, loc.z, -1);
    }

    private int toLight( int sun, int r, int g, int b ) {
        return (sun << 12) | (r << 8) | (g << 4) | b;
    }

    public void clearAll() {
        cells.clear();
        fluidData.clear();
        lightData.clear(toLight(15, 0, 0, 0));
        resetChangeCount();
        invalidate();
    }

    public void clearBlocks() {
        cells.clear();
        lightData.clear(toLight(15, 0, 0, 0));
        resetChangeCount();
        invalidate();
    }

    public void clearFluids() {
        fluidData.clear();
        lightData.clear(toLight(15, 0, 0, 0));
        resetChangeCount();
        invalidate();
    }

    protected void loadFiles( AssetManager assets ) throws IOException {
        File bFile = BlockEdConfig.getInstance().getBlocksFile();
        File fFile = BlockEdConfig.getInstance().getFluidsFile();
        File mFile = BlockEdConfig.getInstance().getMaterialsFile();

        try( InputStream in = new FileInputStream(bFile) ) {
            BlockTypeIndex.load(in);
        }

        try( InputStream in = new FileInputStream(fFile) ) {
            FluidTypeIndex.load(in);
        }

        try( InputStream in = new FileInputStream(mFile) ) {
            this.materials = MaterialRegistry.loadCompiledMaterials(assets, in);
        }

        // Add some custom stuff just for blocked.
//        Material water = materials.get("
log.info("material keys:" + materials.keySet());
        MaterialType waterType = new MaterialType("water", GeomReq.IndexedNormals);
        Material water = materials.get(waterType.getId());
log.info("water:" + water);
        if( water != null ) {
            // Then we will use it as the basis for our keep and required
            // blocks.
            MaterialType keepType = new MaterialType("keep", GeomReq.IndexedNormals);
            MaterialType requiredType = new MaterialType("required", GeomReq.IndexedNormals);
            Material keep = water.clone();
            keep.setColor("Diffuse", new ColorRGBA(0, 1, 0, 0.5f));
            keep.setColor("Ambient", new ColorRGBA(0, 1, 0.5f, 0.5f));
            materials.put(keepType.getId(), keep);

            Material required = water.clone();
            required.setColor("Diffuse", new ColorRGBA(1, 0, 0, 0.5f));
            required.setColor("Ambient", new ColorRGBA(1, 0, 0.5f, 0.5f));
            materials.put(requiredType.getId(), required);

            FluidType keepFluid = new FluidType(new FluidName("keep"), new LiquidFactory(keepType));
            FluidType requiredFluid = new FluidType(new FluidName("required"), new LiquidFactory(requiredType));

            FluidType[] types = FluidTypeIndex.getTypes();
            FluidType[] newTypes = new FluidType[types.length + 2];
            System.arraycopy(types, 0, newTypes, 0, types.length);
            newTypes[types.length] = keepFluid;
            newTypes[types.length+1] = requiredFluid;
            FluidTypeIndex.reset();
            FluidTypeIndex.initialize(newTypes);
        }

    }

    @Override
    protected void initialize( Application app ) {

        try {
            loadFiles(app.getAssetManager());
        } catch( IOException e ) {
            throw new RuntimeException("Error loading binaries", e);
        }

        this.geomFactory = new GeometryFactory(materials);


        MaskUtils.calculateSideMasks(cells, cellArraySize);
        FluidUtils.calculateSideMasks(fluidData, cells);
        FluidUtils.calculateFluidSlopes(fluidData, cells);

        blocks = new Node("blocks");
        blocks.setShadowMode(ShadowMode.CastAndReceive);
        blocks.setLocalScale(0.25f);
        blocks.detachAllChildren();
        float move = cellArraySize * 0.5f * 0.25f;
        blocks.move(-move, 0, -move);
        geomFactory.generateBlocks(blocks, cells, safeLightData, smoothLighting);

        fluid = new Node("fluid");
        fluid.setShadowMode(ShadowMode.CastAndReceive);
        fluid.setLocalScale(0.25f);
        fluid.detachAllChildren();
        fluid.move(-move, 0, -move);
        geomFactory.generateFluid(fluid, fluidData, cells, safeLightData, smoothLighting);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getState(GridState.class).getGrid().attachChild(blocks);
        getState(GridState.class).getGrid().attachChild(fluid);
    }

    @Override
    public void update( float tpf ) {
        if( invalid ) {
            invalid = false;
            FluidUtils.calculateFluidSlopes(fluidData, cells);
            recalculateLighting(cells, lightData, cellArraySize);
            geomFactory.generateBlocks(blocks, cells, safeLightData, smoothLighting);
            geomFactory.generateFluid(fluid, fluidData, cells, safeLightData, smoothLighting);
            updateDebug();
        }
    }

    @Override
    protected void onDisable() {
        blocks.removeFromParent();
        fluid.removeFromParent();
    }

    protected void recalculateLighting( CellArray cells, CellArray lights, int size ) {
        //log.info("recalculateLighting()");
        long start = System.nanoTime();
        LightUtils.recalculateLighting(cells, lights, size);
        long end = System.nanoTime();
        log.info("Recalculated lighting in " + ((end-start)/1000000.0) + " ms");
    }

    protected void updateDebug() {
        getState(DebugNormalsState.class).updateNormalsDebug(blocks);
        getState(DebugNormalsState.class).updateNormalsDebug(fluid);
        getState(DebugLightValuesState.class).updateLightData(blocks, cells, lightData, cellArraySize);
    }

}
