/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.lemur.core.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SlotTemplate implements VersionedObject<SlotTemplate> {
    static Logger log = LoggerFactory.getLogger(SlotTemplate.class);
    
    private long version;
    private TagPredicate tagRules = new TagPredicate();
    private EnumSet<PartTransform> transforms = EnumSet.noneOf(PartTransform.class);
    
    public SlotTemplate() {
    }

    public SlotTemplate clone() {
        SlotTemplate result = new SlotTemplate();
        result.tagRules.set(tagRules);
        result.transforms.addAll(transforms);
        return result;
    }
    
    public void clear() {
        tagRules.clear();
        transforms.clear();
    }

    public void invalidate() {
        version++;
    }

    @Override
    public long getVersion() {
        return version + tagRules.getVersion();
    }
    
    @Override
    public SlotTemplate getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<SlotTemplate> createReference() {
        return new VersionedReference<>(this);
    }
    
    public void set( SlotTemplate slot ) {
        if( this == slot ) {
            return;
        }
        tagRules.set(slot.tagRules);
        transforms.clear();
        transforms.addAll(slot.transforms);
        version++;
    }
 
    public SlotTemplate requires( String... tags ) {
        tagRules.getRequiredTags().addAll(Arrays.asList(tags));
        version++;
        return this;
    }

    public SlotTemplate rejects( String... tags ) {
        tagRules.getRejectedTags().addAll(Arrays.asList(tags));
        version++;
        return this;
    }
    
    public SlotTemplate transforms( PartTransform... transforms ) {
        for( PartTransform xform : transforms ) {
            this.transforms.add(xform);
        }
        version++;
        return this;
    }

    public SlotTemplate transforms( Set<PartTransform> transforms ) {
        this.transforms.addAll(transforms);
        version++;
        return this;
    }
    
    public TagPredicate getTagRules() {
        return tagRules;
    }
    
    public Set<PartTransform> getTransforms() {
        return transforms;
    }
    
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("tagRules", tagRules)
                .add("transforms", transforms)
                .toString();
    }
}

