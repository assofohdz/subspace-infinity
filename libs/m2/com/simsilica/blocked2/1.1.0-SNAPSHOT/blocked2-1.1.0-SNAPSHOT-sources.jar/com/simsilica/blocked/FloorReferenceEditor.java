/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Strings;

import com.jme3.math.*;
import com.jme3.texture.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FloorReferenceEditor extends Container {
    static Logger log = LoggerFactory.getLogger(FloorReferenceEditor.class);
    
    private FloorReference floor;
    private VersionedReference<FloorReference> floorRef;

    private Selector<FloorTemplate> templateSelector;
    private VersionedReference<FloorTemplate> templateRef;
        
    private Vec3iEditor offsetEditor;
    private VersionedReference<Vec3i> offsetRef;
 
    private ListBox<String> minList;
    private ListBox<String> maxList;
     
    private VersionedList<FloorTemplate> floorTemplates;
    
    public FloorReferenceEditor( VersionedList<FloorTemplate> floorTemplates ) { 
        this.floorTemplates = floorTemplates;
 
        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("Floor:"));
        templateSelector = properties.addChild(new Selector<>(floorTemplates, new BuildingTemplateEditor.FloorTemplateRenderer()), 1);
        templateRef = templateSelector.createSelectedItemReference();

        properties.addChild(new Label("Offset:"));
        offsetEditor = properties.addChild(new Vec3iEditor(true, true, true), 1);
        offsetRef = offsetEditor.createReference();
 
        Container sub = addChild(new Container());
    
        Container left = sub.addChild(new Container());
        Container right = sub.addChild(new Container(), 1);
 
        Container buttons;
 
        left.addChild(new Label("Min:"));
        minList = left.addChild(new ListBox());
        buttons = left.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Add", this, "addMin")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeMin")));
                
        right.addChild(new Label("Max:"));        
        maxList = right.addChild(new ListBox());
        buttons = right.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Add", this, "addMax")));
        buttons.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeMax")));
        
        refreshEditor();
    }
 
    public void setObject( FloorReference floor ) {
        if( floor == null ) {
            floorRef = null;
        } else {
            floorRef = floor.createReference();
        }
        this.floor = floor;
        refreshEditor();
    }
    
    public FloorReference getObject() {
        return floor;
    }
 
    @Override   
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( floorRef != null && floorRef.update() ) {
            refreshEditor();
        }
        if( floor != null ) {
            if( templateRef.update() && templateRef.get() != null ) {
                floor.setFloor(templateRef.get().getName());
            }
            if( offsetRef.update() ) {
                floor.setOffset(offsetRef.get());
            }
        }
    }
    
    protected void doAdd( List<String> target, String tags ) {
        String[] array = tags.split("\\s*,\\s*");
        if( array.length == 0 ) {
            return;
        }
        for( String tag : array ) {
            if( Strings.isNullOrEmpty(tag) ) {
                continue;
            }
            int index = Collections.binarySearch(target, tag);
            if( index < 0 ) {
                index = -(index + 1);
            }
            target.add(index, tag);
        }    
    }    

    protected void addMin() {
        if( floor == null ) {
            return;
        }
        GetStringDialog dialog = new GetStringDialog("Add Min Tags", "Tags:", "", (tags) -> {
                doAdd(floor.getMinimumTags(), tags);
            });
        dialog.show();
    }
    
    protected void removeMin() {
        if( floor == null ) {
            return;
        }
        String selected = minList.getSelectedItem();
        floor.getMinimumTags().remove(selected);
    }
    
    protected void addMax() {
        if( floor == null ) {
            return;
        }
        GetStringDialog dialog = new GetStringDialog("Add Max Tags", "Tags:", "", (tags) -> {
                doAdd(floor.getMaximumTags(), tags);
            });
        dialog.show();
    }
    
    protected void removeMax() {
        if( floor == null ) {
            return;
        }
        String selected = maxList.getSelectedItem();
        floor.getMaximumTags().remove(selected);
    }

    public FloorTemplate findTemplate( String name ) {
        for( FloorTemplate floor : floorTemplates ) {
            if( Objects.equals(floor.getName(), name) ) {
                return floor;
            }
        }
        return null;
    }
    
    protected void refreshEditor() {
        if( floor != null ) {
            FloorTemplate template = findTemplate(floor.getFloor());
            templateSelector.setSelectedItem(template);
            offsetEditor.setObject(floor.getOffset());
            minList.setModel(floor.getMinimumTags());
            maxList.setModel(floor.getMaximumTags());
        } else {
            templateSelector.setSelectedItem(null);
            minList.setModel(null);
            maxList.setModel(null);
        }
    }
        
}


