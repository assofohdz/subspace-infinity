/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.core.*;

import com.simsilica.mgen.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BuildingTemplate implements TaggedObject, VersionedObject<BuildingTemplate> {
    static Logger log = LoggerFactory.getLogger(BuildingTemplate.class);

    private String name;
    private SortedSet<String> tags = new TreeSet<>();
    private TagPredicate tagRules = new TagPredicate();
    private VersionedList<FloorReference> floors = new VersionedList<>();
    private long version;
    
    public BuildingTemplate( String name ) {
        this.name = name;
    }
 
    public void upgrade() {
    }
    
    public BuildingTemplate copy( String name ) {
        BuildingTemplate result = new BuildingTemplate(name);
        result.tags = new TreeSet<>(tags);
        result.tagRules.set(tagRules);
        for( FloorReference floor : floors ) {
            result.floors.add(floor.clone());
        }
        return result;
    }
    
    public void setName( String name ) {
        if( Objects.equals(this.name, name) ) {
            return;
        }
        this.name = name;
        version++;
    }
    
    public String getName() {
        return name;
    }
    
    public TagPredicate getTagRules() {
        return tagRules;
    }
    
    public void addFloor( FloorReference floor ) {
        if( floors.add(floor) ) {
            version++;
        }
    }

    public void removeFloor( FloorReference floor ) {
        if( floors.remove(floor) ) {
            version++;
        }
    }
    
    public VersionedList<FloorReference> getFloors() {
        return floors;
    }
    
    public boolean addTag( String tag ) {
        if( tags.add(tag) ) {
            version++;
            return true;
        }
        return false;
    }
 
    public boolean removeTag( String tag ) {
        if( tags.remove(tag) ) {
            version++;
            return true;
        }
        return false;
    }
    
    @Override
    public Set<String> getTags() {
        return tags;
    }
 
    @Override
    public boolean hasTag( String tag ) {
        return tags.contains(tag);
    }
 
    @Override   
    public boolean hasAny( Iterable<String> any ) {
        for( String s : any ) {
            if( tags.contains(s) ) {
                return true;
            }
        }
        return false; 
    }

    @Override
    public boolean hasAll( Collection<String> all ) {
        return tags.containsAll(all);
    }
    
    public void invalidate() {
        log.info("invalidate()");
        version++;
    }
 
    public BuildingGenerator createGenerator( Map<String, FloorTemplate> floorTemplates, Iterable<StructurePartInfo> sourceParts, PartIndex index ) {
   
        // Build a list of the parts available for this building
        // (could have also made a filtered iterable instead of copying)
        List<StructurePartInfo> parts = new ArrayList<>();
        for( StructurePartInfo info : sourceParts ) {
            if( tagRules.apply(info.getTags()) ) {
                parts.add(info);
            }
        }
 
        // Build the floor generator list 
        FloorGenerator[] generators = new FloorGenerator[floors.size()];
        for( int i = 0; i < generators.length; i++ ) {
            FloorReference ref = floors.get(i);
            FloorTemplate template = floorTemplates.get(ref.getFloor());
            if( template == null ) {
                log.warn("No floor template found for:" + ref.getFloor());
                continue;
            }
            generators[i] = template.createGenerator(ref, parts, index);
        }

        return new BuildingGenerator(tags, generators);
    } 
 
    @Override
    public long getVersion() {
        return version + tagRules.getVersion() + floors.getVersion();
    }
    
    @Override
    public BuildingTemplate getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<BuildingTemplate> createReference() {
        return new VersionedReference<>(this);
    }    
    
    @Override
    public String toString() {
        return "BuildingTemplate[name:" + name + "]";
    }
}

