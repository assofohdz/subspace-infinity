/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.lemur.core.*;

import com.simsilica.mgen.FloorGenerator;
import com.simsilica.mgen.Part;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FloorTemplate implements TaggedObject, VersionedObject<FloorTemplate> {
    static Logger log = LoggerFactory.getLogger(FloorTemplate.class);

    private String name;
    private SortedSet<String> tags = new TreeSet<>();
    private int xSize;
    private int zSize;
    private int floorHeight = 3;
    private int gridSpacing = 4;
    private TagPredicate tagRules = new TagPredicate();
    private SlotTemplate[][] slots;
    private long version;

    public FloorTemplate( String name, int xSize, int zSize ) {
        this.name = name;
        this.xSize = xSize;
        this.zSize = zSize;
        this.slots = new SlotTemplate[xSize][zSize];
    }

    public void upgrade() {
        if( gridSpacing == 0 ) {
            gridSpacing = 4;
        }
    }

    public FloorTemplate copy( String name ) {
        FloorTemplate result = new FloorTemplate(name, xSize, zSize);
        result.floorHeight = floorHeight;
        result.gridSpacing = gridSpacing;
        result.tagRules.set(tagRules);
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                if( slots[i][j] != null ) {
                    result.slots[i][j] = new SlotTemplate();
                    result.slots[i][j].set(slots[i][j]);
                }
            }
        }
        return result;
    }

    public void resize( int xNewSize, int zNewSize ) {
        // Just do it the dumb way for now
        SlotTemplate[][] newSlots = new SlotTemplate[xNewSize][zNewSize];
        for( int i = 0; i < Math.min(xSize, xNewSize); i++ ) {
            for( int j = 0; j < Math.min(zSize, zNewSize); j++ ) {
                newSlots[i][j] = slots[i][j];
            }
        }
        this.xSize = xNewSize;
        this.zSize = zNewSize;
        this.slots = newSlots;
        version++;
    }

    public void setName( String name ) {
        if( Objects.equals(this.name, name) ) {
            return;
        }
        this.name = name;
        version++;
    }

    public String getName() {
        return name;
    }

    public boolean addTag( String tag ) {
        if( tags.add(tag) ) {
            version++;
            return true;
        }
        return false;
    }

    public boolean removeTag( String tag ) {
        if( tags.remove(tag) ) {
            version++;
            return true;
        }
        return false;
    }

    @Override
    public Set<String> getTags() {
        return tags;
    }

    @Override
    public boolean hasTag( String tag ) {
        return tags.contains(tag);
    }

    @Override
    public boolean hasAny( Iterable<String> any ) {
        for( String s : any ) {
            if( tags.contains(s) ) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean hasAll( Collection<String> all ) {
        return tags.containsAll(all);
    }

    public void setSizeX( int xSize ) {
        if( this.xSize == xSize ) {
            return;
        }
        this.xSize = xSize;
        version++;
    }

    public int getSizeX() {
        return xSize;
    }

    public void setSizeZ( int zSize ) {
        if( this.zSize == zSize ) {
            return;
        }
        this.zSize = zSize;
        version++;
    }

    public int getSizeZ() {
        return zSize;
    }

    public void setFloorHeight( int floorHeight ) {
        if( this.floorHeight == floorHeight ) {
            return;
        }
        this.floorHeight = floorHeight;
        version++;
    }

    public int getFloorHeight() {
        return floorHeight;
    }

    public void setGridSpacing( int gridSpacing ) {
        if( this.gridSpacing == gridSpacing ) {
            return;
        }
        this.gridSpacing = gridSpacing;
        version++;
    }

    public int getGridSpacing() {
        return gridSpacing;
    }

    public TagPredicate getTagRules() {
        return tagRules;
    }

    public SlotTemplate getSlot( int x, int z ) {
        return slots[x][z];
    }

    public SlotTemplate getSlot( int x, int z, boolean create ) {
        if( slots[x][z] == null ) {
            slots[x][z] = new SlotTemplate();
        }
        return slots[x][z];
    }

    /**
     *  Goes through all of the supplied parts and if they match the
     *  floor's tag rules then they are applied to the slots where the
     *  transforms and tag rules match.
     */
    public FloorGenerator createGenerator( FloorReference reference, Iterable<StructurePartInfo> sourceParts, PartIndex index ) {
        FloorGenerator result = new FloorGenerator(xSize, zSize, reference.getOffset(), floorHeight, gridSpacing,
                                                   reference.getMinimumTags(),
                                                   reference.getMaximumTags());

        int xOffset = reference.getOffset().x;
        int zOffset = reference.getOffset().z;

        for( StructurePartInfo info : sourceParts ) {
            if( !tagRules.apply(info.getTags()) ) {
                continue;
            }
            Map<PartTransform, Part> transforms = index.getTransforms(info);
            for( int i = 0; i < xSize; i++ ) {
                for( int j = 0; j < zSize; j++ ) {
                    SlotTemplate slot = slots[i][j];
                    if( slot == null ) {
                        continue;
                    }
                    if( !slot.getTagRules().apply(info.getTags()) ) {
                        continue;
                    }
                    for( int count = 0; count < info.getFrequency(); count++ ) {
                        for( PartTransform xform : slot.getTransforms() ) {
                            //result.addPart(xOffset + i, zOffset + j, transforms.get(xform));
                            result.addPart(i, j, transforms.get(xform));
                        }
                    }
                }
            }
        }
        return result;
    }

    public void invalidate() {
        version++;
    }

    @Override
    public long getVersion() {
        return version + tagRules.getVersion();
    }

    @Override
    public FloorTemplate getObject() {
        return this;
    }

    @Override
    public VersionedReference<FloorTemplate> createReference() {
        return new VersionedReference<>(this);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("name", name)
                .add("xSize", xSize)
                .add("zSize", zSize)
                .add("tags", tags)
                .add("floorHeight", floorHeight)
                .add("tagRules", tagRules)
                .toString();
    }
}


