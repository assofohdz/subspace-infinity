/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.io.Files;
import com.google.gson.*;

import com.simsilica.lemur.core.*;

import com.simsilica.mathd.*;

import com.simsilica.mgen.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.io.*;

/**
 *  Main entry point for managing a parts database.
 *
 *  @author    Paul Speed
 */
public class PartsDatabase {
    static Logger log = LoggerFactory.getLogger(PartsDatabase.class);
    
    private transient File rootDir;
    private transient File partsDir;
    private VersionedList<StructurePartInfo> parts = new VersionedList<>();
    
    protected PartsDatabase( File rootDir ) {
        this.rootDir = rootDir;
        rootDir.mkdirs();
    }
    
    protected void upgrade() {
        for( StructurePartInfo part : parts ) {
            part.upgrade();
        }
    }
 
    public static PartsDatabase create( File rootDir ) {
        PartsDatabase result = null;
        File index = new File(rootDir, "parts.index");
        if( index.exists() ) {
            GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
            Gson gson = gsonBuilder.create();
            try {
                String json = Files.toString(index, Charsets.UTF_8);
                result = gson.fromJson(json, PartsDatabase.class);
                result.rootDir = rootDir;
                result.partsDir = new File(rootDir, "parts");
                result.upgrade();
            } catch( IOException e ) {
                throw new RuntimeException("Error loading:" + index, e);
            }
        } else {
            result = new PartsDatabase(rootDir);
            result.save();
        }
        return result;
    } 
 
    public void save() {
        log.info("Saving.");
        File index = new File(rootDir, "parts.index");
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + index);
            String json = gson.toJson(this);
            Files.write(json, index, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + index, e);
        }        
    }
 
    public StructurePartInfo createPart( String... tags ) {
        StringBuilder sb = new StringBuilder();
        for( String s : tags ) {
            if( Strings.isNullOrEmpty(s) ) {
                continue;
            }
            if( sb.length() > 0 ) {
                sb.append(",");
            }
            sb.append(s);
        }
        String baseName = sb.toString();        
        String fileName = baseName + "-" + System.currentTimeMillis();
        StructurePartInfo part = new StructurePartInfo(fileName, tags);
        parts.add(part);
        return part; 
    }
    
    public File getPartFile( StructurePartInfo info ) {
        return new File(partsDir, info.getBlocksFile() + ".blocks");
    }
    
    public VersionedList<StructurePartInfo> getParts() {
        return parts;
    }
 
    public Part loadPart( StructurePartInfo info ) throws IOException {
        File f = getPartFile(info);
        FileInputStream fIn = new FileInputStream(f); 
        BlockObject blocks = BlocksFileFormat.readBlocks(fIn, true);       
 
        log.info("Read:" + blocks.cells);
         
        // Just write out the variations to see that it's working
        Vec3i offset = blocks.cells.getSize().subtract(info.getGridSize());
        offset.y = 0;
        
        //return new Part(info, blocks.cells, offset);
        return info.createPart(blocks.cells, offset);
    }
           
}



