/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class TagPredicateEditor extends Container {
    static Logger log = LoggerFactory.getLogger(TagPredicateEditor.class);
    
    private TagPredicate tagRules;
    private VersionedReference<TagPredicate> tagRulesRef;     
    
    private TagSetButton requiresButton;
    private VersionedReference<Set<String>> requiresRef;
    private TagSetButton rejectsButton;
    private VersionedReference<Set<String>> rejectsRef;
    
    public TagPredicateEditor() {
        super(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last));
        addChild(new Label("Requires:"));
        requiresButton = addChild(new TagSetButton(new TreeSet<>()), 1);
        requiresRef = requiresButton.createReference();
        addChild(new Label("Rejects:"));
        rejectsButton = addChild(new TagSetButton(new TreeSet<>()), 1);
        rejectsRef = rejectsButton.createReference();
    }
    
    public void setObject( TagPredicate tagRules ) {
        if( tagRules == null ) {
            tagRulesRef = null;
        } else {
            tagRulesRef = tagRules.createReference();
        }
        this.tagRules = tagRules;        
        refreshEditor();
    }
    
    public TagPredicate getObject() {
        return tagRules;
    }
     
    @Override   
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( requiresRef.update() ) {
            if( tagRules != null ) {
                tagRules.setRequiredTags(requiresRef.get());
            }
        }
        if( rejectsRef.update() ) {
            if( tagRules != null ) {
                tagRules.setRejectedTags(rejectsRef.get());
            }
        }
        if( tagRulesRef != null && tagRulesRef.update() ) {
            refreshEditor();
        }
    }    
    
    protected void refreshEditor() {
        if( tagRules != null ) {
            requiresButton.setTags(new TreeSet<>(tagRules.getRequiredTags()));
            rejectsButton.setTags(new TreeSet<>(tagRules.getRejectedTags()));
        }
    }

}
