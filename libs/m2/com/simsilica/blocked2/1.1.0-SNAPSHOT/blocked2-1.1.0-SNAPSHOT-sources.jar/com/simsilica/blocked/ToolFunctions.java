/*
 * $Id$
 * 
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.blocked;

import com.jme3.input.KeyInput;
import com.simsilica.lemur.input.Axis;
import com.simsilica.lemur.input.Button;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.input.InputState;


/**
 *  Defines a set of global game functions and some default key/control
 *  mappings.
 *
 *  @author    Paul Speed
 */
public class ToolFunctions {

    public static final String TOOL = "Tool";
    public static final FunctionId F_SUBTOOL = new FunctionId(TOOL, "Subtool");
    public static final FunctionId F_PICK = new FunctionId(TOOL, "Pick");
        
    public static void initializeDefaultMappings( InputMapper inputMapper ) {
 
        inputMapper.map(F_SUBTOOL, InputState.Negative, KeyInput.KEY_COMMA);        
        inputMapper.map(F_SUBTOOL, KeyInput.KEY_PERIOD);
        inputMapper.map(F_SUBTOOL, Axis.MOUSE_WHEEL);        
        
        inputMapper.map(F_PICK, KeyInput.KEY_C);        
    }
}
