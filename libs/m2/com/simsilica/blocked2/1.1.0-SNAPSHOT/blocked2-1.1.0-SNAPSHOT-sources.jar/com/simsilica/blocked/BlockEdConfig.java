/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;
import com.google.gson.*;


/**
 *  Config settings for the BlockEd tool.
 *
 *  @author    Paul Speed
 */
public class BlockEdConfig {

    public static final String CONFIG_FILE = "blocked.config";
    public static final String DEFAULT_PROJECT_DIR = ".";
    public static final String DEFAULT_OUTPUT_DIR = "blocks-files";
    public static final String DEFAULT_EXPORT_DIR = "exports";
    public static final String DEFAULT_BLOCKS_FILE = "blocks.bset";
    public static final String DEFAULT_FLUIDS_FILE = "fluids.fset";
    public static final String DEFAULT_MATERIALS_FILE = "materials.mset";
    public static final String DEFAULT_STRUCTURE_DB = "structure.db";
    public static final String DEFAULT_SCRIPT_DIR = "scripts";

    static Logger log = LoggerFactory.getLogger(BlockEdConfig.class);

    private String projectDir;
    private String blocksFile;
    private String fluidsFile;
    private String materialsFile;
    private String outputDir;
    private String exportDir;
    private String structureDb;
    private List<String> startupScripts;
    private String scriptDir;
    
    private Map<String, Object> startupSettings;

    private static BlockEdConfig instance;

    public BlockEdConfig() {
    }

    protected void initializeDefaults() {
        this.projectDir = DEFAULT_PROJECT_DIR;
        this.blocksFile = DEFAULT_BLOCKS_FILE;
        this.fluidsFile = DEFAULT_FLUIDS_FILE;
        this.materialsFile = DEFAULT_MATERIALS_FILE;
        this.outputDir = DEFAULT_OUTPUT_DIR;
        this.structureDb = DEFAULT_STRUCTURE_DB;
        this.scriptDir = DEFAULT_SCRIPT_DIR;
        this.startupSettings = new HashMap<>();
    }
    
    protected boolean upgrade() {
        boolean changed = false;
        if( fluidsFile == null ) {
            fluidsFile = DEFAULT_FLUIDS_FILE;
            changed = true;
        }
        if( structureDb == null ) {
            structureDb = DEFAULT_STRUCTURE_DB;
            changed = true;
        }
        if( scriptDir == null ) {
            scriptDir = DEFAULT_SCRIPT_DIR;
            changed = true;
        }
        if( startupSettings == null ) {
            this.startupSettings = new HashMap<>();
            changed = true;
        }
        return changed;
    }

    public File getProjectDir() {
        return new File(projectDir);
    }

    public File getScriptsDir() {
        return new File(projectDir, scriptDir);
    }

    public File getBlocksFile() {
        return new File(projectDir + "/" + blocksFile);
    }

    public File getFluidsFile() {
        return new File(projectDir + "/" + fluidsFile);
    }

    public File getMaterialsFile() {
        return new File(projectDir + "/" + materialsFile);
    }

    public File getOutputDir() {
        return new File(projectDir + "/" + outputDir);
    }

    public File getExportDir() {
        return new File(projectDir + "/" + exportDir);
    }

    public File getStructureDbDir() {
        return new File(projectDir + "/" + structureDb);
    }

    public String getStructureDb() {
        return structureDb;
    }

    public Iterable<String> getStartupScripts() {
        return startupScripts == null ? Collections.emptyList() : startupScripts;
    }

    @SuppressWarnings("unchecked")   
    public <T> T getStartupSetting( String key, T defaultValue ) {
        if( startupSettings.containsKey(key) ) {
            return (T)startupSettings.get(key);
        }
        return defaultValue;
    }

    public int getStartupSettingInt( String key, int defaultValue ) {
        if( !startupSettings.containsKey(key) ) {
            return defaultValue;
        }
        Number result = getStartupSetting(key, null);
        if( result == null ) {
            return defaultValue;
        }
        return result.intValue();
    }

    public Map<String, Object> getStartupSettings() {
        return startupSettings;
    }

    public static BlockEdConfig getInstance() {
        if( instance == null ) {
            try {
                instance = load(new File(CONFIG_FILE));
                if( instance.upgrade() ) {
                    store(instance, new File(CONFIG_FILE));
                }
            } catch( Exception e ) {
                log.error("Error loading config file.  Initializing defaults", e);
            }
        }
        if( instance == null ) {
            instance = new BlockEdConfig();
            instance.initializeDefaults();
            File f = new File(CONFIG_FILE);
            if( !f.exists() ) {
                store(instance, new File(CONFIG_FILE));
            }
        }
        return instance;
    }

    public static BlockEdConfig load( File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return gson.fromJson(json, BlockEdConfig.class);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }

    public static void store( BlockEdConfig config, File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + f);
            String json = gson.toJson(config);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }
}

