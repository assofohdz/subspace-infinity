/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FloorReference implements VersionedObject<FloorReference> {
    static Logger log = LoggerFactory.getLogger(FloorReference.class);
    
    private String floor;
    private Vec3i offset = new Vec3i();
    private VersionedList<String> minTags = new VersionedList<>();
    private VersionedList<String> maxTags = new VersionedList<>();     
    private long version;
    
    public FloorReference( String floor ) {
        this.floor = floor;
    }
    
    public FloorReference clone() {
        FloorReference result = new FloorReference(floor);
        result.offset.set(offset);
        result.minTags.addAll(minTags);
        result.maxTags.addAll(maxTags);
        return result;
    }
    
    public void setFloor( String floor ) {
        if( Objects.equals(this.floor, floor) ) {
            return;
        }
        this.floor = floor;
        version++;
    }
    
    public String getFloor() {
        return floor;
    }
    
    public void setOffset( Vec3i offset ) {
        if( Objects.equals(this.offset, offset) ) {
            return;
        }
        this.offset.set(offset);
        version++;
    }
    
    public Vec3i getOffset() {
        return offset;
    }
 
    public void addMinimumTag( String tag ) {
        if( minTags.add(tag) ) {
            version++;
        }
    }

    public void removeMinimumTag( String tag ) {
        if( minTags.remove(tag) ) {
            version++;
        }
    }
    
    public VersionedList<String> getMinimumTags() {
        return minTags;
    }
    
    public void addMaximumTag( String tag ) {
        if( maxTags.add(tag) ) {
            version++;
        }
    }

    public void removeMaximumTag( String tag ) {
        if( maxTags.remove(tag) ) {
            version++;
        }
    }
    
    public VersionedList<String> getMaximumTags() {
        return maxTags;
    }
 
    public void invalidate() {
        version++;
    }
 
    @Override
    public long getVersion() {
        return version + minTags.getVersion() + maxTags.getVersion();
    }
    
    @Override
    public FloorReference getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<FloorReference> createReference() {
        return new VersionedReference<>(this);
    }    
    
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("floor", floor)
                .add("offset", offset)
                .add("minimumTags", minTags)
                .add("maximumTags", maxTags)
                .toString();
    }
}


