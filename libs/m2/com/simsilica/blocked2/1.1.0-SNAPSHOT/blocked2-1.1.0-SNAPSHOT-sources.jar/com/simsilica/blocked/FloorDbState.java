/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.*;
import com.simsilica.lemur.style.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;
import com.simsilica.mgen.FloorGenerator;
import com.simsilica.mgen.Part;


// For testing stuff
//import com.simsilica.mblock.*;
//import com.simsilica.mblock.io.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class FloorDbState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FloorDbState.class);

    private Container window;

    private FloorsDatabase floorsDb;
    private ListBox<FloorTemplate> floorsList;

    private VersionedReference<List<FloorTemplate>> floorsRef;
    private VersionedList<FloorTemplate> filteredList = new VersionedList<>();
    private FloorFilter filter = new FloorFilter();

    private TextField filterEditor;

    private VersionedReference<Integer> selectionRef;
    private FloorTemplate selectedFloor;
    private VersionedReference<FloorTemplate> selectedFloorRef;
    private FloorTemplateEditor floorEditor;

    public FloorDbState() {        
    }

    public VersionedList<FloorTemplate> getFloorTemplates() {
        return floorsDb.getFloors();
    }

    public FloorTemplate findTemplate( String name ) {
        return floorsDb.findTemplate(name);
    }

    public Map<String, FloorTemplate> getTemplates() {
        // Just build it upon request
        Map<String, FloorTemplate> results = new HashMap<>();
        for( FloorTemplate template : floorsDb.getFloors() ) {
            results.put(template.getName(), template);
        }
        return results;
    } 

    protected void createFloor() {
        log.info("Create floor");
 
        CreateFloorDialog dialog = new CreateFloorDialog("Create Floor", "", new Vec3i(2, 0, 2), (floor) -> {
                doCreate(floor);
            });
        dialog.show();
    }
 
    protected void doCreate( FloorTemplate holder ) {    
        //String name = partName.getText().trim();
        if( Strings.isNullOrEmpty(holder.getName()) ) {
            return;
        }
        if( holder.getSizeX() == 0 || holder.getSizeZ() == 0 ) {
            return;
        }
        FloorTemplate floor = floorsDb.createFloor(holder.getName(), holder.getSizeX(), holder.getSizeZ());
        
        // Make sure the filtered list has the lastest floor if it matches
        // the filter.
        resetFilteredList();
        int index = filteredList.indexOf(floor);
        if( index >= 0 ) {
            floorsList.getSelectionModel().setSelection(index);
        }
        floorsDb.save();
        focus();
    }

    protected void copyFloor() {
        log.info("Copy floor");
        if( selectedFloor == null ) {
            return;
        }
 
        CreateFloorDialog dialog = new CreateFloorDialog("Copy Floor", "", 
                                                         new Vec3i(selectedFloor.getSizeX(), 0, 
                                                         selectedFloor.getSizeZ()), (floor) -> {
                doCopy(floor);
            });
        dialog.show();
    }
 
    protected void doCopy( FloorTemplate holder ) {    
        if( selectedFloor == null ) {
            return;
        }
        
        //String name = partName.getText().trim();
        if( Strings.isNullOrEmpty(holder.getName()) ) {
            return;
        }
        if( holder.getSizeX() == 0 || holder.getSizeZ() == 0 ) {
            return;
        }
        FloorTemplate floor = floorsDb.copyFloor(holder.getName(), selectedFloor);
        floor.resize(holder.getSizeX(), holder.getSizeZ()); 
        
        // Make sure the filtered list has the lastest floor if it matches
        // the filter.
        resetFilteredList();
        int index = filteredList.indexOf(floor);
        if( index >= 0 ) {
            floorsList.getSelectionModel().setSelection(index);
        }
        floorsDb.save();
        focus();
    }
 
    protected void deleteFloor() {
        log.info("Delete floor");
        if( selectedFloor == null ) {
            return;
        }
        getState(OptionPanelState.class).show("Delete?", 
                                              "Really delete floor:" + selectedFloor.getName() + "?", 
                                              new CallMethodAction("Yes", this, "doDeleteFloor"),
                                              new EmptyAction("No"),
                                              new EmptyAction("Cancel"));
    }

    protected void doDeleteFloor() {
        if( selectedFloor == null ) {
            return;
        }
        floorsDb.deleteFloor(selectedFloor);
    }
    
    public void focus() {
        TabbedPanel tabs = getState(ToolPanelState.class).getTabs(); 
        for( TabbedPanel.Tab tab : tabs.getTabs() ) {
            if( tab.getContents() == window ) {
                tabs.setSelectedTab(tab);
                break;
            }
        }
    }

    protected void setSelectedFloor( FloorTemplate floor ) {
        if( floor == selectedFloor ) {
            return;
        }
        selectedFloor = floor;
        floorEditor.setObject(floor);
        if( selectedFloor != null ) {
            selectedFloorRef = floor.createReference();
        } else {
            selectedFloorRef = null;
        }
    }    
    
    @Override
    protected void initialize( Application app ) {
        floorsDb = FloorsDatabase.create(BlockEdConfig.getInstance().getStructureDbDir());
        floorsRef = floorsDb.getFloors().createReference();

        window = new Container();
        getState(ToolPanelState.class).getTabs().addTab("Floors DB", window);
        
        Container container;
        window.addChild(new Label("Floors:"));
        container = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.First, FillMode.Last)));
        filterEditor = container.addChild(new TextField(""));
        container.addChild(new ActionButton(new CallMethodAction("Filter", this, "parseFilter")));

        //floorsList = window.addChild(new ListBox<>(floorsDb.getFloors()));
        floorsList = window.addChild(new ListBox<>(filteredList));
        floorsList.setCellRenderer(new FloorTemplateRenderer());
        selectionRef = floorsList.getSelectionModel().createSelectionReference();

        Container buttons = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Create", this, "createFloor")));
        buttons.addChild(new ActionButton(new CallMethodAction("Copy", this, "copyFloor")));
        buttons.addChild(new ActionButton(new CallMethodAction("Delete", this, "deleteFloor")));
        window.addChild(new ActionButton(new CallMethodAction("Test Floor", this, "testFloor")));
 
        container = new Container();
        window.addChild(new RollupPanel("Floor:", container, null));
        
        floorEditor = container.addChild(new FloorTemplateEditor());
        
        //buttons = container.addChild(new Container());
        //buttons.addChild(new ActionButton(new CallMethodAction("Test Floor", this, "testFloor")));
           
        resetFilteredList();
    }
    
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        if( floorsRef.update() ) {
            resetFilteredList();
        }
        if( selectionRef.update() ) {
            setSelectedFloor(floorsList.getSelectedItem());
        }
        if( selectedFloorRef != null && selectedFloorRef.update() ) {
            floorsDb.save();
            log.info("save db");
            floorsList.getModel().add(null);
            floorsList.getModel().remove(null);
        }
    }
    
    protected void testFloor() throws Exception {
        if( selectedFloor == null ) {
            return;
        }
        getState(PartDbState.class).testFloor(selectedFloor);
    }
    
    protected void parseFilter() {        
        String text = filterEditor.getText().trim();
        filter.clear();           
        String[] tags = text.split("\\s*,\\s*");
        for( String tag : tags ) {
            tag = tag.trim();
            if( tag.length() > 0 ) {
                if( tag.charAt(0) == '!' ) {
                    filter.exclude(tag.substring(1));
                } else {
                    filter.include(tag);
                }
            }
        }
        resetFilteredList();
    }
    
    protected void resetFilteredList() {
        FloorTemplate selected = floorsList.getSelectedItem();
        filteredList.clear();
        for( FloorTemplate floor : floorsDb.getFloors() ) {
            if( filter.apply(floor) ) {
                filteredList.add(floor);
            }
        }         
        int i = filteredList.indexOf(selected);
        if( i >= 0 ) {
            floorsList.getSelectionModel().setSelection(i);
        } else {
            floorsList.getSelectionModel().clear();
        }
    }  

    protected void logFloor( FloorTemplate template ) {
        int xSize = template.getSizeX();
        int zSize = template.getSizeZ();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                log.info("slots[" + i + "][" + j + "] = " + template.getSlot(i, j));
            }
        }
    } 

    protected void logFloor( FloorGenerator generator ) {
        int xSize = generator.getSizeX();
        int zSize = generator.getSizeZ();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                log.info("parts[" + i + "][" + j + "]");
                List<Part> parts = generator.getParts(i, j);
                for( Part p : parts ) {
                    log.info("    " + p);                    
                }            
            }
        }
    }     
    
    private class FloorTemplateRenderer extends DefaultValueRenderer<FloorTemplate> {
        public FloorTemplateRenderer() {
            super(null, null);            
        }
 
        @Override
        protected String valueToString( FloorTemplate floor ) {
            if( floor == null ) {
                return null;
            }
            String result = floor.getName();
            return result;
        }
    }
    
    private class FloorFilter implements Predicate<FloorTemplate> {
        private Set<String> include = new HashSet<>();
        private Set<String> exclude = new HashSet<>();
    
        public void include( String tag ) {
            include.add(tag);
        }
        
        public void exclude( String tag ) {
            exclude.add(tag);
        }
    
        public void clear() {
            include.clear();
            exclude.clear();
        }

        public boolean apply( FloorTemplate info ) {
            if( info == null ) {
                return false;
            }
            if( info.hasAny(exclude) ) {
                return false;
            }
            if( include.isEmpty() ) {
                return true;
            }
            return info.hasAll(include);
        } 
    }
    
}

