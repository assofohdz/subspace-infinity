/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.*;
import com.simsilica.lemur.props.*;

import com.simsilica.tool.DebugNormalsState;

/**
 *  Just collects the other menus and puts them together.
 *
 *  @author    Paul Speed
 */
public class MainMenuState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(MainMenuState.class);

    private Container mainMenu;
    private TabbedPanel tabs;

    public MainMenuState() {
    }

    public TabbedPanel getTabs() {
        return tabs;
    }

    @Override
    protected void initialize( Application app ) {

        Container settings = new Container();
        settings.addChild(getState(PostProcessingState.class).getSettings());

        getState(PostProcessingState.class).getSettings()
            .addFloatProperty("Local Light", getState(BlockState.class), "localLight", 0, 1, 0.05f);

        PropertyPanel debug = new PropertyPanel("glass");
        debug.addBooleanProperty("Show Normals", getState(DebugNormalsState.class), "enabled");
        debug.addBooleanProperty("Show Light Values", getState(DebugLightValuesState.class), "enabled");
        debug.addBooleanProperty("Show Wire Frame", getState(BlockState.class), "wireFrame");

        Container help = new Container();
        help.addChild(new ActionButton(new CallMethodAction("Key Mappings", getState(HelpState.class), "toggleEnabled")));

        mainMenu = new Container();
        RollupPanel rollup = mainMenu.addChild(new RollupPanel("Block-Ed", null));

        this.tabs = new TabbedPanel();
        rollup.setContents(tabs);

        tabs.addTab("File", getState(FileState.class).getMenu());
        tabs.addTab("Settings", settings);
        tabs.addTab("Debug", debug);
        tabs.addTab("Help", help);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        ((Main)getApplication()).getGuiNode().attachChild(mainMenu);
        mainMenu.setLocalTranslation(16, getApplication().getCamera().getHeight() - 16, 0);
    }

    @Override
    protected void onDisable() {
        mainMenu.removeFromParent();
    }
}
