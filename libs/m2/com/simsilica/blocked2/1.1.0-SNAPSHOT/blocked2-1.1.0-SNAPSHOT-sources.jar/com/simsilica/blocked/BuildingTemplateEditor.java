/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;
import com.jme3.texture.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BuildingTemplateEditor extends Container {
    static Logger log = LoggerFactory.getLogger(BuildingTemplateEditor.class);

    private BuildingTemplate building;
    private VersionedReference<BuildingTemplate> buildingRef;

    private TagSetButton tagsButton;
    private VersionedReference<Set<String>> tagsRef; 
    
    private TextField nameEditor;
    private VersionedReference<DocumentModel> nameRef;
 
    private Selector<FloorTemplate> templateSelector;
 
    private List<Button> actions = new ArrayList<>();
 
    private ListBox<FloorReference> floorList;
    private VersionedList<FloorTemplate> floorTemplates;
    private VersionedReference<Integer> selectedFloorRef;
    
    private FloorReferenceEditor floorEditor;
    private VersionedReference<FloorReference> floorRef;
    
    public BuildingTemplateEditor( VersionedList<FloorTemplate> floorTemplates ) { 
        this.floorTemplates = floorTemplates;
 
        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("Name:"));
        nameEditor = properties.addChild(new TextField(""), 1);
        nameRef = nameEditor.getDocumentModel().createReference();
        
        properties.addChild(new Label("Tags:"));
        tagsButton = properties.addChild(new TagSetButton(new TreeSet<String>()), 1);
        tagsRef = tagsButton.createReference();

        Container sub = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.First, FillMode.Last)));
        templateSelector = sub.addChild(new Selector<>(floorTemplates, new FloorTemplateRenderer()));
        actions.add(sub.addChild(new ActionButton(new CallMethodAction("Add", this, "addFloor"))));      
        
        addChild(new Label("Floors:"));
        floorList = addChild(new ListBox<>());
        floorList.setCellRenderer(new FloorReferenceRenderer());
        selectedFloorRef = floorList.getSelectionModel().createSelectionReference();

        sub = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        actions.add(sub.addChild(new ActionButton(new CallMethodAction("Move Up", this, "moveUp"))));        
        actions.add(sub.addChild(new ActionButton(new CallMethodAction("Move Down", this, "moveDown"))));
        actions.add(sub.addChild(new ActionButton(new CallMethodAction("Remove", this, "removeFloor"))));
 
        floorEditor = addChild(new FloorReferenceEditor(floorTemplates));
        
        refreshEditor();
    }
 
    public void setObject( BuildingTemplate building ) {
        if( building == null ) {
            buildingRef = null;
        } else {
            buildingRef = building.createReference();
        }
        this.building = building;
        if( building != null ) {
            floorList.setModel(building.getFloors());        
            if( building.getFloors().size() > 0 ) {
                floorList.getSelectionModel().setSelection(0);
            }
        } else {
            floorList.setModel(null);
        }                         
        refreshEditor();
    }
    
    public BuildingTemplate getObject() {
        return building;
    }
 
    @Override   
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( buildingRef != null && buildingRef.update() ) {
            refreshEditor();
        }
        if( tagsRef != null && tagsRef.update() ) {
            // Make the building look like it changed
            building.invalidate();
        }
        if( selectedFloorRef != null && selectedFloorRef.update() ) {
            setSelectedFloor(floorList.getSelectedItem());            
        }
        if( floorRef != null && floorRef.update() ) {
            // Make the building look like it changed
            building.invalidate();
            
            // And make the view update in the floor list
            floorList.getModel().add(null);
            floorList.getModel().remove(null);
        }        
        if( building != null ) {
            if( nameRef.update() ) {
                building.setName(nameRef.get().getText());
            }
        }
    }    
 
    protected void setSelectedFloor( FloorReference floor ) {
        floorEditor.setObject(floor);
        if( floor != null ) {
            floorRef = floor.createReference();
        }    
    }
    
    protected void refreshEditor() {
        if( building != null ) {
            tagsButton.setTags(building.getTags());
            
            // Grab a new reference so it doesn't look like we updated the tags
            tagsRef = tagsButton.createReference();
            
            nameEditor.setText(building.getName());
            nameRef = nameEditor.getDocumentModel().createReference();
            
            for( Button b : actions ) {
                b.setEnabled(true);
            }
        } else {
            for( Button b : actions ) {
                b.setEnabled(false);
            }                        
        }
    }
    
    protected void addFloor() {
        log.info("Add floor");
        if( building == null ) {
            return;
        }
        FloorTemplate template = templateSelector.getSelectedItem();
        if( template == null ) {
            return;
        }
        building.addFloor(new FloorReference(template.getName()));
    }

    protected void moveUp() {
        log.info("Move up");
        if( building == null ) {
            return;
        }
        Integer i = floorList.getSelectionModel().getSelection();
        if( i == null || i < 1 ) {
            return;
        }
        FloorReference ref = floorList.getModel().remove((int)i);
        floorList.getModel().add(i-1, ref); 
        floorList.getSelectionModel().setSelection(i-1); 
    }
    
    protected void moveDown() {
        log.info("Move down");
        if( building == null ) {
            return;
        }
        Integer i = floorList.getSelectionModel().getSelection();
        if( i == null || i >= floorList.getModel().size() - 1 ) {
            return;
        }
        FloorReference ref = floorList.getModel().remove((int)i);
        floorList.getModel().add(i+1, ref);
        floorList.getSelectionModel().setSelection(i+1); 
    }
    
    protected void removeFloor() {
        log.info("Remove floor");
        if( building == null ) {
            return;
        }
        Integer i = floorList.getSelectionModel().getSelection();
        if( i == null ) {
            return;
        }
        FloorReference ref = floorList.getModel().remove((int)i);
    }
    
    public FloorTemplate findTemplate( String name ) {
        for( FloorTemplate floor : floorTemplates ) {
            if( Objects.equals(floor.getName(), name) ) {
                return floor;
            }
        }
        return null;
    }
    
    public static class FloorTemplateRenderer extends DefaultValueRenderer<FloorTemplate> {
        public FloorTemplateRenderer() {
        }
        
        @Override        
        protected String valueToString( FloorTemplate floor ) {
            if( floor == null ) {
                return null;
            }
            StringBuilder sb = new StringBuilder(floor.getName());
            sb.append(" (" + floor.getSizeX() + "x" + floor.getSizeZ() + ")");
            return sb.toString(); 
        } 
    }
    
    private class FloorReferenceRenderer extends DefaultValueRenderer<FloorReference> {
        @Override        
        protected String valueToString( FloorReference floor ) {
            if( floor == null ) {
                return null;
            }
            StringBuilder sb = new StringBuilder(floor.getFloor());
            FloorTemplate template = findTemplate(floor.getFloor());
            if( template != null ) {
                sb.append(" (" + template.getSizeX() + "x" + template.getSizeZ() + ")");
            } else {
                sb.append(" ?x?");
            }
            if( floor.getOffset().lengthSq() > 0 ) {
                sb.append(" +" + floor.getOffset());
            }
            
            return sb.toString(); 
        } 
    }  
}


