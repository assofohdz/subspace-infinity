/*
 * $Id$
 * 
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.blocked;

import com.jme3.input.KeyInput;
import com.simsilica.lemur.input.Button;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MainAppFunctions {

    public static final FunctionId F_HELP = new FunctionId("Help");

    public static final FunctionId F_NEW = new FunctionId("New");
    public static final FunctionId F_OPEN = new FunctionId("Open");
    public static final FunctionId F_SAVE = new FunctionId("Save");
    public static final FunctionId F_SAVE_AS = new FunctionId("Save As");
    public static final FunctionId F_EXIT = new FunctionId("Exit");

    public static final FunctionId F_CAMERA_TOGGLE = new FunctionId("Camera Toggle");
    public static final FunctionId F_OPEN_UI = new FunctionId("Open UI");

    public static void initializeDefaultMappings( InputMapper inputMapper ) {
    
        inputMapper.map(F_HELP, KeyInput.KEY_F1);
        
        inputMapper.map(F_NEW, KeyInput.KEY_N, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_OPEN, KeyInput.KEY_O, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_SAVE, KeyInput.KEY_S, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_SAVE_AS, KeyInput.KEY_A, KeyInput.KEY_LCONTROL);
        inputMapper.map(F_EXIT, KeyInput.KEY_ESCAPE);
        
        inputMapper.map(F_CAMERA_TOGGLE, KeyInput.KEY_SPACE);
        
    }
}
