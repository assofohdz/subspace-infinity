/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.collision.*;
import com.jme3.math.*;
import com.jme3.renderer.Camera;

import com.simsilica.input.*;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.input.*;
import com.simsilica.state.*;

import com.simsilica.tool.*;

/**
 *  Manages the toggling between camera modes, UI, etc.
 *
 *  @author    Paul Speed
 */
public class CameraToggleState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(CameraToggleState.class);

    private boolean firstPerson = false;
    private GravityMovementTarget target;

    public CameraToggleState() {
            
    }
 
    public void toggleCamera() {
        firstPerson = !firstPerson;
        getState(OrbitCameraState.class).setEnabled(!firstPerson);
        getState(MovementState.class).setEnabled(firstPerson);
        
        if( firstPerson ) {
            getState(CameraState.class).setFieldOfView(60);
            getState(CameraState.class).setNear(0.01f);
        } else {
            getState(CameraState.class).setFieldOfView(45);
            getState(CameraState.class).setNear(0.1f);
        }
    }
    
    public void toggleUi() {
    }
    
    @Override
    protected void initialize( Application app ) {
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.addDelegate(MainAppFunctions.F_CAMERA_TOGGLE, this, "toggleCamera");
        inputMapper.addDelegate(MainAppFunctions.F_OPEN_UI, this, "toggleUi");
        this.target = new GravityMovementTarget(app.getCamera());
        getState(MovementState.class).setMovementTarget(target, false);
        getState(MovementState.class).setWalkSpeed(3.0/4);
        getState(MovementState.class).setRunSpeed(10.0/4);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        target.update(tpf);
    }
    
    private class GravityMovementTarget extends CameraMovementTarget {
        private Camera camera;
        private float yOffset = 1.7f;
        private float scale = 1/4f;
    
        public GravityMovementTarget( Camera camera ) {
            super(camera);
            this.camera = camera;
        }
        
        public void update( float tpf ) {
            if( !firstPerson ) {
                return;
            }
            Vector3f loc = camera.getLocation();
            Ray ray = new Ray(loc, new Vector3f(0, -1, 0));
            ray.setLimit(2 * scale);

            float floor = 0;
            float yTarget = floor + (yOffset * scale); 
 
            CollisionResults collisions = new CollisionResults();           
            getState(BlockState.class).getBlocksSpatial().collideWith(ray, collisions);
            if( collisions.size() > 0 ) {
                //log.info("closest:" + collisions.getClosestCollision());
                CollisionResult cr = collisions.getClosestCollision();
                yTarget = cr.getContactPoint().y;
                if( yTarget < floor ) {
                    yTarget = floor;
                }
                yTarget += yOffset * scale;
            }            
 
            if( loc.y > yTarget ) {
                loc.y -= tpf;
                loc.y = Math.max(yTarget, loc.y);
                camera.setLocation(loc); 
            } else if( loc.y < yTarget ) {
                loc.y += tpf * 2;
                loc.y = Math.min(yTarget, loc.y);
                camera.setLocation(loc); 
            }
        } 
    }
}

