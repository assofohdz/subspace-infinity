/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class GetStringDialog extends Container {
    static Logger log = LoggerFactory.getLogger(GetStringDialog.class);
 
    private TextField text;
    private Command<String> done;
    
    public GetStringDialog( String title, String label, String startValue, Command<String> done ) {
        super(new BorderLayout());
        
        this.done = done;
        
        addChild(new Label(title, new ElementId("title.label")), BorderLayout.Position.North);
        
        Container contents = addChild(new Container(), BorderLayout.Position.Center);
        contents.addChild(new Label(label));
        
        text = contents.addChild(new TextField(startValue), 1);
        Vector3f pref = text.getPreferredSize();
        pref.x = Math.max(pref.x, 100);
        text.setPreferredSize(pref);
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)), BorderLayout.Position.South);
        buttons.addChild(new ActionButton(new CallMethodAction(this, "ok")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));
    }
 
    public void show() {
        GuiGlobals.getInstance().getPopupState().centerInGui(this);
        GuiGlobals.getInstance().getPopupState().showModalPopup(this);
        GuiGlobals.getInstance().requestFocus(text);
    }
 
    public String getText() {
        return text.getText();
    }
    
    protected void ok() {
        done.execute(text.getText());
        removeFromParent();
    }
    
    protected void cancel() {
        removeFromParent();
    }
}
