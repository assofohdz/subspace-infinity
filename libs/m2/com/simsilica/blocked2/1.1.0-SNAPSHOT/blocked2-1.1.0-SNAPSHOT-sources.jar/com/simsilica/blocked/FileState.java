/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.io.Files;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.export.binary.BinaryExporter;
import com.jme3.math.*;
import com.jme3.scene.Spatial;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.mblock.*;
import com.simsilica.mblock.io.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FileState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FileState.class);

    private Container fileMenu;

    private File lastFile;
    private int lastSavedCount;

    private Container fileSaveDialog;
    private TextField fileEntry;

    private ExportFormat[] exportFormats = new ExportFormat[] {
            new J3oExportFormat(),
            new ObjExportFormat()
        };

    private Container fileLoadDialog;
    private ListBox<String> files;

    private File rootDir = BlockEdConfig.getInstance().getOutputDir(); //new File("blocks-files");

    // Used when we've saved during the "Exit" workflow and should then just leave.
    private boolean exitOnSave;

    private String preload;

    public FileState() {
        if( !rootDir.exists() ) {
            rootDir.mkdirs();
        }
    }

    public void setPreload( String file ) {
        this.preload = file;
    }

    public String getPreload() {
        return preload;
    }

    public Container getMenu() {
        return fileMenu;
    }

    protected File toFile( String f ) {
        if( f == null ) {
            return null;
        }
        if( !f.toLowerCase().endsWith(".blocks") ) {
            f += ".blocks";
        }
        File file = new File(rootDir, f);
        return file;
    }

    protected String toName( File f ) {
        return Files.getNameWithoutExtension(f.getName());
    }

    public void newFile() {
        System.out.println("newFile()");

        if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
            getState(OptionPanelState.class).show("Clear Object?",
                                                "Really clear current object?",
                                                new CallMethodAction("Yes", this, "clear"),
                                                new EmptyAction("No"),
                                                new EmptyAction("Cancel"));
        } else {
            // nothing to do but we'll clear anyway
            clear();
        }
    }

    protected void clear() {
        System.out.println("clear()");
        getState(BlockState.class).clearAll();
        lastSavedCount = 0;
        lastFile = null;
    }

    public boolean hasChanged() {
        return getState(BlockState.class).getChangeCount() > lastSavedCount;
    }

    public void open() {
        System.out.println("open()");
        if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
            getState(OptionPanelState.class).show("Abandon Changes?",
                                                "Really abandon current changes?",
                                                new CallMethodAction("Yes", this, "selectFile"),
                                                new EmptyAction("No"),
                                                new EmptyAction("Cancel"));
        } else {
            selectFile();
        }
    }

    public void save() {
        System.out.println("save()");
        if( lastFile == null ) {
            saveAs();
        } else {
            saveBlocks(lastFile);
        }
    }

    public void saveAs() {
        System.out.println("saveAs()");

        if( lastFile != null ) {
            fileEntry.setText(toName(lastFile));
        }

        Vector3f pref = fileSaveDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileSaveDialog.setLocalTranslation(loc);

        GuiGlobals.getInstance().getPopupState().showModalPopup(fileSaveDialog);
    }

    public void exit() {
        if( getState(BlockState.class).getChangeCount() > lastSavedCount ) {
            exitOnSave = true;
            getState(OptionPanelState.class).show("Save Changes?",
                                                "Save changes before exiting?",
                                                new CallMethodAction("Save", this, "save"),
                                                new CallMethodAction("Save As", this, "saveAs"),
                                                new CallMethodAction("Exit", getApplication(), "stop"),
                                                new CallMethodAction("Cancel", this, "cancelExit"));
        } else {
            getApplication().stop();
        }
    }

    protected void cancelExit() {
        exitOnSave = false;
    }

    protected void cancelSave() {
        exitOnSave = false;
        fileSaveDialog.removeFromParent();
    }

    protected void selectFile() {
        System.out.println("selectFile()");

        // Update the file list
        List<String> objects = new ArrayList<>();
        for( String s : rootDir.list() ) {
            if( !s.toLowerCase().endsWith(".blocks") ) {
                continue;
            }
            s = s.substring(0, s.length() - ".blocks".length());
            objects.add(s);
        }

        files.getModel().clear();
        files.getModel().addAll(objects);
        files.getSelectionModel().clear();

        Vector3f pref = fileLoadDialog.getPreferredSize();
        Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                    getApplication().getCamera().getHeight() * 0.5f,
                                    0);
        loc.x -= pref.x * 0.5f;
        loc.y += pref.y * 0.5f;
        fileLoadDialog.setLocalTranslation(loc);

        GuiGlobals.getInstance().getPopupState().showModalPopup(fileLoadDialog);
    }

    protected void saveCurrentFile() {
        System.out.println("Save current file:" + fileEntry.getText());
        fileSaveDialog.removeFromParent();

        String name = fileEntry.getText();
        File file = toFile(name);
        if( file.exists() ) {
            getState(OptionPanelState.class).show("Overwrite?",
                                                "Really overwrite existing file:" + name + "?",
                                                new CallMethodAction("Yes", this, "saveBlocks"),
                                                new CallMethodAction("No", this, "saveAs"),
                                                new CallMethodAction("Cancel", this, "cancelExit"));
        } else {
            saveBlocks(name);
        }
    }

    // CallMethodAction won't let us supply our own parameters so we have to
    // double dip
    protected void saveBlocks() {
        saveBlocks(fileEntry.getText());
    }

    protected void saveBlocks( String f ) {
        System.out.println("Save blocks:" + f);
        saveBlocks(toFile(f));
    }

    public void saveBlocks( File file ) {
        lastFile = file;

        System.out.println("Write to:" + file);
        try {
            writeBlocks(file, getState(BlockState.class).getCells(), getState(BlockState.class).getFluidData());
            lastSavedCount = getState(BlockState.class).getChangeCount();

            if( exitOnSave ) {
                exit();
            }
        } catch( IOException e ) {
            log.error("Error saving file:" + file, e);
            getState(OptionPanelState.class).showError("Error saving:" + file, e);
        }
    }

    protected void loadSelectedFile() {
        System.out.println("loadSelectedFile()");
        fileLoadDialog.removeFromParent();

        Integer selection = files.getSelectionModel().getSelection();
        if( selection == null ) {
            getState(OptionPanelState.class).show("Not Loaded",
                                                  "Object not loaded.  No file was selected.");
            return;
        }

        String s = files.getModel().get(selection);
        loadFile(s);
    }

    protected void loadFile( String s ) {
        loadFile(toFile(s));
    }

    public void loadFile( File file ) {
        try {
            readBlocks(file, getState(BlockState.class).getCells(), getState(BlockState.class).getFluidData());
            getState(BlockState.class).resetChangeCount();
            getState(BlockState.class).invalidate();
            lastSavedCount = 0;
            lastFile = file;
        } catch( IOException e ) {
            log.error("Error reading file:" + file, e);
            getState(OptionPanelState.class).showError("Error reading:" + file, e);
        }
    }

    @Override
    protected void initialize( Application app ) {

        // For now just create and position our own panel.
        // We'll centralize later.

        fileMenu = new Container();

        fileMenu.addChild(new ActionButton(new CallMethodAction("New", this, "newFile")));
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "open")));
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "save")));
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "saveAs")));
        fileMenu.addChild(new Container());
        //fileMenu.addChild(new ActionButton(new CallMethodAction("Export .j3o", j3oExport, "showFileSelector")));
        //fileMenu.addChild(new ActionButton(new CallMethodAction("Export .obj", j3oExport, "showFileSelector")));
        for( ExportFormat format : exportFormats ) {
            fileMenu.addChild(new ActionButton(
                new CallMethodAction("Export " + format.getName(),
                                     new ExportFormatUi(format),
                                     "showFileSelector")));
        }
        fileMenu.addChild(new Container());
        fileMenu.addChild(new ActionButton(new CallMethodAction(this, "exit")));


        // A simple file dialog that just prompts for a file name
        fileSaveDialog = new Container();
        fileSaveDialog.addChild(new Label("Save As...", new ElementId("title.label")));
        fileEntry = fileSaveDialog.addChild(new TextField("MyFile"));
        Container buttons = fileSaveDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Save", this, "saveCurrentFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", this, "cancelSave")));


        // A simple file selection dialog that just displays a list of all
        // .blocks files and allows selection
        fileLoadDialog = new Container();
        Label title = fileLoadDialog.addChild(new Label("Load Object", new ElementId("title.label")));

        // Set the preferred width of the title so that the whole box is nice and wide
        Vector3f pref = title.getPreferredSize();
        pref.x = Math.max(pref.x, 200);
        title.setPreferredSize(pref);

        files = fileLoadDialog.addChild(new ListBox<String>());
        files.setVisibleItems(10);
        buttons = fileLoadDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Load", this, "loadSelectedFile")));
        buttons.addChild(new ActionButton(new CallMethodAction("Cancel", fileLoadDialog, "removeFromParent")));


        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.addDelegate(MainAppFunctions.F_NEW, this, "newFile");
        inputMapper.addDelegate(MainAppFunctions.F_OPEN, this, "open");
        inputMapper.addDelegate(MainAppFunctions.F_SAVE, this, "save");
        inputMapper.addDelegate(MainAppFunctions.F_SAVE_AS, this, "saveAs");
        inputMapper.addDelegate(MainAppFunctions.F_EXIT, this, "exit");

        if( preload != null ) {
            loadFile(preload);
        }
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    private void writeBlocks( File f, CellArray cells, CellArray fluids ) throws IOException {
        BlockObject blocks = new BlockObject(cells, fluids);
        FileOutputStream fOut = new FileOutputStream(f);
        BlocksFileFormat.writeBlocks(blocks, fOut);
    }

    private void readBlocks( File f, CellArray cells, CellArray fluids ) throws IOException {
        cells.clear();
        fluids.clear();

        FileInputStream fIn = new FileInputStream(f);
        BlockObject blocks = BlocksFileFormat.readBlocks(fIn, false);

        if( cells.getSize().equals(blocks.cells.getSize()) ) {
            cells.set(blocks.cells);
            if( blocks.fluids != null ) {
                fluids.set(blocks.fluids);
            }
        } else {
            // Have to do it the harder way
            int xOffset = (cells.getSizeX() - blocks.cells.getSizeX()) / 2;
            int zOffset = (cells.getSizeZ() - blocks.cells.getSizeZ()) / 2;
            if( xOffset < 0 || zOffset < 0 ) {
                throw new RuntimeException("Loaded data is larger than grid size:" + blocks.cells.getSize());
            }
            for( int i = 0; i < blocks.cells.getSizeX(); i++ ) {
                for( int j = 0; j < blocks.cells.getSizeY(); j++ ) {
                    for( int k = 0; k < blocks.cells.getSizeZ(); k++ ) {
                        cells.setCell(i + xOffset, j, k + zOffset, blocks.cells.getCell(i, j, k));
                        if( blocks.fluids != null ) {
                            fluids.setCell(i + xOffset, j, k + zOffset, blocks.fluids.getCell(i, j, k));
                        }
                    }
                }
            }
        }
    }

    public interface ExportFormat {
        public String getName();
        public String getExtension();
        public void writeData( File file, BlockState blocks ) throws IOException;
    }

    private class J3oExportFormat implements ExportFormat {

        public String getName() {
            return "JME J3o";
        }

        public String getExtension() {
            return "j3o";
        }

        public void writeData( File f, BlockState blocks ) throws IOException {
            Spatial spatial = blocks.getBlocksSpatial();
            BinaryExporter exporter = BinaryExporter.getInstance();
            exporter.save(spatial, f);
        }
    }

    private class ObjExportFormat implements ExportFormat {

        public String getName() {
            return "Wavefront OBJ";
        }

        public String getExtension() {
            return "obj";
        }

        public void writeData( File f, BlockState blocks ) throws IOException {
            ObjWriter writer = new ObjWriter(f);
            try {
                writer.write(blocks.getBlocksSpatial());
            } finally {
                writer.close();
            }
        }
    }

    // Less ugly but still ugly.
    private class ExportFormatUi {

        private ExportFormat format;
        private Container exportDialog;
        private TextField exportEntry;

        public ExportFormatUi( ExportFormat format ) {
            this.format = format;
            this.exportDialog = new Container();
            exportDialog.addChild(new Label("Export " + format.getName() + " As...",
                                            new ElementId("title.label")));
            exportEntry = exportDialog.addChild(new TextField("My " + format.getName()));
            Container buttons = exportDialog.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
            buttons.addChild(new ActionButton(new CallMethodAction("Export", this, "tryExport")));
            buttons.addChild(new ActionButton(new CallMethodAction("Cancel", exportDialog, "removeFromParent")));
        }

        protected File toExportFile( String f ) {
            if( f == null ) {
                return null;
            }
            if( !f.toLowerCase().endsWith("." + format.getExtension()) ) {
                f += "." + format.getExtension();
            }
            File file = new File(BlockEdConfig.getInstance().getExportDir(), f);
            if( !file.getParentFile().exists() ) {
                file.getParentFile().mkdirs();
            }
            return file;
        }

        public void showFileSelector() {
            System.out.println("showFileSelector()" + format.getName());

            if( lastFile != null ) {
                exportEntry.setText(toName(lastFile));
            }

            Vector3f pref = exportDialog.getPreferredSize();
            Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() * 0.5f,
                                        getApplication().getCamera().getHeight() * 0.5f,
                                        0);
            loc.x -= pref.x * 0.5f;
            loc.y += pref.y * 0.5f;
            exportDialog.setLocalTranslation(loc);

            GuiGlobals.getInstance().getPopupState().showModalPopup(exportDialog);
        }

        public void tryExport() {
            System.out.println("Export current file:" + exportEntry.getText());
            exportDialog.removeFromParent();

            String name = exportEntry.getText();
            File file = toExportFile(name);
            if( file.exists() ) {
                getState(OptionPanelState.class).show("Overwrite?",
                                                      "Really overwrite existing file:" + file + "?",
                                                      new CallMethodAction("Yes", this, "doExport"),
                                                      new CallMethodAction("No", this, "showFileSelector"),
                                                      new EmptyAction("Cancel"));
            } else {
                doExport(name);
            }
        }

        protected void doExport() {
            doExport(exportEntry.getText());
        }

        protected void doExport( String f ) {
            System.out.println("Export " + format.getName() + " as:" + f);

            // Just a dump export, no mesh optimizations
            File file = toExportFile(f);

            System.out.println("Exporting to:" + file);
            try {
                //writeJ3o(file, getState(BlockState.class).getBlocksSpatial());
                format.writeData(file, getState(BlockState.class));
            } catch( IOException e ) {
                log.error("Error exporting file:" + file, e);
                getState(OptionPanelState.class).showError("Error exporting:" + file, e);
            }
        }

        /*private void writeJ3o( File f, Spatial spatial ) throws IOException {
            BinaryExporter exporter = BinaryExporter.getInstance();
            exporter.save(spatial, f);
        }*/
    }
}
