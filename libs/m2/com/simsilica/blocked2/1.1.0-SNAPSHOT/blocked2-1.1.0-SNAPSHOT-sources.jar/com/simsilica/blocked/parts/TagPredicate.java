/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;

import com.simsilica.lemur.core.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TagPredicate implements Predicate<Set<String>>, VersionedObject<TagPredicate> {
    static Logger log = LoggerFactory.getLogger(TagPredicate.class);
 
    private long version;
    private VersionedSet<String> requiredTags = new VersionedSet<>();
    private VersionedSet<String> rejectedTags = new VersionedSet<>();
    
    public TagPredicate() {
    }
 
    @Override
    public long getVersion() {
        return version + requiredTags.getVersion() + rejectedTags.getVersion();
    }
    
    @Override
    public TagPredicate getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<TagPredicate> createReference() {
        return new VersionedReference<>(this);
    }
 
    public void clear() {
        if( requiredTags.isEmpty() && rejectedTags.isEmpty() ) {
            return;
        }
        requiredTags.clear();
        rejectedTags.clear();
        version++;
    }
     
    public void set( TagPredicate tagPredicate ) {
        if( tagPredicate == this ) {
            return;
        }
        clear();
        if( tagPredicate == null ) {
            return;
        }
        requiredTags.addAll(tagPredicate.requiredTags);
        rejectedTags.addAll(tagPredicate.rejectedTags);
        version++;
    }

    public void addRequiredTag( String required ) {
        if( Strings.isNullOrEmpty(required) ) {
            throw new IllegalArgumentException("Null or empty tags not allowed");
        } 
        if( requiredTags.add(required) ) {
            version++;
        }
    }

    public void removeRequiredTag( String required ) {
        if( requiredTags.remove(required) ) {
            version++;
        }
    }
    
    public void setRequiredTags( Set<String> requiredTags ) {
        if( this.requiredTags == requiredTags ) {
            return;
        }
        checkTags(requiredTags);
        this.requiredTags.clear();
        this.requiredTags.addAll(requiredTags);
    }
    
    public Set<String> getRequiredTags() {
        return requiredTags;
    }
    
    public void addRejectedTag( String rejected ) {
        if( Strings.isNullOrEmpty(rejected) ) {
            throw new IllegalArgumentException("Null or empty tags not allowed");
        } 
        if( rejectedTags.add(rejected) ) {
            version++;
        }
    }

    public void removeRejectedTag( String rejected ) {
        if( rejectedTags.remove(rejected) ) {
            version++;
        }
    }
    
    public void setRejectedTags( Set<String> rejectedTags ) {
        if( this.rejectedTags == rejectedTags ) {
            return;
        }
        checkTags(rejectedTags);
        this.rejectedTags.clear();
        this.rejectedTags.addAll(rejectedTags);
    }
    
    public Set<String> getRejectedTags() {
        return rejectedTags;
    }
    
    protected void checkTags( Set<String> tags ) {
        for( String s : tags ) {
            if( Strings.isNullOrEmpty(s) ) {
                throw new IllegalArgumentException("Null or empty tags not allowed");
            } 
        }
    }
    
    public boolean apply( Set<String> tags ) {
        // Any found rejected tag will reject the whole set
        for( String s : rejectedTags ) {
            if( tags.contains(s) ) {
                return false;
            }
        }
        if( !requiredTags.isEmpty() ) {
            // But all of the required tags must be there to pass
            return tags.containsAll(requiredTags);
        }
        // We have no required tags so all tags are good
        return true;         
    }
    
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("requiredTags", requiredTags)
                .add("rejectedTags", rejectedTags)
                .toString();
    }   
}


