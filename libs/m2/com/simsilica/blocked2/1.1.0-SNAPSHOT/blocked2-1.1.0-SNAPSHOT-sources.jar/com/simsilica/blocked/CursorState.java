/*
 * $Id$
 * 
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.collision.CollisionResult;
import com.jme3.math.Vector3f;
import com.jme3.scene.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.event.*;

import com.simsilica.blocked.tool.*;
import com.simsilica.tool.GridState;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CursorState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(CursorState.class);

    private Node grid;
    private CursorHandler handler = new CursorHandler();
    private BlockState blocks;

    private Spatial cursor;

    private Tool tool;

    private CollisionResult lastCollision;

    public CursorState() {        
    }
 
    public Vec3i getLastBlockLocation() {
        if( lastCollision == null ) {
            return null;
        }
        Vector3f worldPos = lastCollision.getContactPoint();
        Vector3f normal = lastCollision.getContactNormal();
        return blocks.getBlockLocation(worldPos, normal); 
    }
    
    public Vec3i getLastEmptyLocation() {
        if( lastCollision == null ) {
            return null;
        }
        Vector3f worldPos = lastCollision.getContactPoint();
        Vector3f normal = lastCollision.getContactNormal();
        return blocks.getEmptyLocation(worldPos, normal);
    }
 
    public CollisionResult getLastCollision() {
        return lastCollision;
    }
 
    public void setTool( Tool tool ) {
        this.tool = tool;
    }
    
    public Tool getTool() {
        return tool;
    }
 
    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    } 
    
    protected void setCursor( Spatial cursor ) {
        if( this.cursor == cursor ) {
            return;
        }
        if( this.cursor != null ) {
            this.cursor.removeFromParent();
        }
        this.cursor = cursor;
        if( isEnabled() && cursor != null ) {
            getRoot().attachChild(cursor);
        }
    }
    
    @Override
    protected void initialize( Application app ) {
        GridState gridState = getState(GridState.class);
        this.grid = gridState.getGrid();
        blocks = getState(BlockState.class);
        if( blocks == null ) {
            throw new RuntimeException("Requires BlockState");
        }
        
        // Hard coded for now
        tool = new MiniBlockTool();
        //tool = new MultiBlockTool(2, 2, 2);
        //tool = new MultiBlockTool(4, 4, 4);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        CursorEventControl.addListenersToSpatial(grid, handler);
        if( cursor != null ) {
            getRoot().attachChild(cursor);
        }
    }        
    
    @Override
    protected void onDisable() {
        CursorEventControl.removeListenersFromSpatial(grid, handler);
        if( cursor != null ) {
            cursor.removeFromParent();
        }
    }
    
    private class CursorHandler implements CursorListener {
    
        public void cursorButtonEvent( CursorButtonEvent event, Spatial target, Spatial capture ) {
            if( event.isPressed() ) {
                return;
            }
            if( lastCollision == null || tool == null ) {
                return;
            }
//System.out.println("event:" + event);
            if( event.getButtonIndex() == 0 ) {
                tool.main(blocks, lastCollision.getContactPoint(), lastCollision.getContactNormal());
            } else if( event.getButtonIndex() == 1 ) {
                tool.alternate(blocks, lastCollision.getContactPoint(), lastCollision.getContactNormal());
            } else if( event.getButtonIndex() == 2 ) {
                tool.combo(blocks, lastCollision.getContactPoint(), lastCollision.getContactNormal());
            } 
        }

        public void cursorEntered( CursorMotionEvent event, Spatial target, Spatial capture ) {
        }

        public void cursorExited( CursorMotionEvent event, Spatial target, Spatial capture ) {
            setCursor(null);
            lastCollision = null;
        }

        public void cursorMoved( CursorMotionEvent event, Spatial target, Spatial capture ) {
            lastCollision = event.getCollision();
    
            if( tool != null ) {
                if( lastCollision != null ) { 
                    setCursor(tool.getCursor(blocks, lastCollision.getContactPoint(), lastCollision.getContactNormal()));
                } else {
                    setCursor(null);
                }
            }           
        }
    }
}
