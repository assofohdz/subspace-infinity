/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.tool;

import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;

import com.simsilica.lemur.*;
import com.simsilica.mathd.*;

import com.simsilica.blocked.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MiniBlockTool implements Tool {

    private int blockType = 1;
    private int altBlockType = 0;

    private Node cursor;
    private Spatial miniBlock;
    private Spatial eraserBlock;

    public MiniBlockTool() {

        cursor = new Node("cursor");

        float size = 0.25f;
        WireBox box = new WireBox(size * 0.5f, size * 0.5f, size * 0.5f);
        Geometry geom = new Geometry("miniBlock", box);
        ColorRGBA color = new ColorRGBA(1, 1, 0, 0.5f);
        Material mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        geom.setMaterial(mat);

        this.miniBlock = geom;

        Box solidBox = new Box(size * 0.501f, size * 0.501f, size * 0.501f);
        geom = new Geometry("eraserBlock", solidBox);
        color = new ColorRGBA(1, 1, 1, 0.5f);
        mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

        Texture texture = GuiGlobals.getInstance().loadTexture("Textures/x-block.png", false, false);
        mat.setTexture("ColorMap", texture);

        geom.setMaterial(mat);

        this.eraserBlock = geom;

        cursor.attachChild(miniBlock);
        cursor.attachChild(eraserBlock);
    }

    public void setBlockType( int type ) {
        this.blockType = type;
    }

    public int getBlockType() {
        return blockType;
    }

    public void setAltType( int type ) {
        this.altBlockType = type;
    }

    public int getAltType() {
        return altBlockType;
    }

    @Override
    public Spatial getCursor( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        Vec3i eraserLoc = blocks.getBlockLocation(worldPos, normal);
        if( loc == null && eraserLoc == null ) {
            return null;
        }

        if( loc != null ) {
            Vector3f pos = blocks.getWorldPosition(loc);
            miniBlock.setLocalTranslation(pos);
            miniBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            miniBlock.setCullHint(Spatial.CullHint.Always);
        }

        if( eraserLoc != null && eraserLoc.y >= 0 ) {
            Vector3f pos = blocks.getWorldPosition(eraserLoc);
            eraserBlock.setLocalTranslation(pos);
            eraserBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            eraserBlock.setCullHint(Spatial.CullHint.Always);
        }

        return cursor;
    }

    @Override
    public void alternate( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Add a block
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        if( loc != null ) {
            blocks.setBlock(loc, blockType);
        }
    }

    @Override
    public void main( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Remove a block
        Vec3i loc = blocks.getBlockLocation(worldPos, normal);
        if( loc != null ) {
            blocks.setBlock(loc, altBlockType);
        }
    }

    @Override
    public void combo( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Replace a block
        Vec3i loc = blocks.getBlockLocation(worldPos, normal);
        if( loc != null ) {
            blocks.setBlock(loc, blockType);
        }
    }

}
