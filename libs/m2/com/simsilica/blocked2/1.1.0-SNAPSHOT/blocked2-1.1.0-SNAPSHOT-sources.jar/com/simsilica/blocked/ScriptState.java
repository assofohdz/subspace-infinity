/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;
import javax.script.*;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.collect.*;
import com.google.common.io.Files;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.value.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class ScriptState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ScriptState.class);

    private ScriptEngine engine;
    private Bindings mainBindings;

    private VersionedList<File> scripts = new VersionedList<>();
    private ListBox<File> scriptsList;

    public ScriptState() {
    }

    public void setBinding( String name, Object value ) {
        mainBindings.put(name, value);
    }

    protected void executeScript() {
        File script = scriptsList.getSelectedItem();
        log.info("Selected:" + script);
        executeScript(script);
    }

    protected void executeScript( String script ) {
        File dir = BlockEdConfig.getInstance().getScriptsDir();
        executeScript(new File(dir, script));
    }

    protected void executeScript( File script ) {
        try {
            String contents = Files.toString(script, Charsets.UTF_8);
            log.info("contents:" + contents);

            Bindings bindings = new NestedBindings(mainBindings); //engine.createBindings();
            //bindings.putAll(mainBindings);
            bindings.put("log", LoggerFactory.getLogger(Files.getNameWithoutExtension(script.getName())));

            engine.eval(contents, bindings);
        } catch( Exception e ) {
            log.error("Error evaluating:" + script, e);
        }
    }

    protected void executeStartupScript( File script ) {
        try {
            String contents = Files.toString(script, Charsets.UTF_8);
            log.info("contents:" + contents);

            Bindings bindings = new NestedBindings(mainBindings); //engine.createBindings();
            //bindings.putAll(mainBindings);
            bindings.put("log", LoggerFactory.getLogger(Files.getNameWithoutExtension(script.getName())));

            engine.eval(contents, bindings);
        } catch( Exception e ) {
            log.error("Error evaluating:" + script, e);
        }
    }

    @Override
    protected void initialize( Application app ) {

        ScriptEngineManager mgr = new ScriptEngineManager();
        this.engine = mgr.getEngineByExtension("groovy");
        log.info("Engine:" + engine);
        if( engine == null ) {
            throw new RuntimeException("No groovy script engine found");
        }
        this.mainBindings = engine.createBindings();
        mainBindings.put("scripts", this);
        mainBindings.put("app", getApplication());
        mainBindings.put("config", BlockEdConfig.getInstance());

        Container main = new Container();
        getState(MainMenuState.class).getTabs().addTab("Scripts", main);

        loadScripts();
        scriptsList = main.addChild(new ListBox<File>(scripts));
        scriptsList.setCellRenderer(new DefaultValueRenderer<File>() {
                protected String valueToString( File value ) {
                    return value == null ? "null" : Files.getNameWithoutExtension(value.getName());
                }
            });

        main.addChild(new ActionButton(new CallMethodAction(this, "executeScript")));

        // If scripts state is always last in the stack then this is good
        // enough.  If we ever want something more complicated then we may
        // need to enqueue it.
        runStartupScripts();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    protected void runStartupScripts() {
        // Init scripts are project relative
        File dir = BlockEdConfig.getInstance().getProjectDir();
        for( String s : BlockEdConfig.getInstance().getStartupScripts() ) {
            if( !s.toLowerCase().endsWith(".groovy") ) {
                log.warn("Script type not supported:" + s);
                continue;
            }
            File f = new File(dir, s);
            executeStartupScript(f);
        }
    }

    protected void loadScripts() {
        File dir = BlockEdConfig.getInstance().getScriptsDir();
        if( !dir.exists() ) {
            return;
        }
        for( File f : dir.listFiles() ) {
            if( f.isDirectory() ) {
                continue;
            }
            if( !f.getName().toLowerCase().endsWith(".groovy") ) {
                continue;
            }
            //String name = f.getName().substring(0, f.getName().length() - ".groovy".length());
            //scripts.add(name);
            scripts.add(f);
        }
    }

    private class NestedBindings extends AbstractMap<String, Object> implements Bindings {
        private Map<String, Object> properties = new HashMap<>();
        private Bindings parent;

        public NestedBindings( Bindings parent ) {
            this.parent = parent;
        }

        @Override
        public Object put( String key, Object value ) {
            return properties.put(key, value);
        }

        //@Override
        //public void putAll( Map<String, Object> m ) {
        //    properties.putAll(m);
        //}

        @Override
        public Set<Map.Entry<String, Object>> entrySet() {
            return Sets.union(properties.entrySet(), parent.entrySet());
        }
    }
}
