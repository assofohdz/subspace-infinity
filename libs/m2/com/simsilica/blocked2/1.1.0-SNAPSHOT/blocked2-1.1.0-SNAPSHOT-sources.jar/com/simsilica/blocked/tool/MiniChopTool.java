/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.tool;

import org.slf4j.*;

import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;

import com.simsilica.lemur.*;
import com.simsilica.mathd.*;

import com.simsilica.blocked.*;
import com.simsilica.mblock.*;
import com.simsilica.mblock.phys.*;
import com.simsilica.mblock.phys.collision.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MiniChopTool implements Tool {
    static Logger log = LoggerFactory.getLogger(MiniChopTool.class);

    private Node cursor;
    private Spatial eraserBlock;
    private Collider[] colliders;
    private SimilarShapeIndex shapeIndex;

    public MiniChopTool() {

        BlockType[] types = BlockTypeIndex.getTypes();
        this.colliders = new ColliderFactories(true).createColliders(types);

        this.shapeIndex = new SimilarShapeIndex(types, colliders);

        cursor = new Node("cursor");

        float size = 0.25f / 4;

        Box solidBox = new Box(size * 0.501f, size * 0.501f, size * 0.501f);
        Geometry geom = new Geometry("eraserBlock", solidBox);
        ColorRGBA color = new ColorRGBA(1, 1, 1, 0.5f);
        Material mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        //mat.getAdditionalRenderState().setDepthTest(false);
        cursor.setQueueBucket(Bucket.Translucent);

        Texture texture = GuiGlobals.getInstance().loadTexture("Textures/x-block.png", false, false);
        mat.setTexture("ColorMap", texture);

        geom.setMaterial(mat);

        this.eraserBlock = geom;

        cursor.attachChild(eraserBlock);
    }

    @Override
    public void setBlockType( int type ) {
    }

    @Override
    public Spatial getCursor( BlockState blocks, Vector3f worldPos, Vector3f normal ) {

//log.info("getCursor(" + worldPos + ")");

        Vec3i blockLoc = blocks.getBlockLocation(worldPos, normal);
        if( blockLoc == null ) {
            return null;
        }

        //int cell = blocks.getBlock(blockLoc);
        int cell = blocks.getCells().getCell(blockLoc.x, blockLoc.y, blockLoc.z, 0);
//log.info("blockLoc:" + blockLoc + " cell:" + cell);
        int type = MaskUtils.getType(cell);
//log.info("cell:" + cell + "  type:" + type + "  blockType:" + BlockTypeIndex.get(type));
        if( colliders[type] == null ) {
            return null;
        }

        Collider collider = colliders[type];
        ShapeSignature sig = ColliderUtils.calculateShapeSignature(collider, 0.125);
//log.info("sig:" + sig);


        Vector3f v = blocks.getBlocksSpatial().localToWorld(blockLoc.toVector3f(), null);
//        v.subtract(normal.mult(0.0625f));
        Vector3f relative = worldPos.subtract(v);

        int x = (int)((relative.x * 4 * 4) - (normal.x * 0.5));
        int y = (int)((relative.y * 4 * 4) - (normal.y * 0.5));
        int z = (int)((relative.z * 4 * 4) - (normal.z * 0.5));

//log.info("isSet:" + sig.isSet(x, y, z));
        if( !sig.isSet(x, y, z) ) {
            return null;
        }

//log.info("subblock:" + x + ", " + y+ ", " + z + "  relative:" + relative.mult(16) + " n:" + normal);

        relative.x = x * 0.0625f;
        relative.y = y * 0.0625f;
        relative.z = z * 0.0625f;

        eraserBlock.setLocalTranslation(v.add(relative).add(0.03125f, 0.03125f, 0.03125f));

/*
        if( loc != null ) {
            Vector3f pos = blocks.getWorldPosition(loc);
            miniBlock.setLocalTranslation(pos);
            miniBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            miniBlock.setCullHint(Spatial.CullHint.Always);
        }

        if( eraserLoc != null && eraserLoc.y >= 0 ) {
            Vector3f pos = blocks.getWorldPosition(eraserLoc);
            eraserBlock.setLocalTranslation(pos);
            eraserBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            eraserBlock.setCullHint(Spatial.CullHint.Always);
        }
*/

        return cursor;
    }

    @Override
    public void alternate( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
    }

    @Override
    public void main( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        log.info("main(" + blocks + ", " + worldPos + ", " + normal + ")");

        Vec3i blockLoc = blocks.getBlockLocation(worldPos, normal);
        if( blockLoc == null ) {
            return;
        }

        int cell = blocks.getCells().getCell(blockLoc.x, blockLoc.y, blockLoc.z, 0);
//log.info("blockLoc:" + blockLoc + " cell:" + cell);
        int type = MaskUtils.getType(cell);
        BlockType blockType = BlockTypeIndex.get(type);
//log.info("cell:" + cell + "  type:" + type + "  blockType:" + BlockTypeIndex.get(type));
        if( colliders[type] == null ) {
            return;
        }

        Collider collider = colliders[type];
        ShapeSignature sig = ColliderUtils.calculateShapeSignature(collider, 0.125);
//log.info("sig:" + sig);

        Vector3f v = blocks.getBlocksSpatial().localToWorld(blockLoc.toVector3f(), null);
        Vector3f relative = worldPos.subtract(v);

        int x = (int)((relative.x * 4 * 4) - (normal.x * 0.5));
        int y = (int)((relative.y * 4 * 4) - (normal.y * 0.5));
        int z = (int)((relative.z * 4 * 4) - (normal.z * 0.5));

        ShapeSignature find = sig.clone();
        find.unset(x, y, z);

        int newTypeIndex = shapeIndex.findSimilar(blockType, find);
        log.info("newType:" + newTypeIndex + "  type:" + BlockTypeIndex.get(newTypeIndex));

        blocks.setBlock(blockLoc, newTypeIndex);
    }

    @Override
    public void combo( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
    }

}
