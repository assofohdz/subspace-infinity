/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TagSetButton extends Button implements VersionedObject<Set<String>> {
    static Logger log = LoggerFactory.getLogger(TagSetButton.class);
 
    private static Joiner joiner = Joiner.on(", ");
 
    private long version;   
    private Set<String> tags;
    
    public TagSetButton( Set<String> tags ) {
        super(joiner.join(tags));
        this.tags = tags;
    }
 
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public Set<String> getObject() {
        return tags;
    }
    
    @Override
    public VersionedReference<Set<String>> createReference() {
        return new VersionedReference<>(this);
    }
 
    public void setTags( Set<String> tags ) {
log.info("setTags(" + tags + ")  existing:" + this.tags);    
        if( this.tags == tags ) {
            return;
        }
        if( Objects.equals(this.tags, tags) ) {
            return;
        }
        this.tags = tags;
        version++;
        resetText();
    }
    
    public Set<String> getTags() {
        return tags;
    }
    
    @Override
    protected void runClick() {
        super.runClick();        
        GetStringDialog dialog = new GetStringDialog("Edit Tags", "Tags:", joiner.join(this.tags), (tags) -> {
                updateTags(tags);
            });
        dialog.show();
    }
    
    protected void updateTags( String tags ) {
        log.info("updateTags(" + tags + ")");        
        String[] array = tags.split("\\s*,\\s*");
        this.tags.clear();
        for( String s : array ) {
            if( Strings.isNullOrEmpty(s) ) {
                continue;
            }        
            this.tags.add(s);
        }
        version++;
        resetText();
    }
    
    protected void resetText() {
        setText(joiner.join(this.tags));
    }
}
