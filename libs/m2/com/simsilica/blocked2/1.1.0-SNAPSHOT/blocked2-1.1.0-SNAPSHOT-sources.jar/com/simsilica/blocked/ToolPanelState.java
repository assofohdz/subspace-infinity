/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.event.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.Texture.MagFilter;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.input.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.blocked.tool.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ToolPanelState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ToolPanelState.class);

    private static final ColorRGBA TRANSPARENT = new ColorRGBA(0, 0, 0, 0);

    private Panel mainWindow;
    private TabbedPanel tabs;
    private Container toolPanel;

    private Map<BlockName, BlockType> typeIndex = new HashMap<>();
    private Map<BlockType, Integer> valueIndex = new HashMap<>();

    private BlockNameSelector nameSelector;
    private VersionedReference<BlockName> selectedNameRef;

    private FluidSelector fluidSelector;
    private VersionedReference<FluidInfo> fluidInfoRef;

    private VersionedHolder<BlockType> selectedType = new VersionedHolder<>();
    private VersionedReference<BlockType> selectionRef = selectedType.createReference();

    private ColorRGBA toolSelectedColor = new ColorRGBA(0.5f, 0.9f, 0.9f, 0.75f);
    private ColorRGBA toolUnselectedColor = new ColorRGBA(0.4f, 0.6f, 0.6f, 0.4f);
    private Tool currentTool;
    private Tool[] tools;
    private FluidTool fluidTool;
    private ActionButton[] toolButtons;
    private int toolIndex = 0;
    private InputHandler inputHandler = new InputHandler();

    public ToolPanelState() {
    }

    public TabbedPanel getTabs() {
        return tabs;
    }

    public void focusEdit() {
        for( TabbedPanel.Tab tab : tabs.getTabs() ) {
            if( tab.getContents() == toolPanel ) {
                tabs.setSelectedTab(tab);
                break;
            }
        }
    }

    protected void selectMiniTool() {
        toolIndex = 0;
        refreshTool();
    }

    protected void select2x2Tool() {
        toolIndex = 1;
        refreshTool();
    }

    protected void select4x4Tool() {
        toolIndex = 2;
        refreshTool();
    }

    protected void selectFluidTool() {
        toolIndex = 3;
        refreshTool();
    }

    protected void selectMiniChopperTool() {
        toolIndex = 4;
        refreshTool();
    }

    protected void rotate90() {
        CellArray original = getState(BlockState.class).getCells();
        CellArray rotated = CellUtils.rotate(original, 1);

        // Note: fluid rotation is not yet supported.  FIXME

        // Copy the data back
        original.clear();
        CellUtils.copy(rotated, 0, 0, 0, original, 0, 0, 0, original.getSizeX(), original.getSizeY(), original.getSizeZ());
        MaskUtils.calculateSideMasks(original);
        getState(BlockState.class).invalidate();
    }

    protected void mirrorX() {
        CellArray original = getState(BlockState.class).getCells();
        CellArray rotated = CellUtils.mirrorX(original);

        // Note: fluid mirroring is not yet supported.  FIXME

        // Copy the data back
        original.clear();
        CellUtils.copy(rotated, 0, 0, 0, original, 0, 0, 0, original.getSizeX(), original.getSizeY(), original.getSizeZ());
        MaskUtils.calculateSideMasks(original);
        getState(BlockState.class).invalidate();
    }

    protected void mirrorZ() {
        CellArray original = getState(BlockState.class).getCells();
        CellArray rotated = CellUtils.mirrorZ(original);

        // Note: fluid mirroring is not yet supported.  FIXME

        // Copy the data back
        original.clear();
        CellUtils.copy(rotated, 0, 0, 0, original, 0, 0, 0, original.getSizeX(), original.getSizeY(), original.getSizeZ());
        MaskUtils.calculateSideMasks(original);
        getState(BlockState.class).invalidate();
    }


    protected void createPart() {
        getState(PartDbState.class).createPart();
    }

    protected void setBlockType( BlockType type ) {
        log.info("setBlockType(" + (type == null ? null : type.getName()) + ")");
        if( type == null ) {
            return;
        }
        int index = valueIndex.get(type);
        for( Tool tool : tools ) {
            tool.setBlockType(index);
        }
        selectedType.setObject(type);

        // Reset the fluid type to be accurate
        fluidTool.setBlockType(fluidInfoRef.get().getType());
    }

    protected void nextSubtype() {
        if( currentTool == fluidTool ) {
            fluidSelector.nextLevel();
        } else {
            nameSelector.nextRotation();
        }
    }

    protected void previousSubtype() {
        if( currentTool == fluidTool ) {
            fluidSelector.previousLevel();
        } else {
            nameSelector.previousRotation();
        }
    }

    protected Node getGuiNode() {
        return ((Main)getApplication()).getGuiNode();
    }

    @Override
    protected void initialize( Application app ) {

        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        ToolFunctions.initializeDefaultMappings(inputMapper);
        inputMapper.addStateListener(inputHandler,
                                     ToolFunctions.F_SUBTOOL,
                                     ToolFunctions.F_PICK);

        tools = new Tool[] {
            new MiniBlockTool(),
            new MultiBlockTool(2, 2, 2),
            new MultiBlockTool(4, 4, 4),
            fluidTool = new FluidTool(),
            new MiniChopTool()
        };

        tabs = new TabbedPanel();
        mainWindow = new RollupPanel("Editors", tabs, (String)null);
        mainWindow.getControl(GuiControl.class).addListener(new ReshapeListener(mainWindow));

        toolPanel = new Container();
        tabs.addTab("Blocks", toolPanel);

        int index = 0;
        for( BlockType type : BlockTypeIndex.getTypes() ) {
            if( type == null ) {
                index++;
                continue;
            }
            BlockName name = type.getName();
            typeIndex.put(name, type);
            valueIndex.put(type, index);
            index++;
        }

        Container blockTypes = new Container();
        RollupPanel rollup = toolPanel.addChild(new RollupPanel("Block Types", blockTypes, null));

        nameSelector = blockTypes.addChild(new BlockNameSelector());
        selectedNameRef = nameSelector.createBlockNameReference();

        Container fluidTypes = new Container();
        rollup = toolPanel.addChild(new RollupPanel("Fluid Types", fluidTypes, null));
        fluidSelector = fluidTypes.addChild(new FluidSelector());
        fluidInfoRef = fluidSelector.createFluidInfoReference();

        Container toolTypes = new Container();
        toolPanel.addChild(new RollupPanel("Tools", toolTypes, null));

        toolButtons = new ActionButton[] {
            new ActionButton(new CallMethodAction("", this, "selectMiniTool")),
            new ActionButton(new CallMethodAction("", this, "select2x2Tool")),
            new ActionButton(new CallMethodAction("", this, "select4x4Tool")),
            new ActionButton(new CallMethodAction("", this, "selectFluidTool")),
            new ActionButton(new CallMethodAction("x", this, "selectMiniChopperTool"))
        };

        float iconScale = 0.5f;
        toolButtons[0].setIcon(new IconComponent("Textures/mini-block-icon.png", iconScale, 0, 0, 0.01f, false));
        toolButtons[1].setIcon(new IconComponent("Textures/2x2-block-icon.png", iconScale, 0, 0, 0.01f, false));
        toolButtons[2].setIcon(new IconComponent("Textures/4x4-block-icon.png", iconScale, 0, 0, 0.01f, false));
        toolButtons[3].setIcon(new IconComponent("Textures/fluid-icon.png", iconScale, 0, 0, 0.01f, false));

        toolTypes.addChild(toolButtons[0]);
        toolTypes.addChild(toolButtons[1], 1);
        toolTypes.addChild(toolButtons[2], 2);
        toolTypes.addChild(toolButtons[3], 3);
        toolTypes.addChild(toolButtons[4], 4);

        setBlockType(BlockTypeIndex.get(1));

        refreshTool();

        Container buttons = toolPanel.addChild(new Container());
        buttons.addChild(new ActionButton(new CallMethodAction("Rotate 90", this, "rotate90")));
        buttons.addChild(new ActionButton(new CallMethodAction("Mirror X", this, "mirrorX")));
        buttons.addChild(new ActionButton(new CallMethodAction("Mirror Z", this, "mirrorZ")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "createPart")));
    }

    protected void refreshTool() {
        for( int i = 0; i < toolButtons.length; i++ ) {
            ActionButton b = toolButtons[i];
            if( i == toolIndex ) {
                ((ColoredComponent)b.getBackground()).setColor(toolSelectedColor);
            } else {
                ((ColoredComponent)b.getBackground()).setColor(toolUnselectedColor);
            }
        }
        currentTool = tools[toolIndex];
        getState(CursorState.class).setTool(currentTool);
    }

    @Override
    protected void cleanup( Application app ) {
        InputMapper inputMapper = GuiGlobals.getInstance().getInputMapper();
        inputMapper.removeStateListener(inputHandler,
                                     ToolFunctions.F_SUBTOOL,
                                     ToolFunctions.F_PICK);
    }

    @Override
    protected void onEnable() {
        GuiGlobals.getInstance().getInputMapper().activateGroup(ToolFunctions.TOOL);

        getGuiNode().attachChild(mainWindow);

        Vector3f pref = mainWindow.getPreferredSize();

        mainWindow.setLocalTranslation(getApplication().getCamera().getWidth() - pref.x - 16,
                                       getApplication().getCamera().getHeight() - 16,
                                       0);
    }

    @Override
    public void update( float tpf ) {
        if( selectedNameRef.update() ) {
            BlockType type = typeIndex.get(selectedNameRef.get());
            if( type != null ) {
                setBlockType(type);
            }
        }
        if( fluidInfoRef.update() ) {
            fluidTool.setBlockType(fluidInfoRef.get().getType());
        }
        if( selectionRef.update() ) {
            nameSelector.setBlockName(selectionRef.get().getName());
        }
    }

    @Override
    protected void onDisable() {
        GuiGlobals.getInstance().getInputMapper().deactivateGroup(ToolFunctions.TOOL);
        //tabs.removeFromParent();
    }

    // This actually belongs on CursorState but the wiring to next/previous
    // is a little trickier since the tools don't know about rotation and stuff.
    private class InputHandler implements AnalogFunctionListener, StateFunctionListener {

        @Override
        public void valueChanged( FunctionId func, InputState value, double tpf ) {
            log.info("valueChanged(" + func + ", " + value + ", " + tpf + ")");
            if( func == ToolFunctions.F_SUBTOOL ) {
                if( value == InputState.Positive ) {
                    nextSubtype();
                } else if( value == InputState.Negative ) {
                    previousSubtype();
                }
            } else if( func == ToolFunctions.F_PICK ) {
                if( value == InputState.Positive ) {
                    Vec3i loc = getState(CursorState.class).getLastBlockLocation();
                    if( loc != null ) {
                        int type = MaskUtils.getType(getState(BlockState.class).getBlock(loc));
                        setBlockType(BlockTypeIndex.get(type));
                    }
                }
            }
        }

        @Override
        public void valueActive( FunctionId func, double value, double tpf ) {
            log.info("valueActive(" + func + ", " + value + ", " + tpf + ")");
        }
    }

    private class ReshapeListener extends AbstractGuiControlListener {

        private int minWidth = 250;

        private Panel window;

        public ReshapeListener( Panel window ) {
            this.window = window;
        }

        @Override
        public void reshape( GuiControl source, Vector3f pos, Vector3f size ) {
log.info("reshape(" + pos + ", " + size + ")");
            // Note: reshape() is about the layout within the container
            // and not its position on screen... so moving the popup isn't
            // really a recursive operation.
            Vector3f windowSize = window.getSize();
            if( windowSize.x < minWidth ) {
                windowSize.x = minWidth;
                // Note: this does result in a recursive call... so be careful
                // that we always create stable results.
                window.setSize(windowSize);
            }
            Vector3f loc = new Vector3f(getApplication().getCamera().getWidth() - windowSize.x - 10,
                                        getApplication().getCamera().getHeight() - 20,
                                        0);
            window.setLocalTranslation(loc);
        }
    }
}

