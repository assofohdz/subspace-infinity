/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.nio.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.material.RenderState.FaceCullMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.util.*;

import com.simsilica.lemur.LayerComparator;

import com.simsilica.mblock.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class DebugLightValuesState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(DebugLightValuesState.class);

    private Node blocksNode;
    private CellArray cells;
    private CellArray lightData;
    private int size;
 
    private ColorRGBA sunColor = new ColorRGBA(1, 1, 0.8f, 1);
    
    private Node debugView;
    private Material debugMaterial1;
    private Material debugMaterial2;

    public DebugLightValuesState() {
        setEnabled(false);        
    }
    
    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }

    public void updateLightData( Node blocksNode, CellArray cells, CellArray lightData, int size ) {
        this.blocksNode = blocksNode;
        this.cells = cells;
        this.lightData = lightData;
        this.size = size;
 
        debugView.setLocalTranslation(blocksNode.getLocalTranslation());
        debugView.setLocalScale(blocksNode.getLocalScale());
        
        if( !isEnabled() ) {
            return;
        }
        regenerateDebugView();
    }
        
    @Override
    protected void initialize( Application app ) {
        debugView = new Node();
        LayerComparator.setLayer(debugView, 1);
        
        AssetManager assets = app.getAssetManager();
        debugMaterial1 = new Material(assets, "MatDefs/UnshadedBillboard.j3md");
        debugMaterial1.setColor("Color", new ColorRGBA(1, 1, 1, 0.8f));
        debugMaterial1.setTexture("ColorMap", assets.loadTexture("Textures/hex-matrix.png"));
        debugMaterial1.setBoolean("VertexColor", true);
        debugMaterial1.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        debugMaterial1.getAdditionalRenderState().setFaceCullMode(FaceCullMode.Off);
        
        debugMaterial2 = new Material(assets, "MatDefs/UnshadedBillboard.j3md");
        debugMaterial2.setColor("Color", new ColorRGBA(1, 1, 1, 0.2f));
        debugMaterial2.setTexture("ColorMap", assets.loadTexture("Textures/hex-matrix.png"));
        debugMaterial2.setBoolean("VertexColor", true);
        debugMaterial2.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        debugMaterial2.getAdditionalRenderState().setDepthTest(false);
        debugMaterial2.getAdditionalRenderState().setFaceCullMode(FaceCullMode.Off);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(debugView);
        regenerateDebugView();
    }
    
    @Override
    protected void onDisable() {
        debugView.removeFromParent();
    }
    
    protected void regenerateDebugView() {
        debugView.detachAllChildren();

        List<LightEntry> lights = new ArrayList<>();
        
        for( int x = 0; x < size; x++ ) {
            for( int y = 0; y < size; y++ ) {
                for( int z = 0; z < size; z++ ) {
                    int light = lightData.getCell(x, y, z);
                    if( (light & 0xffff) == 0 || light == LightUtils.DIRECT_SUN ) {
                        continue; 
                    }
                    
                    lights.add(new LightEntry(new Vector3f(x, y, z), light));
                }
            }
        }

        QuadBuffer quads = new QuadBuffer(lights.size() * 4);        
        
        int baseIndex = 0;
        float radius = 0.05f;
        float offset = 0.05f;  
        for( LightEntry light : lights ) {
            Vector3f center = light.pos.add(0.5f, 0.5f, 0.5f);
            quads.add(offset, center, new Vector3f(-radius, radius, 0), sunColor, LightUtils.sun(light.light));   
            quads.add(offset, center, new Vector3f(radius, radius, 0), ColorRGBA.Red, LightUtils.red(light.light));   
            quads.add(offset, center, new Vector3f(-radius, -radius, 0), ColorRGBA.Green, LightUtils.green(light.light));   
            quads.add(offset, center, new Vector3f(radius, -radius, 0), ColorRGBA.Blue, LightUtils.blue(light.light));   
        }
               
        Mesh mesh = quads.createMesh();

        Geometry geom;
        geom = new Geometry("debugLights1", mesh); // new Box(1, 1, 1));
        geom.setMaterial(debugMaterial1);
        geom.setQueueBucket(Bucket.Transparent);
        debugView.attachChild(geom);
        
        geom = new Geometry("debugLights2", mesh); //new Box(1, 1, 1));
        geom.setMaterial(debugMaterial2);
        geom.setQueueBucket(Bucket.Translucent);
        debugView.attachChild(geom);
        
        
        log.info("world bounds:" + geom.getWorldBound());
    }
    
    private class QuadBuffer {

        private int quadCount;
        private FloatBuffer pb;
        private FloatBuffer colors;
        private FloatBuffer uvs;
        private IntBuffer inds;
        
        private int baseIndex = 0;

        public QuadBuffer( int quadCount ) {
            this.quadCount = quadCount;

            int triCount = quadCount * 2; 
            int vertCount = quadCount * 4;
            
            pb = BufferUtils.createFloatBuffer(vertCount * 3);
            colors = BufferUtils.createFloatBuffer(vertCount * 4);
            uvs = BufferUtils.createFloatBuffer(vertCount * 4);
            inds = BufferUtils.createIntBuffer(triCount * 3);
        }
        
        public Mesh createMesh() {
            Mesh mesh = new Mesh();
            mesh.setBuffer(VertexBuffer.Type.Position, 3, pb);
            mesh.setBuffer(VertexBuffer.Type.Color, 4, colors);
            mesh.setBuffer(VertexBuffer.Type.TexCoord, 4, uvs);
            mesh.setBuffer(VertexBuffer.Type.Index, 3, inds);
            mesh.updateBound();
            return mesh;
        }

        public void add( float radius, Vector3f pos, Vector3f offset, ColorRGBA color, int light ) {
        
            float s1 = (light % 4) * 0.25f;
            float t1 = 0.75f - ((light / 4) * 0.25f);
            float s2 = s1 + 0.25f;
            float t2 = t1 + 0.25f;
 
            // x margins
            s1 += (13f/256);
            s2 -= (12f/256);
            
            // y margins: 3, 3
            t1 += (3f/256);
            t2 -= (3f/256);
        
            Vector3f v1;
            Vector3f v2;
            v1 = pos;
            //v1 = pos.add(-radius, -radius, 0);            
            v2 = offset.add(-radius, -radius, 0);
            
            pb.put(v1.x).put(v1.y).put(v1.z);
            colors.put(color.r).put(color.g).put(color.b).put(color.a);
            uvs.put(s1).put(t1).put(v2.x).put(v2.y);
            
            //v1 = pos.add(radius, -radius, 0);
            v2 = offset.add(radius, -radius, 0);
            pb.put(v1.x).put(v1.y).put(v1.z);
            colors.put(color.r).put(color.g).put(color.b).put(color.a);
            uvs.put(s2).put(t1).put(v2.x).put(v2.y);

            //v1 = pos.add(radius, radius, 0);
            v2 = offset.add(radius, radius, 0);
            pb.put(v1.x).put(v1.y).put(v1.z);
            colors.put(color.r).put(color.g).put(color.b).put(color.a);
            uvs.put(s2).put(t2).put(v2.x).put(v2.y);
            
            //v1 = pos.add(-radius, radius, 0);
            v2 = offset.add(-radius, radius, 0);
            pb.put(v1.x).put(v1.y).put(v1.z);
            colors.put(color.r).put(color.g).put(color.b).put(color.a);
            uvs.put(s1).put(t2).put(v2.x).put(v2.y);
            
            inds.put(baseIndex + 0).put(baseIndex + 1).put(baseIndex + 2);
            inds.put(baseIndex + 0).put(baseIndex + 2).put(baseIndex + 3);
            
            baseIndex += 4;
        }        

        
    }
    
    private class LightEntry {
        Vector3f pos;
        int light;
        
        public LightEntry( Vector3f pos, int light ) {
            this.pos = pos;
            this.light = light;
        }
    }
}
