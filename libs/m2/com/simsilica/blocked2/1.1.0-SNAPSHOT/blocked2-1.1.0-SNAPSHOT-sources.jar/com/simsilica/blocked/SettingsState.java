/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.blocked;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.KeyInput;

import com.simsilica.lemur.Container;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.Label;
import com.simsilica.lemur.TabbedPanel;
import com.simsilica.lemur.component.BorderLayout;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.fx.sky.SkySettingsState;


/**
 *
 *
 *  @author    Paul Speed
 */
public class SettingsState extends BaseAppState {
    
    public static final FunctionId F_SETTINGS = new FunctionId("Show Settings");
        
    private Container mainWindow;
    private Container mainContents; 
 
    private TabbedPanel tabs;
    
    private boolean originalCursorEventsEnabled = false;
    
    public SettingsState() {
        //setEnabled(false);
    }
 
    public static void initializeDefaultMappings( InputMapper inputMapper ) {
        inputMapper.map(F_SETTINGS, KeyInput.KEY_TAB);
    }
 
    public void toggleEnabled() {
        setEnabled(!isEnabled());
    }
    
    public TabbedPanel getParameterTabs() {
        return tabs;
    }

    @Override
    protected void initialize( Application app ) {
        GuiGlobals.getInstance().getInputMapper().addDelegate(F_SETTINGS, this, "toggleEnabled");
        
        mainWindow = new Container(new BorderLayout(), new ElementId("window"), "glass");
        mainWindow.addChild(new Label("Settings", mainWindow.getElementId().child("title.label"), "glass"),
                            BorderLayout.Position.North); 
        mainWindow.setLocalTranslation(10, app.getCamera().getHeight() - 10, 0);        
 
        mainContents = mainWindow.addChild(new Container(mainWindow.getElementId().child("contents.container"), "glass"),
                                                        BorderLayout.Position.Center); 
 
        tabs = new TabbedPanel("glass");       
        mainContents.addChild(tabs);
 
        /*PhysicsState physics = getState(PhysicsState.class);
        ShootState shoot = getState(ShootState.class);
        Container physicsSettings = new Container();
        tabs.addTab("Physics", physicsSettings);
        //physicsSettings.addChild(new Label("Projectiles", new ElementId("window.title.label")));               
        //physicsSettings.addChild(shoot.getSettings());
        physicsSettings.addChild(new Label("Simulation", new ElementId("window.title.label")));               
        physicsSettings.addChild(physics.getSimulationSettings());
        physicsSettings.addChild(new Label("New Bodies", new ElementId("window.title.label")));               
        physicsSettings.addChild(physics.getBodySettings());
        physicsSettings.addChild(new Label("Contacts", new ElementId("window.title.label")));               
        physicsSettings.addChild(physics.getContactSettings());
        physicsSettings.addChild(new Label("Annealing", new ElementId("window.title.label")));               
        physicsSettings.addChild(physics.getAnnealingSettings());

        tabs.addTab("Projectiles", shoot.getSettings());*/
                
        SkySettingsState skySettings = getState(SkySettingsState.class);
        getParameterTabs().addTab("Sky", skySettings.getSettings());        
                
    }
    
    @Override
    protected void cleanup( Application app ) {
        GuiGlobals.getInstance().getInputMapper().removeDelegate(F_SETTINGS, this, "toggleEnabled");
    }
    
    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getGuiNode().attachChild(mainWindow);
    }
    
    @Override
    protected void onDisable() {
        mainWindow.removeFromParent();
    }
}


