/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.Axis;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.list.*;
import com.simsilica.lemur.style.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;
import com.simsilica.mgen.*;

// For testing stuff
import com.simsilica.mblock.*;
import com.simsilica.mblock.io.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PartDbState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PartDbState.class);

    private Container window;

    private PartsDatabase partsDb;
    private ListBox<StructurePartInfo> partsList;

    private VersionedReference<List<StructurePartInfo>> partsRef;
    private VersionedList<StructurePartInfo> filteredList = new VersionedList<>();
    private StructureFilter filter = new StructureFilter();

    private TextField filterEditor;

    private VersionedReference<Integer> selectionRef;
    private StructurePartInfo selectedPart;
    private VersionedReference<StructurePartInfo> selectedPartRef;
    private StructurePartEditor partEditor;

    private PartIndex partIndex;
    //private TypeCombiner typeCombiner = new TypeCombiner();
    private IntCombiner typeCombiner = new TypeCombiner();

    public PartDbState() {
    }

    public void setTypeCombiner( IntCombiner typeCombiner ) {
        this.typeCombiner = typeCombiner;
    }

    public IntCombiner getTypeCombiner() {
        return typeCombiner;
    }

    public void createPart() {
        log.info("Create part");

        GetStringDialog dialog = new GetStringDialog("Create Part", "Tags:", "", (tags) -> {
                doCreate(tags.trim());
            });
        dialog.show();
    }

    protected void doCreate( String name ) {
        //String name = partName.getText().trim();
        if( Strings.isNullOrEmpty(name) ) {
            return;
        }
        String[] tags = name.split("\\s*,\\s*");
        if( tags.length == 0 ) {
            return;
        }
        StructurePartInfo part = partsDb.createPart(tags);
        File f = partsDb.getPartFile(part);
        getState(FileState.class).saveBlocks(f);
        partsDb.save();
        focus();

        try {
            detectMasks(part);
        } catch( Exception e ) {
            log.error("Error detecting masks", e);
        }
        partIndex = null;
    }

    public void focus() {
        TabbedPanel tabs = getState(ToolPanelState.class).getTabs();
        for( TabbedPanel.Tab tab : tabs.getTabs() ) {
            if( tab.getContents() == window ) {
                tabs.setSelectedTab(tab);
                break;
            }
        }
    }

    protected void edit() {
        StructurePartInfo part = partsList.getSelectedItem();
        if( part == null ) {
            return;
        }
        if( getState(FileState.class).hasChanged() ) {
            getState(OptionPanelState.class).show("Abandon Changes?",
                                                "Really abandon current changes?",
                                                new CallMethodAction("Yes", this, "editSelected"),
                                                new EmptyAction("No"),
                                                new EmptyAction("Cancel"));
        } else {
            editSelected();
        }
    }

    protected void editSelected() {
        StructurePartInfo part = partsList.getSelectedItem();
        if( part == null ) {
            return;
        }
        File f = partsDb.getPartFile(part);
        getState(FileState.class).loadFile(f);
        //getState(ToolPanelState.class).focusEdit();

        // not perfect because we can't really tell when they edit or
        // save it but it's pretty good because if they start to edit the part
        // then they will either save it and click one of the generate buttons
        // (thus regenerating the index) or click and edit other things.  Either
        // way eventually we lead to a case where either the old part index was
        // ok and we falsely cleared it (no big deal) or we regenerate it.
        partIndex = null;
    }

    protected void setSelectedPart( StructurePartInfo part ) {
        if( part == selectedPart ) {
            return;
        }
        selectedPart = part;
        partEditor.setObject(part);
        if( selectedPart != null ) {
            selectedPartRef = part.createReference();
        } else {
            selectedPartRef = null;
        }
    }

    @Override
    protected void initialize( Application app ) {
        partsDb = PartsDatabase.create(BlockEdConfig.getInstance().getStructureDbDir());
        partsRef = partsDb.getParts().createReference();

        window = new Container();
        getState(ToolPanelState.class).getTabs().addTab("Parts DB", window);

        Container container;
        window.addChild(new Label("Parts:"));
        container = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.First, FillMode.Last)));
        filterEditor = container.addChild(new TextField(""));
        container.addChild(new ActionButton(new CallMethodAction("Filter", this, "parseFilter")));

        //partsList = window.addChild(new ListBox<>(partsDb.getParts()));
        partsList = window.addChild(new ListBox<>(filteredList));
        partsList.setCellRenderer(new StructurePartInfoRenderer());
        selectionRef = partsList.getSelectionModel().createSelectionReference();

//log.info("partsList cell renderer:" + partsList.getCellRenderer());
//log.info("element ID:" + ((DefaultCellRenderer)partsList.getCellRenderer()).getElementId());

        Container buttons = window.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction("Edit Blocks", this, "edit")));
        buttons.addChild(new ActionButton(new CallMethodAction("Detect Masks", this, "detectMasks")));


        container = new Container();
        window.addChild(new RollupPanel("Part:", container, null));

        partEditor = container.addChild(new StructurePartEditor());

        buttons = container.addChild(new Container());

        container.addChild(new ActionButton(new CallMethodAction("Log Rotations", this, "logRotations")));
        container.addChild(new ActionButton(new CallMethodAction("Test Rotations", this, "testRotations")));
        //container.addChild(new ActionButton(new CallMethodAction("Test Stuff", this, "test4")));
        //container.addChild(new ActionButton(new CallMethodAction("Test Stuff 2", this, "test5")));

        resetFilteredList();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    public void update( float tpf ) {
        if( partsRef.update() ) {
            resetFilteredList();
            partIndex = null;
        }
        if( selectionRef.update() ) {
            setSelectedPart(partsList.getSelectedItem());
        }
        if( selectedPartRef != null && selectedPartRef.update() ) {
            partsDb.save();
            // So it will refresh the tags, etc... maybe even resort.
            //StructurePartInfo part = partsList.getSelectedItem();
            //partsList.setModel(null);
            //partsList.setModel(partsDb.getParts());
            //int i = partsDb.getParts().indexOf(part);
            //if( i >= 0 ) {
            //    partsList.getSelectionModel().setSelection(i);
            //}
            // The above works but does not great things.  It's a lot
            // of work just to get things to repaint and points out some
            // styling bugs where the item style somehow gets reset.
            // Trying something else to trigger a repaint
            partsList.getModel().add(null);
            partsList.getModel().remove(null);
            partIndex = null;
        }
    }

    @Override
    protected void onDisable() {
    }

    protected void parseFilter() {
        String text = filterEditor.getText().trim();
        filter.clear();
        String[] tags = text.split("\\s*,\\s*");
        for( String tag : tags ) {
            tag = tag.trim();
            if( tag.length() > 0 ) {
                if( tag.charAt(0) == '!' ) {
                    filter.exclude(tag.substring(1));
                } else {
                    filter.include(tag);
                }
            }
        }
        resetFilteredList();
    }

    protected void resetFilteredList() {
        StructurePartInfo selected = partsList.getSelectedItem();
        filteredList.clear();
        for( StructurePartInfo part : partsDb.getParts() ) {
            if( filter.apply(part) ) {
                filteredList.add(part);
            }
        }
        //filteredList.addAll(partsDb.getParts());
        int i = filteredList.indexOf(selected);
        if( i >= 0 ) {
            partsList.getSelectionModel().setSelection(i);
        } else {
            partsList.getSelectionModel().clear();
        }
    }

    protected void detectMasks() throws Exception {
        StructurePartInfo part = partsList.getSelectedItem();
        if( part == null ) {
            return;
        }
        detectMasks(part);
    }

    protected void detectMasks( StructurePartInfo part ) throws Exception {
        // Load the blocks
        File f = partsDb.getPartFile(part);
        FileInputStream fIn = new FileInputStream(f);
        BlockObject blocks = BlocksFileFormat.readBlocks(fIn, true);

        log.info("Cells:" + blocks.cells);
        log.info("Fluids:" + blocks.fluids);
        CellArray cells = blocks.cells;
        CellArray fluids = blocks.fluids;

        int[] open = new int[6];
        int[] required = new int[6];

        // Find the max/min locations of the cell grid within the blocks space.
        // This is the bounary of the part that is 'on the grid'.
        Vec3i max = blocks.cells.getSize().clone();
        Vec3i min = max.subtract(part.getGridSize());
        max.subtractLocal(1,1,1);
        min.y = 0;
        max.y = Math.min(3, max.y);

        log.info("min:" + min + "  max:" + max);
        Vec3i pos = new Vec3i();

        int requiredType = FluidTypeIndex.findType(new FluidName("required"));

        Vec3i right = null;
        Vec3i up = null;

        for( int d = 0; d < 6; d++ ) {
            Direction dir = Direction.values()[d];
log.info("dir:"+ dir);

            // We actually want to make sure that each end of an axis matches and
            // isn't reflect.  So we'll pick consistent "right" and "up" for each
            // axis.  For the cardinal directions, we'll use the positive axes
            // for consistency... so east and south.
            Vec3i origin = new Vec3i();
            int upSize = 0;
            switch( dir ) {
                case North:
                    origin.set(max.x, min.y, min.z);
                    right = Direction.South.getRight();
                    up = Direction.South.getUp();
                    upSize = max.y + 1;
                    break;
                case South:
                    origin.set(max.x, min.y, max.z);
                    right = Direction.South.getRight();
                    up = Direction.South.getUp();
                    upSize = max.y + 1;
                    break;
                case East:
                    origin.set(max.x, min.y, min.z);
                    right = Direction.East.getRight();
                    up = Direction.East.getUp();
                    upSize = max.y + 1;
                    break;
                case West:
                    origin.set(min.x, min.y, min.z);
                    right = Direction.East.getRight();
                    up = Direction.East.getUp();
                    upSize = max.y + 1;
                    break;
                case Up:
                    origin.set(min.x, max.y, max.z);
                    right = Direction.Down.getRight();
                    up = Direction.Down.getUp();
                    upSize = max.z + 1;
                    break;
                case Down:
                    origin.set(min.x, min.y, max.z);
                    right = Direction.Down.getRight();
                    up = Direction.Down.getUp();
                    upSize = max.z + 1;
                    break;
            }
log.info("upSize:" + upSize);

            int openMask = 0;
            int reqMask = 0;
            for( int i = 0; i < 4; i++ ) {
                for( int j = 0; j < upSize; j++ ) {
                    pos.set(origin);
                    pos.addLocal(right.mult(i));
                    pos.addLocal(up.mult(j));

                    pos.x = Math.max(0, pos.x);
                    pos.z = Math.max(0, pos.z);
                    pos.x = Math.min(max.x, pos.x);
                    pos.z = Math.min(max.z, pos.z);

log.info("  [" + i+ "][" + j + "] = " + pos);
                    int val = cells.getCell(pos.x, pos.y, pos.z);
                    int type = MaskUtils.getType(val);

                    // If this is down then only consider double-height
                    // open... experimental trying to get stairs to stack
                    // properly.
                    if( dir == Direction.Down ) {
                        type = type + MaskUtils.getType(cells.getCell(pos.x, Math.min(max.y, pos.y+1), pos.z));
                    }

                    if( type == 0 ) {
                        openMask = openMask | ((0x1 << (3 - i)) << (j * 4));
                    }

                    if( fluids != null ) {
                        val = fluids.getCell(pos.x, pos.y, pos.z);
                        type = FluidUtils.getType(val);
                        if( type == requiredType ) {
                            reqMask = reqMask | ((0x1 << (3 - i)) << (j * 4));
                        }
                    }
                }
            }
log.info("  open:" + Integer.toBinaryString(openMask) + "  req:" + Integer.toBinaryString(reqMask));

            open[d] = openMask;
            required[d] = reqMask;

log.info("open:\n" + PartUtils.maskToString(openMask));
log.info("xReflect:\n" + PartUtils.maskToString(PartUtils.xReflect(openMask)));
log.info("yReflect:\n" + PartUtils.maskToString(PartUtils.yReflect(openMask)));

int[][] cellsTest = PartUtils.maskToCells(openMask);
for( int j = 0; j < 4; j++ ) {
    StringBuilder row = new StringBuilder();
    for( int i = 0; i < 4; i++ ) {
        row.append(cellsTest[i][j]);
    }
    log.info("[" + j + "]:" + row);
}
log.info("Cells test:\n" + PartUtils.maskToString(PartUtils.cellsToMask(cellsTest)));

int rot90 = PartUtils.rotate(openMask, 1);
int rot180 = PartUtils.rotate(openMask, 2);
int rot270 = PartUtils.rotate(openMask, -1);
int rotTest = PartUtils.rotate(rot90, -1);
log.info("rot90:\n" + PartUtils.maskToString(rot90));
log.info("rot180:\n" + PartUtils.maskToString(rot180));
log.info("rot270:\n" + PartUtils.maskToString(rot270));
log.info("original:\n" + PartUtils.maskToString(rotTest));


log.info("-------------");
log.info("req:\n" + PartUtils.maskToString(reqMask));
        }

        part.setOpenMasks(open);
        part.setRequiredMasks(required);

        if( fluids != null ) {
            List<Vec3i> preserved = new ArrayList<>();
            // Detect any cells marked for preserving
            int preserveType = FluidTypeIndex.findType(new FluidName("keep"));
            for( int i = 0; i < fluids.getSizeX(); i++ ) {
                for( int j = 0; j < fluids.getSizeY(); j++ ) {
                    for( int k = 0; k < fluids.getSizeZ(); k++ ) {
                        int val = fluids.getCell(i, j, k);
                        int type = FluidUtils.getType(val);
                        if( type == preserveType ) {
                            preserved.add(new Vec3i(i, j, k));
                        }
                    }
                }
            }
            if( !preserved.isEmpty() ) {
                part.setPreservedCells(preserved.toArray(new Vec3i[0]));
            }
        }

        partIndex = null;
    }

    protected void logRotations() throws Exception {
        log.info("logRotations");

        StructurePartInfo info = partsList.getSelectedItem();
        if( info == null ) {
            return;
        }
        PartIndex index = new PartIndex();
        Part original = partsDb.loadPart(info);
        index.indexPart(info, original);

        Map<PartTransform, Part> parts = index.getTransforms(info);
        for( PartTransform xform : PartTransform.values() ) {
            Part p = parts.get(xform);

            log.info("xform:" + xform);
            for( int i = 0; i < 6; i++ ) {
                Direction dir = Direction.values()[i];
                log.info("--" + dir);
                log.info("open:\n" + PartUtils.maskToString(p.getOpenMasks()[i]));
                log.info("required:\n" + PartUtils.maskToString(p.getRequiredMasks()[i]));
            }
        }
    }

    protected void testRotations() throws Exception {
        log.info("testRotations");

        StructurePartInfo info = partsList.getSelectedItem();
        if( info == null ) {
            return;
        }
        PartIndex index = new PartIndex();
        Part original = partsDb.loadPart(info);
        index.indexPart(info, original);

        Map<PartTransform, Part> parts = index.getTransforms(info);

        CellArray target = getState(BlockState.class).getCells();

        int x = 4;
        int z = 4;
        for( PartTransform xform : PartTransform.values() ) {
            Part p = parts.get(xform);

            p.insert(target, x, 0, z, typeCombiner);

            if( p.getPreservedCells() != null ) {
                Vec3i offset = p.getOffset();

                // Highlight the preserved blocks for testing
                for( Vec3i v : p.getPreservedCells() ) {
                    target.setCell(x + v.x - offset.x, v.y - offset.y, z + v.z - offset.z, 1);
                }
            }


            x += 8;
            if( x >= 32 ) {
                x = 4;
                z += 8;
            }

log.info("xform:" + xform);
for( int i = 0; i < 6; i++ ) {
    Direction dir = Direction.values()[i];
    log.info("--" + dir);
    log.info("open:\n" + PartUtils.maskToString(p.getOpenMasks()[i]));
    log.info("required:\n" + PartUtils.maskToString(p.getRequiredMasks()[i]));
}
        }


        Part rot90 = original.rotate(1);
Part p = rot90;
log.info("Raw rot90:");
for( int i = 0; i < 1; i++ ) {
    Direction dir = Direction.values()[i];
    log.info("--" + dir);
    log.info("open:\n" + PartUtils.maskToString(p.getOpenMasks()[i]));
    log.info("required:\n" + PartUtils.maskToString(p.getRequiredMasks()[i]));
}

        Part rot90MirrorX = rot90.mirrorX();
p = rot90MirrorX;
log.info("Raw rot90MirrorX:");
for( int i = 0; i < 1; i++ ) {
    Direction dir = Direction.values()[i];
    log.info("--" + dir);
    log.info("open:\n" + PartUtils.maskToString(p.getOpenMasks()[i]));
    log.info("required:\n" + PartUtils.maskToString(p.getRequiredMasks()[i]));
}

p = rot90;
log.info("Raw rot90:");
for( int i = 0; i < 1; i++ ) {
    Direction dir = Direction.values()[i];
    log.info("--" + dir);
    log.info("open:\n" + PartUtils.maskToString(p.getOpenMasks()[i]));
    log.info("required:\n" + PartUtils.maskToString(p.getRequiredMasks()[i]));
}

        MaskUtils.calculateSideMasks(target);
        getState(BlockState.class).invalidate();
    }

    protected void rebuildPartIndex() {
        long start = System.nanoTime();
        partIndex = new PartIndex();
        for( StructurePartInfo info : partsDb.getParts() ) {
            try {
                partIndex.indexPart(info, partsDb.loadPart(info));
            } catch( IOException e ) {
                throw new RuntimeException("Error loading part for:" + info, e);
            }
        }
        long end = System.nanoTime();
        log.info("Generated part index in:" + ((end-start)/1000000.0) + " ms");
    }

    protected PartIndex getPartIndex() {
        if( partIndex == null ) {
            rebuildPartIndex();
        }
        return partIndex;
    }

    protected void testFloor( FloorTemplate floor ) throws Exception {
        log.info("testFloor(" + floor + ")");

        long start, end;

        PartIndex index = getPartIndex();

        start = System.nanoTime();
        FloorReference floorRef = new FloorReference(floor.getName());

        Random rand = new Random(System.currentTimeMillis());

        FloorGenerator generator = floor.createGenerator(floorRef, partsDb.getParts(), index);
        generator.shuffle(rand);

        end = System.nanoTime();
        log.info("Generated templates in:" + ((end-start)/1000000.0) + " ms");

        start = System.nanoTime();
        Building building = new Building(floor.getSizeX(), 1, floor.getSizeZ());
        generator.generateFloor(building, 0, rand);
        generator.connect(building, 0, rand);

        end = System.nanoTime();
        log.info("Generated building in:" + ((end-start)/1000000.0) + " ms");


        CellArray target = getState(BlockState.class).getCells();
        target.clear();
        Vec3i base = new Vec3i(20 - floor.getSizeX() * 2, 0, 20 - floor.getSizeZ() * 2);

        start = System.nanoTime();
        building.insert(target, base.x, base.y, base.z, typeCombiner);
        end = System.nanoTime();
        log.info("Inserted floors in:" + ((end-start)/1000000.0) + " ms");


        MaskUtils.calculateSideMasks(target);
        getState(BlockState.class).invalidate();
    }

    public void testBuilding( BuildingTemplate buildingTemplate ) throws Exception {
        log.info("testBuilding(" + buildingTemplate + ")");

        try {
            Random rand = new Random(System.currentTimeMillis());

            PartIndex index = getPartIndex();
            long start, end;

            start = System.nanoTime();
            // Build a list of the parts available for this building
            // (could have also made a filtered iterable instead of copying
            TagPredicate tagRules = buildingTemplate.getTagRules();
            List<StructurePartInfo> parts = new ArrayList<>();
            for( StructurePartInfo info : partsDb.getParts() ) {
                if( tagRules.apply(info.getTags()) ) {
                    parts.add(info);
                }
            }

            Map<String, FloorTemplate> floorTemplates = getState(FloorDbState.class).getTemplates();

            end = System.nanoTime();
            log.info("Initialized indexes in:" + ((end-start)/1000000.0) + " ms");

            start = System.nanoTime();
            BuildingGenerator generator = buildingTemplate.createGenerator(floorTemplates, parts, index);
            generator.shuffle(rand);
            end = System.nanoTime();
            log.info("Created generators in:" + ((end-start)/1000000.0) + " ms");


            start = System.nanoTime();
            Building building = generator.generate(rand);
            end = System.nanoTime();
            log.info("Generated building in:" + ((end-start)/1000000.0) + " ms");

            CellArray target = getState(BlockState.class).getCells();
            target.clear();
            int xSize = building.getSizeX();
            int zSize = building.getSizeZ();
            Vec3i base = new Vec3i(20 - xSize * 2, 0, 20 - zSize * 2);

            start = System.nanoTime();
            building.insert(target, base.x, base.y, base.z, typeCombiner);
            end = System.nanoTime();
            log.info("Inserted floors in:" + ((end-start)/1000000.0) + " ms");

            MaskUtils.calculateSideMasks(target);
            getState(BlockState.class).invalidate();
        } catch( RuntimeException e ) {
            log.error("Error generating building", e);
            getState(OptionPanelState.class).showError("Error generating building", e);
        }
    }


    public void testBuildingOld( BuildingTemplate buildingTemplate ) throws Exception {
        log.info("testBuilding(" + buildingTemplate + ")");

        Random rand = new Random(System.currentTimeMillis());

        PartIndex index = getPartIndex();
        long start, end;

        start = System.nanoTime();
        // Build a list of the parts available for this building
        // (could have also made a filtered iterable instead of copying
        TagPredicate tagRules = buildingTemplate.getTagRules();
        List<StructurePartInfo> parts = new ArrayList<>();
        for( StructurePartInfo info : partsDb.getParts() ) {
            if( tagRules.apply(info.getTags()) ) {
                parts.add(info);
            }
        }

        // Build the floor generator list and calculate the
        // max size
        int xSize = 0;
        int ySize = buildingTemplate.getFloors().size();
        int zSize = 0;
        List<FloorGenerator> generators = new ArrayList<>();
        int y = 0;
        for( FloorReference ref : buildingTemplate.getFloors() ) {
            FloorTemplate template = getState(FloorDbState.class).findTemplate(ref.getFloor());
            if( template == null ) {
                log.warn("Template not found:" + template);
                continue;
            }
            FloorGenerator gen = template.createGenerator(ref, parts, index);
            gen.shuffle(rand);
            generators.add(gen);

            xSize = Math.max(xSize, template.getSizeX() + ref.getOffset().x);
            zSize = Math.max(zSize, template.getSizeZ() + ref.getOffset().z);

            y++;

            ySize = Math.max(ySize, y + ref.getOffset().y);
        }

        end = System.nanoTime();
        log.info("Created generators in:" + ((end-start)/1000000.0) + " ms");

        log.info("building size:" + xSize + ", " + ySize + ", " + zSize);

        start = System.nanoTime();
        Building building = new Building(xSize, ySize, zSize);
        for( int i = 0; i < generators.size(); i++ ) {
            FloorGenerator gen = generators.get(i);
            gen.generateFloor(building, i, rand);
            gen.connect(building, i, rand);
            //building.lock(i);
        }

        end = System.nanoTime();
        log.info("Generated building in:" + ((end-start)/1000000.0) + " ms");

        CellArray target = getState(BlockState.class).getCells();
        target.clear();
        Vec3i base = new Vec3i(20 - xSize * 2, 0, 20 - zSize * 2);

        start = System.nanoTime();
        building.insert(target, base.x, base.y, base.z, typeCombiner);
        end = System.nanoTime();
        log.info("Inserted floors in:" + ((end-start)/1000000.0) + " ms");

        MaskUtils.calculateSideMasks(target);
        getState(BlockState.class).invalidate();
    }

    protected void logFloor( FloorTemplate template ) {
        int xSize = template.getSizeX();
        int zSize = template.getSizeZ();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < zSize; j++ ) {
                log.info("slots[" + i + "][" + j + "] = " + template.getSlot(i, j));
            }
        }
    }

    private class TypeCombiner implements IntCombiner {

        private int brownCube = -1;

        public TypeCombiner() {
        }

        public int apply( int i1, int i2 ) {
            if( i1 == i2 ) {
                return i1;
            }
            if( i1 == 0 ) {
                return i2;
            }
            if( i2 == 0 ) {
                return i1;
            }

            // Hack in some known conversions for now
            i1 = MaskUtils.getType(i1);
            i2 = MaskUtils.getType(i2);
            if( i1 == i2 ) {
                return i1;
            }
            BlockType type1 = BlockTypeIndex.get(i1);
            BlockType type2 = BlockTypeIndex.get(i2);

            // type1 is the new type being inserted.
            // type2 is the existing type
            if( "cube".equals(type2.getName().getShape()) ) {
                return i2;
            }
            if( "cube".equals(type1.getName().getShape()) ) {
                return i1;
            }

            // type1[275]:brown:slab-up  type2[262]:brown:beam-up.0
            // type1[275]:brown:slab-up  type2[300]:brown:post.0
            // type1[275]:brown:slab-up  type2[303]:brown:post.3
            // type1[275]:brown:slab-up  type2[550]:roof:wedge.0
            if( "brown".equals(type1.getName().getBase()) ) {
                if( "slab-up".equals(type1.getName().getShape()) ) {
                    if( brownCube < 0 ) {
                        brownCube = BlockTypeIndex.findType(new BlockName("brown", "cube", null), 0);
                    }
                    return brownCube;
                }
            }

            // Also saw a case of a roof wedge and an inverted brown wedge... I think
            // type1[326]:brown:inv-wedge.0  type2[550]:roof:wedge.0
            if( "inv-wedge".equals(type1.getName().getShape()) && "wedge".equals(type2.getName().getShape()) ) {
                // Fill it in with whatever the cube of inv wedge is
                if( "brown".equals(type1.getName().getBase()) ) {
                    if( brownCube < 0 ) {
                        brownCube = BlockTypeIndex.findType(new BlockName("brown", "cube", null), 0);
                    }
                    return brownCube;
                }
                int type = BlockTypeIndex.findType(new BlockName(type1.getName().getBase(), "cube", null), 0);
                return type <= 0 ? i2 : type;
            }

log.info("type1[" + i1 + "]:" + type1.getName() + "  type2[" + i2 + "]:" + type2.getName());

            return i2;
        }
    }

    private class StructurePartInfoRenderer extends DefaultValueRenderer<StructurePartInfo> {
        public StructurePartInfoRenderer() {
            super(null, null);
        }

        @Override
        protected String valueToString( StructurePartInfo part ) {
            if( part == null ) {
                return null;
            }
            String result = String.valueOf(part.getTags());
            if( part.getFrequency() > 1 ) {
                result += " x" + part.getFrequency();
            }
            return result;
        }
    }

    private class StructureFilter implements Predicate<StructurePartInfo> {
        private Set<String> include = new HashSet<>();
        private Set<String> exclude = new HashSet<>();

        public void include( String tag ) {
            include.add(tag);
        }

        public void exclude( String tag ) {
            exclude.add(tag);
        }

        public void clear() {
            include.clear();
            exclude.clear();
        }

        public boolean apply( StructurePartInfo info ) {
            if( info == null ) {
                return false;
            }
            if( info.hasAny(exclude) ) {
                return false;
            }
            if( include.isEmpty() ) {
                return true;
            }
            return info.hasAll(include);
        }
    }
}

