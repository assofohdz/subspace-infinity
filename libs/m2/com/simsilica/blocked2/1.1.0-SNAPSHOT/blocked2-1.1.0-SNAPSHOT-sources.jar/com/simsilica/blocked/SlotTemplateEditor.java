/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class SlotTemplateEditor extends Container {
    static Logger log = LoggerFactory.getLogger(SlotTemplateEditor.class);
    
    private SlotTemplate slot;
    private VersionedReference<SlotTemplate> slotRef;     
    
    private Checkbox[] xformChecks;
    private List<VersionedReference<Boolean>> xformRefs;
    
    private TagPredicateEditor tagRulesEditor;
 
    private static SlotTemplate clipboard;
       
    public SlotTemplateEditor() {
        Container checks = addChild(new Container());
        PartTransform[] xforms = PartTransform.values();
        xformChecks = new Checkbox[xforms.length];
        xformRefs = new ArrayList<>();
        for( int i = 0; i < xforms.length; i++ ) {
            PartTransform xform = xforms[i];
            int x = i / 4;
            int y = i % 4;
            xformChecks[i] = checks.addChild(new Checkbox(xform.toString()), y, x);
            xformRefs.add(xformChecks[i].getModel().createReference()); 
        }
 
        addChild(new Label("Slot Tag Rules:"));
        tagRulesEditor = addChild(new TagPredicateEditor());
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "copy")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "paste")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "clear")));
    }
 
    protected void copy() {
        clipboard = slot == null ? null : slot.clone();
    }
    
    protected void paste() {
        if( slot == null ) {
            return;
        }
        slot.set(clipboard);
    }
    
    protected void clear() {
        slot.clear();
        refreshEditor();
    }
    
    public void setObject( SlotTemplate slot ) {
        if( slot == null ) {
            slotRef = null;
        } else {
            slotRef = slot.createReference();
        }
        this.slot = slot;        
        refreshEditor();
    }
    
    public SlotTemplate getObject() {
        return slot;
    }
     
    @Override   
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( slot == null ) {
            return;
        }
        for( int i = 0; i < xformRefs.size(); i++ ) {        
            if( xformRefs.get(i).update() ) {
                Boolean b = xformRefs.get(i).get();
                if( b ) {
                    slot.getTransforms().add(PartTransform.values()[i]);
                } else {
                    slot.getTransforms().remove(PartTransform.values()[i]);
                }
                slot.invalidate(); 
            }
        }
        if( slotRef != null && slotRef.update() ) {
            refreshEditor();
        }
    }    
    
    protected void refreshEditor() {
        if( slot != null ) {
            for( int i = 0; i < xformChecks.length; i++ ) {
                PartTransform xform = PartTransform.values()[i];
                xformChecks[i].setChecked(slot.getTransforms().contains(xform));
            }
            tagRulesEditor.setObject(slot.getTagRules());
        } else {
            tagRulesEditor.setObject(null);
            for( int i = 0; i < xformChecks.length; i++ ) {
                xformChecks[i].setChecked(false);
            }
        }
    }

}
