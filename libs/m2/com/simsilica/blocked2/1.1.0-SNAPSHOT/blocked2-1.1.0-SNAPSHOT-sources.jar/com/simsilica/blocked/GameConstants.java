/*
 * $Id$
 * 
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.blocked;


/**
 *
 *
 *  @author    Paul Speed
 */
public class GameConstants {

    public static final String GAME_NAME = "Block-Ed Plus";
}



