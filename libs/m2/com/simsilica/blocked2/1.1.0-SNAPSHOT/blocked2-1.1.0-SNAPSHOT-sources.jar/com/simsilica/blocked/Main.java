/*
 * $Id$
 *
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.blocked;

import java.util.prefs.Preferences;

import com.jme3.app.*;
import com.jme3.app.state.ScreenshotAppState;
import com.jme3.input.KeyInput;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.material.Material;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.system.AppSettings;
import com.jme3.texture.Texture;

import com.simsilica.event.EventBus;
import com.simsilica.input.*;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.OptionPanelState;
import com.simsilica.lemur.anim.AnimationState;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.BaseStyles;
import com.simsilica.state.*;
import com.simsilica.util.LogAdapter;


import com.simsilica.fx.LightingState;
import com.simsilica.fx.sky.SkyState;
import com.simsilica.fx.sky.SkySettingsState;
import com.simsilica.mathd.*;

import com.simsilica.tool.*;


/**
 *  The main bootstrap class.
 *
 *  @author    Paul Speed
 */
public class Main extends SimpleApplication {

    private static final BlockEdConfig CONFIG = BlockEdConfig.getInstance(); 

    public static int gridSize;
    public static int cameraDistance;
    public static int yOffset;

    private Node logo;

    private String preload = null;

    public static void main( String... args ) throws Exception {
        System.out.println(GameConstants.GAME_NAME);

        gridSize = CONFIG.getStartupSettingInt("gridSize", 10);

        // Make sure JUL logging goes to our log4j configuration
        LogAdapter.initialize();

        Main main = new Main(args);

        AppSettings settings = new AppSettings(true);

        // Set some defaults that will get overwritten if
        // there were previously saved settings from the last time the user
        // ran.
        settings.setWidth(1280);
        settings.setHeight(720);
        settings.setVSync(true);

        settings.load(GameConstants.GAME_NAME);
        settings.setTitle(GameConstants.GAME_NAME);
        //settings.setSettingsDialogImage("/sim-eth-es-splash-512.png");
        settings.setUseJoysticks(true);
        /*
        try {
            BufferedImage[] icons = new BufferedImage[] {
                    ImageIO.read( TreeEditor.class.getResource( "/-icon-128.png" ) ),
                    ImageIO.read( TreeEditor.class.getResource( "/-icon-32.png" ) ),
                    ImageIO.read( TreeEditor.class.getResource( "/-icon-16.png" ) )
                };
            settings.setIcons(icons);
        } catch( IOException e ) {
            log.warn( "Error loading globe icons", e );
        }*/

        main.setSettings(settings);

        main.start();
    }

    public Main( String... args ) {
        super(new StatsAppState(), new DebugKeysAppState(), new BasicProfilerState(false),
              new OptionPanelState(), // from Lemur
              new DebugHudState(), // SiO2 utility class
              new CameraState(),
              new GridState(gridSize),
              new CursorState(),
              new BlockState(gridSize),
              new ToolPanelState(),
              new FileState(),
              new PartDbState(),
              new FloorDbState(),
              new BuildingDbState(),
              new OrbitCameraState(CONFIG.getStartupSettingInt("cameraDistance", 12), 
                                   new Vector3f(0, CONFIG.getStartupSettingInt("yOffset", 1), 0)),
              new MovementState(),
              new LightingState(),
              new SkyState(new ColorRGBA(0.3f, 0.5f, 0.1f, 1), true),
              new SkySettingsState(),
              new PostProcessingState(),
              new DebugNormalsState(),
              new DebugLightValuesState(),
              new MainMenuState(),
              new CameraToggleState(),
              new HelpState(),
              new ScriptState(),
              new ScreenshotAppState("", System.currentTimeMillis()));

        if( args.length > 0 ) {
            preload = args[0];
        } else {
            // For testing... saves me a half dozen clicks sometimes
            preload = null; //"alpha-test.blocks";
        }

    }

    public void simpleInitApp() {

        setPauseOnLostFocus(false);
        setDisplayFps(false);
        setDisplayStatView(false);

        GuiGlobals.initialize(this);

        GuiGlobals globals = GuiGlobals.getInstance();
        BaseStyles.loadGlassStyle();
        globals.getStyles().setDefaultStyle("glass");

        InputMapper inputMapper = globals.getInputMapper();
        MainAppFunctions.initializeDefaultMappings(inputMapper);
        //CameraMovementFunctions.initializeDefaultMappings(inputMapper);
        OrbitCameraFunctions.initializeDefaultMappings(inputMapper);
        ToolFunctions.initializeDefaultMappings(inputMapper);
        stateManager.getState(MovementState.class).setEnabled(false);

        // Just a temporary hookup
        //FunctionId drawCircle = new FunctionId("drawCircle");
        //inputMapper.map(drawCircle, KeyInput.KEY_C, KeyInput.KEY_RSHIFT);
        //inputMapper.map(drawCircle, KeyInput.KEY_C, KeyInput.KEY_LSHIFT);
        //inputMapper.addDelegate(drawCircle, stateManager.getState(BlockState.class), "drawCircle");

        // Get rid of the default close mapping in InputManager
        if( inputManager.hasMapping(INPUT_MAPPING_EXIT) ) {
            inputManager.deleteMapping(INPUT_MAPPING_EXIT);
        }

        if( preload != null ) {
            stateManager.getState(FileState.class).setPreload(preload);
        }
    }
}


