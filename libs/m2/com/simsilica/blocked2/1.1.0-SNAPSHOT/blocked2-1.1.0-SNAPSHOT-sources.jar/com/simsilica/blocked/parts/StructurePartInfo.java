/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.parts;

import java.util.*;

import org.slf4j.*;

import com.simsilica.lemur.core.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.CellArray;
import com.simsilica.mgen.Part;

/**
 *
 *
 *  @author    Paul Speed
 */
public class StructurePartInfo implements VersionedObject<StructurePartInfo>, TaggedObject {
    static Logger log = LoggerFactory.getLogger(StructurePartInfo.class);
 
    private long version;
    private String blocksFile;
    private SortedSet<String> tags = new TreeSet<>();
    private Vec3i offset = new Vec3i();
    private Vec3i gridSize = new Vec3i(4, 3, 4);
    private int[] openMasks;
    private int[] reqMasks;
    private Vec3i[] preserved;
    private int frequency = 1;
    private boolean impassable;
    
    public StructurePartInfo( String blocksFile, String... tags ) {
        this.blocksFile = blocksFile;
        this.tags.addAll(Arrays.asList(tags));
    }
 
    public Part createPart( CellArray cells, Vec3i offset ) {
        return new Part(new HashSet<>(tags), cells, offset, 
                        openMasks, reqMasks, preserved, impassable);
    }
    
    protected void upgrade() {
        if( offset == null ) {
            offset = new Vec3i();
        }
        if( gridSize == null ) {
            gridSize = new Vec3i(4, 3, 4);
        }
        if( frequency == 0 ) {
            frequency = 1;
        }
    }
    
    public String getBlocksFile() {
        return blocksFile;
    }
    
    public boolean addTag( String tag ) {
        if( tags.add(tag) ) {
            version++;
            return true;
        }
        return false;
    }
 
    public boolean removeTag( String tag ) {
        if( tags.remove(tag) ) {
            version++;
            return true;
        }
        return false;
    }
    
    @Override
    public Set<String> getTags() {
        return tags;
    }
 
    @Override
    public boolean hasTag( String tag ) {
        return tags.contains(tag);
    }
 
    @Override   
    public boolean hasAny( Iterable<String> any ) {
        for( String s : any ) {
            if( tags.contains(s) ) {
                return true;
            }
        }
        return false; 
    }

    @Override
    public boolean hasAll( Collection<String> all ) {
        return tags.containsAll(all);
    }
 
    public void setFrequency( int frequency ) {
        if( this.frequency == frequency ) {
            return;
        }
        this.frequency = frequency;
        version++;
    }
 
    public int getFrequency() {
        return frequency;
    }
    
    public void setImpassable( boolean impassable ) {
        if( impassable == this.impassable ) {
            return;
        }
        this.impassable = impassable;
        version++;
    }
    
    public boolean isImpassable() {
        return impassable;
    }
 
    public void setOffset( Vec3i offset ) {
        if( offset == null ) {
            throw new IllegalArgumentException("Offset cannot be null");
        }
        if( Objects.equals(offset, this.offset) ) {
            return;
        }
        this.offset.set(offset);
        version++;
    }
    
    public Vec3i getOffset() {
        return offset;
    } 

    public void setGridSize( Vec3i gridSize ) {
        if( gridSize == null ) {
            throw new IllegalArgumentException("GridSize cannot be null");
        }
        if( Objects.equals(gridSize, this.gridSize) ) {
            return;
        }
        this.gridSize.set(gridSize);
        version++;
    }
    
    public Vec3i getGridSize() {
        return gridSize;
    } 
 
    public void setOpenMasks( int[] openMasks ) {
        this.openMasks = openMasks;
        version++;
    }
    
    public int[] getOpenMasks() {
        return openMasks;
    }
    
    public void setRequiredMasks( int[] reqMasks ) {
        this.reqMasks = reqMasks;
        version++;
    }
    
    public int[] getRequiredMasks() {
        return reqMasks;
    }
 
    public void setPreservedCells( Vec3i... preserved ) {
        this.preserved = preserved;
        version++;
    }
    
    public Vec3i[] getPreservedCells() {
        return preserved;
    }
    
    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public StructurePartInfo getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<StructurePartInfo> createReference() {
        return new VersionedReference<>(this);
    }
    
    public String toString() {
        return "StructurePartInfo[blocks:" + blocksFile + ", tags:" + tags + "]"; 
    }
}
