/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.event.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.Texture.MagFilter;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.event.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.input.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.blocked.tool.*;

/**
 *  Composite UI element that allows block selection by
 *  base name, shape name, and rotation.
 *
 *  @author    Paul Speed
 */
public class BlockNameSelector extends Container {
    static Logger log = LoggerFactory.getLogger(BlockNameSelector.class);

    private SortedSetMultimap<String, String> shapeNameIndex = MultimapBuilder.treeKeys().treeSetValues().build();
    private SortedSetMultimap<String, Integer> rotationIndex = MultimapBuilder.treeKeys().treeSetValues().build();

    private VersionedList<String> baseNames = new VersionedList<>();
    private VersionedList<String> shapeNames = new VersionedList<>();
    private VersionedList<Integer> rotations = new VersionedList<>();  

    private Selector<String> baseSelector;
    private VersionedReference<String> baseRef;
    private Selector<String> shapeSelector;
    private VersionedReference<String> shapeRef;
    private Spinner<Integer> rotationSpinner;
    private VersionedReference<Integer> rotationRef;
    
    private VersionedHolder<BlockName> selectedName = new VersionedHolder<>();

    public BlockNameSelector() {
        reindex();
        
        addChild(new Label("Base:"));
        baseSelector = addChild(new Selector(baseNames), 1);
        baseRef = baseSelector.createSelectedItemReference();
 
        addChild(new Label("Shape:"));
        shapeSelector = addChild(new Selector(shapeNames), 1);
        shapeRef = shapeSelector.createSelectedItemReference();
        
        addChild(new Label("Rotation:"));
        rotationSpinner = addChild(new Spinner(SequenceModels.listSequence(rotations)), 1);
        rotationRef = rotationSpinner.getModel().createReference();
        
        setNameSelection(BlockTypeIndex.get(1).getName());
    }    
    
    public void reindex() {
        shapeNameIndex.clear();
        rotationIndex.clear();
        
        for( BlockType type : BlockTypeIndex.getTypes() ) {
            if( type == null ) {
                continue;
            }
            BlockName name = type.getName();
            shapeNameIndex.put(name.getBase(), name.getShape());
            if( name.getRotation() != null ) {
                rotationIndex.put(name.getBase() + ":" + name.getShape(), name.getRotation());
            } else {
                rotationIndex.put(name.getBase() + ":" + name.getShape(), -1);
            }
        }
        baseNames.clear();
        baseNames.addAll(shapeNameIndex.keySet());    
    }

    public void setBlockName( BlockName name ) {
        if( selectedName.updateObject(name) ) {
            setNameSelection(name);
        }
    }
    
    public BlockName getBlockName() {
        return selectedName.getObject();
    }
    
    public VersionedReference<BlockName> createBlockNameReference() {
        return selectedName.createReference();
    }

    public void nextRotation() {
        rotationSpinner.nextValue();
    }
    
    public void previousRotation() {
        rotationSpinner.previousValue();
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        
        boolean changed = false;
        if( baseRef.update() ) {
            changed = true;
        }
        if( shapeRef.update() ) {
            changed = true;
        }
        if( rotationRef.update() ) {
            changed = true;
        }
        if( changed ) {
            updateNameSelection();
        }
    }
 
    /**
     *  Builds a valid block name from the current UI selections.
     */
    protected BlockName getNameSelection() {
        String base = baseSelector.getSelectedItem();
        String shape = shapeSelector.getSelectedItem();
        if( base == null || shape == null ) {
            return null;
        }
        if( !shapeNameIndex.get(base).contains(shape) ) {
            shape = Iterables.getFirst(shapeNameIndex.get(base), null);
        }
        Integer rotation = rotationSpinner.getValue();
        if( rotation == null ) {
            rotation = -1;
        }
        String key = base + ":" + shape;
        if( !rotationIndex.get(key).contains(rotation) ) {
            rotation = Iterables.getFirst(rotationIndex.get(key), -1);
        }  
        return new BlockName(base, shape, rotation == -1 ? null : rotation); 
    }
 
    protected void updateNameSelection() {
        // Need to make the selection match the UI... but
        // the selection may affect the values available in the
        // rest of the UI
        //BlockName current = selectedName.getObject();
        BlockName uiName = getNameSelection();        
        if( uiName == null ) {
            log.info("Null selection");
            return;
        }
 
        if( selectedName.updateObject(uiName) ) {        
            setNameSelection(uiName);
        } else {       
            log.info("Already selected");
        }
    }
    
    protected void setNameSelection( BlockName name ) {
log.info("setNameSelection(" + name + ")");    
        String base = baseSelector.getSelectedItem();
        String shape = shapeSelector.getSelectedItem();
        
        // Make sure the sublists are up to date
        Set<String> nameShapes = shapeNameIndex.get(name.getBase());
        if( !nameShapes.containsAll(shapeNames) || nameShapes.size() != shapeNames.size() ) {
            shapeNames.clear();            
            shapeNames.addAll(nameShapes);
log.info("reset shapes:" + shapeNames);        
        } 
        String key = name.getBase() + ":" + name.getShape();
        Set<Integer> nameRotations = rotationIndex.get(key);
        if( !nameRotations.containsAll(rotations) || nameRotations.size() != rotations.size() ) {
            rotations.clear();
            rotations.addAll(rotationIndex.get(key));            
log.info("reset rotations:" + rotations);        
        } 
        
        // Then set the selections... which should already
        // be valid
        baseSelector.setSelectedItem(name.getBase());
        shapeSelector.setSelectedItem(name.getShape());
log.info("Setting rotation to:" + (name.getRotation() == null ? -1 : name.getRotation()));         
        rotationSpinner.setValue(name.getRotation() == null ? -1 : name.getRotation());
    }
    
}


