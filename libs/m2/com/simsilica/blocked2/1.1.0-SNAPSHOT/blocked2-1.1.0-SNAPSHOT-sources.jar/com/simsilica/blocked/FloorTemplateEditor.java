/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;
import com.jme3.texture.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.grid.*;
import com.simsilica.lemur.text.*;
import com.simsilica.lemur.value.*;

import com.simsilica.blocked.parts.*;

import com.simsilica.mblock.Direction;

import com.simsilica.tool.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FloorTemplateEditor extends Container {
    static Logger log = LoggerFactory.getLogger(FloorTemplateEditor.class);

    private FloorTemplate floor;
    private VersionedReference<FloorTemplate> floorRef;

    private TagSetButton tagsButton;
    private VersionedReference<Set<String>> tagsRef;

    private TextField nameEditor;
    private VersionedReference<DocumentModel> nameRef;

    private Vec3iEditor sizeEditor;
    private Spinner<Double> blockHeightEditor;

    private VersionedReference<Double> blockHeightRef;
    private VersionedReference<Vec3i> sizeRef;

    private Spinner<Double> gridSpacingEditor;
    private VersionedReference<Double> gridSpacingRef;

    private TagPredicateEditor tagRulesEditor;

    private GridPanel slotGrid;
    private SlotTemplate selectedSlot;
    private Vec3i selectedPos = new Vec3i(-1, 0, -1);
    private long selectionVersion = 0;
    private SlotTemplateEditor slotEditor;
    private List<VersionedReference<SlotTemplate>> slotRefs;

    private Map<EnumSet<PartTransform>, Texture> iconIndex = new HashMap<>();

    private ColorRGBA selectedColor = new ColorRGBA(0.5f, 0.9f, 0.9f, 1);
    private ColorRGBA unselectedColor = new ColorRGBA(0.4f, 0.4f, 0.4f, 1);

    public FloorTemplateEditor() {

        GuiGlobals globals = GuiGlobals.getInstance();

        // Load some icons that represent standard transform combinations
        iconIndex.put(EnumSet.allOf(PartTransform.class),
                      globals.loadTexture("Textures/xform-all.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.MirrorX),
                      globals.loadTexture("Textures/xform-mirrorx.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.MirrorZ),
                      globals.loadTexture("Textures/xform-mirrorz.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.None, PartTransform.MirrorX),
                      globals.loadTexture("Textures/xform-none-mirrorx.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.None, PartTransform.Rot90MirrorX),
                      globals.loadTexture("Textures/xform-none-rot90mirrox.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.None),
                      globals.loadTexture("Textures/xform-none.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot180, PartTransform.MirrorZ),
                      globals.loadTexture("Textures/xform-rot180-mirrorz.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot180, PartTransform.Rot90MirrorZ),
                      globals.loadTexture("Textures/xform-rot180-rot90mirrorz.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot180),
                      globals.loadTexture("Textures/xform-rot180.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot270, PartTransform.MirrorZ),
                      globals.loadTexture("Textures/xform-rot270-mirrorz.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot270, PartTransform.Rot90MirrorX),
                      globals.loadTexture("Textures/xform-rot270-rot90mirrorx.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot270),
                      globals.loadTexture("Textures/xform-rot270.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot90, PartTransform.MirrorX),
                      globals.loadTexture("Textures/xform-rot90-mirrorx.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot90, PartTransform.Rot90MirrorZ),
                      globals.loadTexture("Textures/xform-rot90-rot90mirrorz.png", false, false));
        iconIndex.put(EnumSet.of(PartTransform.Rot90),
                      globals.loadTexture("Textures/xform-rot90.png", false, false));


        Container properties = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.Last, FillMode.Last)));
        properties.addChild(new Label("Name:"));
        nameEditor = properties.addChild(new TextField(""), 1);
        nameRef = nameEditor.getDocumentModel().createReference();

        properties.addChild(new Label("Tags:"));
        tagsButton = properties.addChild(new TagSetButton(new TreeSet<String>()), 1);
        tagsRef = tagsButton.createReference();

        properties.addChild(new Label("Block height:"));

        SequenceModel<Double> model = SequenceModels.rangedSequence(
                                                new DefaultRangedValueModel(1, 20, 0),
                                                1, 1);
        blockHeightRef = model.createReference();
        DefaultValueRenderer<Double> renderer = ValueRenderers.formattedRenderer("%.0f", "error");
        blockHeightEditor = properties.addChild(new Spinner<>(model, renderer), 1);
        blockHeightEditor.setValueEditor(ValueEditors.doubleEditor("%.0f"));

        properties.addChild(new Label("Size:"));
        sizeEditor = properties.addChild(new Vec3iEditor(true, false, true), 1);
        sizeRef = sizeEditor.createReference();

        // We cannot edit sizes without causing crashes right now.  What to do about
        // resizes in the grid layout is an open question with no easy answers and so
        // it's better for the user to just copy a floor to a new size.
        sizeEditor.setEnabled(false);

        properties.addChild(new Label("Grid spacing:"));
        // We don't have nice int range models so we'll just use a double model
        // for now.
        model = SequenceModels.rangedSequence(new DefaultRangedValueModel(2, 7, 4),
                                              1, 1);
        gridSpacingRef = model.createReference();
        gridSpacingEditor = properties.addChild(new Spinner<>(model, renderer), 1);
        gridSpacingEditor.setValueEditor(ValueEditors.doubleEditor("%.0f"));

        addChild(new Label("Floor Tag Rules:"));
        tagRulesEditor = addChild(new TagPredicateEditor());

        addChild(new Label("Slots:"));
        slotGrid = addChild(new GridPanel(new SlotModelAdapter(new SlotGridModel(null))));
        slotGrid.setVisibleSize(1, 1);

        slotEditor = new SlotTemplateEditor();
        addChild(new RollupPanel("Slot:", slotEditor, null));
    }

    public void setObject( FloorTemplate floor ) {
log.info("setObject(" + floor + ")");
        if( this.floor == floor ) {
            return;
        }
        if( floor == null ) {
            floorRef = null;
        } else {
            floorRef = floor.createReference();
        }
        this.floor = floor;
        setSelectedPos(-1, -1);
        slotGrid.setModel(new SlotModelAdapter(new SlotGridModel(floor)));
        if( floor == null ) {
            slotGrid.setVisibleSize(1, 1);
            slotRefs = null;
        } else {
            slotGrid.setVisibleSize(floor.getSizeZ(), floor.getSizeX());
            slotRefs = new ArrayList<>();
            for( int i = 0; i < floor.getSizeX(); i++ ) {
                for( int j = 0; j < floor.getSizeZ(); j++ ) {
                    slotRefs.add(floor.getSlot(i, j, true).createReference());
                }
            }
        }
        //selectedPos = new Vec3i(-1, 0, -1);
        refreshEditor();
    }

    public FloorTemplate getObject() {
        return floor;
    }

    @Override
    public void updateLogicalState( float tpf ) {
        super.updateLogicalState(tpf);
        if( slotRefs != null ) {
            for( VersionedReference<SlotTemplate> ref : slotRefs ) {
                if( ref.update() ) {
                    floor.invalidate();
                }
            }
        }
        if( floorRef != null && floorRef.update() ) {
            refreshEditor();
        }
        if( tagsRef != null && tagsRef.update() ) {
            // Make the floor look like it changed
            floor.invalidate();
        }
        if( floor != null ) {
            if( nameRef.update() ) {
                floor.setName(nameRef.get().getText());
            }
            if( sizeRef.update() ) {
                Vec3i size = sizeRef.get();
                floor.setSizeX(size.x);
                floor.setSizeZ(size.z);
            }
            if( blockHeightRef.update() ) {
                double d = blockHeightRef.get();
                floor.setFloorHeight((int)d);
            }
            if( gridSpacingRef.update() ) {
                double d = gridSpacingRef.get();
                floor.setGridSpacing((int)d);
            }
        }
    }

    protected void refreshEditor() {
        if( floor != null ) {
            tagsButton.setTags(floor.getTags());
            tagRulesEditor.setObject(floor.getTagRules());
            Vec3i size = new Vec3i(floor.getSizeX(), 0, floor.getSizeZ());
            sizeEditor.setObject(size);
            blockHeightEditor.setValue((double)floor.getFloorHeight());
            nameEditor.setText(floor.getName());
        }
    }

    protected void setSelectedPos( int x, int z ) {
        log.info("select slot:" + x + ", " + z);
        if( selectedPos.x == x && selectedPos.z == z ) {
            return;
        }
        SlotTemplate slot;
        if( floor == null || x < 0 || z < 0 ) {
            slot = null;
        } else {
            slot = floor.getSlot(x, z, true);
        }
        selectedPos = new Vec3i(x, 0, z);
        setSelectedSlot(slot);
        selectionVersion++;
    }

    protected void setSelectedSlot( SlotTemplate slot ) {
        if( selectedSlot == slot ) {
            return;
        }
        log.info("setSelectedSlot(" + slot + ")");
        selectedSlot = slot;
        slotEditor.setObject(slot);
    }

    private class SlotGridModel implements GridModel<SlotTemplate> {
        private FloorTemplate floor;

        public SlotGridModel( FloorTemplate floor ) {
            this.floor = floor;
        }

        @Override
        public SlotTemplate getCell( int row, int col, SlotTemplate existing ) {
            return floor == null ? null : floor.getSlot(col, row, true);
        }

        @Override
        public int getColumnCount() {
            return floor == null ? 1 : floor.getSizeX();
        }

        @Override
        public int getRowCount() {
            return floor == null ? 1 : floor.getSizeZ();
        }

        @Override
        public void setCell( int row, int col, SlotTemplate value ) {
        }

        @Override
        public long getVersion() {
            return floor == null ? 0 : floor.getVersion() + selectionVersion;
        }

        @Override
        public GridModel<SlotTemplate> getObject() {
            return this;
        }

        @Override
        public VersionedReference<GridModel<SlotTemplate>> createReference() {
            return new VersionedReference<>(this);
        }
    }

    private class SlotModelAdapter extends GridModelWrapper<SlotTemplate, Panel> {
        public SlotModelAdapter( GridModel<SlotTemplate> delegate ) {
            super(delegate);
        }

        @Override
        public Panel getCell( int row, int col, Panel existing ) {
            if( existing == null ) {
                existing = new Button("");
                ((Button)existing).addClickCommands(new SlotClicker(col, row));
            }
            Button b = (Button)existing;

            SlotTemplate slot = getDelegate().getCell(row, col, null);
            if( slot != null ) {
                Set<PartTransform> xforms = slot.getTransforms();
                //if( xforms.size() == PartTransform.values().length ) {
                //    b.setText("[*]");
                //} else {
                //    b.setText(String.valueOf(xforms));
                //}
                Texture texture = iconIndex.get(slot.getTransforms());
                Texture existingTexture = b.getIcon() != null ? ((IconComponent)b.getIcon()).getImageTexture() : null;
                if( texture != existingTexture ) {
                    if( xforms == null || xforms.isEmpty() ) {
                        b.setIcon(null);
                        b.setText("");
                    } else if( texture == null ) {
                        b.setIcon(null);
                        b.setText("[??]");
                    } else {
                        IconComponent icon = new IconComponent(texture, new Vector2f(0.5f, 0.5f), 0, 0, 0.1f, false);
                        icon.setHAlignment(HAlignment.Center);
                        b.setIcon(icon);
                        b.setText("");
                    }
                }
            }

            if( row == selectedPos.z && col == selectedPos.x ) {
log.info("selected:" + slot);
                ((ColoredComponent)b.getBackground()).setColor(selectedColor);
            } else {
log.info("unselected:" + slot);
                ((ColoredComponent)b.getBackground()).setColor(unselectedColor);
            }

            return existing;
        }

        @Override
        public void setCell( int row, int col, Panel value ) {
        }
    }

    private class SlotClicker implements Command<Button> {
        private int x;
        private int z;

        public SlotClicker( int x, int z ) {
            this.x = x;
            this.z = z;
        }

        public void execute( Button b ) {
            setSelectedPos(x, z);
        }
    }
}


