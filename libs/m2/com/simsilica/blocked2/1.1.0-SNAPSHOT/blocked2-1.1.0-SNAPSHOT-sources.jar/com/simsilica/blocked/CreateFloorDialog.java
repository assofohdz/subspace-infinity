/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked;

import org.slf4j.*;

import com.jme3.math.Vector3f;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.style.*;
import com.simsilica.mathd.*;

import com.simsilica.tool.*;

import com.simsilica.blocked.parts.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CreateFloorDialog extends Container {
    static Logger log = LoggerFactory.getLogger(CreateFloorDialog.class);
 
    private TextField text;
    private Vec3iEditor sizeEditor; 
    private Command<FloorTemplate> done;
    
    public CreateFloorDialog( String title, String startValue, Vec3i startSize, Command<FloorTemplate> done ) {
        super(new BorderLayout());
        
        this.done = done;
        
        addChild(new Label(title, new ElementId("title.label")), BorderLayout.Position.North);
        
        Container contents = addChild(new Container(), BorderLayout.Position.Center);
        contents.addChild(new Label("Name:"));
        
        text = contents.addChild(new TextField(startValue), 1);
        Vector3f pref = text.getPreferredSize();
        pref.x = Math.max(pref.x, 100);
        text.setPreferredSize(pref);
 
        contents.addChild(new Label("Size:"));
        sizeEditor = contents.addChild(new Vec3iEditor(true, false, true), 1);
        sizeEditor.setObject(startSize);
        
        Container buttons = addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y)), BorderLayout.Position.South);
        buttons.addChild(new ActionButton(new CallMethodAction(this, "ok")));
        buttons.addChild(new ActionButton(new CallMethodAction(this, "cancel")));
    }
 
    public void show() {
        GuiGlobals.getInstance().getPopupState().centerInGui(this);
        GuiGlobals.getInstance().getPopupState().showModalPopup(this);
        GuiGlobals.getInstance().requestFocus(text);
    }
 
    public String getText() {
        return text.getText();
    }
    
    protected void ok() {
        Vec3i size = sizeEditor.getObject(); 
        FloorTemplate template = new FloorTemplate(text.getText(), size.x, size.z);
        done.execute(template);
        removeFromParent();
    }
    
    protected void cancel() {
        removeFromParent();
    }
}
