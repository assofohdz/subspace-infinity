/*
 * $Id$
 * 
 * Copyright (c) 2017, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.blocked.tool;

import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;

import com.simsilica.lemur.*;
import com.simsilica.mathd.*;

import com.simsilica.blocked.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MultiBlockTool implements Tool {

    private int blockType = 1;
    private int altBlockType = 0;
    private int xSize;
    private int ySize;
    private int zSize;
    
    private boolean align = true;
    
    private Node cursor;   
    private Spatial miniBlock;
    private Spatial eraserBlock;

    public MultiBlockTool( int xSize, int ySize, int zSize ) {
        this.xSize = xSize;
        this.ySize = ySize;
        this.zSize = zSize;
         
        float x = 0.25f * xSize;
        float y = 0.25f * ySize;
        float z = 0.25f * zSize;
        
        WireBox box = new WireBox(x * 0.5f, y * 0.5f, z * 0.5f);
        Geometry geom = new Geometry("miniBlock", box);
        ColorRGBA color = new ColorRGBA(1, 1, 0, 0.5f);
        Material mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);        
        geom.setMaterial(mat);
        
        this.miniBlock = geom;
        
        Box solidBox = new Box(x * 0.501f, y * 0.501f, z * 0.501f);
        geom = new Geometry("eraserBlock", solidBox);
        color = new ColorRGBA(1, 1, 1, 0.5f);
        mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        
        Texture texture = GuiGlobals.getInstance().loadTexture("Textures/x-block.png", false, false);
        mat.setTexture("ColorMap", texture); 
        
        geom.setMaterial(mat);
        geom.setQueueBucket(Bucket.Transparent);
        
        this.eraserBlock = geom;
        
        cursor = new Node("cursor");        
        cursor.attachChild(miniBlock);
        cursor.attachChild(eraserBlock);
    }

    public void setBlockType( int type ) {
        this.blockType = type;
    }
    
    public int getBlockType() {
        return blockType;
    }

    public void setAltType( int type ) {
        this.altBlockType = type;
    }
    
    public int getAltType() {
        return altBlockType;
    }

    protected Vec3i[] getLocations( Vec3i loc, Vec3i eraserLoc ) {
        Vec3i gridLoc = loc != null ? loc.clone() : null;
        Vec3i eraserGridLoc = eraserLoc != null ? eraserLoc.clone() : null;
        if( align ) {
            if( gridLoc != null ) {
                gridLoc.x = (gridLoc.x / xSize);// * xSize;
                gridLoc.y = (gridLoc.y / ySize);// * ySize;
                gridLoc.z = (gridLoc.z / zSize);// * zSize;
            }
            
            if( eraserGridLoc != null ) {
                // See if the eraser position is essentially in the same grid cell
                // as the other.
                eraserGridLoc.x = eraserGridLoc.x / xSize;
                eraserGridLoc.y = eraserGridLoc.y / ySize;
                eraserGridLoc.z = eraserGridLoc.z / zSize;
                if( eraserGridLoc.equals(gridLoc) ) {
                    eraserGridLoc = null;
                }
            }
            
            if( eraserGridLoc != null && gridLoc != null ) {
                Vec3i dir = eraserLoc.subtract(loc);
                eraserGridLoc.x = gridLoc.x + dir.x;// * xSize;
                eraserGridLoc.y = gridLoc.y + dir.y;// * ySize;
                eraserGridLoc.z = gridLoc.z + dir.z;// * zSize;
                if( eraserGridLoc.y < 0 ) {
                    eraserGridLoc = null;
                }
            } else if( eraserGridLoc != null ) {
                eraserGridLoc.x = (eraserGridLoc.x / xSize);// * xSize;
                eraserGridLoc.y = (eraserGridLoc.y / ySize);// * ySize;
                eraserGridLoc.z = (eraserGridLoc.z / zSize);// * zSize;
            }
            
            if( gridLoc != null ) {
                gridLoc.x *= xSize;
                gridLoc.y *= ySize;
                gridLoc.z *= zSize;
            }
            if( eraserGridLoc != null ) {
                eraserGridLoc.x *= xSize;
                eraserGridLoc.y *= ySize;
                eraserGridLoc.z *= zSize;
            }            
        }
        
        return new Vec3i[] { gridLoc, eraserGridLoc };
    }

    @Override
    public Spatial getCursor( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        Vec3i eraserLoc = blocks.getBlockLocation(worldPos, normal);
        if( eraserLoc != null && eraserLoc.y < 0 ) {
            eraserLoc = null;           
        }
         
        if( loc == null && eraserLoc == null ) {
            return null;
        }
 
        Vec3i[] locs = getLocations(loc, eraserLoc);        
        
        if( locs[0] != null ) {
            Vector3f pos = blocks.getWorldPosition(locs[0]);
            miniBlock.setLocalTranslation(pos);
            miniBlock.move(0.25f * xSize * 0.5f - 0.125f,
                           0.25f * ySize * 0.5f - 0.125f, 
                           0.25f * zSize * 0.5f - 0.125f);
            miniBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            miniBlock.setCullHint(Spatial.CullHint.Always);
        }

        if( locs[1] != null ) {
            Vector3f pos = blocks.getWorldPosition(locs[1]);
            eraserBlock.setLocalTranslation(pos);
            eraserBlock.move(0.25f * xSize * 0.5f - 0.125f,
                           0.25f * ySize * 0.5f - 0.125f, 
                           0.25f * zSize * 0.5f - 0.125f);
            eraserBlock.setCullHint(Spatial.CullHint.Inherit);
        } else {
            eraserBlock.setCullHint(Spatial.CullHint.Always);
        }
                           
        return cursor;
    }
 
    @Override   
    public void alternate( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Add a block
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        Vec3i[] locs = getLocations(loc, null);
        Vec3i gridLoc = locs[0];
                
        /*Vec3i gridLoc = loc;
        if( align ) {
            gridLoc.x = (gridLoc.x / xSize) * xSize;
            gridLoc.y = (gridLoc.y / ySize) * ySize;
            gridLoc.z = (gridLoc.z / zSize) * zSize;
        }*/
        
        if( gridLoc != null ) {
            for( int i = 0; i < xSize; i++ ) {
                for( int j = 0; j < ySize; j++ ) {
                    for( int k = 0; k < zSize; k++ ) {
                        blocks.setBlock(gridLoc.add(i, j, k), blockType);
                    }
                }
            }
        }
    }
 
    @Override   
    public void main( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Remove a block
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        Vec3i eraserLoc = blocks.getBlockLocation(worldPos, normal);
        Vec3i[] locs = getLocations(loc, eraserLoc);
 
        Vec3i gridLoc = locs[1];
        
        if( gridLoc != null ) {
            for( int i = 0; i < xSize; i++ ) {
                for( int j = 0; j < ySize; j++ ) {
                    for( int k = 0; k < zSize; k++ ) {
                        blocks.setBlock(gridLoc.add(i, j, k), altBlockType);
                    }
                }
            }
        }
    }
 
    @Override   
    public void combo( BlockState blocks, Vector3f worldPos, Vector3f normal ) {
        // Replace the blocks that aren't empty
        Vec3i loc = blocks.getEmptyLocation(worldPos, normal);
        Vec3i eraserLoc = blocks.getBlockLocation(worldPos, normal);
        Vec3i[] locs = getLocations(loc, eraserLoc);
 
        Vec3i gridLoc = locs[1];
        if( gridLoc == null ) {
            gridLoc = locs[0];
        }
 
        if( gridLoc != null ) {
            for( int i = 0; i < xSize; i++ ) {
                for( int j = 0; j < ySize; j++ ) {
                    for( int k = 0; k < zSize; k++ ) {
                        int existing = blocks.getBlock(gridLoc.add(i, j, k));
                        if( existing > 0 ) {
                            blocks.setBlock(gridLoc.add(i, j, k), blockType);
                        }
                    }
                }
            }
        }
    }
    
}
