#import "Common/ShaderLib/GLSLCompat.glsllib"
#import "Common/ShaderLib/Skinning.glsllib"
#import "Common/ShaderLib/Instancing.glsllib"
#import "Common/ShaderLib/MorphAnim.glsllib"

attribute vec3 inPosition;

#if defined(HAS_COLORMAP) || (defined(HAS_LIGHTMAP) && !defined(SEPARATE_TEXCOORD))
    #define NEED_TEXCOORD1
#endif

attribute vec4 inTexCoord;
attribute vec2 inTexCoord2;
attribute vec4 inColor;

varying vec2 texCoord1;
varying vec2 texCoord2;

varying vec4 vertColor;
#ifdef HAS_POINTSIZE
    uniform float m_PointSize;
#endif


uniform vec3 g_CameraLeft;
uniform vec3 g_CameraUp;
uniform vec3 g_CameraDirection;
uniform vec3 g_CameraPosition;

void main(){
    #ifdef NEED_TEXCOORD1
        texCoord1 = inTexCoord.xy;
    #endif

    #ifdef SEPARATE_TEXCOORD
        texCoord2 = inTexCoord2;
    #endif

    #ifdef HAS_VERTEXCOLOR
        vertColor = inColor;
    #endif

    #ifdef HAS_POINTSIZE
        gl_PointSize = m_PointSize;
    #endif

    vec4 modelSpacePos = vec4(inPosition, 1.0);
    //modelSpacePos.xy += inTexCoord.zw;
    modelSpacePos.xyz -= g_CameraLeft * inTexCoord.z;
    modelSpacePos.xyz += g_CameraUp * inTexCoord.w;

    #ifdef NUM_MORPH_TARGETS
        Morph_Compute(modelSpacePos);
    #endif

    #ifdef NUM_BONES
        Skinning_Compute(modelSpacePos);
    #endif

    vec3 offset = TransformWorld(modelSpacePos).xyz - g_CameraPosition; 
    float distance = dot(offset, g_CameraDirection);
    //float falloff = max(0.25, 1.0 - (distance / 8.0));
    float focus = 2.0;
    distance = abs(distance - focus); 
    float falloff = distance/(focus * 0.5);
    falloff = falloff * falloff;
    falloff = max(0.1, 1.0 - falloff);
    vertColor.a *= falloff;

    gl_Position = TransformWorldViewProjection(modelSpacePos);
    
    
}
