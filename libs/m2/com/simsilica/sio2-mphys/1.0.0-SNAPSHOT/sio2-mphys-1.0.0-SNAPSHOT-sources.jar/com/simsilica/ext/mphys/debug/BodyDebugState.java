/*
 * $Id$
 *
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys.debug;

import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.scene.shape.*;
import com.jme3.scene.debug.WireBox;
import com.jme3.texture.Texture;

import com.simsilica.es.*;
import com.simsilica.mathd.*;
import com.simsilica.lemur.GuiGlobals;

import com.simsilica.mphys.*;
import com.simsilica.ext.mphys.*;

/**
 *  Debug views of rigid body bounding shapes, status, etc.
 *
 *  @author    Paul Speed
 */
public class BodyDebugState<S extends AbstractShape> extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(BodyDebugState.class);

    private MPhysSystem<S> mphys;
    private PhysicsSpace<EntityId, S> space;
    private Grid grid;
    private ObjectObserver observer = new ObjectObserver();

    private boolean showBoundsSphere = false;
    private Set<EntityId> hiddenEntities = new HashSet<>();

    /**
     *  Root node positioned such that the center bin cell is at its 0,0,0.
     */
    private Node objectRoot = new Node("objectRoot");

    /**
     *  Keep track of the center bin coordinate and its world coordinate.
     *  Objects will be positioned relative to the center world coordinate.
     */
    private Vec3i lastCenter = new Vec3i();
    private Vec3i lastCenterWorld = new Vec3i();

    /**
     *  Keep track of the origin under which the camera operates.
     *  viewOrigin.add(camera.getLocation()) should be the world position of
     *  the eyeball.
     */
    private Vec3d viewOrigin = new Vec3d();

    private Camera camera;
    private Vec3d eyeLocation = new Vec3d();

    private Map<EntityId, BodyView> bodyIndex = new HashMap<>();
    private DynArray bodies = new DynArray<>(BodyView.class);
    private Queue<RigidBody<EntityId, S>> addedBodies = new ConcurrentLinkedQueue<>();
    private Queue<RigidBody<EntityId, S>> removedBodies = new ConcurrentLinkedQueue<>();

    private Map<EntityId, StaticBodyView> staticBodyIndex = new HashMap<>();
    private DynArray staticBodies = new DynArray<>(StaticBodyView.class);
    private Queue<StaticBody<EntityId, S>> addedStaticBodies = new ConcurrentLinkedQueue<>();
    private Queue<StaticBody<EntityId, S>> removedStaticBodies = new ConcurrentLinkedQueue<>();

    private DynArray<DebugShapeFactory> debugFactories = new DynArray<>(DebugShapeFactory.class);

    private Mesh axesMesh;
    private Geometry axesTemplate;
    private Mesh cogMesh;
    private Mesh boundsSphere;

    public BodyDebugState( MPhysSystem<S> mphys ) {
        this.mphys = mphys;
        this.space = mphys.getPhysicsSpace();
        this.grid = space.getGrid();
        setEnabled(false);
    }

    public void hideEntity( EntityId hidden ) {
        if( hiddenEntities.add(hidden) ) {
            updateVisibility();
        }
    }

    public void unhideEntity( EntityId hidden ) {
        if( hiddenEntities.remove(hidden) ) {
            updateVisibility();
        }
    }

    public Node getObjectRoot() {
        return objectRoot;
    }

    public void addDebugShapeFactory( DebugShapeFactory<S> factory ) {
        if( isInitialized() ) {
            factory.initialize(this);
        }
        debugFactories.add(factory);
    }

    public void removeDebugShapeFactory( DebugShapeFactory<S> factory ) {
        if( isInitialized() ) {
            factory.terminate(this);
        }
        debugFactories.remove(factory);
    }

    public void toggleEnabled() {
        setEnabled(!isEnabled());
    }

    public void setViewOrigin( double x, double y, double z ) {
        viewOrigin.set(x, y, z);
    }

    public void setViewOrigin( Vec3d origin ) {
        setViewOrigin(origin.x, origin.y, origin.z);
    }

    public Vec3d getViewOrigin() {
        return viewOrigin;
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected Camera getCamera() {
        if( camera == null ) {
            camera = getApplication().getCamera();
        }
        return camera;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {

        // Create some template geometry
        float axesSize = 0.1f;
        axesMesh = new Mesh();
        axesMesh.setMode(Mesh.Mode.Lines);
        axesMesh.setBuffer(Type.Position, 3,
            new float[] {
                0, 0, 0, axesSize,  0,          0,
                0, 0, 0, 0,         axesSize,   0,
                0, 0, 0, 0,         0,          axesSize
            });
        axesMesh.setBuffer(Type.Color, 4,
            new float[] {
                1, 0, 0, 1, 1, 0, 0, 1,
                0, 1, 0, 1, 0, 1, 0, 1,
                0, 0, 1, 1, 0, 0, 1, 1
            });
        axesTemplate = new Geometry("axes", axesMesh);
        axesTemplate.setQueueBucket(Bucket.Translucent);
        Material mat = GuiGlobals.getInstance().createMaterial(new ColorRGBA(1, 1, 1, 0.5f), false).getMaterial();
        mat.setBoolean("VertexColor", true);
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        axesTemplate.setMaterial(mat);

        float cogSize = axesSize * 0.1f;
        cogMesh = new WireBox(cogSize, cogSize, cogSize);

        boundsSphere = new Sphere(24, 24, 1);

        for( DebugShapeFactory factory : debugFactories ) {
            factory.initialize(this);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void cleanup( Application app ) {
        for( DebugShapeFactory factory : debugFactories ) {
            factory.terminate(this);
        }
    }

    @Override
    protected void onEnable() {
        mphys.getBinEntityManager().addObjectStatusListener(observer);
        getRoot().attachChild(objectRoot);

        // Create views for all of the existing bodies
        // FIXME: this is not thread-safe
        // and today I actually hit this again. -pspeed:2022-05-01
        PhysicsSpace<EntityId, S> space = mphys.getPhysicsSpace();
        BinIndex<EntityId, S> bins = space.getBinIndex();
        for( EntityId id : bins.getBodyIds() ) {
log.info("Loading existing ID:" + id);
            RigidBody<EntityId, S> body = bins.getRigidBody(id);
            bodyAdded(body);
        }

        for( EntityId id : bins.getStaticBodyIds() ) {
            StaticBody<EntityId, S> body = bins.getStaticBody(id);
            staticBodyAdded(body);
        }
    }

    @Override
    protected void onDisable() {
        objectRoot.removeFromParent();
        mphys.getBinEntityManager().removeObjectStatusListener(observer);
        clearBodies();
    }

    @Override
    public void update( float tpf ) {
        RigidBody<EntityId, S> body = null;
        while( (body = addedBodies.poll()) != null ) {
            bodyAdded(body);
        }
        while( (body = removedBodies.poll()) != null ) {
            bodyRemoved(body);
        }
        StaticBody<EntityId, S> sb = null;
        while( (sb = addedStaticBodies.poll()) != null ) {
            staticBodyAdded(sb);
        }
        while( (sb = removedStaticBodies.poll()) != null ) {
            staticBodyRemoved(sb);
        }
        updateCenter();
    }

    protected void updateCenter() {
        Vector3f cameraPos = getCamera().getLocation();
        Vec3d world = viewOrigin.add(new Vec3d(cameraPos));
        eyeLocation.set(world);

        Vec3i center = grid.worldToCell(world.x, 0, world.z);
        if( !center.equals(lastCenter) ) {
            lastCenter.set(center);
            //Vec3i cellWorld = grid.cellToWorld(center, lastCenterWorld);
            updateVisibility();
        }

        // Figure out how far to offset the binRoot
        //objectRoot.setLocalTranslation(
        //    (float)(lastCenterWorld.x - world.x),
        //    (float)(lastCenterWorld.y),
        //    (float)(lastCenterWorld.z - world.z));
        updatePositions();
    }

    @SuppressWarnings("unchecked")
    protected void updateVisibility() {
        // Note: a common base class/interface doesn't work here because of
        // the outer parameterization.  Because the inner classes rely on the S
        // of the outer class, as soon as we try to do something smarter with DynArray
        // we get generics type cast errors and such related to the S type parameter.
        // We can't parameterize BodyView and StaticBodyView because DynArray wraps
        // an array and array types can't really be parameterized.  So we're stuck casting.

        for( Object view : bodies.getArray() ) {
            ((BodyView)view).updateVisibility();
        }
        for( Object view : staticBodies.getArray() ) {
            ((StaticBodyView)view).updateVisibility();
        }
    }

    @SuppressWarnings("unchecked")
    protected void updatePositions() {
        for( Object view : bodies.getArray() ) {
            ((BodyView)view).updatePosition();
        }
        for( Object view : staticBodies.getArray() ) {
            ((StaticBodyView)view).updatePosition();
        }
    }

    private static ColorRGBA HOTTEST = new ColorRGBA(1, 1, 0.5f, 1);
    private static ColorRGBA HOT = ColorRGBA.Yellow;
    private static ColorRGBA WARM = ColorRGBA.Red;
    private static ColorRGBA COOLING = new ColorRGBA(0.5f, 0, 0, 1);
    private static ColorRGBA COLD = ColorRGBA.Cyan;
    public static ColorRGBA temperatureToColor( double temperature, ColorRGBA target, float alpha ) {
        // We want a gradient where it's white/yellow at max then as it falls changes
        // to orange, then red, the to gray through to blue at the very bottom.
        if( temperature > 0.75 ) {
            double t = (temperature - 0.75) * 4;
            target.interpolateLocal(HOT, HOTTEST, (float)t);
        } else if( temperature > 0.50 ) {
            double t = (temperature - 0.5) * 4;
            target.interpolateLocal(WARM, HOT, (float)t);
        } else if( temperature > 0.25 ) {
            double t = (temperature - 0.25) * 4;
            target.interpolateLocal(COOLING, WARM, (float)t);
        } else {
            double t = (temperature) * 4;
            target.interpolateLocal(COLD, COOLING, (float)t);
        }
        target.a = alpha;
        return target;
    }

    protected void clearBodies() {
        for( BodyView view : bodyIndex.values() ) {
            bodies.remove(view);
            view.release();
        }
        bodyIndex.clear();
        for( StaticBodyView view : staticBodyIndex.values() ) {
            staticBodies.remove(view);
            view.release();
        }
        staticBodyIndex.clear();
    }

    @SuppressWarnings("unchecked")
    protected void bodyAdded( RigidBody<EntityId, S> body ) {
log.info("bodyAdded(" + body.id + ")");
        BodyView view = bodyIndex.get(body.id);
        if( view != null ) {
            log.error("Added entity body already has a view:" + body.id + ", view:" + view);
            return;
        }

        view = new BodyView(body);
        bodyIndex.put(body.id, view);
        bodies.add(view);
        view.updateVisibility();
    }

    @SuppressWarnings("unchecked")
    protected void bodyRemoved( RigidBody<EntityId, S> body ) {
log.info("bodyRemoved(" + body.id + ")");
        BodyView view = bodyIndex.remove(body.id);
        if( view == null ) {
            log.error("Removed entity body has no view:" + body.id);
            return;
        }
        bodies.remove(view);
        view.release();
    }

    @SuppressWarnings("unchecked")
    protected void staticBodyAdded( StaticBody<EntityId, S> body ) {
log.info("staticBodyAdded(" + body.id + ")");
        StaticBodyView view = staticBodyIndex.get(body.id);
        if( view != null ) {
            log.error("Added entity body already has a view:" + body.id + ", view:" + view);
            return;
        }
        view = new StaticBodyView(body);
        staticBodies.add(view);
        staticBodyIndex.put(body.id, view);
        view.updateVisibility();
    }

    @SuppressWarnings("unchecked")
    protected void staticBodyRemoved( StaticBody<EntityId, S> body ) {
log.info("staticBodyRemoved(" + body.id + ")");
        StaticBodyView view = staticBodyIndex.remove(body.id);
        if( view == null ) {
            log.error("Removed entity body has no view:" + body.id);
            return;
        }
        staticBodies.remove(view);
        view.release();
    }

    private class ObjectObserver extends ObjectStatusAdapter<S> {

        public ObjectObserver() {
        }

        @Override
        public void objectLoaded( EntityId entity, RigidBody<EntityId, S> body ) {
            addedBodies.add(body);
        }

        @Override
        public void objectUnloaded( EntityId entity, RigidBody<EntityId, S> body ) {
            removedBodies.add(body);
        }

        @Override
        public void staticObjectLoaded( EntityId entity, StaticBody<EntityId, S> body ) {
log.info("staticObjectLoaded(" + entity + ")");
            addedStaticBodies.add(body);
        }

        @Override
        public void staticObjectUnloaded( EntityId entity, StaticBody<EntityId, S> body ) {
log.info("staticObjectUNloaded(" + entity + ")");
            removedStaticBodies.add(body);
        }
    }

    private class BodyView {
        EntityId entity;
        RigidBody<EntityId, S> body;

        Vec3d pos = new Vec3d();
        Quatd orient = new Quatd();
        Node view;
        Node orientedView;
        Spatial axes;
        ColorRGBA temperature = new ColorRGBA(0.5f, 0.5f, 0.5f, 0.5f);
        Mesh aabbMesh;

        long lastShapeVersion;

        @SuppressWarnings("unchecked")
        public BodyView( RigidBody<EntityId, S> body ) {
            this.entity = body.id;
            this.body = body;
            this.view = new Node("BodyView:" + entity);

            orientedView = new Node("OrientedView:" + entity);
            view.attachChild(orientedView);

            axes = axesTemplate.clone();
            orientedView.attachChild(axes);

            Geometry geom = new Geometry("cog", cogMesh);
            Material mat = GuiGlobals.getInstance().createMaterial(temperature, false).getMaterial();
            geom.setMaterial(mat);
            geom.setQueueBucket(Bucket.Translucent);
            view.attachChild(geom);

            Material wireMat = mat.clone();
            wireMat.getAdditionalRenderState().setWireframe(true);
            wireMat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

            if( showBoundsSphere ) {
                // The bounding sphere will reflect the current incorrect
                // bounding sphere that the MBlockCollisionSystem uses.  This
                // uses the shape's radius centered on the CoG instead of centered
                // on the shape's center.  When we fix that, we can fix the debug
                // view also.  FIXME - fix debug view to match collision system when fixed.
                geom = new Geometry("boundSphere", boundsSphere);
                //mat = GuiGlobals.getInstance().createMaterial(temperature, false).getMaterial();
                //mat.getAdditionalRenderState().setWireframe(true);
                //mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                geom.setMaterial(wireMat.clone());
                geom.setQueueBucket(Bucket.Translucent);
                geom.setLocalScale((float)body.shape.getMass().getRadius());
                orientedView.attachChild(geom);
            }

            if( false ) {
                // Let's see what the shape bounds looks like relative to CoG
                // which is how it's usually applied (incorrectly).
                geom = new Geometry("shapeSphere", boundsSphere);
                mat = GuiGlobals.getInstance().createMaterial(ColorRGBA.Red, false).getMaterial();
                mat.getAdditionalRenderState().setWireframe(true);
                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                geom.setMaterial(mat);
                geom.setQueueBucket(Bucket.Translucent);
                geom.setLocalScale((float)body.shape.getBoundsRadius());
                orientedView.attachChild(geom);
            }

            boolean showBoundsBox = false;
            if( showBoundsBox ) {
                // The AaBBox will be correct, though... because the body's AaBBox is
                // centered around the cog.
                AaBBox bounds = body.getWorldBounds();

                Vector3f min = bounds.getMin().subtract(body.position).toVector3f();
                Vector3f max = bounds.getMax().subtract(body.position).toVector3f();

                aabbMesh = new Box(min, max);
                geom = new Geometry("boundBox", aabbMesh);
                //mat = mat.clone();
                //mat.getAdditionalRenderState().setWireframe(false);
                //Texture texture = GuiGlobals.getInstance().loadTexture("Interface/borderx4-256.png", true, true);
                //mat.setTexture("ColorMap", texture);
                //mat.setFloat("AlphaDiscardThreshold", 0.1f);
                geom.setMaterial(wireMat.clone());
                geom.setQueueBucket(Bucket.Translucent);
                view.attachChild(geom);
            }

            for( DebugShapeFactory factory : debugFactories.getArray() ) {
                factory.addDebugShape(body, orientedView, temperature);
            }
            lastShapeVersion = body.shape.getVersion();
        }

        @SuppressWarnings("unchecked")
        public void updatePosition() {
            if( lastShapeVersion < body.shape.getVersion() ) {
                for( DebugShapeFactory factory : debugFactories.getArray() ) {
                    factory.updateDebugShape(body, orientedView, temperature);
                }
                lastShapeVersion = body.shape.getVersion();
            }

            // This is not thread safe but also shouldn't cause harm
            pos.set(body.position);
            orient.set(body.orientation);

            float x = (float)(pos.x - viewOrigin.x);
            float y = (float)(pos.y - viewOrigin.y);
            float z = (float)(pos.z - viewOrigin.z);

            view.setLocalTranslation(x, y, z);
            //axes.setLocalRotation(orient.toQuaternion());
            orientedView.setLocalRotation(orient.toQuaternion());

            double dist = pos.distance(eyeLocation) - body.shape.getMass().getRadius();
            dist = dist * dist; // exponential falloff
            double fade = 1;
            if( dist > 0 ) {
                fade = Math.min(1, (16 * 16) / dist);
            }

            temperatureToColor(body.getTemperature(), temperature, 0.25f * (float)fade);
        }

        public void updateVisibility() {
            if( hiddenEntities.contains(entity) ) {
                view.removeFromParent();
            } else {
                if( view.getParent() == null ) {
                    // For now, always visible
                    objectRoot.attachChild(view);
                }
            }
        }

        @SuppressWarnings("unchecked")
        public void release() {
            view.removeFromParent();
            for( DebugShapeFactory factory : debugFactories.getArray() ) {
                factory.releaseDebugShape(body, orientedView);
            }
        }
    }

    private class StaticBodyView {
        EntityId entity;
        StaticBody<EntityId, S> body;

        Vec3d pos = new Vec3d();
        Quatd orient = new Quatd();
        Node view;
        Node orientedView;
        Spatial axes;
        Mesh aabbMesh;

        ColorRGBA color;

        long lastShapeVersion;

        @SuppressWarnings("unchecked")
        public StaticBodyView( StaticBody<EntityId, S> body ) {
            this.entity = body.id;
            this.body = body;
            this.view = new Node("StaticBodyView:" + entity);

            orientedView = new Node("OrientedView:" + entity);
            view.attachChild(orientedView);

            axes = axesTemplate.clone();
            orientedView.attachChild(axes);

            this.color = ColorRGBA.Black.clone();

            Geometry geom = new Geometry("cog", cogMesh);
            Material mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
            geom.setMaterial(mat);
            geom.setQueueBucket(Bucket.Translucent);
            view.attachChild(geom);

            boolean showBoundsSphere = false;
            if( showBoundsSphere ) {
                // The bounding sphere will reflect the current incorrect
                // bounding sphere that the MBlockCollisionSystem uses.  This
                // uses the shape's radius centered on the CoG instead of centered
                // on the shape's center.  When we fix that, we can fix the debug
                // view also.  FIXME - fix debug view to match collision system when fixed.
                geom = new Geometry("boundSphere", boundsSphere);
                mat = GuiGlobals.getInstance().createMaterial(color, false).getMaterial();
                mat.getAdditionalRenderState().setWireframe(true);
                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                geom.setMaterial(mat);
                geom.setQueueBucket(Bucket.Translucent);
                geom.setLocalScale((float)body.shape.getMass().getRadius());
                orientedView.attachChild(geom);
            }

            if( false ) {
                // Let's see what the shape bounds looks like relative to CoG
                // which is how it's usually applied (incorrectly).
                geom = new Geometry("shapeSphere", boundsSphere);
                mat = GuiGlobals.getInstance().createMaterial(ColorRGBA.Red, false).getMaterial();
                mat.getAdditionalRenderState().setWireframe(true);
                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                geom.setMaterial(mat);
                geom.setQueueBucket(Bucket.Translucent);
                geom.setLocalScale((float)body.shape.getBoundsRadius());
                orientedView.attachChild(geom);
            }

            for( DebugShapeFactory factory : debugFactories.getArray() ) {
               factory.addDebugShape(body, orientedView, ColorRGBA.Yellow.clone());
            }
            lastShapeVersion = body.shape.getVersion();

            updatePosition();
        }

        @SuppressWarnings("unchecked")
        public void updatePosition() {
            if( lastShapeVersion < body.shape.getVersion() ) {
                for( DebugShapeFactory factory : debugFactories.getArray() ) {
                    factory.updateDebugShape(body, orientedView, ColorRGBA.Yellow.clone());
                }
            }

            // This is not thread safe but also shouldn't cause harm
            pos.set(body.position);
            orient.set(body.orientation);

            float x = (float)(pos.x - viewOrigin.x);
            float y = (float)(pos.y - viewOrigin.y);
            float z = (float)(pos.z - viewOrigin.z);

            view.setLocalTranslation(x, y, z);
            orientedView.setLocalRotation(orient.toQuaternion());

            double dist = pos.distance(eyeLocation) - body.shape.getMass().getRadius();
            dist = dist * dist; // exponential falloff
            double fade = 1;
            if( dist > 0 ) {
                fade = Math.min(1, (8 * 8) / dist);
            }
            color.a = (float)Math.min(0.5f, fade);
        }

        public void updateVisibility() {
            if( hiddenEntities.contains(entity) ) {
                view.removeFromParent();
            } else {
                if( view.getParent() == null ) {
                    // For now, always visible
                    objectRoot.attachChild(view);
                }
            }
        }

        public void release() {
            view.removeFromParent();
        }
    }
}
