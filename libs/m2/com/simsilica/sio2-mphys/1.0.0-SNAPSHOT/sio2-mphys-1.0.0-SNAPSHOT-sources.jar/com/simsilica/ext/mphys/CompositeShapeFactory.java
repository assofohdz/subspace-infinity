/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.util.*;

import org.slf4j.*;

import com.google.common.reflect.TypeToken;

import com.simsilica.mphys.*;

/**
 *  Holds an in-order list of delegate ShapeFactories that are treated like
 *  a "chop chain" where each gets a crack at creating the shape until one
 *  succeeds.  Sometimes different shapes require different setups but otherwise
 *  fit a general category.  For example, the shape name might end with a particular
 *  extension or start with a particular prefix that then requires special handling.
 *
 *  @author    Paul Speed
 */
public class CompositeShapeFactory<S extends AbstractShape> implements ShapeFactory<S> {
    static Logger log = LoggerFactory.getLogger(CompositeShapeFactory.class);
 
    private DynArray<ShapeFactory<S>> delegates = new DynArray<>(new TypeToken<ShapeFactory<S>>() {});
    
    @SafeVarargs
    public CompositeShapeFactory( ShapeFactory<S>... delegates ) {
        this.delegates.addAll(Arrays.asList(delegates));
    }
 
    public void addDelegate( ShapeFactory<S> delegate ) {
        delegates.add(delegate);
    }
    
    public List<ShapeFactory<S>> getDelegates() {
        return delegates;
    }
    
    @Override
    public S createShape( String name, double scale, Mass mass ) {
        for( ShapeFactory<S> factory : delegates.getArray() ) {
            S result = factory.createShape(name, scale, mass);
            if( result != null ) {
                return result;
            }
        }
        return null;
    }
}


