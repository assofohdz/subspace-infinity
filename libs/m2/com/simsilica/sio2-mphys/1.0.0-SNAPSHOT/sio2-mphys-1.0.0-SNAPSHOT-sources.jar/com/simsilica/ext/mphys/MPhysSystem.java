/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Set;

import org.slf4j.*;

import com.simsilica.es.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;
import com.simsilica.sim.*;

/**
 *  An SiO2 game system that manages an mphys PhysicsSpace instance.
 *
 *  @author    Paul Speed
 */
public class MPhysSystem<S extends AbstractShape> extends AbstractGameSystem {

    static Logger log = LoggerFactory.getLogger(MPhysSystem.class);

    private PhysicsSpace<EntityId, S> phys;
    private Grid zoneGrid;
    private EntityData ed;
    private BinEntityManager<S> binManager;
    private EntityBodyFactory<S> bodyFactory;

    private EntitySet impulses;

    public MPhysSystem( Grid zoneGrid, EntityBodyFactory<S> bodyFactory  ) {
        this(zoneGrid, null, bodyFactory);
    }

    public MPhysSystem( Grid zoneGrid, Vec3i gridRadius, EntityBodyFactory<S> bodyFactory  ) {
        this.zoneGrid = zoneGrid;
        this.bodyFactory = bodyFactory;
        this.phys = new PhysicsSpace<>(zoneGrid, gridRadius);
    }

    public String getDiagnostics() {
        PhysicsStats stats = phys.getStats();
        return String.format("active bins: %d/%d, active bodies: %d/%d,"
            + " frame: %.03f ms (avg: %.03f),"
            + " integrate: %.03f ms (avg: %.03f),"
            + " driver: %.03f ms (avg: %.03f),"
            + " binUpdate: %.03f ms (avg: %.03f),"
            + " contactGen: %.03f ms (avg: %.03f),"
            + " contactRes: %.03f (avg: %.03f)",
            stats.getLong(PhysicsStats.STAT_ACTIVE_BIN_COUNT),
            stats.getLong(PhysicsStats.STAT_BIN_COUNT),
            stats.getLong(PhysicsStats.STAT_ACTIVE_BODY_COUNT),
            stats.getLong(PhysicsStats.STAT_BODY_COUNT),
            stats.getLastDouble(PhysicsStats.STAT_FRAME_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_FRAME_TIME)/1000000.0,
            stats.getLastDouble(PhysicsStats.STAT_INTEGRATION_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_INTEGRATION_TIME)/1000000.0,
            stats.getLastDouble(PhysicsStats.STAT_DRIVER_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_DRIVER_TIME)/1000000.0,
            stats.getLastDouble(PhysicsStats.STAT_BIN_UPDATE_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_BIN_UPDATE_TIME)/1000000.0,
            stats.getLastDouble(PhysicsStats.STAT_CONTACT_GEN_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_CONTACT_GEN_TIME)/1000000.0,
            stats.getLastDouble(PhysicsStats.STAT_CONTACT_RES_TIME)/1000000.0,
            stats.getDouble(PhysicsStats.STAT_CONTACT_RES_TIME)/1000000.0
            );
    }

    public String getDiagnostics2() {
        StringWriter sOut = new StringWriter();
        try( PrintWriter out = new PrintWriter(sOut) ) {
            phys.getBinIndex().writeDebugInfo(out);
        }
        return sOut.toString();
    }

    /**
     *  Sets the EntityData that this system will use to detect new
     *  physics entities.  Will be looked up in the GameSystemManager if
     *  not set.  Note: the EntityData must be set before the system has
     *  been initialized for it to take effect.  The method will throw
     *  an IllegalStateException if called after initialization.
     */
    public void setEntityData( EntityData ed ) {
        if( isInitialized() ) {
            throw new IllegalStateException("System is already initialized");
        }
        this.ed = ed;
    }

    public EntityData getEntityData() {
        return ed;
    }

    public PhysicsSpace<EntityId, S> getPhysicsSpace() {
        return phys;
    }

    public BinEntityManager<S> getBinEntityManager() {
        return binManager;
    }

    public EntityBodyFactory<S> getBodyFactory() {
        return bodyFactory;
    }

    public void setCollisionSystem( CollisionSystem<EntityId, S> collisionSystem ) {
        phys.setCollisionSystem(collisionSystem);
    }

    public CollisionSystem<EntityId, S> getCollisionSystem() {
        return phys.getCollisionSystem();
    }

    public void addPhysicsListener( PhysicsListener<EntityId, S> l ) {
        phys.addPhysicsListener(l);
    }

    public void removePhysicsListener( PhysicsListener<EntityId, S> l ) {
        phys.removePhysicsListener(l);
    }

    @Override
    protected void initialize() {
        if( ed == null ) {
            ed = getSystem(EntityData.class, true);
        }
        this.binManager = new BinEntityManager<>(ed);
        phys.addBinListener(binManager);
        phys.setPhysicsFactory(bodyFactory);
    }

    @Override
    protected void terminate() {
    }

    @Override
    public void start() {
        super.start();

        impulses = ed.getEntities(ShapeInfo.class, Mass.class, Impulse.class);
    }

    private static double FPS60 = 1.0/60;

    @Override
    public void update( SimTime time ) {
//if( phys.getActiveObjectCount() > 0 ) {
//    log.info("Wobble: update() active objects:" + phys.getActiveObjectCount());
//}
        long start = System.nanoTime();

        binManager.update();

        long time1 = System.nanoTime();

        impulses.applyChanges();
        if( !impulses.isEmpty() ) {
            // We don't really care if the set changed or not, we will
            // always iterate over all items until they are removed.
            // The applyImpulses() method will clear the current impulse
            // if the body exists for the entity.
            applyImpulses(impulses);
        }

        long time2 = System.nanoTime();

        //double tpf = time.getTpf();
        double tpf = FPS60;
        phys.integrate(time.getTime(), tpf);

        long end = System.nanoTime();

        if( end - start > 50000000L ) {
            log.warn(String.format("update time: %.03f ms, binManager: %.03f, impulses: %.03f, integration: %.03f, diag: %s",
                        (end - start)/1000000.0,
                        (time1 - start)/1000000.0,
                        (time2 - time2)/1000000.0,
                        (end - time2)/1000000.0,
                        getDiagnostics()
                    ));
        }
    }

    @Override
    public void stop() {
        super.stop();
        impulses.release();
    }

    protected void applyImpulses( Set<Entity> impulses ) {
        for( Entity e : impulses ) {
            Impulse imp = e.get(Impulse.class);

            if( phys.applyImpulse(e.getId(), imp.getLinearVelocity()) ) {
                // Then it's safe to remove the component.
                ed.removeComponent(e.getId(), Impulse.class);
            }
        }
    }
}
