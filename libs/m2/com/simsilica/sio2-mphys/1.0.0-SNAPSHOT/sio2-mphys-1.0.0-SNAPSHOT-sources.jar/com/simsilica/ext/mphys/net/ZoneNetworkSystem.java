/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys.net;

import org.slf4j.*;

import com.simsilica.es.EntityId;
import com.simsilica.ethereal.zone.ZoneManager;
import com.simsilica.mathd.Quatd;
import com.simsilica.mathd.Vec3d;
import com.simsilica.sim.AbstractGameSystem;

import com.simsilica.mphys.AbstractShape;
import com.simsilica.mphys.DynArray;
import com.simsilica.mphys.PhysicsListener;
import com.simsilica.mphys.RigidBody;
import com.simsilica.ext.mphys.MPhysSystem;
import com.simsilica.ext.mphys.ObjectStatusAdapter;


/**
 *  Integrates an MPhysSystem with the SimEthereal networking.
 *  Also provides hooks for other systems to include their own sim-ethereal
 *  updates in a standard way that works with the physics space's begin/end
 *  frame.
 *
 *  @author    Paul Speed
 */
public class ZoneNetworkSystem<S extends AbstractShape> extends AbstractGameSystem {
    static Logger log = LoggerFactory.getLogger(ZoneNetworkSystem.class);

    private ZoneManager zones;
    private PhysicsObserver physicsObserver = new PhysicsObserver();
    private DynArray<ZoneNetworkListener> listeners = new DynArray<>(ZoneNetworkListener.class);

    public ZoneNetworkSystem( ZoneManager zones ) {
        this.zones = zones;
    }

    public ZoneManager getZones() {
        return zones;
    }

    public void addZoneNetworkListener( ZoneNetworkListener l ) {
        if( l == null ) {
            throw new IllegalArgumentException("Listener cannot be null");
        }
        listeners.add(l);
    }

    public void removeZoneNetworkListener( ZoneNetworkListener l ) {
        listeners.remove(l);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize() {
        getSystem(MPhysSystem.class).addPhysicsListener(physicsObserver);
        getSystem(MPhysSystem.class).getBinEntityManager().addObjectStatusListener(physicsObserver);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void terminate() {
        getSystem(MPhysSystem.class).removePhysicsListener(physicsObserver);
        getSystem(MPhysSystem.class).getBinEntityManager().removeObjectStatusListener(physicsObserver);
    }

    /**
     *  Listens for changes in the physics objects and sends them
     *  to the zone manager.
     */
    private class PhysicsObserver extends ObjectStatusAdapter<S> implements PhysicsListener<EntityId, S> {

        private Vec3d pos = new Vec3d();
        private Quatd orient = new Quatd();

        public PhysicsObserver() {
        }

        @Override
        public void startFrame( long frameTime, double stepSize ) {
            zones.beginUpdate(frameTime);
            for( ZoneNetworkListener l : listeners.getArray() ) {
                l.beginUpdate(frameTime);
            }
        }

        @Override
        public void endFrame() {
            for( ZoneNetworkListener l : listeners.getArray() ) {
                l.endUpdate();
            }
            zones.endUpdate();
        }

        @Override
        public void update( RigidBody<EntityId, S> body ) {
            if( log.isTraceEnabled() ) {
                log.trace("update(" + body.id + ", " + body.isSleepy() + ")");
            }
            boolean active = !body.isSleepy();

            // Need to adjust the sent position to be the model origin
            // position in world space.  The center of gravity may move around
            // and client won't know about that.  So if we send the position of
            // CoG then the client won't know how to offset the actual model.
            // The server knows both things and so will send the model origin
            // which will always be consistent with where the model should be
            // viewed... and should also greatly simplify the client code in
            // the process since it no longer has to worry so much about CoG
            // offsets.
            Vec3d pos = body.shape.getWorldShapeOrigin(body);

            zones.updateEntity(body.id.getId(), active, pos, body.orientation,
                               body.getWorldBounds());
        }

        @Override
        public void objectLoaded( EntityId id, RigidBody<EntityId, S> body ) {
            if( log.isTraceEnabled() ) {
                log.trace("objectAdded(" + id + ", " + body + ")");
            }
            // Don't really care about this
        }

        @Override
        public void objectUnloaded( EntityId id, RigidBody<EntityId, S> body ) {
            if( log.isTraceEnabled() ) {
                log.trace("objectRemoved(" + id + ", " + body + ")");
            }
            zones.remove(id.getId());
        }
    }
}


