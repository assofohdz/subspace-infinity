/*
 * $Id$
 * 
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import com.simsilica.mathd.Vec3d;
import com.simsilica.es.EntityComponent;

/**
 *  Represents the linear acceleration of an object, usually gravity.
 *  This is used by the EntityBodyFactory by default to set the linear
 *  acceleration of the RigidBody upon creation.  If there is no Gravity
 *  component then the default gravity is used.
 * 
 *  FIXME - revisit if this is the right approach... since it doesn't
 *          handle runtime updates.  Note that runtime updates are harder
 *          since the object may/may not be loaded in the space at any 
 *          given time.
 *
 *  @author    Paul Speed
 */
public class Gravity implements EntityComponent {
 
    /**
     *  Gravity representing 0 linear acceleration, ie: a neutrally
     *  buoyant object.
     */
    public static final Gravity ZERO = new Gravity(0);
    
    /**
     *  Gravity representing an approximation of Earth's gravity
     *  of -10 m/sec/sec. 
     */
    public static final Gravity EARTH = new Gravity(-10);

    /**
     *  Gravity representing the typical computer game gravity of
     *  -20 m/sec/sec.
     */
    public static final Gravity GAME = new Gravity(-20);
 
    private Vec3d linearAcceleration;
    
    protected Gravity() {
    }
    
    public Gravity( double yAcceleration ) {
        this(new Vec3d(0, yAcceleration, 0));
    }
 
    public Gravity( Vec3d linearAcceleration ) {
        this.linearAcceleration = linearAcceleration;
    }
    
    public Vec3d getLinearAcceleration() {
        return linearAcceleration;
    }
    
    @Override
    public String toString() {
        return "Gravity[" + linearAcceleration + "]";
    }
}
