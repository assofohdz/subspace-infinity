/*
 * $Id$
 *
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys.debug;

import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.scene.shape.*;
import com.jme3.texture.Texture;

import com.simsilica.es.*;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.mathd.*;

import com.simsilica.mphys.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ContactDebugState<S extends AbstractShape> extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ContactDebugState.class);

    private PhysicsSpace<EntityId, S> space;
    private Grid grid;
    private Node contactRoot = new Node("contactRoot");
    private Camera camera;

    private double visibleRadius = 128;

    // We can't use the pure camera location for the visuals since the
    // application may be using a local-origin view.  So we'll represent
    // this internally.
    private Vec3d viewOrigin = new Vec3d();
    private Vec3d cameraWorld = new Vec3d();

    // We'll build our geometry relative to the view center grid cell
    // to avoid having to constantly refresh positions when the camera
    // moves in a pure 'conveyor belt' style terrain grid.
    private Vec3i lastCenter = new Vec3i(Integer.MAX_VALUE, 0, Integer.MAX_VALUE);
    private Vec3i lastCenterWorld = new Vec3i();

    private ContactListener<EntityId, S> contactListener;
    private ContactListener<EntityId, S> originalContactListener;
    private ConcurrentLinkedQueue<Contact<EntityId, S>> newContacts = new ConcurrentLinkedQueue<>();

    private int maxVisibleContacts;
    private Contact<EntityId, S>[] buffer;

    private Vec3d testLoc = new Vec3d(0.5, 65.5, 0.5);
    private Spatial testGeom;

    private ColorRGBA cpColor = new ColorRGBA(1, 0, 0, 0.5f);
    private ColorRGBA cnColor = new ColorRGBA(0, 1, 1, 0.5f);
    private ColorRGBA penColor = new ColorRGBA(0, 1, 0, 0.5f);

    // One big mesh for the contact geometry.
    private Mesh arrowMesh;
    private Geometry arrowGeom;
    private Mesh penMesh;
    private Geometry penGeom;
    private Mesh cpMesh;
    private Geometry cpGeom;

    public ContactDebugState( PhysicsSpace<EntityId, S> space ) {
        this(space, 128, 1000);
    }

    public ContactDebugState( PhysicsSpace<EntityId, S> space, double visibleRadius ) {
        this(space, visibleRadius, 1000);
    }

    @SuppressWarnings("unchecked")
    public ContactDebugState( PhysicsSpace<EntityId, S> space, double visibleRadius, int maxVisibleContacts ) {
        this.space = space;
        this.grid = space.getGrid();
        this.visibleRadius = visibleRadius;
        this.maxVisibleContacts = maxVisibleContacts;
        this.buffer = new Contact[maxVisibleContacts];
        setEnabled(false);
    }

    public Node getContactRoot() {
        return contactRoot;
    }

    public void toggleEnabled() {
        setEnabled(!isEnabled());
    }

    public void setViewOrigin( double x, double y, double z ) {
        viewOrigin.set(x, y, z);
    }

    public void setViewOrigin( Vec3d origin ) {
        setViewOrigin(origin.x, origin.y, origin.z);
    }

    public Vec3d getViewOrigin() {
        return viewOrigin;
    }

    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }

    protected Camera getCamera() {
        if( camera == null ) {
            camera = getApplication().getCamera();
        }
        return camera;
    }

    @Override
    protected void initialize( Application app ) {

        arrowMesh = new Mesh();
        arrowMesh.setMode(Mesh.Mode.Lines);
        arrowGeom = new Geometry("arrows", arrowMesh);
        arrowGeom.setMaterial(GuiGlobals.getInstance().createMaterial(cnColor, false).getMaterial());
        arrowGeom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        //arrowGeom.getMaterial().setBoolean("VertexColor", true);
        arrowGeom.setQueueBucket(Bucket.Translucent);
        contactRoot.attachChild(arrowGeom);

        penMesh = new Mesh();
        penMesh.setMode(Mesh.Mode.Lines);
        penGeom = new Geometry("pentrations", penMesh);
        penGeom.setMaterial(GuiGlobals.getInstance().createMaterial(penColor, false).getMaterial());
        penGeom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        penGeom.setQueueBucket(Bucket.Translucent);
        contactRoot.attachChild(penGeom);

        cpMesh = new Mesh();
        cpMesh.setMode(Mesh.Mode.Lines);
        cpGeom = new Geometry("contactPoints", cpMesh);
        cpGeom.setMaterial(GuiGlobals.getInstance().createMaterial(cpColor, false).getMaterial());
        cpGeom.getMaterial().getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        cpGeom.setQueueBucket(Bucket.Translucent);
        contactRoot.attachChild(cpGeom);

        Box b = new Box(0.5f, 0.5f, 0.5f);
        testGeom = new Geometry("test", b);
        testGeom.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Yellow, true).getMaterial());
        contactRoot.attachChild(testGeom);
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        getRoot().attachChild(contactRoot);

        // If the physics space already has a contact dispatcher then
        // we'll just splice ourselves in after.
        originalContactListener = space.getContactDispatcher();
        if( originalContactListener != null ) {
            // We'll call the original first and then ours... that way we don't
            // get notified about disabled contacts.  (We could flip it around
            // if we ever want to see the disabled ones.)
            contactListener = new FilteredContactListener<>(originalContactListener, new ContactObserver());
        } else {
            contactListener = new ContactObserver();
        }
        space.setContactDispatcher(contactListener);
    }

    @Override
    protected void onDisable() {
        contactRoot.removeFromParent();

        // Put back the original dispatcher
        if( space.getContactDispatcher() == contactListener ) {
            space.setContactDispatcher(originalContactListener);
        } else {
            log.warn("Could not remove the contact listener");
        }
    }

    @Override
    public void update( float tpf ) {
        updateCenter();

        double threshold = visibleRadius * visibleRadius;

        // Drain the queue
        int count = 0;
        int index = 0;
        Contact<EntityId, S> contact;
        while( (contact = newContacts.poll()) != null ) {
            double dSq = contact.contactPoint.distanceSq(cameraWorld);
            if( dSq > threshold ) {
                continue;
            }
            buffer[index] = contact;
            index = (index + 1) % maxVisibleContacts;
            count++;
        }
        if( log.isTraceEnabled() ) {
            log.trace("Frame visible contact count:" + count);
        }

        rebuildGeometry(Math.min(count, maxVisibleContacts));
    }

    protected void updateCenter() {
        Vector3f cameraPos = getCamera().getLocation();
        cameraWorld.set(viewOrigin).addLocal(new Vec3d(cameraPos));

        Vec3i center = grid.worldToCell(cameraWorld.x, 0, cameraWorld.z);
        if( !center.equals(lastCenter) ) {
            lastCenter.set(center);
            grid.cellToWorld(center, lastCenterWorld);
            updatePositions();
        }

        // Figure out how far to offset the binRoot
        //contactRoot.setLocalTranslation(
        //    (float)(lastCenterWorld.x - cameraWorld.x),
        //    (float)(lastCenterWorld.y),
        //    (float)(lastCenterWorld.z - cameraWorld.z));
        // Commented out the above to get it work in a non-continuous
        // mode like Mythruna uses.  This may break code that uses
        // continuous position updates.  May need a fancier solution. -pspeed:2022-12-09
    }

    protected void updatePositions() {
        Vec3d rel = testLoc.subtract(lastCenterWorld.toVec3d());
        testGeom.setLocalTranslation(rel.toVector3f());

        //arrowGeom.setLocalTranslation(rel.toVector3f());
    }

    protected void rebuildGeometry( int count ) {

        Vec3d origin = lastCenterWorld.toVec3d();

        // The stupid but easy way just to prove it works
        int linesPerContact = 5;
        int linesPerCp = 3;
        double arrowHeadBase = 0.9;
        double arrowHeadSize = 0.05;
        double axisSize = 0.01;
        float[] pos = new float[count * linesPerContact * 3 * 2];
        float[] penPos = new float[count * linesPerContact * 3 * 2];
        float[] cpPos = new float[count * linesPerCp * 3 * 2];
        int index = 0;
        int penIndex = 0;
        int cpIndex = 0;
        Vec3d p = new Vec3d();
        Vec3d tip = new Vec3d();
        Vec3d arrowBase = new Vec3d();
        Vec3d axis1 = new Vec3d();
        Vec3d axis2 = new Vec3d();
        for( int i = 0; i < count; i++ ) {
            Contact c = buffer[i];
            p.set(c.contactPoint).subtractLocal(origin);
            tip.set(p).addLocal(c.contactNormal);
            pos[index++] = (float)p.x;
            pos[index++] = (float)p.y;
            pos[index++] = (float)p.z;
            pos[index++] = (float)tip.x;
            pos[index++] = (float)tip.y;
            pos[index++] = (float)tip.z;

            arrowBase.set(c.contactNormal).multLocal(arrowHeadBase).addLocal(p);

            // If the normal points nearly straight up or down then just use the x/z axes
            if( Math.abs(c.contactNormal.dot(0, 1, 0)) > 0.9999 ) {
                axis1.set(1, 0, 0);
                axis2.set(0, 0, 1);
            } else {
                // Calculate them
                axis1.set(0, 0, 1).crossLocal(c.contactNormal);
                axis2.set(axis1).crossLocal(c.contactNormal);
            }
            axis1.multLocal(arrowHeadSize);
            axis2.multLocal(arrowHeadSize);

            pos[index++] = (float)tip.x;
            pos[index++] = (float)tip.y;
            pos[index++] = (float)tip.z;
            pos[index++] = (float)(arrowBase.x + axis1.x);
            pos[index++] = (float)(arrowBase.y + axis1.y);
            pos[index++] = (float)(arrowBase.z + axis1.z);

            pos[index++] = (float)tip.x;
            pos[index++] = (float)tip.y;
            pos[index++] = (float)tip.z;
            pos[index++] = (float)(arrowBase.x + axis2.x);
            pos[index++] = (float)(arrowBase.y + axis2.y);
            pos[index++] = (float)(arrowBase.z + axis2.z);

            pos[index++] = (float)tip.x;
            pos[index++] = (float)tip.y;
            pos[index++] = (float)tip.z;
            pos[index++] = (float)(arrowBase.x - axis1.x);
            pos[index++] = (float)(arrowBase.y - axis1.y);
            pos[index++] = (float)(arrowBase.z - axis1.z);

            pos[index++] = (float)tip.x;
            pos[index++] = (float)tip.y;
            pos[index++] = (float)tip.z;
            pos[index++] = (float)(arrowBase.x - axis2.x);
            pos[index++] = (float)(arrowBase.y - axis2.y);
            pos[index++] = (float)(arrowBase.z - axis2.z);

            // Now do the penetration arrows which will use a lot of the
            // same calculations
            tip.set(c.contactNormal).multLocal(-c.penetration).addLocal(p);
            arrowBase.set(c.contactNormal).multLocal(-c.penetration * arrowHeadBase).addLocal(p);
            axis1.multLocal(c.penetration);
            axis2.multLocal(c.penetration);

            penPos[penIndex++] = (float)p.x;
            penPos[penIndex++] = (float)p.y;
            penPos[penIndex++] = (float)p.z;
            penPos[penIndex++] = (float)tip.x;
            penPos[penIndex++] = (float)tip.y;
            penPos[penIndex++] = (float)tip.z;

            penPos[penIndex++] = (float)tip.x;
            penPos[penIndex++] = (float)tip.y;
            penPos[penIndex++] = (float)tip.z;
            penPos[penIndex++] = (float)(arrowBase.x + axis1.x);
            penPos[penIndex++] = (float)(arrowBase.y + axis1.y);
            penPos[penIndex++] = (float)(arrowBase.z + axis1.z);

            penPos[penIndex++] = (float)tip.x;
            penPos[penIndex++] = (float)tip.y;
            penPos[penIndex++] = (float)tip.z;
            penPos[penIndex++] = (float)(arrowBase.x + axis2.x);
            penPos[penIndex++] = (float)(arrowBase.y + axis2.y);
            penPos[penIndex++] = (float)(arrowBase.z + axis2.z);

            penPos[penIndex++] = (float)tip.x;
            penPos[penIndex++] = (float)tip.y;
            penPos[penIndex++] = (float)tip.z;
            penPos[penIndex++] = (float)(arrowBase.x - axis1.x);
            penPos[penIndex++] = (float)(arrowBase.y - axis1.y);
            penPos[penIndex++] = (float)(arrowBase.z - axis1.z);

            penPos[penIndex++] = (float)tip.x;
            penPos[penIndex++] = (float)tip.y;
            penPos[penIndex++] = (float)tip.z;
            penPos[penIndex++] = (float)(arrowBase.x - axis2.x);
            penPos[penIndex++] = (float)(arrowBase.y - axis2.y);
            penPos[penIndex++] = (float)(arrowBase.z - axis2.z);

            cpPos[cpIndex++] = (float)(p.x + axisSize);
            cpPos[cpIndex++] = (float)p.y;
            cpPos[cpIndex++] = (float)p.z;
            cpPos[cpIndex++] = (float)(p.x - axisSize);
            cpPos[cpIndex++] = (float)p.y;
            cpPos[cpIndex++] = (float)p.z;

            cpPos[cpIndex++] = (float)p.x;
            cpPos[cpIndex++] = (float)(p.y + axisSize);
            cpPos[cpIndex++] = (float)p.z;
            cpPos[cpIndex++] = (float)p.x;
            cpPos[cpIndex++] = (float)(p.y - axisSize);
            cpPos[cpIndex++] = (float)p.z;

            cpPos[cpIndex++] = (float)p.x;
            cpPos[cpIndex++] = (float)p.y;
            cpPos[cpIndex++] = (float)(p.z + axisSize);
            cpPos[cpIndex++] = (float)p.x;
            cpPos[cpIndex++] = (float)p.y;
            cpPos[cpIndex++] = (float)(p.z - axisSize);
        }

        arrowMesh.setBuffer(Type.Position, 3, pos);
        arrowGeom.updateModelBound();

        penMesh.setBuffer(Type.Position, 3, penPos);
        penGeom.updateModelBound();

        cpMesh.setBuffer(Type.Position, 3, cpPos);
        cpGeom.updateModelBound();
    }

    private class ContactObserver implements ContactListener<EntityId, S> {
        public void newContact( Contact<EntityId, S> contact ) {
            // Super important to be as light-weight here as possible because
            // there will be a LOT of contacts and any extra processing slows
            // the physics engine down.
            newContacts.add(contact);
        }
    }
}
