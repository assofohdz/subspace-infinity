/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mphys.AbstractShape;


/**
 *  A special ShapeFactory that holds a registry of other shape factories
 *  based on the ShapeInfo ID.  A default shape factory can be set that
 *  catches misses.
 *
 *  @author    Paul Speed
 */
public class ShapeFactoryRegistry<S extends AbstractShape> implements ShapeFactory<S> {

    static Logger log = LoggerFactory.getLogger(ShapeFactoryRegistry.class);

    private Map<String, ShapeFactory<? extends S>> registry = new HashMap<>();
    private ShapeFactory<? extends S> defaultFactory;

    public ShapeFactoryRegistry() {
    }

    public void setDefaultFactory( ShapeFactory<? extends S> factory ) {
        this.defaultFactory = factory;
    }

    public ShapeFactory<? extends S> getDefaultFactory() {
        return defaultFactory;
    }

    public void registerFactory( String name, ShapeFactory<? extends S> factory ) {
        registry.put(name, factory);
    }

    public ShapeFactory<? extends S> getFactory( String name ) {
        ShapeFactory<? extends S> result = registry.get(name);

        if( result == null && log.isDebugEnabled() ) {
            log.debug("Using default.  Missed:" + name + " in registry keys:" + registry.keySet());
        }
        return result == null ? defaultFactory : result;
    }

    @Override
    public S createShape( String name, double scale, Mass mass ) {
        ShapeFactory<? extends S> factory = getFactory(name);
        return factory == null ? null : factory.createShape(name, scale, mass);
    }
}
