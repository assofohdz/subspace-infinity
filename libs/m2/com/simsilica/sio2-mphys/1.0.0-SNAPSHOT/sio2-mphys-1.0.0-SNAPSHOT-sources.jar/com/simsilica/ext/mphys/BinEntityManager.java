/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Predicate;

import org.slf4j.*;

import com.simsilica.es.*;
import com.simsilica.es.base.DefaultEntity;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;

/**
 *  Provides the physics simulation the appropriate entities
 *  for a particular bin, etc.
 *
 *  @author    Paul Speed
 */
public class BinEntityManager<S extends AbstractShape> implements BinListener<EntityId,S> {

    static Logger log = LoggerFactory.getLogger(BinEntityManager.class);

    private EntityData ed;
    private BinIndex<EntityId, S> binIndex;
    private EntityChangeObserver entityListener = new EntityChangeObserver();

    private ConcurrentLinkedQueue<EntityChange> changes = new ConcurrentLinkedQueue<>();
    private Map<EntityId, HoldingEntity> changeSet = new HashMap<>();
    private Set<EntityId> toRemove = new HashSet<>();

    private Class[] types = new Class[] { SpawnPosition.class, ShapeInfo.class, Mass.class };

    // Keep track of the entities that we've updated SpawnPositions for because they
    // were being unloaded.  We are guaranteed to get a change event for these that would
    // normally reactivate the bin.  Note: if we kept a state component on the entity
    // then we could just check for 'unloaded' to know if this was a new object or just
    // one we unloaded.  The thing is, it's otherwise a waste of space so as long as our
    // work-around works we might as well use it.
    private Set<EntityId> skip = new HashSet<>();

    // Keep track of the objects we've already loaded.  The physics engine is managing
    // all of these anyway, it doesn't do much additional harm for use to keep a set
    // of the IDs that have already been loaded.
    private Set<EntityId> loaded = new HashSet<>();

    private DynArray<ObjectStatusListener> listeners = new DynArray<>(ObjectStatusListener.class);

    // When non-null, only entities for which selector.test(id) returns true
    // will be processed by this manager.  Used to split fine vs large-static
    // populators across two BinIndex instances backed by the same EntityData.
    // The selector should be stable across an entity's lifetime; transitions
    // that change the selector's verdict are not handled.
    private final Predicate<EntityId> selector;

    public BinEntityManager( EntityData ed ) {
        this(ed, null);
    }

    public BinEntityManager( EntityData ed, Predicate<EntityId> selector ) {
        this.ed = ed;
        this.selector = selector;
    }

    protected boolean accepts( EntityId id ) {
        return selector == null || selector.test(id);
    }

    public void addObjectStatusListener( ObjectStatusListener l ) {
        listeners.add(l);
    }

    public void removeObjectStatusListener( ObjectStatusListener l ) {
        listeners.remove(l);
    }

    public void update() {
        changeSet.clear();
        toRemove.clear();

        // This changeset accumulation is kind of a complicated way to avoid
        // calling objectAdded() for each component change if we already have them
        // all... which is quite common.  It also then avoids looking up the components
        // in that case.
        // Without this, for each component type, we'd fill in the entity, call objectChanged().
        // So three times per new complete entity.

        EntityChange change;
        while( (change = changes.poll()) != null ) {
            EntityComponent value = change.getComponent();
            if( log.isTraceEnabled() ) {
                log.trace("change:" + change);
            }

            // Create a holding entity even for removed components in case
            // we get a remove and a set in the same batch.
            EntityId id = change.getEntityId();

            if( value instanceof SpawnPosition ) {
                // See if we've marked this entity for skipping... we are just
                // seeing the results of our own change.
                if( skip.remove(id) ) {
                    continue;
                }
            }

            HoldingEntity entity = changeSet.get(id);
            if( entity == null ) {
                entity = new HoldingEntity(id, types);
                changeSet.put(id, entity);
            }

            if( value == null ) {
                if( log.isTraceEnabled() ) {
                    log.trace(id + " value removed:" + change.getComponentType());
                }
                toRemove.add(change.getEntityId());
                entity.clear(change.getComponentType());
            } else {
                if( log.isTraceEnabled() ) {
                    log.trace(id + ".set:" + value);
                }
                entity.set(value);
            }
        }

        for( EntityId id : toRemove ) {
            if( log.isTraceEnabled() ) {
                log.trace("toRemove:" + id);
            }
            if( loaded.remove(id) ) {
                objectRemoved(id);
            } else {
                if( log.isTraceEnabled() ) {
                    log.trace("already removed:" + id);
                }
            }
        }

        for( HoldingEntity e : changeSet.values() ) {
            if( e.loadMissing() ) {
                if( log.isTraceEnabled() ) {
                    log.trace("discovered entity:" + e.getId());
                }
                if( !accepts(e.getId()) ) {
                    // Belongs to a sibling manager (e.g. fine vs. large-static)
                    continue;
                }
                if( loaded.add(e.getId()) ) {
                    objectAdded(e);
                } else {
                    if( log.isTraceEnabled() ) {
                        log.trace("already added:" + e.getId());
                    }
                    objectUpdated(e);
                }
            }
        }
    }

    @Override
    public void initialize( BinIndex<EntityId, S> binIndex ) {
        this.binIndex = binIndex;
        log.debug("initialize()");
        ((ObservableEntityData)ed).addEntityComponentListener(entityListener);
    }

    public void tempActivate( Vec3d location ) {
        log.debug("tempActivate(" + location + ")");
        Bin<EntityId, S> bin = binIndex.getBin(location, true);
    }

    protected boolean isStatic( Mass mass ) {
        return mass.getMass() == 0;
    }

    @Override
    public void loaded( Bin<EntityId, S> bin ) {
        log.debug("loaded(" + bin + ")");

        // Find all of the objects in this zone
        Vec3i cell = bin.getGridCell().getCell();
        long binId = bin.getGridCell().getGrid().cellToId(cell.x, cell.y, cell.z);

        ComponentFilter<SpawnPosition> filter = Filters.fieldEquals(SpawnPosition.class, "binId", binId);
        for( EntityId id : ed.findEntities(filter, SpawnPosition.class, ShapeInfo.class, Mass.class) ) {
            log.debug("found:" + id);
            if( !accepts(id) ) {
                // Belongs to a sibling manager (e.g. fine vs. large-static)
                continue;
            }
            // If the update() call has already loaded this then we don't
            // need to do it again.
            if( !loaded.add(id) ) {
                log.debug("it's already loaded:" + id);
                continue;
            }
            Mass mass = ed.getComponent(id, Mass.class);
            if( mass == null ) {
                log.warn("Loaded object seems to have been removed since we queried it:" + id);
                continue;
            }
            if( isStatic(mass) ) {
                StaticBody<EntityId, S> body = bin.addStaticBody(id);
                fireStaticObjectLoaded(id, body);
            } else {
                RigidBody<EntityId, S> body = bin.addRigidBody(id);
                fireObjectLoaded(id, body);
            }
        }

    }

    @Override
    public void statusChanged( Bin<EntityId, S> bin, Bin.Status status ) {
        log.debug("statusChanged(" + bin + "):" + status);
    }

    @Override
    public void unloaded( Bin<EntityId, S> bin ) {
        log.debug("unloaded(" + bin + ")");

        for( RigidBody<EntityId, S> body : bin.getActiveObjects().getArray() ) {
            if( log.isTraceEnabled() ) {
                log.trace("  active:" + body);
            }
        }
        for( RigidBody<EntityId, S> body : bin.getInactiveObjects().getArray() ) {
            if( log.isTraceEnabled() ) {
                log.trace("  inactive:" + body);
            }
            // If the update() call already unloaded it then we don't
            // need to do it again.
            if( !loaded.remove(body.id) ) {
                if( log.isTraceEnabled() ) {
                    log.trace("it's already unloaded:" + body.id);
                }
                continue;
            }
            //ed.setComponent(body.id, new SpawnPosition(binId, body.position, body.orientation));
            // 2021-02-08 - Need to translate back from CoG-centric space to
            //              the model space-relative position that the application
            //              will understand.
            Vec3d world = body.shape.getWorldShapeOrigin(body);
            if( log.isTraceEnabled() ) {
                log.trace(body.id + " set spawn position:" + world);
            }
            ed.setComponent(body.id, new SpawnPosition(binIndex.getGrid(), world, body.orientation));
            skip.add(body.id);
            fireObjectUnloaded(body.id, body);
        }
        for( StaticBody<EntityId, S> body : bin.getStaticObjects() ) {
            if( log.isTraceEnabled() ) {
                log.trace("  static:" + body);
            }
            if( !loaded.remove(body.id) ) {
                if( log.isTraceEnabled() ) {
                    log.trace("it's already unloaded:" + body.id);
                }
                continue;
            }
            fireStaticObjectUnloaded(body.id, body);
        }
    }

    @Override
    public void terminate( BinIndex<EntityId, S> binIndex ) {
        log.debug("terminate()");
        ((ObservableEntityData)ed).removeEntityComponentListener(entityListener);
        this.binIndex = null;
    }

    /**
     *  Called when the object has been removed due to changes in the
     *  entity as opposed to the bin being unloaded.
     */
    protected void objectRemoved( EntityId id ) {
        if( log.isTraceEnabled() ) {
            log.trace("objectRemoved(" + id + ")");
        }

        // Just in case, make sure that removed objects are not hanging around
        // in the skip set.
        skip.remove(id);

        // Remove it from the physics space
        AbstractBody<EntityId, S> body = binIndex.remove(id);
        if( log.isTraceEnabled() ) {
            log.trace("removed object:" + body);
        }

        if( body instanceof RigidBody ) {
            //for( ObjectStatusListener l : listeners.getArray() ) {
            //    l.objectRemoved(id, (RigidBody<EntityId, S>)body);
            //}
            // Note: we do not update the spawn position here because
            // from our perspective the object is no longer a physical
            // object.  This method is called when the object has been
            // 'removed from the physics space', effectively.
            fireObjectUnloaded(id, (RigidBody<EntityId, S>)body);
        } else if( body instanceof StaticBody ) {
            fireStaticObjectUnloaded(id, (StaticBody<EntityId, S>)body);
        }
    }

    /**
     *  Called when the object has been added due to changes in the
     *  entity as opposed to the bin being loaded.
     */
    protected void objectAdded( Entity entity ) {
        if( skip.remove(entity.getId()) ) {
            if( log.isTraceEnabled() ) {
                log.trace("Skipping:" + entity.getId());
            }
            return;
        }
        //objectAdded(entity.getId(),
        //            entity.get(SpawnPosition.class),
        //            entity.get(ShapeInfo.class),
        //            entity.get(Mass.class));
        // 2023-06-18 - going a different direction with this.  In the
        // case of objects that are already loaded, we will not need to grab
        // the entity data anyway.  For the case that an object is not already
        // loaded then the code path to instantate it will end up looking that
        // stuff up separately anyway.  And based on comments in the broken
        // out objectAdded(id, components) method, there is a discrepancy between
        // what we think of as the location and what mphys thinks of as the location
        // so better to just not second guess anyway.  (I was hitting cases where
        // we were looking up the wrong bin... so now we won't even bother until
        // after the object is created.)
        // The only component we really need is Mass and that's only so we
        // know what's static and what isn't.
        Mass mass = entity.get(Mass.class);
        EntityId id = entity.getId();
        if( isStatic(mass) ) {
            StaticBody<EntityId, S> sb = binIndex.addStaticBody(id);
            fireStaticObjectLoaded(id, sb);
        } else {
            RigidBody<EntityId, S> body = binIndex.addRigidBody(id);
            fireObjectLoaded(id, body);
        }
    }

    /**
     *  Called when the update loop detects an entity change but it was neither
     *  added or removed from the physical objects sets.
     */
    protected void objectUpdated( Entity entity ) {
        if( log.isTraceEnabled() ) {
            log.trace("objectUpdated(" + entity.getId() + ")");
        }

        // See if the static/dynamic-ness has changed
        Mass mass = entity.get(Mass.class);
        if( isStatic(mass) ) {
            staticBodyUpdated(entity, binIndex.getStaticBody(entity.getId()));
        } else {
            rigidBodyUpdated(entity, binIndex.getRigidBody(entity.getId()));
        }
    }

    protected void staticBodyUpdated( Entity entity, StaticBody<EntityId, S> sb ) {
        EntityId id = entity.getId();
        if( log.isTraceEnabled() ) {
            log.trace("staticBodyUpdated(" + id + ")");
        }
        if( sb == null ) {
            // Maybe we transitioned from a rigid body
            RigidBody<EntityId, S> rb = binIndex.getRigidBody(id);
            if( rb == null ) {
                log.warn("Update for entity:" + id + " but no static or rigid body exists.");
                return;
            }
            if( log.isTraceEnabled() ) {
                log.trace("**** Dynamic to static:" + id);
            }

            // Let's hope this doesn't cause us problems... we'll remove it
            // and readd it.
            AbstractBody<EntityId, S> removed = binIndex.remove(id);
            if( removed != rb ) {
                log.warn("Thought we were removing:" + rb + " but actually removed:" + removed);
            }

            // Make sure that the current object position gets translated back to
            // the entity
            Vec3d world = rb.shape.getWorldShapeOrigin(rb);
            if( log.isTraceEnabled() ) {
                log.trace(id + " setting spawn position to:" + world + ", " + rb.orientation);
            }
            ed.setComponent(id, new SpawnPosition(binIndex.getGrid(), world, rb.orientation));
            skip.add(id);
            fireObjectUnloaded(id, rb);

            // Add it back as a static object
            sb = binIndex.addStaticBody(id);
            fireStaticObjectLoaded(id, sb);
        } else {
            // Maybe we've moved
            SpawnPosition pos = entity.get(SpawnPosition.class);
            if( pos != null ) {
                sb.shape.setWorldShapeOrigin(sb, pos.getLocation(), pos.getOrientation());
            }
        }
    }

    protected void rigidBodyUpdated( Entity entity, RigidBody<EntityId, S> rb ) {
        EntityId id = entity.getId();
        if( log.isTraceEnabled() ) {
            log.trace("rigidBodyUpdated(" + id + ")");
        }
        if( rb == null ) {
            // Maybe we transitioned from a static body
            StaticBody<EntityId, S> sb = binIndex.getStaticBody(id);
            if( sb == null ) {
                log.warn("Update for entity:" + id + " but no rigid or static body exists.");
                return;
            }
            if( log.isTraceEnabled() ) {
                log.trace("**** Static to dynamic:" + id);
            }
            // Let's hope this doesn't cause us problems... we'll remove it
            // and readd it.
            AbstractBody<EntityId, S> removed = binIndex.remove(id);
            if( removed != sb ) {
                log.warn("Thought we were removing:" + sb + " but actually removed:" + removed);
            }
            fireStaticObjectUnloaded(id, sb);

            // Add it back as a dynamic object
            rb = binIndex.addRigidBody(id);
            fireObjectLoaded(id, rb);
        }
    }

    @SuppressWarnings("unchecked")
    protected final void fireObjectLoaded( EntityId id, RigidBody<EntityId, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("fireObjectLoaded(" + id + ")");
        }
        for( ObjectStatusListener l : listeners.getArray() ) {
            l.objectLoaded(id, body);
        }
    }

    @SuppressWarnings("unchecked")
    protected final void fireObjectUnloaded( EntityId id, RigidBody<EntityId, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("fireObjectUnloaded(" + id + ")");
        }
        for( ObjectStatusListener l : listeners.getArray() ) {
            l.objectUnloaded(id, body);
        }
    }

    @SuppressWarnings("unchecked")
    protected final void fireStaticObjectLoaded( EntityId id, StaticBody<EntityId, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("fireStaticObjectLoaded(" + id + ")");
        }
        for( ObjectStatusListener l : listeners.getArray() ) {
            l.staticObjectLoaded(id, body);
        }
    }

    @SuppressWarnings("unchecked")
    protected final void fireStaticObjectUnloaded( EntityId id, StaticBody<EntityId, S> body ) {
        if( log.isTraceEnabled() ) {
            log.trace("fireStaticObjectUnloaded(" + id + ")");
        }
        for( ObjectStatusListener l : listeners.getArray() ) {
            l.staticObjectUnloaded(id, body);
        }
    }

    /**
     *  We need to know about all entity changes that might add/remove
     *  objects from the physics space... across the whole world.  For example,
     *  if a physics object is created in some far corner of the world we will
     *  need to activate in the physics engine so that the bin gets activated,
     *  etc.  Likewise, if some object is removed we might as well use these
     *  same events for that... rather than keep a container around per bin.
     *  For an ES, this is technically a "bad practice" but I think it's the
     *  only good way to handle these sorts of cases.  The world could have
     *  hundreds of thousands of bodies and we only care about the active ones...
     *  hopefully a really small percentage.  The thing is, we don't know if
     *  they are active until we throw them into the physics engine to see.
     *  So there is no way to select for it at the ES level.
     */
    private class EntityChangeObserver implements EntityComponentListener {

        @Override
        public void componentChange( EntityChange change ) {
            // We only care about a few components and we should quickly
            // short-circuit otherwise to avoid lag
            Class type = change.getComponentType();
            if( type != SpawnPosition.class && type != ShapeInfo.class && type != Mass.class ) {
                return;
            }

            // Queue the change for processing on the game loop thread.
            changes.add(change);
        }
    }

    /**
     *  Used to hold the values that we collect during change handling.
     *  It's basically a DefaultEntity that has set() overridden to not write
     *  back to the EntityData database.  That way we can fill in the values
     *  we have as we find them in the change set without causing additional
     *  change events.
     */
    private class HoldingEntity extends DefaultEntity {

        public HoldingEntity( EntityId id, Class[] types ) {
            super(null, id, new EntityComponent[types.length], types);
        }

        @Override
        public void set( EntityComponent c ) {
            EntityComponent[] components = getComponents();
            for( int i = 0; i < components.length; i++ ) {
                if( types[i].isInstance(c) ) {
                    components[i] = c;
                    return;
                }
            }
        }

        public void clear( Class type ) {
            EntityComponent[] components = getComponents();
            for( int i = 0; i < components.length; i++ ) {
                if( types[i] == type ) {
                    components[i] = null;
                    return;
                }
            }
        }

        /**
         *  Attempts to load any components that are still missing.  Returns
         *  true if all components have been filled in.
         */
        @SuppressWarnings("unchecked")
        public boolean loadMissing() {
            EntityComponent[] components = getComponents();
            int completed = 0;
            for( int i = 0; i < types.length; i++ ) {
                if( components[i] == null ) {
                    components[i] = ed.getComponent(getId(), types[i]);
                    if( components[i] != null ) {
                        completed++;
                    }
                } else {
                    completed++;
                }
            }
            return completed == types.length;
        }
    }
}




