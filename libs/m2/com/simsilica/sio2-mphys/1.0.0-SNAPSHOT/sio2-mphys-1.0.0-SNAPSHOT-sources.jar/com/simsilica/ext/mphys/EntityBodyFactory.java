/*
 * $Id$
 * 
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.util.function.Supplier;

import org.slf4j.*;

import com.google.common.base.Function;

import com.simsilica.es.*;
import com.simsilica.mathd.*;
import com.simsilica.mphys.*;


/**
 *  Creates rigid bodies for entities using a preconfigured gravity acceleration
 *  and shape factory.
 *
 *  @author    Paul Speed
 */
public class EntityBodyFactory<S extends AbstractShape> implements PhysicsFactory<EntityId, S> {

    static Logger log = LoggerFactory.getLogger(EntityBodyFactory.class);

    private EntityData ed;
    private Vec3d defaultGravity;
    private ShapeFactory<S> shapeFactory;
    private DynArray<Function> dynamicInitializers = new DynArray<>(Function.class);
    private ShapeFactory<S> errorFactory;

    public EntityBodyFactory( EntityData ed, Vec3d defaultGravity, ShapeFactory<S> shapeFactory ) {
        this.ed = ed;
        this.defaultGravity = defaultGravity;
        this.shapeFactory = shapeFactory;
    }    

    public void setDefaultGravity( Vec3d defaultGravity ) {
        this.defaultGravity = defaultGravity;
    }
    
    public Vec3d getDefaultGravity() {
        return defaultGravity;
    }
    
    public void setShapeFactory( ShapeFactory<S> shapeFactory ) {
        this.shapeFactory = shapeFactory;
    }
    
    public ShapeFactory getShapeFactory() {
        return shapeFactory;
    }
 
    /**
     *  Sets a shape factory that will be used if for some reason the
     *  regular shape factory throws an exception.  The error factory
     *  should be written in such a way that it provides an error-free
     *  stand-in shape so that the rest of the program can continue without
     *  crashing the whole physics space.
     */   
    public void setErrorFactory( ShapeFactory<S> errorFactory ) {
        this.errorFactory = errorFactory; 
    }
    
    public ShapeFactory<S> getErrorFactory() {
        return errorFactory;
    }

    /**
     *  Adds an initializer that will be passed every new RigidBody created
     *  in case there is additional setup to be performed.
     */
    public void addDynamicInitializer( Function<RigidBody<EntityId, S>, ?> i ) {
        if( i == null ) {
            throw new IllegalArgumentException("Initializer cannot be null");
        }
        dynamicInitializers.add(i);
    }
    
    public void removeDynamicInitializer( Function<RigidBody<EntityId, S>, ?> i ) {
        dynamicInitializers.remove(i);
    }

    protected <T extends EntityComponent> T getComponent( EntityId id, Class<T> type ) {
        return ed.getComponent(id, type);
    }

    protected S createShape( String name, double scale, Mass mass ) {
        try {
            return shapeFactory.createShape(name, scale, mass);
        } catch( Exception e ) {
            log.error("Error creating shape for:" + name + " scale:" + scale, e);
            
            // Return a default error shape
            return errorFactory.createShape(name, scale, mass);
        }
    } 

    /**
     *  Default implementation creates a RigidBody using the pos, info, and mass.  The
     *  shape info is passed to the shape factory along with the mass to create the body's
     *  shape.  If the gravity parameter is not specified then the current defaultGravity is 
     *  used to set the object's linear acceleration. 
     */
    protected RigidBody<EntityId, S> createRigidBody( EntityId id, 
                                                      SpawnPosition pos, ShapeInfo info, 
                                                      Mass mass, Gravity gravity ) {

        log.debug("createRigidBody(" + id + ")");
                    
        S shape = createShape(info.getShapeName(ed), info.getScale(), mass);
 
//log.info("Wobble: spawn pos:" + pos.getLocation());
        RigidBody<EntityId, S> body = new RigidBody<>(id, shape);
        //body.position.set(pos.getLocation());
        //body.orientation.set(pos.getOrientation());
        // 2021-02-08 - SpawnPosition is in the application-understood 'model space'
        //              reference frame.  The body is in CoG-relative reference
        //              frame.  setWorldShapeOrigin() translates.
        shape.setWorldShapeOrigin(body, pos.getLocation(), pos.getOrientation());
//log.info("Wobble: body pos after world shape:" + body.position);
 
        // Set the gravity
        if( gravity == null ) {                                       
            body.setLinearAcceleration(defaultGravity);
        } else {
            body.setLinearAcceleration(gravity.getLinearAcceleration());
        }
                  
//if( id.getId() == 2 ) {        
//    body.setControlDriver(new UprightDriver<EntityId, S>());
//}

        return body;
    }
    
    /**
     *  Default implementation creates a StaticBody using the pos, info, and mass.  The
     *  shape info is passed to the shape factory along with the mass to create the body's
     *  shape.  
     */
    protected StaticBody<EntityId, S> createStaticBody( EntityId id, 
                                                        SpawnPosition pos, ShapeInfo info, Mass mass ) {
        log.debug("createStaticBody(" + id + ")");
                    
        S shape = createShape(info.getShapeName(ed), info.getScale(), mass);
                    
        StaticBody<EntityId, S> body = new StaticBody<>(id, shape);
        //body.position.set(pos.getLocation());
        //body.orientation.set(pos.getOrientation());
        // 2021-02-08 - SpawnPosition is in the application-understood 'model space'
        //              reference frame.  The body is in CoG-relative reference
        //              frame.  setWorldShapeOrigin() translates.
        shape.setWorldShapeOrigin(body, pos.getLocation(), pos.getOrientation());
                    
        return body;
    }

    /** 
     *  Creates the rigid body and runs any registered initializers against it.
     */
    @Override
    @SuppressWarnings("unchecked")
    public RigidBody<EntityId, S> createRigidBody( EntityId id ) {
        RigidBody<EntityId, S> body = createRigidBody(id, 
                                            getComponent(id, SpawnPosition.class), 
                                            getComponent(id, ShapeInfo.class), 
                                            getComponent(id, Mass.class),
                                            getComponent(id, Gravity.class)); 
        // Run the custom initializers
        for( Function<RigidBody<EntityId, S>, ?> i : dynamicInitializers.getArray() ) {
            i.apply(body);
        }  
        return body;
    }
    
    @Override    
    public StaticBody<EntityId, S> createStaticBody( EntityId id ) {
        return createStaticBody(id, 
                                getComponent(id, SpawnPosition.class), 
                                getComponent(id, ShapeInfo.class), 
                                getComponent(id, Mass.class)); 
    }
     
    @Override    
    public Joint<EntityId, S> createJoint( EntityId key, RigidBody<EntityId, S> end1, RigidBody<EntityId, S> end2 ) {
        throw new UnsupportedOperationException();
    }  
}


