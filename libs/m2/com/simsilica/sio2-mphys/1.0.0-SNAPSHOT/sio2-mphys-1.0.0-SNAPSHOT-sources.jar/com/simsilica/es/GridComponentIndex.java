/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.es;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Used by a SpatialEntityContainer to build component-specific
 *  grid-based filters.
 *
 *  @author    Paul Speed
 */
public abstract class GridComponentIndex<C extends EntityComponent> {
    static Logger log = LoggerFactory.getLogger(GridComponentIndex.class);

    private Class<C> componentClass;
    private final Grid grid;
    private final int gridRadius;

    private final Vec3d center = new Vec3d();
    private final Vec3i centerCell = new Vec3i();

    // Book-keeping
    private int size;
    private ComponentFilter[] filterArray;
    private ComponentFilter<C> positionFilter;

    protected GridComponentIndex( Class<C> componentClass, Grid grid, int gridRadius ) {
        this.componentClass = componentClass;
        this.grid = grid;
        this.gridRadius = gridRadius;

        this.size= gridRadius * 2 + 1;
        this.filterArray = new ComponentFilter[size * size];
    }

    public ComponentFilter<C> getIndexFilter() {
        return positionFilter;
    }

    public ComponentFilter<C> createFalseFilter() {
        ComponentFilter<C> f1 = createBinFilter(0);
        ComponentFilter<C> f2 = createBinFilter(1);
        return Filters.and(componentClass, f1, f2);
    }

    @SafeVarargs
    public final void validate( Class<? extends EntityComponent>... componentTypes ) {
        boolean found = false;
        for( Class type : componentTypes ) {
            if( type == componentClass ) {
                found = true;
                break;
            }
        }
        if( !found ) {
            throw new IllegalArgumentException("Component types does not include " + componentClass.getName());
        }
    }

    public boolean setCenter( Vec3d center, boolean forceUpdate ) {
        if( !forceUpdate && this.center.equals(center) ) {
            // No update needed
            return false;
        }
        this.center.set(center);

        Vec3i newGridCenter = grid.worldToCell(center);
        if( !forceUpdate && newGridCenter.equals(centerCell) ) {
            // No update needed
            return false;
        }
        centerCell.set(newGridCenter);

        recalculateFilter();
        return true;
    }

    protected abstract ComponentFilter<C> createBinFilter( long cellId );

    @SuppressWarnings("unchecked")
    protected void recalculateFilter() {
        int xBase = centerCell.x - gridRadius;
        int yBase = centerCell.y;
        int zBase = centerCell.z - gridRadius;
        int index = 0;
        for( int x = 0; x < size; x++ ) {
            for( int z = 0; z < size; z++ ) {
                long id = grid.cellToId(xBase + x, yBase, zBase + z);
                ComponentFilter filter = createBinFilter(id);
                filterArray[index++] = filter;
            }
        }
        this.positionFilter = (ComponentFilter<C>)Filters.or(componentClass, filterArray);
    }

}
