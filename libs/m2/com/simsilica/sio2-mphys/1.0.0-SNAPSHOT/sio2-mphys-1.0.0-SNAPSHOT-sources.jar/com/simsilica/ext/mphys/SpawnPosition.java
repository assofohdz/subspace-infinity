/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys;

import java.util.Objects;

import com.google.common.base.MoreObjects;

import com.simsilica.es.ComponentFilter;
import com.simsilica.es.EntityComponent;
import com.simsilica.es.Filters;
import com.simsilica.es.IndexedField;
import com.simsilica.es.PersistentComponent;
import com.simsilica.mathd.*;


/**
 *  Represents the initial physical position of an entity.
 *
 *  @author    Paul Speed
 */
public class SpawnPosition implements EntityComponent, PersistentComponent {
    private Vec3d location;
    private Quatd orientation;

    @IndexedField
    private long binId;

    // FIXME: make this constructor protected when zay-es persistence can
    // work with non-public constructors.
    public SpawnPosition() {
    }

    public SpawnPosition( Grid grid, double x, double y, double z ) {
        this(grid, new Vec3d(x, y, z), new Quatd());
    }

    public SpawnPosition( Grid grid, double x, double y, double z, Quatd orientation ) {
        this(grid, new Vec3d(x, y, z), orientation);
    }

    public SpawnPosition( Grid grid, Vec3d location ) {
        this(grid, location, new Quatd());
    }

    public SpawnPosition( Grid grid, Vec3d location, double facing ) {
        this(grid, location, new Quatd().fromAngles(0, (float)facing, 0));
    }

    public SpawnPosition( Grid grid, Vec3d location, Quatd orientation ) {
        this.location = location;
        this.orientation = orientation;
        Vec3i cell = grid.worldToCell(location);
        this.binId = grid.cellToId(cell.x, cell.y, cell.z);
    }

    public SpawnPosition( long binId, Vec3d location, Quatd orientation ) {
        this.binId = binId;
        this.location = location;
        this.orientation = orientation;
    }

    public static ComponentFilter<SpawnPosition> binFilter( long binId ) {
        return Filters.fieldEquals(SpawnPosition.class, "binId", binId);
    }

    public Vec3d getLocation() {
        return location;
    }

    public Quatd getOrientation() {
        return orientation;
    }

    public long getBinId() {
        return binId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("location", location)
            .add("orientation", orientation)
            .add("binId", binId)
            .toString();
    }
}
