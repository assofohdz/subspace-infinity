/*
 * $Id$
 * 
 * Copyright (c) 2019, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.ext.mphys.debug;

import java.io.*; // for the dump stuff
import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.*;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.scene.debug.WireBox;
import com.jme3.texture.Texture;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.input.*;
import com.simsilica.mathd.*;

import com.simsilica.mphys.*;

/**
 *  Debug view of the bin boundaries and the states of the bins.
 *
 *  @author    Paul Speed
 */
public class BinStatusState<S extends AbstractShape> extends BaseAppState {

    public static final FunctionId F_PHYSICS_DUMP = new FunctionId("Physics Dump");    

    static Logger log = LoggerFactory.getLogger(BinStatusState.class);

    private PhysicsSpace space;
    private Grid grid; 
    private Node binRoot;
    private Camera camera; 

    // A single box that we'll clone as needed to make the different
    // bins.
    private Geometry boxTemplate;

    // The height to draw the 'ground' plane bin elements.
    private double groundHeight;
    
    // We can't use the pure camera location for the visuals since the
    // application may be using a local-origin view.  So we'll represent
    // this internally.
    private Vec3d viewOrigin = new Vec3d();
    
    // The above are an attempt to cover both the case where the local
    // world moves continuously with the camera as well as the case where
    // the local origin only moves when crossing grid boundaries of some
    // kind.  In the case of a continuosly moving 'origin', the viewOrigin
    // and camera would move together.  Otherwise, the viewOrigin only changes
    // when the camera crosses a boundary.
    //
    // We already track the last center location so we can radius-filter.
    // I think we could also use that to avoid having to constantly reset
    // the bin locations.  We can move the binRoot by the constant difference
    // and then just move the bins themselves when the center changes.

    private Vec3i lastCenter = new Vec3i();
    private Vec3i lastCenterWorld = new Vec3i();
    
    private BinObserver binListener = new BinObserver();
    private ConcurrentLinkedQueue<BinEvent> binEvents = new ConcurrentLinkedQueue<>();
     
    private Map<GridCell, StatusView> statusIndex = new HashMap<>();
    private int radius = 5;
    
    private PhysicsListener debugDumper = new DebugDumper();

    public BinStatusState( PhysicsSpace space ) {
        this(space, 0);
    }
    
    public BinStatusState( PhysicsSpace space, float groundHeight ) {
        this.space = space;
        this.groundHeight = groundHeight;        
        this.grid = space.getGrid();
        setEnabled(true);
    }
 
    //public static void initializeDefaultMappings( InputMapper inputMapper ) {
    //    inputMapper.map(F_PHYSICS_DUMP, KeyInput.KEY_F3);
    //}

    @SuppressWarnings("unchecked")
    public void logPhysicsState() {
        // Make sure to do the dump on the physics thread by registering
        // a temporary listener that will fire once and remove itself.
        space.addPhysicsListener(debugDumper);       
    }
 
    public void toggleEnabled() {
        setEnabled(!isEnabled());
    }
 
    public void setViewOrigin( double x, double y, double z ) {
        viewOrigin.set(x, y, z);
        //updateCenter();
    }
    
    public void setViewOrigin( Vec3d origin ) {
        setViewOrigin(origin.x, origin.y, origin.z);
    }
    
    public Vec3d getViewOrigin() {
        return viewOrigin;
    }
     
    protected Node getRoot() {
        return ((SimpleApplication)getApplication()).getRootNode();
    }
 
    protected Camera getCamera() {
        if( camera == null ) {
            camera = getApplication().getCamera();
        }
        return camera;
    }
    
    protected Geometry createBoxTemplate( Application app ) {
        GuiGlobals globals = GuiGlobals.getInstance();
        Texture texture = globals.loadTexture("Interface/bottom-corners2.png", true, true);    
        Material mat = globals.createMaterial(ColorRGBA.Pink, false).getMaterial();
        mat.setTexture("ColorMap", texture);
        mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        mat.getAdditionalRenderState().setDepthWrite(false);
 
        float xHalf = grid.getSpacing().x * 0.5f;
        float zHalf = grid.getSpacing().z * 0.5f;
        float height = 2;                     
        WireBox box = new WireBox(xHalf * 0.995f, height * 0.995f, zHalf * 0.995f);
        box.setBuffer(Type.TexCoord, 2, new float[]{0, 0,
                                                    1, 0,
                                                    1, 0.5f,
                                                    0, 0.5f,
                                                        
                                                    1, 0,
                                                    0, 0,
                                                    0, 0.5f,
                                                    1, 0.5f});
 
        Geometry geom = new Geometry("boxTemplate", box);
        geom.setMaterial(mat);
        geom.setQueueBucket(Bucket.Transparent);
        geom.setUserData("layer", 4);        
        
        // Set an initial offset so we know where it's lower left corner
        // is.
        geom.setLocalTranslation(xHalf, height, zHalf);
        
        return geom;
    }
    
    @Override
    protected void initialize( Application app ) {
    
        log.info("initialize()");
    
        this.binRoot = new Node("binRoot");
 
        this.boxTemplate = createBoxTemplate(app);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected void onEnable() {
        GuiGlobals.getInstance().getInputMapper().addDelegate(F_PHYSICS_DUMP, this, "logPhysicsState");
        getRoot().attachChild(binRoot);
        space.addBinListener(binListener);
        resetViews();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    protected void onDisable() {
        GuiGlobals.getInstance().getInputMapper().removeDelegate(F_PHYSICS_DUMP, this, "logPhysicsState");
        space.removeBinListener(binListener);
        binRoot.removeFromParent();
        statusIndex.clear();
    }
    
    @Override
    public void update( float tpf ) {
    
        if( !binEvents.isEmpty() ) {
            // Process any new bin status changes since last frame
            BinEvent e = null;
            while( (e = binEvents.poll()) != null ) {
                updateStatus(e.cell, e.status);
            }
        }
    
        updateCenter();
    }
    
    protected void resetViews() {
        Vector3f cameraPos = getCamera().getLocation();
        Vec3d world = viewOrigin.add(new Vec3d(cameraPos));        
        Vec3i center = grid.worldToCell(world.x, 0, world.z);
        lastCenter.set(center);
         
        for( int x = center.x - radius; x <= center.x + radius; x++ ) {
            for( int z = center.z - radius; z <= center.z + radius; z++ ) {
                GridCell cell = grid.getGridCell(x, 0, z);
                Bin.Status status = space.getBinStatus(cell);
                updateStatus(cell, status);
            }
        }
        
        updatePositions();
    }   
 
    protected void updateCenter() {
        Vector3f cameraPos = getCamera().getLocation();
        Vec3d world = viewOrigin.add(new Vec3d(cameraPos));         
        
        Vec3i center = grid.worldToCell(world.x, 0, world.z); 
        if( !center.equals(lastCenter) ) {
            lastCenter.set(center);
            Vec3i cellWorld = grid.cellToWorld(center, lastCenterWorld);
            updatePositions();
        }
        
        // Figure out how far to offset the binRoot       
        binRoot.setLocalTranslation(
            (float)(lastCenterWorld.x - world.x),
            (float)(lastCenterWorld.y),
            (float)(lastCenterWorld.z - world.z));
        
    }
 
    protected void updatePositions() {
System.out.println("----- updatePositions() lastCenter:" + lastCenter);    
        for( StatusView view : statusIndex.values() ) {
            view.updatePosition(lastCenter);
        }
    }

    private StatusView getView( GridCell cell, boolean create ) {
        StatusView existing = statusIndex.get(cell);
        if( existing == null && create ) {
            existing = new StatusView(cell);
            statusIndex.put(cell, existing);
            existing.updatePosition(lastCenter);
        }
        return existing;
    }

    protected void updateStatus( GridCell cell, Bin.Status status ) {
        if( status != null ) {
            StatusView view = getView(cell, true);
            view.update(status);
            view.updatePosition(lastCenter);            
        } else {
            // It's being removed
            remove(cell);
        }
    } 

    private void remove( GridCell cell ) {
        StatusView existing = statusIndex.remove(cell);
        if( existing != null ) {
            existing.detach();
        }
    }

    private class StatusView {
        Geometry view;
        GridCell cell;
        ColorRGBA color = new ColorRGBA(1, 0, 1, 1);
 
        public StatusView( GridCell cell ) {
            this.cell = cell;
 
            view = boxTemplate.clone(true);
            view.setName("view:" + cell);
 
            view.getMaterial().setColor("Color", color);
        }
        
        public void detach() {
            view.removeFromParent();
        }
        
        public void update( Bin.Status status ) {
            switch( status ) {
                case Empty:
                    color.set(0, 0, 0, 1);
                    break;
                case Static:
                    color.set(0, 0, 1, 1);
                    break;
                case Asleep:
                    color.set(0, 1, 1, 1);
                    break;
                case Active:
                    color.set(1, 0, 0, 1);
                    break;                    
            }
        }
        
        public void updatePosition( Vec3i centerCell ) {
            int xDelta = Math.abs(cell.getCell().x - centerCell.x);  
            int zDelta = Math.abs(cell.getCell().z - centerCell.z);
            boolean visible = xDelta <= 5 && zDelta <= 5;
            if( visible ) {
                binRoot.attachChild(view);
            } else {
                view.removeFromParent();
            }
            
            // Position this bin relative to the view origin
            double x = cell.getWorldOrigin().x - lastCenterWorld.x; //viewOrigin.x;
            double y = groundHeight - lastCenterWorld.y; //viewOrigin.y;
            double z = cell.getWorldOrigin().z - lastCenterWorld.z; //viewOrigin.z;
            Vector3f offset = boxTemplate.getLocalTranslation();
            view.setLocalTranslation((float)x + offset.x, (float)y + offset.y, (float)z + offset.z);             
        }
    }

    private class BinEvent {
        GridCell cell;
        Bin.Status status;
        
        public BinEvent( GridCell cell, Bin.Status status ) {
            this.cell = cell;
            this.status = status;
        }
    }
    
    private class BinObserver implements BinListener<Integer, S> {
        
        @Override 
        public void initialize( BinIndex<Integer, S> binIndex ) {
        }
    
        @Override 
        public void terminate( BinIndex<Integer, S> binIndex ) {
        }

        @Override
        public void loaded( Bin<Integer, S> bin ) {
            log.info("loaded(" + bin + ") thread:" + Thread.currentThread());
            binEvents.add(new BinEvent(bin.getGridCell(), bin.getStatus()));        
        }
        
        @Override
        public void unloaded( Bin<Integer, S> bin ) {
            log.info("unloaded(" + bin + ") thread:" + Thread.currentThread());                
            binEvents.add(new BinEvent(bin.getGridCell(), null));        
        }
        
        @Override
        public void statusChanged( Bin<Integer, S> bin, Bin.Status status ) {
            log.info("stateChanged(" + bin + ", " + status + ") thread:" + Thread.currentThread());        
            // We may get events out of order so we should just grab
            // the latest status instead of using what was passed in.
            binEvents.add(new BinEvent(bin.getGridCell(), bin.getStatus()));        
        }
    }
    
    private class DebugDumper implements PhysicsListener {
    
        @SuppressWarnings("unchecked")
        public void startFrame( long frameTime, double stepSize ) {
            StringWriter sOut = new StringWriter();
            PrintWriter out = new PrintWriter(sOut);
            space.writeDebugInfo(out);
            out.close();
            log.info("Physics dump:\n" + sOut.toString());
            
            // Remove ourselves now that we've done our job
            space.removePhysicsListener(this); 
        }
        
        public void update( RigidBody body ) {
        }
        
        public void endFrame() {
        }        
    }
    
    
}

