/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.es;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  Extends a regular EntityContainer to provide spatial filtering
 *  based on grid and position.
 *
 *  @author    Paul Speed
 */
public abstract class SpatialEntityContainer<T, C extends EntityComponent> extends EntityContainer<T> {
    static Logger log = LoggerFactory.getLogger(SpatialEntityContainer.class);

    private GridComponentIndex<C> gridIndex;
    private ComponentFilter<C> positionFilter;

    @SuppressWarnings("unchecked")
    @SafeVarargs
    protected SpatialEntityContainer( GridComponentIndex<C> gridIndex, EntityData ed, Class<? extends EntityComponent>... componentTypes ) {
        super(ed, null, componentTypes);
        this.gridIndex = gridIndex;
        gridIndex.validate(componentTypes);

        // Just in case, set a filter that will never return a value
        updateSpatialFilter(null);
    }

    public ComponentFilter<C> getPositionFilter() {
        return positionFilter;
    }

    protected void updateSpatialFilter( ComponentFilter<C> filter ) {
        if( filter == null ) {
            // Make sure that a null filter returns nothing instead of everything.
            // Zay-es doesn't have an 'always false' filter so we'll make one by
            // testing for the impossible.
            filter = gridIndex.createFalseFilter();
            this.positionFilter = null;
        } else {
            this.positionFilter = filter;
        }
        super.setFilter(filter);
    }

    protected void setFilter( ComponentFilter filter ) {
        throw new UnsupportedOperationException("SpatialEntityContainer manages its own filter");
    }

    public boolean setCenter( Vec3d center, boolean forceUpdate ) {
        boolean changed = gridIndex.setCenter(center, forceUpdate);
        if( changed ) {
            updateSpatialFilter(gridIndex.getIndexFilter());
        }
        return changed;
    }
}

