/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.config;

import java.io.Serializable;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.jme3.asset.AssetManager;
import com.jme3.material.*;
import com.jme3.shader.VarType;

import com.simsilica.mblock.geom.GeomPart;
import com.simsilica.mblock.geom.GeomReq;
import com.simsilica.mblock.geom.MaterialType;

/**
 *  Used to configure a JME material.  This is similar to what a j3m
 *  provides except it will support all material options and may eventually
 *  support alternate configurations, etc..
 *
 *  @author    Paul Speed
 */
public class MaterialConfig implements Serializable {

    static Logger log = LoggerFactory.getLogger(MaterialConfig.class);

    static final long serialVersionUID = 42L;

    private String name;
    private String j3md;

    // I think this will make JSON happier
    private Map<String, Object> properties = new HashMap<>();

    // I think I will regret directly putting this here.
    private RenderState renderState = new RenderState();

    private List<String> inherit = null; // only set if used

    // Since the API does not provide an easy json way of removing
    // set values, we won't include any defaults here.  We can always
    // add them on the constructor if we want.
    private EnumSet<GeomReq> geomReqs = EnumSet.noneOf(GeomReq.class);

    /**
     *  Only used if set, controls the material ordering.
     */
    private Integer layer;

    // Cached when first looked up.
    private transient MaterialDef matDef;

    public MaterialConfig( String name, String j3md ) {
        this.name = name;
        this.j3md = j3md;
    }

    public MaterialConfig( String name, MaterialConfig inherit ) {
        this.name = name;
        this.j3md = inherit.j3md;
        this.renderState = inherit.renderState != null ? inherit.renderState.clone() : null;
        this.properties.putAll(inherit.properties);
    }

    public MaterialType createMaterialType() {
log.info("createMaterialType(" + name + ") layer:" + layer + " reqs:" + geomReqs);
        return new MaterialType(name, layer, geomReqs);
    }

    public MaterialType getMaterialType() {
        return createMaterialType().internalize();
    }

    public String getName() {
        return name;
    }

    public String getJ3md() {
        return j3md;
    }

    public RenderState getRenderState() {
        return renderState;
    }

    public void addGeomReq( GeomReq req ) {
        geomReqs.add(req);
    }

    public EnumSet<GeomReq> getGeomReqs() {
        return geomReqs;
    }

    public EnumSet<GeomReq> getImpliedReqs() {
        return GeomReq.expandImplied(geomReqs);
    }

    /**
     *  Returns true if the specified part is valid for this material type.
     */
    public boolean canRender( GeomPart part ) {
        // This one can be slower as it's used for final UI editor filtering
        EnumSet<GeomReq> caps = part.calculateGeomCaps();
        return caps.containsAll(getImpliedReqs());
    }

    public EnumSet<GeomReq> getMissingReqs( GeomPart part ) {
        EnumSet<GeomReq> caps = part.calculateGeomCaps();
        EnumSet<GeomReq> result = getImpliedReqs().clone();
        result.removeAll(caps);
        return result;
    }

    //@Override
    public Object get( Object key ) {
        return properties.get(key);
    }

    //@Override
    public Set<Map.Entry<String, Object>> entrySet() {
        return properties.entrySet();
    }

    //@Override
    public Object put( String key, Object value ) {
        return properties.put(key, value);
    }

    private static Object toValue( AssetManager assets, VarType type, Object value ) {
        if( value == null ) {
            return null;
        }
        if( value instanceof TextureConfig ) {
            value = ((TextureConfig)value).create(assets);
        }
        // JME is ok with converting int -> float, etc. as material parameters
        // but not when passing through to a define list.  So we'll make sure
        // to sanitize some of the values that are likely to be passed as
        // literals somewhere.
        switch( type ) {
            case Float:
                if( value instanceof Float ) {
                    return value;
                }
                if( value instanceof Number ) {
                    return ((Number)value).floatValue();
                }
                throw new IllegalArgumentException("Type mismatch for var type:" + type
                                                    + ", value type:" + value.getClass());
            case Int:
                if( value instanceof Integer ) {
                    return value;
                }
                if( value instanceof Number ) {
                    return ((Number)value).intValue();
                }
                throw new IllegalArgumentException("Type mismatch for var type:" + type
                                                    + ", value type:" + value.getClass());
        }
        return value;
    }

    protected void applyConfig( AssetManager assets, MaterialRegistry materials, Material target, Set<MaterialConfig> visited ) {
        log.info("Applying material config:" + getName());
        if( !visited.add(this) ) {
            log.info("  already visited:" + getName());
            return;
        }

        Set<GeomReq> implied = getImpliedReqs();
        for( MaterialConfig config : materials.getConfigs(getName()) ) {
            // We just check it,  not add it... because if we haven't
            // visited it yet then the applyconfig will mark it.
            // We want to check it because it's possible that the rest of
            // this loop does a lot of work we can avoid.
            if( visited.contains(config) ) {
                continue;
            }
            // See if it's compatible with this material.  "Compatible"
            // in this case means that the sibling material doesn't have
            // any requirements that we don't... ie: a subset of our requirements.
            // This allows the (x, y, z, a, b, c) materials to inherit a more general
            // (x) or (x, y).
            if( implied.containsAll(config.getImpliedReqs()) ) {
log.info("inheriting sibling parameters from:" + config.getMaterialType());
                config.applyConfig(assets, materials, target, visited);
            }
        }

        for( String name : getInherit() ) {
            // Inherit from the material with no special settings
            //MaterialType mt = new MaterialType(name);
            //MaterialConfig config = materials.getConfig(mt);
            MaterialConfig config = materials.findConfig(name, getMaterialType());
            if( config == null ) {
                throw new RuntimeException("Inherited material not found:" + name + " + " + getMaterialType());
            }
            config.applyConfig(assets, materials, target, visited);
        }

        MaterialDef md = target.getMaterialDef();
        for( Map.Entry<String, Object> e : entrySet() ) {
            MatParam mp = md.getMaterialParam(e.getKey());
            if( mp == null ) {
                throw new RuntimeException("Paramer not found:" + e.getKey());
            }
log.info("  set parameter:" + e.getKey());
            target.setParam(e.getKey(), mp.getVarType(), toValue(assets, mp.getVarType(), e.getValue()));
        }
        RenderState merged = new RenderState();
        merged = target.getAdditionalRenderState().copyMergedTo(renderState, merged);
        target.getAdditionalRenderState().set(merged);
    }

    public Material createMaterial( AssetManager assets, MaterialRegistry materials ) {
        assert assets != null : "Asset manager is null";

        Material result = new Material(assets, j3md);
        result.setName(name);

log.info("createMaterial(" + name + ")");
        applyConfig(assets, materials, result, new HashSet<MaterialConfig>());

        return result;
    }

    public void updateMaterial( Material mat, AssetManager assets, MaterialRegistry materials ) {
log.info("updateMaterial(" + name + ")");
        applyConfig(assets, materials, mat, new HashSet<MaterialConfig>());
    }

    public void setInherit( String... names ) {
        if( names == null ) {
            inherit = null;
            return;
        }
        setInherit(Arrays.asList(names));
    }

    public void setInherit( Collection<String> names ) {
        if( names == null ) {
            inherit = null;
            return;
        }
        if( inherit == null ) {
            inherit = new ArrayList<>();
        }
        inherit.addAll(names);
    }

    public void addInherit( String... names ) {
        addInherit(Arrays.asList(names));
    }

    public void addInherit( Collection<String> names ) {
        if( inherit == null ) {
            inherit = new ArrayList<>();
        }
        inherit.addAll(names);
    }

    public List<String> getInherit() {
        if( inherit != null ) {
            return inherit;
        }
        List<String> empty = Collections.emptyList();
        return empty;
    }

    public void setLayer( Integer layer ) {
        this.layer = layer;
    }

    public Integer getLayer() {
        return layer;
    }

    public MaterialDef getMatDef( AssetManager assets ) {
        if( matDef == null ) {
            matDef = new MaterialDef(assets, j3md);
        }
        return matDef;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("name", name)
            .add("j3md", j3md)
            .add("layer", layer)
            .add("geomReqs", geomReqs)
            .add("properties", properties)
            .add("inherit", inherit)
            .toString();
    }
}


