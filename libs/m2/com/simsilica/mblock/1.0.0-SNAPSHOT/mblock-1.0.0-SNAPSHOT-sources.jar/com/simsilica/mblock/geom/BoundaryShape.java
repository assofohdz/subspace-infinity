/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.io.Serializable;
import java.util.List;

import com.jme3.math.Vector2f;
import com.simsilica.mblock.Direction;

/**
 *  The shape of a block where it intersects the unit cube.  This
 *  is used when matching faces from one cube to the next to eliminate
 *  invisible faces.  BoundaryShapes are always defined from a specific
 *  perspective down a specific axis such that a boundary shape on the 
 *  'left side' of a cube that exactly matches a boundary shape on the 
 *  'right side' of a cube means those two faces match.  
 *
 *  @author    Paul Speed
 */
public interface BoundaryShape extends Serializable {

    /**
     *  Returns true if the specified shape is a face-to-face
     *  match for this shape.  Generally, this is true if the
     *  shapes are the same but there are exceptions such as
     *  "NullShape" which never match.
     */
    public boolean isMatchingFace( BoundaryShape shape );
 
    /**
     *  Returns the surface area of this boundary shape.  This is used
     *  when estimating the light passing properties.
     */   
    public double getArea();
 
    /**
     *  Returns a version of this shape rotated around the y axis.
     *  Note: this means that a dirDelta of 2 will be a 180 degree rotation
     *  which for nonsymmetrical shapes will not match with this shape.
     */   
    public BoundaryShape rotate( Direction dir, int dirDelta );
 
    /**
     *  Returns a version of this shape that is scaled relative to the specified
     *  origin.
     */   
    public BoundaryShape scale( Direction dir, double xOrigin, double yOrigin, double zOrigin, 
                                double x, double y, double z );
 
    /**
     *  Returns a version of this shape that is translated 
     */   
    public BoundaryShape translate( Direction dir, double x, double y, double z );
    
    /**
     *  For debugging purposes, returns a set of points representing the
     *  general 2D border of the shape from the perspective of any axis.
     */
    public List<Vector2f> getBorder(); 
}
