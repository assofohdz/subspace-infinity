/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.Objects;
import java.util.regex.*;

import com.google.common.base.Strings;

/**
 *  A multipart name used for block types.
 *
 *  @author    Paul Speed
 */
public class BlockName implements java.io.Serializable {

    static final long serialVersionUID = 42L;

    public static final Pattern PARSE = Pattern.compile("(.*):(.*?)(?:\\.(\\d+))?");

    private String base;
    private String shape;
    private Integer rotation;

    private BlockName() {
    }

    public BlockName( String base, String shape ) {
        this(base, shape, null);
    }

    public BlockName( String base, String shape, Integer rotation ) {
        this.base = base;
        this.shape = shape;
        this.rotation = rotation;
    }

    public static BlockName parse( String s ) {
        Matcher m = PARSE.matcher(s);
        if( !m.matches() ) {
            return null;
        }
        String base = m.group(1);
        String shape = m.group(2);
        String rot = m.group(3);
        Integer rotation = null;
        if( !Strings.isNullOrEmpty(rot) ) {
            rotation = Integer.parseInt(rot);
        }
        return new BlockName(base, shape, rotation);
    }

    public String getBase() {
        return base;
    }

    public String getShape() {
        return shape;
    }

    public Integer getRotation() {
        return rotation;
    }

    public BlockName rotate( int dirDelta ) {
        if( dirDelta < 0 || dirDelta > 3 ) {
            throw new IllegalArgumentException("dirDelta is out of bounds:" + dirDelta);
        }
        int rot = rotation == null ? 0 : rotation;
        int newRotation = (rot + dirDelta) % 4;
        return new BlockName(base, shape, newRotation);
    }

    public BlockName rotate( int dirDelta, int max ) {
        //if( dirDelta < 0 || dirDelta >= max ) {
        //    throw new IllegalArgumentException("dirDelta is out of bounds [0, " + (max-1) + "]:" + dirDelta);
        //}
        int rot = rotation == null ? 0 : rotation;
        int newRotation = (rot + dirDelta) % max;
        if( newRotation < 0 ) {
            newRotation += max;
        }
        return new BlockName(base, shape, newRotation);
    }

    public int hashCode() {
        return Objects.hash(base, shape, rotation);
    }

    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        BlockName other = (BlockName)o;
        if( !Objects.equals(base, other.base) ) {
            return false;
        }
        if( !Objects.equals(shape, other.shape) ) {
            return false;
        }
        if( !Objects.equals(rotation, other.rotation) ) {
            return false;
        }
        return true;
    }

    public String toString() {
        return base + ":" + shape + (rotation != null ? "." + rotation : "");
    }
}
