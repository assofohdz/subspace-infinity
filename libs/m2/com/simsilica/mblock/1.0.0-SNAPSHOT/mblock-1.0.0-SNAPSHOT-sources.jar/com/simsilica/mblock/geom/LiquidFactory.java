/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.Objects;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *  FluidFactory implementation that renders flowing fluids.
 *
 *  @author    Paul Speed
 */
public class LiquidFactory implements FluidFactory {
    static final long serialVersionUID = 42L;

    static Logger log = LoggerFactory.getLogger(LiquidFactory.class);

    public static boolean DEBUG = false;

    private MaterialType topType;
    private MaterialType sideType;

    public LiquidFactory( MaterialType materialType ) {
        this(materialType, materialType);
    }

    public LiquidFactory( MaterialType topType, MaterialType sideType ) {
        this.topType = topType;
        this.sideType = sideType;
    }

    public MaterialType getTopMaterialType() {
        return topType;
    }

    public MaterialType getSideMaterialType() {
        return sideType;
    }

    private static float toCornerY( int level ) {
        // 1 is the minimum and 8 is the maximum... but we generally
        // want 1 to be drawn as 0.  So we'll stretch things a little oddly.
        return (level - 1) / 7.0f;
    }

    @Override
    public int addGeometryToBuffer( GeomPartBuffer buffer, int i, int j, int k,
                                    int xWorld, int yWorld, int zWorld,
                                    int sideMask, int level,
                                    CellData cells,
                                    CellData fluid,
                                    FluidType type ) {
        int count = 0;

        Vec3d min = new Vec3d();
        Vec3d max = new Vec3d(1, level/8.0, 1);

        // Could pass in slope instead to avoid creating a new
        // instance all the time
        int value = fluid.getCell(i, j, k);
        FluidSlope slope = new FluidSlope().setBits(FluidUtils.getSlopeBits(value));
        if( log.isTraceEnabled() ) {
            log.trace("part slope:" + slope);
        }

        // Figure out what to do with the top first and the rest will
        // follow.

        // Even though the corners are going to by 1 and up, we
        // may actually render them at 0 depending on certain factors.
        // We'll precalculate the corners so we can adjust them.
        float nw = toCornerY(slope.nw);
        float ne = toCornerY(slope.ne);
        float se = toCornerY(slope.se);
        float sw = toCornerY(slope.sw);

        if( DEBUG ) {
            nw = toCornerY(level);
            ne = nw;
            se = nw;
            sw = nw;
        }

        if( DirectionMasks.hasUp(sideMask) || level < 8 ) {
            // Then we will render a top which may be two triangles
            // or more triangles depending on the center and corner
            // heights.

            float center = toCornerY(level);
            if( center == 0 ) {
                // For the center, we'll want a little elevation
                center += 1/14f;
            }

            // We need to characterize the type of geometry we need.
            // Cases:
            // 1) regular: two triangles in standard orientation.
            // 2) flipped: two triangles with the long side running
            //             on the other diagonal.
            // 3) star: 4 triangles with a common point in the center of the
            //             quad.
            //
            // In general, we will want to pick the two triangle orientation
            // where the joined corners' average is bigger than the other
            // orientation.  If that biggest average is smaller than the
            // center then we'll need to switch to the 4 quad version.
            //
            // The default Up quad is:
            //      3-2
            //      |/|
            //      0-1
            float avg1 = (ne + sw) * 0.5f;
            float avg2 = (nw + se) * 0.5f;

            GeomPart part;
            if( center > avg1 && center > avg2 ) {
                // Four triangle version
                //
                //   3---2
                //   |\ /|
                //   | 4 |
                //   |/ \|
                //   0---1
                //
                double xMid = (min.x + max.x) * 0.5;
                double zMid = (min.z + max.z) * 0.5;
                part = new GeomPart(topType, Direction.Up.ordinal(), false);
                part.setCoords(new float[] {
                    (float)min.x, (float)sw, (float)max.z,
                    (float)max.x, (float)se, (float)max.z,
                    (float)max.x, (float)ne, (float)min.z,
                    (float)min.x, (float)nw, (float)min.z,
                    (float)xMid, (float)center, (float)zMid
                });
                part.setIndexes(new short[] {
                    0, 1, 4,
                    1, 2, 4,
                    2, 3, 4,
                    3, 0, 4
                });
                part.setTexCoords(new float[] {
                    0, 0,
                    1, 0,
                    1, 1,
                    0, 1,
                    0.5f, 0.5f
                });
            } else if( avg1 < avg2 ) {
                // flipped diagonal
                // For now we will reuse the createQuad() method for convenience
                // at least until we start to mess with normals.
                part = GeomPart.createQuad(min, max, topType, Direction.Up);
                float[] coords = part.getCoords();
                coords[0 * 3 + 1] = sw;
                coords[1 * 3 + 1] = se;
                coords[2 * 3 + 1] = ne;
                coords[3 * 3 + 1] = nw;
                part.setIndexes(new short[] {
                    0, 1, 3,
                    1, 2, 3
                });
            } else {
                // regular diagonal
                // For now we will reuse the createQuad() method for convenience
                // at least until we start to mess with normals.
                part = GeomPart.createQuad(min, max, topType, Direction.Up);
                float[] coords = part.getCoords();
                coords[0 * 3 + 1] = sw;
                coords[1 * 3 + 1] = se;
                coords[2 * 3 + 1] = ne;
                coords[3 * 3 + 1] = nw;
            }

            if( !topType.needsIndexedNormals() ) {
                if( topType.needsNormals() ) {
                    part.generateNormals(Direction.Up);
                }
                if( topType.needsTangents() ) {
                    part.generateTangents(Direction.Up);
                }
            }

            buffer.addPart(i, j, k, part);
            count++;

            // If we rendered a top face then there is a chance that we do
            // not need to render some sides
            if( nw <= 0 && ne <= 0 ) {
                // Clear north
                sideMask = sideMask & ~DirectionMasks.NORTH_MASK;
            }
            if( ne <= 0 && se <= 0 ) {
                // Clear East
                sideMask = sideMask & ~DirectionMasks.EAST_MASK;
            }
            if( se <= 0 && sw <= 0 ) {
                // Clear South
                sideMask = sideMask & ~DirectionMasks.SOUTH_MASK;
            }
            if( nw <= 0 && sw <= 0 ) {
                // Clear West
                sideMask = sideMask & ~DirectionMasks.WEST_MASK;
            }
        }

        // For now just treat it like a cube of the material type
        for( Direction dir : Direction.values() ) {
            if( dir == Direction.Up ) {
                // Up was already rendered
                continue;
            }
            if( (sideMask & dir.getBitMask()) == 0 ) {
                continue;
            }
            MaterialType materialType = sideType;
            GeomPart part = GeomPart.createQuad(min, max, materialType, dir);

            // It's probably worth noting that without transparency
            // being present, the sides for the cardinal directions will
            // pretty much never be visible because if the border an open
            // cell then the height is forced to 0.

            // At least for now, we'll just edit the part if needed
            int corner1, corner2;
            float[] coords = part.getCoords();
            float[] uvs = part.getTexCoords();
            switch( dir ) {
                case North:
                    coords[2 * 3 + 1] = nw;
                    coords[3 * 3 + 1] = ne;
                    break;
                case South:
                    coords[2 * 3 + 1] = se;
                    coords[3 * 3 + 1] = sw;
                    break;
                case East:
                    coords[2 * 3 + 1] = ne;
                    coords[3 * 3 + 1] = se;
                    break;
                case West:
                    coords[2 * 3 + 1] = sw;
                    coords[3 * 3 + 1] = nw;
                    break;
                // case Up: never comes up because if the if at the top of the loop
                case Down:
                    // requires no change but implies a particle effect
                    break;
            }

            buffer.addPart(i, j, k, part);
            count++;
        }

        return count;
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        LiquidFactory other = (LiquidFactory)o;
        if( !Objects.equals(topType, other.topType) ) {
            return false;
        }
        if( !Objects.equals(sideType, other.sideType) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(topType, sideType);
    }

}
