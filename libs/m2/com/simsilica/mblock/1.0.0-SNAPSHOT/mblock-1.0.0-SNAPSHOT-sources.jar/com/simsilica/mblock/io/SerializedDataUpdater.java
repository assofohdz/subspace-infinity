/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;


/**
 *  Can manage a source and target file for upgrade when the objects
 *  are serializable.
 *
 *  @author    Paul Speed
 */
public class SerializedDataUpdater<T extends UpdateableData<T>> extends DataUpdater<T> {
    static Logger log = LoggerFactory.getLogger(SerializedDataUpdater.class);
 
//    private File target;
//    private File savedSource;
    
    public SerializedDataUpdater( File target ) {
        super(target);
//        this.target = target;
//        this.savedSource = new File(target.getParentFile(), "last-global-" + target.getName()); 
    }
    
//    public boolean update( T global ) throws IOException {
//    
//        T local = read(target);
//        boolean changed = false;
//        if( local == null ) {
//            log.info("Initializing " + target + " with source data.");
//            local = global;
//            changed = true;
//        } else {
//            log.info("Checking for " + target + " upgrades.");
//            
//            T lastGlobal = read(savedSource);
//            if( lastGlobal != null ) {
//                log.info("Comparing last source data " + savedSource + " snapshot...");
//                changed = lastGlobal.update(global);
//            } else {
//                // We don't have a snapshot so assume we should try to 
//                // upgrade.
//                changed = true;
//            }
//            if( changed ) {
//                log.info("Upgrading " + target + " to source data...");
//                local.update(global);
//            }
//        }
//        
//        if( changed ) {
//            log.info("Storing updated " + target);
//            write(local, target);
//            
//            log.info("Storing source snapshot " + savedSource);
//            write(global, savedSource);           
//        }
//        
//        return changed;
//    }
//    
    /**
     *  Default implementation reads the type directly from an ObjectInputStream
     *  and closes the stream.
     */
    @SuppressWarnings("unchecked")
    @Override
    public T read( InputStream rawIn ) throws IOException {
        try( ObjectInputStream in = new ObjectInputStream(rawIn) ) {            
            return (T)in.readObject();
        } catch( ClassNotFoundException e ) {
            throw new IOException("Error resolving types", e);
        }
    }
    
//    public T read( String resource ) throws IOException {
//        java.net.URL u = BlockTypeData.class.getResource(resource);
//        if( u == null ) {
//            // Could try the context class loader
//            return null;
//        }
//        return read(u.openStream());
//    }
//
//    public T read( File f ) throws IOException {
//        return read(new FileInputStream(f));
//    }
// 
//    public void write( T data, File f ) throws IOException {
//        write(data, new FileOutputStream(f));
//    }
    
    /**
     *  Default implementation writes the type directly from an ObjectOutputStream
     *  and closes the stream.
     */
    @Override
    public void write( T data, OutputStream rawOut ) throws IOException {
        try( ObjectOutputStream out = new ObjectOutputStream(rawOut) ) {
            out.writeObject(data);
        }   
    }    
}


