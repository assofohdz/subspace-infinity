/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;


/**
 *
 *
 *  @author    Paul Speed
 */
public class DirectionMasks {

    public static final int NORTH_MASK = 0x1;
    public static final int SOUTH_MASK = 0x2;
    public static final int EAST_MASK = 0x4;
    public static final int WEST_MASK = 0x8;
    public static final int UP_MASK = 0x10;
    public static final int DOWN_MASK = 0x20;
    
    public static final int ALL_MASKS = NORTH_MASK | SOUTH_MASK
                                        | EAST_MASK | WEST_MASK
                                        | UP_MASK | DOWN_MASK;

    public static final int[] MASKS = new int[Direction.values().length];
    static {
        MASKS[Direction.North.ordinal()] = NORTH_MASK;
        MASKS[Direction.South.ordinal()] = SOUTH_MASK;
        MASKS[Direction.East.ordinal()] = EAST_MASK;
        MASKS[Direction.West.ordinal()] = WEST_MASK;
        MASKS[Direction.Up.ordinal()] = UP_MASK;
        MASKS[Direction.Down.ordinal()] = DOWN_MASK;
    } 
    
    public static boolean hasMask( int test, int mask ) {
        return (test & mask) != 0;
    }
    
    public static final boolean hasNorth( int mask ) {
        return (mask & NORTH_MASK) != 0;
    }
    
    public static final boolean hasSouth( int mask ) {
        return (mask & SOUTH_MASK) != 0;
    }
    
    public static final boolean hasEast( int mask ) {
        return (mask & EAST_MASK) != 0;
    }
    
    public static final boolean hasWest( int mask ) {
        return (mask & WEST_MASK) != 0;
    }
    
    public static final boolean hasUp( int mask ) {
        return (mask & UP_MASK) != 0;       
    }
    
    public static final boolean hasDown( int mask ) {
        return (mask & DOWN_MASK) != 0;
    }
 
    public static final boolean hasNorthOrSouth( int mask ) {
        return hasNorth(mask) || hasSouth(mask);
    }

    public static final boolean hasEastOrWest( int mask ) {
        return hasEast(mask) || hasWest(mask);
    }
    
    public static final boolean hasUpOrDown( int mask ) {
        return hasUp(mask) || hasDown(mask);
    }
 
    public static final String toString( int mask ) {
        if( mask == 0 ) {
            return "None";
        }
        StringBuilder sb = new StringBuilder();
        if( hasNorth(mask) ) {
            sb.append("N");
        }
        if( hasSouth(mask) ) {
            sb.append("S");
        }
        if( hasEast(mask) ) {
            sb.append("E");
        }
        if( hasWest(mask) ) {
            sb.append("W");
        }
        if( hasUp(mask) ) {
            sb.append("U");
        }
        if( hasDown(mask) ) {
            sb.append("D");
        }
        return sb.toString();
    }
}
