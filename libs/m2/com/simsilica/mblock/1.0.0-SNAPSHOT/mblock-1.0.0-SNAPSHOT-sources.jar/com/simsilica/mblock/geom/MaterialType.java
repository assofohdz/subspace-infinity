/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  An abstract representation of a type of mesh material and its
 *  constraints.  A material type is not necessarily an immutable object so it's
 *  use as a key should be limited to cases where the caller knows
 *  it will no longer change.  For example, sets of part templates may
 *  define materials in general terms until they are remapped to global
 *  indexes.
 *
 *  @author    Paul Speed
 */
public class MaterialType implements java.io.Serializable {

    static Logger log = LoggerFactory.getLogger(MaterialType.class);

    static final long serialVersionUID = 42L;

    // For 'internalizing' the MaterialTypes to avoid duplicate instances
    private static Map<String, MaterialType> intern = new HashMap<>();

    private String name;
    private Integer layer;
    private EnumSet<GeomReq> geomReqs = EnumSet.noneOf(GeomReq.class);
    private transient EnumSet<GeomReq> impliedReqs = null;
    private transient String id;

    public MaterialType( String name, boolean needsIndexedNormals,
                         boolean needsNormals, boolean needsTangents ) {
        this.name = name;
        if( needsIndexedNormals ) {
            geomReqs.add(GeomReq.IndexedNormals);
        } else {
            if( needsNormals ) {
                geomReqs.add(GeomReq.Normals);
            }
            if( needsTangents ) {
                geomReqs.add(GeomReq.Tangents);
            }
        }
        cacheReqs();
    }

    public MaterialType( String name, GeomReq... reqs ) {
        this(name, null, Arrays.asList(reqs));
    }

    public MaterialType( String name, Collection<GeomReq> reqs ) {
        this(name, null, reqs);
    }

    public MaterialType( String name, Integer layer, Collection<GeomReq> reqs ) {
        this.name = name;
        this.layer = layer;
        this.geomReqs.addAll(reqs);
        cacheReqs();
    }

    /**
     *  Returns a shared instance of the data represented by this MaterialType.
     */
    public synchronized MaterialType internalize() {
        MaterialType result = intern.get(getId());
        if( result == null ) {
            intern.put(getId(), this);
            result = this;
        }
        return result;
    }

    public String getId() {
        if( id == null ) {
            // Catches the case where we were loaded from JSON and
            // haven't cached the reqs yet.
            cacheReqs();
            id = toString();
        }
        return id;
    }

    public EnumSet<GeomReq> getImpliedReqs() {
        if( impliedReqs == null ) {
            impliedReqs = GeomReq.expandImplied(geomReqs);
        }
        return impliedReqs;
    }

    protected void cacheReqs() {

        getImpliedReqs(); // make sure it's cached

        // Make sure that any implies reqs are not specifically
        // mentioned in the set.  It's redundant and since we use
        // the set for part of the unique ID, it can lead to two
        // MaterialTypes registering as different even if they are
        // effectively the same.  So we'll make them canonical.
        // We know that IndexedNormals is the biggest one so
        // we'll flatten that one first and do the others automatically
        if( geomReqs.contains(GeomReq.IndexedNormals) ) {
            for( GeomReq req : GeomReq.IndexedNormals.implies() ) {
                geomReqs.remove(req);
            }
        }
        for( GeomReq req : geomReqs ) {
            for( GeomReq imp : req.implies() ) {
                geomReqs.remove(imp);
            }
        }
    }

    public Set<GeomReq> getGeomReqs() {
        return Collections.unmodifiableSet(geomReqs);
    }

    public boolean requires( GeomReq req ) {
        return getImpliedReqs().contains(req);
    }

    /**
     *  If assertions are enabled this will assert that the part is
     *  valid for this material, throwing the appropriate assertion message
     *  otherwise.
     */
    public boolean assertValid( GeomPart part ) {

        // needs to be fast, called only be DefaultPartBuffer during
        // geometry construction as a double-check.
        if( geomReqs.contains(GeomReq.IndexedNormals) ) {
            assert part.hasIndexedNormals()
                : "Missing indexed normals, mt:" + this + " part:" + part;
        }

        if( geomReqs.contains(GeomReq.Tangents) ) {
            assert part.getNormals() != null
                : "Missing normals, mt:" + this + " part:" + part;
            assert part.getTangents() != null
                : "Missing tangents, mt:" + this + " part:" + part;
        } else if( geomReqs.contains(GeomReq.Normals) ) {
            assert part.getNormals() != null
                : "Missing normals, mt:" + this + " part:" + part;
        }

        // We could do more checks if we decide it's needed but those
        // are the only ones we traditionally did.  When lores values
        // are implemented then we will probably want to check for that, too.
        // Really it depends on what kind of errors we see 'in the wild'.

        return true;
    }

    public EnumSet<GeomReq> getMissingReqs( GeomPart part ) {
        EnumSet<GeomReq> caps = part.calculateGeomCaps();
        EnumSet<GeomReq> result = getImpliedReqs().clone();
        result.removeAll(caps);
        return result;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setLayer( Integer layer ) {
        this.layer = layer;
    }

    public Integer getLayer() {
        return layer;
    }

    public boolean needsIndexedNormals() {
        return requires(GeomReq.IndexedNormals);
    }

    public boolean needsNormals() {
        return requires(GeomReq.Normals);
    }

    public boolean needsTangents() {
        return requires(GeomReq.Tangents);
    }

    public int hashCode() {
        return getId().hashCode();
    }

    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        MaterialType other = (MaterialType)o;
        return Objects.equals(other.getId(), getId());
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("name", name)
            .add("layer", layer)
            .add("geomReqs", geomReqs)
            .toString();
    }
}
