/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.io.ObjectStreamException;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.jme3.math.FastMath;
import com.jme3.math.Vector2f;

import com.simsilica.mathd.*;

import com.simsilica.mblock.Direction;

/**
 *  A set of factory methods that can be used to create consistent
 *  BoundaryShape objects.
 *
 *  <p>For consistency of facing, shapes should always be defined
 *  in (x,y), (x,z), or (y,z) space... ie: never define an up facing
 *  triangle in y,x space.<p>
 *
 *  @author    Paul Speed
 */
public class BoundaryShapes {

    public static final BoundaryShape NULL_SHAPE = new NullShape();

    /**
     *  The lock used to gate access to the shape index for
     *  consistent behavior.
     */
    private static final ReentrantReadWriteLock indexLock = new ReentrantReadWriteLock();

    /**
     *  Maps shapes to unique IDs.
     */
    private static final Map<BoundaryShape,Integer> shapeIndex = new HashMap<>();

    /**
     *  The list of all created shapes where the index is the unique ID
     *  for the shape.  This is effectively the reverse lookup of the shape index
     *  above.
     */
    private static final List<BoundaryShape> shapes = new ArrayList<>();

    // Have to do these after the maps and list are initialized
    public static final BoundaryShape UNIT_SQUARE = getRect(0, 0, 1, 1);

    private BoundaryShapes() {
    }

    /**
     *  Resolves a random shape instance to its globally unique shared instance.
     */
    public static BoundaryShape resolve( BoundaryShape shape ) {
        // Acquire the read lock so data doesn't change underneath us
        indexLock.readLock().lock();
        try {
            Integer id = shapeIndex.get(shape);
            if( id != null ) {
                // Shape already exists, we're done... just return the shared version
                return shapes.get(id);
            }

            // This is a new shape... need to get the write lock to update
            // the index.
            indexLock.readLock().unlock();
            indexLock.writeLock().lock();
            try {
                // Now we can modify the list but because of the lock switch we
                // should check one more time in case some other thread slipped in
                // and added the shape
                id = shapeIndex.get(shape);
                if( id != null ) {
                    // Shape already exists, we're done... just return the shared version
                    return shapes.get(id);
                }

                // Create it
                id = shapes.size();
                shapes.add(shape);
                shapeIndex.put(shape, id);

                // Downgrade by acquiring read lock before releasing write lock
                indexLock.readLock().lock();

                // Return the original shape which is now the authoritative instance
                return shape;
            } finally {
                indexLock.writeLock().unlock();
            }

        } finally {
            indexLock.readLock().unlock();
        }
    }

    public static BoundaryShape getRect( double xMin, double yMin, double xMax, double yMax ) {
        if( xMin < 0 || yMin < 0 ) {
            throw new IllegalArgumentException("range out of bounds, min:" + xMin + ", " + yMin);
        }
        if( xMax > 1 || yMax > 1 ) {
            throw new IllegalArgumentException("range out of bounds, max:" + xMax + ", " + yMax);
        }
        return resolve(new Rect(xMin, yMin, xMax, yMax));
    }

    public static BoundaryShape getTriangle( double xMin, double yMin, double xMax, double yMax,
                                             double xNormal, double yNormal ) {
        return resolve(new Triangle(xMin, yMin, xMax, yMax, xNormal, yNormal));
    }

    public static BoundaryShape getCircle( double xCenter, double yCenter, double radius ) {
        return resolve(new Circle(xCenter, yCenter, radius));
    }

    /**
     *  Returns the boundary shape for the given direction as the face of a cube.
     *  If the particular side is not incident with the unit cube then this method
     *  returns null.
     */
    public static final BoundaryShape getBoxSide( Vec3d min, Vec3d max, Direction dir ) {

        // Check for boundaries... just brute force it.
        switch( dir ) {
            case North:
                if( min.z != 0 ) {
                    return null;
                }
                break;
            case South:
                if( max.z != 1 ) {
                    return null;
                }
                break;
            case East:
                if( max.x != 1 ) {
                    return null;
                }
                break;
            case West:
                if( min.x != 0 ) {
                    return null;
                }
                break;
            case Up:
                if( max.y != 1 ) {
                    return null;
                }
                break;
            case Down:
                if( min.y != 0 ) {
                    return null;
                }
                break;
        }

        Vector2f low = BoundaryShapes.unprojectDir(min, dir);
        Vector2f high = BoundaryShapes.unprojectDir(max, dir);
        return BoundaryShapes.getRect(low.x, low.y, high.x, high.y);
    }

    /**
     *  Truncates extra decimal places to help shapes resolve to their shared
     *  instances better.
     */
    protected static float quantize( double d ) {
        long i = Math.round(d * 10000);
        float result = i / 10000f;
        return result;
    }

    /**
     *  Projects the specified 2D location into 3D shape space
     *  based on the supplied direction.
     */
    public static Vec3d projectPos( Vector2f v, Direction dir ) {

        Vec3d result = new Vec3d();
        switch( dir ) {
            case North: // x,y
                result.x = v.x - 0.5f;
                result.y = v.y - 0.5f;
                result.z = -0.5f;
                break;
            case South: // x,y
                result.x = v.x - 0.5f;
                result.y = v.y - 0.5f;
                result.z = 0.5f;
                break;
            case East: // z,y
                result.x = 0.5f;
                result.y = v.y - 0.5f;
                result.z = v.x - 0.5f;
                break;
            case West: // z,y
                result.x = -0.5f;
                result.y = v.y - 0.5f;
                result.z = v.x - 0.5f;
                break;
            case Up:  // x,z
                result.x = v.x - 0.5f;
                result.y = 0.5f;
                result.z = v.y - 0.5f;
                break;
            case Down: // x,z
                result.x = v.x - 0.5f;
                result.y = -0.5f;
                result.z = v.y - 0.5f;
                break;
            default:
                throw new IllegalArgumentException("Unknown direction:" + dir);
        }
        return result;
    }

    public static Vector2f unprojectPos( Vec3d v, Direction dir ) {

        Vector2f result = new Vector2f();
        switch( dir ) {
            case North: // x,y
                result.x = quantize(0.5f + v.x);
                result.y = quantize(0.5f + v.y);
                break;
            case South: // x,y
                result.x = quantize(0.5f + v.x);
                result.y = quantize(0.5f + v.y);
                break;
            case East: // z, y
                result.x = quantize(0.5f + v.z);
                result.y = quantize(0.5f + v.y);
                break;
            case West: // z, y
                result.x = quantize(0.5f + v.z);
                result.y = quantize(0.5f + v.y);
                break;
            case Up:  // x,z
                result.x = quantize(0.5f + v.x);
                result.y = quantize(0.5f + v.z);
                break;
            case Down: // x,z
                result.x = quantize(0.5f + v.x);
                result.y = quantize(0.5f + v.z);
                break;
            default:
                throw new IllegalArgumentException("Unknown direction:" + dir);
        }
        return result;
    }

    /**
     *  Projects a direction vector into 3D shape space based on the supplied
     *  direction.  These 2D direction vectors are often used for things
     *  like triangle hypotenuse normals.  Unlike projectPos, we just
     *  project it untranslated.
     */
    public static Vec3d projectDir( Vector2f v, Direction dir ) {

        Vec3d result = new Vec3d();
        switch( dir ) {
            case North: // x,y
                result.x = v.x;
                result.y = v.y;
                break;
            case South: // x,y
                result.x = v.x;
                result.y = v.y;
                break;
            case East: // z, y
                result.z = v.x;
                result.y = v.y;
                break;
            case West: // z, y
                result.z = v.x;
                result.y = v.y;
                break;
            case Up:  // x,z
                result.x = v.x;
                result.z = v.y;
                break;
            case Down: // x,z
                result.x = v.x;
                result.z = v.y;
                break;
            default:
                throw new IllegalArgumentException("Unknown direction:" + dir);
        }
        return result;
    }

    public static Vector2f unprojectDir( Vec3d v, Direction dir ) {

        Vector2f result = new Vector2f();
        switch( dir ) {
            case North: // x,y
                result.x = quantize(v.x);
                result.y = quantize(v.y);
                break;
            case South: // x,y
                result.x = quantize(v.x);
                result.y = quantize(v.y);
                break;
            case East: // z, y
                result.x = quantize(v.z);
                result.y = quantize(v.y);
                break;
            case West: // z, y
                result.x = quantize(v.z);
                result.y = quantize(v.y);
                break;
            case Up:  // x,z
                result.x = quantize(v.x);
                result.y = quantize(v.z);
                break;
            case Down:  // x,z
                result.x = quantize(v.x);
                result.y = quantize(v.z);
                break;
            default:
                throw new IllegalArgumentException( "Unknown direction:" + dir );
            }

        return result;
    }


    private static abstract class AbstractShape implements BoundaryShape {
        static final long serialVersionUID = 42L;

        protected Object readResolve() throws ObjectStreamException {
            return resolve(this);
        }
    }

    /**
     *  NullShape is a shape that represents no bounding shape.
     *  It will never face another shape... and there is only
     *  ever one of these instances.
     */
    public static class NullShape extends AbstractShape {

        static final long serialVersionUID = 42L;

        @Override
        public boolean isMatchingFace( BoundaryShape shape ) {
            // 2022-03-27 - Today I would make the argument that a NullShape should match a NullShape
            // but nothing else.  This method is based on 10+ year old code at this point and I'm
            // hesitant to change it in case something else needs it.  So I'm logging evidence here
            // as I find things.
            // In today's case, I'm dealing with block type reflections and I wanted a null shape
            // to match a null shape to make logic easier.s
            // Coming at this again a few days later, probably it's so that we still turn the
            // side masks on for types that border null shapes... but even that's not clear that
            // its desirable.  It might be nice to use the masks to see if a type adjoins another
            // block of the same type/group... even if it doesn't have sides in that direction.
            return false;
        }

        @Override
        public BoundaryShape translate( Direction dir, double x, double y, double z ) {
            return this;
        }

        @Override
        public BoundaryShape rotate( Direction dir, int dirDelta ) {
            return this;
        }

        @Override
        public BoundaryShape scale( Direction dir, double xOrigin, double yOrigin, double zOrigin, double x, double y, double z ) {
            return this;
        }

        @Override
        public double getArea() {
            return 0;
        }

        @Override
        public List<Vector2f> getBorder() {
            return Collections.emptyList();
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            return true;
        }

        @Override
        public int hashCode() {
            return Objects.hash(getClass());
        }

        @Override
        public String toString() {
            return "NULL_SHAPE";
        }
    }

    public static class Rect extends AbstractShape {
        static final long serialVersionUID = 42L;

        private Vector2f min;
        private Vector2f max;
        private double area;

        private Rect() {
        }

        public Rect( double xMin, double yMin, double xMax, double yMax ) {
            this.min = new Vector2f(quantize(xMin), quantize(yMin));
            this.max = new Vector2f(quantize(xMax), quantize(yMax));
            this.area = (xMax - xMin) * (yMax - yMin);
        }

        @Override
        public List<Vector2f> getBorder() {
            List<Vector2f> results = new ArrayList<>();
            results.add(min);
            results.add(new Vector2f(max.x, min.y));
            results.add(max);
            results.add(new Vector2f(min.x, max.y));
            return results;
        }

        public double getArea() {
            return area;
        }

        @Override
        public BoundaryShape translate( Direction dir, double x, double y, double z ) {

            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);

            pMin.x += x;
            pMin.y += y;
            pMin.z += z;

            pMax.x += x;
            pMax.y += y;
            pMax.z += z;

            Vector2f v1 = unprojectPos(pMin, dir);
            Vector2f v2 = unprojectPos(pMax, dir);

            return getRect(v1.x, v1.y, v2.x, v2.y);
        }

        @Override
        public BoundaryShape scale( Direction dir, double xOrigin, double yOrigin, double zOrigin, double x, double y, double z ) {
            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);

            // Projected positions are in 0,0-center space... so we need
            // to add 0.5 to them to put them back in "origin space"

            pMin.x = (xOrigin + (pMin.x + 0.5 - xOrigin) * x) - 0.5;
            pMin.y = (yOrigin + (pMin.y + 0.5  - yOrigin) * y) - 0.5;
            pMin.z = (zOrigin + (pMin.z + 0.5  - zOrigin) * z) - 0.5;

            pMax.x = (xOrigin + (pMax.x + 0.5  - xOrigin) * x) - 0.5;
            pMax.y = (yOrigin + (pMax.y + 0.5  - yOrigin) * y) - 0.5;
            pMax.z = (zOrigin + (pMax.z + 0.5  - zOrigin) * z) - 0.5;

            Vector2f v1 = unprojectPos(pMin, dir);
            Vector2f v2 = unprojectPos(pMax, dir);

            // Should be ok as long as none of the scales are negative
            return getRect(v1.x, v1.y, v2.x, v2.y);
        }

        @Override
        public BoundaryShape rotate( Direction dir, int dirDelta ) {
            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);

            //Quatd rot = new Quatd().fromAngles(0, FastMath.DEG_TO_RAD * dirDelta * 90, 0);
            // ...except that rotates counter-clockwise
            Quatd rot = Direction.getRotation(dirDelta);

            pMin = rot.mult(pMin);
            pMax = rot.mult(pMax);

            Direction newDir = dir.rotate(dirDelta);

            Vector2f v1 = unprojectPos(pMin, newDir);
            Vector2f v2 = unprojectPos(pMax, newDir);

            return getRect(Math.min(v1.x, v2.x), Math.min(v1.y, v2.y),
                           Math.max(v1.x, v2.x), Math.max(v1.y, v2.y));
        }

        @Override
        public boolean isMatchingFace( BoundaryShape shape ) {
            return shape == this;
        }

        @Override
        public int hashCode() {
            return Objects.hash(getClass(), min, max);
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }

            Rect other = (Rect)o;

            if( !Objects.equals(other.min, min) ) {
                return false;
            }
            if( !Objects.equals(other.max, max) ) {
                return false;
            }
            return true;
        }

        @Override
        public String toString() {
            return "Rect[" + min + ", " + max + "]";
        }
    }

    public static class Triangle extends AbstractShape {
        static final long serialVersionUID = 42L;

        private Vector2f min;
        private Vector2f max;
        private Vector2f normal;
        private double area;

        private Triangle() {
        }

        public Triangle( double xMin, double yMin, double xMax, double yMax, double xNormal, double yNormal ) {
            this.min = new Vector2f(quantize(xMin), quantize(yMin));
            this.max = new Vector2f(quantize(xMax), quantize(yMax));
            this.normal = new Vector2f(quantize(xNormal), quantize(yNormal));
            this.area = ((xMax - xMin) * (yMax - yMin)) * 0.5;
        }

        public Vector2f getMin() {
            return min;
        }
        
        public Vector2f getMax() {
            return max;
        }

        public Vector2f getNormal() {
            return normal;
        }

        @Override
        public List<Vector2f> getBorder() {
            List<Vector2f> results = new ArrayList<>();

            // Check the normal direction to eliminate the corner
            // it's pointing to
            if( !(normal.x < 0 && normal.y < 0) ) {
                results.add(min);
            }
            if( !(normal.x > 0 && normal.y < 0) ) {
                results.add(new Vector2f(max.x, min.y));
            }
            if( !(normal.x > 0 && normal.y > 0) ) {
                results.add(max);
            }
            if( !(normal.x < 0 && normal.y > 0) ) {
                results.add(new Vector2f(min.x, max.y));
            }

            return results;
        }

        @Override
        public BoundaryShape translate( Direction dir, double x, double y, double z ) {

            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);
            Vec3d pNorm = projectDir(normal, dir);

            pMin.x += x;
            pMin.y += y;
            pMin.z += z;

            pMax.x += x;
            pMax.y += y;
            pMax.z += z;

            Vector2f v1 = unprojectPos(pMin, dir);
            Vector2f v2 = unprojectPos(pMax, dir);
            Vector2f n = unprojectPos(pNorm, dir);

            return getTriangle(v1.x, v1.y, v2.x, v2.y, n.x, n.y);
        }

        @Override
        public BoundaryShape scale( Direction dir, double xOrigin, double yOrigin, double zOrigin, double x, double y, double z ) {
            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);

            pMin.x = (xOrigin + (pMin.x + 0.5 - xOrigin) * x) - 0.5;
            pMin.y = (yOrigin + (pMin.y + 0.5  - yOrigin) * y) - 0.5;
            pMin.z = (zOrigin + (pMin.z + 0.5  - zOrigin) * z) - 0.5;

            pMax.x = (xOrigin + (pMax.x + 0.5  - xOrigin) * x) - 0.5;
            pMax.y = (yOrigin + (pMax.y + 0.5  - yOrigin) * y) - 0.5;
            pMax.z = (zOrigin + (pMax.z + 0.5  - zOrigin) * z) - 0.5;

            // Normal is different... and actually, just scaling the normal
            // isn't proper.  We need to do something fancier than that.

            // Figure out what the two scale values in our plane are
            Vector2f pScale = unprojectDir(new Vec3d(x, y, z), dir);

            // Now, the normal is orthogonal -y, x from a normal surface
            // so we must apply scaling differently or it will come out
            // wonky.  Basically, we just swap the x,y scaling
            Vector2f n = new Vector2f(normal.x * (float)pScale.y,
                                      normal.y * (float)pScale.x).normalizeLocal();

            Vector2f v1 = unprojectPos(pMin, dir);
            Vector2f v2 = unprojectPos(pMax, dir);

            // Should be ok as long as none of the scales are negative
            BoundaryShape result = getTriangle(v1.x, v1.y, v2.x, v2.y, n.x, n.y);

            return result;
        }

        @Override
        public BoundaryShape rotate( Direction dir, int dirDelta ) {
            Vec3d pMin = projectPos(min, dir);
            Vec3d pMax = projectPos(max, dir);
            Vec3d pNorm = projectDir(normal, dir);

            // Shapes are projected in space where z is up... so it's
            // around the z-axis that we need to rotate.
            //Quatd rot = new Quatd().fromAngles(0, FastMath.DEG_TO_RAD * dirDelta * 90, 0);
            // That comment is old anyway, as now everything is y-up... and that rotates
            // counterclockwise.
            Quatd rot = Direction.getRotation(dirDelta);

            pMin = rot.mult(pMin);
            pMax = rot.mult(pMax);
            pNorm = rot.mult(pNorm);

            Direction newDir = dir.rotate(dirDelta);

            Vector2f v1 = unprojectPos(pMin, newDir);
            Vector2f v2 = unprojectPos(pMax, newDir);
            Vector2f n = unprojectDir(pNorm, newDir);

            BoundaryShape result = getTriangle(Math.min(v1.x, v2.x), Math.min(v1.y, v2.y),
                                               Math.max(v1.x, v2.x), Math.max(v1.y, v2.y),
                                               n.x, n.y );
            return result;
        }

        @Override
        public boolean isMatchingFace( BoundaryShape shape ) {
            return shape == this;
        }

        @Override
        public double getArea() {
            return area;
        }

        @Override
        public int hashCode() {
            return Objects.hash(getClass(), min, max, normal);
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }

            Triangle other = (Triangle)o;

            if( !Objects.equals(other.min, min) ) {
                return false;
            }
            if( !Objects.equals(other.max, max) ) {
                return false;
            }
            if( !Objects.equals(other.normal, normal) ) {
                return false;
            }
            return true;
        }

        @Override
        public String toString() {
            return "Triangle[" + min + ", " + max + ", norm:" + normal + "]";
        }
    }

    public static class Circle extends AbstractShape {
        static final long serialVersionUID = 42L;

        private Vector2f center;
        private double radius;
        private double area;

        private Circle() {
        }

        public Circle( double xCenter, double yCenter, double radius ) {
            this.center = new Vector2f(quantize(xCenter), quantize(yCenter));
            this.radius = radius;
            this.area = Math.PI * radius * radius;
        }

        @Override
        public List<Vector2f> getBorder() {
            List<Vector2f> results = new ArrayList<>();

            int points = 8;
            double radDelta = 2 * Math.PI / points;
            for( int i = 0; i < points; i++ ) {
                double x = Math.cos(i * radDelta) * radius;
                double y = Math.sin(i * radDelta) * radius;
                results.add(new Vector2f(center).addLocal((float)x, (float)y));
            }

            return results;
        }

        @Override
        public BoundaryShape translate( Direction dir, double x, double y, double z ) {
            Vec3d pCenter = projectPos(center, dir);

            pCenter.x += x;
            pCenter.y += y;
            pCenter.z += z;

            Vector2f v = unprojectPos(pCenter, dir);

            BoundaryShape result = getCircle(v.x, v.y, radius);
            return result;
        }

        @Override
        public BoundaryShape scale( Direction dir, double xOrigin, double yOrigin, double zOrigin, double x, double y, double z ) {

            Vec3d pCenter = projectPos( center, dir );
            pCenter.x = (xOrigin + (pCenter.x + 0.5  - xOrigin) * x) - 0.5;
            pCenter.y = (yOrigin + (pCenter.y + 0.5  - yOrigin) * y) - 0.5;
            pCenter.z = (zOrigin + (pCenter.z + 0.5  - zOrigin) * z) - 0.5;

            // Figure out what the two scale values in our plane are
            Vector2f pScale = unprojectDir(new Vec3d(x, y, z), dir);
            if( pScale.x != pScale.y ) {
                throw new RuntimeException("Non-uniform scaling in circle plane:" + pScale);
            }

            double newRadius = radius * pScale.x;

            Vector2f v = unprojectPos(pCenter, dir);

            // Should be ok as long as none of the scales are negative
            BoundaryShape result = getCircle(v.x, v.y, newRadius);
            return result;
        }

        @Override
        public BoundaryShape rotate( Direction dir, int dirDelta ) {

            Vec3d pCenter = projectPos( center, dir );

            // Shapes are projected in space where z is up... so it's
            // around the z-axis that we need to rotate.
            //Quatd rot = new Quatd().fromAngles(0, FastMath.DEG_TO_RAD * dirDelta * 90, 0);
            // That comment is old anyway, as now everything is y-up... and that rotates
            // counterclockwise.
            Quatd rot = Direction.getRotation(dirDelta);

            pCenter = rot.mult(pCenter);

            Direction newDir = dir.rotate(dirDelta);

            Vector2f v1 = unprojectPos(pCenter, newDir);

            BoundaryShape result = getCircle(v1.x, v1.y, radius);
            return result;
        }

        @Override
        public boolean isMatchingFace( BoundaryShape shape ) {
            return shape == this;
        }

        @Override
        public double getArea() {
            return area;
        }

        @Override
        public int hashCode() {
            return Objects.hash(getClass(), center, radius);
        }

        @Override
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }

            Circle other = (Circle)o;

            if( !Objects.equals(other.center, center) )
                return false;
            if( Double.compare(other.radius, radius) != 0 )
                return false;
            return true;
        }

        public String toString() {
            return "Circle[" + center + ", " + radius + "]";
        }
    }
}


