/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.config;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.jme3.asset.AssetManager;
import com.jme3.export.*;
import com.jme3.export.binary.*;
import com.jme3.material.Material;

import com.simsilica.mblock.geom.GeomPart;
import com.simsilica.mblock.geom.GeomReq;
import com.simsilica.mblock.geom.MaterialType;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MaterialRegistry implements Serializable {

    static Logger log = LoggerFactory.getLogger(MaterialRegistry.class);

    static final long serialVersionUID = 42L;

    private Set<String> names = new TreeSet<>();
    private Map<MaterialType, MaterialConfig> configs = new HashMap<>();
    private ListMultimap<String, MaterialConfig> configIndex
                    = MultimapBuilder.hashKeys().arrayListValues().build();

    // Key the materials map off of MaterialType.getId() so that it's
    // a one-to-one mapping and more portable.
    private transient Map<String, Material> materials = new HashMap<>();

    public MaterialRegistry() {
    }

    public void initialize( AssetManager assets ) {
        for( MaterialConfig config : configs.values() ) {
            MaterialType mt = config.getMaterialType();
            log.info("Creating material:" + mt + "  parms:" + config.entrySet());
            materials.put(mt.getId(), config.createMaterial(assets, this));
        }
    }

    public void update( AssetManager assets ) {
        for( MaterialConfig config : configs.values() ) {
            update(config, assets);
        }
    }

    public void update( MaterialConfig config, AssetManager assets ) {
        log.info("Updating:" + config.getName());
        MaterialType mt = config.getMaterialType();
        String key = mt.getId();
        Material mat = materials.get(key);
        if( mat == null ) {
            materials.put(key, config.createMaterial(assets, this));
            return;
        }
        config.updateMaterial(mat, assets, this);
    }

    public void addConfig( MaterialConfig config ) {
        MaterialType mt = config.getMaterialType();
        configs.put(mt, config);
        configIndex.put(config.getName(), config);
        names.add(config.getName());
    }

    public void addConfigs( Collection<MaterialConfig> configs ) {
        for( MaterialConfig c : configs ) {
            addConfig(c);
        }
    }

    public Set<MaterialType> getTypes() {
        return configs.keySet();
    }

    public Collection<String> getNames() {
        return names;
    }

    public Collection<MaterialConfig> getConfigs() {
        return configs.values();
    }

    public Collection<MaterialConfig> getConfigs( String name ) {
        return configIndex.get(name);
    }

    public MaterialConfig getConfig( MaterialType type ) {
        return configs.get(type);
    }

    public MaterialConfig findConfig( String name, MaterialType type ) {
        // For now just return the first one... in this transition
        // phase there is only one per name anyway and we may change
        // what 'inheritance' means soon.  Otherwise, a material that
        // requires normals won't find another material that requires
        // normals even if it exists because there is no logical way (yet)
        // to use type to find a parent.  And in parent-finding, the
        // type is technically not 100% relevant.  There is some 'baser'
        // material than all the others for a given name and other than
        // ordering, we have no better way to define it.  And we can't
        // just apply the properties of any old material config because
        // it might include flags that the searching material doesn't
        // support.
        List<MaterialConfig> list = configIndex.get(name);
        if( !list.isEmpty() ) {
            return list.get(0);
        }
        return null;
    }

    /**
     *  Returns the best fit material for the specified part and name.
     *  It tries to find the most efficient material that the part
     *  will support.
     */
    public MaterialConfig findBest( String name, GeomPart part ) {
        EnumSet<GeomReq> caps = part.calculateGeomCaps();
        return findBest(name, caps);
    }

    public MaterialConfig findBest( String name, GeomReq... caps ) {
        EnumSet<GeomReq> set = EnumSet.noneOf(GeomReq.class);
        if( caps != null && caps.length > 0 ) {
            set.addAll(Arrays.asList(caps));
            set = GeomReq.expandImplied(set);
        }
        return findBest(name, set);
    }

    public MaterialConfig findBest( String name, EnumSet<GeomReq> caps ) {
log.info("************ findBest(" + name + ", " + caps + ")");
        MaterialConfig best = null;
        int maxCount = -1;
        for( MaterialConfig config : configIndex.get(name) ) {
            EnumSet<GeomReq> reqs = config.getImpliedReqs();
log.info("  " + name + "  reqs:" + reqs);
            // Will the geometry support every thing that the material
            // requires?
            if( caps.containsAll(reqs) || reqs.isEmpty() ) {
log.info("    compatible.");
                if( reqs.size() > maxCount ) {
                    // Best so far
                    maxCount = reqs.size();
                    best = config;
                }
            }
        }
        return best;
    }

    public boolean remove( MaterialType type ) {
        log.info("Removing:" + type);
        MaterialConfig config = configs.remove(type);
        if( config == null ) {
            return false;
        }
        configIndex.remove(type, config);
        materials.remove(type.getId());
        return true;
    }

    public Material getMaterial( MaterialType type ) {
        return getMaterial(type, true);
    }

    public Map<String, Material> getMaterials() {
        return materials;
    }

    public void storeCompiledMaterials( OutputStream out ) throws IOException {
        BinaryExporter.getInstance().save(new MaterialSetSavable(materials), out);
    }

    public static Map<String, Material> loadCompiledMaterials( AssetManager assets, InputStream in ) throws IOException {
        BinaryImporter importer = BinaryImporter.getInstance();
        importer.setAssetManager(assets);
        MaterialSetSavable loaded = (MaterialSetSavable)importer.load(in);
        return loaded.materials;
    }

    public static Map<String, Material> loadCompiledMaterials( AssetManager assets, String resource ) throws IOException {
        java.net.URL u = MaterialRegistry.class.getResource(resource);
        if( u == null ) {
            // Could try the context class loader
            return null;
        }
        return loadCompiledMaterials(assets, u.openStream());
    }

    public Material getMaterial( MaterialType type, boolean failOnMiss ) {
        Material result = materials.get(type.getName());
        if( result == null && materials.containsKey(type.getName()) ) {
            throw new IllegalStateException("MaterialRegistry has not been initialized");
        }
        if( result == null && failOnMiss ) {
            throw new IllegalArgumentException("No material found for:" + type + ", all types:" + materials.keySet());
        }
        return result;
    }

    // JME won't let us store a map directly so we need at least a
    // wrapper object to hold it. :-/
    public static class MaterialSetSavable implements Savable {

        private Map<String, Material> materials;

        protected MaterialSetSavable() {
        }

        public MaterialSetSavable( Map<String, Material> materials ) {
            this.materials = materials;
        }

        @Override
        @SuppressWarnings("unchecked")
        public void read( JmeImporter in ) throws IOException {
            this.materials = (Map<String, Material>)in.getCapsule(this).readStringSavableMap("materials", null);
        }

        @Override
        public void write( JmeExporter out ) throws IOException {
            out.getCapsule(this).writeStringSavableMap(materials, "materials", null);
        }
    }
}
