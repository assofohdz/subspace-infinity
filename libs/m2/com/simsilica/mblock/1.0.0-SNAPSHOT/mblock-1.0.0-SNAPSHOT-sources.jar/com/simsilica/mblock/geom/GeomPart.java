/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.io.Serializable;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.Vec3i;
import com.simsilica.mathd.Vec3d;

import com.simsilica.mblock.Direction;

/**
 *  Some single piece of geometry such as a point or a triangle, defined in
 *  local space (0 to 1).  This can be combined with other geometry in a buffer
 *  based on material and then subsequently used to generate mesh data.  In many cases,
 *  a single GeomPart can be reused and within a GeomPartBuffer is treated
 *  as a template where the data in this part is combined with a local
 *  origin during actual mesh generation.  This is why the coordinates within
 *  a GeomPart are 0-based.
 *
 *  @author    Paul Speed
 */
public class GeomPart implements Cloneable, Serializable {

    static Logger log = LoggerFactory.getLogger(GeomPart.class);

    static final long serialVersionUID = 42L;

    private MaterialType materialType;
    private PrimitiveType primitiveType;

    private int dir = -1; // for auto-normal indexing where the shader calculates the normal
    private boolean floatTexCoords;
    private float[] coords;
    private float[] norms;
    private float[] texes;
    private float[] tangents;
    private short[] indexes;

    // So far we set colors in things like flame factory or the
    // particles.
    private float[] colors;
    private float[] sizes;

    public GeomPart( MaterialType materialType, int dir, boolean floatTexCoords ) {
        this(materialType, PrimitiveType.Triangles, dir, floatTexCoords);
    }

    public GeomPart( MaterialType materialType ) {
        this(materialType, PrimitiveType.Triangles, -1, false);
    }

    public GeomPart( MaterialType materialType, PrimitiveType primitiveType ) {
        this(materialType, primitiveType, -1, false);
    }

    public GeomPart( MaterialType materialType, PrimitiveType primitiveType, int dir, boolean floatTexCoords ) {
        this.materialType = materialType;
        this.primitiveType = primitiveType;
        this.dir = dir;
        this.floatTexCoords = floatTexCoords;
    }

    /**
     *  Creates a "back face" version of this part.
     */
    public GeomPart invert() {
        return invert(materialType);
    }

    /**
     *  Creates a "back face" version of this part.
     */
    public GeomPart invert( MaterialType materialType ) {

        if( primitiveType != PrimitiveType.Triangles ) {
            throw new UnsupportedOperationException("Can only invert triangle-based geometry.");
        }
        if( indexes == null || indexes.length == 0 ) {
            // For now
            throw new UnsupportedOperationException("Can only invert index-based geometry.");
        }
        GeomPart clone = clone();
        clone.materialType = materialType;
        clone.indexes = clone.indexes.clone();
        short[] newIndexes = clone.indexes;
        for( int i = 0; i < newIndexes.length; i += 3 ) {
            // Just swap +1 and +2 to invert the triangle
            short swap = newIndexes[i+1];
            newIndexes[i+1] = newIndexes[i+2];
            newIndexes[i+2] = swap;
        }
        if( clone.norms != null ) {
            // Need to invert the normals but tangents should be ok since the texture coordinates
            // are still reflected.
            clone.norms = clone.norms.clone();
            float[] newNorms = clone.norms;
            for( int i = 0; i < newNorms.length; i ++ ) {
                newNorms[i] *= -1;
            }
        }
        if( clone.dir != -1 ) {
            // Need to invert the automatic normal direction... which, by the way, probably WILL
            // mess up the tangents.
            // One way to fix that would be to have extra direction indexes to flip the tangent
            //Direction d = Direction.values()[clone.dir];
            //clone.dir = d.reverse().ordinal();
            clone.dir += 6;
        }

        return clone;
    }

    /**
     *  Convenience factory method for creating a full cube face in the specified
     *  direction.
     */
    public static GeomPart createFace( MaterialType materialType, Direction dir ) {
        GeomPart part = new GeomPart(materialType, dir == null ? -1 : dir.ordinal(), false);

        // Indexed normals so we only have to set the coordinates, indexes, and
        // texture coordinates
        // For now I'll leave these here but they really should default to direction
        // specific min/max.
        part.texes = new float[] {
            0, 0,
            1, 0,
            1, 1,
            0, 1
        };
        part.indexes = new short[] {
            0, 1, 2,
            0, 2, 3
        };

        switch( dir ) {
            case North:
                part.coords = new float[] {
                    1, 0, 0,
                    0, 0, 0,
                    0, 1, 0,
                    1, 1, 0
                };
                break;
            case South:
                part.coords = new float[] {
                    0, 0, 1,
                    1, 0, 1,
                    1, 1, 1,
                    0, 1, 1
                };
                break;
            case East:
                part.coords = new float[] {
                    1, 0, 1,
                    1, 0, 0,
                    1, 1, 0,
                    1, 1, 1
                };
                break;
            case West:
                part.coords = new float[] {
                    0, 0, 0,
                    0, 0, 1,
                    0, 1, 1,
                    0, 1, 0
                };
                break;
            case Up:
                part.coords = new float[] {
                    0, 1, 1,
                    1, 1, 1,
                    1, 1, 0,
                    0, 1, 0
                };
                break;
            case Down:
                part.coords = new float[] {
                    0, 0, 0,
                    1, 0, 0,
                    1, 0, 1,
                    0, 0, 1
                };
                break;
        }
        if( !materialType.needsIndexedNormals() && dir != null ) {
            if( materialType.needsNormals() ) {
                part.generateNormals(dir);
            }
            if( materialType.needsTangents() ) {
                part.generateTangents(dir);
            }
        }
        return part;
    }

    /**
     *  Convenience factory method for creating a non-unit sized cube face in the specified
     *  direction.
     */
    public static GeomPart createQuad( Vec3d min, Vec3d max, MaterialType materialType, Direction dir ) {
        // Old one would stretch by default so we will too
        return createQuad(min, max, materialType, dir, true);
    }

    public static GeomPart createQuad( Vec3d min, Vec3d max, MaterialType materialType, Direction dir, boolean stretch ) {
        GeomPart part = new GeomPart(materialType, dir.ordinal(), false);

        // Indexed normals so we only have to set the coordinates, indexes, and
        // texture coordinates
        if( stretch ) {
            part.texes = new float[] {
                0, 0,
                1, 0,
                1, 1,
                0, 1
            };
        }
        part.indexes = new short[] {
            0, 1, 2,
            0, 2, 3
        };

        switch( dir ) {
            case North:
                part.coords = new float[] {
                    (float)max.x, (float)min.y, (float)min.z,
                    (float)min.x, (float)min.y, (float)min.z,
                    (float)min.x, (float)max.y, (float)min.z,
                    (float)max.x, (float)max.y, (float)min.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        1 - (float)max.x, (float)min.y,
                        1 - (float)min.x, (float)min.y,
                        1 - (float)min.x, (float)max.y,
                        1 - (float)max.x, (float)max.y
                    };
                }
                break;
            case South:
                part.coords = new float[] {
                    (float)min.x, (float)min.y, (float)max.z,
                    (float)max.x, (float)min.y, (float)max.z,
                    (float)max.x, (float)max.y, (float)max.z,
                    (float)min.x, (float)max.y, (float)max.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        (float)min.x, (float)min.y,
                        (float)max.x, (float)min.y,
                        (float)max.x, (float)max.y,
                        (float)min.x, (float)max.y
                    };
                }
                break;
            case East:
                part.coords = new float[] {
                    (float)max.x, (float)min.y, (float)max.z,
                    (float)max.x, (float)min.y, (float)min.z,
                    (float)max.x, (float)max.y, (float)min.z,
                    (float)max.x, (float)max.y, (float)max.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        1 - (float)max.z, (float)min.y,
                        1 - (float)min.z, (float)min.y,
                        1 - (float)min.z, (float)max.y,
                        1 - (float)max.z, (float)max.y
                    };
                }
                break;
            case West:
                part.coords = new float[] {
                    (float)min.x, (float)min.y, (float)min.z,
                    (float)min.x, (float)min.y, (float)max.z,
                    (float)min.x, (float)max.y, (float)max.z,
                    (float)min.x, (float)max.y, (float)min.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        (float)min.z, (float)min.y,
                        (float)max.z, (float)min.y,
                        (float)max.z, (float)max.y,
                        (float)min.z, (float)max.y
                    };
                }
                break;
            case Up:
                part.coords = new float[] {
                    (float)min.x, (float)max.y, (float)max.z,
                    (float)max.x, (float)max.y, (float)max.z,
                    (float)max.x, (float)max.y, (float)min.z,
                    (float)min.x, (float)max.y, (float)min.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        (float)min.x, 1 - (float)max.z,
                        (float)max.x, 1 - (float)max.z,
                        (float)max.x, 1 - (float)min.z,
                        (float)min.x, 1 - (float)min.z
                    };
                }
                break;
            case Down:
                part.coords = new float[] {
                    (float)min.x, (float)min.y, (float)min.z,
                    (float)max.x, (float)min.y, (float)min.z,
                    (float)max.x, (float)min.y, (float)max.z,
                    (float)min.x, (float)min.y, (float)max.z
                };
                if( !stretch ) {
                    part.texes = new float[] {
                        (float)min.x, (float)min.z,
                        (float)max.x, (float)min.z,
                        (float)max.x, (float)max.z,
                        (float)min.x, (float)max.z
                    };
                }
                break;
        }
        if( !materialType.needsIndexedNormals() && dir != null ) {
            if( materialType.needsNormals() ) {
                part.generateNormals(dir);
            }
            if( materialType.needsTangents() ) {
                part.generateTangents(dir);
            }
        }
        return part;
    }

    public static Vec3d getNormal( Direction dir ) {
        return dir.getVec3i().toVec3d();
    }

    public static Vec3d getTangent( Direction dir ) {
        switch( dir ) {
            case North:
                return new Vec3d(-1, 0, 0);
            case South:
                return new Vec3d(1, 0, 0);
            case East:
                return new Vec3d(0, 0, -1);
            case West:
                return new Vec3d(0, 0, 1);
            case Up:
                return new Vec3d(1, 0, 0);
            case Down:
                return new Vec3d(1, 0, 0);
        }
        throw new IllegalArgumentException("Unnknown dir:" + dir);
    }

    // For parts with a dir and no indexed normals, we can generate tangents.
    protected void generateNormals( Direction dir ) {
        if( log.isTraceEnabled() ) {
            log.trace("generateNormals(" + dir + ")");
        }
        Vec3i v = dir.getVec3i();
        norms = new float[getVertexCount() * 3];
        int index = 0;
        for( int i = 0; i < getVertexCount(); i++ ) {
            norms[index++] = v.x;
            norms[index++] = v.y;
            norms[index++] = v.z;
        };
    }

    protected void generateTangents( Direction dir ) {
        if( log.isTraceEnabled() ) {
            log.trace("generateTangents(" + dir + ")");
        }
        Vec3d v = getTangent(dir); //new Vec3i();
        //switch( dir ) {
        //    case North:
        //        v.set(-1, 0, 0);
        //        break;
        //    case South:
        //        v.set(1, 0, 0);
        //        break;
        //    case East:
        //        v.set(0, 0, -1);
        //        break;
        //    case West:
        //        v.set(0, 0, 1);
        //        break;
        //    case Up:
        //        v.set(-1, 0, 0);
        //        break;
        //    case Down:
        //        v.set(1, 0, 0);
        //        break;
        //}
        tangents = new float[getVertexCount() * 3];
        int index = 0;
        for( int i = 0; i < getVertexCount(); i++ ) {
            tangents[index++] = (float)v.x;
            tangents[index++] = (float)v.y;
            tangents[index++] = (float)v.z;
        };
    }

    /**
     *  For geom parts that support indexed normals this will
     *  generate or clear the real normal and tangent buffers based
     *  on the current materialType.
     */
    public void setupAlternates() {
        if( dir < 0 ) {
            return;
        }

        if( materialType.requires(GeomReq.IndexedNormals) ) {
            // Not required but it can save a bit of memory to not carry
            // the extra redundant/unncessary data around.
            log.trace("Clearing normal and tangent buffers");
            norms = null;
            tangents = null;
            return;
        }

        int dirUnflipped = dir % 6;
        Direction d = Direction.values()[dirUnflipped];
        if( materialType.requires(GeomReq.Normals) && norms == null ) {
            if( dir >= 6 ) {
                // For inverted directions the normals are reversed but not the tangents
                generateNormals(d.reverse());
            } else {
                generateNormals(d);
            }
        }
        if( materialType.requires(GeomReq.Tangents) && tangents == null ) {
            generateTangents(d);
        }
    }

    public GeomPart clone() {
        try {
            GeomPart result = (GeomPart)super.clone();
            return result;
        } catch( CloneNotSupportedException e ) {
            throw new RuntimeException( "Error cloning geom part", e );
        }
    }

    /**
     *  Returns the set of GeomReqs that this part is capable of
     *  supporting.  For example, just because a part has tangents
     *  doesn't mean that the material has to use them.
     */
    public EnumSet<GeomReq> calculateGeomCaps() {
        EnumSet<GeomReq> result = EnumSet.noneOf(GeomReq.class);

        if( hasIndexedNormals() ) {
            result.add(GeomReq.IndexedNormals);
        }
        if( norms != null ) {
            result.add(GeomReq.Normals);
            // Could do some magic to check for 'lores-ness'
        }
        if( tangents != null ) {
            result.add(GeomReq.Tangents);
        }
        if( colors != null ) {
            result.add(GeomReq.Colors);
        }
        if( sizes != null ) {
            result.add(GeomReq.Sizes);
        }
        result = GeomReq.expandImplied(result);

        return result;
    }

    public void setMaterialType( MaterialType materialType ) {
        this.materialType = materialType;

        // See if we need to reconfigure the normals and tangents based
        // on 'indexedness'. Not required but it can save a bit of memory
        // to not carry the extra redundant/unncessary data around.
        setupAlternates();
    }

    public MaterialType getMaterialType() {
        return materialType;
    }

    public PrimitiveType getPrimitiveType() {
        return primitiveType;
    }

    public int getDirectionIndex() {
        return dir;
    }

    public boolean hasIndexedNormals() {
        return dir != -1;
    }

    public boolean requiresFloatTexCoords() {
        return floatTexCoords;
    }

    public void setCoords( float... f ) {
        // Could do some length validation here if we wanted
        // to be defensive
        this.coords = f;
    }

    public float[] getCoords() {
        return coords;
    }

    public int getVertexCount() {
        return coords.length / 3;
    }

    public void setNormals( float... f ) {
        if( hasIndexedNormals() ) {
            log.error("Setting normals on a part with indexed normals.");
        }
        this.norms = f;
    }

    public float[] getNormals() {
        return norms;
    }

    public void setTangents( float... f ) {
        if( hasIndexedNormals() ) {
            log.error("Setting tangents on a part with indexed normals.");
        }
        this.tangents = f;
    }

    public float[] getTangents() {
        return tangents;
    }

    public void setTexCoords( float... f ) {
        this.texes = f;
    }

    public float[] getTexCoords() {
        return texes;
    }

    public void setIndexes( short... s ) {
        this.indexes = s;
    }

    public void setIndexes( int... ints ) {
        this.indexes = new short[ints.length];
        for( int i = 0; i < indexes.length; i++ ) {
            indexes[i] = (short)ints[i];
        }
    }

    public short[] getIndexes() {
        return indexes;
    }

    public void setColors( float... f ) {
        this.colors = f;
    }

    public float[] getColors() {
        return colors;
    }

    public void setSizes( float... f ) {
        this.sizes = f;
    }

    public float[] getSizes() {
        return sizes;
    }

    public int getTriangleCount() {
        if( indexes != null ) {
            return primitiveType.getCount(indexes.length);
        }
        return primitiveType.getCount(coords.length / 3);
    }

    public GeomPart rotate( int dirDelta ) {
        if( dirDelta < 0 || dirDelta > 3 ) {
            throw new IllegalArgumentException("dirDelta is out of bounds:" + dirDelta);
        }

        GeomPart result = new GeomPart(materialType, primitiveType);

        // Need to uninvert inverted dirs
        int d = dir;
        if( d >= 0 ) {
            // Un-invert the direction if necessary
            d = d % 6;

            //result.dir = (dir + dirDelta) % 4;
            result.dir = GeomUtils.rotateIndex(d, dirDelta);

            // If it's an inverted dir then reinvert it
            if( dir >= 6 ) {
                result.dir += 6;
            }
        }
        if( d < 0 ) {
            // Transfer the normals/tangents if there... but only if
            // we aren't using indexed normals.
            result.norms = GeomUtils.rotateDir(norms, dirDelta);
            result.tangents = GeomUtils.rotateDir(tangents, dirDelta);
        }

        // For up and down, things get weird with respect to indexed
        // tangents and texture coordinates.  For asymmetric shapes
        // we do want to rotate them but we will also need to rotate
        // the texture coordinates somehow or the indexed tangents will be
        // wrong.
        result.coords = GeomUtils.rotatePos(coords, dirDelta);

        if( d >= 4 ) {
            // Up or down
            int vertCount = coords.length / 3;
            // -dirDelta because we are trying to counteract the vertex rotation
            // by inverting the texture coordinate rotation... we want the texture
            // coordinates not to move in space.
            result.texes = GeomUtils.rotateUvs(texes, vertCount, Direction.values()[d], -dirDelta);
        } else {
            result.texes = texes == null ? null : texes.clone();
        }

        // And just copy the rest
        result.floatTexCoords = floatTexCoords;

        result.indexes = indexes == null ? null : indexes.clone();
        result.colors = colors == null ? null : colors.clone();
        result.sizes = sizes == null ? null : sizes.clone();

        return result;
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        GeomPart other = (GeomPart)o;
        if( other.dir != dir ) {
            return false;
        }
        if( other.floatTexCoords != floatTexCoords ) {
            return false;
        }
        if( !Objects.equals(other.materialType, materialType) ) {
            return false;
        }
        if( !Objects.equals(other.primitiveType, primitiveType) ) {
            return false;
        }
        if( !Arrays.equals(other.coords, coords) ) {
            return false;
        }
        if( !Arrays.equals(other.norms, norms) ) {
            return false;
        }
        if( !Arrays.equals(other.texes, texes) ) {
            return false;
        }
        if( !Arrays.equals(other.tangents, tangents) ) {
            return false;
        }
        if( !Arrays.equals(other.indexes, indexes) ) {
            return false;
        }
        if( !Arrays.equals(other.colors, colors) ) {
            return false;
        }
        if( !Arrays.equals(other.sizes, sizes) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dir, floatTexCoords, materialType, primitiveType,
                            Arrays.hashCode(coords),
                            Arrays.hashCode(norms),
                            Arrays.hashCode(texes),
                            Arrays.hashCode(tangents),
                            Arrays.hashCode(indexes),
                            Arrays.hashCode(colors),
                            Arrays.hashCode(sizes));
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("materialType", materialType)
            .add("primitiveType", primitiveType)
            .add("directionIndex", dir)
            .add("vertexCount", getVertexCount())
            .add("triangleCount", getTriangleCount())
            .toString();
    }
}



