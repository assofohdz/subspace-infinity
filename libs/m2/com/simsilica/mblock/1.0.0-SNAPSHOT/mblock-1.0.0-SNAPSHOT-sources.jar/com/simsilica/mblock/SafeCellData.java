/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;


/**
 *  Wraps one CellData and provides safe access through all get() calls
 *  by returning a default value and optionally read-only set() calls.
 *
 *  @author    Paul Speed
 */
public class SafeCellData implements CellData {

    private CellData delegate;
    private int defaultValue;
    private boolean readOnly;

    public SafeCellData( CellData delegate, int defaultValue ) {
        this(delegate, defaultValue, false);
    }

    public SafeCellData( CellData delegate, int defaultValue, boolean readOnly ) {
        this.delegate = delegate;
        this.defaultValue = defaultValue;
        this.readOnly = readOnly;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        return delegate.getCell(x, y, z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        return delegate.getCell(x, y, z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        return delegate.getCell(x, y, z, dir, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
        if( !readOnly ) {
            delegate.setCell(x, y, z, value);
        }
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[defaultValue:" + defaultValue + ", delegate:" + delegate + "]";
    }
}
