/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import com.simsilica.mathd.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public enum Axis {
    X(new Vec3i(1, 0, 0)), 
    Y(new Vec3i(0, 1, 0)), 
    Z(new Vec3i(0, 0, 1));
 
    private Vec3i dir;
    
    private Axis( Vec3i dir ) {
        this.dir = dir;
    }
    
    public Vec3i getDirection() {
        return dir;
    }
    
    public Vec3i getLeft() {
        switch(this) {
            case X:
                return new Vec3i(0, 0, -1);
            case Y:
                return new Vec3i(-1, 0, 0);
            case Z:
                return new Vec3i(-1, 0, 0);
            default:
                throw new UnsupportedOperationException("Unhandled type:" + this);
        }
    }

    public Vec3i getUp() {
        switch(this) {
            case X:
                return new Vec3i(0, 1, 0);
            case Y:
                return new Vec3i(0, 0, 1);
            case Z:
                return new Vec3i(0, 1, 0);
            default:
                throw new UnsupportedOperationException("Unhandled type:" + this);
        }
    }
}
