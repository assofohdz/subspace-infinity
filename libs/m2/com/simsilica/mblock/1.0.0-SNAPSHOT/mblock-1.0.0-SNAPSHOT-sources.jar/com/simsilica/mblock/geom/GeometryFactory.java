/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.nio.*;
import java.util.Map;

import org.slf4j.*;

import com.jme3.asset.AssetManager;
import com.jme3.bounding.BoundingBox;
import com.jme3.material.Material;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import com.jme3.scene.VertexBuffer;
import com.jme3.scene.mesh.IndexBuffer;
import com.jme3.util.BufferUtils;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;


/**
 *  Creates JME geometry for a block array using the configured
 *  material registry and global block type index.
 *
 *  @author    Paul Speed
 */
public class GeometryFactory {
    static Logger log = LoggerFactory.getLogger(GeometryFactory.class);

    private Map<String, Material> materials;
    private boolean allowCollisions;

    public GeometryFactory( Map<String, Material> materials ) {
        this(true, materials);
    }

    public GeometryFactory( boolean allowCollisions, Map<String, Material> materials ) {
        this.allowCollisions = allowCollisions;
        this.materials = materials;
    }

    /**
     *  Generates Geometry objects for the specified cells CellArray and lightData
     *  cellArray.  The Geometry objects are added to the 'target' Node.  The
     *  target node's existing children are cleared during this process.
     *  Each material represented in the cells data is a separate Geometry child
     *  in the final Node child list.
     */
    public Node generateBlocks( Node target, CellArray cells, CellData lightData, boolean smoothLighting ) {
        // For now we'll still choose lighting implementation internally

        long start = System.nanoTime();
        Node result = target;
        result.detachAllChildren();

        // Collect the visible GeomParts by type
        DefaultPartBuffer buffer = new DefaultPartBuffer();

        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();

        for( int x = 0; x < xSize; x++ ) {
            for( int y = 0; y < ySize; y++ ) {
                for( int z = 0; z < zSize; z++ ) {
                    int val = cells.getCell(x, y, z);
                    int type = MaskUtils.getType(val);
                    if( type == 0 ) {
                        continue;
                    }
                    BlockType blockType = BlockTypeIndex.get(type);
                    if( blockType == null ) {
                        continue;
                    }
                    int sideMask = MaskUtils.getSideMask(val);
                    blockType.getFactory().addGeometryToBuffer(buffer, x, y, z, x, y, z,
                                                               sideMask, cells, blockType);
                }
            }
        }

        // Resolve a light gradient implementation based on the
        // smooth lighting flag.  Ultimately, if we ever have more than
        // two implementations or can think of reasons why this should be
        // customized then we should break it out as a parameter.  Might also
        // consider supporting pregenerated part buffers though I have no
        // strong reason why today.  2020-11-22
        LightGradient gradient = null;
        if( smoothLighting ) {
            gradient = calculateLightGradient(cells, lightData);
        } else {
            gradient = new NoLightGradient(lightData);
        }
        renderBuffer(result, buffer, gradient, lightData);

        long end = System.nanoTime();
        if( log.isTraceEnabled() ) {
            log.trace("Generated in:" + ((end - start)/1000000.0) + " ms");
        }
        return result;
    }



    /**
     *  Generates Geometry objects for the specified fluid, cells, and lightData cell arrays.
     *  The Geometry objects are added to the 'target' Node.  The
     *  target node's existing children are cleared during this process.
     *  Each material represented in the cells data is a separate Geometry child
     *  in the final Node child list.
     */
    public Node generateFluid( Node target, CellArray fluid, CellArray cells, CellData lightData, boolean smoothLighting ) {
        // For now we'll still choose lighting implementation internally
        if( fluid == null ) {
            return target;
        }

        long start = System.nanoTime();
        Node result = target;
        result.detachAllChildren();

        // Collect the visible GeomParts by type
        DefaultPartBuffer buffer = new DefaultPartBuffer();

        int xSize = fluid.getSizeX();
        int ySize = fluid.getSizeY();
        int zSize = fluid.getSizeZ();

        for( int x = 0; x < xSize; x++ ) {
            for( int y = 0; y < ySize; y++ ) {
                for( int z = 0; z < zSize; z++ ) {
                    int val = fluid.getCell(x, y, z);
                    int type = FluidUtils.getType(val);
                    if( type == 0 ) {
                        continue;
                    }
                    FluidType fluidType = FluidTypeIndex.get(type);
                    if( fluidType == null ) {
                        continue;
                    }
                    int level = FluidUtils.getLevel(val);
                    int sideMask = FluidUtils.getSideMask(val);
                    fluidType.getFactory().addGeometryToBuffer(buffer, x, y, z, x, y, z,
                                                               sideMask, level,
                                                               cells, fluid, fluidType);
                }
            }
        }

        // Resolve a light gradient implementation based on the
        // smooth lighting flag.  Ultimately, if we ever have more than
        // two implementations or can think of reasons why this should be
        // customized then we should break it out as a parameter.  Might also
        // consider supporting pregenerated part buffers though I have no
        // strong reason why today.  2020-11-22
        LightGradient gradient = null;
        if( smoothLighting ) {
            gradient = calculateLightGradient(fluid, lightData);
        } else {
            gradient = new NoLightGradient(lightData);
        }
        renderBuffer(result, buffer, gradient, lightData);

        long end = System.nanoTime();
        if( log.isTraceEnabled() ) {
            log.trace("Generated in:" + ((end - start)/1000000.0) + " ms");
        }
        return result;
    }

    protected void renderBuffer( Node target, DefaultPartBuffer buffer,
                                 LightGradient gradient, CellData lightData ) {

        // Resolve the GeomParts into actual JME mesh data
        for( DefaultPartBuffer.PartList list : buffer.getPartLists() ) {
            if( list.list.isEmpty() ) {
                continue;
            }
            MaterialType mt = list.materialType;

            // We know we have simplified geometry so our mesh generation
            // can also be simplified
            int vertCount = list.vertCount;
            ScaledBuffer pos;
            if( mt.requires(GeomReq.LoResPositions) ) {
                pos = ScaledBuffer.createScaledBuffer(vertCount * 3, 0, 32);
            } else {
                pos = ScaledBuffer.createUnscaledBuffer(vertCount * 3);
            }
            int texPerVert = 2;
            if( list.primitiveType == PrimitiveType.Points ) {
                texPerVert = 4;
            }
            int texCount = vertCount * texPerVert;
            ScaledBuffer texes;
            if( mt.requires(GeomReq.LoResTexCoords) ) {
                texes = ScaledBuffer.createScaledBuffer(texCount, 0, 1);
            } else {
                texes = ScaledBuffer.createUnscaledBuffer(texCount);
            }
            // The 3-vertex assumption may not hold for point-sprite parts
            // The 'vertCount' part is weird here... it's just informational to do
            // some bounds checking, I think.
            IndexBuffer indexes = null;
            if( list.primitiveType != PrimitiveType.Points ) {
                indexes = IndexBuffer.createIndexBuffer(vertCount, list.triCount * 3);
            }

            // We'll use the color buffer for lighting like Mythruna-proper did
            // but some of Mythruna's materials also used color for other things
            // so it might be less confusing to pick an unused tex coord.
            // Or for the old Mythruna things that used color, we can pick something
            // else like an unused TexCoord#.  Though their usage of "color" probably
            // really is 'color'.
            FloatBuffer colors = BufferUtils.createFloatBuffer(vertCount * 4);  // for lighting

            ScaledBuffer nb = null;
            ScaledBuffer tb = null;
            ByteBuffer dirB = null;
            if( mt.requires(GeomReq.IndexedNormals) ) {
                dirB = BufferUtils.createByteBuffer(vertCount);
            } else {
                // It may require other buffers
                if( mt.requires(GeomReq.Normals) ) {
                    if( mt.requires(GeomReq.LoResNormals) ) {
                        nb = ScaledBuffer.createScaledBuffer(vertCount * 3, -1, 1);
                    } else {
                        nb = ScaledBuffer.createUnscaledBuffer(vertCount * 3);
                    }
                }
                if( mt.requires(GeomReq.Tangents) ) {
                    if( mt.requires(GeomReq.LoResTangents) ) {
                        tb = ScaledBuffer.createScaledBuffer(vertCount * 3, -1, 1);
                    } else {
                        tb = ScaledBuffer.createUnscaledBuffer(vertCount * 3);
                    }
                }
            }
            ScaledBuffer sizeBuffer = null;
            if( mt.requires(GeomReq.Sizes) ) {
                sizeBuffer = ScaledBuffer.createUnscaledBuffer(vertCount);
                //sizeBuffer = ScaledBuffer.createScaledBuffer(vertCount, 0, 255);
            }

            Vector3f min = new Vector3f(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY);
            Vector3f max = new Vector3f(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
            int baseIndex = 0;
            for( DefaultPartBuffer.PartEntry entry : list.list ) {

                int i = entry.i;
                int j = entry.j;
                int k = entry.k;
                GeomPart part = entry.part;

                byte dir = (byte)part.getDirectionIndex();
                if( dirB != null && dir < 0 ) {
                    throw new RuntimeException("Entry for material:" + mt + " has invalid dir:" + dir);
                }
                Direction dirEnum = dir >= 0 ? Direction.values()[dir % 6] : null;
                if( dir >= 6 ) {
                    dirEnum = dirEnum.reverse();
                }
                int size = part.getVertexCount();
                float[] verts = part.getCoords();
                float[] norms = part.getNormals();
                float[] tangents = part.getTangents();
                float[] sizes = part.getSizes();

                int vIndex = 0;
                for( int v = 0; v < size; v++ ) {
                    float x = verts[vIndex++];
                    float y = verts[vIndex++];
                    float z = verts[vIndex++];
                    float ix = i + x;
                    float jy = j + y;
                    float kz = k + z;
                    pos.put(ix);
                    pos.put(jy);
                    pos.put(kz);

                    min.x = Math.min(min.x, ix);
                    min.y = Math.min(min.y, jy);
                    min.z = Math.min(min.z, kz);
                    max.x = Math.max(max.x, ix);
                    max.y = Math.max(max.y, jy);
                    max.z = Math.max(max.z, kz);

                    if( dirB != null ) {
                        dirB.put(dir);
                    }
                    if( sizeBuffer != null ) {
                        sizeBuffer.put(sizes[v]);
                    }

                    // Apply lighting data to this face as required
                    // Note: original Mythruna-new did this too for its lighting
                    // implementation (more or less).  It's interesting that we
                    // don't check the material or anything considering that a comment
                    // above indicates that some block types use color for different
                    // things.  This line seems to indicate that 'colors' is the standard
                    // buffer for lighting data and nothing can 'opt out'.
                    gradient.appendLight(lightData, i, j, k, x, y, z, dirEnum, colors);
                }

                if( nb != null && norms != null ) {
                    nb.put(norms);
                }
                if( tb != null && tangents != null ) {
                    tb.put(tangents);
                }

                float[] texArray = part.getTexCoords();
                for( int t = 0; t < texArray.length; t++ ) {
                    // I don't know why I put this check in because
                    // there could be valid reasons for wanting shifted
                    // coordinates. 2020-12-24
                    //if( texArray[t] < 0 || texArray[t] > 1 ) {
                    //    throw new RuntimeException("Entry has out of bounds texcoord:" + texArray[t]
                    //                                + " type:" + part.getMaterialType());
                    //}
                    // Removing the above because sometimes we want wrapping
                    // like for cylinders.  Not sure how it could work otherwise
                    // without a lot of repeated vertexes
                    texes.put(texArray[t]);
                }

                if( part.getIndexes() != null ) {
                    // The indexes need to be offset also
                    for( short s : part.getIndexes() ) {
                        indexes.put(baseIndex + s);
                    }
                    baseIndex += size;
                }
            }

            // Use a mesh with no collision
            Mesh mesh = new ColliderlessMesh(target.getName() + "#" + mt, allowCollisions);
            switch( list.primitiveType ) {
                case Points:
                    mesh.setMode(Mesh.Mode.Points);
                    break;
                case Triangles:
                default:
                    break;
            }
            pos.applyToMesh(mesh, VertexBuffer.Type.Position, 3);
            texes.applyToMesh(mesh, VertexBuffer.Type.TexCoord, texPerVert);

            if( indexes != null ) {
                // Just an otherwise convenient class to have to do this BS
                switch( indexes.getFormat() ) {
                    case UnsignedInt:
                        mesh.setBuffer(VertexBuffer.Type.Index, 3, (IntBuffer)indexes.getBuffer());
                        break;
                    case UnsignedShort:
                        mesh.setBuffer(VertexBuffer.Type.Index, 3, (ShortBuffer)indexes.getBuffer());
                        break;
                    case UnsignedByte:
                        mesh.setBuffer(VertexBuffer.Type.Index, 3, (ByteBuffer)indexes.getBuffer());
                        break;
                }
            }
            if( dirB != null && dirB.position() != 0 ) {
                mesh.setBuffer(VertexBuffer.Type.Size, 1, dirB);
            }
            if( sizeBuffer != null && sizeBuffer.position() != 0 ) {
                sizeBuffer.applyToMesh(mesh, VertexBuffer.Type.Size, 1);
            }
            if( nb != null && nb.position() != 0 ) {
                nb.applyToMesh(mesh, VertexBuffer.Type.Normal, 3);
            }
            if( tb != null && tb.position() != 0 ) {
                tb.applyToMesh(mesh, VertexBuffer.Type.Tangent, 3);
            }
            mesh.setBuffer(VertexBuffer.Type.Color, 4, colors);
            mesh.setStatic();

            // Set the mesh bound based on the collected min/max values from geometry.
            // Do it in a way the subclasses can override until we have material-type-specific
            // strategies to do so.
            setBound(mt, mesh, min, max);

            Geometry geom = new Geometry("mesh:" + mt + ":" + list.primitiveType, mesh);
            Material mat = materials.get(mt.getId());
            if( mat == null ) {
                // Try not to crash at least
                MaterialType bad = new MaterialType("bad", mt.getGeomReqs());
                log.warn("Missed material for:" + mt.getId() + " trying to fall back to:" + bad);
                mat = materials.get(bad.getId());
            }
            if( mat == null ) {
                log.debug("all keys:" + materials.keySet());
                throw new RuntimeException("Materal not found for:" + mt.getId());
            }
            geom.setMaterial(mat);

            if( mt.getLayer() != null ) {
                // Back door into the layer comparator by setting the layer
                // user data optimistically.  On the one hand, this is a bit fragile
                // using a magic word.  On the other hand, it's meaning is obvious,
                // it aligns with Lemur's layer comparator, and it keeps us nicely
                // decoupled from a specific comparator implementation.
                geom.setUserData("layer", mt.getLayer());
            }

            // This is kind of a hack... not sure what the better way is. FIXME: Bucket.Transparent
            BlendMode blendMode = geom.getMaterial().getAdditionalRenderState().getBlendMode();
            if( blendMode == BlendMode.Alpha || blendMode == BlendMode.AlphaAdditive ) {
                log.debug("Putting in transparent bucket:" + geom);
                geom.setQueueBucket(Bucket.Transparent);
            }
            target.attachChild(geom);
        }
    }

    protected void setBound( MaterialType mt, Mesh mesh, Vector3f min, Vector3f max ) {
        mesh.setBound(new BoundingBox(min, max));
    }

    // These are lighting specific methods and classes that could be moved
    // out of this class into separate gradient classes.
    //----------------------------------------------------------------------

    /**
     *  Calculates the average r,g,b,sun value over all of the specified
     *  light bits values.
     */
    private int average( int... lights ) {
        int s = 0;
        int r = 0;
        int g = 0;
        int b = 0;
        int count = 0;
        for( int i : lights ) {
            if( i == LightUtils.SOLID ) {
                continue;
            }
            s += LightUtils.sun(i);
            r += LightUtils.red(i);
            g += LightUtils.green(i);
            b += LightUtils.blue(i);
            count++;
        }
        if( count == 0 ) {
            return 0;
        }
        return LightUtils.toLight(s/count, r/count, g/count, b/count);
    }

    /**
     *  Builds a SmoothLightGradient from the specified light data.
     */
    private LightGradient calculateLightGradient( CellArray cells, CellData lightData ) {
        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();

        CellArray corners = new CellArray(xSize + 1, ySize + 1, zSize + 1);

        for( int x = 0; x <= xSize; x++ ) {
            for( int y = 0; y <= ySize; y++ ) {
                for( int z = 0; z <= zSize; z++ ) {
                    // Rereading this today, I think there is a mismatch between
                    // how I'm building the corners array and how I'm using the
                    // corners array.  I also half-remember that there might be a
                    // clever collapsing that happens here that makes it work.
                    // ...because it does seem to be working.
                    // TODO: refigure out what's going on here and document it.
                    //
                    // Ok, thinking about this again, I think it's a matter of
                    // remembering what the grid coordinate means versus the cell
                    // coordinate.
                    //
                    // aa --- ba --- ca --- da
                    // |      |      |      |
                    // |  AA  |  BA  |  CA  |
                    // |      |      |      |
                    // ab --- bb --- cb --- db
                    // |      |      |      |
                    // |  AB  |  BB  |  CB  |
                    // |      |      |      |
                    // ac --- bc --- cc --- dc
                    //
                    // We are averaging cell values into the shared corners.
                    // So for corner 'bb' we need to sample AA, BA, AB, BB (in 3d)
                    // which is what the code below is doing. x,y,z in 'cell space'
                    // means something slightly different than in 'corner space'.
                    //

                    int l1 = lightData.getCell(x-1, y-1, z-1);
                    int l2 = lightData.getCell(x, y-1, z-1);
                    int l3 = lightData.getCell(x, y, z-1);
                    int l4 = lightData.getCell(x-1, y, z-1);
                    int l5 = lightData.getCell(x-1, y-1, z);
                    int l6 = lightData.getCell(x, y-1, z);
                    int l7 = lightData.getCell(x, y, z);
                    int l8 = lightData.getCell(x-1, y, z);

                    corners.setCell(x, y, z, average(l1, l2, l3, l4, l5, l6, l7, l8));
                }
            }
        }

        return new SmoothLightGradient(corners);
    }

    private interface LightGradient {
        public void appendLight( CellData lights, int i, int j, int k, float x, float y, float z, Direction dir, FloatBuffer colors );
    }

    private class NoLightGradient implements LightGradient {
        CellData lightData;

        public NoLightGradient( CellData lightData ) {
            this.lightData = lightData;
        }

        public void appendLight( CellData lights, int i, int j, int k, float x, float y, float z, Direction dir, FloatBuffer colors ) {

            if( dir != null ) {
                // If it's on the border facing out (most common case) then we need
                // to move our light sampling point.
                switch( dir ) {
                    case North:
                        if( z == 0 ) {
                            k--;
                        }
                        break;
                    case South:
                        if( z == 1 ) {
                            k++;
                        }
                        break;
                    case East:
                        if( x == 1 ) {
                            i++;
                        }
                        break;
                    case West:
                        if( x == 0 ) {
                            i--;
                        }
                        break;
                    case Up:
                        if( y == 1 ) {
                            j++;
                        }
                        break;
                    case Down:
                        if( y == 0 ) {
                            j--;
                        }
                        break;
                }
            }

            int l = lights.getCell(i,j,k, 0xf000);

            int s = (l >> 12) & 0xf;
            int r = (l >> 8) & 0xf;
            int g = (l >> 4) & 0xf;
            int b = (l) & 0xf;

            colors.put(r/15f).put(g/15f).put(b/15f).put(s/15f);
        }
    }

    private class SmoothLightGradient implements LightGradient {
        CellArray corners;

        public SmoothLightGradient( CellArray corners ) {
            this.corners = corners;
        }

        private float interp( float x, float x1, float x2 ) {
            return x1 + (x2 - x1) * x;
        }

        private float bilinearInterp( float x, float y, float nw, float ne, float se, float sw ) {
            float n = interp(x, nw, ne);
            float s = interp(x, sw, se);
            return interp(y, n, s);
        }

        private float trilinearInterp( float x, float y, float z,
                                       float dnw, float dne, float dse, float dsw,
                                       float unw, float une, float use, float usw ) {
            float d = bilinearInterp(x, y, dnw, dne, dse, dsw);
            float u = bilinearInterp(x, y, unw, une, use, usw);
            return interp(z, d, u);
        }

        private float accumToFloat( int accum ) {
            // The accumulator is x 8, so divide by 8 to average it
            int result = accum; // >> 3;
            // Then make it from 0..1
            return result/15f;
        }

        private float accToRed( int spread ) {
            return accumToFloat(LightUtils.red(spread));
        }
        private float accToGreen( int spread ) {
            return accumToFloat(LightUtils.green(spread));
        }
        private float accToBlue( int spread ) {
            return accumToFloat(LightUtils.blue(spread));
        }
        private float accToSun( int spread ) {
            return accumToFloat(LightUtils.sun(spread));
        }

        public void appendLight( CellData lights, int i, int j, int k, float x, float y, float z, Direction dir, FloatBuffer colors ) {

            int dnw = corners.getCell(i, j, k);
            int dne = corners.getCell(i + 1, j, k);
            int dse = corners.getCell(i + 1, j + 1, k);
            int dsw = corners.getCell(i, j + 1, k);
            int unw = corners.getCell(i, j, k+1);
            int une = corners.getCell(i + 1, j, k+1);
            int use = corners.getCell(i + 1, j + 1, k+1);
            int usw = corners.getCell(i, j + 1, k+1);

            float red = trilinearInterp(x, y, z,
                                        accToRed(dnw), accToRed(dne), accToRed(dse), accToRed(dsw),
                                        accToRed(unw), accToRed(une), accToRed(use), accToRed(usw));
            float green = trilinearInterp(x, y, z,
                                        accToGreen(dnw), accToGreen(dne), accToGreen(dse), accToGreen(dsw),
                                        accToGreen(unw), accToGreen(une), accToGreen(use), accToGreen(usw));
            float blue = trilinearInterp(x, y, z,
                                        accToBlue(dnw), accToBlue(dne), accToBlue(dse), accToBlue(dsw),
                                        accToBlue(unw), accToBlue(une), accToBlue(use), accToBlue(usw));
            float sun = trilinearInterp(x, y, z,
                                        accToSun(dnw), accToSun(dne), accToSun(dse), accToSun(dsw),
                                        accToSun(unw), accToSun(une), accToSun(use), accToSun(usw));

            colors.put(red).put(green).put(blue).put(sun);
        }
    }




}




