/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.Objects;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.geom.FluidFactory;


/**
 *  Represents a type of fluid which more generally includes any
 *  fluidic material done as a fluid overlay: water, lava, smoke,
 *  ice, snow, whatever we decide should exist in tandem with partial blocks.
 *
 *  @author    Paul Speed
 */
public class FluidType implements java.io.Serializable {

    static final long serialVersionUID = 42L;

    private FluidName name;
    private FluidFactory factory;

    /**
     *  The 4-bit each red/green/blue/sunlight value imparted by this block.
     *  Usually, 0.
     */
    private short light;

    private FluidType() {
    }

    public FluidType( FluidName name, FluidFactory factory ) {
        this.name = name;
        this.factory = factory;
    }

    public void setName( FluidName name ) {
        this.name = name;
    }

    public final FluidName getName() {
        return name;
    }

    public void setLight( short light ) {
        this.light = light;
    }

    public final short getLight() {
        return light;
    }

    public void setFactory( FluidFactory factory ) {
        this.factory = factory;
    }

    public final FluidFactory getFactory() {
        return factory;
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        FluidType other = (FluidType)o;
        if( other.light != light ) {
            return false;
        }
        if( !Objects.equals(name, other.name) ) {
            return false;
        }
        if( !Objects.equals(factory, other.factory) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, factory, light);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("name", name)
                .add("light", Integer.toHexString(light))
                .add("factory", factory)
                .toString();
    }
}

