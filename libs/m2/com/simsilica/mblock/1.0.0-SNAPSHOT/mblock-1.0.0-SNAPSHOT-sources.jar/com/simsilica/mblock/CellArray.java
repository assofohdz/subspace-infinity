/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.io.Serializable;
import java.util.Arrays;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

/**
 *  A flat-array based implementation of the CellData interface.
 *
 *  @author    Paul Speed
 */
public class CellArray implements CellData, Cloneable, Serializable {

    static final long serialVersionUID = 42L;

    private final int xSize;
    private final int ySize;
    private final int zSize;
    private int[] array;

    public CellArray( int size ) {
        this(size, size, size);
    }

    public CellArray( int xSize, int ySize, int zSize ) {
        this.xSize = xSize;
        this.ySize = ySize;
        this.zSize = zSize;
        array = new int[xSize * ySize * zSize];
    }

    public boolean isClear() {
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    if( array[index(i, j, k)] != 0 ) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     *  Creates a full clone of this CellArray.  Modifications to the
     *  clone's array will not affect the original.
     */
    public CellArray clone() {
        try {
            CellArray clone = (CellArray)super.clone();
            clone.array = new int[array.length];
            System.arraycopy(array, 0, clone.array, 0, array.length);
            return clone;
        } catch( CloneNotSupportedException e ) {
            throw new RuntimeException("Checked exceptions are fun", e);
        }
    }

    public final void clear() {
        Arrays.fill(array, 0);
    }

    public final void clear( int value ) {
        Arrays.fill(array, value);
    }

    public final void set( CellArray cells ) {
        if( cells.xSize != xSize || cells.ySize != ySize || cells.zSize != zSize ) {
            throw new IllegalArgumentException("Cell sizes do not match, this:" + this + " cells:" + cells);
        }
        System.arraycopy(cells.array, 0, array, 0, array.length);
    }

    public final int getSizeX() {
        return xSize;
    }

    public final int getSizeY() {
        return ySize;
    }

    public final int getSizeZ() {
        return zSize;
    }

    public Vec3i getSize() {
        return new Vec3i(xSize, ySize, zSize);
    }

    public final int[] getArray() {
        return array;
    }

    private int index( int x, int y, int z ) {
        // We store things as a sequence of y strips, basically.  This
        // makes it better for run-length encoding and so on.
        // Note: to save my brain later, xSize doesn't appear because
        // it's the 'major' coordinate.  Think if we were just doing
        // x, z... index = x * zSize + z.  xSize doesn't appear.
        // It's the same here: (x * zSize + z) * ySize + y
        // I just wrote it differently.  (I'd change it but this second
        // I'm not 100% sure it wouldn't affect behavior and I don't have
        // time to test it... I'm only 99.999% sure.)
        return (x * ySize * zSize) + (z * ySize) + y;
    }

    @Override
    public final int getCell( int x, int y, int z ) {
        return array[index(x, y, z)];
    }

    @Override
    public final int getCell( int x, int y, int z, int defaultValue ) {
        if( x < 0 || y < 0 || z < 0 ) {
            return defaultValue;
        }
        if( x >= xSize || y >= ySize || z >= zSize ) {
            return defaultValue;
        }
        return getCell(x, y, z);
    }

    @Override
    public final int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    @Override
    public final void setCell( int x, int y, int z, int type ) {
        array[index(x, y, z)] = type;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("xSize", xSize)
                .add("ySize", ySize)
                .add("zSize", zSize)
                .toString();
    }
}
