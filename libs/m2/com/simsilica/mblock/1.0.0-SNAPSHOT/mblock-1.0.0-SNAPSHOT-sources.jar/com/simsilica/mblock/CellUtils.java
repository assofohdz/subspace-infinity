/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.*;

import org.slf4j.*;

import com.google.common.hash.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.geom.BoundaryShape;

/**
 *
 *
 *  @author    Paul Speed
 */
public class CellUtils {

    static Logger log = LoggerFactory.getLogger(CellUtils.class);

    /**
     *  Reprojects the specified CellArray into a new cell array where
     *  the source x axis is projected along the specified xAxis and the source
     *  z axis is projected along the specified zAxis.  This can be used to
     *  rotate or mirror existing cell arrays.
     */
    public static CellArray reproject( CellArray cells, Vec3i xAxis, Vec3i zAxis ) {
        Vec3i size = xAxis.mult(cells.getSizeX()).addLocal(zAxis.mult(cells.getSizeZ()));
        Vec3i start = new Vec3i();
        if( size.x < 0 ) {
            size.x = Math.abs(size.x);
            start.x = size.x-1;
        }
        if( size.z < 0 ) {
            size.z = Math.abs(size.z);
            start.z = size.z-1;
        }
        CellArray result = new CellArray(size.x, cells.getSizeY(), size.z);

        Vec3i pos = new Vec3i();
        for( int i = 0; i < cells.getSizeX(); i++ ) {
            for( int k = 0; k < cells.getSizeZ(); k++ ) {
                pos.set(start).addLocal(xAxis.mult(i));
                pos.addLocal(zAxis.mult(k));
                for( int j = 0; j < cells.getSizeY(); j++ ) {
                    int val = cells.getCell(i, j, k);
                    int type = MaskUtils.getType(val);
                    result.setCell(pos.x, j, pos.z, type);
                }
            }
        }

        MaskUtils.calculateSideMasks(result);

        return result;
    }

    public static void copy( CellArray src, int xSource, int ySource, int zSource,
                             CellArray dest, int xTarget, int yTarget, int zTarget,
                             int xSize, int ySize, int zSize ) {

        if( log.isTraceEnabled() ) {
            log.trace("copy(" + src + ", " + xSource + ", " + ySource + ", " + zSource + ", "
                 + dest + ", " + xTarget + ", " + yTarget + ", " + zTarget + ", "
                 + xSize + ", " + ySize + ", " + zSize);
        }
        if( xSource + xSize > src.getSizeX()
            || ySource + ySize > src.getSizeY()
            || zSource + zSize > src.getSizeZ() ) {
            throw new IllegalArgumentException("Source overflow");
        }
        if( xTarget + xSize > dest.getSizeX()
            || yTarget + ySize > dest.getSizeY()
            || zTarget + zSize > dest.getSizeZ() ) {
            throw new IllegalArgumentException("Destination overflow");
        }
        copyData(src, xSource, ySource, zSource,
                 dest, xTarget, yTarget, zTarget,
                 xSize, ySize, zSize);
    }

    public static void copyData( CellData src, int xSource, int ySource, int zSource,
                                 CellData dest, int xTarget, int yTarget, int zTarget,
                                 int xSize, int ySize, int zSize ) {

        if( log.isTraceEnabled() ) {
            log.trace("copy(" + src + ", " + xSource + ", " + ySource + ", " + zSource + ", "
                 + dest + ", " + xTarget + ", " + yTarget + ", " + zTarget + ", "
                 + xSize + ", " + ySize + ", " + zSize);
        }
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int value = src.getCell(xSource + i, ySource + j, zSource + k);
                    dest.setCell(xTarget + i, yTarget + j, zTarget + k, value);
                }
            }
        }
    }

    public static void copy( CellArray src, int xSource, int ySource, int zSource,
                             CellArray dest, int xTarget, int yTarget, int zTarget,
                             int xSize, int ySize, int zSize,
                             IntCombiner typeCombiner ) {

        if( log.isTraceEnabled() ) {
            log.trace("copy(" + src + ", " + xSource + ", " + ySource + ", " + zSource + ", "
                 + dest + ", " + xTarget + ", " + yTarget + ", " + zTarget + ", "
                 + xSize + ", " + ySize + ", " + zSize + ", " + typeCombiner + ")");
        }
        if( xSource + xSize > src.getSizeX()
            || ySource + ySize > src.getSizeY()
            || zSource + zSize > src.getSizeZ() ) {
            throw new IllegalArgumentException("Source overflow");
        }
        if( xTarget + xSize > dest.getSizeX()
            || yTarget + ySize > dest.getSizeY()
            || zTarget + zSize > dest.getSizeZ() ) {
            throw new IllegalArgumentException("Destination overflow");
        }
        copyData(src, xSource, ySource, zSource,
                 dest, xTarget, yTarget, zTarget,
                 xSize, ySize, zSize, typeCombiner);
    }

    public static void copyData( CellData src, int xSource, int ySource, int zSource,
                                 CellData dest, int xTarget, int yTarget, int zTarget,
                                 int xSize, int ySize, int zSize,
                                 IntCombiner typeCombiner ) {

        if( log.isTraceEnabled() ) {
            log.trace("copy(" + src + ", " + xSource + ", " + ySource + ", " + zSource + ", "
                 + dest + ", " + xTarget + ", " + yTarget + ", " + zTarget + ", "
                 + xSize + ", " + ySize + ", " + zSize + ", " + typeCombiner + ")");
        }
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int value = src.getCell(xSource + i, ySource + j, zSource + k);
                    int existing = dest.getCell(xTarget + i, yTarget + j, zTarget + k);
                    dest.setCell(xTarget + i, yTarget + j, zTarget + k, typeCombiner.apply(value, existing));
                }
            }
        }
    }

    public static CellArray trim( CellArray cells, int x, int y, int z, int xSize, int ySize, int zSize ) {
        CellArray result = new CellArray(xSize, ySize, zSize);
        copy(cells, x, y, z, result, 0, 0, 0, xSize, ySize, zSize);
        return result;
    }

    public static Vec3i[] calculateSize( CellArray cells ) {
        Vec3i min = new Vec3i(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE);
        Vec3i max = new Vec3i(0,0,0);

        int xSize = cells.getSizeX();
        int ySize = cells.getSizeY();
        int zSize = cells.getSizeZ();
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int val = cells.getCell(i, j, k);
                    if( val == 0 ) {
                        continue;
                    }
                    min = min.minLocal(i, j, k);
                    max = max.maxLocal(i, j, k);
                }
            }
        }
        // Handle the empty case
        min.minLocal(max);

        return new Vec3i[] { min, max };
    }

    public static String hashString( CellData cells, int x, int y, int z, int xSize, int ySize, int zSize ) {
        return hashString(null, cells, x, y, z, xSize, ySize, zSize);
    }

    public static String hashString( String salt, CellData cells, int x, int y, int z, int xSize, int ySize, int zSize ) {
        //Hasher hasher = Hashing.sha256().newHasher();
        Hasher hasher = Hashing.crc32().newHasher();
        if( salt != null ) {
            hasher.putUnencodedChars(salt);
        }
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int type = MaskUtils.getType(cells.getCell(x + i, y + j, z + k));
                    hasher.putInt(type);
                }
            }
        }

        StringBuilder result = new StringBuilder();

        // Improve the uniqueness of the hash by including the size
        // But we'll format it to make sure it has a consistent length
        result.append(String.format("%02x%02x%02x", xSize, ySize, zSize));
        result.append(hasher.hash().toString());

        return result.toString();
    }

    public static byte[] hash( CellData cells, int x, int y, int z, int xSize, int ySize, int zSize ) {
        return hash(null, cells, x, y, z, xSize, ySize, zSize);
    }

    public static byte[] hash( String salt, CellData cells, int x, int y, int z, int xSize, int ySize, int zSize ) {
        //Hasher hasher = Hashing.sha256().newHasher();
        Hasher hasher = Hashing.crc32().newHasher();
        if( salt != null ) {
            hasher.putUnencodedChars(salt);
        }
        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                for( int k = 0; k < zSize; k++ ) {
                    int type = MaskUtils.getType(cells.getCell(x + i, y + j, z + k));
                    hasher.putInt(type);
                }
            }
        }

        byte[] bytes = hasher.hash().asBytes();
        byte[] result = new byte[bytes.length + 3];
        result[0] = (byte)xSize;
        result[1] = (byte)ySize;
        result[2] = (byte)zSize;

        System.arraycopy(bytes, 0, result, 3, bytes.length);
        return result;
    }

    public static int getTypeRotation( int type, int rotate ) {
        BlockType start = BlockTypeIndex.get(type);
        if( start == null ) {
            return type;
        }
        BlockName name = start.getName();
        if( name.getRotation() == null ) {
            // There is no rotation
            return type;
        }
        // See if there is a rotated name
        BlockName find = name.rotate(rotate);
        int index = BlockTypeIndex.findType(find, -1);
        if( index >= 0 ) {
            return index;
        }

        // Else try to see if it's only a two position rotation
        find = name.rotate(rotate, 2);
        index = BlockTypeIndex.findType(find, -1);
        if( index >= 0 ) {
            return index;
        }

        // No rotation, just return the original and hope for the best
        return type;
    }

    public static int getTypeMirrorX( int type ) {
        // This is actually hard... we need to know block symmetry for
        // this to work.  I guess we can figure it out from the sides
        // but what a pain...  Definitely need to preindex this stuff.
        BlockType start = BlockTypeIndex.get(type);
        if( start == null ) {
            return type;
        }
        BlockName name = start.getName();
        if( name.getRotation() == null ) {
            // There is no rotation
            return type;
        }

        BoundaryShape negative = start.getShape(Direction.West);
        BoundaryShape positive = start.getShape(Direction.East);
        if( positive.isMatchingFace(negative) ) {
            // Symmetrical for our purposes... at least I hope so.
            return type;
        }

        // 2022-03-27 - Testing the west/east sides alone isn't enough
        // because for cases like "angle" blocks we have two possible
        // matching rotations when just considering those sides.  We
        // need to also check the reflected north/side sides to make
        // sure they match also.  And now we can be even _more_ sure
        // that we'll want to cache these relationships.
        // Note that a reflection of the boundary shapes is a 180
        // degree rotation because of how we project them onto the axis.
        BoundaryShape alt1 = start.getShape(Direction.North).rotate(Direction.North, 2);
        BoundaryShape alt2 = start.getShape(Direction.South).rotate(Direction.South, 2);

        // Find a rotation where one the boundary shapes match
        for( int i = 1; i <= 3; i++ ) {
            int newType = getTypeRotation(type, i);
            BlockType bt = BlockTypeIndex.get(newType);
            // We check instance != also because otherwise NULL_SHAPE to NULL_SHAPE won't match
            // FIXME: simplify if we fix NULL_SHAPE isMatchingFace
            if( alt1 != bt.getShape(Direction.North) && !alt1.isMatchingFace(bt.getShape(Direction.North)) ) {
                continue;
            }
            if( alt2 != bt.getShape(Direction.South) && !alt2.isMatchingFace(bt.getShape(Direction.South)) ) {
                continue;
            }
            // Need to do a similar check here or null faces east/west won't match... like for the
            // hollow wedges.
            if( negative == bt.getShape(Direction.East) || negative.isMatchingFace(bt.getShape(Direction.East)) ) {
                return newType;
            }
            if( positive == bt.getShape(Direction.West) || positive.isMatchingFace(bt.getShape(Direction.West)) ) {
                return newType;
            }
        }
        return type;
    }

    public static int getTypeMirrorZ( int type ) {
        // This is actually hard... we need to know block symmetry for
        // this to work.  I guess we can figure it out from the sides
        // but what a pain...  Definitely need to preindex this stuff.
        BlockType start = BlockTypeIndex.get(type);
        if( start == null ) {
            return type;
        }
        BlockName name = start.getName();
        if( name.getRotation() == null ) {
            // There is no rotation
            return type;
        }
        BoundaryShape negative = start.getShape(Direction.North);
        BoundaryShape positive = start.getShape(Direction.South);
        if( positive.isMatchingFace(negative) ) {
            // Symmetrical for our purposes... at least I hope so.
            return type;
        }

        BoundaryShape alt1 = start.getShape(Direction.East).rotate(Direction.East, 2);
        BoundaryShape alt2 = start.getShape(Direction.West).rotate(Direction.West, 2);

        // Find a rotation where one the boundary shapes match
        for( int i = 1; i <= 3; i++ ) {
            int newType = getTypeRotation(type, i);
            BlockType bt = BlockTypeIndex.get(newType);
            // We check instance != also because otherwise NULL_SHAPE to NULL_SHAPE won't match
            // FIXME: simplify if we fix NULL_SHAPE isMatchingFace
            if( alt1 != bt.getShape(Direction.East) && !alt1.isMatchingFace(bt.getShape(Direction.East)) ) {
                continue;
            }
            if( alt2 != bt.getShape(Direction.West) && !alt2.isMatchingFace(bt.getShape(Direction.West)) ) {
                continue;
            }
            if( negative == bt.getShape(Direction.South) || negative.isMatchingFace(bt.getShape(Direction.South)) ) {
                return newType;
            }
            if( positive == bt.getShape(Direction.North) || positive.isMatchingFace(bt.getShape(Direction.North)) ) {
                return newType;
            }
        }
        return type;
    }

    public static CellArray rotate( CellArray cells, int rotate ) {
        rotate = rotate % 4;
        if( rotate < 0 ) {
            rotate += 4;
        }

        Vec3i xAxis = Direction.East.rotate(rotate).getVec3i();
        Vec3i zAxis = Direction.South.rotate(rotate).getVec3i();

        // First just reproject it
        CellArray results = reproject(cells, xAxis, zAxis);

        // Then rotate the block types to match
        Map<Integer, Integer> remap = new HashMap<>();
        int[] array = results.getArray();
        for( int i = 0; i < array.length; i++ ) {
            int val = array[i];
            int type = MaskUtils.getType(val);
            Integer newType = remap.get(type);
            if( newType == null ) {
                newType = getTypeRotation(type, rotate);
                remap.put(type, newType);
            }
            array[i] = newType;
        }

        return results;
    }

    public static CellArray mirrorX( CellArray cells ) {
        Vec3i xAxis = new Vec3i(-1, 0, 0);
        Vec3i zAxis = new Vec3i(0, 0, 1);

        // First just reproject it
        CellArray results = reproject(cells, xAxis, zAxis);

        // Then rotate the block types to match
        Map<Integer, Integer> remap = new HashMap<>();
        int[] array = results.getArray();
        for( int i = 0; i < array.length; i++ ) {
            int val = array[i];
            int type = MaskUtils.getType(val);
            Integer newType = remap.get(type);
            if( newType == null ) {
                newType = getTypeMirrorX(type);
                remap.put(type, newType);
            }
            array[i] = newType;
        }

        return results;
    }

    public static CellArray mirrorZ( CellArray cells ) {
        Vec3i xAxis = new Vec3i(1, 0, 0);
        Vec3i zAxis = new Vec3i(0, 0, -1);

        // First just reproject it
        CellArray results = reproject(cells, xAxis, zAxis);

        // Then rotate the block types to match
        Map<Integer, Integer> remap = new HashMap<>();
        int[] array = results.getArray();
        for( int i = 0; i < array.length; i++ ) {
            int val = array[i];
            int type = MaskUtils.getType(val);
            Integer newType = remap.get(type);
            if( newType == null ) {
                newType = getTypeMirrorZ(type);
                remap.put(type, newType);
            }
            array[i] = newType;
        }

        return results;
    }
}
