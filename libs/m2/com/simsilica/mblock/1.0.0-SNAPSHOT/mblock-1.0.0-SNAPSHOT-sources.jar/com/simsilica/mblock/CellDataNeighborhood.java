/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import org.slf4j.*;

import com.simsilica.mathd.*;

/**
 *  A 3D array of CellData children such that they can be accessed
 *  in the space of the center block.
 *
 *  @author    Paul Speed
 */
public class CellDataNeighborhood implements CellData {
    static Logger log = LoggerFactory.getLogger(CellDataNeighborhood.class);
 
    private int radius;
    private int size;
    private int xArraySize;
    private int yArraySize;
    private int zArraySize;
    private CellData center;
    private CellData[][][] neighborhood;
    
    public CellDataNeighborhood( CellData center, Vec3i cellDataSize, int radius ) {
        this.radius = radius;
        this.size = 1 + radius * 2;
        this.neighborhood = new CellData[size][size][size];
        this.center = center;
        neighborhood[radius][radius][radius] = center;
        xArraySize = cellDataSize.x;
        yArraySize = cellDataSize.y;
        zArraySize = cellDataSize.z;
    }
    
    public void setCellData( int xOffset, int yOffset, int zOffset, CellData array ) {
        neighborhood[radius + xOffset][radius + yOffset][radius + zOffset] = array;
    }
    
    public CellData getCellData( int xOffset, int yOffset, int zOffset ) {
        return neighborhood[radius + xOffset][radius + yOffset][radius + zOffset];
    }
 
    @Override
    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, 0);
    }
        
    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        int xArray = radius;
        int yArray = radius;
        int zArray = radius;
        if( x < 0 ) {
            xArray = xArray + (int)(Math.floor(x / xArraySize));
            x = xArraySize + (x % xArraySize); 
        } else if( x >= xArraySize ) {
            xArray = xArray + (int)(Math.floor(x / xArraySize));
            x = x % xArraySize;
        }
        if( xArray < 0 || xArray >= size ) {
            return defaultValue;
        }
        if( y < 0 ) {
            yArray = yArray + (int)(Math.floor(y / yArraySize));
            y = yArraySize + (y % yArraySize); 
        } else if( y >= yArraySize ) {
            yArray = yArray + (int)(Math.floor(y / yArraySize));
            y = y % yArraySize;
        }
        if( yArray < 0 || yArray >= size ) {
            return defaultValue;
        }
        if( z < 0 ) {
            zArray = zArray + (int)(Math.floor(z / zArraySize));
            z = zArraySize + (z % zArraySize); 
        } else if( z >= zArraySize ) {
            zArray = zArray + (int)(Math.floor(z / zArraySize));
            z = z % zArraySize;
        }
        if( zArray < 0 || zArray >= size ) {
            return defaultValue;
        }
        CellData array = neighborhood[xArray][yArray][zArray];
        if( array == null ) {
            return defaultValue;
        }
        return array.getCell(x, y, z);
    }
        
    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);        
    }
        
    @Override
    public void setCell( int x, int y, int z, int type ) {
        int xArray = radius;
        int yArray = radius;
        int zArray = radius;
        if( x < 0 ) {
            xArray = xArray + (int)(Math.floor(x / xArraySize));
            x = xArraySize + (x % xArraySize); 
        } else if( x >= xArraySize ) {
            xArray = xArray + (int)(Math.floor(x / xArraySize));
            x = x % xArraySize;
        }
        if( xArray < 0 || xArray >= size ) {
            throw new IllegalArgumentException("x out of bounds");
        }
        if( y < 0 ) {
            yArray = yArray + (int)(Math.floor(y / yArraySize));
            y = yArraySize + (y % yArraySize); 
        } else if( y >= yArraySize ) {
            yArray = yArray + (int)(Math.floor(y / yArraySize));
            y = y % yArraySize;
        }
        if( yArray < 0 || yArray >= size ) {
            throw new IllegalArgumentException("y out of bounds");
        }
        if( z < 0 ) {
            zArray = zArray + (int)(Math.floor(z / zArraySize));
            z = zArraySize + (z % zArraySize); 
        } else if( z >= zArraySize ) {
            zArray = zArray + (int)(Math.floor(z / zArraySize));
            z = z % zArraySize;
        }
        if( zArray < 0 || zArray >= size ) {
            throw new IllegalArgumentException("z out of bounds");
        }
        CellData array = neighborhood[xArray][yArray][zArray];
        if( array == null ) {
            throw new IllegalArgumentException("x,y,z not loaded");
        }
        array.setCell(x, y, z, type);
    }
}
