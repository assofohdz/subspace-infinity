/*
 * $Id$
 * 
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;


/**
 *  A basic base class for GeomPartBuffer implementations that
 *  simply groups parts together by primitive type and material type.
 *  Subclasses can use the internal structures to generate geometry, etc..
 *
 *  @author    Paul Speed
 */
public class DefaultPartBuffer implements GeomPartBuffer {
 
    static Logger log = LoggerFactory.getLogger(DefaultPartBuffer.class);
    
    /**
     *  The index of part lists by material type and primitive type.
     */
    private Map<PartKey, PartList> parts = new HashMap<>();
 
    private long seed = 0;   
    private Random random = new Random(seed);
    
    public DefaultPartBuffer() {
    }
    
    public Collection<PartList> getPartLists() {
        return parts.values();
    }
    
    public void setRandomSeed( long seed ) {
        this.seed = seed;
        if( parts.isEmpty() ) {
            random.setSeed(seed);
        }
    }
    
    public long getRandomSeed() {
        return seed;
    }
    
    public double nextRandom() {
        return random.nextDouble();
    }
 
    protected PartKey getKey( MaterialType materialType, PrimitiveType type ) {
        return new PartKey(materialType, type); //materialType.getId() | (type.ordinal() << 24);
    } 

    protected PartList getList( MaterialType materialType, PrimitiveType type, boolean create ) {
        PartKey key = getKey(materialType, type);
        PartList list = parts.get(key);
        if( list == null && create ) {
            list = new PartList(materialType, type);
            parts.put(key, list);
        }
        return list;
    }
    
    public void addPart( int i, int j, int k, GeomPart part ) {
//log.info("addPart(" + i + ", " + j + ", " + k + ") mat:" + part.getMaterialType().getName());    
        PartList list = getList(part.getMaterialType(), part.getPrimitiveType(), true);
        list.add(i, j, k, part);
    }
     
    /**
     *  Clears any stored part information and resets the random number 
     *  generator.
     */
    public void clear() {
        parts.clear();
        random.setSeed(seed);
    }   

    /**
     *  A single part at a specific location.
     */
    public static class PartEntry {
        public int i,j,k;
        public GeomPart part;

        public PartEntry( int i, int j, int k, GeomPart part ) {
            this.i = i;
            this.j = j;
            this.k = k;
            this.part = part;
        }
    }

    public static class PartList {
        public MaterialType materialType;
        public PrimitiveType primitiveType;
        public List<PartEntry> list = new ArrayList<>();
        
        public int vertCount;
        public int triCount;
         
        // booleans used to make sure the list stays homogenous
        public boolean requiresFloatTexCoords;
        
        public PartList( MaterialType materialType, PrimitiveType primitiveType ) {
            this.materialType = materialType;
            this.primitiveType = primitiveType;
        }
        
        public void add( int i, int j, int k, GeomPart part ) {
            assert materialType.assertValid(part);
            //if( !materialType.isValid(part) ) {
            //    throw new IllegalArgumentException(part + " is not valid for:" + materialType);
            //}
            // I think this will be covered by the material type reqs now
            //if( part.requiresFloatTexCoords() ) {
            //    if( !list.isEmpty() && !requiresFloatTexCoords ) {
            //        throw new RuntimeException("Part requires float texCoords but the rest of part list does not, type:" 
            //                                    + materialType + ", part:" + part);
            //    }
            //    requiresFloatTexCoords = true;
            //} else if( requiresFloatTexCoords ) {
            //    throw new RuntimeException("Part does not require float texCoords but the rest of part list does, type:" 
            //                                + materialType + ", part:" + part);
            //}
            
            list.add(new PartEntry(i, j, k, part));

            // update our stats
            vertCount += part.getVertexCount();
            triCount += part.getTriangleCount();
        }
        
        @Override   
        public String toString() {
            return MoreObjects.toStringHelper(getClass().getSimpleName())
                    .add("materialType", materialType)
                    .add("primitiveType", primitiveType)
                    .add("vertCount", vertCount)
                    .add("triCount", triCount)
                    .add("requiresFloatTexCoords", requiresFloatTexCoords)
                    .toString();
        }   
    }
    
    private static class PartKey {
        MaterialType material;
        PrimitiveType primitive;
        
        public PartKey( MaterialType material, PrimitiveType primitive ) {
            this.material = material;
            this.primitive = primitive;
        }
        
        public int hashCode() {
            return Objects.hash(material, primitive);
        }
        
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            PartKey other = (PartKey)o;
            if( !Objects.equals(other.material, material) ) {
                return false;
            }
            return other.primitive == primitive;
        }        
    }        
}


