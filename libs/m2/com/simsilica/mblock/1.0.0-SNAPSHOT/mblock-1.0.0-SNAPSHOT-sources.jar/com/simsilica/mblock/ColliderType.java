/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.Objects;
import com.google.common.base.MoreObjects;

/**
 *  An abstract representation of a collider that a physics collision
 *  system could use to resolve the implementation-specific collider.
 *
 *  @author    Paul Speed
 */
public class ColliderType implements java.io.Serializable {

    static final long serialVersionUID = 42L;

    private String name;
    private int rotation;  // 0-4 for cardinal rotation, -1 if type has no special rotation
    
    public ColliderType( String name, int rotation ) {
        this.name = name;
        this.rotation = rotation;
    }
    
    public void setName( String name ) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
 
    public String toDisplay() {
        if( rotation < 0 ) {
            return name;
        }
        return name + ":" + (rotation * 90);
    }
 
    public ColliderType rotate( int dirDelta ) {
        if( rotation < 0 ) {
            // No difference for rotations
            return this;
        }
        if( dirDelta < 0 || dirDelta > 3 ) {
            throw new IllegalArgumentException("dirDelta is out of bounds:" + dirDelta);
        }
        return new ColliderType(name, (rotation + dirDelta) % 4); 
    }
 
    public void setRotation( int rotation ) {
        this.rotation = rotation;
    }
    
    public int getRotation() {
        return rotation;
    }
 
    public int hashCode() {
        return Objects.hash(name, rotation);
    }
    
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        ColliderType other = (ColliderType)o;
        if( other.rotation != rotation ) {
            return false;
        } 
        return Objects.equals(other.name, name);
    }
 
    @Override   
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("name", name)
            .add("rotation", rotation)
            .toString();
    }   
}
