/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import com.simsilica.mathd.Vec3d;
import com.simsilica.mathd.Vec3i;
import com.simsilica.mathd.Quatd;

/**
 *
 *
 *  @author    Paul Speed
 */
public enum Direction {
    // Note that 'direction indexed' code relies on the ordinal values
    // of these so the order should never change.
    North(new Vec3i(0, 0, -1), new Vec3i(1, 0, 0), new Vec3i(0, 1, 0), 0, Axis.Z, DirectionMasks.NORTH_MASK),
    South(new Vec3i(0, 0, 1), new Vec3i(-1, 0, 0), new Vec3i(0, 1, 0), 2, Axis.Z, DirectionMasks.SOUTH_MASK),
    East(new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(0, 1, 0), 1, Axis.X, DirectionMasks.EAST_MASK),
    West(new Vec3i(-1, 0, 0), new Vec3i(0, 0, -1), new Vec3i(0, 1, 0), 3, Axis.X, DirectionMasks.WEST_MASK),
    Up(new Vec3i(0, 1, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), -1, Axis.Y, DirectionMasks.UP_MASK),
    Down(new Vec3i(0, -1, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, -1), -1, Axis.Y, DirectionMasks.DOWN_MASK);

    private Axis axis;
    private int cardinalDir;
    private int dirMask;
    private Vec3i vec3i;
    private Vec3i right;
    private Vec3i up;

    private static Direction[] cardinalDirections = new Direction[] { North, East, South, West };

    // Note: for whatever reason, the fromAngles(0, y, 0) seems to be wired
    // for + going counter-clockwise.  To me this doesn't really make sense
    // when x goes right and z goes 'down' when looked at from above, ie: the
    // axes are inverted from our normal trig cartesian plane.
    // Either way, we want our dir-based rotation to be clockwise.
    private static final Quatd[] ROT = new Quatd[] {
            new Quatd().fromAngles(0, 0, 0),
            new Quatd().fromAngles(0, -Math.PI * 0.5, 0),
            new Quatd().fromAngles(0, -Math.PI, 0),
            new Quatd().fromAngles(0, -Math.PI * 1.5, 0)
        };

    private Direction( Vec3i vec3i, Vec3i right, Vec3i up, int cardinalDir, Axis axis, int dirMask ) {
        this.vec3i = vec3i;
        this.right = right;
        this.up = up;
        this.cardinalDir = cardinalDir;
        this.axis = axis;
        this.dirMask = dirMask;
    }

    /**
     *  Returns the vec3i representing the direction vector if this
     *  direction.
     */
    public Vec3i getVec3i() {
        return vec3i;
    }

    /**
     *  Returns the vec3i representing the right-axis relative to the direction.
     */
    public Vec3i getRight() {
        return right;
    }

    /**
     *  Returns the vec3i representing the up-axis relative to the direction.
     */
    public Vec3i getUp() {
        return up;
    }

    /**
     *  Returns a unique bit mask for this direction.
     */
    public int getBitMask() {
        return dirMask;
    }

    /**
     *  Return this direction's axis.
     */
    public Axis getAxis() {
        return axis;
    }

    /**
     *  Returns this direction's cardinal direction as an index
     *  relative to North where dir * 90 is one of the cardinal degrees
     *  North = 0, East = 1, South = 2, West = 3.
     */
    public int getCardinalDirection() {
        return cardinalDir;
    }

    /**
     *  Returns the opposite direction.
     */
    public Direction reverse() {
        switch( this ) {
            case North:
                return Direction.South;
            case South:
                return Direction.North;
            case East:
                return Direction.West;
            case West:
                return Direction.East;
            case Up:
                return Direction.Down;
            case Down:
                return Direction.Up;
            default:
                throw new UnsupportedOperationException("Unhandled type:" + this);
        }
    }

    public boolean isCardinal() {
        // An ordinal check should be enough
        return ordinal() < 4;
    }

    /**
     *  Returns one of the four cardinal directions in sequence
     *  where 0 is North and 3 is West.
     */
    public static Direction cardinalDirection( int d ) {
        return cardinalDirections[d];
    }

    /**
     *  Rotates clockwise around the compass rose relative to this
     *  direction the specified number of hops..  If this direction
     *  is either up or down then it is returned directly.
     */
    public Direction rotate( int dirDelta ) {
        if( this == Up || this == Down ) {
            return this;
        }

        int d = (cardinalDir + dirDelta) % 4;
        if( d < 0 ) {
            d += 4;
        }
        return cardinalDirections[d];
    }

    /**
     *  Returns a quaternion representing the specified dirDelta
     *  rotation.
     */
    public static Quatd getRotation( int dirDelta ) {
        if( dirDelta < 0 ) {
            dirDelta = (dirDelta % ROT.length) + ROT.length;
        }
        return ROT[dirDelta % ROT.length];
    }
 
    /**
     *  Returns true if the specified Vec3d closely matches this direction
     *  within a small margin of error.
     */   
    public boolean matches( Vec3d dir ) {
        return matches(dir, 0.001);
    }
    
    /**
     *  Returns true if the specified Vec3d closely matches this direction
     *  within a small margin of error specified by epsilon.
     */   
    public boolean matches( Vec3d dir, double epsilon ) {
        if( Math.abs(dir.x - vec3i.x) > epsilon ) {
            return false;
        }
        if( Math.abs(dir.y - vec3i.y) > epsilon ) {
            return false;
        }
        if( Math.abs(dir.z - vec3i.z) > epsilon ) {
            return false;
        }
        return true;
    }
    
    /**
     *  Finds the Direction that most closely matches the specified
     *  Vec3d direction vector.
     */
    public static Direction findDirection( Vec3d dir, double epsilon ) {
        if( Direction.North.matches(dir, epsilon) ) {
            return Direction.North;
        }
        if( Direction.South.matches(dir, epsilon) ) {
            return Direction.South;
        }
        if( Direction.East.matches(dir, epsilon) ) {
            return Direction.East;
        }
        if( Direction.West.matches(dir, epsilon) ) {
            return Direction.West;
        }
        if( Direction.Up.matches(dir, epsilon) ) {
            return Direction.Up;
        }
        if( Direction.Down.matches(dir, epsilon) ) {
            return Direction.Down;
        }
        return null;
    }        
}


