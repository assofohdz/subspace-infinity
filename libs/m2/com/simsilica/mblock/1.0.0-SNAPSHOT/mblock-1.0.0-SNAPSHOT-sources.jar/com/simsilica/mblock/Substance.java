/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import org.slf4j.*;

import java.util.Objects;
import com.google.common.base.MoreObjects;

/**
 *  Represents the amount of a particular substance name.
 *
 *  @author    Paul Speed
 */
public class Substance implements java.io.Serializable {

    static final long serialVersionUID = 42L;

    static Logger log = LoggerFactory.getLogger(Substance.class);

    private SubstanceName name;
    private double amount;

    private Substance() {
    }

    public Substance( String name, double amount ) {
        this(new SubstanceName(name), amount);
    }

    public Substance( SubstanceName name, double amount ) {
        this.name = name;
        this.amount = amount;
    }

    public void setName( SubstanceName name ) {
        this.name = name;
    }

    public SubstanceName getName() {
        return name;
    }

    public void setAmount( double amount ) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public int hashCode() {
        return Objects.hash(name, amount);
    }

    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        Substance other = (Substance)o;
        if( !Objects.equals(other.name, name) ) {
            return false;
        }
        if( Math.abs(other.amount - amount) > 0.0000001 ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("name", name)
            .add("amount", amount)
            .toString();
    }
}
