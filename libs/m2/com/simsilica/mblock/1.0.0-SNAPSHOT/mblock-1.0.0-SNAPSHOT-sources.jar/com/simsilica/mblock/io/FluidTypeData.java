/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Charsets;

import com.simsilica.mblock.FluidName;
import com.simsilica.mblock.FluidType;

/**
 *  Holds the FluidType[] array and any meta-data for a fluid set. 
 *
 *  @author    Paul Speed
 */
public class FluidTypeData implements UpdateableData<FluidTypeData> {

    public static final long formatVersion = 42L; 

    static Logger log = LoggerFactory.getLogger(FluidTypeData.class);

    public FluidType[] types;    
    
    public FluidTypeData() {
    }
 
    public FluidTypeData( FluidType[] types ) {
        this.types = types;
    }    
 
    @Override  
    public boolean update( FluidTypeData update ) {
        // See if they are the same... because then we don't have to do
        // anything
        if( Arrays.asList(types).equals(Arrays.asList(update.types)) ) {
            return false;
        }        
        // Something has changed
        
        // Note: right now because FluidType (and related classes) don't
        // really implement .equals(), this will always upgrade the fluidset
        // every time.  I'm ok with that today.  2021-01-16... copied from BlockTypeData, 
        // I'm still ok with it.
        
        Map<FluidName, FluidType> index = new HashMap<>();
        for( FluidType type : types ) {
            if( type == null ) {
                continue;
            }
            index.put(type.getName(), type);
        }
        
        List<FluidType> newTypes = new ArrayList<>(Arrays.asList(types));
        for( FluidType type : update.types ) {
            if( type == null ) {
                continue;
            }
            FluidType existing = index.get(type.getName());
            if( existing == null ) {
                log.info("New type:" + type.getName());
                newTypes.add(type);
                index.put(type.getName(), type);
            } else if( !Objects.equals(type, existing) ) {
                log.info("Replacing:" + existing.getName());
                int i = newTypes.indexOf(existing);
                if( i < 0 ) {
                    throw new RuntimeException("Data format error: "
                                               + "existing fluid type not found in type list, type:" 
                                               + existing.getName());
                }
                newTypes.set(i, type);
                index.put(type.getName(), type);
            }
        }
        
        this.types = newTypes.toArray(new FluidType[0]);
        
        return true;
    }

    public static FluidTypeData load( InputStream rawIn ) throws IOException {
        try( ObjectInputStream in = new ObjectInputStream(rawIn) ) {
            FluidTypeData result = new FluidTypeData();
            long version = in.readLong();
            try {
                result.types = (FluidType[])in.readObject();                
            } catch( ClassNotFoundException e ) {
                throw new IOException("Error resolving types", e);
            }
            
            return result;
        }   
    }
    
    public static FluidTypeData load( String resource ) throws IOException {
        java.net.URL u = FluidTypeData.class.getResource(resource);
        if( u == null ) {
            // Could try the context class loader
            return null;
        }
        return load(u.openStream());
    }
    
    public static FluidTypeData load( File f ) throws IOException {
        if( !f.exists() ) {
            return null;
        }
        return load(new FileInputStream(f));
    }

    public static void store( FluidTypeData data, File f ) throws IOException {
        store(data, new FileOutputStream(f));
    }
    
    public static void store( FluidTypeData data, OutputStream rawOut ) throws IOException {
        // Doesn't need to be particularly fast so we
        // want bother wrapping in a buffered stream.  Caller
        // can always do it if it's performance criticial.
        try( ObjectOutputStream out = new ObjectOutputStream(rawOut) ) {
            out.writeLong(formatVersion);
            out.writeObject(data.types);
        }
    }
    
    /**
     *  Writes a text-based index file where each fluid type is represented
     *  as an index value followed by its fluid name. Like: [0] foo:bar.0
     *  This can potentially be used to reconstruct a world's fluid set
     *  if the world's fset file is unreadable for some reason.
     */
    public void writeIndex( File f ) throws IOException {
        FileOutputStream fOut = new FileOutputStream(f);
        try( PrintWriter out = new PrintWriter(new OutputStreamWriter(fOut,Charsets.UTF_8)) ) {
            out.println("# Generated:" + String.format("%1$tF %1$tT", new Date()));
            for( int i = 0; i < types.length; i++ ) {
                FluidType type = types[i];
                if( type == null ) {
                    continue;
                }
                out.println("[" + i + "] " + type.getName());
            }
        } 
    }  
}

