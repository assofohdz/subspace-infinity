/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.config;

import java.io.Serializable;

import com.google.common.base.MoreObjects;

import com.jme3.asset.AssetManager;
import com.jme3.asset.TextureKey;
import com.jme3.texture.Texture;
import com.jme3.texture.Texture.MagFilter;
import com.jme3.texture.Texture.MinFilter;

/**
 *  The parameters necessary to find and load a texture.
 *
 *  @author    Paul Speed
 */
public class TextureConfig implements Serializable {

    static final long serialVersionUID = 42L;

    private String path;
    private boolean wrapS = true;
    private boolean wrapT = true;
    private boolean generateMips = true;
    private boolean flipY = true; // the JME default
    private Integer anisotropy;
    private MinFilter minFilter;
    private MagFilter magFilter;

    public TextureConfig() {
        this("Textures/bad.jpg");
    }

    public TextureConfig( String path ) {
        this(path, true, true, true);
    }

    public TextureConfig( String path, boolean wrapS, boolean wrapT, boolean generateMips ) {
        this.path = path;
        this.wrapS = wrapS;
        this.wrapT = wrapT;
        this.generateMips = generateMips;
    }

    public void setWrapS( boolean b ) {
        this.wrapS = b;
    }

    public boolean getWrapS() {
        return wrapS;
    }

    public void setWrapT( boolean b ) {
        this.wrapT = b;
    }

    public boolean getWrapT() {
        return wrapT;
    }

    public void setGenerateMips( boolean b ) {
        this.generateMips = b;
    }

    public boolean getGenerateMips() {
        return generateMips;
    }

    public void setFlipY( boolean b ) {
        this.flipY = b;
    }

    public boolean getFlipY() {
        return flipY;
    }

    public void setAnisotropy( Integer i ) {
        this.anisotropy = i;
    }

    public Integer getAnisotropy() {
        return anisotropy;
    }

    public void setMinFilter( MinFilter minFilter ) {
        this.minFilter = minFilter;
    }

    public MinFilter getMinFilter() {
        return minFilter;
    }

    public void setMagFilter( MagFilter magFilter ) {
        this.magFilter = magFilter;
    }

    public MagFilter getMagFilter() {
        return magFilter;
    }

    public Texture create( AssetManager assets ) {
        TextureKey key = new TextureKey(path, flipY);
        key.setGenerateMips(generateMips);
        if( anisotropy != null ) {
            key.setAnisotropy(anisotropy);
        }

        Texture t = assets.loadTexture(key);
        if( t == null ) {
            throw new RuntimeException("Error loading texture:" + path);
        }
        if( wrapS ) {
            t.setWrap(Texture.WrapAxis.S, Texture.WrapMode.Repeat);
        } else {
            // JME has deprecated Clamp and defaults to EdgeClamp.
            t.setWrap(Texture.WrapAxis.S, Texture.WrapMode.EdgeClamp);
        }
        if( wrapT ) {
            t.setWrap(Texture.WrapAxis.T, Texture.WrapMode.Repeat);
        } else {
            t.setWrap(Texture.WrapAxis.T, Texture.WrapMode.EdgeClamp);
        }
        if( minFilter != null ) {
            t.setMinFilter(minFilter);
        }
        if( magFilter != null ) {
            t.setMagFilter(magFilter);
        }
        return t;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("path", path)
            .add("wrapS", wrapS)
            .add("wrapT", wrapT)
            .add("generateMips", generateMips)
            .add("flipY", flipY)
            .add("anisotropy", anisotropy)
            .toString();
    }
}


