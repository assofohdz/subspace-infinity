/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import org.slf4j.*;

import com.jme3.bounding.BoundingVolume;
import com.jme3.collision.Collidable;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Matrix4f;
import com.jme3.scene.Mesh;


/**
 *  Calculating the collision data on block worlds can be inefficient
 *  especially when the data is updated dynamically.  There are already
 *  routines for calculating collisions against the block data without
 *  even needing the geometry.  So we extend Mesh to allow us to override
 *  the collideWith() and the creation of collision data.
 *
 *  For block objects, we may still want it so we'll make it optional
 *  to make our calling code cleaner.
 *
 *  @author    Paul Speed
 */
public class ColliderlessMesh extends Mesh {
    static Logger log = LoggerFactory.getLogger(ColliderlessMesh.class);

    public static boolean debug = false;

    private String name;
    private boolean allowCollision;

    public ColliderlessMesh() {
        // For serialization
    }

    public ColliderlessMesh( String name ) {
        this(name, false);
    }

    public ColliderlessMesh( String name, boolean allowCollision ) {
        this.name = name;
        this.allowCollision = allowCollision;
    }

    public void createCollisionData() {
        if( allowCollision ) {
            if( debug ) {
                log.info("Creating collision data for(" + name + "):" + this, new Throwable("Stack Trace"));
            } else if( log.isTraceEnabled() ) {
                log.trace("Creating collision data for(" + name + "):" + this);
            }
            super.createCollisionData();
        }
    }

    public int collideWith( Collidable other, Matrix4f worldMatrix,
                            BoundingVolume worldBound, CollisionResults results ) {
        if( allowCollision ) {
            return super.collideWith(other, worldMatrix, worldBound, results);
        }
        return 0;
    }
}
