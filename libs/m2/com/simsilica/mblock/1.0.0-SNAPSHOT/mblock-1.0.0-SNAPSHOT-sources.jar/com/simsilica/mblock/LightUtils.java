/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.geom.BlockFactory;


/**
 *  Utilities for calculating cell lighting.
 *
 *  @author    Paul Speed
 */
public class LightUtils {

    static Logger log = LoggerFactory.getLogger(LightUtils.class);

    public static final int DIRECT_SUN = toLight(15, 0, 0, 0);

    public static final int SOLID = 0xffff0000;

    public static int MAX_LIGHT_EFFECT = 14; // 14 meters from point of origin with max light value

    public static int toLight( int sun, int r, int g, int b ) {
        return (sun << 12) | (r << 8) | (g << 4) | b;
    }

    public static int sun( int light ) {
        return (light >> 12) & 0xf;
    }

    public static int red( int light ) {
        return (light >> 8) & 0xf;
    }

    public static int green( int light ) {
        return (light >> 4) & 0xf;
    }

    public static int blue( int light ) {
        return light & 0xf;
    }

    public static int localLight( int light ) {
        return light & 0xfff;
    }

    /**
     *  Returns just the light part of a light cell value.
     */
    public static int getLight( int value ) {
        return value & 0xffff;
    }

    public static int localMax( int light ) {
        int r = red(light);
        int g = green(light);
        int b = blue(light);
        return Math.max(r, Math.max(g, b));
    }

    public static int getBlockLight( int type ) {
        BlockType bt = BlockTypeIndex.get(type);
        return bt == null ? 0 : bt.getLight();
    }

    public static int mergeLights( int light1, int light2 ) {
        if( light1 == light2 ) {
            return light1;
        }
        if( light1 == SOLID ) {
            return light2;
        }
        if( light2 == SOLID ) {
            return light1;
        }
        int s = Math.max(sun(light1), sun(light2));
        int r = Math.max(red(light1), red(light2));
        int g = Math.max(green(light1), green(light2));
        int b = Math.max(blue(light1), blue(light2));
        return toLight(s, r, g, b);
    }

    /**
     *  Returns true if any component in newLight is less than
     *  a component in originalLight.
     */
    public static boolean isDecreasing( int light1, int light2 ) {
        if( light2 == SOLID ) {
            // Massively so
            return true;
        }
        if( light1 == SOLID ) {
            return false;
        }
        if( sun(light2) < sun(light1) ) {
            return true;
        }
        if( red(light2) < red(light1) ) {
            return true;
        }
        if( green(light2) < green(light1) ) {
            return true;
        }
        if( blue(light2) < blue(light1) ) {
            return true;
        }
        // All components of light2 are the same or higher than
        // the components of light1.
        return false;
    }

    /**
     *  Returns true if any of the components of light1 match light2.
     */
    public static boolean anyMatch( int light1, int light2 ) {
        if( light1 == light2 ) {
            // Obviously
            return true;
        }
        if( light1 == SOLID || light2 == SOLID ) {
            // Can't be
            return false;
        }
        if( sun(light1) == sun(light2) ) {
            return true;
        }
        if( red(light1) == red(light2) ) {
            return true;
        }
        if( green(light1) == green(light2) ) {
            return true;
        }
        if( blue(light1) == blue(light2) ) {
            return true;
        }
        return false;
    }

    // Copied directly from old Mythruna code to get the same sunlight
    // propagation.
    private static int nextSun( int current, Direction dir ) {
        // Sunlight gets a special type of propagation
        // that depends on direction.  We can do this only
        // because it is a wholy separate component from the
        // r,g,b light accumulators.  To me this makes sunlight
        // behave a little more realistically and allows infinite
        // depth penetration, etc..
        //
        // Basically, we want max sunlight to penetrate to any level.
        // We want the max sunlight and high sunlight values to fall
        // off more quickly than regular light.  This makes shadows
        // under trees look better and doorways and stuff stand out
        // more.
        //
        // Finally, when traveling up, we fall off even faster.
        // This helps simulate the reflective ambient properties
        // of sunlight even though we aren't actually simulating them.
        // If we ever _do_ simulate them then we may even want to clamp
        // down up propagation completely and let reflective properties
        // 100% take over.

        int nextVal = current;

        // If the value is the max, then we behave a little differently
        //if( current >= 14 ) {
        // 2022-07-04 - trying to tweak the propagation a little more
        if( current >= 13 ) {
            // Only fall-off if we aren't going down... and then
            // do it drastically this first time
            if( dir != Direction.Down ) {
                //nextVal -= 4;
                // That's what Mythruna did but it does mess up smooth
                // lighting a lot... well, I mean we want darker shadows
                // but that also means we end up with darker bleed.  So
                // if the bleed problem is ever readdressed then we could
                // look at this again.  But it would be better to let sun
                // propagate farther, I think instead of chopping off
                // 4 blocks of its range.
                //nextVal--;
                // 2022-07-04 - I do find the straight fall-off a lot more
                // bland, though.  I'm trying to compromise by increasing
                // the 'infinite' range from 14-15 to 13-15 and then doing
                // double fall-off in that range.
                nextVal -= 2;
                // In theory, this should mimic the original -4 but with a
                // smoother gradient.  It seems so.  The added bonus like the
                // previous change (that I didn't notice) is that it increases
                // the range of 'infinite' sun.
            }
            // Else we propagate infinitely down to penetrate even
            // the deepest holes.
        } else if( dir == Direction.Up ) {
            // Fall off faster going up... especially if the value
            // is bright to begin with
            if( current > 10 ) {
                nextVal -= 4;
            } else {
                nextVal -= 3;
            }
        } else {
            // Normal fall-off
            nextVal--;
        }
        return nextVal < 0 ? 0 : nextVal;
    }

    //public static boolean isSolid( int type ) {
    //    return type > 0 && type <= 64;
    //}

    public static boolean isLightPassable( BlockType cell, Direction dir, BlockType other ) {
        // For light venturing out of the cell through the dir into other

        // If we are a solid block of non-transparent material then, no, we
        // never let light out.
        // The isSolid(dir) is not enough because we could be transparent.
        // But we can't just check general whole-block transparency because
        // things like wedges will pass on light when they shouldn't.
        // If the shape is solid in a particular direction and that axis
        // is also not transparent then we can't let lighting through.
        if( cell != null && cell.isSolid(dir) ) {
            if( cell.getTransparency(dir) == 0 ) {
                // There is no way we'll pass on lighting.
                return false;
            }
        }

        if( other == null ) {
            // Of course we do
            return true;
        }

        // Else we _might_ let light into the next block if it will.
        Direction back = dir.reverse();
        if( other.isSolid(back) && other.getTransparency(back) == 0 ) {
            // The other side won't accept light
            return false;
        }

        return true;
    }

    /**
     *  Filters the specified light component by the filter/transmission
     *  value.  Mostly light will filter is multiplication with the filter
     *  but there is special behavior for very high filter values where
     *  the only barely clip the brighest components but otherwise leave
     *  them.
     */
    public static int filter( double filter, int light ) {
        if( filter > 0.99 ) {
            return light;
        }
        if( filter > 0.9 ) {
            if( light == 15 ) {
                return 14;
            }
            return light;
        }
        return (int)Math.round(filter * light);
    }

    public static int attenuateLight( int light, BlockType from, Direction dir, BlockType to ) {
        // Note: being passable and the target being solid are
        // two different things.
        if( to != null && to.isSolid() && !to.isTransparent() ) {
            return SOLID;
        }
        if( !isLightPassable(from, dir, to) ) {
            //return SOLID;
            // No light can pass
            return 0;
        }

        // simple transparency for now... just on the exit.
        double filter = 1;
        if( from != null ) {
            filter = from.getTransparency(dir);
        }
        int s = filter(filter, sun(light));
        int r = filter(filter, red(light));
        int g = filter(filter, green(light));
        int b = filter(filter, blue(light));

        s = nextSun(s, dir);
        if( r > 0 ) {
            r--;
        }
        if( g > 0 ) {
            g--;
        }
        if( b > 0 ) {
            b--;
        }

        return toLight(s, r, g, b);
    }

    /**
     *  Resets the lighting data with specified light from above as far as it
     *  will penetrate and zeroes out all other lighting data.  Usually this
     *  is called with topLight = DIRECT_SUN.
     */
    public static void resetLighting( int topLight, CellData cells, CellData lights, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd ) {

        for( int x = xStart; x < xEnd; x++ ) {
            for( int z = zStart; z < zEnd; z++ ) {
                int light = topLight;
                boolean lit = true;
                BlockType lastType = null;
                for( int y = yEnd - 1; y >= yStart; y-- ) {
                    int val = cells.getCell(x, y, z, -1);
                    if( val == -1 ) {
                        break;
                    }

                    BlockType type = MaskUtils.getBlockType(val);

                    // For sunlight, once the light has gone to 0 then we
                    // don't need to calculate attenuation or track last type
                    // anymore.
                    if( lit ) {

                        // Attenuate the light based on block type
                        //int attenuated = attenuateLight(type, light, Direction.Down);
                        int attenuated = attenuateLight(light, lastType, Direction.Down, type);

                        // Capture any filtered attenuation on the way down
                        light = attenuated;

                        lastType = type;

                        // If we've hit 0 then there is no more sunlight to propagate
                        // down and we enter 'fill mode'
                        lit = getLight(light) != 0;
                    } else {
                        // Fill the remaining blocks with either dark solid or dark empty.
                        if( type != null && type.isSolid() && !type.isTransparent() ) {
                            light = SOLID;
                        } else {
                            light = 0;
                        }
                    }

                    // Have to keep going even if it's 0 because that's how we clear
                    // the light data to start.
                    lights.setCell(x, y, z, light);
                }
            }
        }
    }

    /**
     *  Recalculates all of the lighting within the given cell area.
     */
    public static void recalculateLighting( CellData cells, CellData lights, int arraySize ) {
        recalculateLighting(cells, lights, 0, 0, 0, arraySize, arraySize, arraySize);
    }

    /**
     *  Recalculates all of the lighting within the given cell area.
     */
    public static void recalculateLighting( CellData cells, CellData lights, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd ) {

        LinkedList<LightSeed> seeds = new LinkedList<>();

        // Fill in all of the sunlight first just dropping it down from above.
        // We'll do a second pass to find 'seeds'.  We need to do this first
        // because it allows us to fill in all of the straight down sunlight.
        // We don't generate seeds during this pass because we end up creating
        // alot of redundant seeds and it's difficult to keep track of which
        // columns are open sunlight and which aren't, etc..
        resetLighting(DIRECT_SUN, cells, lights, xStart, yStart, zStart, xEnd, yEnd, zEnd);

        // Note: by now, all solid cells should be marked SOLID

        // Find the seeds by checking neighbors for sunlight and checking cells
        // for lighting sources.
        for( int x = xStart; x < xEnd; x++ ) {
            for( int z = zStart; z < zEnd; z++ ) {
                // We'll still go top down because we can skip accepting
                // sunlight from directions if we already know we would have
                // propagated that down... so we'll track our sunlight on the
                // way down.  For example, this avoids adding 20 seeds for a 20
                // block high overhang when one seed will do.
                // No it doesn't.  That would only be true if non-max sunlight
                // propagated down without attenuation.
                //int sunTrack = 0;
                for( int y = yEnd - 1; y >= yStart; y-- ) {
                    int val = cells.getCell(x, y, z, -1);
                    if( val == -1 ) {
                        break;
                    }
                    BlockType type = MaskUtils.getBlockType(val);
                    int emit = 0;
                    if( type != null ) {
                        emit = type.getLight();
                        if( emit == 0 && type.isSolid() && !type.isTransparent() ) {
                            // No light can enter this cell anyway... and
                            // we don't give off any light.
                            continue;
                        }
                    }
                    int existing = lights.getCell(x, y, z, -1);
                    if( existing == -1 ) {
                        // Not a valid cell for light
                        continue;
                    }
                    if( existing == SOLID && emit == 0 ) {
                        // Target is solid, can't put light there anyway
                        continue;
                    }

                    //int emit = getBlockLight(type);

                    if( existing == DIRECT_SUN && emit == 0 ) {
                        // No more sunlight can propagate into this cell
                        // and we don't have any emission to seed... so skip
                        // the cell.
                        continue;
                    }

                    // Check each direction for sunlight sources
                    // Note: sunlight is the only light added to the light data
                    // at this point... so no reason to mask it.
                    int sun = existing;
                    int maxSun = sun;
                    for( Direction dir : Direction.values() ) {
                        int neighborSun = lights.getCell(x, y, z, dir, -1);
                        if( neighborSun == -1 ) {
                            continue;
                        }
                        BlockType neighbor = MaskUtils.getBlockType(cells.getCell(x, y, z, dir, 0));
                        Direction back = dir.reverse();
                        int attenuatedSun = attenuateLight(neighborSun, neighbor, back, type);
                        if( attenuatedSun > maxSun ) {
                            maxSun = attenuatedSun;
                        }
                    }
                    if( maxSun > sun ) {
                        // The sunlight has a contribution so merge it
                        // with any existing emission value
                        emit = mergeLights(emit, maxSun);
                    }

                    if( emit > 0 ) {
                        // Then we have a seed
                        seeds.add(new LightSeed(x, y, z, emit));
                    }
                }
            }
        }

        propagateSeeds(cells, lights, seeds, false);
    }

    public static final int propagateSeeds( CellData cells, CellData lights, LinkedList<LightSeed> seeds, boolean clamp ) {
        if( log.isTraceEnabled() ) {
            log.trace("Processing " + seeds.size() + " initial seeds.");
        }
        int initialSize = seeds.size();
        int counter = 0;
Map<String, Integer> visited = new HashMap<>();
        while( !seeds.isEmpty() ) {
            LightSeed seed = seeds.removeFirst();
//log.info("seed:" + seed);

            int light = lights.getCell(seed.x, seed.y, seed.z, -1);
            if( light == -1 ) {
                // Not a viable cell
                continue;
            }

            int newLight = mergeLights(light, seed.light);
//log.info("  merge:" + Integer.toHexString(light) + " with:" + Integer.toHexString(seed.light) + " = " + Integer.toHexString(newLight));
            if( newLight == light ) {
                // Nothing more to propagate
                continue;
            }
//String key = seed.x + "," + seed.y + "," + seed.z;
//Integer old = visited.get(key);
//if( old != null && counter > 400000 ) {
//    log.info("Revisiting:" + key + " with:" + seed + "   oldValue:" + Integer.toHexString(old) + " existing:" + Integer.toHexString(light) + " new light:" + Integer.toHexString(newLight));
//}
//visited.put(key, newLight);

            lights.setCell(seed.x, seed.y, seed.z, newLight);
//int retest = lights.getCell(seed.x, seed.y, seed.z, -1);
//if( retest != newLight ) {
//    throw new RuntimeException("Setting light value did not take for:" + seed + " set:" + Integer.toHexString(newLight) + " found:" + Integer.toHexString(retest) + "  on target:" + lights);
//}

            // Check all of the neighbors (except the one we came from)
            BlockType source = MaskUtils.getBlockType(cells.getCell(seed.x, seed.y, seed.z, 0));
            for( Direction dir : Direction.values() ) {
//log.info("   checking dir:" + dir);
                // Skip the direction back the way we came
                if( seed.dir == dir.reverse() ) {
//                    log.info("  Skipping back dir");
                    // except we didn't before, a bug?
                    //continue;
                    // If we continue here then things don't propagate properly,
                    // especially in the case below a window... it seems like light
                    // falls off very quickly about a block below the open window. 2020-11-23
                }

                int val = cells.getCell(seed.x, seed.y, seed.z, dir, -1);
                if( val == -1 ) {
                    continue;
                }
                BlockType type = MaskUtils.getBlockType(val);
                int attenuated = attenuateLight(newLight, source, dir, type);
//log.info("     attenuated:" + Integer.toHexString(attenuated));
                if( attenuated <= 0 ) {
                    // Nothing left to pass on in this direction
                    continue;
                }

                int existing = lights.getCell(seed.x, seed.y, seed.z, dir, -1);
                if( existing == -1 ) {
                    // This means we can't propagate light around the borders if
                    // our lighting array is the same size as our real cells or
                    // the celldata doesn't let us write outside.  It's the caller's
                    // problem.
                    continue;
                }
                // 2022-01-16 - trying to remember why we don't check for SOLID
                // here... though I guess "attenuated" should be SOLID and SOLID
                // is less than zero.  So yeah, if attenuated is <= 0 above then
                // one of the reasons would be because type is solid and not
                // transparent.

                int predict = mergeLights(existing, attenuated);
//log.info("      predict:" + Integer.toHexString(predict) + " from:" + Integer.toHexString(existing) + " and:" + Integer.toHexString(attenuated));
                if( predict != existing ) {
//boolean add = true;
//if( clamp ) {
//    Vec3i test = dir.getVec3i().add(seed.x, seed.y, seed.z);
//    if( test.x < 0 || test.x >= 32 || test.z < 0 || test.z >= 32 ) {
//        //log.info("Propagating outside of range:" + seed
//        //        + " Dir:" + dir + "  New light:" + Integer.toHexString(newLight)
//        //        + " Existing:" + Integer.toHexString(existing)
//        //        + " Attenuated:" + Integer.toHexString(attenuated)
//        //        + " predict:" + Integer.toHexString(predict)
//        //        + " type:" + type);
//        add = false;
//    }
//}

//                    if( add ) {
                        // then the seed would propagate
                        seeds.add(new LightSeed(seed.x, seed.y, seed.z, dir, attenuated));
//                    }
                }
            }
            counter++;
            if( counter > 500000 ) {
                log.warn("Counter overrun:" + counter + "  Original seeds:" + initialSize, new Throwable("stack"));
                break;
            }
        }
        if( log.isTraceEnabled() ) {
            log.trace(counter + " seed iterations");
        }
        return counter;
    }

    /**
     *  For each of the four borders, it checks neighboring cells to see if they
     *  should continue lighting to the main data area.  If so, light is propagated.
     */
    public static int propagateBorders( CellData cells, CellData lights, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd ) {

        if( log.isTraceEnabled() ) {
            log.trace("propagateBorders(" + xStart + ", " + yStart + ", " + zStart + ", " + xEnd + ", " + yEnd + ", " + zEnd + ")");
        }
        LinkedList<LightSeed> seeds = new LinkedList<>();

        for( int x = xStart; x < xEnd; x++ ) {
            for( int y = yStart; y < yEnd; y++ ) {
                int nExisting = lights.getCell(x, y, zStart);
                int nValue = cells.getCell(x, y, zStart);
                int n = lights.getCell(x, y, zStart-1);
                int nPrev = cells.getCell(x, y, zStart-1, 0);
                if( nValue != -1 ) {
                    BlockType from = MaskUtils.getBlockType(nPrev);
                    BlockType type = MaskUtils.getBlockType(nValue);
                    // coming from the north, we're going south
                    int att = attenuateLight(n, from, Direction.South, type);
                    int predict = mergeLights(nExisting, att);
                    if( predict != nExisting ) {
                        seeds.add(new LightSeed(x, y, zStart, Direction.South, att));
                    }
                }

                int sExisting = lights.getCell(x, y, zEnd-1);
                int sValue = cells.getCell(x, y, zEnd-1);
                int s = lights.getCell(x, y, zEnd);
                int sPrev = cells.getCell(x, y, zEnd, 0);
                if( sValue != -1 ) {
                    BlockType from = MaskUtils.getBlockType(sPrev);
                    BlockType type = MaskUtils.getBlockType(sValue);
                    // coming from the north, we're going south
                    int att = attenuateLight(s, from, Direction.North, type);
                    int predict = mergeLights(sExisting, att);
                    if( predict != sExisting ) {
                        seeds.add(new LightSeed(x, y, zEnd-1, Direction.North, att));
                    }
                }
            }
        }
        for( int z = zStart; z < zEnd; z++ ) {
            for( int y = yStart; y < yEnd; y++ ) {
                int wExisting = lights.getCell(xStart, y, z);
                int wValue = cells.getCell(xStart, y, z);
                int w = lights.getCell(xStart-1, y, z);
                int wPrev = cells.getCell(xStart-1, y, z, 0);
                if( wValue != -1 ) {
                    BlockType from = MaskUtils.getBlockType(wPrev);
                    BlockType type = MaskUtils.getBlockType(wValue);
                    // coming from the west, we're going east
                    int att = attenuateLight(w, from, Direction.East, type);
                    int predict = mergeLights(wExisting, att);
                    if( predict != wExisting ) {
                        seeds.add(new LightSeed(xStart, y, z, Direction.East, att));
                    }
                }

                int eExisting = lights.getCell(xEnd-1, y, z);
                int eValue = cells.getCell(xEnd-1, y, z);
                int e = lights.getCell(xEnd, y, z);
                int ePrev = cells.getCell(xEnd, y, z, 0);
                if( eValue != -1 ) {
                    BlockType from = MaskUtils.getBlockType(ePrev);
                    BlockType type = MaskUtils.getBlockType(eValue);
                    // coming from the east, we're going west
                    int att = attenuateLight(e, from, Direction.West, type);
                    int predict = mergeLights(eExisting, att);
                    if( predict != eExisting ) {
                        seeds.add(new LightSeed(xEnd-1, y, z, Direction.West, att));
                    }
                }
            }
        }
        if( log.isTraceEnabled() ) {
            log.trace("Propagating " + seeds.size() + " border seeds.");
        }
        return propagateSeeds(cells, lights, seeds, true);
    }

    /*
     * There are a few cases that we want to deal with:
     * 1) light added as the result of a light block being placed.
     *     Need to set the cell value light as a seed and then
     *     propagate outwards.  propagateSeeds() is setup such that
     *     we should be able to just create the LightSeed for the cell
     *     and then propagate it.
     * 2) a block was removed and now we want to look at the surrounding cells
     *     and merge all of those values together into a new seed.
     * 3) a light was removed.  We run the same algorithm as if we placed
     *     the light and remove any lighting that could have been caused
     *     by the removed light: component-by-component exact match.  Once done,
     *     for any light cleared we want to do the same as in (2) and suck in the
     *     neighbors.
     */


    /**
     *  Looks at the cell and its surrounding cells to merge a new light value
     *  for the cell.  If it would change the lighting (brighter in any way)
     *  then a LightSeed is returned for propagation.
     */
    public static LightSeed calculateSeed( CellData cells, CellData light, int x, int y, int z, int originalLight, int newLight ) {
        if( log.isTraceEnabled() ) {
            log.trace("calculateSeed(" + x + ", " + y + ", " + z + ", " + Integer.toHexString(originalLight) + ", " + Integer.toHexString(newLight) + ")");
        }

        // newLight is passed to us because the world probably hasn't been edited
        // to put lighting into this cell yet... that's why we're calculating it.
        // However, if the caller did not provide a new light value then we will check
        // to see if the existing block emits light.
        int sourceLight = newLight;
        BlockType sourceType = MaskUtils.getBlockType(cells.getCell(x, y, z, 0));
        if( sourceLight <= 0 && sourceType != null && sourceType.getLight() > 0 ) {
            if( log.isTraceEnabled() ) {
                log.trace("calculating see for emissive cell:" + Integer.toHexString(sourceType.getLight()));
            }
            sourceLight = sourceType.getLight();
        }

        // Keep track of the best merged light solution we find
        int bestLight = sourceLight;
//log.info("bestLight:" + Integer.toHexString(bestLight));

        // Check the neighbors
        Direction sunDir = null;
        for( Direction dir : Direction.values() ) {
            int existing = light.getCell(x, y, z, dir, -1);

            // Get the neighboring cell data and type
            int val = cells.getCell(x, y, z, dir, -1);
            if( val == -1 ) {
                // We've fallen off the edge... technically this should not
                // happen except going down.
                continue;
            }
            BlockType type = MaskUtils.getBlockType(val);
            if( type != null && type.getLight() > 0 ) {
                // Need to cover the case where we've zeroed out the lighting
                // but there is a light-emitting block here
                if( existing <= 0 ) {
                    existing = type.getLight();
                }
            }
            if( existing <= 0 ) {
                // No light in this direction so no need to do anything else
                continue;
            }

            // See how the light from that neighbor would attenuate into
            // the target cell, ie: the reverse direction from where we found
            // the neighbor.
            int attenuated = attenuateLight(existing, type, dir.reverse(), sourceType);
            bestLight = mergeLights(bestLight, attenuated);
//log.info(dir + " attenuated:" + Integer.toHexString(attenuated) + " bestLight:" + Integer.toHexString(bestLight));
        }

        // If after all of that, bestLight is better than the existing
        // light then we can make a new seed
        if( bestLight != originalLight ) {
            return new LightSeed(x, y, z, bestLight);
        }

        // Else there is no new see here.
        return null;
    }

    /**
     *  Subtracts the specified light from the light data by removing anything
     *  that would match propagation of that light cell.  The list of cleared cells are
     *  returned for reseeding.
     */
    public static List<Vec3i> subtractLight( CellData cells, CellData lights, int x, int y, int z, int start ) {
        if( log.isTraceEnabled() ) {
            log.trace("subtractLight(" + x + ", " + y + ", " + z + ", " + Integer.toHexString(start));
        }

        if( start == 0 || start == SOLID ) {
            // Nothing to subtract
            return Collections.emptyList();
        }

        LinkedList<LightSeed> seeds = new LinkedList<>();
        seeds.add(new LightSeed(x, y, z, start));

        List<Vec3i> removed =  new ArrayList<>();

        int counter = 0;
        while( !seeds.isEmpty() ) {
            LightSeed seed = seeds.removeFirst();

            int light = lights.getCell(seed.x, seed.y, seed.z, -1);
            if( light == -1 ) {
                // Not a viable cell
                continue;
            }
            if( log.isTraceEnabled() ) {
                log.trace("  seed:" + seed + "  existing:" + Integer.toHexString(light));
            }

            // If the light here is solid then nothing will change
            if( light == SOLID ) {
                continue;
            }
            if( light == 0 ) {
                // Cannot subtract light when there is no light
                continue;
            }

            // Compare the components of the light to what the seed thinks the
            // light should be.
            int sSeed = sun(seed.light);
            int rSeed = red(seed.light);
            int gSeed = green(seed.light);
            int bSeed = blue(seed.light);

            int s = sun(light);
            int r = red(light);
            int g = green(light);
            int b = blue(light);

            // An existing value should either be the same or greater
            // than the seed if this light was properly propagated in
            // the first place.  The only real case where the existing
            // value is less than our seed is when we cleared it on a
            // previous visit... in which case all of the values should
            // have been cleared and the check above 'continue'.
            // So we will log a warning if we discover these cases
            boolean warn = false;
            boolean clear = false;
            if( sSeed <= 0 ) {
                // Don't need to compare it because it's not a factor
            } else if( sSeed > s ) {
                warn = true;
            } else if( sSeed == s ) {
                clear = true;
//log.info("    sun matches");
            }
            if( rSeed <= 0 ) {
                // Don't need to compare it because it's not a factor
            } else if( rSeed > r ) {
                warn = true;
            } else if( rSeed == r ) {
                clear = true;
//log.info("    red matches");
            }
            if( gSeed <= 0 ) {
                // Don't need to compare it because it's not a factor
            } else if( gSeed > g ) {
                warn = true;
            } else if( gSeed == g ) {
                clear = true;
//log.info("    green matches");
            }
            if( bSeed <= 0 ) {
                // Don't need to compare it because it's not a factor
            } else if( bSeed > b ) {
                warn = true;
            } else if( bSeed == b ) {
                clear = true;
//log.info("    blue matches");
            }
            if( warn ) {
                // One of the seed components is greater than the existing
                // components which means that the original light didn't propagate
                // properly.  Even if we find legitimate reasons why this could
                // happen (say multiblock edits at the same time), it stands to
                // reason that it would make this whole subtraction algorithm
                // suspect.
                log.warn("Propagation error detected, existing value:"
                            + Integer.toHexString(light)
                            + " seed:" + seed);
            }
            if( clear ) {
                if( log.isTraceEnabled() ) {
                    log.trace("    clearing:" + seed);
                }
                // The light possibly affected this cell when originally propagated
                // so we will clear the whole light value and track the cell for
                // the reseeding results.
                removed.add(new Vec3i(seed.x, seed.y, seed.z));
                lights.setCell(seed.x, seed.y, seed.z, 0);
            } else {
                if( log.isTraceEnabled() ) {
                    log.trace("    unaffected");
                }
                // Otherwise, this light had no affect on this cell originally
                // and so we don't need to propagate anymore from this particular
                // seed
                continue;
            }

            // Propagate to the neighbors like a normal light would.
            BlockType source = MaskUtils.getBlockType(cells.getCell(seed.x, seed.y, seed.z, 0));
            for( Direction dir : Direction.values() ) {
                // Skip the direction back the way we came
                if( seed.dir == dir.reverse() ) {
//                    log.info("  Skipping back dir");
                    // except we didn't before, a bug?
                    //continue;
                    // If we continue here then things don't propagate properly,
                    // especially in the case below a window... it seems like light
                    // falls off very quickly about a block below the open window. 2020-11-23
                }
                // 2022-01-15 Note: I've copied the above code from the original propagation
                // but I wish I'd left a comment about why the described scenario doesn't work.
                // Seems like we shouldn't have to check the reverse because we just came
                // from there.
                int val = cells.getCell(seed.x, seed.y, seed.z, dir, -1);
                if( val == -1 ) {
                    continue;
                }
                BlockType type = MaskUtils.getBlockType(val);
                // attenuate the seed.light directly because we're tracking the
                // original subtracted light's propagation and not the world merged
                // lighting.
                int attenuated = attenuateLight(seed.light, source, dir, type);
                if( log.isTraceEnabled() ) {
                    log.trace(dir + " attenuated:" + Integer.toHexString(attenuated));
                }
                if( attenuated <= 0 ) {
                    // Nothing left to pass on in this direction
                    continue;
                }

                int existing = lights.getCell(seed.x, seed.y, seed.z, dir, -1);
                if( log.isTraceEnabled() ) {
                    log.trace("    existing:" + Integer.toHexString(existing));
                }
                if( existing == -1 ) {
                    // This means we can't propagate light around the borders if
                    // our lighting array is the same size as our real cells or
                    // the celldata doesn't let us write outside.  It's the caller's
                    // problem.
                    continue;
                }
                // I don't think predicting gets us anything.  If we're the
                // same then we need to keep going.  We would need a better
                // comparison and the seed handling will already do that.
                //int predict = mergeLights(existing, attenuated);
//log.info("  existing:" + Integer.toHexString(existing) + "  predict:" + Integer.toHexString(predict));
                //if( predict != existing ) {
                //    // Then our light would have contributed something to this
                //    // neighbor and we should add a seed for it.  But note: not
                //    // the combined lighting but the attenuated lighting.  We
                //    // are only tracking the components of our originaly light...
                //    // not the existing lighting.  (Even the regular lighting
                //    // does not propagate 'predict' because we don't really know
                //    // what should end up there until we handle the best seed.
                //    seeds.add(new LightSeed(seed.x, seed.y, seed.z, dir, attenuated));
                //}
                if( existing == 0 ) {
                    // Light never propagated in this direction and so we can't
                    // match by propagating and there would be nothing to clear
                    // anyway.  There is also the very likely case it's because
                    // we already visited and cleared it.
                    continue;
                }
                if( existing == SOLID ) {
                    // attenuateLight() should have returned < 0 in this case
                    // and we should never get here.
                    log.warn("How did this happen?  attenuateLight() error somewhere.");
                    continue;
                }

                // If there is any attenuated value left at all and the lighting
                // isn't blocked by beind solid then we need to check it to see
                // if any of our propagated lighting matches.
                seeds.add(new LightSeed(seed.x, seed.y, seed.z, dir, attenuated));
            }

            // Just in case a bug in the algorithm causes an endless loop,
            // we will bottom out at a ridiculously high iteration count for
            // one light.  (The brightest of bright lights cannot exceed a 15 meter
            // radius.  Even a solid block of seeds would only be 32,000.)
            counter++;
            if( counter > 500000 ) {
                log.warn("Counter overrun:" + counter, new Throwable("stack"));
                break;
            }
        }
        if( log.isTraceEnabled() ) {
            log.trace(counter + " subtract light seed iterations");
        }

        return removed;
    }



    public static class LightSeed {
        int x, y, z;
        Direction dir;
        int light;

        public LightSeed( int x, int y, int z, Direction dir, int light ) {
            this.x = x + dir.getVec3i().x;
            this.y = y + dir.getVec3i().y;
            this.z = z + dir.getVec3i().z;
            this.dir = dir;
            this.light = light;
        }

        public LightSeed( int x, int y, int z, int light ) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.light = light;
        }

        public String toString() {
            return "LightSeed[(" + x + ", " + y + ", " + z + "), " + dir + ", " + Integer.toHexString(light) + "]";
        }
    }
}
