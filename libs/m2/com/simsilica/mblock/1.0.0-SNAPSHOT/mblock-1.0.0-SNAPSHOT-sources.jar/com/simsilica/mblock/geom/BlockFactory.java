/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.io.Serializable;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *  Creates the geometry for a given type of block.
 *
 *  @author    Paul Speed
 */
public interface BlockFactory extends Serializable {

    /**
     *  Called to add the appropriate parts to the part buffer.
     *  i, j, and k are the cell coordinate within the current 'block space'
     *  represented by 'cells'.  This is the space that was used to look up
     *  the side mask, block type, etc..
     *  xWorld, yWorld, and zWorld are the world coordinates of the cell.
     */
    public int addGeometryToBuffer( GeomPartBuffer buffer, int i, int j, int k,
                                    int xWorld, int yWorld, int zWorld,
                                    int sideMask,
                                    CellData cells,
                                    BlockType type );

    /**
     *  Returns the boundary shape in the specified direction.  Returns
     *  BoundaryShapes.NULL_SHAPE if there is no face in the specified
     *  direction.
     */
    public BoundaryShape getShape( Direction dir );

    /**
     *  Returns true if the block face in the specified direction
     *  is solid.  A 'solid' face is one that covers the whole block
     *  space in that surface direction.
     */
    public boolean isSolid( Direction dir );

    /**
     *  Returns true if all directions are solid, ie: this block factory
     *  creates full cubes.
     */
    public boolean isSolid();

    /**
     *  Returns the relative level of transparency along the specified
     *  axis where 0 is fully opaque and 1 is fully transparent.  This may be
     *  a factor of the type of material used or may
     *  be related to the size of the surfaces along that axis and how
     *  much light they would let pass.  (ie: a half block would let
     *  50% of the light through.)
     */
    //public double getTransparency( Axis axis );

    public double getTransparency( Direction dir );

    /**
     *  Returns true if any direction is transparent.
     */
    public boolean isTransparent();

    /**
     *  Returns the portion of mass that should be attributed to
     *  the material.  This is the rough volume of the shape
     *  in most cases and can be used as such for volume calculations.
     *  It is the portion of a unit cube that is "solid" for mass
     *  purposes.
     */
    public double getVolume();

    public Vec3d getMin();

    public Vec3d getMax();

    //public Collider getCollider();

    public BlockFactory rotate( int dirDelta );

    /**
     *  Factory implementations should have equals() and hashCode()
     *  to detect upgrades
     */
    public boolean equals( Object o );

    /**
     *  Factory implementations should have equals() and hashCode()
     *  to detect upgrades
     */
    public int hashCode();
}

