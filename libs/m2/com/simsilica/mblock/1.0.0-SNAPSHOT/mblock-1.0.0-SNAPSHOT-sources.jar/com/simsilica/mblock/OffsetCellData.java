/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;


/**
 *  Wraps one CellData and provides a coordinate offset into
 *  the delegate.
 *
 *  @author    Paul Speed
 */
public class OffsetCellData implements CellData {

    private CellData delegate;
    private int xOffset;
    private int yOffset;
    private int zOffset;

    public OffsetCellData( CellData delegate, int xOffset, int yOffset, int zOffset ) {
        this.delegate = delegate;
        this.xOffset = xOffset;
        this.yOffset = yOffset;
        this.zOffset = zOffset;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        return delegate.getCell(xOffset + x, yOffset + y, zOffset + z);
    }
        
    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        return delegate.getCell(xOffset + x, yOffset + y, zOffset + z, defaultValue);
    }
        
    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        return delegate.getCell(xOffset + x, yOffset + y, zOffset + z, dir, defaultValue);
    }
        
    @Override
    public void setCell( int x, int y, int z, int value ) {
        delegate.setCell(xOffset + x, yOffset + y, zOffset + z, value);
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[offset:(" + xOffset + ", " + yOffset + ", " + zOffset + "), delegate:" + delegate + "]";
    }
}
