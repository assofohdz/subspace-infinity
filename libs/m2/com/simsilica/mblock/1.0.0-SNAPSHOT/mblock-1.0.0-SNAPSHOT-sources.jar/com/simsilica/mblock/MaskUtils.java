/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import org.slf4j.*;

import com.simsilica.mathd.Vec3i;
import com.simsilica.mblock.geom.BoundaryShape;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MaskUtils {

    static Logger log = LoggerFactory.getLogger(MaskUtils.class);

    // Documenting the bits used    
    // FEDCBA9876543210FEDCBA9876543210
    // SSSSSS      TTTTTTTTTTTTTTTTTTTT
    //
    // MWorld additional uses bits 24 and 25 for gen type (G)
    // SSSSSSGG    TTTTTTTTTTTTTTTTTTTT
    //
    // We may additionally use the remaining 4 bits for block
    // subtype information like color. (C)
    //
    // FEDCBA9876543210FEDCBA9876543210
    // SSSSSSGGCCCCTTTTTTTTTTTTTTTTTTTT
    //
    // Though there is also the likelihood that we'd leave that
    // as the top part of the regular 20 type bits so that the block
    // type could decide to use it or not use it.  That's the way I
    // have it in the design doc. (?) being the optional subbits:
    //
    // FEDCBA9876543210FEDCBA9876543210
    // SSSSSSGG    ????TTTTTTTTTTTTTTTT
    

    private static final int TYPE_MASK  = 0x000fffff;
    private static final int SIDE_MASK_BITS = 0x3f;
    private static final int SIDE_MASK_SHIFT = 26;
    private static final int SIDE_MASK  = SIDE_MASK_BITS << SIDE_MASK_SHIFT;

    // 2022-01-22
    // Right now we aren't using this and if we do we'll
    // have to move it so that it doesn't overlap with the
    // newly moved side masks.  I think originally I was thinking we could
    // drop the fluid type here so that it was easy to see that
    // the block was 'wet'.  But I don't know what use-case we'd
    // have for needing to know the whole type versus just one 'wet'
    // bit that we then use to look at the fluid data.
    //private static final int FLUID_BITS = 0x3f;
    //private static final int FLUID_MASK = FLUID_BITS << 26;

    public static int setType( int value, int type ) {
        return (value & (~TYPE_MASK)) | type;
    }

    public static int getType( int value ) {
        return value & TYPE_MASK;
    }

    public static int getSideMask( int value ) {
        //return (value & SIDE_MASK) >> SIDE_MASK_SHIFT;
        // If we use the above then it might return 111111111 for -1
        // by masking last, we make sure only the bits we want are set.
        return (value >> SIDE_MASK_SHIFT) & SIDE_MASK_BITS;
    }

    public static int setSideMask( int value, int sideMask ) {
        return (value & (~SIDE_MASK)) | (sideMask << SIDE_MASK_SHIFT);
    }

    //public static int getFluidInfo( int value ) {
    //    return (value >> 26) & FLUID_BITS;
    //}
    //
    //public static int setFluidInfo( int value, int fluidInfo ) {
    //    return (value & (~FLUID_MASK)) | (fluidInfo << 26);
    //}

    /**
     *  Returns the BlockType for the type-filtered raw value, ie: this is
     *  the equivalent of calling BlockTypeIndex.get(MaskUtils.getType(value)).
     */
    public static BlockType getBlockType( int val ) {
        int type = getType(val);
        return BlockTypeIndex.get(type);
    }

    public static String valueToString( int value ) {
        return "@" + getType(value) + " #" + Integer.toBinaryString(getSideMask(value));
    }

    public static void recalculateSideMasks( CellData data, int x, int y, int z, int defaultBorder ) {
        // A defaultBorder of 0 means we'll treat out-of-bounds bordering
        // cells as if there was open space there.  -1 means we'll treat
        // out-of-bounds bordering cells as if there was a type block there.
        // ...especially useful for the down face of y=0
        if( log.isTraceEnabled() ) {
            log.trace("recalculateSideMasks(" + x + ", " + y + ", " + z + ")");
        }
        int val = data.getCell(x, y, z, -1);
        if( val == -1 ) {
            throw new IllegalArgumentException("Recalculating masks for invalid cell location:" + x + ", " + y + ", " + z);
        }
        BlockType centerType = getBlockType(val);
        int centerMask = 0;
        for( Direction dir : Direction.values() ) {
            Vec3i v = dir.getVec3i();
            int nx = x + v.x;
            int ny = y + v.y;
            int nz = z + v.z;
            int nVal = data.getCell(nx, ny, nz, defaultBorder);
            BlockType neighbor = getBlockType(nVal);
            if( log.isTraceEnabled() ) {
                log.trace(dir + " (" + nx + ", " + ny + ", " + nz + ") -> " + Integer.toHexString(nVal));
            }
            if( centerType != null ) {
                // Check the center mask in the neighbor direction
                // (null blocks can't have masks as it doesn't render anything)
                if( isSideVisible(centerType, dir, neighbor) ) {
                    centerMask = centerMask | dir.getBitMask();
                }
            }
            if( neighbor != null ) {
                // Calculate the reverse mask for the neighbor
                int mask = getSideMask(nVal);
                if( log.isTraceEnabled() ) {
                    log.trace("   existing:" + Integer.toHexString(mask));
                }
                Direction reverse = dir.reverse();
                if( isSideVisible(neighbor, reverse, centerType) ) {
                    mask = mask | reverse.getBitMask();
                } else {
                    // Unset the bit
                    mask = mask & (~reverse.getBitMask());
                }
                if( log.isTraceEnabled() ) {
                    log.trace("   final:" + Integer.toHexString(mask));
                }
                data.setCell(nx, ny, nz, setSideMask(nVal, mask));
            }
        }
        // And set the center cell's mask like we originally set out to do
        data.setCell(x, y, z, setSideMask(val, centerMask));
    }

    // 2022-01-16 - This method has been around since I started writing MOSS, I think.
    //  It's very inefficient because it recalculates the masks in all directions
    // for every 3x3x3 neighbor.  It was fast to write... but if we're only recalculating
    // the masks facing x, y, z then we can do MUCH better.  In addition to avoiding
    // the 8 useless corners, we can avoid another 6x5 worth of face calculations
    // and reduce the footprint of the 5x5x5 area we actually query in the end.
    public static void oldRecalculateSideMasks( CellData data, int x, int y, int z ) {
        int xStart = x - 1;
        int yStart = Math.max(0, y - 1); // y is 0 to infinity
        int zStart = z - 1;
        int xEnd = x + 1;
        int yEnd = y + 1;
        int zEnd = z + 1;

        for( x = xStart; x <= xEnd; x++ ) {
            for( y = yStart; y <= yEnd; y++ ) {
                for( z = zStart; z <= zEnd; z++ ) {
                    int val = data.getCell(x, y, z);
                    BlockType type = getBlockType(val);
                    // But we can't skip it completely because the existing
                    // mask might still be wrong and we need to zero it out.
                    int sideMask = 0;

                    // null is always empty space so we only need to recalculate
                    // a mask if there is a thing there... but we still want to
                    // set an empty mask back in case it wasn't empty before.
                    // Note: this shouldn't happen in practice because of how we
                    // set the cell data to the raw type before applying side masks
                    // but it's better to be correct just in case... and costs us
                    // nothing.
                    if( type != null ) {
                        // Calculate the mask right here
                        for( Direction dir : Direction.values() ) {
                            BlockType next = getBlockType(data.getCell(x, y, z, dir, 0));
                            if( isSideVisible(type, dir, next) ) {
                                // It's empty so we emit a face in that direction
                                sideMask = sideMask | dir.getBitMask();
                            }
                        }
                    }
                    data.setCell(x, y, z, setSideMask(val, sideMask));
                }
            }
        }

    }

    public static void recalculateSideMasks( CellArray array, int x, int y, int z, boolean includeNeighbors ) {

        int xStart = Math.max(0, x - (includeNeighbors ? 1 : 0));
        int yStart = Math.max(0, y - (includeNeighbors ? 1 : 0));
        int zStart = Math.max(0, z - (includeNeighbors ? 1 : 0));
        int xEnd = Math.min(array.getSizeX() - 1, x + (includeNeighbors ? 1 : 0));
        int yEnd = Math.min(array.getSizeY() - 1, y + (includeNeighbors ? 1 : 0));
        int zEnd = Math.min(array.getSizeZ() - 1, z + (includeNeighbors ? 1 : 0));

        for( x = xStart; x <= xEnd; x++ ) {
            for( y = yStart; y <= yEnd; y++ ) {
                for( z = zStart; z <= zEnd; z++ ) {
                    int val = array.getCell(x, y, z);
                    BlockType type = getBlockType(val);
                    int sideMask = 0;

                    if( type != null ) {
                        // Calculate the mask right here
                        for( Direction dir : Direction.values() ) {
                            BlockType next = getBlockType(array.getCell(x, y, z, dir, 0));
                            // Just a simple check for now
                            if( isSideVisible(type, dir, next) ) {
                                // It's empty so we emit a face in that direction
                                sideMask = sideMask | dir.getBitMask();
                            }
                        }
                    }
                    array.setCell(x, y, z, setSideMask(val, sideMask));
                }
            }
        }
    }

    public static int calculateSideMask( int x, int y, int z, CellData data ) {
        return calculateSideMask(x, y, z, data, false);
    }

    /**
     *  Calculates and returns the side mask for the specified coordinate by looking at the
     *  neighbors in the specified CellData object.  If writeBack is true then the value is
     *  also written back to the cell x,y,z.
     */
    public static int calculateSideMask( int x, int y, int z, CellData data, boolean writeBack ) {
        int val = data.getCell(x, y, z);
        BlockType type = getBlockType(val);
        if( type == null ) {
            // null is always empty space
            return 0;
        }
        int sideMask = 0;

        // Calculate the mask right here
        for( Direction dir : Direction.values() ) {
            //BlockType next = BlockTypeIndex.get(getType(data.getCell(x, y, z, dir, 0)));
            BlockType next = getBlockType(data.getCell(x, y, z, dir, 0));
            if( isSideVisible(type, dir, next) ) {
                // It's empty so we emit a face in that direction
                sideMask = sideMask | dir.getBitMask();
            }
        }
        if( writeBack ) {
            data.setCell(x, y, z, setSideMask(val, sideMask));
        }
        return sideMask;
    }

    public static void calculateSideMasks( CellArray array ) {
        calculateSideMasks(array, array.getSizeX(), array.getSizeY(), array.getSizeZ());
    }

    public static void calculateSideMasks( CellData data, int size ) {
        calculateSideMasks(data, size, size, size);
    }

    public static int calculateSideMasks( CellData data, int xSize, int ySize, int zSize ) {
        return calculateSideMasks(data, 0, 0, 0, xSize, ySize, zSize);
    }

    public static int calculateSideMasks( CellData data, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd) {
        return calculateSideMasks(data, xStart, yStart, zStart, xEnd, yEnd, zEnd, 0);
    }

    public static int calculateSideMasks( CellData data, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd, int defaultValue ) {

        int sideCount = 0;
        for( int x = xStart; x < xEnd; x++ ) {
            for( int y = yStart; y < yEnd; y++ ) {
                for( int z = zStart; z < zEnd; z++ ) {
                    int val = data.getCell(x, y, z);
                    BlockType type = getBlockType(val);
                    if( type == null ) {
                        // null is always empty space
                        // I think we can get away with this here because we
                        // aren't calculating light passability anymore.
                        continue;
                    }
                    int sideMask = 0;

                    // Calculate the mask right here
                    for( Direction dir : Direction.values() ) {
                        BlockType next = getBlockType(data.getCell(x, y, z, dir, defaultValue));
                        if( isSideVisible(type, dir, next) ) {
                            // It's empty so we emit a face in that direction
                            sideMask = sideMask | dir.getBitMask();
                            sideCount++;
                        }
                    }
                    data.setCell(x, y, z, setSideMask(val, sideMask));
                }
            }
        }

        return sideCount;
    }

    public static boolean isSideVisible( BlockType cell, Direction dir, BlockType other ) {
        if( cell == null ) {
            return false;
        }
        if( other == null ) {
            return true;
        }

        log.trace("isSideVisible()");

        // All other checks are irrelevant unless the transparency groups match
        int ourGroup = cell.getTransparencyGroup();
        int otherGroup = other.getTransparencyGroup();
        if( ourGroup != otherGroup || ourGroup == -1 ) {
            // Added the ourGroup == -1 check above to handle the thatch to thatch
            // boundary sides.

            // If the groups are different then we assume that we should
            // render the side.
            // The exceptions:
            // For group 0, we always consider that "solid" and will normally
            // never render a face in that direction.  This is to cover things
            // like water, shrubs, etc. that are facing always solid blocks.
            //
            // For negative groups, this feature is bypassed.  Negative groups
            // will always render against different groups.  In the original Mythruna,
            // this was to cover the case of the logs that drop down below their
            // block.  Quote from the old comment:
            // "The case where this is necessary is the logs that drop down
            // below their block.  Without this, the end caps won't get
            // rendered when against a solid block.  So, negative groups
            // have the special behavior that the sides are always drawn
            // when against a different group... even if that group is 0."
            //
            // I don't remember today why this is the case but I do know that
            // the stuff that extends out of blocks required special consideration.
            if( otherGroup != 0 || ourGroup < 0 ) {
                if( log.isTraceEnabled() ) {
                    log.trace("group mismatch, ourGroup:" + ourGroup + "  otherGroup:" + otherGroup);
                }
                return true;
            }

            // Else the groups are different and the "other" group is an opaque
            // face.  Let normal side processing happen then.
        }

        // At this point, we assume the types are in the same transparency
        // group or at least renderable as if they are.  So now we need to
        // compare sides to see if our side is 'smaller' than the facing
        // side.  For the idea of 'smaller' we simply refer to whether the
        // other side is solid or not... meaning it covers the full face.
        //
        // Note: I'm keeping the code this way for now but I still think it
        // would be possible to do this directly with the BoundaryShapes without
        // incurring any real extra work.  If our side is contained within the
        // other side then don't render anything.  The "contained within" check
        // could be smart enough to do the direct face match check but could
        // also do more advanced stuff in the future.  For example, a half block
        // triangle side should not be rendered again a half block rectangle side
        // but in the 'legacy' approach, it will be.  2020-11-23

        Direction back = dir.reverse();
        if( other.isSolid(back) ) {
            log.trace("other is solid");
            // The other side is solid so we do not draw our face.  The best
            // we could be is also solid in which case we'd just match exactly.
            return false;
        }
        if( cell.isSolid(dir) ) {
            log.trace("cell is solid");
            // Our side is solid but the other side is not... so we definitely
            // render.
            return true;
        }

        // For non-solid sides, we need to know if the faces match or not.
        BoundaryShape us = cell.getShape(dir);
        BoundaryShape them = other.getShape(back);
        // See comment above about the fact that we probably already have
        // what we need for the 'solid' check without those additional
        // lookups.  isSolid() is also based on transparency values but
        // I think we already eliminated the need to check that with the
        // group checks.  Will need real data before a refactoring should
        // be attempted.  2020-11-23
        // In testing later the same day, I discovered that my non-transparent
        // water (because it wasn't setup properly yet) was causing solid
        // sides of other block types to not be rendered.  Regardless of boundary
        // shape... this kind of makes sense.  A block type may have some transparent
        // sides and some solid sides.
        // Nah... that's a bug.  isSolid() is not supposed to care about
        // transparency.
        if( log.isTraceEnabled() ) {
            log.trace("us:" + us + "  them:" + them);
        }
        if( !us.isMatchingFace(them) ) {
            return true;
        }
        return false;
    }

}
