/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.io.*;
import java.util.Objects;

import com.simsilica.mblock.io.FluidTypeData;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidTypeIndex {
    static final long serialVersionUID = 42L;
    
    private static FluidType[] types;
    private static int typeCount;
    
    private FluidTypeIndex() {
    }
 
    /**
     *  Initializes the current fluid types with the specified types.  
     *  If there is an existing set of types then this will throw an
     *  IllegalStateException.  
     *  Note: it is expected that the types array already contains the null value
     *  for index 0.
     */   
    public static void initialize( FluidType[] types ) {
        if( FluidTypeIndex.types != null ) {
            throw new IllegalStateException("FluidTypeIndex is already initialized");
        }
        FluidTypeIndex.types = types; 
        FluidTypeIndex.typeCount = types.length;
    }

    public static void initialize( FluidTypeData fluidData ) {
        initialize(fluidData.types);
    }

    public static void load( InputStream rawIn ) throws IOException {
        FluidTypeData fluidData = FluidTypeData.load(rawIn);
        reset();
        initialize(fluidData.types);
    }
    
    public static void store( OutputStream rawOut ) throws IOException {
        FluidTypeData fluidData = new FluidTypeData();
        fluidData.types = types;
        FluidTypeData.store(fluidData, rawOut);
    }
    
    
    public static void reset() {
        FluidTypeIndex.types = null; 
        FluidTypeIndex.typeCount = 0;
    }
    
    public static FluidTypeData toFluidTypeData() {
        return new FluidTypeData(types);
    }
    
    public static FluidType get( int type ) {
        // Caller beware... no 'bad type' here.
        return types[type];
    }
    
    public static void override( int index, FluidType type ) {
        types[index] = type;
    }
 
    public static boolean isInitialized() {
        return types != null; 
    }
    
    public static int getTypeCount() {
        return typeCount;
    }
    
    public static FluidType[] getTypes() {
        return types;
    }
    
    public static int findType( FluidName name ) {
        return findType(name, -1);
    }
    
    public static int findType( FluidName name, int defaultValue ) {
        for( int i = 0; i < types.length; i++ ) {
            FluidType type = types[i];
            if( type == null ) {
                continue;
            }
            if( Objects.equals(type.getName(), name) ) {
                return i;
            }
        }
        return defaultValue;
    }
}
