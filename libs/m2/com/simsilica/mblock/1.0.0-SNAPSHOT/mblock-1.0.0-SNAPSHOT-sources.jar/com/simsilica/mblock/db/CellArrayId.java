/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.db;

import java.util.Objects;

import org.slf4j.*;

/**
 *  Uniquely identifies a CellArray in CellArrayStorage.
 *  This is not a GridBasedId or any other type of spatial ID
 *  and serves no real purpose other than retrieving CellArrays
 *  from storage.  (In fact, callers have no real reason to create
 *  these on their own other than for transformations.)
 *
 *  @author    Paul Speed
 */
public class CellArrayId {
    static Logger log = LoggerFactory.getLogger(CellArrayId.class);

    private long id;

    private CellArrayId() {
    }

    public CellArrayId( long id ) {
        this.id = id;
    }

    /**
     *  Turns a hexadecimal string into a CellArrayId.
     */
    public static CellArrayId fromString( String s ) {
        return new CellArrayId(Long.parseUnsignedLong(s, 16));
    }

    /**
     *  Turns a CellArrayId.toFileName() string back into a CellArrayId.
     */
    public static CellArrayId fromFileName( String s ) {
        if( !s.endsWith(".ca") ) {
            throw new IllegalArgumentException("String is not in filename form, no .ca extension:" + s);
        }
        s = s.substring(0, s.length() - 3);
        return fromString(s);
    }

    public long getId() {
        return id;
    }

    public String toIdString() {
        return String.format("%x", id);
    }

    /**
     *  Returns the ID in default file name form suitable for
     *  passing back to fromFileName().
     */
    public String toFileName() {
        return String.format("%x.ca", id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        CellArrayId other = (CellArrayId)o;
        if( other.id != id ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[id:" + id + "]";
    }
}
