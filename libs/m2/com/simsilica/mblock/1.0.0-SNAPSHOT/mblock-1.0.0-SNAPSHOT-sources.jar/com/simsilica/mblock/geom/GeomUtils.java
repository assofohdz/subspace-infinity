/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.nio.*;
import java.util.function.Predicate;

import org.slf4j.*;

import com.jme3.scene.*;
import com.jme3.scene.VertexBuffer.Type;

import com.simsilica.mathd.*;

import com.simsilica.mblock.Direction;

/**
 *  Block-centric geometry manipulation utils.
 *
 *  @author    Paul Speed
 */
public class GeomUtils {

    static Logger log = LoggerFactory.getLogger(GeomUtils.class);

    // Note: for whatever reason, the fromAngles(0, y, 0)
    // seems to be wired for + going counter-clockwise.  To me this
    // doesn't really make sense when x goes right and z goes 'down'
    // when looked at from above, ie: the axes are inverted from our
    // normal trig cartesian plane.
    // Either way, we want our dir-based rotation to be clockwise.
    //private static final Quatd[] ROT = new Quatd[] {
    //        new Quatd().fromAngles(0, 0, 0),
    //        new Quatd().fromAngles(0, -Math.PI * 0.5, 0),
    //        new Quatd().fromAngles(0, -Math.PI, 0),
    //        new Quatd().fromAngles(0, -Math.PI * 1.5, 0)
    //    };
    // Defined these centrally on the Direction class now.

    public static int rotateIndex( int index, int dirDelta ) {
        // Convert from dir to cardinal direction
        Direction dir = Direction.values()[index];
        dir = dir.rotate(dirDelta);
        return dir.ordinal();
    }

    /**
     *  Rotates the specified block-corner relative point
     *  around the center yAxis by dirDelta * 90 degrees.
     */
    public static Vec3d rotatePos( Vec3d v, int dirDelta ) {
        dirDelta = dirDelta % 4;
        if( dirDelta < 0 ) {
            dirDelta += 4;
        }
        v = v.subtract(0.5, 0.5, 0.5);
        v = Direction.getRotation(dirDelta).mult(v, v);
        return v.addLocal(0.5, 0.5, 0.5);
    }

    public static Vec3d rotateDir( Vec3d v, int dirDelta ) {
        dirDelta = dirDelta % 4;
        if( dirDelta < 0 ) {
            dirDelta += 4;
        }
        return Direction.getRotation(dirDelta).mult(v);
    }

    public static float[] rotatePos( float[] vecs, int dirDelta ) {
        if( vecs == null ) {
            return null;
        }
        dirDelta = dirDelta % 4;
        if( dirDelta < 0 ) {
            dirDelta += 4;
        }
        Vec3d v = new  Vec3d();
        float[] result = new float[vecs.length];
        for( int i = 0; i < vecs.length; i += 3 ) {
            v.set(vecs[i], vecs[i+1], vecs[i+2]);
            v = v.subtractLocal(0.5, 0.5, 0.5);
            v = Direction.getRotation(dirDelta).mult(v, v);
            v.addLocal(0.5, 0.5, 0.5);
            result[i] = (float)round(v.x, 1000);
            result[i+1] = (float)round(v.y, 1000);
            result[i+2] = (float)round(v.z, 1000);
        }
        return result;
    }

    public static float[] rotateDir( float[] vecs, int dirDelta ) {
        if( vecs == null ) {
            return null;
        }
        dirDelta = dirDelta % 4;
        if( dirDelta < 0 ) {
            dirDelta += 4;
        }
        Vec3d v = new  Vec3d();
        float[] result = new float[vecs.length];
        for( int i = 0; i < vecs.length; i += 3 ) {
            v.set(vecs[i], vecs[i+1], vecs[i+2]);
            v = Direction.getRotation(dirDelta).mult(v, v);
            result[i] = (float)round(v.x, 1000);
            result[i+1] = (float)round(v.y, 1000);
            result[i+2] = (float)round(v.z, 1000);
        }
        return result;
    }

    public static float[] rotateUvs( float[] texes, int vertCount, Direction dir, int dirDelta ) {
        if( texes == null ) {
            return null;
        }
        float[] result = texes.clone();
        if( dirDelta == 0 || vertCount == 0 ) {
            return result;
        }
        switch( dir ) {
            case North:
            case South:
            case East:
            case West:
                return result;
            case Down:
                // Rotate that opposit way for down because we
                // are looking at the texture from bottom up
                dirDelta = -dirDelta;
                break;
        }
        dirDelta = dirDelta % 4;
        if( dirDelta < 0 ) {
            dirDelta += 4;
        }
        Vec3d v = new  Vec3d();
        // Account for 2 and 3 element texture coordinates.  We ignore
        // the third element as it would have been cloned above and
        // should not be rotated (at least for what we plan to use it for: layers)
        int step = texes.length / vertCount;
        for( int i = 0; i < texes.length; i += step ) {
            v.set(texes[i]-0.5, 0, texes[i+1]-0.5);
            v = Direction.getRotation(dirDelta).mult(v, v);
            v.addLocal(0.5, 0, 0.5);
            result[i] = (float)round(v.x, 1000);
            result[i+1] = (float)round(v.z, 1000);
        }

        return result;
    }

    public static float round( float f, float scale ) {
        return (float)(Math.round(f * scale)/scale);
    }

    public static float round( double d, double scale ) {
        return (float)(Math.round(d * scale)/scale);
    }

    // For lack of a better place
    public static void carveTextureCoordinates( Node model, float scale ) {
        carveTextureCoordinates(model, scale, Geometry -> true);
    }

    public static void carveTextureCoordinates( Node model, float scale, Predicate<Geometry> include ) {
        model.depthFirstTraversal(new SceneGraphVisitorAdapter() {
                @Override
                public void visit( Geometry geom ) {
                    if( include.test(geom) ) {
                        carveTextureCoordinates(geom.getMesh(), scale);
                    }
                }
            });
    }

    public static boolean carveTextureCoordinates( Mesh mesh, float scale ) {
        // For each vertex, we'll adjust its texture
        // coordinate to be based on position.  For textures
        // with no built in repeats, this is straight forward
        // as the uv can be considered percentages of the block
        // space... and so the sub-block position probably matches.
        //
        // It potentially gets a little complicated for byte-based
        // UVs if we need more precision.
        VertexBuffer tVb = mesh.getBuffer(Type.TexCoord);
        if( tVb == null ) {
            log.warn("No uv buffer, skipping carving of mesh:" + mesh);
            return false;
        }
        VertexBuffer pVb = mesh.getBuffer(Type.Position);

        // Only carve things that look like what we expect
        if( !(pVb.getData() instanceof FloatBuffer) ) {
            log.warn("Pos buffer mismatch, Skipping carving of mesh:" + mesh);
            return false;
        }
        if( !(tVb.getData() instanceof FloatBuffer) ) {
            log.warn("UV buffer mismatch, Skipping carving of mesh:" + mesh);
            return false;
        }
        if( pVb.getNumComponents() != 3 || tVb.getNumComponents() != 2 ) {
            log.warn("Components count mismatch, Skipping carving of mesh:" + mesh);
            return false;
        }

        FloatBuffer pb = (FloatBuffer)pVb.getData();
        pb.rewind();
        FloatBuffer tb = (FloatBuffer)tVb.getData();
        tb.rewind();

        ByteBuffer dirB = null;
        FloatBuffer normB = null;
        VertexBuffer nVb = mesh.getBuffer(Type.Normal);
        VertexBuffer dirVb = mesh.getBuffer(Type.Size);
        if( nVb == null && dirVb != null ) {
            dirB = (ByteBuffer)dirVb.getData();
        } else if( nVb != null ) {
            normB = (FloatBuffer)nVb.getData();
        }
        if( dirB == null && normB == null ) {
            // Can't interpret position for uvs without direction
            log.warn("No normal buffer, skipping carving of mesh:" + mesh);
            return false;
        }

        if( log.isTraceEnabled() ) {
            log.trace("pVb elements:" + pVb.getNumElements() + "  components:" + pVb.getNumComponents());
            log.trace("tVb elements:" + tVb.getNumElements() + "  components:" + tVb.getNumComponents());
        }

        Direction[] dirs = Direction.values();

        int count = pVb.getNumElements();
        int basePos = 0;
        int baseUv = 0;
        int baseNorm = 0;
        for( int i = 0; i < count; i++ ) {
            float x = pb.get(basePos);
            float y = pb.get(basePos + 1);
            float z = pb.get(basePos + 2);

            float nx;
            float ny;
            float nz;
            if( dirB != null ) {
                byte d = dirB.get(baseNorm);
                Vec3i dir = dirs[d].getVec3i();
                nx = dir.x;
                ny = dir.y;
                nz = dir.z;
            } else {
                nx = normB.get(baseNorm);
                ny = normB.get(baseNorm + 1);
                nz = normB.get(baseNorm + 2);
            }

            float u = tb.get(baseUv);
            float v = tb.get(baseUv + 1);

            float left = x;
            float up = z;
            if( Math.abs(ny) < 0.7072 ) {
                // Predominantly sideways
                up = y;
                if( Math.abs(nz) < 0.7072 ) {
                    // Predominantly zy instead of xy
                    left = z;
                }
            }
            u = left * scale;
            v = up * scale;

            tb.put(baseUv, u);
            tb.put(baseUv + 1, v);

            basePos += 3;
            baseUv += 2;
            if( dirB != null ) {
                baseNorm++;
            } else {
                baseNorm += 3;
            }
        }

        pb.rewind();
        tb.rewind();

        tVb.updateData(tb);

        return true;
    }
}


