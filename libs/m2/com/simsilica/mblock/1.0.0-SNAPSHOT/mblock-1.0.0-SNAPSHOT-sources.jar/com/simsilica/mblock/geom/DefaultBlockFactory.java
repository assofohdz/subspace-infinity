/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.Arrays;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;


/**
 *  A default BlockFactory implementation that uses a set of
 *  optional PartFactories for each of the directions and
 *  the 'inside'.  Face factories are simply called based on
 *  the direction and the current side mask at creation time.
 *
 *  @author    Paul Speed
 */
public class DefaultBlockFactory implements BlockFactory {

    static final long serialVersionUID = 42L;

    static Logger log = LoggerFactory.getLogger(DefaultBlockFactory.class);

public static boolean debug = false;

    private final PartFactory[] dirParts;
    private PartFactory internalParts;
    private final boolean allSolid;
    private final boolean[] solid;
    private final double[] transparency;
    private final boolean isTransparent;
    private final double volume;
    private final Vec3d min;
    private final Vec3d max;
    //private Collider collider;

    /**
     *  Creates a fully specified DefaultBlockFactory with the supplied parameters.
     *  If the solid[] array is null then all directions are considered solid.
     *  If the transparency array is null then all directions are considered
     *  transparency = 0, ie: fully opaque.
     */
    public DefaultBlockFactory( PartFactory[] dirParts, PartFactory internalParts,
                                boolean[] solid, double[] transparency, double volume,
                                Vec3d min, Vec3d max ) {
        if( transparency != null && transparency.length != 6 ) {
            throw new IllegalArgumentException("Transparency array should be 6 elements");
        }
        if( solid != null && solid.length != 6 ) {
            throw new IllegalArgumentException("Solid array should be 6 elements");
        }
        this.dirParts = dirParts;
        this.internalParts = internalParts;
        this.solid = solid;
        this.transparency = transparency;
        this.volume = volume;
        this.min = min;
        this.max = max;
        boolean all = true;
        if( solid != null ) {
            for( boolean b : solid ) {
                if( !b ) {
                    all = false;
                }
            }
        }
        this.allSolid = all;
        if( transparency == null ) {
            this.isTransparent = false;
        } else {
            this.isTransparent = (transparency[0] + transparency[1] + transparency[2]
                                 + transparency[3] + transparency[4] + transparency[5]) != 0;
        }
    }

    /**
     *  Constructs a block factory that creates a regular cube with the overall specified
     *  transparency.  It is assumed that all of the part factories are full size and that
     *  the min is 0,0,0 and the max is 1,1,1, etc.
     */
    public static DefaultBlockFactory createCube( double transparency, PartFactory... dirParts ) {
        if( dirParts.length != Direction.values().length ) {
            throw new IllegalArgumentException("Incorrect number of part factories:" + dirParts.length + ", requires:" + Direction.values().length);
        }
        double[] trans = null;
        if( transparency != 0 ) {
            trans = new double[] {transparency, transparency, transparency, transparency, transparency, transparency};
        }
        return new DefaultBlockFactory(dirParts, null, null, trans, 1,
                                       new Vec3d(0, 0, 0), new Vec3d(1, 1, 1));
    }

    /**
     *  Constructs a block factory that creates a regular cube with the overall specified
     *  transparency and PartFactories created by calling DefaultPartFactory.createFace()
     *  all using the specified material type.
     */
    public static DefaultBlockFactory createCube( double transparency, MaterialType materialType ) {
        return createCube(transparency,
                          DefaultPartFactory.createCubeFace(materialType, Direction.North),
                          DefaultPartFactory.createCubeFace(materialType, Direction.South),
                          DefaultPartFactory.createCubeFace(materialType, Direction.East),
                          DefaultPartFactory.createCubeFace(materialType, Direction.West),
                          DefaultPartFactory.createCubeFace(materialType, Direction.Up),
                          DefaultPartFactory.createCubeFace(materialType, Direction.Down));
    }

    /**
     *  Constructs a block factory that creates a regular cube with the overall specified
     *  transparency and PartFactories created by calling DefaultPartFactory.createFace()
     *  with each of the specified material types.
     */
    public static DefaultBlockFactory createCube( double transparency, MaterialType... materialTypes ) {
        return createCube(transparency,
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.North.ordinal()],
                                                            Direction.North),
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.South.ordinal()],
                                                            Direction.South),
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.East.ordinal()],
                                                            Direction.East),
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.West.ordinal()],
                                                            Direction.West),
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.Up.ordinal()],
                                                            Direction.Up),
                          DefaultPartFactory.createCubeFace(materialTypes[Direction.Down.ordinal()],
                                                            Direction.Down));
    }

    /**
     *  Constructs a new block factory, calculating the min/max, volume, transparency, and
     *  solid values based on the supplied part factories.
     */
    public static DefaultBlockFactory create( PartFactory[] dirParts, PartFactory internalParts ) {
        return create(dirParts, internalParts, null);
    }

    /**
     *  Constructs a new block factory, calculating the min/max, volume, and
     *  solid values based on the supplied part factories.
     */
    public static DefaultBlockFactory create( PartFactory[] dirParts, PartFactory internalParts, double[] transparency ) {

        if( dirParts == null && internalParts == null ) {
            throw new IllegalArgumentException("dirParts and internalParts cannot both be null");
        }

        boolean[] solid = new boolean[Direction.values().length];
        double[] newTrans = transparency == null ? new double[] {1, 1, 1, 1, 1, 1} : null;

        Vec3d min = new Vec3d(100, 100, 100);  // just needs to be relatively big
        Vec3d max = new Vec3d(-100, -100, -100); // just needs to be relatively small

        if( dirParts != null ) {
            for( Direction dir : Direction.values() ) {
                PartFactory face = dirParts[dir.ordinal()];
                if( face == null ) {
                    continue;
                }
                min.minLocal(face.getMin());
                max.maxLocal(face.getMax());
                BoundaryShape shape = face.getBoundaryShape();
                double area = shape.getArea();
                if( area >= 1 ) {
                    solid[dir.ordinal()] = true;
                }

                if( newTrans != null ) {
                    double t = Math.max(0, 1 - area);
                    int d = dir.ordinal();
                    newTrans[d] = Math.min(newTrans[d], t);
                }
            }
            int count = 0;
            for( double d : newTrans ) {
                if( d > 0 ) {
                    count++;
                }
            }
            if( count == 0 ) {
                newTrans = null;
            }
        }

        if( internalParts != null ) {
            min.minLocal(internalParts.getMin());
            max.maxLocal(internalParts.getMax());
        }

        double x = max.x - min.x;
        double y = max.y - min.y;
        double z = max.z - min.z;

        double volume = x * y * z;

        return new DefaultBlockFactory(dirParts, internalParts, solid,
                                       newTrans != null ? newTrans : transparency,
                                       volume, min, max);
    }

    public PartFactory[] getDirParts() {
        return dirParts;
    }

    public void setInternalParts( PartFactory internalParts ) {
        this.internalParts = internalParts;
    }

    public PartFactory getInternalParts() {
        return internalParts;
    }

    @Override
    public int addGeometryToBuffer( GeomPartBuffer buffer, int i, int j, int k,
                                    int xWorld, int yWorld, int zWorld,
                                    int sideMask,
                                    CellData cells,
                                    BlockType type ) {

        int count = 0;

        if( dirParts != null ) {
            for( Direction dir : Direction.values() ) {
                PartFactory part = dirParts[dir.ordinal()];
                if( part == null || (sideMask & dir.getBitMask()) == 0 ) {
                    continue;
                }
if( debug ) {
    log.info("add part for:" + dir);
}
                count += part.addParts(buffer, i, j, k, xWorld, yWorld, zWorld, type, dir);
            }
        }

        if( internalParts != null ) {
            count += internalParts.addParts(buffer, i, j, k, xWorld, yWorld, zWorld, type, null);
        }

        return count;
    }

    @Override
    public final BoundaryShape getShape( Direction dir ) {
        PartFactory factory = dirParts == null ? null : dirParts[dir.ordinal()];
        if( factory == null ) {
            return BoundaryShapes.NULL_SHAPE;
        }
        return factory.getBoundaryShape();
    }

    @Override
    public final boolean isSolid( Direction dir ) {
        return solid == null ? true : solid[dir.ordinal()];
    }

    @Override
    public final boolean isSolid() {
        return allSolid;
    }

    protected boolean[] getSolidArray() {
        return solid;
    }

    @Override
    public final double getTransparency( Direction dir ) {
        return transparency == null ? 0 : transparency[dir.ordinal()];
    }

    @Override
    public final boolean isTransparent() {
        return isTransparent;
    }

    protected double[] getTransparencyArray() {
        return transparency;
    }

    @Override
    public final double getVolume() {
        return volume;
    }

    @Override
    public final Vec3d getMin() {
        return min;
    }

    @Override
    public final Vec3d getMax() {
        return max;
    }

    @Override
    public BlockFactory rotate( int dirDelta ) {
        if( dirDelta < 0 || dirDelta > 3 ) {
            throw new IllegalArgumentException("dirDelta is out of bounds:" + dirDelta);
        }

        PartFactory[] newDirParts = null;
        if( dirParts != null ) {
            newDirParts = new PartFactory[dirParts.length];
            for( int i = 0; i < newDirParts.length; i++ ) {
                if( dirParts[i] == null ) {
                    continue;
                }
                Direction dir = Direction.values()[i];
                if( i < 4 ) {
                    // Need to swap things around
                    newDirParts[GeomUtils.rotateIndex(i, dirDelta)] = dirParts[i].rotate(dir, dirDelta);
                } else {
                    newDirParts[i] = dirParts[i].rotate(dir, dirDelta);
                }
            }
        }
        PartFactory newInternalParts = null;
        if( internalParts != null ) {
            newInternalParts = internalParts.rotate(null, dirDelta);
        }
        boolean[] newSolid = null;
        if( solid != null ) {
            newSolid = new boolean[6];
            for( int i = 0; i < 6; i++ ) {
                if( i < 4 ) {
                    newSolid[GeomUtils.rotateIndex(i, dirDelta)] = solid[i];
                } else {
                    newSolid[i] = solid[i];
                }
            }
        }
        double[] newTransparency = null;
        if( transparency != null ) {
            newTransparency = new double[6];
            for( int i = 0; i < 6; i++ ) {
                if( i < 4 ) {
                    newTransparency[GeomUtils.rotateIndex(i, dirDelta)] = transparency[i];
                } else {
                    newTransparency[i] = transparency[i];
                }
            }
        }

        Vec3d v1 = GeomUtils.rotatePos(min, dirDelta);
        Vec3d v2 = GeomUtils.rotatePos(max, dirDelta);

        Vec3d newMin = new Vec3d(v1).minLocal(v2);
        Vec3d newMax = new Vec3d(v1).maxLocal(v2);

        return new DefaultBlockFactory(newDirParts, newInternalParts, newSolid, newTransparency,
                                       volume, newMin, newMax);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        DefaultBlockFactory other = (DefaultBlockFactory)o;
        if( other.allSolid != allSolid ) {
            return false;
        }
        if( other.isTransparent != isTransparent ) {
            return false;
        }
        if( other.volume != volume ) {
            return false;
        }
        if( !Objects.equals(internalParts, other.internalParts) ) {
            return false;
        }
        if( !Objects.equals(min, other.min) ) {
            return false;
        }
        if( !Objects.equals(max, other.max) ) {
            return false;
        }
        if( !Arrays.equals(dirParts, other.dirParts) ) {
            return false;
        }
        if( !Arrays.equals(solid, other.solid) ) {
            return false;
        }
        if( !Arrays.equals(transparency, other.transparency) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(allSolid, isTransparent, volume, internalParts, min, max,
                            Arrays.hashCode(dirParts),
                            Arrays.hashCode(solid),
                            Arrays.hashCode(transparency));
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                    .add("dirParts", dirParts != null ? Arrays.asList(dirParts) : null)
                    .add("internalParts", internalParts)
                    .add("min", min)
                    .add("max", max)
                    .toString();
    }
}



