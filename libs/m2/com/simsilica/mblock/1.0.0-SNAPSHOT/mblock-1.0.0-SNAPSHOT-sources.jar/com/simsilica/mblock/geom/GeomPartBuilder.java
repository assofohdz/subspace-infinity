/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.*;

import org.slf4j.*;

import com.jme3.math.*;
import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *  Builder for more conveniently making a GeomPart
 *  from vertexes.
 *
 *  @author    Paul Speed
 */
public class GeomPartBuilder {
    static Logger log = LoggerFactory.getLogger(GeomPartBuilder.class);
    
    private MaterialType materialType;
    private PrimitiveType primitiveType = PrimitiveType.Triangles;
    
    private int dir = -1; // for auto-normal indexing where the shader calculates the normal
    private boolean floatTexCoords;
    
    private List<VertexBuilder> verts = new ArrayList<>();    
    private List<IndexBuilder> indexes = new ArrayList<>();

    private boolean hasNormals = false;
    private boolean hasTangents = false;
    private boolean hasUvs = false;
    private boolean hasColors = false;
    private boolean hasSizes = false;

    public GeomPartBuilder() {
    }
    
    public GeomPart build() {
        GeomPart part = new GeomPart(materialType, primitiveType, dir, floatTexCoords);

        for( VertexBuilder v : verts ) {
            if( v.normal != null ) {
                hasNormals = true;
            }
            if( v.tangent != null ) {
                hasTangents = true;
            }
            if( v.uv != null ) {
                hasUvs = true;
            }
            if( v.color != null ) {
                hasColors = true;
            }
            if( v.size != null ) {
                hasSizes = true;
            }
        }    
 
        float[] coords = new float[verts.size() * 3];       
        float[] normals = !hasNormals ? null : new float[verts.size() * 3];       
        float[] tangents = !hasTangents ? null : new float[verts.size() * 3];
        float[] uvs = !hasUvs ? null : new float[verts.size() * 2];
        float[] colors = !hasColors ? null : new float[verts.size() * 4];
        float[] sizes = !hasSizes ? null : new float[verts.size()];
                
        int pos = 0;
        for( VertexBuilder v : verts ) {
            int base3 = pos * 3;
            coords[base3 + 0] = (float)v.coord.x;
            coords[base3 + 1] = (float)v.coord.y;
            coords[base3 + 2] = (float)v.coord.z;
            if( v.normal != null ) {
                normals[base3 + 0] = (float)v.normal.x;
                normals[base3 + 1] = (float)v.normal.y;
                normals[base3 + 2] = (float)v.normal.z;
            }
            if( v.tangent != null ) {
                tangents[base3 + 0] = (float)v.tangent.x;
                tangents[base3 + 1] = (float)v.tangent.y;
                tangents[base3 + 2] = (float)v.tangent.z;
            }
            if( v.uv != null ) {
                int base2 = pos * 2;
                uvs[base2 + 0] = (float)v.uv[0];
                uvs[base2 + 1] = (float)v.uv[1];
            }
            if( v.color != null ) {
                int base4 = pos * 4;
                colors[base3 + 0] = (float)v.color[0];
                colors[base3 + 1] = (float)v.color[1];
                colors[base3 + 2] = (float)v.color[2];
                colors[base3 + 3] = (float)v.color[3];
            }
            if( v.size != null ) {
                sizes[pos] = (float)(double)v.size;
            }
            pos++;
        }
        part.setCoords(coords);
        part.setNormals(normals);
        part.setTangents(tangents);
        part.setTexCoords(uvs);
        part.setColors(colors);
        part.setSizes(sizes);
        
        int indexSize = 0;
        for( IndexBuilder ib : indexes ) {
            indexSize += ib.values.length;
        }
        if( indexSize > 0 ) {
            short[] buffer = new short[indexSize];
            int i = 0;
            for( IndexBuilder ib : indexes ) {
                for( int val : ib.values ) {
                    buffer[i++] = (short)(ib.base + val);
                }
            }
            part.setIndexes(buffer);
        }
        return part;
    }
 
    public IndexBuilder indexes() {
        return indexes(0);
    }

    public IndexBuilder indexes( int base ) {
        IndexBuilder ib = new IndexBuilder(base);
        indexes.add(ib);
        return ib;
    }

    public GeomPartBuilder material( MaterialType materialType ) {
        this.materialType = materialType;
        return this;
    }     

    public GeomPartBuilder direction( int dir ) {
        this.dir = dir;
        return this;
    }
    
    public GeomPartBuilder primitive( PrimitiveType primitiveType ) {
        this.primitiveType = primitiveType;
        return this;
    }
 
    public GeomPartBuilder floatTexCoords( boolean flag ) {
        this.floatTexCoords = flag;
        return this;
    }
 
    public VertexBuilder vertex( double x, double y, double z ) {
        VertexBuilder vert = new VertexBuilder(new Vec3d(x, y, z));
        verts.add(vert);
        return vert;
    }

    public int vertexCount() {
        return verts.size();
    }

    public static class IndexBuilder {
        private int base;
        private int[] values;
        
        public IndexBuilder( int base ) {
            this.base = base;
        }
        
        public IndexBuilder set( int... values ) { 
            this.values = values;
            return this;
        }
    }
    
    public static class VertexBuilder {
        private Vec3d coord;
        private Vec3d normal;
        private Vec3d tangent;
        private double[] uv;
        private double[] color;
        private Double size;
        
        public VertexBuilder( Vec3d coord ) {
            this.coord = coord;
        }
        
        public VertexBuilder normal( double x, double y, double z ) {
            this.normal = new Vec3d(x, y, z);
            return this;
        }

        public VertexBuilder tangent( double x, double y, double z ) {
            this.tangent = new Vec3d(x, y, z);
            return this;
        }

        public VertexBuilder uv( double x, double y ) {
            this.uv = new double[] { x, y };
            return this;
        }

        public VertexBuilder color( double r, double g, double b, double a ) {
            this.color = new double[] { r, g, b, a };
            return this;
        }
        
        public VertexBuilder size( double x ) {
            this.size = x;
            return this;
        }
    
        public String toString() {
            return getClass().getSimpleName() + "[coord:" + coord + ", normal:" + normal + "]";
        }
    }
}




