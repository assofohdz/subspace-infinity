/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Charsets;

import com.simsilica.mblock.BlockName;
import com.simsilica.mblock.BlockType;

/**
 *  Holds the BlockType[] array and meta-data for a block set.
 *
 *  @author    Paul Speed
 */
public class BlockTypeData implements UpdateableData<BlockTypeData> {

    public static final long formatVersion = 42L;

    static Logger log = LoggerFactory.getLogger(BlockTypeData.class);

    public int badTypeIndex;
    public BlockType[] types;

    public BlockTypeData() {
    }

    public BlockTypeData( BlockType[] types, int badTypeIndex ) {
        this.types = types;
        this.badTypeIndex = badTypeIndex;
    }

    @Override
    public boolean update( BlockTypeData update ) {
        // See if they are the same... because then we don't have to do
        // anything
        if( Arrays.asList(types).equals(Arrays.asList(update.types)) ) {
            return false;
        }
        // Something has changed

        // Note: right now because BlockType (and related classes) don't
        // really implement .equals(), this will always upgrade the blockset
        // every time.  I'm ok with that today.  2021-01-16

        // Need to lookup the bad block types now before modifying the
        // types array.  Else we might confuse an old bad index for a good index
        // into some weird imported type.
        BlockName updateBadType = null;
        if( update.badTypeIndex >= 0 && update.badTypeIndex < update.types.length ) {
            BlockType bt = update.types[update.badTypeIndex];
            updateBadType = bt != null ? bt.getName() : null;
        }
        BlockName badType = null;
        if( badTypeIndex >= 0 && badTypeIndex < types.length ) {
            BlockType bt = types[badTypeIndex];
            badType = bt != null ? bt.getName() : null;
        }

        // Build an index of the existing types by name
        Map<BlockName, BlockType> index = new HashMap<>();
        for( BlockType type : types ) {
            if( type == null ) {
                continue;
            }
            index.put(type.getName(), type);
        }

        List<BlockType> newTypes = new ArrayList<>(Arrays.asList(types));
        for( BlockType type : update.types ) {
            if( type == null ) {
                continue;
            }
            BlockType existing = index.get(type.getName());
            if( existing == null ) {
                log.info("New type:" + type.getName());
                newTypes.add(type);
                index.put(type.getName(), type);
            } else if( !Objects.equals(type, existing) ) {
                log.info("Replacing:" + existing.getName());
                int i = newTypes.indexOf(existing);
                if( i < 0 ) {
                    throw new RuntimeException("Data format error: "
                                               + "existing block type not found in type list, type:"
                                               + existing.getName());
                }
                newTypes.set(i, type);
                index.put(type.getName(), type);
            }
        }

        if( !Objects.equals(badType, updateBadType) ) {
            // Then the bad type index has changed somehow
            log.info("Updating bad type index, old type:" + badType + " new type:" + updateBadType);

            // Find the new bad type in the types
            BlockType bad = updateBadType == null ? null : index.get(updateBadType);

            badTypeIndex = newTypes.indexOf(bad);

            log.info("New bad type index:" + badTypeIndex);
        }

        this.types = newTypes.toArray(new BlockType[0]);

        return true;
    }

    public static BlockTypeData load( InputStream rawIn ) throws IOException {
        try( ObjectInputStream in = new ObjectInputStream(rawIn) ) {
            BlockTypeData result = new BlockTypeData();
            long version = in.readLong();
            try {
                result.types = (BlockType[])in.readObject();
            } catch( ClassNotFoundException e ) {
                throw new IOException("Error resolving types", e);
            }
            result.badTypeIndex = in.readInt();

            return result;
        }
    }

    public static BlockTypeData load( String resource ) throws IOException {
        java.net.URL u = BlockTypeData.class.getResource(resource);
        if( u == null ) {
            // Could try the context class loader
            return null;
        }
        return load(u.openStream());
    }

    public static BlockTypeData load( File f ) throws IOException {
        if( !f.exists() ) {
            return null;
        }
        return load(new FileInputStream(f));
    }

    public static void store( BlockTypeData data, File f ) throws IOException {
        store(data, new FileOutputStream(f));
    }

    public static void store( BlockTypeData data, OutputStream rawOut ) throws IOException {
        // Doesn't need to be particularly fast so we
        // want bother wrapping in a buffered stream.  Caller
        // can always do it if it's performance criticial.
        try( ObjectOutputStream out = new ObjectOutputStream(rawOut) ) {
            out.writeLong(formatVersion);
            out.writeObject(data.types);
            out.writeInt(data.badTypeIndex);
        }
    }

    /**
     *  Writes a text-based index file where each block type is represented
     *  as an index value followed by its block name. Like: [0] foo:bar.0
     *  This can potentially be used to reconstruct a world's block set
     *  if the world's bset file is unreadable for some reason.
     */
    public void writeIndex( File f ) throws IOException {
        FileOutputStream fOut = new FileOutputStream(f);
        try( PrintWriter out = new PrintWriter(new OutputStreamWriter(fOut,Charsets.UTF_8)) ) {
            out.println("# Generated:" + String.format("%1$tF %1$tT", new Date()));
            for( int i = 0; i < types.length; i++ ) {
                BlockType type = types[i];
                if( type == null ) {
                    continue;
                }
                out.println("[" + i + "] " + type.getName());
            }
        }
    }
}

