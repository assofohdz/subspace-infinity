/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.Arrays;
import java.util.EnumSet;

/**
 *  Enum representing the different geometry requirements that
 *  a material might have.  When matching actual material instance
 *  to part, this can be used to pick the best material.
 *
 *  @author    Paul Speed
 */
public enum GeomReq {
    
    Normals(), 
    Tangents(Normals), 
    Colors(), // for when color is not used for lighting
    Sizes(),
    LoResPositions(), 
    LoResNormals(), 
    LoResTangents(), 
    LoResTexCoords(), 
    IndexedNormals(Normals, Tangents, LoResNormals, LoResTangents);
    
    // The theory behind IndexedNormals indicating that LoResNormals
    // and LoResTangents are ok is to make sure that IndexedNormals
    // will always match "best" to materials that need IndexedNormals.
    // Otherwise, two matches with LoRes* would select over IndexedNormals.
    // And lest we worry about "but what about materials that require lores
    // stuff and a part only indicates lores because of the indexed cap"
    // ...well that's fine because a GeomPart that can have IndexedNormals
    // can also easily support lores normals... they just might have to be
    // filled in first like any other case where "Normals" requirs dir->normals
    // expansion.

    // I tried to make this a set but passing values into
    // the set on the constructor proved... difficult.
    private GeomReq[] implies = null;
    
    private GeomReq( GeomReq... implies ) {
        this.implies = implies;
    }
    
    public GeomReq[] implies() {    
        return implies;
    }
    
    /**
     *  Returns a new EnumSet that has all of the target sets reqs
     *  expanded into implied reqs.  Includes the original reqs also.
     */
    public static EnumSet<GeomReq> expandImplied( EnumSet<GeomReq> set ) {
        if( set == null || set.isEmpty() ) {
            return EnumSet.noneOf(GeomReq.class);
        }
        EnumSet<GeomReq> result = EnumSet.copyOf(set);
        for( GeomReq req : set ) {
            if( req.implies != null ) {
                result.addAll(Arrays.asList(req.implies));
            }
        }
        return result;
    } 
}


