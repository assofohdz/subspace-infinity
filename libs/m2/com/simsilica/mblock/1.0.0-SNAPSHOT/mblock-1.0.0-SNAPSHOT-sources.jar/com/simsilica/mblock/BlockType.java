/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mblock.geom.BlockFactory;
import com.simsilica.mblock.geom.BoundaryShape;

/**
 *  Information about a specific type of 'block'.
 *
 *  @author    Paul Speed
 */
public class BlockType implements java.io.Serializable {

    static final long serialVersionUID = 42L;

    public static final ColliderType DEFAULT_COLLIDER = new ColliderType("cube", -1);

    static Logger log = LoggerFactory.getLogger(BlockType.class);

    private BlockName name;
    private BlockFactory factory;
    private ColliderType colliderType;
    private Substance[] substances;

    private int group;

    /**
     *  The 4-bit each red/green/blue/sunlight value imparted by this block.
     *  Usually, 0.
     */
    private short light;

    // Cache the factory values for some things locally so
    // that we don't have to delegate all the time.
    private transient BoundaryShape[] shapes;
    private transient double[] transparency;
    private transient boolean anyTransparent;
    private transient boolean[] solid;
    private transient boolean allSolid;

    public BlockType( BlockName name, BlockFactory factory ) {
        this(name, 0, (short)0, factory, DEFAULT_COLLIDER);
    }

    public BlockType( BlockName name, BlockFactory factory, ColliderType colliderType ) {
        this(name, 0, (short)0, factory, colliderType);
    }

    public BlockType( BlockName name, int group, BlockFactory factory ) {
        this(name, group, (short)0, factory, DEFAULT_COLLIDER);
    }

    public BlockType( BlockName name, int group, BlockFactory factory, ColliderType colliderType ) {
        this(name, group, (short)0, factory, colliderType);
    }

    public BlockType( BlockName name, int group, short light, BlockFactory factory ) {
        this(name, group, light, factory, DEFAULT_COLLIDER);
    }

    public BlockType( BlockName name, int group, short light, BlockFactory factory, ColliderType colliderType ) {
        this.name = name;
        this.group = group;
        this.light = light;
        this.factory = factory;
        this.colliderType = colliderType;
        cacheSideData();
    }

    public void cacheSideData() {
        this.anyTransparent = factory.isTransparent();
        this.allSolid = factory.isSolid();
        int size = Direction.values().length;
        this.shapes = new BoundaryShape[size];
        this.transparency = new double[size];
        this.solid = new boolean[size];
        for( Direction dir : Direction.values() ) {
            int index = dir.ordinal();
            shapes[index] = factory.getShape(dir);
            transparency[index] = factory.getTransparency(dir);
            solid[index] = factory.isSolid(dir);
        }
    }

    public void setName( BlockName name ) {
        this.name = name;
    }

    public final BlockName getName() {
        return name;
    }

    public void setFactory( BlockFactory factory ) {
        this.factory = factory;
        cacheSideData();
    }

    public final BlockFactory getFactory() {
        return factory;
    }

    public void setColliderType( ColliderType colliderType ) {
        this.colliderType = colliderType;
    }

    public final ColliderType getColliderType() {
        return colliderType;
    }

    public void setSubstances( Substance... substances ) {
        this.substances = substances;
    }

    public Substance[] getSubstances() {
        return substances;
    }

    public final BoundaryShape getShape( Direction dir ) {
        return shapes[dir.ordinal()];
    }

    /**
     *  Returns true if the specified direction is a full
     *  solid face.  The side may be solid but still have
     *  transparency.  This is used by masking to quickly discard
     *  invisible faces.
     */
    public final boolean isSolid( Direction dir ) {
        return solid[dir.ordinal()];
    }

    public final boolean isSolid() {
        return allSolid;
    }

    /**
     *  Returns the transparency value for the specified direction
     *  where 0 is fully opaque and 1 is fully transparent.  Note that
     *  by default, block factories will tend to fake some amount of
     *  transparency for partial blocks.  This was so that they attenuate
     *  light more than a fully open side... but it creates visually
     *  anomolies and it may not always be true.
     *  Bottom line: isSolid(dir) controls side masking and
     *  getTransparency(dir) controls light attenuation out of the
     *  block in that direction.  (Blocks are considered fully lit
     *  with whatever light entered them so that we don't double
     *  atennuate and because the blocks that want special behavior
     *  can always implement that directly without automatic
     *  attenuation [ie: darkening themselves a little])
     */
    public final double getTransparency( Direction dir ) {
        return transparency[dir.ordinal()];
    }

    public final boolean isTransparent() {
        return anyTransparent;
    }

    /**
     *  The transparency group is used to control when a surface-to-surface
     *  shape is shown or hidden, generally for semi-transparent
     *  blocks.  Objects in the same group will have their 'in between'
     *  faces hidden while still emitting shapes that abutt other block
     *  type groups.  (For example, glass blocks.)  -1 is a special group that
     *  will always emit its faces even when abutting its own types.  (For
     *  example, leaf blocks.)
     */
    public void setTransparencyGroup( int group ) {
        this.group = group;
    }

    public final int getTransparencyGroup() {
        return group;
    }

    public void setLight( short light ) {
        this.light = light;
    }

    public final short getLight() {
        return light;
    }

    /**
     *  Used at blockset definition time to create a rotated version of
     *  this block type.  This is not really a 'game time' method but was
     *  too convenient not to put here... plus this way the factory implementations
     *  get to decide if they need special rotation handling.
     */
    public BlockType createRotation( int dirDelta ) {
        BlockType result = new BlockType(name.rotate(dirDelta), group, light, factory.rotate(dirDelta));
        if( colliderType != null ) {
            result.colliderType = colliderType.rotate(dirDelta);
        }
        result.cacheSideData();
        return result;
    }

    private void readObject( ObjectInputStream in ) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        cacheSideData();
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        BlockType other = (BlockType)o;
        if( other.group != group ) {
            return false;
        }
        if( other.light != light ) {
            return false;
        }
        if( !Objects.equals(name, other.name) ) {
            return false;
        }
        if( !Objects.equals(factory, other.factory) ) {
            return false;
        }
        if( !Objects.equals(colliderType, other.colliderType) ) {
            return false;
        }
        if( !Arrays.deepEquals(substances, other.substances) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, factory, colliderType, group, light, Arrays.deepHashCode(substances));
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("name", name)
                .add("factory", factory)
                .add("colliderType", colliderType)
                .add("transparencyGroup", group)
                .add("light", Integer.toHexString(light))
                .toString();
    }
}
