/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.util.Arrays;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidUtils {
    static Logger log = LoggerFactory.getLogger(FluidUtils.class);

    public static final int TYPE_MASK  = 0x0000001f; // 5 bits (up to 31 fluid types)

    public static final int LEVEL_BITS = 0b1111;
    public static final int LEVEL_MASK = LEVEL_BITS << 5; //0x000001E0; // 4 bits

    public static final int SIDE_MASK_BITS = 0x3f;
    public static final int SIDE_MASK  = SIDE_MASK_BITS << 26;

    public static final int CONNECT_MASK_BITS = 0b1111;
    public static final int CONNECT_MASK_SHIFT = 22;
    public static final int CONNECT_MASK = CONNECT_MASK_BITS << CONNECT_MASK_SHIFT;

    // 3 bits per corner... 12 bits.
    // Each corner encodes the level of that corner: 1..8 (0..7 in bits)
    public static final int SLOPE_BITS = 0b111111111111;
    public static final int SLOPE_MASK_SHIFT = 9;  // right above type + level
    public static final int SLOPE_MASK = SLOPE_BITS << SLOPE_MASK_SHIFT;

    public static int getType( int value ) {
        return value & TYPE_MASK;
    }

    public static int getLevel( int value ) {
        // The level has different meanings depending on if the type
        // is set.  If there is no type then the level is meaningless
        // and we'll return 0.  Else the range 0...7 actually corresponds
        // to 1..8
        if( getType(value) > 0 ) {
            return getRawLevel(value) + 1;
        }
        return 0;
    }

    public static int getRawLevel( int value ) {
        //return (value & LEVEL_MASK) >> 5;
        return (value >> 5) & LEVEL_BITS;
    }

    public static int setLevel( int value, int level ) {
        level = Math.max(0, level - 1);
        return (value & (~LEVEL_MASK)) | (level << 5);
    }

    public static int getSlopeBits( int value ) {
        return (value & SLOPE_MASK) >> SLOPE_MASK_SHIFT;
    }

    public static int setSlopeBits( int value, int slopeBits ) {
        return (value & (~SLOPE_MASK)) | (slopeBits << SLOPE_MASK_SHIFT);
    }

    public static int getSideMask( int value ) {
        return (value >> 26) & SIDE_MASK_BITS;
    }

    public static int setSideMask( int value, int sideMask ) {
        return (value & (~SIDE_MASK)) | (sideMask << 26);
    }

    public static int getConnectMask( int value ) {
        return (value >> CONNECT_MASK_SHIFT) & CONNECT_MASK_BITS;
    }

    public static int setConnectMask( int value, int connectMask ) {
        return (value & (~CONNECT_MASK)) | (connectMask << CONNECT_MASK_SHIFT);
    }

    private static final int D_NW = 0;
    private static final int D_N = 1;
    private static final int D_NE = 2;
    private static final int D_E = 3;
    private static final int D_SE = 4;
    private static final int D_S = 5;
    private static final int D_SW = 6;
    private static final int D_W = 7;

    public static void calculateFluidSlopes( CellArray fluid, CellArray blocks ) {
        calculateFluidSlopes(fluid, blocks, 0, 0, 0, fluid.getSizeX(), fluid.getSizeY(), fluid.getSizeZ());
    }

    /**
     *  Takes the raw fluid data and recalculates the slope/flow information
     *  based on the relative levels of adjacent blocks.
     */
    public static void calculateFluidSlopes( CellData fluid, CellData blocks, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd ) {
        if( log.isTraceEnabled() ) {
            log.trace("calculateFluidSlopes(" + xStart + ", " + yStart + ", " + zStart + ", " + xEnd + ", " + yEnd + ", " + zEnd + ")");
        }
        int[] neighbors = new int[8];  // clockwise from nw

        FluidSlope slope = new FluidSlope(); // we'll reuse it

        for( int x = xStart; x < xEnd; x++ ) {
            for( int y = yStart; y < yEnd; y++ ) {
                for( int z = zStart; z < zEnd; z++ ) {
                    int val = fluid.getCell(x, y, z);
                    int type = getType(val);
                    if( type == 0 ) {
                        // For fluids, we treat them all as full blocks even
                        // if they aren't really... so we get away without having
                        // to look up the fluid type itself
                        continue;
                    }
                    int sides = getSideMask(val);
                    int connectMask = getConnectMask(val);
                    int level = calculateLevel(val);
                    if( log.isTraceEnabled() ) {
                        log.trace("sides:" + Integer.toBinaryString(sides) + "  connect:" + Integer.toBinaryString(connectMask)
                                        + "  level:" + level);
                    }

                    // If the level is 8 and we would not be rendering a top anyway
                    // then force all corners to 8 and we're done.  calculateLevel()
                    // indicates this condition by returning 9.
                    if( level == 9 ) {
                        slope.nw = 8;
                        slope.ne = 8;
                        slope.se = 8;
                        slope.sw = 8;
                        if( log.isTraceEnabled() ) {
                            log.trace("  capped nw:" + slope.nw + "   ne:" + slope.ne + "  se:" + slope.se + "   sw:" + slope.sw);
                        }
                        val = setSlopeBits(val, slope.getBits());
                        fluid.setCell(x, y, z, val);
                        continue;
                    }

                    // A corner's level will be based on the adjacent fluid
                    // levels that are 'connected' reachable.  For the cardinal
                    // directions, this is easy to determine with the connectivity
                    // masks.  For the diagonals, we must first check the two cardinal
                    // directions and then see if either of those can reach the diagonal.
                    //
                    // We'll keep the values we find in a "neighbors" array.
                    // -1 will indicate a value that should be ignored as not reachable.
                    // 0 will indicate connected but no fluid
                    // 1..8 will indicate a fluid level that should be averaged with
                    // the rest.
                    // 9 will indicate a forced max level.
                    //
                    // Until we know reachability, all neighbors are 'blocked'
                    Arrays.fill(neighbors, -1);


                    if( DirectionMasks.hasNorth(connectMask) ) {
                        int dirValue = fluid.getCell(x, y, z, Direction.North, 0);
                        neighbors[D_N] = calculateLevel(dirValue);
                        int dirConnect = getConnectMask(dirValue);
                        if( DirectionMasks.hasWest(dirConnect) ) {
                            neighbors[D_NW] = calculateLevel(fluid.getCell(x - 1, y, z - 1, 0));
                        }
                        if( DirectionMasks.hasEast(dirConnect) ) {
                            neighbors[D_NE] = calculateLevel(fluid.getCell(x + 1, y, z - 1, 0));
                        }
                    }

                    if( DirectionMasks.hasSouth(connectMask) ) {
                        int dirValue = fluid.getCell(x, y, z, Direction.South, 0);
                        neighbors[D_S] = calculateLevel(dirValue);
                        int dirConnect = getConnectMask(dirValue);
                        if( DirectionMasks.hasWest(dirConnect) ) {
                            neighbors[D_SW] = calculateLevel(fluid.getCell(x - 1, y, z + 1, 0));
                        }
                        if( DirectionMasks.hasEast(dirConnect) ) {
                            neighbors[D_SE] = calculateLevel(fluid.getCell(x + 1, y, z + 1, 0));
                        }
                    }

                    if( DirectionMasks.hasEast(connectMask) ) {
                        int dirValue = fluid.getCell(x, y, z, Direction.East, 0);
                        neighbors[D_E] = calculateLevel(dirValue);
                        int dirConnect = getConnectMask(dirValue);
                        // I believe that the check for existing neighbors[] will be
                        // faster than looking up the corner again
                        if( DirectionMasks.hasNorth(dirConnect) && neighbors[D_NE] == -1 ) {
                            neighbors[D_NE] = calculateLevel(fluid.getCell(x + 1, y, z - 1, 0));
                        }
                        if( DirectionMasks.hasSouth(dirConnect) && neighbors[D_SE] == -1 ) {
                            neighbors[D_SE] = calculateLevel(fluid.getCell(x + 1, y, z + 1, 0));
                        }
                    }

                    if( DirectionMasks.hasWest(connectMask) ) {
                        int dirValue = fluid.getCell(x, y, z, Direction.West, 0);
                        neighbors[D_W] = calculateLevel(dirValue);
                        int dirConnect = getConnectMask(dirValue);
                        if( DirectionMasks.hasNorth(dirConnect) && neighbors[D_NW] == -1 ) {
                            neighbors[D_NW] = calculateLevel(fluid.getCell(x - 1, y, z - 1, 0));
                        }
                        if( DirectionMasks.hasSouth(dirConnect) && neighbors[D_SW] == -1 ) {
                            neighbors[D_SW] = calculateLevel(fluid.getCell(x - 1, y, z + 1, 0));
                        }
                    }

                    if( log.isTraceEnabled() ) {
                        log.trace("Neighbors:" + Arrays.toString(neighbors));
                    }

                    // Now calculate the corner values based on the neighbor influences.
                    int nw = calculateCorner(level, neighbors[D_NW], neighbors[D_W], neighbors[D_N]);
                    int ne = calculateCorner(level, neighbors[D_NE], neighbors[D_E], neighbors[D_N]);
                    int se = calculateCorner(level, neighbors[D_SE], neighbors[D_E], neighbors[D_S]);
                    int sw = calculateCorner(level, neighbors[D_SW], neighbors[D_W], neighbors[D_S]);

                    if( log.isTraceEnabled() ) {
                        log.trace("  offsets nw:" + nw + "   ne:" + ne + "  se:" + se + "   sw:" + sw);
                    }

                    slope.nw = nw;
                    slope.ne = ne;
                    slope.se = se;
                    slope.sw = sw;

                    val = setSlopeBits(val, slope.getBits());
                    fluid.setCell(x, y, z, val);
                }
            }
        }
    }

    /**
     *  Returns true if the specified block cell is 'blocked' in the direction
     *  specified.  Essentially, is there something sitting in that corner
     *  that would prevent fluid adjoinment.
     */
    private static boolean isBlocked( int blockCell, Direction dir1, Direction dir2 ) {
        // For now we will just look for full faces
        BlockType type = MaskUtils.getBlockType(blockCell);
        if( type == null ) {
            return false;
        }
        // Note: we do an OR here figuring that if some part of the corner
        // is filled then we won't adjoin fluids.  It could turn out that
        // we want a better check here.
        if( type.isSolid(dir1) ) {
            return true;
        }
        if( type.isSolid(dir2) ) {
            return true;
        }
        // Someday we will probably also want to check for partial sides
        // that are indicent with the corner.  For now we won't. 2022-01-24
        return false;
    }

    private static boolean isBlocked( BlockType type, Direction dir ) {
        // For now we will just look for full faces
        if( type == null ) {
            return false;
        }
        return type.isSolid(dir);
    }

    /**
     *  Returns 0..9 where 0 = no water, 1..8 = proper water level,
     *  9 = full block without top being rendered.
     */
    private static int calculateLevel( int fluidValue ) {
        if( getType(fluidValue) == 0 ) {
            return 0;
        }
        int level = getRawLevel(fluidValue) + 1;
        if( level < 8 ) {
            return level;
        }
        int masks = getSideMask(fluidValue);
        if( !DirectionMasks.hasUp(masks) ) {
            // Special indicator that we cannot lower this corner
            return 9;
        }
        return 8;
    }

    private static int calculateCorner( int level, int... neighbors ) {
        if( log.isTraceEnabled() ) {
            log.trace("calculateCorner(" + level + ", " + Arrays.toString(neighbors) + ")");
        }
        if( level == 9 ) {
            return 8;
        }
        // Find the average of the real heights and make that the corner level
        int total = level;
        int count = 1;
        int min = 8;
        for( int i : neighbors ) {
            if( i == 9 ) {
                return 8;
            }
            if( i >= 0 ) {
                // This is lieu of early-out on finding a 0 because any 9's
                // should trump a zero.  So we can early-out for 9 but we have
                // to check all directions just in case another one is a 9...
                // and can't early-out the first 0 we find.
                if( i < min ) {
                    min = i;
                }
                total += i;
                count++;
            }
        }
        if( log.isTraceEnabled() ) {
            log.trace("  min:" + min + "  total:" + total + "  count:" + count + "  avg:" + (int)Math.round((double)total/count));
        }
        if( min == 0 ) {
            return 1;
        }
        if( count == 1 ) {
            return level; // we are an island
        }
        int avg = (int)Math.round((double)total/count);
        return Math.max(1, avg);
    }

    public static void recalculateSideMasks( CellData fluid, CellData blocks, int x, int y, int z, int defaultBorder ) {

        // For now we'll do it the brute-force way and just recalculate
        // the whole neighborhood around the cell.
        // Note: end coordinates are exclusive which is why we +2 them.
        int minY = Math.max(0, y - 1);
        int maxY = y + 2; // FIXME: clamp to top of the world?
        FluidUtils.calculateSideMasks(fluid, blocks,
                                      x - 1, minY, z - 1,
                                      x + 2, maxY, z + 2);
        FluidUtils.calculateFluidSlopes(fluid, blocks,
                                      x - 1, minY, z - 1,
                                      x + 2, maxY, z + 2);
    }

    // We do the above brute-force version which should be fast enough for
    // the time being.  About equivalent in the worst case, I guess.
    // FIXME: implement optimimzed FluidUtils.recalculateSideMasks()
    private static void unfinishedRecalculateSideMasks( CellData fluid, CellData blocks, int x, int y, int z, int defaultBorder ) {
        if( log.isTraceEnabled() ) {
            log.trace("recalculateSideMasks(" + x + ", " + y + ", " + z + ")");
        }
        int val = fluid.getCell(x, y, z, -1);
        if( val == -1 ) {
            throw new IllegalArgumentException("Recalculating masks for invalid cell location:" + x + ", " + y + ", " + z);
        }

        int sideMask = 0;
        int connectMask = 0;

        int type = getType(val);
        if( type == 0 ) {
            // For fluids, we treat them all as full blocks even
            // if they aren't really... so we get away without having
            // to look up the fluid type itself
            // So we just need to zero out the masks.
            sideMask = 0;
            connectMask = 0;
        } else {
            int level = getLevel(val);
            if( log.isTraceEnabled() ) {
                log.trace("[" + x + "][" + y + "][" + z + "] = " + type + "  level:" + level);
            }

            int blockValue = blocks.getCell(x, y, z);
            BlockType block = MaskUtils.getBlockType(blockValue);

            // Calculate the mask right here
            for( Direction dir : Direction.values() ) {
                int nextVal = fluid.getCell(x, y, z, dir, 0);
                int next = getType(nextVal);
                if( log.isTraceEnabled() ) {
                    log.trace("  " + dir + "  " + next);
                }

                BlockType neighbor = MaskUtils.getBlockType(blocks.getCell(x, y, z, dir, 0));

                boolean connected = isConnected(level, block, neighbor, dir);
                if( log.isTraceEnabled() ) {
                    log.trace("   dir:" + dir + "  connected:" + connected);
                }
                if( connected ) {
                    // Then we definitely emit a side if there is not the same fluid
                    // in the cells or in the case of up/down if the level isn't full
                    if( next != type
                        || (dir == Direction.Up && level < 8)
                        || (dir == Direction.Down && getLevel(nextVal) < 8) ) {
                        sideMask = sideMask | dir.getBitMask();
                    }

                    // Only keep connect masks for cardinal directions
                    if( dir.isCardinal() ) {
                        connectMask = connectMask | dir.getBitMask();
                    }
                } else {
                    // There is no connectivity but we might still have a visible side

                    // If the direction doesn't even connect then the only case where
                    // we would emit a side is for a transparent side... in either
                    // direction or reverse direction.
                    if( block != null && block.getTransparency(dir) <= 0 ) {
                        // Opaque
                    } else if( neighbor != null && neighbor.getTransparency(dir) <= 0 ) {
                        // Opaque
                    } else {
                        // Transparent on some level
                        // We don't connect but we should emit a side
                        sideMask = sideMask | dir.getBitMask();
                    }
                }

                // Here we can check if we changed the side mask and then recalculate
                // the neighbor
            }
        }

        int newVal = setSideMask(val, sideMask);
        newVal = setConnectMask(newVal, connectMask);
        fluid.setCell(x, y, z, newVal);
    }


    public static void calculateSideMasks( CellArray fluid, CellArray blocks ) {
        calculateSideMasks(fluid, blocks, fluid.getSizeX(), fluid.getSizeY(), fluid.getSizeZ());
    }

    public static void calculateSideMasks( CellData fluid, CellData blocks, int size ) {
        calculateSideMasks(fluid, blocks, size, size, size);
    }

    public static int calculateSideMasks( CellData fluid, CellData blocks, int xSize, int ySize, int zSize ) {
        return calculateSideMasks(fluid, blocks, 0, 0, 0, xSize, ySize, zSize);
    }

    public static int calculateSideMasks( CellData fluid, CellData blocks, int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd ) {

        int sideCount = 0;
        for( int x = xStart; x < xEnd; x++ ) {
            for( int y = yStart; y < yEnd; y++ ) {
                for( int z = zStart; z < zEnd; z++ ) {
                    int val = fluid.getCell(x, y, z);
                    int type = getType(val);
                    if( type == 0 ) {
                        // For fluids, we treat them all as full blocks even
                        // if they aren't really... so we get away without having
                        // to look up the fluid type itself
                        // So we just need to zero out the masks.
                        int newVal = setSideMask(val, 0);
                        newVal = setConnectMask(newVal, 0);
                        fluid.setCell(x, y, z, newVal);
                        continue;
                    }
                    int level = getLevel(val);
                    if( log.isTraceEnabled() ) {
                        log.trace("[" + x + "][" + y + "][" + z + "] = " + type + "  level:" + level);
                    }
                    int sideMask = 0;
                    int connectMask = 0;

                    int blockValue = blocks.getCell(x, y, z);
                    BlockType block = MaskUtils.getBlockType(blockValue);

                    // Calculate the mask right here
                    for( Direction dir : Direction.values() ) {
                        int nextVal = fluid.getCell(x, y, z, dir, 0);
                        int next = getType(nextVal);
                        if( log.isTraceEnabled() ) {
                            log.trace("  " + dir + "  " + next);
                        }

                        BlockType neighbor = MaskUtils.getBlockType(blocks.getCell(x, y, z, dir, 0));

                        boolean connected = isConnected(level, block, neighbor, dir);
                        if( log.isTraceEnabled() ) {
                            log.trace("   dir:" + dir + "  connected:" + connected);
                        }
                        if( connected ) {
                            // Then we definitely emit a side if there is not the same fluid
                            // in the cells or in the case of up/down if the level isn't full
                            if( next != type
                                || (dir == Direction.Up && level < 8)
                                || (dir == Direction.Down && getLevel(nextVal) < 8) ) {
                                sideMask = sideMask | dir.getBitMask();
                                sideCount++;
                            }

                            // Only keep connect masks for cardinal directions
                            if( dir.isCardinal() ) {
                                connectMask = connectMask | dir.getBitMask();
                            }
                            continue;
                        }
                        // There is no connectivity but we might still have a visible side

                        // If the direction doesn't even connect then the only case where
                        // we would emit a side is for a transparent side... in either
                        // direction or reverse direction.
                        if( block != null && block.getTransparency(dir) <= 0 ) {
                            // Opaque
                            continue;
                        }

                        if( neighbor != null && neighbor.getTransparency(dir) <= 0 ) {
                            // Opaque
                            continue;
                        }

                        // We don't connect but we should emit a side
                        sideMask = sideMask | dir.getBitMask();
                        sideCount++;
                    }
                    int newVal = setSideMask(val, sideMask);
                    newVal = setConnectMask(newVal, connectMask);
                    fluid.setCell(x, y, z, newVal);
                }
            }
        }

        return sideCount;
    }

    /**
     *  Returns true if the fluid in the local cell could connect to the fluid in
     *  the neighbor cell in the specified direction.  Fluid "connects" if the fluid
     *  level is more than 0 and has an appropriate height gap that allows it through.
     */
    public static boolean isConnected( int fluidLevel, BlockType local, BlockType neighbor, Direction dir ) {

        if( log.isTraceEnabled() ) {
            log.trace("isConnected(" + fluidLevel + ", "
                + (local == null ? "null" : local.getName().toString()) + ", "
                + (neighbor == null ? "null" : neighbor.getName().toString()) + ", "
                + dir + ")");
        }

        if( fluidLevel <= 0 ) {
            // Only a cell with fluid in it can connect to a neighbor but this
            // method shouldn't have even been called in that case.  We'll handle
            // it just in case, though.  Just one conditional.
            return false;
        }
        if( local == null && neighbor == null ) {
            // Empty space all the way
            return true;
        }
        if( local != null && local.isSolid(dir) ) {
            // Blocked leaving the cell
            return false;
        }
        Direction rev = dir.reverse();
        if( neighbor != null && neighbor.isSolid(rev) ) {
            // Blocked entering the next cell
            return false;
        }

        // Note: fluid level only matters in the cardinal directions.
        // Up/down are always treated like full blocks for connectivity
        // purposes so any gap = true.

        // Here is where we'd check for gaps in the boundary
        // shapes to determine if fluid could pass.  For now, we'll just
        // assume any non-solid side is open enough.
        // FIXME: implement proper boundary shape gap checks
        return true;
    }

}



