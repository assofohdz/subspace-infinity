/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import com.google.common.base.MoreObjects;

import org.slf4j.*;

/**
 *  Provides information about the raised/lowered status of
 *  the corners of a fluid cell.
 *
 *  @author    Paul Speed
 */
public class FluidSlope {
    static Logger log = LoggerFactory.getLogger(FluidSlope.class);

    //public enum Corner {
    //    None(0),
    //    Raised(1),
    //    Lowered(-1),
    //    Rapids(-1);
    //
    //    private final int offset;
    //    private Corner( int offset ) {
    //        this.offset = offset;
    //    }
    //
    //    public int getOffset() {
    //        return offset;
    //    }
    //};

    public int nw;
    public int ne;
    public int se;
    public int sw;

    public FluidSlope() {
    }

    private static final int BIT_MASK = 0b111;
    public FluidSlope setBits( int bits ) {
        this.nw = bitsToValue((bits     ) & BIT_MASK);
        this.ne = bitsToValue((bits >> 3) & BIT_MASK);
        this.se = bitsToValue((bits >> 6) & BIT_MASK);
        this.sw = bitsToValue((bits >> 9) & BIT_MASK);
        return this;
    }

    public int getBits() {
        int result = valueToBits(nw);
        result |= valueToBits(ne) << 3;
        result |= valueToBits(se) << 6;
        result |= valueToBits(sw) << 9;
        return result;
    }

    //private static int SIGN_EXTEND = 0xfffffff8;
    public static final int bitsToValue( int bits ) {
//        if( bits > 3 ) {
//log.info("-bitsToValue(" + Integer.toBinaryString(bits) + ") = " + (bits | SIGN_EXTEND));
//            return bits | SIGN_EXTEND;
//        }
//log.info("+bitsToValue(" + Integer.toBinaryString(bits) + ") = " + bits);
        // 0...7 is really 1...8
        return bits + 1;
    }

    public static final int valueToBits( int value ) {
        return (value - 1) & BIT_MASK;
    }

    //public static final Corner offsetToCorner( int offset ) {
    //    if( offset == 0 ) {
    //        return Corner.None;
    //    }
    //    if( offset > 0 ) {
    //        return Corner.Raised;
    //    }
    //    if( offset < -1 ) {
    //        return Corner.Rapids;
    //    }
    //    // offset <0
    //    return Corner.Lowered;
    //}
    //
    //public static final Corner bitsToCorner( int bits ) {
    //    switch( bits ) {
    //        case 0b00:
    //            return Corner.None;
    //        case 0b01:
    //            return Corner.Raised;
    //        case 0b10:
    //            return Corner.Lowered;
    //        case 0b11:
    //            return Corner.Rapids;
    //    }
    //    throw new IllegalArgumentException("Unhandled corner bits:" + bits);
    //}
    //
    //public static final int cornerToBits( Corner corner ) {
    //    switch( corner ) {
    //        case None:
    //            return 0;
    //        case Raised:
    //            return 0b01;
    //        case Lowered:
    //            return 0b10;
    //        case Rapids:
    //            return 0b11;
    //    }
    //    throw new IllegalArgumentException("Unhandled corner:" + corner);
    //}

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("nw", nw)
                .add("ne", ne)
                .add("se", se)
                .add("sw", sw)
                .toString();
    }
}
