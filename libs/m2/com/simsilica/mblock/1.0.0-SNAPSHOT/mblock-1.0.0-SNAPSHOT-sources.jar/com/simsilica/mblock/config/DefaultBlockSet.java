/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.config;

import java.util.EnumSet;

import org.slf4j.*;

import com.jme3.asset.AssetManager;
import com.jme3.asset.TextureKey;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.ColorRGBA;
import com.jme3.texture.Texture;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.geom.*;


/**
 *  Encapsulating the setup of a default set of block types and
 *  materials just to make transition easier and maybe this gets kept
 *  around as a basic boot-strapper/guide. 
 *
 *  @author    Paul Speed
 */
public class DefaultBlockSet {

    public static final String MAT_BASE = "base";
    public static final String MAT_SPECIAL = "special";
    public static final String MAT_WATER = "water";
    public static final String MAT_LAVA = "lava";
    public static final String MAT_BAD = "bad";

    static Logger log = LoggerFactory.getLogger(DefaultBlockSet.class);

    private MaterialRegistry materials = new MaterialRegistry();

    /**
     *  Creates a default block set where the first 1-64 block types are
     *  regular full cubes using an 8x8 palette base texture.  The next 'n' blocks
     *  are special blocks for lighting, water, etc. testing.  The use the second
     *  8x8 base texture.
     */
    public DefaultBlockSet( AssetManager assets, String baseTexture, String specialTexture, String badTexture ) {
                
        //MaterialType base = materials.getType(MAT_BASE);       
        //MaterialType special = materials.getType(MAT_SPECIAL);
        //MaterialType bad = materials.getType(MAT_BAD);
 
        if( !BlockTypeIndex.isInitialized() ) {
            initializeBlockTypes();
        }
               
        materials = createDefaultMaterials(baseTexture, specialTexture, badTexture);
        initializeMaterials(assets);
    }
    
    protected void initializeMaterials( AssetManager assets ) {
        materials.initialize(assets);                                       
    }

    public static MaterialRegistry createDefaultMaterials( String baseTexture, String specialTexture, String badTexture ) {
        MaterialRegistry materials = new MaterialRegistry();
        
        //materials.addType(new MaterialType(MAT_BASE, true, false, false));
        //materials.addType(new MaterialType(MAT_SPECIAL, true, false, false));
        //materials.addType(new MaterialType(MAT_BAD, true, false, false));

        //Texture texture1 = loadTexture(assets, baseTexture, true, true);
        //Texture texture2 = loadTexture(assets, specialTexture, true, true);
        //Texture texture3 = loadTexture(assets, badTexture, true, true);
        TextureConfig texture1 = new TextureConfig(baseTexture, true, true, true);
        TextureConfig texture2 = new TextureConfig(specialTexture, true, true, true);
        TextureConfig texture3 = new TextureConfig(badTexture, true, true, true);
               
        MaterialConfig config = new MaterialConfig(MAT_BASE, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.Normals);
        config.put("DiffuseMap", texture1);
        config.put("Diffuse", ColorRGBA.White);
        config.put("Ambient", ColorRGBA.White);
        config.put("UseMaterialColors", true);
        config.put("UseFog", true);
        config.put("FogColor",  new ColorRGBA(0.7f, 0.7f, 0.9f, 1f));
        config.put("ExpFog", 1/6000f);
        
        materials.addConfig(config);

        config = new MaterialConfig(MAT_BAD, config);
        config.put("DiffuseMap", texture3);
        materials.addConfig(config);


        config = new MaterialConfig(MAT_SPECIAL, config);
        config.put("DiffuseMap", texture2);
        config.put("Diffuse", new ColorRGBA(1, 1, 1, 0.75f));
        config.getRenderState().setBlendMode(BlendMode.Alpha);
        materials.addConfig(config);
    
        config = new MaterialConfig(MAT_BASE, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.IndexedNormals);
        config.put("NormalLookup", true);
        materials.addConfig(config);

        config = new MaterialConfig(MAT_SPECIAL, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.IndexedNormals);
        config.put("NormalLookup", true);
        materials.addConfig(config);

        config = new MaterialConfig(MAT_BAD, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.IndexedNormals);
        config.put("NormalLookup", true);
        materials.addConfig(config);

        // A version of bad that will work with geometry with normals
        config = new MaterialConfig(MAT_BAD, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.Normals);
        materials.addConfig(config);
 
        config = new MaterialConfig(MAT_WATER, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.IndexedNormals);
        config.put("NormalLookup", true);
        config.put("Diffuse", new ColorRGBA(0.1f, 0.5f, 0.7f, 0.5f));
        config.put("Ambient", new ColorRGBA(0.1f, 0.5f, 0.7f, 0.5f));
        config.put("UseMaterialColors", true);
        config.put("UseFog", true);
        config.put("FogColor",  new ColorRGBA(0.7f, 0.7f, 0.9f, 1f));
        config.put("ExpFog", 1/6000f);
        config.getRenderState().setBlendMode(BlendMode.Alpha);
        materials.addConfig(config);

        config = new MaterialConfig(MAT_LAVA, "MatDefs/MBlockLighting.j3md");
        config.addGeomReq(GeomReq.IndexedNormals);
        config.put("NormalLookup", true);
        config.put("Diffuse", new ColorRGBA(0.7f, 0.5f, 0.1f, 0.95f));
        config.put("Ambient", new ColorRGBA(0.7f, 0.5f, 0.1f, 0.95f));
        config.put("UseMaterialColors", true);
        config.put("UseFog", true);
        config.put("FogColor",  new ColorRGBA(0.7f, 0.7f, 0.9f, 1f));
        config.put("ExpFog", 1/6000f);
        config.getRenderState().setBlendMode(BlendMode.Alpha);
        materials.addConfig(config);
        
        
        return materials;
    }
    
    public static final BlockType[] createBlockTypes() {
    
        MaterialType base = new MaterialType(MAT_BASE, true, true, false);
        MaterialType special = new MaterialType(MAT_SPECIAL, true, true, false);
        MaterialType bad = new MaterialType(MAT_BAD, true, true, false);
    
        int specialTypeCount = 8 + 8 + 1;
        BlockType[] types = new BlockType[65 + specialTypeCount];
        for( int i = 0; i < 64; i++ ) {
            types[i+1] = new BlockType(new BlockName("base" + i, "cube"), createFactory(base, i));
        }

        // Ground flame
        int group = 0;
        short light = (short)0xa97;        
        types[65] = new BlockType(new BlockName("light", "flame"), group, light, createSpecialFactory(special, 0, new Vec3d(0.25, 0, 0.25), new Vec3d(0.75, 0.75, 0.75)), null);
        
        // Various lantern directions
        light = (short)0xfff;
        types[66] = new BlockType(new BlockName("sm_light", "cube", 0), 
                                  group, light, 
                                  createSpecialFactory(special, 1, new Vec3d(0.4, 0.4, 0), new Vec3d(0.6, 0.6, 0.2)));
        types[67] = new BlockType(new BlockName("sm_light", "cube", 1), 
                                  group, light, 
                                  createSpecialFactory(special, 2, new Vec3d(0.4, 0.4, 0.8), new Vec3d(0.6, 0.6, 1.0)));
        types[68] = new BlockType(new BlockName("sm_light", "cube", 2), 
                                  group, light, 
                                  createSpecialFactory(special, 3, new Vec3d(0.8, 0.4, 0.4), new Vec3d(1, 0.6, 0.6)));
        types[69] = new BlockType(new BlockName("sm_light", "cube", 3), 
                                  group, light, 
                                  createSpecialFactory(special, 4, new Vec3d(0, 0.4, 0.4), new Vec3d(0.2, 0.6, 0.6)));
        // TBD
        types[70] = new BlockType(new BlockName("unknown", "cube"), group, light, createSpecialFactory(special, 5, new Vec3d(0.25, 0.25, 0.25), new Vec3d(0.75, 0.75, 0.75)));
        types[71] = new BlockType(new BlockName("unknown", "cube"), group, light, createSpecialFactory(special, 6, new Vec3d(0.25, 0.25, 0.25), new Vec3d(0.75, 0.75, 0.75)));
        types[72] = new BlockType(new BlockName("unknown", "cube"), group, light, createSpecialFactory(special, 7, new Vec3d(0.25, 0.25, 0.25), new Vec3d(0.75, 0.75, 0.75)));

        // Some fake water blocks
        for( int i = 0; i < 8; i++ ) {
            types[73 + i] = new BlockType(new BlockName("water", "cube" + i), 1, 
                                          createFactory(special, 0.9, i + 8), null);
        }
 
        // A 'bad type' type
        types[73 + 8] = new BlockType(new BlockName("bad", "cube"), 
                                      DefaultBlockFactory.createCube(0, bad), null);
        return types;
    }
        
    public static final void initializeBlockTypes() {
        BlockType[] types = createBlockTypes();
        BlockTypeIndex.initialize(types, 73+8);          
    }
 
    public static final FluidType[] createFluidTypes() {
        EnumSet<GeomReq> geomReqs = EnumSet.of(GeomReq.IndexedNormals);
        MaterialType mWater = new MaterialType("water", geomReqs); 
        MaterialType mLava = new MaterialType("lava", geomReqs);
         
        FluidType[] fluidTypes = new FluidType[] {
                null,
                new FluidType(new FluidName("water"), new LiquidFactory(mWater)),
                new FluidType(new FluidName("lava"), new LiquidFactory(mLava))
            };
        return fluidTypes;
    }
    
    public static final void initializeFluidTypes() {
        FluidType[] types = createFluidTypes();
        FluidTypeIndex.initialize(types);
    }

    public GeometryFactory createGeometryFactory( boolean allowCollisions ) {
        return new GeometryFactory(allowCollisions, materials.getMaterials());
    }
        
    public MaterialRegistry getMaterials() {
        return materials;
    }

    private static BlockFactory createFactory( MaterialType mt, int color ) {
        return createFactory(mt, 0, color);
    }
    
    private static BlockFactory createFactory( MaterialType mt, double transparency, int color ) {
        int x = color & 0x7;
        int y = (color & 0x38) >> 3;

        float textureScale = 0.125f; // 1/8th
        float halfScale = textureScale * 0.5f;
        float s = x * textureScale + halfScale;
        float t = 1f - (y * textureScale + halfScale);

        DefaultBlockFactory result = DefaultBlockFactory.createCube(transparency, mt); 
        for( PartFactory partFactory : result.getDirParts() ) {
            for( GeomPart part : ((DefaultPartFactory)partFactory).getTemplates() ) {
                
                // Convenient that we want all texture coordinates to be the same
                float[] texes = part.getTexCoords();
                for( int i = 0; i < texes.length; i+=2 ) {
                    texes[i] = s;
                    texes[i+1] = t;
                }                
            } 
        }
  
        return result;        
    }
    
    private static BlockFactory createSpecialFactory( MaterialType mt, int color, Vec3d min, Vec3d max ) {

        // We use the same palette texture (right now) for the special
        // blocks but either way it's super convenient to reuse the same scheme here.
        int x = color & 0x7;
        int y = (color & 0x38) >> 3;

        float textureScale = 0.125f; // 1/8th
        float halfScale = textureScale * 0.5f;
        float s = x * textureScale + halfScale;
        float t = 1f - (y * textureScale + halfScale);
 
        DefaultPartFactory partFactory = DefaultPartFactory.create(
                GeomPart.createQuad(min, max, mt, Direction.North),
                GeomPart.createQuad(min, max, mt, Direction.South),
                GeomPart.createQuad(min, max, mt, Direction.East),
                GeomPart.createQuad(min, max, mt, Direction.West),
                GeomPart.createQuad(min, max, mt, Direction.Up),
                GeomPart.createQuad(min, max, mt, Direction.Down)
            );

        for( GeomPart part : partFactory.getTemplates() ) {
                
            // Convenient that we want all texture coordinates to be the same
            float[] texes = part.getTexCoords();
            for( int i = 0; i < texes.length; i+=2 ) {
                texes[i] = s;
                texes[i+1] = t;
            }                
        } 
 
        // Create a factory with only internal parts
        DefaultBlockFactory result = DefaultBlockFactory.create(null, partFactory);

        return result;        
    }
    
    //private static Texture loadTexture( AssetManager assets, String path, boolean repeat, boolean generateMips ) {
    //    TextureKey key = new TextureKey(path);
    //    key.setGenerateMips(generateMips);
    //
    //    Texture t = assets.loadTexture(key);
    //    if( t == null ) {
    //        throw new RuntimeException("Error loading texture:" + path);
    //    }
    //
    //    if( repeat ) {
    //        t.setWrap(Texture.WrapMode.Repeat);
    //    } else {
    //        // JME has deprecated Clamp and defaults to EdgeClamp.
    //        // I think the WrapMode.EdgeClamp javadoc is totally bonkers, though.
    //        t.setWrap(Texture.WrapMode.EdgeClamp);
    //    }
    //    return t;
    //}


}


