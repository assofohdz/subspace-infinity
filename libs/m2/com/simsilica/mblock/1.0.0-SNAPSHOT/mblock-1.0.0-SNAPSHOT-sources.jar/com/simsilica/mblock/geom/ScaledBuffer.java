/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.nio.*;

import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.util.BufferUtils;


/**
 *  Wraps a java.nio.Buffer and provides optional compressed/scaled
 *  storage to an underlying lower-resolution buffer.
 *
 *  @author    Paul Speed
 */
public abstract class ScaledBuffer {

    public static ScaledBuffer createUnscaledBuffer( int elements ) {
        return new PassthroughBuffer(elements);
    }
    
    public static ScaledBuffer createScaledBuffer( int elements, float min, float max ) {
        return new ScaledByteBuffer(elements, min, max);
    }
 
    public abstract int position();  
    public abstract ScaledBuffer put( float value );     
    public abstract ScaledBuffer put( float... value );     
    public abstract void applyToMesh( Mesh mesh, Type type, int components );
    
    private static class PassthroughBuffer extends ScaledBuffer {
        private FloatBuffer buffer;
        
        public PassthroughBuffer( int elements ) {
            this.buffer = BufferUtils.createFloatBuffer(elements);
        }
 
        public int position() {
            return buffer.position();
        }
        
        public ScaledBuffer put( float value ) {
            buffer.put(value);
            return this;
        }

        public ScaledBuffer put( float... value ) {
            buffer.put(value);
            return this;
        }
        
        public void applyToMesh( Mesh mesh, Type type, int components ) {
            mesh.setBuffer(type, components, buffer);
        }
    }

    // Essentially untested
    private static class ScaledByteBuffer extends ScaledBuffer {
        private ByteBuffer buffer;
        private float min;
        private float max;
        private float range;
        
        public ScaledByteBuffer( int elements, float min, float max ) {
            this.min = min;
            this.max = max;
            this.range = max - min;
            this.buffer = BufferUtils.createByteBuffer(elements);
        }
 
        private byte scale( float val ) {
            val = val - min;
            return (byte)((val / range) * 255);
        }
 
        public int position() {
            return buffer.position();
        }
        
        public ScaledBuffer put( float value ) {
            buffer.put(scale(value));
            return this;
        }

        public ScaledBuffer put( float... values ) {
            for( float f : values ) {
                put(f);
            } 
            return this;
        }
        
        public void applyToMesh( Mesh mesh, Type type, int components ) {
            mesh.setBuffer(type, components, buffer);
            mesh.getBuffer(type).setNormalized(true);
        }
    }
}
