/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock.geom;

import java.util.Arrays;
import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

import com.simsilica.mblock.BlockType;
import com.simsilica.mblock.Direction;

/**
 *  A default implementation of PartFactory that uses a predefined
 *  list of GeomParts as a template that it passes to the GeomPartBuffer
 *  at creation time.
 *
 *  @author    Paul Speed
 */
public class DefaultPartFactory implements PartFactory {
    static final long serialVersionUID = 42L;

    static Logger log = LoggerFactory.getLogger(DefaultPartFactory.class);

    private final GeomPart[] templates;
    private final BoundaryShape shape;
    private final Vec3d min;
    private final Vec3d max;

    public DefaultPartFactory( BoundaryShape shape, Vec3d min, Vec3d max, GeomPart... templates ) {
        this.templates = templates;
        this.shape = shape;
        this.min = min;
        this.max = max;
    }

    /**
     *  Convenience method for creating a DefaultPartFactory that creates a full sized
     *  cube face in the specified direction.  It delegates to the GeomPart.createFace()
     *  method to create the actual cube face GeomPart template.
     */
    public static DefaultPartFactory createCubeFace( MaterialType materialType, Direction dir ) {
        return new DefaultPartFactory(BoundaryShapes.UNIT_SQUARE, new Vec3d(), new Vec3d(1, 1, 1),
                                      GeomPart.createFace(materialType, dir));
    }

    public static DefaultPartFactory create( GeomPart... templates ) {
        return create(null, templates);
    }

    public static DefaultPartFactory create( BoundaryShape shape, GeomPart... templates ) {
        Vec3d min = new Vec3d(100, 100, 100); // just needs to be relatively big
        Vec3d max = new Vec3d(-100, -100, -100); // just needs to be relatively small

        for( GeomPart p : templates ) {
            if( p == null ) {
                continue;
            }
            float[] coords = p.getCoords();
            for( int i = 0; i < coords.length; i += 3 ) {
                float x = coords[i];
                float y = coords[i+1];
                float z = coords[i+2];

                Vec3d pos = new Vec3d(x, y, z);
                min.minLocal(pos);
                max.maxLocal(pos);
            }
        }

        return new DefaultPartFactory(shape, min, max, templates);
    }

    public GeomPart[] getTemplates() {
        return templates;
    }

    @Override
    public BoundaryShape getBoundaryShape() {
        return shape;
    }

    @Override
    public Vec3d getMin() {
        return min;
    }

    @Override
    public Vec3d getMax() {
        return max;
    }

    @Override
    public int addParts( GeomPartBuffer buffer, int i, int j, int k,
                         int xWorld, int yWorld, int zWorld,
                         BlockType block,
                         Direction dir ) {
        int count = 0;
        for( GeomPart t : templates ) {
            buffer.addPart(i, j, k, t);
            count++;
        }
        return count;
    }

    public PartFactory rotate( Direction dir, int dirDelta ) {
        if( dirDelta < 0 || dirDelta > 3 ) {
            throw new IllegalArgumentException("dirDelta is out of bounds:" + dirDelta);
        }

        GeomPart[] newParts = new GeomPart[templates.length];
        for( int i = 0; i < newParts.length; i++ ) {
            newParts[i] = templates[i].rotate(dirDelta);
        }
        BoundaryShape newShape = null;
        if( shape != null ) {
            newShape = shape.rotate(dir, dirDelta);
        }

        Vec3d v1 = GeomUtils.rotatePos(min, dirDelta);
        Vec3d v2 = GeomUtils.rotatePos(max, dirDelta);

        Vec3d newMin = new Vec3d(v1).minLocal(v2);
        Vec3d newMax = new Vec3d(v1).maxLocal(v2);

        return new DefaultPartFactory(newShape, newMin, newMax, newParts);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        DefaultPartFactory other = (DefaultPartFactory)o;
        if( !Objects.equals(other.shape, shape) ) {
            return false;
        }
        if( !Objects.equals(other.min, min) ) {
            return false;
        }
        if( !Objects.equals(other.max, max) ) {
            return false;
        }
        if( !Arrays.equals(other.templates, templates) ) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(shape, min, max, Arrays.hashCode(templates));
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                    .add("boundaryShape", shape)
                    .add("min", min)
                    .add("max", max)
                    .add("templates", Arrays.asList(templates))
                    .toString();
    }
}

