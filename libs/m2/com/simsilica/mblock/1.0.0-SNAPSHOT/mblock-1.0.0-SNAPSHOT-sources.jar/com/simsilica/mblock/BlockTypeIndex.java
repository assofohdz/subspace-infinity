/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mblock;

import java.io.*;
import java.util.Objects;

import org.slf4j.*;

import com.simsilica.mblock.io.BlockTypeData;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BlockTypeIndex {

    static final long serialVersionUID = 42L;

    static Logger log = LoggerFactory.getLogger(BlockTypeIndex.class);

    private static BlockType[] types;
    private static int typeCount;

    private static BlockType badType;
    private static int badTypeIndex;

    private BlockTypeIndex() {
    }

    /**
     *  Initializes the current block types with the specified types.
     *  If there is an existing set of block types then this will throw an
     *  IllegalStateException.
     *  Note: it is expected that the types array already contains the null value
     *  for index 0.
     */
    public static void initialize( BlockType[] types, int badTypeIndex ) {
        log.info("initialize(size:" + types.length + ")");
        if( BlockTypeIndex.types != null ) {
            throw new IllegalStateException("BlockTypeIndex is already initialized");
        }
        BlockTypeIndex.types = types;
        BlockTypeIndex.typeCount = types.length;
        BlockTypeIndex.badTypeIndex = badTypeIndex;
        BlockTypeIndex.badType = types[badTypeIndex];
    }

    public static void initialize( BlockTypeData blockData ) {
        initialize(blockData.types, blockData.badTypeIndex);
    }


    public static void load( InputStream rawIn ) throws IOException {
        BlockTypeData blockData = BlockTypeData.load(rawIn);
        reset();
        initialize(blockData.types, blockData.badTypeIndex);
    }

    public static void store( OutputStream rawOut ) throws IOException {
        BlockTypeData blockData = new BlockTypeData();
        blockData.types = types;
        blockData.badTypeIndex = badTypeIndex;
        BlockTypeData.store(blockData, rawOut);
    }

    public static void reset() {
        log.info("reset()");
        BlockTypeIndex.types = null;
        BlockTypeIndex.typeCount = 0;
        BlockTypeIndex.badTypeIndex = 0;
        BlockTypeIndex.badType = null;
    }

    public static BlockTypeData toBlockTypeData() {
        return new BlockTypeData(types, badTypeIndex);
    }

    public static BlockType get( int type ) {
        if( type >= 0 && type < typeCount ) {
            return types[type];
        }
        return badType;
    }

    public static void setBadTypeIndex( int index ) {
        badTypeIndex = index;
    }

    public static int getBadTypeIndex() {
        return badTypeIndex;
    }

    public static void override( int index, BlockType type ) {
        types[index] = type;
    }

    public static boolean isInitialized() {
        return BlockTypeIndex.types != null;
    }

    public static int getTypeCount() {
        return typeCount;
    }

    public static BlockType[] getTypes() {
        return types;
    }

    public static int findType( BlockName name ) {
        return findType(name, -1);
    }

    public static int findType( BlockName name, int defaultValue ) {
        for( int i = 0; i < types.length; i++ ) {
            BlockType type = types[i];
            if( type == null ) {
                continue;
            }
            if( Objects.equals(type.getName(), name) ) {
                return i;
            }
        }
        return defaultValue;
    }
}
