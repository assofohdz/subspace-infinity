/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mod;

import java.io.*;
import java.util.*;

import org.slf4j.*;

/**
 *  Extension of ModPack that monitors local files for changes but
 *  otherwise delegates to the ModPack super class.  This will watch
 *  the main .json modpack file as well as any directly mentioned 
 *  scripts for changes.  At the time of this writing, this is really
 *  only useful for "leaf" mods of the dependency tree as there is no
 *  mechanism to reload dependents automatically when a dependency reloads.
 *
 *  @author    Paul Speed
 */
public class FileModPack extends ModPack {
    static Logger log = LoggerFactory.getLogger(FileModPack.class);

    private File root;
    private File infoFile; 
    private List<FileRef> files = new ArrayList<>();
    
    public FileModPack( File infoFile, ModInfo info ) {
        super(infoFile.getParentFile().toURI(), info);
        this.root = infoFile.getParentFile();
        this.infoFile = infoFile;
    }
    
    public boolean hasChanged() {
        for( FileRef ref : files ) {
            if( ref.hasChanged() ) {
                return true;
            }
        }
        return false;
    }
 
    public void reload() {
        List<FileRef> savedFiles = new ArrayList<>(files);
        try {
            terminate();
            initialize(getModManager());
        } catch( RuntimeException e ) {
            // But resurrect the files from before in case they change again
            // and fix the issue.
            for( FileRef ref : savedFiles ) {
                ref.clearChanged();
                files.add(ref);
            }
            throw e;
        }
    }
 
    @Override
    public void initialize( ModManager manager ) {
        super.initialize(manager);
        files.add(new FileRef(infoFile));
 
        // Keep track of our init and terminate scripts to see 
        // if they get modified at runtime
        for( String s : getInfo().getInitScripts() ) {
            files.add(new FileRef(new File(root, s)));
        }
        for( String s : getInfo().getTerminateScripts() ) {
            files.add(new FileRef(new File(root, s)));
        }
    }    
 
    @Override
    public void terminate() {
        super.terminate();
        files.clear();
    }
    
    private class FileRef {
        private File file;
        private long lastModified;
    
        public FileRef( File file ) {            
            this.file = file;
            this.lastModified = file.lastModified();
            log.info("Tracking:" + file);
        }
        
        public boolean hasChanged() {
            return lastModified != file.lastModified();
        }
        
        public void clearChanged() {
            this.lastModified = file.lastModified();
        }
    }
}
