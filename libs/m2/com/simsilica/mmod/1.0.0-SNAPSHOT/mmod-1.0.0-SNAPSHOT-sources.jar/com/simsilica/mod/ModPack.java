/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mod;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import org.codehaus.groovy.control.CompilerConfiguration;
import org.codehaus.groovy.control.customizers.ImportCustomizer;


/**
 *  Provides access to the scripts and resources within a mod pack.
 *
 *  @author    Paul Speed
 */
public class ModPack {
    static Logger log = LoggerFactory.getLogger(ModPack.class);

    private URI root;
    private ModInfo info;
    private GroovyScriptEngine scriptEngine;
    private ModManager manager;
    private List<Runnable> terminateCallbacks = new ArrayList<>();
    private boolean initializing = false;
    private boolean enabled;

    public ModPack( URI root, ModInfo info ) {
        this.root = root;
        this.info = info;
        this.enabled = info.isEnabled();
    }

    public boolean isEnabled() {
        return enabled;
    }

    protected ModManager getModManager() {
        return manager;
    }

    public void initialize( ModManager manager ) {
        this.manager = manager;
        try {
            CompilerConfiguration config = manager.getCompilerConfig();

            this.scriptEngine = new GroovyScriptEngine(new URL[] { root.toURL() });
            scriptEngine.setConfig(config);
        } catch( MalformedURLException e ) {
            throw new RuntimeException("Error resolving root to URL:" + root, e);
        }
        this.initializing = true;
        Binding binding = new LocalBinding(info.getGroupId() + "." + info.getName(),
                                           manager.getGlobalBindings());
        for( String s : info.getInitScripts() ) {
            log.info("Running:" + s);
            try {
                scriptEngine.run(s, binding);
            } catch( Exception e ) {
                throw new RuntimeException("Error running:" + s, e);
            }
        }

        if( log.isDebugEnabled() ) {
            log.debug("post bindings:" + manager.getGlobalBindings());
        }
        // Now essentially freeze the bindings so we can detect 'def' mistakes
        this.initializing = false;
    }

    public void terminate() {
        // Run the callbacks before the scripts
        for( Runnable callback : terminateCallbacks ) {
            try {
                if( log.isDebugEnabled() ) {
                    log.debug("Running terminate callback:" + callback);
                }
                callback.run();
            } catch( Exception e ) {
                throw new RuntimeException("Error running termination callback:" + callback, e);
            }
        }
        terminateCallbacks.clear();

        Binding binding = new LocalBinding(info.getGroupId() + "." + info.getName(),
                                           manager.getGlobalBindings());
        for( String s : info.getTerminateScripts() ) {
            log.info("Running:" + s);
            try {
                scriptEngine.run(s, binding);
            } catch( Exception e ) {
                throw new RuntimeException("Error running:" + s, e);
            }
        }
    }

    public String getId() {
        return info.getId();
    }

    public URI getRoot() {
        return root;
    }

    public URI getResource( String resource ) {
        if( !info.getResources().contains(resource) ) {
            throw new IllegalArgumentException("Resource not configured:" + resource);
        }
        return root.resolve(resource);
    }

    public List<String> getDependencies() {
        return info.getDependencies();
    }

    public ModInfo getInfo() {
        return info;
    }

    public Map<String, Object> getConfig() {
        return info.getConfig();
    }

    /**
     *  Adds a runnable that will be run (and then removed) when this modpack
     *  is terminated.  This is especially important for mods that should be
     *  reloadable.
     */
    public void onTerminate( Runnable callback ) {
        terminateCallbacks.add(callback);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("root", root)
            .add("info", info)
            .toString();
    }

    private class LocalBinding extends Binding {
        private Logger log;

        public LocalBinding( String context, Map<String, Object> map ) {
            super(map);
            this.log = LoggerFactory.getLogger(context);
        }

        public ModPack getMod() {
            return ModPack.this;
        }

        @Override
        public void setVariable( String name, Object value ) {
            if( "mod".equals(name) ) {
                throw new IllegalArgumentException("The 'mod' binding is hard-wired.");
            }
            if( "log".equals(name) ) {
                throw new IllegalArgumentException("The 'log' binding is hard-wired.");
            }
            if( !initializing ) {
                log.warn("Setting binding outside of init:" + name + "=" + value, new Throwable("stack-trace"));
            }
            super.setVariable(name, value);
        }

        @Override
        public Object getProperty( String property ) {
            if( "mod".equals(property) ) {
                return getMod();
            }
            if( "log".equals(property) ) {
                return log;
            }
            return super.getProperty(property);
        }

        @Override
        public Object getVariable( String name ) {
            if( "mod".equals(name) ) {
                return getMod();
            }
            if( "log".equals(name) ) {
                return log;
            }
            return super.getVariable(name);
        }

        @Override
        public boolean hasVariable( String name ) {
            if( "mod".equals(name) ) {
                return true;
            }
            if( "log".equals(name) ) {
                return true;
            }
            return super.hasVariable(name);
        }
    }
}

