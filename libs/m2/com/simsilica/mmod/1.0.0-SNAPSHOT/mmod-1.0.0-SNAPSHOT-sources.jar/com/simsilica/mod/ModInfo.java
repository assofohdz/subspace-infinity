/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mod;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  Information about a modpack like it's name, version, dependencies,
 *  etc..
 *
 *  @author    Paul Speed
 */
public class ModInfo {
    static Logger log = LoggerFactory.getLogger(ModInfo.class);

    private static final String FORMAT_VERSION = "1.0";

    private String groupId;
    private String name;
    private String author;
    private String version;
    private String formatVersion;
    private Boolean enabled;
    private List<String> dependencies;
    private List<String> initScripts;
    private List<String> terminateScripts;
    private List<String> resources;
    private Map<String, Object> config;

    public ModInfo() {
    }

    public ModInfo( String groupId, String name, String... initScripts ) {
        this.groupId = groupId;
        this.name = name;
        this.initScripts = Arrays.asList(initScripts);
        upgrade();
    }

    /**
     *  Returns the canonical ID for this MOD which is a combination
     *  of the groupId and name as groupId:name.
     */
    public String getId() {
        return groupId + ":" + name;
    }

    protected void upgrade() {
        if( initScripts == null ) {
            initScripts = new ArrayList<>(Arrays.asList("initialize.groovy"));
        }
        if( terminateScripts == null ) {
            terminateScripts = new ArrayList<>();
        }
        if( dependencies == null ) {
            dependencies = new ArrayList<>();
        }
        if( resources == null ) {
            resources = new ArrayList<>();
        }
        if( config == null ) {
            config = new HashMap<String, Object>();
        }
    }

    public String getGroupId() {
        return groupId;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getVersion() {
        return version;
    }

    public boolean isEnabled() {
        // True by default
        return enabled == null ? true : enabled;
    }

    public List<String> getDependencies() {
        return Collections.unmodifiableList(dependencies);
    }

    public List<String> getInitScripts() {
        return Collections.unmodifiableList(initScripts);
    }

    public List<String> getTerminateScripts() {
        return Collections.unmodifiableList(terminateScripts);
    }

    /**
     *  Returns a list of resources that are accessible through the mod.getResource() call.
     */
    public List<String> getResources() {
        return Collections.unmodifiableList(resources);
    }

    public Map<String, Object> getConfig() {
        return config;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("groupId", groupId)
            .add("name", name)
            .add("author", author)
            .add("version", version)
            .add("dependencies", dependencies)
            .add("initScripts", initScripts)
            .add("config", config)
            .toString();
    }
}

