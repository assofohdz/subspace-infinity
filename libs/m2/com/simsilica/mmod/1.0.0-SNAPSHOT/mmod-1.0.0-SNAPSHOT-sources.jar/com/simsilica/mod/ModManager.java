/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mod;

import java.io.*;
import java.net.*;
import java.util.*;

import org.slf4j.*;

// It's super convenient to be able to hold onto these and build them up as
// we go.  We could abstract them behind some interface but then something still
// needs to initialize them... and the only implementation right now is groovy anyway.
import org.codehaus.groovy.control.CompilerConfiguration;
import org.codehaus.groovy.control.customizers.ImportCustomizer;

import com.simsilica.progress.*;

/**
 *  Manages the lifecycle of loaded "mods" as ModPack instances.
 *
 *  @author    Paul Speed
 */
public class ModManager {
    static Logger log = LoggerFactory.getLogger(ModManager.class);

    private Set<ModPack> mods = new LinkedHashSet<>();
    private Map<String, ModPack> index = new HashMap<>();

    private boolean initialized;

    private List<String> imports = new ArrayList<>();
    private List<String> staticImports = new ArrayList<>();
    private Map<String, Object> bindings = new HashMap<>();

    private List<ModPack> sorted;
    private URL[] roots;

    // Keep track specifically of the ones that were actually initialized and
    // in what order.
    private List<ModPack> initializedMods = new ArrayList<>();

    private CompilerConfiguration compilerConfig;
    private ImportCustomizer importCustomizer;

    public ModManager() {
        bindings.put("modManager", this);

        compilerConfig = new CompilerConfiguration();
        importCustomizer = new ImportCustomizer();
        // Can we do this now?
        compilerConfig.addCompilationCustomizers(importCustomizer);
    }

    protected void checkInitialized() {
        if( initialized ) {
            throw new IllegalStateException("ModManager already initialized");
        }
    }

    public void addGlobalImport( String s ) {
        log.info("addGlobalImport(" + s + ")");
        imports.add(s);
        if( s.endsWith(".*") ) {
            importCustomizer.addStarImports(s.substring(0, s.length()-2));
        } else {
            importCustomizer.addImports(s);
        }
    }

    public List<String> getGlobalImports() {
        return imports;
    }

    public void addGlobalStaticImport( String s ) {
        log.info("addStaticGlobalImport(" + s + ")");
        if( s.lastIndexOf('.') < 0 ) {
            throw new IllegalArgumentException("Invalid static import format:" + s);
        }
        staticImports.add(s);
        if( s.endsWith(".*") ) {
            importCustomizer.addStaticStars(s.substring(0, s.length()-2));
        } else {
            int split = s.lastIndexOf('.');
            if( split < 0 ) {
                throw new RuntimeException("Invalid static import format:" + s);
            }
            String c = s.substring(0, split);
            String n = s.substring(split + 1);
            importCustomizer.addStaticImport(c, n);
        }
    }

    public List<String> getGlobalStaticImports() {
        return staticImports;
    }

    public void setGlobalBinding( String name, Object value ) {
        bindings.put(name, value);
    }

    public Map<String, Object> getGlobalBindings() {
        return bindings;
    }

    public void removeGlobalBinding( String name ) {
        bindings.remove(name);
    }

    public Object getGlobalBinding( String name ) {
        return bindings.get(name);
    }

    public Set<String> getModPackIds() {
        return index.keySet();
    }

    public void initialize() {
        checkInitialized();

        ProgressTracker progress = ProgressTrackers.openTracker("Initializing game modules...");
        try {
            progress.setMax(2 + mods.size());

            // Perform a topological sort of the mods
            Collection<ModPack> sort = topologicalSort();
            this.sorted = new ArrayList<>(sort);
            progress.increment();

            // Because resources/scripts may resolve in the order we present them,
            // we'll make sure our roots are ordered.
            Set<URL> roots = new LinkedHashSet<>();
            for( ModPack mod : sort ) {
                log.info("preparing mod:" + mod.getId() + "  root:" + mod.getRoot());
                try {
                    URL u = mod.getRoot().toURL();
                    if( roots.add(u) ) {
                        log.info("root:" + mod.getRoot());
                    }
                } catch( MalformedURLException e ) {
                    throw new RuntimeException("Error resolving root to URL:" + mod.getRoot(), e);
                }
            }
            progress.increment();

            // Now initialize each of the ModPacks however they
            // want to be initialized.
            // Rather than have one common scripting engine that they all
            // share, we force their isolation.  If we want to allow sharing
            // of classes/jars/whatever other than through bindings then
            // we'll need to do it explicitly and I'd prefer to have use-cases
            // for that first.
            // Otherwise, if they all comingle then there will be no way to
            // sort out one mod's "Foo" script from some other mod's "Foo" script
            // even if they do two completely different things.
            for( ModPack mod : sorted ) {
                if( mod.isEnabled() ) {
                    log.info("Initializing:" + mod.getId());
                    mod.initialize(this);
                    initializedMods.add(mod);
                } else {
                    log.info("Skipping:" + mod.getId() + " because it is disabled.");
                }
                progress.increment();
            }
        } finally {
            progress.close(true);
        }

        this.initialized = true;
    }

    public void terminate() {
        List<ModPack> reversed = new ArrayList<>(initializedMods);
        Collections.reverse(reversed);
        for( ModPack mod : reversed ) {
            mod.terminate();
        }
        initialized = false;
    }

    protected CompilerConfiguration getCompilerConfig() {
        return compilerConfig;
    }

    protected Collection<ModPack> topologicalSort() {
        Set<ModPack> sort = new LinkedHashSet<>();

        // To detect cycles we'll see where we've been as we go
        Set<ModPack> visited = new HashSet<>();
        for( ModPack mod : mods ) {
            addToTopoSort(mod, sort, visited);
        }
        return sort;
    }

    protected void addToTopoSort( ModPack mod, Set<ModPack> sort, Set<ModPack> visited ) {
        if( sort.contains(mod) ) {
            // Already in the sort
            return;
        }
        if( !visited.add(mod) ) {
            throw new RuntimeException("Cycle detected at:" + mod);
        }
        for( String d : mod.getDependencies() ) {
            ModPack dep = index.get(d);
            if( dep == null ) {
                throw new RuntimeException("Dependency not found:" + d + " Needed by:" + mod.getId());
            }
            addToTopoSort(dep, sort, visited);
        }

        // Now that all of the dependencies are added, we can
        // add the mod.
        sort.add(mod);
    }

    public ModPack add( ModPack pack ) {
        checkInitialized();
        // Later loaded mods with the same ID will override existing
        // mods.  The theory is that this allows mods to override even
        // base systems.  It's likely that this should be a controllable
        // policy and it's also likely that overrides should be explicit
        // instead of implicit... because in this case the mod has to lie
        // about its groupId.  Note that any override mechanism must take
        // into account that other mods may be 'depending' on the original
        // name... so likely we will need some sort of modpack proxies or
        // to stub out the existing overridden mod except make it depend
        // on the override.
        ModPack existing = index.put(pack.getId(), pack);
        if( existing != null ) {
            log.warn("Overrode existing:" + existing + " with:" + pack);
            mods.remove(existing);
        }
        mods.add(pack);
        return pack;
    }

    protected URI getParent( URI u ) {
        URI parent = u.resolve(".");
        if( !parent.toString().equals(".") ) {
            return parent;
        }
        // Else we need to be a little more clever
        String s = u.toString();
        int split;
        if( s.endsWith("json") ) {
            split = s.lastIndexOf('/');
        } else if( s.endsWith("/") ) {
            split = s.substring(0, s.length()-1).lastIndexOf('/');
        } else {
            split = s.lastIndexOf('/');
        }
        if( split < 0 ) {
            throw new IllegalArgumentException("Error finding parent for:" + u);
        }
        String p = s.substring(0, split) + "/";
        try {
            return new URI(p);
        } catch( URISyntaxException e ) {
            throw new IllegalArgumentException("Error constructing parent URI from:" + p + " extracted from:" + u, e);
        }
    }

    public ModPack loadModPack( URI infoLocation ) {
        log.info("loadModPack(" + infoLocation + ")");

        // Get just the path part of the URI
        URI parent = getParent(infoLocation); //.resolve(".");

        ModInfo info = ModInfoJson.load(infoLocation);
        ModPack result = new ModPack(parent, info);
        return add(result);
    }

    public ModPack loadFromResource( String resource ) {
        URL u = getClass().getResource(resource);
        if( u == null ) {
            throw new IllegalArgumentException("Resource not found for:" + resource);
        }

        URI uri;
        try {
            uri = u.toURI();
        } catch( URISyntaxException e ) {
            throw new IllegalArgumentException("Error resolving URL:" + u, e);
        }
        return loadModPack(uri);
    }

    /**
     *  Loads the specified mod info file and initializes and adds the
     *  mod pack.  The parent file is used as the mod pack's root.
     */
    public FileModPack loadModPack( File modInfoFile ) {
        log.info("loadModPack(" + modInfoFile + ")");
        ModInfo info = ModInfoJson.load(modInfoFile);
        FileModPack result = new FileModPack(modInfoFile, info);
        add(result);
        return result;
    }

}

