/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fsm;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.Predicate;
import com.google.common.collect.*;

/**
 *  Implements a 'finite state machine' which contains a set of
 *  states and associated transition.  Transitions can be triggered
 *  externally which cause the state to change.  Listeners can be
 *  attached to transitions in various ways.
 *
 *  @author    Paul Speed
 */
public class StateMachine<K, T> {
    static Logger log = LoggerFactory.getLogger(StateMachine.class);
  
    private Map<K, State> states = new HashMap<>();
    private Map<T, State> defaultTransitions = new HashMap<>();
    
    // Note: there are undoubtedly better ways to deal with transition matching 
    // listeners than a global map and someday we could switch to them.
    // But given that we can listen for (*, *, *, *) (*, *, trigger, *(
    // (from, *, trigger, *), etc... for anything less than a few hundered
    // transitions iterating and testing is probably going to be fine.
    // It's also a LOT simpler.  We could narrow down by from or to or
    // even trigger... but then we end up dispatching at least twice to
    // catch the wild-cards.  
    private Multimap<TransitionPredicate, TransitionListener<T>> listeners 
                    = MultimapBuilder.linkedHashKeys().arrayListValues().build();

    // Since there is no real 'stopped' state we will keep special
    // listeners
    private List<TransitionListener<T>> stopListeners = new ArrayList<>();

    private State currentState;
    private State start;
 
    public StateMachine() {
    }
 
    protected void needsRunning() {
        if( !isRunning() ) {
            throw new IllegalStateException("StateMachine is not running");
        }
    }

    protected void needsNotRunning() {
        if( isRunning() ) {
            throw new IllegalStateException("StateMachine is running");
        }
    }
 
    public void start() {
        start(null);
    }
    
    public void start( Object payload ) {    
        needsNotRunning();
        setCurrentState(start, null, payload);        
    }

    public void trigger( T trigger ) {
        trigger(trigger, null);
    }
    
    public void trigger( T trigger, Object payload ) {
        needsRunning();

        if( log.isTraceEnabled() ) {
            log.trace("trigger(" + trigger + ", " + payload + ")");
        }
                
        // Check the state first
        State to = null;
        if( currentState.transitions.containsKey(trigger) ) {
            to = currentState.transitions.get(trigger);
        } else if( defaultTransitions.containsKey(trigger) ) {
            to = defaultTransitions.get(trigger);
        } else {
            throw new IllegalArgumentException("Trigger:[" + trigger 
                                                + "] does not transition from:" + currentState);
        }
        setCurrentState(to, trigger, payload);
    }

    protected void setCurrentState( State to, T cause, Object payload ) {
        if( log.isTraceEnabled() ) {
            log.trace("setCurrentState(" + to + ", " + cause + ", " + payload + ")");
        }
        State from = currentState;
        currentState = to;
        fireTransition(from, to, cause, payload);
    }

    public StateMachine addDefaultTransition( T trigger, State to ) {
        needsNotRunning();        
        defaultTransitions.put(trigger, to);
        return this;
    }

    public StateMachine addDefaultTransition( T trigger, K to ) {
        needsNotRunning();        
        defaultTransitions.put(trigger, getState(to));
        return this;
    }
 
    public StateMachine addDefaultTermination( T trigger ) {
        needsNotRunning();        
        defaultTransitions.put(trigger, null);
        return this;
    }
       
    public StateMachine addTransitionListener( State from, State to, T trigger, Class payloadType, TransitionListener<T> l ) {
        needsNotRunning();        
        TransitionPredicate p = new TransitionPredicate(from, to, trigger, payloadType);
        listeners.put(p, l);       
        return this;
    }

    public StateMachine removeTransitionListener( State from, State to, T trigger, Class payloadType, TransitionListener<T> l ) {
        needsNotRunning();        
        TransitionPredicate p = new TransitionPredicate(from, to, trigger, payloadType);
        listeners.remove(p, l);       
        return this;
    }
 
    /**
     *  Adds a transition listener that will be notified whenever the state
     *  machine stops, for whatever reason.
     */   
    public StateMachine onStop( TransitionListener<T> l ) {
        stopListeners.add(l);
        return this;
    }

    public StateMachine onStop( Runnable r ) {
        return onStop(new TransitionListenerRunnableAdapter<T>(r));
    }
  
    protected void fireTransition( State from, State to, T trigger, Object payload ) {
        TransitionEvent<T> event = new TransitionEvent<>(this, from, to, trigger, payload);
        
        // Hacking this for the moment to run all of the 'exit only' listeners
        // first... probably we need better sort semantics.
        // From the user's perspective, it's weird if they see 'enter' events
        // before 'exit' events... even though a transition is a transition.
        for( TransitionPredicate p : listeners.keySet() ) {
            if( p.to == null && p.apply(event) ) {
                for( TransitionListener<T> l : listeners.get(p) ) {
                    l.transition(event);
                }
            }
        } 
        for( TransitionPredicate p : listeners.keySet() ) {
            if( p.to != null && p.apply(event) ) {
                for( TransitionListener<T> l : listeners.get(p) ) {
                    l.transition(event);
                }
            }
        }
        
        if( to == null ) {
            // Run stop listeners lat of all
            for( TransitionListener<T> l : stopListeners ) {
                l.transition(event);
            }
        } 
    }
    
    public boolean isRunning() {
        return currentState != null;
    }
    
    public State getCurrentState() {
        return currentState;
    }
    
    public State getState( K id ) {
        return getState(id, true);
    }

    public State getState( K id, boolean create ) {
        if( id == null ) {
            return null;
        }
        State result = states.get(id);
        if( result == null && create ) {
            // Running state machines are supposed to be immutable
            needsNotRunning();
            result = new State(id);
            states.put(id, result);
        }
        return result;
    }

    public State setStart( K id ) {
        return setStart(getState(id));
    }
 
    public State setStart( State start ) {
        needsNotRunning();
        this.start = start;
        return start;
    }
    
    public State getStart() {
        return start;
    }
     
    public Set<State> findOrphanStates() {
        Set<State> results = new HashSet<>();
        for( State state : states.values() ) {
            if( state.transitions.isEmpty() ) {
                results.add(state);
            }
        }
        return results;
    }
     
    public class State {
        private K id;
        private Map<T, State> transitions = new HashMap<>();
        
        public State( K id ) {
            this.id = id;
        }

        public K getId() {
            return id;
        }
        
        /**
         *  Adds a transition from this state to the specified state that
         *  is initiated by the specified trigger.
         */
        public State addTransition( T trigger, State to ) {
            transitions.put(trigger, to);
            return this;
        }

        public State addTransition( T trigger, K to ) {
            transitions.put(trigger, getState(to));
            return this;
        }
 
        public State addTermination( T trigger ) {
            transitions.put(trigger, null);
            return this;
        }
        
        public State onEnter( TransitionListener<T> l ) {
            addTransitionListener(null, this, null, null, l);
            return this;
        }

        public State onExit( TransitionListener<T> l ) {
            addTransitionListener(this, null, null, null, l);
            return this;
        }

        public State onEnter( Runnable r ) {
            return onEnter(new TransitionListenerRunnableAdapter<T>(r));
        }

        public State onExit( Runnable r ) {
            return onExit(new TransitionListenerRunnableAdapter<T>(r));
        }
 
        public int hashCode() {
            return id.hashCode();
        }
        
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            @SuppressWarnings("unchecked")        
            State other = (State)o;
            return Objects.equals(other.id, id);
        }
        
        public String toString() {
            return "State[" + id + "]";
        }
    }
 
    private class TransitionPredicate implements Predicate<TransitionEvent> {
        private State from;
        private State to;
        private T trigger;
        private Class payloadType;
        
        public TransitionPredicate( State from, State to, T trigger, Class payloadType ) {
            this.from = from;
            this.to = to;
            this.trigger = trigger;
            this.payloadType = payloadType;
        }

        public boolean apply( TransitionEvent event ) {
            if( from != null && !Objects.equals(from, event.getFrom()) ) {
                return false;
            }
            if( to != null && !Objects.equals(to, event.getTo()) ) {
                return false;
            }
            if( trigger != null && !Objects.equals(trigger, event.getTrigger()) ) {
                return false;
            }
            if( payloadType != null ) {
                @SuppressWarnings("unchecked")
                Object payload = event.getPayload(payloadType);
                if( payload == null ) {        
                    return false;
                }
            }
            return true;
        }
        
        public int hashCode() {
            return Objects.hash(from, to, trigger, payloadType);
        }
 
        public boolean equals( Object o ) {
            if( o == this ) {
                return true;
            }
            if( o == null || o.getClass() != getClass() ) {
                return false;
            }
            @SuppressWarnings("unchecked")
            TransitionPredicate other = (TransitionPredicate)o;
            if( !Objects.equals(other.from, from) ) {
                return false;
            }
            if( !Objects.equals(other.to, to) ) {
                return false;
            }
            if( !Objects.equals(other.trigger, trigger) ) {
                return false;
            }
            if( !Objects.equals(other.payloadType, payloadType) ) {
                return false;
            }
            return true;
        }
    }
 
    private class TransitionListenerRunnableAdapter<T> implements TransitionListener<T> {
        private Runnable delegate;
        
        public TransitionListenerRunnableAdapter( Runnable delegate ) {
            this.delegate = delegate;
        }
        
        public void transition( TransitionEvent event ) {
            delegate.run();
        }
    }    
}



