/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.fsm;

import com.google.common.base.MoreObjects;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TransitionEvent<T> {
    
    private StateMachine fsm;
    private StateMachine.State from;
    private StateMachine.State to;
    private T trigger;
    private Object payload;
    
    public TransitionEvent( StateMachine fsm, StateMachine.State from, StateMachine.State to, T trigger, Object payload ) {
        this.fsm = fsm;
        this.from = from;
        this.to = to;
        this.trigger = trigger;
        this.payload = payload;
    }
    
    public StateMachine getStateMachine() {
        return fsm;
    }
    
    public StateMachine.State getFrom() {
        return from;
    }
    
    public StateMachine.State getTo() {
        return to;
    }
    
    public T getTrigger() {
        return trigger;
    }
    
    public <P> P getPayload( Class<P> type ) {
        if( !type.isInstance(payload) ) {
            return null;            
        }
        return type.cast(payload);
    }
 
    public Object getPayload() {
        return payload;
    }
    
    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .omitNullValues()
            .add("from", from)
            .add("to", to)
            .add("trigger", trigger)
            .add("payload", payload)
            .toString();
    }  
}
