#import "Common/ShaderLib/GLSLCompat.glsllib"
#import "Common/ShaderLib/Instancing.glsllib"
#import "Common/ShaderLib/Skinning.glsllib"
#import "Common/ShaderLib/MorphAnim.glsllib"
#import "MatDefs/TerrainTile.glsllib"

attribute vec3 inPosition;
attribute vec2 inTexCoord;

varying vec2 texCoord;

//float getElevation( vec2 pos ) {
//    float sinX = sin(pos.x * 0.25); 
//    //float cosX = cos(modelSpacePos.x * 0.25); 
//    float sinY = sin(pos.y * 0.25); 
//    //float cosZ = cos(modelSpacePos.z * 0.25);
//    return (sinX + sinY) * 2.5; 
//}

void main(){
    vec4 modelSpacePos = vec4(inPosition, 1.0);

    //texCoord = getMapPosition(modelSpacePos.xyz);
    texCoord = getMapPosition(inTexCoord);
    float y = getElevation(texCoord);
    modelSpacePos.y = y;

   #ifdef NUM_MORPH_TARGETS
           Morph_Compute(modelSpacePos, modelSpaceNorm);
   #endif

   #ifdef NUM_BONES
       Skinning_Compute(modelSpacePos);
   #endif
    gl_Position = TransformWorldViewProjection(modelSpacePos);
    texCoord = inTexCoord;
}
