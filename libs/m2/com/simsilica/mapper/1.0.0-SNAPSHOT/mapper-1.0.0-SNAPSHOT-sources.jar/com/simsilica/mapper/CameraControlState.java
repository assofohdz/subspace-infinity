/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.lemur.input.*;

import com.simsilica.mathd.*;

import com.simsilica.fractal.*;


/**
 *  Control the camera position, angle, and zoom.
 *
 *  @author    Paul Speed
 */
public class CameraControlState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(CameraControlState.class);
 
    private double zoom = 4525; //1024;
    //private double zoom = 401;
    private VersionedHolder<Double> zoomHolder = new VersionedHolder<>(zoom);
    private double turnSpeed = 1;
    private double yaw = Math.PI;
    private double maxPitch = Math.PI * 0.5;
    private double minPitch = 0; //-Math.PI * 0.5;
    private double pitch = maxPitch;

    private Quatd facing = new Quatd().fromAngles(pitch, yaw, 0);
    private Quatd moveDir = new Quatd().fromAngles(0, yaw, 0); 
    private Vec3d movementForce = new Vec3d();

    private Vec3d position = new Vec3d(33000, 0, 32000);
    private VersionedHolder<Vec3d> positionHolder = new VersionedHolder<>(position);

    private double walkSpeed = 0.5;  // units/sec
    private double runSpeed = 2;  // units/sec
    private double currentSpeed = walkSpeed;

    private boolean invertPitch;

    private MoveInputListener inputListener = new MoveInputListener();
    private InputMapper inputMapper;

    //private Sampler elevation;
 
    public CameraControlState() {        
    }
    
    public void setPosition( Vec3d position ) {
        this.position.set(position);
        positionHolder.incrementVersion();
        updateElevation();
    }
 
    public VersionedReference<Vec3d> createPosRef() {
        return positionHolder.createReference();
    }

    public VersionedReference<Double> createZoomRef() {
        return zoomHolder.createReference();
    }
    
    @Override
    protected void initialize( Application app ) {

        this.zoom = MapperConfig.getInstance().getStartupSetting("zoom", zoom);
        zoomHolder.setObject(zoom);

        //this.elevation = getState(MapState.class).getElevation();
 
        inputMapper = GuiGlobals.getInstance().getInputMapper();
        CameraFunctions.initializeDefaultMappings(inputMapper);
    
        // Most of the movement functions are treated as analog.
        inputMapper.addAnalogListener(inputListener,
                                      CameraFunctions.F_Y_LOOK,
                                      CameraFunctions.F_X_LOOK,
                                      CameraFunctions.F_MOVE,
                                      CameraFunctions.F_ZOOM,
                                      CameraFunctions.F_STRAFE);

        // Only run mode is treated as a 'state' or a trinary value.
        // (Positive, Off, Negative) and in this case we only care about
        // Positive and Off.  See CameraFunctions for a description
        // of alternate ways this could have been done.
        inputMapper.addStateListener(inputListener,
                                     CameraFunctions.F_RUN);
    
    }
    
    @Override
    protected void cleanup( Application app ) {
        inputMapper.removeAnalogListener(inputListener,
                                         CameraFunctions.F_Y_LOOK,
                                         CameraFunctions.F_X_LOOK,
                                         CameraFunctions.F_MOVE,
                                         CameraFunctions.F_ZOOM,
                                         CameraFunctions.F_STRAFE);
        inputMapper.removeStateListener(inputListener,
                                        CameraFunctions.F_RUN);
    }

    @Override
    protected void onEnable() {
        // Make sure our input group is enabled
        inputMapper.activateGroup(CameraFunctions.GROUP_MOVEMENT);
        updateCamera();
    }

    @Override
    protected void onDisable() {
        inputMapper.deactivateGroup(CameraFunctions.GROUP_MOVEMENT);
    }

    @Override
    public void update( float tpf ) {

        if( movementForce.lengthSq() != 0 ) {
            //log.info("moving:" + movementForce);
            updateElevation();            
            updateCamera();
        }
    }
    
    protected double clampPitch( double pitch ) {
        if( pitch < minPitch ) {
            return minPitch;
        }
        if( pitch > maxPitch ) {
            return maxPitch;
        }
        return pitch;
    }
 
    protected void updateElevation() {
        position.addLocal(moveDir.mult(movementForce));
        position.y = getState(MapState.class).getElevation().getSample(position.x, 0, position.z);
        positionHolder.incrementVersion();
    }
 
    protected void updateCamera() {
        //log.info("yaw:" + yaw + "  pitch:" + pitch + "  zoom:" + zoom);
 
        facing = new Quatd().fromAngles(pitch, yaw, 0);       
        moveDir = new Quatd().fromAngles(0, yaw, 0);       
        getApplication().getCamera().setRotation(facing.toQuaternion());
        
        Vec3d loc = facing.mult(new Vec3d(0, 0, (float)-zoom));
        if( zoom < 100 ) {
            loc.y += position.y * (1024.0/32768);
        } else if( zoom < 200 ) {
            // Tween it
            double scale = (200 - zoom)/100.0;
            loc.y += position.y * (1024.0/32768) * scale;
        } 
        getApplication().getCamera().setLocation(loc.toVector3f());

        zoomHolder.updateObject(zoom);        
    }
    
    private class MoveInputListener implements AnalogFunctionListener, StateFunctionListener {

        @Override
        public void valueChanged( FunctionId func, InputState value, double tpf ) {

            // Change the speed based on the current run mode
            // Another option would have been to use the value
            // directly:
            //    speed = 3 + value.asNumber() * 5
            //...but I felt it was slightly less clear here.
            boolean b = value == InputState.Positive;
            if( func == CameraFunctions.F_RUN ) {
                if( b ) {
                    currentSpeed = runSpeed;
                } else {
                    currentSpeed = walkSpeed;
                }
            }
        }

        @Override
        public void valueActive( FunctionId func, double value, double tpf ) {

            // Setup rotations and movements speeds based on current
            // axes states.
            if( func == CameraFunctions.F_Y_LOOK ) {
                pitch = clampPitch(pitch - value * tpf * turnSpeed);
                updateCamera();
            } else if( func == CameraFunctions.F_X_LOOK ) {
                yaw += -value * tpf * turnSpeed;
                if( yaw < 0 ) {
                    yaw += Math.PI * 2;
                }
                if( yaw > Math.PI * 2 ) {
                    yaw -= Math.PI * 2;
                }
                updateCamera();
            } else if( func == CameraFunctions.F_MOVE ) {
                movementForce.z = value * currentSpeed * zoom;
            } else if( func == CameraFunctions.F_STRAFE ) {
                // Mappings are set to treat right as positive and left as
                // negative because that's the way things like mice and joysticks
                // are already setup.  However, this is backwards from JME's handedness
                // which when looking down Z, left is positive.  So we'll swap the
                // force.
                movementForce.x = -value * currentSpeed * zoom;
            } else if( func == CameraFunctions.F_ZOOM ) {
                
                if( value > 0 ) {
                    zoom = zoom * 0.9;
                    if( zoom < 1 ) {
                        zoom = 1;   
                    }
                } else if( value < 0 ) {
                    zoom = zoom * 1.111;
                    if( zoom > 10000 ) {
                        zoom = 10000;
                    }
                }
                
                //zoom -= value;
                
                updateCamera();
            }
        }
    }    
}


