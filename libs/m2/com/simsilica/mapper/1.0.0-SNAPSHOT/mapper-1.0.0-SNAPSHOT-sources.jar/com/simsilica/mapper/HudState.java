/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.state.DebugHudState;
import com.simsilica.thread.JobState;


/**
 *  Just addds some application specific stuff to the HUD
 *
 *  @author    Paul Speed
 */
public class HudState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(HudState.class);

    private VersionedHolder<String> posText;
    private VersionedHolder<String> climateText;
    private VersionedHolder<String> layer1Text;
    private VersionedHolder<String> zoomText;
    private VersionedHolder<String> jobsText;    

    private VersionedReference<Vec3d> posRef;
    private VersionedReference<Double> zoomRef;
    private VersionedReference<Integer> queuedRef;
    private VersionedReference<Integer> activeRef;

    public HudState() {        
    }
    
    @Override
    protected void initialize( Application app ) {
        posText = getState(DebugHudState.class).createDebugValue("Focus", DebugHudState.Location.Right); 
        climateText = getState(DebugHudState.class).createDebugValue("Climate", DebugHudState.Location.Right); 
        layer1Text = getState(DebugHudState.class).createDebugValue("Layer 1", DebugHudState.Location.Right); 
        zoomText = getState(DebugHudState.class).createDebugValue("Zoom", DebugHudState.Location.Right); 
        jobsText = getState(DebugHudState.class).createDebugValue("Jobs", DebugHudState.Location.Right);
        
        posRef = getState(CameraControlState.class).createPosRef();
        zoomRef = getState(CameraControlState.class).createZoomRef();
        queuedRef = getState(JobState.class).createQueuedCountReference();
        activeRef = getState(JobState.class).createActiveCountReference();
        
        zoomText.updateObject(String.format("%.0f", zoomRef.get()));
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        if( posRef.update() ) {
            Vec3d pos = posRef.get();
            posText.updateObject(String.format("%.0f, %.0f, %.0f", pos.x, pos.y, pos.z));
 
            double val = getState(MapState.class).getColoring().getSample(pos.x, pos.y, pos.z);            
            climateText.updateObject(String.format("%.03f", val));
            
            val = getState(MapState.class).getLayers()[1].getSample(pos.x, pos.y, pos.z);
            layer1Text.updateObject(String.format("%.03f", val));
        }
        if( zoomRef.update() ) {
            zoomText.updateObject(String.format("%.0f", zoomRef.get()));
        }
        if( queuedRef.update() || activeRef.update() ) {
            jobsText.updateObject("Queued:" + queuedRef.get() + " Active:" + activeRef.get());
        }
    }
}
