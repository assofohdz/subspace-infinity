/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.nio.*;

import org.slf4j.*;

import com.jme3.texture.Image;
import com.jme3.texture.image.ColorSpace;
import com.jme3.util.BufferUtils;

import com.simsilica.mathd.*;

import com.simsilica.fractal.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Tile {

    static Logger log = LoggerFactory.getLogger(Tile.class);

    private int tileSize;
    private TileMesh tileMesh;
    private TileKey key;
    private Image image;
    private Image layerImage;
    
    public Tile( TileKey key, TileMesh tileMesh ) {
        this.key = key;
        this.tileSize = key.getTileSize();
        this.tileMesh = tileMesh;
    }

    public TileKey getKey() {
        return key;
    }

    public TileMesh getTileMesh() {
        return tileMesh;
    }

    public Image getImage() {
        return image;
    }

    public Image getLayerImage() {
        return layerImage;
    }

    public int getTileSize() {
        return tileSize;
    }
    
    public void update( Sampler elevation, Sampler coloring, Sampler[] layers ) {
        if( image == null ) {
            image = tileMesh.createImage();
        }
        if( layerImage == null ) {
            layerImage = tileMesh.createImage();
        }
        Vec3i world = key.getCell().getWorldOrigin();        
  
        /// This isn't right in the long run but we're still using
        // the old code for the moment.  When we switch up the mapping
        // of vertex to texture this will need to just be tileSize/meshSpacing
        //double skip = (double)tileSize/tileMesh.getImageSize();
        double skip = (double)tileSize/tileMesh.getMeshSpacing(); 
        Sampler resampled = Samplers.resample(elevation, skip, 1, skip);
        Sampler resampled2 = Samplers.resample(coloring, skip, 1, skip); 
        // Because we're resampling, we need to adjust our world coordinates into
        // 'resampled space'.
        int xSource = (int)(world.x / skip);
        int zSource = (int)(world.z / skip);
 
        //tileMesh.writeToImage(resampled, resampled2, xSource, zSource, image);

        Sampler[] relayers = new Sampler[layers.length];
        for( int i = 0; i < relayers.length; i++ ) {
            relayers[i] = Samplers.resample(layers[i], skip, 1, skip);
        }
        //tileMesh.writeToImage(relayers, xSource, zSource, layerImage);
        tileMesh.writeToImage(resampled, resampled2, relayers, xSource, zSource, image, layerImage);
    }
}


