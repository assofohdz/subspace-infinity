/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.nio.*;

import org.slf4j.*;

import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer;
import com.jme3.texture.Image;
import com.jme3.texture.image.ColorSpace;
import com.jme3.util.BufferUtils;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

import com.simsilica.fractal.Sampler;

/**
 *  Encapsulates the mesh generation, image creation, and image writing
 *  for a tile.  
 *
 *  @author    Paul Speed
 */
public class TileMesh implements VersionedObject<Mesh> {
    static Logger log = LoggerFactory.getLogger(TileMesh.class);
 
    private long version = 0;
 
    // The physical size of the tile mesh, not the number of
    // vertexes. Even better... the spacing between meshes.  
    private int meshSpacing;
    
    // The number of desired vertexes sampling heights.  The
    // actual mesh and images will be one unit bigger to accomodate
    // the border joining tiles.  ie: if tiles are 1024x1024 then
    // when placed side to side there will be a gap.  So we actually
    // add an additional border.  It's not just a matter of increasing
    // the size by one because the spacing between the other points
    // will depend on the ratio of imageSize and meshSpacing while the
    // border will always be one unit wide.
    // ...and I guess in image space it's also complicated by the
    // fact that texture scaling needs to be linear.  So even if the
    // mesh may be irregular and not 1:1, the raw image data needs
    // to be linearly laid out.  So it will exceed the boundaries of
    // the shape and we'll sample the space between?  Borders will
    // never perfectly line up this way but it's better than big
    // 1 unit gaps.  The only way we could fix it would be with 
    // texture coordinates... more RAM.  That would allow the border
    // edge to have border texture coordinates even if the mesh
    // is non-linear at the borders.  The former-gap would just represent
    // a slightly higher-res area than the rest of the mesh, ie: we
    // squish the texture that was already 1:1 mapping of vertex to texel
    // anyway.  The whole original problem stems from using vertex coordinates
    // as texture coordinates.
    private int imageSize;
    private Mesh mesh;
    private int bufferSize;
 
    // Same in both x and z   
    private double[] samples;
    
    public TileMesh( int meshSpacing, int imageSize ) {
        this.meshSpacing = meshSpacing;
        this.imageSize = imageSize;
        this.bufferSize = imageSize + 1;
    }
 
    public long getVersion() {
        return version;
    }
    
    public Mesh getObject() {
        return getMesh();
    }
    
    public VersionedReference<Mesh> createReference() {
        return new VersionedReference<>(this);
    }
 
    /**
     *  Returns the physical size of the mesh in units from the
     *  lowest coordinate to the highest tile coordinate.  This 
     *  does not include any additional space for borders.
     */   
    public int getMeshSpacing() {
        return meshSpacing;
    }
 
    /**
     *  Returns the number of samples represented by getMeshSpacing().
     *  For example, a mesh size of 1024 and an image size of 512
     *  means that effectively every other vertex is skipped.
     */   
    public int getImageSize() {
        return imageSize;
    }
 
    /**
     *  Returns the texture scale to use to go from model space
     *  to texture space.
     */   
    public float getTileScale() {
        return 1f/meshSpacing;
    }
    
    public Mesh getMesh() {
        if( mesh != null ) {
            return mesh;
        }

        mesh = new Mesh();
        mesh.setMode(Mesh.Mode.TriangleStrip);

log.info("creating mesh at spacing:" + meshSpacing + "   imageSize:" + imageSize);

        float step = (float)meshSpacing / imageSize;
        float texMax = Math.min(meshSpacing, bufferSize * step);

        samples = new double[bufferSize];
        for( int i = 0; i < bufferSize; i++ ) {
            // no matter how big step size is, we will never
            // go outside of 'meshspacing'... which should put us
            // all the way sharing the border with out neighbor.
            // For example, 0...1024
            samples[i] = Math.min(i * step, meshSpacing);
        }

        // So now we can just populate the mesh from our values
        
        float[] fv = new float[bufferSize * bufferSize * 3];
        float[] tv = new float[bufferSize * bufferSize * 2];
        int vIndex = 0;
        int tIndex = 0;
        for( int z = 0; z < bufferSize; z++ ) {
            for( int x = 0; x < bufferSize; x++ ) {
                fv[vIndex++] = (float)samples[x];
                fv[vIndex++] = (float)0;
                fv[vIndex++] = (float)samples[z];

                tv[tIndex++] = (float)samples[x]/texMax; 
                tv[tIndex++] = (float)samples[z]/texMax;                    
            }                        
        }                         
         
        // Build an index buffer for a triangle strip.  The first three
        // start a triangle and then the next joins the previous two, and so on.
        //
        // So each row takes width * 2 indexes plus one extra.
        // ie: we end row one on 7 but add 9 also.  That gives us the 678 degenerate
        // triangle.
        // Row 2 adds 9 which gives us the second 789 degenerate triangle.
        // then it adds A which gives us the third 89A...then we are back on cycle.
        // But note that each 'row' in this cases is actually straddling two rows
        // of vertexes... so we need one less in the buffer in the end.
        int[] ib = new int[(bufferSize * 2 + 1) * (bufferSize-1)];
        int index = 0;

        for( int row = 0; row < bufferSize-1; row++ ) {
            if( (row % 2) == 0 ) {
                // Even rows
                // Top version is for x-right, z-up style winding. ie: if we let
                // x go 0 to 1024 and z go 0 to 1024 then it will face down and not up.
                //for( int col = w-1; col >= 0; col-- ) {
                for( int col = 0; col < bufferSize; col++ ) {
                    ib[index++] = col + row * bufferSize;
                    ib[index++] = col + (row + 1) * bufferSize;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            } else {
                // Odd rows
                for( int col = bufferSize-1; col >= 0; col-- ) {
                //for( int col = 0; col < w; col++ ) {
                    ib[index++] = col + row * bufferSize;
                    ib[index++] = col + (row + 1) * bufferSize;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            }
        }

        mesh.setBuffer(VertexBuffer.Type.Position, 3, fv);
        mesh.setBuffer(VertexBuffer.Type.TexCoord, 2, tv);
        mesh.setBuffer(VertexBuffer.Type.Index, 1, ib);
        mesh.updateBound();
        mesh.setStatic();

        return mesh; 
    }
    
    public Image createImage() {
        // For now just what we've been doing
        ByteBuffer imageData = BufferUtils.createByteBuffer(bufferSize * bufferSize * 4);
        return new Image(Image.Format.ARGB8, bufferSize, bufferSize, imageData, null, ColorSpace.Linear);        
    }
 
    // Elevations should return values between 0 and 65000
    // Coloring should be between 0 and 1   
    public void writeToImage( Sampler elevations, Sampler coloring, double xSource, double zSource, Image image ) {
        ByteBuffer data = image.getData(0);        
        
        for( int z = 0; z < bufferSize; z++ ) {
            for( int x = 0; x < bufferSize; x++ ) {
                double elevation = elevations.getSample(xSource + samples[x], 0, zSource + samples[z]); 
                int val = (int)elevation;
                int col = (int)(coloring.getSample(xSource + samples[x], elevation, zSource + samples[z]) * 255);
                // We support +/- 32500... which means we need to offset
                val += 32500;
                
                if( val < 0 ) {
                    // invert it up
                    val = -val; 
                } else if( val > 65000 ) {
                    // Invert it down
                    val = val - 65000;
                    val = 65000 - val;
                }
 
                // The bytes will be passed through as a float where 0 = 0
                // and 1 == 255.  So to fit our stuff in we have to break it up
                // appropriately.
                int hi = (int)(val / 255);
                int lo = (int)(val % 255);
                
                byte a = (byte)hi;
                byte r = (byte)lo;

                if( col < 0 ) {
                    hi = 0;
                    lo = -col;  // already multiplied by 255
                } else if( col >= 0 ) {
                    hi = col; // already multiplied by 255
                    lo = 0;
                }                
                byte g = (byte)hi; // positive
                byte b = (byte)lo; // negative
                
                data.put(a).put(r).put(g).put(b);
            }
        }        
    }
    
    public void writeToImage( Sampler[] sources, double xSource, double zSource, Image image ) {
        ByteBuffer data = image.getData(0);
                
        for( int z = 0; z < bufferSize; z++ ) {
            for( int x = 0; x < bufferSize; x++ ) {
                for( int i = 0; i < 4; i++ ) {
                    double val = sources[i].getSample(xSource + samples[x], 0, zSource + samples[z]); 
                    data.put((byte)(val * 255));
                }
            }
        }        
    }



    public void writeToImage( Sampler elevations, Sampler coloring, Sampler[] sources, 
                              double xSource, double zSource, Image image, Image layers ) {
        ByteBuffer data1 = image.getData(0);        
        ByteBuffer data2 = layers.getData(0);        
        
        for( int z = 0; z < bufferSize; z++ ) {
            for( int x = 0; x < bufferSize; x++ ) {
                double elevation = elevations.getSample(xSource + samples[x], 0, zSource + samples[z]); 
                int val = (int)elevation;
                int col = (int)(coloring.getSample(xSource + samples[x], elevation, zSource + samples[z]) * 255);
                // We support +/- 32500... which means we need to offset
                val += 32500;
                
                if( val < 0 ) {
                    // invert it up
                    val = -val; 
                } else if( val > 65000 ) {
                    // Invert it down
                    val = val - 65000;
                    val = 65000 - val;
                }
 
                // The bytes will be passed through as a float where 0 = 0
                // and 1 == 255.  So to fit our stuff in we have to break it up
                // appropriately.
                int hi = (int)(val / 255);
                int lo = (int)(val % 255);
                
                byte a = (byte)hi;
                byte r = (byte)lo;

                if( col < 0 ) {
                    hi = 0;
                    lo = -col;  // already multiplied by 255
                } else if( col >= 0 ) {
                    hi = col; // already multiplied by 255
                    lo = 0;
                }                
                byte g = (byte)hi; // positive
                byte b = (byte)lo; // negative
                
                data1.put(a).put(r).put(g).put(b);
                
                for( int i = 0; i < 4; i++ ) {
                    double d = sources[i].getSample(xSource + samples[x], elevation, zSource + samples[z]); 
                    data2.put((byte)(d * 255));
                }
            }
        }        
    }
       
}


