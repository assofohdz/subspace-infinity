/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;
import java.util.function.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;

import com.simsilica.mathd.*;

import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.lemur.event.*;


/**
 *  Keeps track of world markers and renders them when appropriate.
 *
 *  @author    Paul Speed
 */
public class MarkerState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(MarkerState.class);

    private VersionedReference<Vec3d> posRef;

    // MapViewState has the following grid sizes
    //  new TileGrid(this, 8, 65536, settings, tileMesh, tileMat1, hexSize),
    //  new TileGrid(this, 7, 32768, settings, tileMesh, tileMat2, hexSize),
    //  new TileGrid(this, 6, 16384, settings, tileMesh, tileMat3, hexSize),
    //  new TileGrid(this, 5, 8192, settings, tileMesh, tileMat4, hexSize),
    //  new TileGrid(this, 4, 4096, settings, tileMesh, tileMat5, hexSize),
    //  new TileGrid(this, 3, 2048, settings, tileMesh, tileMat6, hexSize),
    //  new TileGrid(this, 2, 1024, settings, tileMesh, tileMat6, hexSize),
    //  new TileGrid(this, 1, 512, settings, tileMesh, tileMat7, hexSize),
    //  new TileGrid(this, 0, 256, settings, tileMesh, tileMat7, hexSize)
    // 
    // We don't really need to go any more granular than 1024 probably and
    // given the relative sparseness of our data, we may never have to roll
    // up either.  At least not to do the job we need.  But need to keep the
    // idea of layering in our back pocket.
    //
    private Grid markerGrid = new Grid(1024, 0, 1024);    
    private Map<String, Map<GridCell, GridMarkers>> layerIndex = new HashMap<>();             
    private String defaultLayer = "default";
 
    private Set<GridMarkers> pending = new HashSet<>();
    
    private Map<String, Pin> pinIndex = new HashMap<>();
    private PinListener pinListener = new PinListener();
    
    private Node viewRoot;
    private float masterScale;

    public MarkerState() {        
    }   
 
    public void setDefaultLayer( String defaultLayer ) {
        this.defaultLayer = defaultLayer == null ? "default" : defaultLayer;
    }
    
    public String getDefaultLayer() {
        return defaultLayer;
    }
    
    public void addLine( Vec3d e1, Vec3d e2, ColorRGBA color1, ColorRGBA color2 ) {
        addLine(defaultLayer, e1, e2, color1, color2);
    }
    
    public void addLine( Vec3d e1, Vec3d e2, ColorRGBA color ) {    
        addLine(defaultLayer, e1, e2, color);
    }
    
    public void addLine( String layer, Vec3d e1, Vec3d e2, ColorRGBA color ) {
        addLine(layer, e1, e2, color, color);
    }

    public void addLine( String layer, Vec3d e1, Vec3d e2, ColorRGBA color1, ColorRGBA color2 ) {
        LineMarker line = new LineMarker(e1, e2, color1, color2);
        getGridMarkers(layer, e1, true).add(line);
    }
    
    public Pin addPin( String id, Vec3d pos, double height, double radius, ColorRGBA color ) {
        return addPin(defaultLayer, id, pos, height, radius, color);
    } 

    public Pin addPin( String layer, String id, Vec3d pos, double height, double radius, ColorRGBA color ) {
        String key = layer + "." + id;
        Pin existing = pinIndex.get(key);
        if( existing != null ) {
            throw new IllegalArgumentException("Pin already exists for layer:" + layer + ", id:" + id);
        }
        Pin pin = new Pin(key, id, pos, height, radius, color);
        pinIndex.put(key, pin);        
        getGridMarkers(layer, pos, true).add(pin);
        return pin;
    }
    
    public Pin getPin( String id ) {
        return getPin(defaultLayer, id);
    } 

    public Pin getPin( String layer, String id ) {
        String key = layer + "." + id;
        return pinIndex.get(key);
    } 

    public void clear() {
        clear(defaultLayer);
    }
 
    public void clear( String layer ) {
        Map<GridCell, GridMarkers> index = getLayer(layer, false);
        if( index == null ) {
            return;
        }
        for( GridMarkers markers : index.values() ) {
            markers.gridRoot.removeFromParent();
        }
        index.clear();
        pending.clear();
        
        for( Iterator<Map.Entry<String, Pin>> it = pinIndex.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, Pin> e = it.next();
            if( e.getKey().startsWith(layer + ".") ) {
                it.remove();
            }
        }
    }
 
    protected Map<GridCell, GridMarkers> getLayer( String layer, boolean create ) {    
        Map<GridCell, GridMarkers> result = layerIndex.get(layer);
        if( result == null && create ) {
            result = new HashMap<>();
            layerIndex.put(layer, result);
        }
        return result;
    } 
 
    protected GridMarkers getGridMarkers( String layer, Vec3d v, boolean create ) {
        Map<GridCell, GridMarkers> index = getLayer(layer, create);
        if( index == null ) {
            return null;
        }
        GridCell cell = markerGrid.getContainingCell(v);
        GridMarkers result = index.get(cell);
        if( result == null && create ) {
            result = new GridMarkers(cell);
            result.updatePosition(posRef.get());
            index.put(cell, result);
        }
        return result;
    } 

    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }
    
    @Override
    protected void initialize( Application app ) {
        this.posRef = getState(CameraControlState.class).createPosRef();

        viewRoot = new Node("markerRoot");
        // Set the master scale
        masterScale = 1024f/32767;
        viewRoot.setLocalScale(masterScale);

        // Add a test line
        //addLine(new Vec3d(928134, 137, 1030409), 
        //        new Vec3d(928134, 700, 1030409),
        //        new ColorRGBA(1, 0, 0, 1)); 
        //
        //addLine(new Vec3d(1043520, 225, 1018112), 
        //        new Vec3d(1043520, 700, 1018112),
        //        new ColorRGBA(0, 0, 1, 1));
        //
        //addPin("test", "test", new Vec3d(1043520, 225, 1018112), 500, 50, ColorRGBA.Red);  
                
        updateGridPositions();
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
    }
    
    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }
    
    @Override
    public void update( float tpf ) {
        if( !pending.isEmpty() ) {
            for( GridMarkers markers : pending ) {
                markers.rebuild();
            }
            pending.clear();
        }
    
        if( posRef.update() ) {
            updateGridPositions();
        }
    }
    
    protected void updateGridPositions() {
        Vec3d pos = posRef.get();
 
        for( Map<GridCell, GridMarkers> index : layerIndex.values() ) {  
            for( GridMarkers markers : index.values() ) {
                markers.updatePosition(pos);
            }
        }
    }
    
    private class PinListener extends DefaultCursorListener {
        protected void click( CursorButtonEvent event, Spatial target, Spatial capture ) {
            log.info("event:" + event);
            if( target == null ) {
                return;
            }
            String key = target.getUserData("key");
            log.info("key:" + key);
            Pin pin = pinIndex.get(key);
            log.info("Clicked pin:" + pin);
            if( pin != null ) {
                try {
                    pin.fireClicked();
                } catch( Exception e ) {
                    // Don't kill the whole app
                    log.error("Error in click handler", e);
                }
            } 
        } 
    }
    
    private class LineMarker {
        Vec3d e1;
        Vec3d e2;
        ColorRGBA color1;
        ColorRGBA color2;
        
        public LineMarker( Vec3d e1, Vec3d e2, ColorRGBA color ) {
            this.e1 = e1;
            this.e2 = e2;
            this.color1 = color;
            this.color2 = color;
        }
         
        public LineMarker( Vec3d e1, Vec3d e2, ColorRGBA color1, ColorRGBA color2 ) {
            this.e1 = e1;
            this.e2 = e2;
            this.color1 = color1;
            this.color2 = color2;
        } 
    }
    
    private class Pin {
        String key;
        String id;        
        Vec3d pos;
        ColorRGBA color;
        Map<String, Object> properties = new HashMap<>();
        Spatial spatial;
        double height;
        double radius;
        Map<String, Consumer> onClick;
 
        public Pin( String key, String id, Vec3d pos, double height, double radius, ColorRGBA color ) {
            this.key = key;
            this.id = id;
            this.pos = pos;
            this.color = color;
            this.height = height;
            this.radius = radius;
            
            Cylinder mesh = new Cylinder(2, 4, 1, (float)radius, (float)height, true, false);            
            Geometry geom = new Geometry("pin:" + id, mesh);
            geom.rotate(FastMath.HALF_PI, 0, 0);
            geom.move(0, (float)(height * 0.5), 0);
            Material mat = new Material(getApplication().getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
            mat.setColor("Color", color);
            //mat.getAdditionalRenderState().setWireframe(true);
            geom.setMaterial(mat);
         
            Node node = new Node("pin:" + id);
            node.setUserData("key", key);
            node.attachChild(geom);
            
            CursorEventControl.addListenersToSpatial(node, pinListener); 
 
            spatial = node;
        }
 
        public void onClick( String clickId, Consumer onClick ) {
            if( this.onClick == null ) {
                this.onClick = new LinkedHashMap<>();
            }
            this.onClick.put(clickId, onClick);
        }
        
        public void fireClicked() {
            if( onClick == null ) {
                return;
            }
            for( Consumer listener : onClick.values() ) {
                listener.accept(this);
            }
        }
        
        public void setOrigin( Vec3d origin ) {
            spatial.setLocalTranslation(pos.subtract(origin).toVector3f());
        }        
 
        public Object put( String key, Object value ) {
            return properties.put(key, value);
        }
        
        public Object get( String key ) {
            return properties.get(key);
        }
        
        public Map<String, Object> getProperties() {
            return properties;
        }
        
        @Override
        public String toString() {
            return "Pin[id:" + id + ", properties:" + properties + "]";
        }
    }
    
    private class GridMarkers {
        private GridCell cell;
        private Node gridRoot;
        private Geometry lineGeom;
        private List<LineMarker> lines = new ArrayList<>();
        private Vec3d origin;
        private List<Pin> pins = new ArrayList<>();

        public GridMarkers( GridCell cell ) {
            this.cell = cell;
            this.gridRoot = new Node("cell:" + cell);
            this.origin = cell.getWorldOrigin().toVec3d();
            viewRoot.attachChild(gridRoot);            
        }
        
        public void add( LineMarker line ) {
            lines.add(line);
            pending.add(this);
        }

        public void add( Pin pin ) {
            pins.add(pin);
            pin.setOrigin(origin);
            gridRoot.attachChild(pin.spatial);
        }
        
        public void clear() {
            lines.clear();
            pending.add(this);
        }
        
        public void updatePosition( Vec3d pos ) {
            Vec3d offset = origin.subtract(pos);
            offset.y = 0;
            gridRoot.setLocalTranslation(offset.toVector3f());
        }
        
        public void rebuild() {
            Mesh mesh = new Mesh();
            mesh.setMode(Mesh.Mode.Lines);
 
            // not the most efficient way but it's easy
            int vertCount = lines.size() * 2;
            float[] verts = new float[vertCount * 3];
            float[] colors = new float[vertCount * 4];
            
            int vpos = 0;
            int cpos = 0;
            for( LineMarker marker : lines ) {
                float x1 = (float)(marker.e1.x - origin.x);
                float y1 = (float)(marker.e1.y - origin.y);
                float z1 = (float)(marker.e1.z - origin.z);
                float x2 = (float)(marker.e2.x - origin.x);
                float y2 = (float)(marker.e2.y - origin.y);
                float z2 = (float)(marker.e2.z - origin.z);
                verts[vpos++] = x1;
                verts[vpos++] = y1;
                verts[vpos++] = z1;
                verts[vpos++] = x2;
                verts[vpos++] = y2;
                verts[vpos++] = z2;
 
                colors[cpos++] = marker.color1.r;
                colors[cpos++] = marker.color1.g;
                colors[cpos++] = marker.color1.b;
                colors[cpos++] = marker.color1.a;
                colors[cpos++] = marker.color2.r;
                colors[cpos++] = marker.color2.g;
                colors[cpos++] = marker.color2.b;
                colors[cpos++] = marker.color2.a;
            }
            
            mesh.setBuffer(VertexBuffer.Type.Position, 3, verts);
            mesh.setBuffer(VertexBuffer.Type.Color, 4, colors);
            mesh.updateBound();
            mesh.setStatic();
            
            if( lineGeom == null ) {
                lineGeom = new Geometry("lines:" + cell, mesh);
                Material mat = new Material(getApplication().getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
                mat.setBoolean("VertexColor", true);
                mat.setColor("Color", ColorRGBA.White);
                lineGeom.setMaterial(mat);
                gridRoot.attachChild(lineGeom);
            } else {
                lineGeom.setMesh(mesh);
                lineGeom.updateModelBound();
            }
        }        
    }
}
