/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.function.BiConsumer;

import org.slf4j.*;

import com.google.common.cache.*;

import com.simsilica.fractal.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TileBuilder {
    static Logger log = LoggerFactory.getLogger(TileBuilder.class);

    private TileMesh tileMesh;
    private Sampler elevation;
    private Sampler coloring;
    private Sampler[] layers;
    private LoadingCache<TileKey, Tile> cache;
    
    private long totalTime;
    private long totalTiles;

    private BiConsumer<TileKey, Long> generated;

    public TileBuilder( Sampler elevation, Sampler coloring, Sampler[] layers, 
                        TileMesh tileMesh, BiConsumer<TileKey, Long> generated ) {
        this.elevation = elevation;        
        this.coloring = coloring;
        this.layers = layers;
        this.tileMesh = tileMesh; // unfortunate that this must be universal
        this.generated = generated;
        
        cache = CacheBuilder.newBuilder()
            .maximumSize(100)
            .build(new CacheLoader<TileKey, Tile>() {
                    @Override
                    public Tile load( TileKey key ) {
                        return createTile(key);
                    }
                });       
    }
    
    public void updateSamplers( Sampler elevation, Sampler coloring, Sampler[] layers ) {
        this.elevation = elevation;        
        this.coloring = coloring;
        this.layers = layers;
        cache.invalidateAll();
    } 
    
    public Tile getTile( TileKey key ) {
        return cache.getUnchecked(key);
    }
     
    protected Tile createTile( TileKey key ) {
        Tile result = new Tile(key, tileMesh);
        long start = System.nanoTime();
        result.update(elevation, coloring, layers);
        long end = System.nanoTime();
        long time = end - start;
        totalTime += time;
        totalTiles++;
        log.info("Tile built in:" + (time/1000000.0) + " ms, average:" + ((totalTime/1000000.0)/totalTiles) + " ms.");
        generated.accept(key, time);
        return result;                
    } 
}


