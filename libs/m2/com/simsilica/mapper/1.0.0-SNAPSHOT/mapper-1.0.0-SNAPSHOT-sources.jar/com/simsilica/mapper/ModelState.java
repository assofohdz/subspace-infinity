/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.util.*;

import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.state.CubeSceneState;

import com.simsilica.fractal.*;


/**
 *  Presents one of many properly scaled avatars on the ground to
 *  better determine scale on raw terrain.
 *
 *  @author    Paul Speed
 */
public class ModelState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ModelState.class);

    private VersionedReference<Vec3d> posRef;
    private VersionedReference<Double> viewOffsetRef;

    private VersionedReference<MapState> mapRef;

    private Node viewRoot;
    private float masterScale;

    private List<Spatial> templates = new ArrayList<>();
    private SafeArrayList<PlacedObject> models = new SafeArrayList<>(PlacedObject.class);

    public ModelState() {
        setEnabled(MapperConfig.getInstance().getStartupSetting("ModelState.enabled", true));        
    }
    
    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }
    
    @Override
    protected void initialize( Application app ) {
        //this.elevation = getState(MapState.class).getElevation();
        this.posRef = getState(CameraControlState.class).createPosRef();
        this.viewRoot = new Node("modelRoot");
        this.viewOffsetRef = getState(MapViewState.class).createViewOffsetRef();
 
        this.mapRef = getState(MapState.class).createReference();
 
        // Set the master scale
        masterScale = 1024f/32767;
        viewRoot.setLocalScale(masterScale);
        
        // Now for some sample templates
        String[] buildings = new String[] {
            //"Models/surprise-ship.j3o",
            "Models/simple1-a.j3o",
            "Models/simple1-b.j3o",
            "Models/Simple1.j3o",
            "Models/Simple1b.j3o",
            "Models/simple2-a.j3o",
            "Models/simple2-b.j3o",
            "Models/simple2-c.j3o",
            "Models/Simple2.j3o",
            "Models/Simple2b.j3o",
            "Models/simple2x2-0-a.j3o",
            "Models/simple2x2-0-b.j3o",
            "Models/simple2x2-1-a.j3o",
            "Models/simple2x2-1-b.j3o"
        };
        
        for( String s : buildings ) {
            Spatial model = app.getAssetManager().loadModel(s);
            model.setLocalScale(1);            
            model.center();
            model.move(0, -model.getLocalTranslation().y, 0);
            model.setShadowMode(ShadowMode.CastAndReceive);
            Node holder = new Node("holder:" + s);
            holder.attachChild(model);
            templates.add(holder);
        }
        
        //Spatial test = templates.get(1).clone();
        //test.setLocalTranslation(40, 400, 0);
        //viewRoot.attachChild(test);
        //
        //test = templates.get(5).clone();
        //test.setLocalTranslation(40, 400, 40);
        //viewRoot.attachChild(test);
        //
        //test = templates.get(10).clone();
        //test.setLocalTranslation(0, 400, 40);
        //viewRoot.attachChild(test);
        
        Random rand = new Random(0);
        // Add some random objects.
        // Just around the main avatar for now
        //int count = 10;
        for( int x = -100; x <= 100; x += 20 ) {
            for( int z = -100; z <= 100; z += 20 ) {
                if( Math.abs(x) < 30 && Math.abs(z) < 30 ) {
                    continue;
                }
                double chance = rand.nextDouble();
                if( chance < 0.4 ) {
                    continue;
                }
                int index = rand.nextInt(templates.size());
                PlacedObject model = new PlacedObject(templates.get(index).clone(), x, z);                 
                models.add(model);
                int rotate = rand.nextInt(4);
                for( int i = 0; i < rotate; i++ ) {
                    model.model.rotate(0, FastMath.HALF_PI, 0);
                } 
            }
        }
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
        updatePosition();
    }
    
    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }
    
    @Override
    public void update( float tpf ) {
        if( posRef.update() || viewOffsetRef.update() ) {
            updatePosition();
            updateElevations();
        }
        //if( mapRef.update() ) {
        //    updateElevations();
        //}
    }
    
    protected void updatePosition() {
        Vec3d pos = posRef.get();
log.info("updatePosition():" + pos);        
        //double h = elevation.getSample(pos.x, 0, pos.z);
        double h = viewOffsetRef.get();
        
        //viewRoot.setLocalTranslation(0, (float)(masterScale * h), 0);
        
        log.info("elevation:" + h);
    }
    
    protected void updateElevations() {
        Vec3d pos = posRef.get();
        
        for( PlacedObject obj : models.getArray() ) {
            obj.update(pos);
        }
    }
    
    private class PlacedObject {
        private Spatial model;
        Vec3d location;
        
        public PlacedObject( Spatial model, double x, double z ) {
            this.model = model;
            this.location = new Vec3d(x, 0, z);
            viewRoot.attachChild(model);
            model.setLocalTranslation(location.toVector3f());
        }
        
        public void update( Vec3d pos ) {
            double h = getState(MapState.class).getElevation().getSample(pos.x + location.x, 0, pos.z + location.z);
            location.y = h;
            model.setLocalTranslation(location.toVector3f());
        }
    }
}

