/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import com.jme3.scene.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MeshFactory {

    /**
     *  Generates a triangle strip mesh of quads count = width*height.
     */
    public static Mesh generateQuad( int width, int height, boolean includeNormals ) {
        return generateQuad(width, height, 1, 1, includeNormals);
    }
    
    public static Mesh generateQuad( int width, int height, float xStep, float zStep, boolean includeNormals ) {

        Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.TriangleStrip);

        int w = width;
        int h = height;

        float xTexMax = width * xStep;
        float zTexMax = height * zStep;
        
        float[] fv = new float[w * h * 3];
        float[] tv = new float[w * h * 2];
        float[] fn = null;
        if( includeNormals ) {
            fn = new float[w * h * 3];
        }
        int vIndex = 0;
        int tIndex = 0;
        int nIndex = 0;
        for( int y = 0; y < h; y++ ) {
            for( int x = 0; x < w; x++ ) {

                fv[vIndex++] = (float)(x * xStep);
                fv[vIndex++] = (float)0;
                fv[vIndex++] = (float)(y * zStep);

                tv[tIndex++] = (float)(x * xStep)/xTexMax; 
                tv[tIndex++] = (float)(y * zStep)/zTexMax;

                if( includeNormals ) {
                    fn[nIndex++] = (float)0;
                    fn[nIndex++] = (float)1;
                    fn[nIndex++] = (float)0;
                }
            }
        }

        // Build an index buffer for a triangle strip.  The first three
        // start a triangle and then the next joins the previous two, and so on.
        // So the pattern has to go something like:
        // 1-3-5-7
        // |\|\|\|
        // 0-2-4-6
        //
        // Of flip it for counter-clockwise initial winding:
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7
        //
        // To start the next row there has to be some degenerate triangles
        // enough so we can start over with a counter-clockwise winding on the
        // next row.  So I think if we do the last vertex again then that's
        // a counter-clockwise
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               cc
        //
        // Then a vertex at the 'home' of the second row
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               678:cc 789:c
        // 9
        // No, because we need one more degenerate triangle to get down
        // to the third row before we can start making triangles again.
        // We'd have to put 10 there also then drop down to the next row
        // for 11... which I guess is counter-clockwise so 10, 11, 12 would
        // be...  Wait:
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               678:cc 789:c
        // 9.A C                 89A:cc 9AB:c        4 degenerate
        // |  /                  ABC:cc... correct.
        // B - D
        // Yeah, so 10, 11, 12 is setup to be cc again.
        // Note: we waste fewer triangles per row if we alternate patterns, I think.
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7                   678=degen cc
        // E-C-A-8
        // |\|\|\|  cc\c cc\c cc\c
        // F-D-B-9
        //                  789=degen c  ...and so we're still off by one flip
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7                   678=degen cc
        // F-D-B-8.9                   789=degen c
        // |\|\|\|  cc\c cc\c cc\c     89A=dege cc  9AB = c  3 degenerate
        // G-E-C-A
        //
        // one fewer per row for more complexity... smaller degen triangles, though.
        //
        // So each row takes width * 2 indexes plus one extra.
        // ie: we end row one on 7 but add 9 also.  That gives us the 678 degenerate
        // triangle.
        // Row 2 adds 9 which gives us the second 789 degenerate triangle.
        // then it adds A which gives us the third 89A...then we are back on cycle.
        // But note that each 'row' in this cases is actually straddling two rows
        // of vertexes... so we need one less in the buffer in the end.
        int[] ib = new int[(w * 2 + 1) * (h-1)];
        int index = 0;

        for( int row = 0; row < h-1; row++ ) {
            if( (row % 2) == 0 ) {
                // Even rows
                // Top version is for x-right, z-up style winding. ie: if we let
                // x go 0 to 1024 and z go 0 to 1024 then it will face down and not up.
                //for( int col = w-1; col >= 0; col-- ) {
                for( int col = 0; col < w; col++ ) {
                    ib[index++] = col + row * w;
                    ib[index++] = col + (row + 1) * w;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            } else {
                // Odd rows
                for( int col = w-1; col >= 0; col-- ) {
                //for( int col = 0; col < w; col++ ) {
                    ib[index++] = col + row * w;
                    ib[index++] = col + (row + 1) * w;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            }
        }

        mesh.setBuffer(VertexBuffer.Type.Position, 3, fv);
        mesh.setBuffer(VertexBuffer.Type.TexCoord, 2, tv);
        if( includeNormals ) {
            mesh.setBuffer(VertexBuffer.Type.Normal, 3, fn);
        }
        mesh.setBuffer(VertexBuffer.Type.Index, 1, ib);
        mesh.updateBound();
        mesh.setStatic();

        return mesh;
    }

}
