/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.fractal.*;
import org.progeeks.map.*;

/**
 *  Temporary as we test transitions.
 *
 *  @author    Paul Speed
 */
public class TempFractalTest extends AbstractSampler {

    static Logger log = LoggerFactory.getLogger(TempFractalTest.class);

    private long baseSeed;
    
    private ElevationSource elevationSource;
    public ElevationSource terrain;
    public ElevationSource transformedTerrain;
    public ElevationSource desert;

    private AbstractNoiseElevationGenerator foliageNoise1;
    private AbstractNoiseElevationGenerator foliageNoise2;
    
    public TempFractalTest( long baseSeed ) {
        super(SamplerRange.INFINITY); // don't actually know
        this.baseSeed = baseSeed;

        //seed="0" frequency="256" additive="false" affected="true" elevationOffset="-1500" elevationScale="15000"
        //frequencyIterations="7" startingFrequency="1.0" />
        FractalSumElevations fse = new FractalSumElevations();
        fse.setSeed(baseSeed);
        fse.setFrequency(256);
        fse.setAdditive(false);
        fse.setAffected(true);
        fse.setElevationOffset(-1500);
        fse.setElevationScale(15000);
        fse.setFrequencyIterations(7);
        fse.setStartingFrequency(1.0);

        // seed="0" frequency="256" additive="true" affected="true" elevationOffset="-1000" elevationScale="3000"
        // fractalIncrement="0.5" gain="2.0" lacunarity="3.02" octaves="8" offset="0.86" threshold="1.57" />
        RidgeFractalElevations rfe = new RidgeFractalElevations();
        rfe.setSeed(baseSeed);
        rfe.setFrequency(256);
        rfe.setAdditive(true);
        rfe.setAffected(true);
        rfe.setElevationOffset(-1000);
        rfe.setElevationScale(3000);
        rfe.setFractalIncrement(0.5);
        rfe.setGain(2.0);
        rfe.setLacunarity(3.02);
        rfe.setOctaves(8);
        rfe.setOffset(0.86);
        rfe.setThreshold(1.57);

        // seed="0" frequency="128" additive="true" affected="true" elevationOffset="-2000" elevationScale="2000"
        // fractalIncrement="0.75" lacunarity="3.09" octaves="7" offset="0.54" />
        HeterogenousFractalElevations hfe = new HeterogenousFractalElevations();
        hfe.setSeed(baseSeed);
        hfe.setFrequency(128);
        hfe.setAdditive(true);
        hfe.setAffected(true);
        hfe.setElevationOffset(-2000);
        hfe.setElevationScale(2000);
        hfe.setFractalIncrement(0.75);
        hfe.setLacunarity(3.09);
        hfe.setOctaves(7);
        hfe.setOffset(0.54);

        // Trying to raise up parts of the world a bit to prevent
        // 'mostly water' planets
        // <org.progeeks.map.PerlinElevations enabled="true" seed="2" frequency="2048" ZOffset="0.0" additive="true"
        // affected="true" elevationOffset="0" elevationScale="1000" />
        //     <org.progeeks.map.PerlinElevations enabled="true" seed="2" frequency="2048" ZOffset="0.0" additive="true"
        //    affected="false" elevationOffset="5000" elevationScale="15000" />
        PerlinElevations pe = new PerlinElevations();
        pe.setSeed(baseSeed + 2);
        pe.setFrequency(2048);
        pe.setZOffset(0);
        pe.setAdditive(true);
        pe.setAffected(false);
        pe.setElevationOffset(5000);
        pe.setElevationScale(15000);

        // It works.  Maybe too well.  Anyway, we can fool with it more later.
        // Not entirely happy with how 'additive' works in this case since it's super
        // hard to predict.
    
        // Trying some desert terrain
        RidgeFractalElevations dunes = new RidgeFractalElevations();
        dunes.setSeed(baseSeed);
        dunes.setFrequency(128);
        dunes.setElevationOffset(0);
        dunes.setElevationScale(1500);
        dunes.setFractalIncrement(0.5);
        dunes.setGain(2);
        dunes.setLacunarity(3.02);
        dunes.setOctaves(4);
        dunes.setOffset(1);
        dunes.setThreshold(1.5);  // controls 'regularity'.  Higher numbers get rid of large flat zones.
        

        this.terrain = new FractalElevationSource(fse, rfe, hfe, pe);
        //((FractalElevationSource)terrain).setFlatten(true); // for now
        //terrain = ElevationSources.maxThreshold(terrain, 300, 0);
        //terrain = ElevationSources.offset(terrain, -150); 
        this.desert = new FractalElevationSource(dunes); 

        //String transformScript =  "t = y/maxElevation;\n"
        //                        + "t = t * t * t * t * t * t;\n"
        //                        + "return t * maxElevation * 0.75;";
        //ElevationSource transformed = new ScriptElevationSource(terrain, transformScript);
        ElevationSource transformed = new AbstractTransformSource(terrain) {
                protected double transform( double elevation, double x, double y ) {
                    double t = elevation / maxElevation;
                    t = t * t * t * t; // * t * t;
                    if( t > 0.75 ) {
                        t = 0.75 + ((t - 0.75) * 0.4);
                    }
                    //return t * maxElevation; // * 0.75;
                    return t * maxElevation * 0.85;
                }
            };
        this.transformedTerrain = transformed;

        //this.elevationSource = new FractalElevationSource(fse, rfe, hfe, pe);
        //((FractalElevationSource)elevationSource).setFlatten(true);
        //this.elevationSource = new FractalElevationSource(dunes);

        //this.elevationSource = ElevationSources.maxThreshold(elevationSource, 300, 0);
        
        //this.elevationSource = ElevationSources.max(terrain, desert);
        //this.elevationSource = terrain;
        this.elevationSource = ElevationSources.max(transformed, desert);

        // For tree noise
        pe = new PerlinElevations();
        pe.setSeed(baseSeed);
        pe.setFrequency(16); //64);//128);
        pe.setZOffset(0);
        pe.setAdditive(false);
        pe.setAffected(false);
        pe.setElevationOffset(5000);
        pe.setElevationScale(15000);
        foliageNoise1 = pe;

        pe = new PerlinElevations();
        pe.setSeed(baseSeed);
        pe.setFrequency(128);
        pe.setZOffset(0);
        pe.setAdditive(false);
        pe.setAffected(false);
        pe.setElevationOffset(5000);
        pe.setElevationScale(15000);
        foliageNoise2 = pe;
    } 

    public double getSample( double x, double y, double z ) {
        return getElevation(x, z);
    }

    public double getElevation( double x, double y ) {
        return elevationSource.getElevation(x, y);
    }

    public double getFoliageLevel( double x, double y ) {
        // For now, we'll suppress desert foliage since we don't have proper
        // climate and moisture models.
        if( false ) {
            double result = foliageNoise1.getLayeredElevation(x, y, 0);
            result += foliageNoise2.getLayeredElevation(x, y, 0);
            return result;
        }
        return 0;
    }    

    private double[] getLayers( double x, double z, double[] layers ) {
        // Ask the fractals
        double terrainElev;// = transformedTerrain.getElevation(x, z);
        double desertElev;// = desert.getElevation(x, z);
        double water = 64;

        if( z > 2048 ) {
            // Just use the regular terrain fractal
            double real = terrain.getElevation(x, z);
            terrainElev = real;
            if( terrainElev <= water ) {
                desertElev = terrainElev + 1;
            } else {
                desertElev = 0;
            }
        } else {            
            desertElev = desert.getElevation(x, z);
            terrainElev = transformedTerrain.getElevation(x, z);

            if( z > 1024 ) {
                double real = terrain.getElevation(x, z);
                double sand = 0; //real;
                //if( real <= water ) {
                //    sand = real+1;
                //}
                
                // We'll interpolate
                double part = (z - 1024)/1024.0;
                real = real * part + terrainElev * (1.0 - part);
                terrainElev = real;
                
                desertElev = sand * part + desertElev * (1.0 - part);
 
                /*if( terrainElev <= water ) {
                    desertElev = terrainElev + 1;
                } else if( terrainElev < desertElev ) {
                    // Need to interpolate the sand, too
                    desertElev = (real - 1) * part + desertElev * (1.0 - part);
                } else {
                    desertElev = 0;
                }*/
                
                if( terrainElev > desertElev && terrainElev <= water ) {
                    desertElev = terrainElev;
                    terrainElev = desertElev - 1; 
                } 
            }
        }
        layers[0] = desertElev;
        layers[1] = terrainElev;
        return layers;
    }

    /**
     *  Samples the fractal in 3D at the x,z location and fills target
     *  with the block types.  Returns the count of elements from bedrock
     *  that were actually filled in (ie: natural terrain elevation)
     */     
    public int getBlockTypes( double x, double z, int[] target ) {
 
        double[] layers = getLayers(x, z, new double[2]);
        int desertElev = (int)layers[0];
        int terrainElev = (int)layers[1];
        int water = 64;
 
        /*int desertElev;
        int terrainElev;
        int water = 64;

        if( z > 2048 ) {
            // Just use the regular terrain fractal
            double real = terrain.getElevation(x, z);
            terrainElev = (int)real;
            if( terrainElev <= water ) {
                desertElev = terrainElev + 1;
            } else {
                desertElev = 0;
            }
        } else {            
            desertElev = (int)desert.getElevation(x, z);
            terrainElev = (int)transformedTerrain.getElevation(x, z);

            if( z > 1024 ) {
                double real = terrain.getElevation(x, z);
                
                // We'll interpolate
                double part = (z - 1024.0)/1024.0;
                real = real * part + terrainElev * (1.0 - part);
                terrainElev = (int)real;
 
                if( terrainElev <= water ) {
                    desertElev = terrainElev + 1;
                } else if( terrainElev < desertElev ) {
                    // Need to interpolate the sand, too
                    desertElev = (int)((real - 1) * part + desertElev * (1.0 - part));
                } else {
                    desertElev = 0;
                } 
            }
        }*/
 
        // At some point we need to resolve what 'elevation' means relative
        // to blocks.  Does elevation 0 mean we set block 0 or does it mean there
        // is a hole in the bottom of the world?
 
        int max = 0;
        for( int y = 0; y < target.length; y++ ) {
            if( y < terrainElev ) {
                // Rock
                target[y] = 39;
            } else if( y < desertElev ) {
                // sand
                target[y] = 3;
            } else if( y < water ) {
                target[y] = 80;
            } else {
                // We don't support voids... so we're done
                //max = y + 1;
                //break;
                target[y] = 0;
            }
        }
        
        max = Math.max(water, Math.max(desertElev, terrainElev));
        return max;
    }
    
//    public TerrainInfo getTerrainInfo( double x, double z, TerrainInfo target ) {
//
//        double[] layers = getLayers(x, z, new double[2]);
//        double desertElev = (int)layers[0];
//        double terrainElev = (int)layers[1];
//        double water = 64;
//        
//        // Ask the fractals
//        /*double terrainElev;// = transformedTerrain.getElevation(x, z);
//        double desertElev;// = desert.getElevation(x, z);
//        double water = 64;
//
//        if( z > 2048 ) {
//            // Just use the regular terrain fractal
//            double real = terrain.getElevation(x, z);
//            terrainElev = (int)real;
//            if( terrainElev <= water ) {
//                desertElev = terrainElev + 1;
//            } else {
//                desertElev = 0;
//            }
//        } else {            
//            desertElev = desert.getElevation(x, z);
//            terrainElev = transformedTerrain.getElevation(x, z);
//
//            if( z > 1024 ) {
//                double real = terrain.getElevation(x, z);
//                
//                // We'll interpolate
//                double part = (z - 1024)/1024.0;
//                real = real * part + terrainElev * (1.0 - part);
//                terrainElev = (int)real;
// 
//                if( terrainElev <= water ) {
//                    desertElev = terrainElev + 1;
//                } else if( terrainElev < desertElev ) {
//                    // Need to interpolate the sand, too
//                    desertElev = (real - 1) * part + desertElev * (1.0 - part);
//                } else {
//                    desertElev = 0;
//                } 
//            }
//        }*/
//
//        double elevation = Math.max(terrainElev, desertElev);
//        target.elevation = elevation; 
//        if( target.elevation < water ) {
//            target.water = water;
//            target.waterType = (byte)0x1;
//        } else {
//            target.water = -1;
//            target.waterType = (byte)0x0;
//        } 
// 
//        if( desertElev < terrainElev ) {
//            // Rocks win
//            target.type = TerrainLayer.TYPE_ROCK; 
//        } else {
//            // Default is sand
//            target.type = TerrainLayer.TYPE_SAND;  
//            double tree = getFoliageLevel(x, z);
//            double treeThreshold = 0.1;
//            if( elevation < 65 ) {
//                treeThreshold = 0.35;
//            } else if( elevation < 70 ) {
//                treeThreshold = 0.01;
//            }
//            if( tree >= treeThreshold ) {
//                ////type = 0x8;
//                //if( size != 1024 ) {
//                    // For reduced scale stuff we can at least guess
//                target.type = 0x8;
//                //}
//            } 
//        }
//
//        return target;        
//    }
//
//    public TerrainLayer createLayer( TileId id, Resolution res ) {
//        TerrainLayer layer = new TerrainLayer(id, new LayerVersion(0, -1, -1), res);
//        
//        Vec3i world = id.getWorld(null);
//        double xCorner = world.x;
//        double zCorner = world.z;
//        
//        int scale = layer.getScale();
//        short[] elevations = layer.getElevations();
//
//        int size = res.getSamples();
//        int pos = 0;
//        /*for( int z = 0; z < size; z++ ) {
//            for( int x = 0; x < size; x++ ) {
//                double xp = xCorner + x * scale;
//                double zp = zCorner + z * scale;
//                short e = (short)elevationSource.getElevation(xp, zp);
//                elevations[pos] = e;
//                pos++;
//            }
//        }*/
//
//        // Second pass for types
//        byte[] types = layer.getTypes();
//        pos = 0;
//        TerrainInfo info = new TerrainInfo();
//long start = System.nanoTime();        
//        for( int z = 0; z < size; z++ ) {
//            for( int x = 0; x < size; x++ ) {
//                double xp = xCorner + x * scale;
//                double zp = zCorner + z * scale;
//                
//                // Ask the fractals
//                getTerrainInfo(xp, zp, info);
//                elevations[pos] = (short)info.elevation;
//                types[pos] = info.type;
//                /*double terrainElev = transformedTerrain.getElevation(xp, zp);
//                //double terrainElev = terrain.getElevation(xp, zp);
//                double desertElev = desert.getElevation(xp, zp);
//                elevations[pos] = (short)Math.max(terrainElev, desertElev);
//                int type = 0;
//                if( desertElev < terrainElev ) {
//                    // Rocks win
//                    type = 0x2;
//                } else {
//                    double tree = getFoliageLevel(xp, zp);
//                    double treeThreshold = 0.1;
//                    short e = elevations[pos];
//                    if( e < 65 ) {
//                        treeThreshold = 0.35;
//                    } else if( e < 70 ) {
//                        treeThreshold = 0;
//                    }
//                    if( tree >= treeThreshold ) {
//                        ////type = 0x8;
//                        //if( size != 1024 ) {
//                            // For reduced scale stuff we can at least guess
//                            type = 0x8;
//                        //}
//                    }
//                }
//                
//                types[pos] = (byte)type;*/                
//                pos++;
//            }
//        }
//long end = System.nanoTime();
//log.info("timecheck tile[" + id + ", " + res + "] " + ((end-start)/1000000.0) + " ms");
// 
//        return layer;       
//    } 
//
//    @Override
//    public void generate( Tile tile, Resolution res ) {
//        tile.addLayer(createLayer(tile.getId(), res));
//    }    
//
///*
//    public Tile generateTile( long id, int xCorner, int yCorner, int size ) {
//
//        Tile tile = new Tile(id, xCorner, yCorner, size);
//        int scale = tile.getScale();
//        short[] elevations = tile.getElevations();
//
//        int pos = 0;
//        for( int y = 0; y < size; y++ ) {
//            for( int x = 0; x < size; x++ ) {
//                double xp = xCorner + x * scale;
//                double yp = yCorner + y * scale;
//
//                short e = (short)elevationSource.getElevation(xp, yp);
//
////if( e < -64 ) e = -64;
////if( e > 512 ) e = 512;
//
//                elevations[pos] = e;
//                pos++;
//            }
//        }
//
//        // Second pass for types
//        byte[] types = tile.getTypes();
//        pos = 0;
//        for( int y = 0; y < size; y++ ) {
//            for( int x = 0; x < size; x++ ) {
//                double xp = xCorner + x * scale;
//                double yp = yCorner + y * scale;
//
//                
//                // Ask the fractals
//                double terrainElev = transformedTerrain.getElevation(xp, yp);
//                double desertElev = desert.getElevation(xp, yp);
//                int type = 0;
//                if( desertElev < terrainElev ) {
//                    // Rocks win
//                    type = 0x2;
//                }
//                
//                types[pos] = (byte)type;
//                pos++;
//            }
//        }
//
//
//        return tile;
//    }
// */
}


