/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import org.slf4j.*;

import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;
import com.jme3.scene.Spatial.CullHint;
import com.jme3.texture.*;

import com.simsilica.mathd.*;
import com.simsilica.thread.Job;

/**
 *  A layer in the tile pyramid representing a single grid
 *  resolution.
 *
 *  @author    Paul Speed
 */
public class TileGrid {
    static Logger log = LoggerFactory.getLogger(TileGrid.class);

    private MapViewState parent;
    private Node root;
 
    private MapSettings settings;
    
    private int priority;
    private int tileSize;
    private Vec3i hexSize;
    private Grid grid;
    private TileMesh tileMesh;
    private Material tileMaterial;
 
    private GridCell center;
    private Slot[] slots;
    
    private Map<Vec3i, TileView> views = new HashMap<>();
    
    private Vec3d offset;
    private double scale;
    
    private TileGrid parentGrid;
    private boolean gridVisible;
    
    public TileGrid( MapViewState parent, int priority, int tileSize, 
                     MapSettings settings, TileMesh tileMesh, Material tileMaterial, Vec3i hexSize ) {
        this.parent = parent;
        this.priority = priority;
        this.tileSize = tileSize;
        this.settings = settings;        
        this.grid = new Grid(tileSize, 0, tileSize);
        this.tileMesh = tileMesh;
        this.tileMaterial = tileMaterial;
        this.hexSize = hexSize;        
 
        this.root = new Node("grid:" + tileSize);
    
        int radius = 1;
        int size = radius * 2 + 1;
        slots = new Slot[size * size];
        int index = 0;        
        for( int i = -radius; i <= radius; i++ ) {
            for( int j = -radius; j <= radius; j++ ) {
                slots[index++] = new Slot(i, j);
            }
        }
        
        this.scale = (double)tileSize / tileMesh.getMeshSpacing();
       
        root.setLocalScale((float)scale);
    }
 
    public void setParentGrid( TileGrid parentGrid ) {
        this.parentGrid = parentGrid;
    }
 
    public void setOccludeChild( TileKey key, boolean occlude ) {
        GridCell child = key.getCell();
        GridCell local = grid.getContainingCell(child.getWorldOrigin());
        
        for( Slot slot : slots ) {            
            Vec3i v = center.getCell().add(slot.offset);
            if( local.getCell().equals(v) ) {
                int i = child.getCell().x % 2;
                if( i < 0 ) {
                    i += 2;
                }
                int j = child.getCell().z % 2;
                if( j < 0 ) {
                    j += 2;
                }
                // Really every slot should have a tile except during the
                // earliest parts of initialization
                if( slot.tile != null ) {
                    slot.tile.occlusion[i][j] = occlude;
                    slot.tile.updateOcclusion();
                }
                return;  // we're done
            }
        }
    }
    
    public void setVisible( boolean gridVisible ) {
        if( this.gridVisible == gridVisible ) {
            return;
        }
        this.gridVisible = gridVisible;
        if( gridVisible ) {
            root.setCullHint(CullHint.Inherit);
            updateTileVisibility();         
        } else {
            root.setCullHint(CullHint.Always);
            updateTileVisibility();         
        }
    }    
    
    public Grid getGrid() {
        return grid;
    }
    
    public int getTileSize() {
        return tileSize;
    }
    
    public Node getRoot() {
        return root;
    }
    
    public void invalidate() {
        for( Slot slot : slots ) {
            if( slot.tile != null ) {
                // Kill any old rebuild 
                if( parent.getJobState().cancel(slot.tile) ) {
                }            
                // Kick it off to build
                parent.getJobState().execute(slot.tile, (int)(priority * 100 + slot.offset.length()));
            } 
        }
    }
    
    public void updatePosition( Vec3d pos ) {
        GridCell cell = grid.getContainingCell(pos);
        offset = pos.subtract(cell.getWorldOrigin().toVec3d());

        root.setLocalTranslation((float)(-offset.x), 0, (float)(-offset.z));
        
        if( cell.equals(center) ) {
            return;
        }
        
        center = cell;
        Set<Vec3i> toRemove = new HashSet<>(views.keySet());
        
        for( Slot slot : slots ) {
            Vec3i v = center.getCell().add(slot.offset);
            TileView view = views.get(v);
            if( view == null ) {
                log.info("Create tile for:" + v);
                TileKey key = new TileKey(new GridCell(grid, v), tileSize);
                view = new TileView(key);
                views.put(v, view);

                // Kick it off to build
                parent.getJobState().execute(view, (int)(priority * 100 + slot.offset.length()));
                root.attachChild(view.node);                
            } else {
                // See if it needs rebuilding
            }
            
            // Make sure the occlusion data is up to date 
            slot.tile = view;
            view.updateOcclusion();
            
            // Position it in the grid
            view.node.setLocalTranslation(slot.offset.x * tileMesh.getMeshSpacing(),  
                                          0, 
                                          slot.offset.z * tileMesh.getMeshSpacing());
 
            toRemove.remove(v);
            
            if( parentGrid != null ) {
                parentGrid.setOccludeChild(view.key, view.isVisible());
            }
        }
        
        log.info("toRemove:" + toRemove);
        for( Vec3i v : toRemove ) {
            TileView view = views.remove(v);
            if( parent.getJobState().cancel(view) ) {
                // Could potentially do some other cleanup if we needed to
            }
            if( view != null ) {
                root.detachChild(view.node);
            }
            if( parentGrid != null ) {
                parentGrid.setOccludeChild(view.key, false);
            }
        }
        
        log.info("view count:" + views.size()); // should always be the same
    }

    public Geometry createCube( float xExtent, float yExtent, float zExtent, ColorRGBA color ) {
        Box b = new Box(xExtent, yExtent, zExtent);
        Geometry geom = new Geometry("Box", b);
        Material mat = new Material(parent.getApplication().getAssetManager(), "Common/MatDefs/Light/Lighting.j3md");
        mat.setColor("Diffuse", color);
        mat.setColor("Ambient", color);
        mat.setBoolean("UseMaterialColors", true);
        geom.setMaterial(mat);
        return geom;
    }

    protected void updateTileVisibility() {
        if( parentGrid == null ) {
            return;
        }
        for( Slot slot : slots ) {
            if( slot.tile != null ) {
                parentGrid.setOccludeChild(slot.tile.key, gridVisible && slot.tile.isVisible());
            }
        }        
    }
    
    private class Slot {
        Vec3i offset;
        TileView tile;
        
        public Slot( int xOffset, int zOffset ) {
            this.offset = new Vec3i(xOffset, 0, zOffset);
        }   
    }
    
    private class TileView implements Job {
        TileKey key;
        Tile tile;
        Node node;
        Material mat;
        boolean[][] occlusion = new boolean[2][2];
        Vector4f childOcclusion = new Vector4f(0, 0, 0, 0);
        volatile boolean tileVisible;     
        
        public TileView( TileKey key ) {
            this.key = key;
            this.node = new Node("tile:" + key);
        }
 
        public void updateOcclusion() {
            childOcclusion.set(
                    occlusion[0][0] ? 1 : 0,
                    occlusion[1][0] ? 1 : 0,
                    occlusion[0][1] ? 1 : 0,
                    occlusion[1][1] ? 1 : 0
                    );
        }
        
        public boolean isVisible() {
            return tileVisible;
        }
        
        public void runOnWorker() {
            tile = parent.getTileBuilder().getTile(key);
        }               
        
        public double runOnUpdate() {
            mat = tileMaterial.clone();
            mat.setVector4("Occlusion", childOcclusion);
 
            // Overlay scale is on top of whatever tile scale is
            // already happening.  Tricky business.
            // Using an example of 3072 meter hexagons (a days travel)
            //           
            //  3072 m |  1024 map im |  1 map texel  | 
            //-----------------------------------------  3072 m = 0.5 map texel 
            //         |  6144 m      |  1024 map img |               
            //
            //  592       0.5
            // ------  = ------   592x = 512  x = 512/592 = 1.15625
            //  1024       x
            //
            // What if we use y as our hexscale.  So aspect is 592/1024
            //  592        y
            // -----  =  -----   1024x = 592 * 0.5   x = (592 * 0.5) / 1024 = .2890625
            //  1024      0.5
            //
            // xScale should be 1.15625 and yScale should be 2.0.
            //
            // If we calculate the hex stuff in relation to 'y' it's easy because
            // that's a hex height.  1.0 hex texel.
            //
            // Calculate with respect to y since 1 unit = 1 hex which is easier
            float aspect = (float)hexSize.y/hexSize.x;
 
            // We want two layers... one smaller one that's roughly
            // a kilometer (we could make it an actual kilometer but it's
            // more fun if it lines up) and a larger one that is "a day's travel"
            // or 3072... which is about 12.8 game-hours of travel at 4 m/sec.       
            float hexSize1 = (float)settings.getMinorHexSpacing(); //1024;
            float hexSize2 = (float)settings.getMajorHexSpacing(); //3072;
            float hexScale1 = tileSize / hexSize1;
            float hexScale2 = tileSize / hexSize2;

            mat.setVector2("OverlayScale", new Vector2f(hexScale1 * aspect, hexScale1));
            mat.setVector2("OverlayScale2", new Vector2f(hexScale2 * aspect, hexScale2));
            
            // The overlay offset is in 'tile space' and so should be
            // relatively easy to calculate.
            double hexHeight = hexSize1;
            double hexWidth = hexSize1 / aspect;
            Vec3i world = key.getCell().getWorldOrigin();
            double hexCellOrigin = Math.floor(world.x / hexWidth) * hexWidth;
            
            // We adjust the hexagon slightly in the x direction so that they
            // center over 0,0.
            double xOffset = -(hexWidth / 3) + world.x - hexCellOrigin; 
            double yOffset = world.z - (Math.floor(world.z / hexHeight) * hexHeight);
            mat.setVector2("OverlayOffset", new Vector2f((float)(xOffset/tileSize), (float)(yOffset/tileSize)));
             
            hexHeight = hexSize2;
            hexWidth = hexSize2 / aspect;
            hexCellOrigin = Math.floor(world.x / hexWidth) * hexWidth;
            xOffset = -(hexWidth / 3) + world.x - hexCellOrigin; 
            yOffset = world.z - (Math.floor(world.z / hexHeight) * hexHeight);
            mat.setVector2("OverlayOffset2", new Vector2f((float)(xOffset/tileSize), (float)(yOffset/tileSize))); 
            
            mat.setTexture("DiffuseMap", new Texture2D(tile.getImage()));
            mat.setTexture("LayerMap", new Texture2D(tile.getLayerImage()));
            
            Geometry geom = new Geometry("tile:" + key, tileMesh.getMesh());
            geom.setShadowMode(ShadowMode.CastAndReceive);
            geom.setMaterial(mat);

            // Need to unscale the elevations to make the tileMeshSize.
            // The parent will scale us up again as appropriate.
            geom.setLocalScale(1, (float)tileMesh.getMeshSpacing()/tile.getTileSize(), 1);
            
            node.detachAllChildren();
            node.attachChild(geom);

            tileVisible = true;
            if( parentGrid != null ) {
                parentGrid.setOccludeChild(key, gridVisible);
            }
            
            return 1; // we did something
        }
    }
}

