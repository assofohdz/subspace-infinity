/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;
import com.google.gson.*;


/**
 *  Config settings for the Mapper tool.
 *
 *  @author    Paul Speed
 */
public class MapperConfig {

    public static final String CONFIG_FILE = "mapper.config";
    public static final String DEFAULT_PROJECT_DIR = ".";
    public static final String DEFAULT_SCRIPT_DIR = "scripts";

    static Logger log = LoggerFactory.getLogger(MapperConfig.class);

    private String projectDir;
    private List<String> startupScripts;
    private String scriptDir;
    private Map<String, Object> startupSettings;

    private static MapperConfig instance;
 
    public MapperConfig() {
    }
    
    protected void initializeDefaults() {
        this.projectDir = DEFAULT_PROJECT_DIR;
        this.scriptDir = DEFAULT_SCRIPT_DIR;
        this.startupSettings = new HashMap<>();
    }
    
    protected boolean upgrade() {
        boolean changed = false;
        if( startupSettings == null ) {
            this.startupSettings = new HashMap<>();
            changed = true;
        }
        return changed;
    }
 
    public File getProjectDir() {
        return new File(projectDir);
    }
 
    public File getScriptsDir() {
        return new File(projectDir, scriptDir);
    }
 
    @SuppressWarnings("unchecked")   
    public <T> T getStartupSetting( String key, T defaultValue ) {
        if( startupSettings.containsKey(key) ) {
            return (T)startupSettings.get(key);
        }
        return defaultValue;
    }

    public int getStartupSettingInt( String key, int defaultValue ) {
        if( !startupSettings.containsKey(key) ) {
            return defaultValue;
        }
        Number result = getStartupSetting(key, null);
        if( result == null ) {
            return defaultValue;
        }
        return result.intValue();
    }

    public long getStartupSettingLong( String key, long defaultValue ) {
        if( !startupSettings.containsKey(key) ) {
            return defaultValue;
        }
        Number result = getStartupSetting(key, null);
        if( result == null ) {
            return defaultValue;
        }
        return result.longValue();
    }

    public Map<String, Object> getStartupSettings() {
        return startupSettings;
    }
 
    public static MapperConfig getInstance() {
        if( instance == null ) {
            try {
                File f = new File(CONFIG_FILE);
                if( f.exists() ) {
                    instance = load(f);
                    if( instance.upgrade() ) {
                        store(instance, f);
                    }
                }
            } catch( Exception e ) {
                log.error("Error loading config file.  Initializing defaults", e);
            }
        }
        if( instance == null ) {
            instance = new MapperConfig();
            instance.initializeDefaults();
            File f = new File(CONFIG_FILE);
            if( !f.exists() ) {
                store(instance, new File(CONFIG_FILE));
            }
        }
        return instance;
    }
 
    public static MapperConfig load( File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return gson.fromJson(json, MapperConfig.class);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }
 
    public static void store( MapperConfig config, File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + f);
            String json = gson.toJson(config);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }        
    }
}

