/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.GuiGlobals;

/**
 *
 *
 *  @author    Paul Speed
 */
public class HorizonState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(HorizonState.class);

    private Spatial horizon;

    public HorizonState() {        
    }

    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }
    
    @Override
    protected void initialize( Application app ) {
        float masterScale = 1024f/32767;

        Cylinder cyl = new Cylinder(3, 12, 8000 * masterScale, 1000 * masterScale, false, true);
        Geometry geom = new Geometry("horizon", cyl);
        geom.rotate(FastMath.HALF_PI, 0, 0);
        Material mat = GuiGlobals.getInstance().createMaterial(ColorRGBA.Cyan, false).getMaterial();
        geom.setMaterial(mat);
        horizon = geom;

        // Note: BaseAppState will run the disable right away if we are disabling ourselves
        // from being enabled.  So we do this at the end so we are at least fully initialized.
        setEnabled(MapperConfig.getInstance().getStartupSetting("HorizonState.enabled", true));
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(horizon);
    }
    
    @Override
    protected void onDisable() {
        horizon.removeFromParent();
    }
    
}


