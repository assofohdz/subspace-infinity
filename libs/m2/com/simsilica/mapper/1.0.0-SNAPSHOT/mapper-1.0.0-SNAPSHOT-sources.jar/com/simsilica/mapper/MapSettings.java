/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import org.slf4j.*;

/**
 *  Settings for the map view.
 *
 *  @author    Paul Speed
 */
public class MapSettings {
    static Logger log = LoggerFactory.getLogger(MapSettings.class);
    
    private double majorHexSpacing = 3072;
    private double minorHexSpacing = 1024;

    private double maxElevation;
    private double minDepth;
 
    // The physical vert-position size of the tile mesh.   
    private int tileMeshSize = 1024;
    // The number of elevation samples in the tile mesh, ie: how dense
    // the mesh is.  1 pixel in the image = 1 vertex in the mesh.
    private int tileImageSize = 512;
    private boolean wireframe = false;
 
    private String baseHighGradient = "Textures/climates.png";
    private String baseLowGradient = "Textures/climates2.png";
    private List<MapLayer> mapLayers = new ArrayList<>();
    
    public MapSettings() {
    }
 
    public void setBaseHighGradient( String baseHighGradient ) {
        this.baseHighGradient = baseHighGradient;
    }
    
    public String getBaseHighGradient() {
        return baseHighGradient;
    }

    public void setBaseLowGradient( String baseLowGradient ) {
        this.baseLowGradient = baseLowGradient;
    }
    
    public String getBaseLowGradient() {
        return baseLowGradient;
    }
 
    public void setMapLayers( MapLayer... mapLayers ) {
        setMapLayers(Arrays.asList(mapLayers));
    }
    
    public void setMapLayers( Collection<MapLayer> mapLayers ) {
        if( this.mapLayers == mapLayers ) { 
            return;
        }
        this.mapLayers.clear();
        this.mapLayers.addAll(mapLayers);
    }
    
    public void setMajorHexSpacing( double majorHexSpacing ) {
        this.majorHexSpacing = majorHexSpacing;
    }
    
    public double getMajorHexSpacing() {
        return majorHexSpacing;
    }
    
    public void setMinorHexSpacing( double minorHexSpacing ) {
        this.minorHexSpacing = minorHexSpacing;
    }
    
    public double getMinorHexSpacing() {
        return minorHexSpacing;
    }
    
    public void setMaxElevation( double maxElevation ) {
        this.maxElevation = maxElevation;
    }
    
    public double getMaxElevation() {
        return maxElevation;
    }
    
    public void setMinDepth( double minDepth ) {
        this.minDepth = minDepth;
    }
    
    public double getMinDepth() {
        return minDepth;
    }    
    
    public void setTileNeshSize( int tileMeshSize ) {
        this.tileMeshSize = tileMeshSize;
    }
    
    public int getTileMeshSize() {  
        return tileMeshSize;
    }
    
    public void setTileImageSize( int tileImageSize ) {
        this.tileImageSize = tileImageSize;
    }
    
    public int getTileImageSize() {
        return tileImageSize;
    }
    
    public void setWireframe( boolean wireframe ) {
        this.wireframe = wireframe;
    }
    
    public boolean getWireframe() {
        return wireframe;
    }
    
          
}
