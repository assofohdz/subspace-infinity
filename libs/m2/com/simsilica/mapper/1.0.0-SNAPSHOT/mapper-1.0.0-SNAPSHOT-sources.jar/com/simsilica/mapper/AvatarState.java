/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.scene.shape.*;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.state.CubeSceneState;

import com.simsilica.fractal.*;


/**
 *  Presents one of many properly scaled avatars on the ground to
 *  better determine scale on raw terrain.
 *
 *  @author    Paul Speed
 */
public class AvatarState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(AvatarState.class);

    private Map<String, Spatial> avatars = new HashMap<>();
    private Sampler elevation; 
    private VersionedReference<Vec3d> posRef;
    private VersionedReference<Double> viewOffsetRef;

    private String currentName;
    private Spatial currentAvatar; 

    private Node viewRoot;
    private float masterScale;

    // For displaying the scale legend... only convenient here because we
    // are already tracking geometry in the world.
    private VersionedReference<Double> zoomRef;    
    //private Spatial scaleLegend;

    private Container legend;
    private Panel miles;
    private Label milesLabel;
    private Panel kilometers;
    private Label kilometersLabel;
    
    private float[] mileLevels = {
            0.01f,
            0.025f,
            0.05f,
            0.1f,
            0.25f,
            0.5f,
            1,
            5,
            10,
            25,
            50,
            100
        };
    private float[] kmLevels = {
            0.01f,
            0.025f,
            0.05f,
            0.1f,
            0.25f,
            0.5f,
            1,
            5,
            10,
            20,
            50,
            100
        };

    public AvatarState() {        
    }
    
    public void setAvatar( String avatar ) {
        if( Objects.equals(avatar, currentName) ) {
            return;
        }
        if( this.currentAvatar != null ) {
            currentAvatar.removeFromParent();
        }
        this.currentName = avatar;
        this.currentAvatar = avatars.get(currentName);
        if( this.currentAvatar != null ) {
            viewRoot.attachChild(currentAvatar);
        }        
    }
    
    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }

    protected Node getGuiNode() {
        return ((Main)getApplication()).getGuiNode();
    }
    
    @Override
    protected void initialize( Application app ) {
        this.elevation = getState(MapState.class).getElevation();
        this.posRef = getState(CameraControlState.class).createPosRef();
        this.viewRoot = new Node("avatarRoot");
        this.viewOffsetRef = getState(MapViewState.class).createViewOffsetRef();
        this.zoomRef = getState(CameraControlState.class).createZoomRef();
 
        // Set the master scale
        masterScale = 1024f/32767;
        viewRoot.setLocalScale(masterScale);
        
        // Now for some sample models
        Spatial model;
        model = getState(CubeSceneState.class).createCube(0.25f, 0.9f, 0.25f, ColorRGBA.Red);
        model.setShadowMode(ShadowMode.CastAndReceive);
        model.move(0, 0.9f, 0);
        avatars.put("Red Cube", model); 
         
        model = getState(CubeSceneState.class).createCube(20, 20, 20, ColorRGBA.Red);
        model.setShadowMode(ShadowMode.CastAndReceive);
        model.move(0, 20, 0); 
        avatars.put("Big Red Cube", model);
 
        Node combined = new Node("test");
        combined.attachChild(model);
 
        Spatial ship = app.getAssetManager().loadModel("Models/surprise-ship.j3o");
        ship.setLocalScale(1); // undo the block-ed quartering
log.info("ship local scale:" + ship.getLocalScale());        
        model = new Node("ship");
        model.setShadowMode(ShadowMode.CastAndReceive);
        ((Node)model).attachChild(ship);
        model.center();
        model.move(0, -model.getLocalTranslation().y, 0);               
log.info("Ship bounds:" + ship.getWorldBound());        
        
        avatars.put("Ship", model);

        combined.attachChild(model);
        avatars.put("Combined", combined);
        
        //setAvatar("Red Cube");
        setAvatar("Ship");
        //setAvatar("Combined");
        
        //Quad mesh = new Quad(100, 100);
        //scaleLegend = new Geometry("test", mesh);
        //scaleLegend.setMaterial(GuiGlobals.getInstance().createMaterial(ColorRGBA.Red, false).getMaterial());
        //scaleLegend.setLocalTranslation(400, 400, 0);
 
 
        TbtQuadBackgroundComponent tbt = TbtQuadBackgroundComponent.create("/legend-bar.png", 0.25f,
                                                                           5, 5, 123, 11, 0, false);
                                                                           
        legend = new Container();  
        
        Container row = legend.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.Last, FillMode.Last)));
        row.setInsets(new Insets3f(0, 0, 4, 0));
        kilometers = row.addChild(new Panel());
        kilometers.setBackground(tbt);
        kilometersLabel = row.addChild(new Label("3 km"));
        kilometersLabel.setInsets(new Insets3f(0, 5, 0, 0));
        kilometersLabel.setFontSize(12);

        row = legend.addChild(new Container(new SpringGridLayout(Axis.X, Axis.Y, FillMode.Last, FillMode.Last)));
        miles = row.addChild(new Panel());
        miles.setBackground(tbt.clone());
        milesLabel = row.addChild(new Label("1 mi."));
        milesLabel.setInsets(new Insets3f(0, 5, 0, 0));
        milesLabel.setFontSize(12);
        
        legend.setLocalTranslation(100, 100, 0); 
        
        updateLegend();       
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
        //getGuiNode().attachChild(scaleLegend);
        getGuiNode().attachChild(legend);
        updatePosition();
    }
    
    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
        //scaleLegend.removeFromParent();
        legend.removeFromParent();
    }
    
    @Override
    public void update( float tpf ) {
        if( posRef.update() || viewOffsetRef.update() ) {
            updatePosition();
        }
        if( zoomRef.update() ) {
            updateLegend();
        }
    }
    
    protected void updatePosition() {
        Vec3d pos = posRef.get();
        //double h = elevation.getSample(pos.x, 0, pos.z);
        double h = viewOffsetRef.get();
        
        viewRoot.setLocalTranslation(0, (float)(masterScale * h), 0);
        
        log.info("elevation:" + h);
        log.info("current avatar bounds:" + currentAvatar.getWorldBound());
    }

    protected float getScreenDistance( float worldDistance ) {
        Vector3f start = viewRoot.getWorldTranslation().clone();
        start.y = 0;
        Vector3f end = start.add(worldDistance * masterScale, 0, 0);
 
        start = getApplication().getCamera().getScreenCoordinates(start);
        end = getApplication().getCamera().getScreenCoordinates(end);
        
        //log.info("start:" + start + "  end:" + end);
        return start.distance(end);
    }
 
    protected void updateLegend() {
        log.info("Zoom:" + zoomRef.get());
        float dist = 0;
        int level;
        for( level = 0; level < kmLevels.length; level++ ) {
            dist = getScreenDistance(kmLevels[level] * 1000);
log.info("[" + level + "] scale:" + kmLevels[level] + " km dist:" + dist);
            if( dist > 50 ) {
                break;
            }
        }         
        kilometers.setPreferredSize(new Vector3f(dist, 12, 1));
        if( kmLevels[level] <= 0.1 ) {
            kilometersLabel.setText((1000 * kmLevels[level]) + " m");
        } else {
            kilometersLabel.setText(kmLevels[level] + " km");
        }

        for( level = 0; level < kmLevels.length; level++ ) {
            dist = getScreenDistance(mileLevels[level] * (1000/0.62f));
log.info("[" + level + "] scale:" + mileLevels[level] + " miles dist:" + dist);
            if( dist > 50 ) {
                break;
            }
        }         
        //dist = getScreenDistance(1000f / 0.62f);
        miles.setPreferredSize(new Vector3f(dist, 12, 1));
        milesLabel.setText(mileLevels[level] + " mi.");
    }
}

