/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.io.*;
import java.util.*;
import javax.script.*;

import org.slf4j.*;

import com.google.common.base.Charsets;
import com.google.common.io.Files;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.util.SafeArrayList;

import com.simsilica.state.DebugHudState;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ScriptState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ScriptState.class);

    private ScriptEngine engine;
    private Bindings mainBindings;

    private SafeArrayList<ScriptEntry> scripts = new SafeArrayList<>(ScriptEntry.class); 
    private Map<File, ScriptEntry> entryIndex = new HashMap<>();

    public ScriptState() {        
    }

    public void addScript( String scriptFile ) {
        File root = MapperConfig.getInstance().getScriptsDir();
        addScript(new File(root, scriptFile));
    }

    public void addScript( File script ) {
        if( entryIndex.containsKey(script) ) {
            return;
        }
        ScriptEntry entry = new ScriptEntry(script); 
        scripts.add(entry);
        entryIndex.put(script, entry);
    }

    public void executeScript( String scriptFile ) {
        File root = MapperConfig.getInstance().getScriptsDir();
        executeScript(new File(root, scriptFile));
    }

    public void setBinding( String name, Object object ) {
        mainBindings.put(name, object);
    }

    public void executeScript( File script ) {
        try {
            log.info("Running script:" + script);
            String contents = Files.toString(script, Charsets.UTF_8);
            //log.info("contents:" + contents);
        
            Bindings bindings = engine.createBindings();
            bindings.putAll(mainBindings);
            bindings.put("log", LoggerFactory.getLogger(Files.getNameWithoutExtension(script.getName())));
            
            engine.eval(contents, bindings);
        } catch( Exception e ) {
            log.error("Error evaluating:" + script, e);
        }       
    }
    
    @Override
    protected void initialize( Application app ) {
        ScriptEngineManager mgr = new ScriptEngineManager();
        this.engine = mgr.getEngineByExtension("groovy");
        log.info("Engine:" + engine);
        if( engine == null ) {
            throw new RuntimeException("No groovy script engine found");
        }
        this.mainBindings = engine.createBindings();
        mainBindings.put("app", getApplication());
        mainBindings.put("scriptState", this);
        mainBindings.put("mapState", getState(MapState.class));
        mainBindings.put("mapViewState", getState(MapViewState.class));
        mainBindings.put("horizonState", getState(HorizonState.class));
        mainBindings.put("markers", getState(MarkerState.class));
        mainBindings.put("config", MapperConfig.getInstance());
        mainBindings.put("debugHud", getState(DebugHudState.class));             

        File root = MapperConfig.getInstance().getScriptsDir();
        for( File f : root.listFiles() ) {
            if( f.isDirectory() ) {
                continue;
            }
            if( f.getName().endsWith(".groovy") ) {
                addScript(f);
            }
        }        
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        for( ScriptEntry e : scripts.getArray() ) {
            e.update();
        }
    }
    
    private class ScriptEntry {
        File scriptFile;
        long lastModified;
        
        public ScriptEntry( File scriptFile ) {
            this.scriptFile = scriptFile;
        }
        
        public void update() {
            long l = scriptFile.lastModified();
            if( l > lastModified ) {
                lastModified = l;
                executeScript(scriptFile);
            }
        }
    } 
}


