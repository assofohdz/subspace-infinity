/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.nio.*;

import com.simsilica.fractal.Sampler;

/**
 *  Utilities for writing Samplers to JME Images.
 *
 *  @author    Paul Speed
 */
public class ImageUtils {

    // Sampler should return values between 0 and 65536
    public static void writeToImage( Sampler elevation, Sampler coloring, int xSource, int zSource, int size, 
                                     ByteBuffer data, int xTarget, int yTarget, int imageSize ) {       
        int pos = xTarget + yTarget * imageSize;
        
        for( int y = 0; y < size; y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < size; x++ ) {
                int val = (int)elevation.getSample(xSource + x, 0, zSource + y);
                int col = (int)(coloring.getSample(xSource + x, 0, zSource + y) * 255);
                
                // We support +/- 32500... which means we need to offset
                val += 32500;
                
                if( val < 0 ) {
                    // invert it up
                    val = -val; 
                } else if( val > 65000 ) {
                    // Invert it down
                    val = val - 65000;
                    val = 65000 - val;
                }
 
                // The bytes will be passed through as a float where 0 = 0
                // and 1 == 255.  So to fit our stuff in we have to break it up
                // appropriately.
                int hi = (int)(val / 255);
                int lo = (int)(val % 255);
                
                byte a = (byte)hi;
                byte r = (byte)lo;

                if( col < 0 ) {
                    //col = 0;
                    hi = 0;
                    lo = -col;  // already multiplied by 255
                } else if( col >= 0 ) {
                    //col = 255 * 255;
                    hi = col; // already multiplied by 255
                    lo = 0;
                }
                                
                //hi = (int)(col / 255);
                //lo = (int)(col % 255);
                
                byte g = (byte)hi;
                byte b = (byte)lo;
                
                data.put(a).put(r).put(g).put(b);
                pos++;
            }
            pos += imageSize - size;
        } 
    }

    // sources Samplers should return values between 0 and 255.
    // there should be four sources samplers representing a, r, g, b channels
    // of 'data'.
    public static void writeToImage( Sampler[] sources, int xSource, int zSource, int size, 
                                     ByteBuffer data, int xTarget, int yTarget, int imageSize ) {       
 
        int pos = xTarget + yTarget * imageSize;
        
        for( int y = 0; y < size; y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < size; x++ ) {
                for( int i = 0; i < 4; i++ ) {
                    data.put((byte)sources[i].getSample(xSource + x, 0, zSource + y));
                }
                pos++;
            }
            pos += imageSize - size;
        } 
    }
                                     
}


