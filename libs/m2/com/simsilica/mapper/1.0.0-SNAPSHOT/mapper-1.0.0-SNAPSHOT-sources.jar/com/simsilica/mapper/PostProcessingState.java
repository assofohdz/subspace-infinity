/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.AssetManager;
import com.jme3.math.*;
import com.jme3.post.FilterPostProcessor;
import com.jme3.shadow.DirectionalLightShadowFilter;
import com.jme3.system.AppSettings;

import com.simsilica.fx.LightingState;

import com.simsilica.lemur.props.PropertyPanel;

/**
 *
 *
 *  @author    Paul Speed
 */
public class PostProcessingState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PostProcessingState.class);

    private FilterPostProcessor fpp;
    private DirectionalLightShadowFilter shadows;
    private float shadowStrength = 0.3f;

    private PropertyPanel settings;    

    public PostProcessingState() {        
    }
    
    public PropertyPanel getSettings() {
        return settings;
    }
    
    public void setEnableShadows( boolean b ) {
        if( shadows != null ) {
            shadows.setEnabled(b);
        }
    }

    public boolean getEnableShadows() {
        return shadows.isEnabled();
    }

    public void setShadowStrength( float f ) {
        if( this.shadowStrength == f ) {
            return;
        }
        this.shadowStrength = f;
        resetShadowStrength();
    }
    
    public float getShadowStrength() {
        return shadowStrength;
    }

    protected void resetShadowStrength() {
        shadows.setShadowIntensity(shadowStrength);
    }
    
    @Override
    protected void initialize( Application app ) {
        AssetManager assets = app.getAssetManager();
        
        fpp = new FilterPostProcessor(assets);
        AppSettings appSettings = app.getContext().getSettings();
        if( appSettings.getSamples() != 0 ) {
            fpp.setNumSamples(appSettings.getSamples());
        }

        shadows = new DirectionalLightShadowFilter(assets, 4096, 4);
        shadows.setShadowIntensity(0.3f);
        shadows.setLight(getState(LightingState.class).getSun());
        shadows.setEnabled(false); 
        fpp.addFilter(shadows);

        settings = new PropertyPanel("glass");

        settings.addBooleanProperty("Shadows", this, "enableShadows");
        settings.addFloatProperty("Shadow Strength (*)", this, "shadowStrength", 0, 1, 0.05f);
        settings.addFloatProperty("Time of Day", getState(LightingState.class), "timeOfDay", -0.1f, 1.1f, 0.01f);
        settings.addFloatProperty("Sun Orientation", getState(LightingState.class), "orientation", 0f, FastMath.TWO_PI, 0.01f);
                
        resetShadowStrength();
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
        getApplication().getViewPort().addProcessor(fpp);        
    }
    
    @Override
    protected void onDisable() {
        getApplication().getViewPort().removeProcessor(fpp);        
    }
}

