/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.lemur.core.*;

import com.simsilica.mathd.*;

import com.simsilica.fractal.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MapState extends BaseAppState implements VersionedObject<MapState> {

    static Logger log = LoggerFactory.getLogger(MapState.class);

    private long version = 0;

    private Sampler estimated;
    private Sampler elevation;
    private Sampler coloring;

    private Sampler[] layers = new Sampler[4];

    private double maxElevation = 0;
    private double lastMaxElevation = 0;

    private double minElevation = 0;
    private double lastMinElevation = 0;
    
    private double maxTemperature = 0;
    private double lastMaxTemperature = 0;

    private double minTemperature = 1.0;
    private double lastMinTemperature = 1.0;

    public MapState() {
        long seed = 123;
        seed = MapperConfig.getInstance().getStartupSettingLong("seed", seed);
        initializeFantasy(seed);
        //initializeDefault(seed);
        //initializeSineTest(seed);
        initializeClimate(seed);
        //initConstantClimate();
    }

    protected void testElevation( final Sampler test ) {
log.info("testElevation range:" + test.getRange());    
        final double min = Math.min(-1, test.getRange().getMin());
        final double max = Math.max(1, test.getRange().getMax());
        
        Sampler terrain = new AbstractSampler(-128, 600) {
                public double getSample( double x, double y, double z ) {
                    double e = test.getSample(x, y, z);
                    if( e < 0 ) {
                        e = (e / min) * -128;
                    } else {                        
                        e = (e / max) * 512;
                    }
                    return e;
                }
            };
        setEstimatedElevation(Samplers.offset(terrain, 1000000, 0, 1000000));
        setElevation(Samplers.offset(terrain, 1000000, 0, 1000000));
        getState(MapViewState.class).invalidate();        
    } 

    public void initializeFantasy( long seed ) {
    
        //long seed = 123; //0; // 7; //0;
        //seed = 1234;

        Sampler noise = new PerlinNoise(seed); 
        Sampler noise1 = noise;
        Sampler noise2 = new PerlinNoise(seed+1);
        Sampler noise3 = new PerlinNoise(seed+2);

//        Sampler source1 = Samplers.resample(noise1, 1/512.0, 1, 1/512.0);
//if( false ) {
//    estimated = elevation = Samplers.scale(source1, 128);
//    log.info("elevation range:" + elevation.getRange());        
//    return;
//}
//        Sampler source2 = Samplers.resample(noise2, 1/500.0, 1, 1/500.0);  
//if( false ) {
//    estimated = elevation = Samplers.scale(source2, 128);
//    log.info("elevation range:" + elevation.getRange());        
//    return;
//}        
        //Sampler combined = Samplers.mult(source1, source2);
        Sampler combined;
//if( false ) {
//    estimated = elevation = Samplers.scale(combined, 128);
//    log.info("elevation range:" + elevation.getRange());        
//    return;
//}
        //Sampler offset = Samplers.resample(Samplers.scale(noise3, 150), 1/50.0, 1, 1/50.0);  
        //combined = Samplers.offset(combined, offset, Samplers.constant(0), offset);
        //Sampler resampled = Samplers.resample(combined, 1.0, 1, 1.0);
        Sampler resampled;

//if( true ) {
//    estimated = elevation = Samplers.scale(resampled, 128);
//    log.info("elevation range:" + elevation.getRange());        
//    return;
//}

        FractalSum fractal = new FractalSum(noise1);
        fractal.setFrequencyIterations(2);
 
if( false ) {
    testElevation(Samplers.resample(fractal, 1/512.0, 1, 1/512.0));
    return;
}        
        //Sampler resampledFractal = Samplers.resample(fractal, 1/8096.0, 1, 1/8096.0);
        //Sampler smooth = Samplers.add(Samplers.scale(resampledFractal, 700), Samplers.constant(100));

        long cellSeed = seed; //3;

        Sampler cells = Samplers.smoothStep(0.10, 0.15, new InvertedCellularNoise(cellSeed, true));
        Sampler cellFilter = new CellularFilter(cellSeed, fractal);
        cellFilter = Samplers.reflect(cellFilter, 0.3, 1);
        Sampler cellsResampled = Samplers.resample(Samplers.mult(cells, cellFilter), 1/512.0, 1, 1/512.0);

if( false ) {
    testElevation(cellsResampled);
    return;
}        

        // jitter the coordinates a bit
        //cellsResampled = Samplers.offset(cellsResampled, 
        //                                 Samplers.scale(Samplers.resample(noise1, 1/2.0, 1, 1/2.0), 1), 
        //                                 Samplers.constant(0), 
        //                                 Samplers.scale(Samplers.resample(noise2, 1/2.0, 1, 1/2.0), 1));
        //cellsResampled = Samplers.offset(cellsResampled, 20, 0, 0);

        // This jitter is nice... but it's slow.  We need a fast spikey noise.
        double jitterFrequency = 1/5.0;
        Sampler jitter1 = Samplers.resample(new CellularFilter(cellSeed, noise1), jitterFrequency, 1, jitterFrequency);
        Sampler jitter2 = Samplers.resample(new CellularFilter(cellSeed, noise2), jitterFrequency, 1, jitterFrequency);

if( false ) {
    testElevation(jitter1);
    return;
}        

if( false ) {
    testElevation(jitter2);
    return;
}        

        // When we figure out a good spikey jitter we need to apply it
        // to mix2, also.

        cellsResampled = Samplers.offset(cellsResampled, 
                                        Samplers.scale(jitter1, 5), 
                                        Samplers.constant(0), 
                                        Samplers.scale(jitter2, 5));

        //mapState.setElevation(Samplers.scale(cellsResampled, 500));
if( false ) {
    testElevation(cellsResampled);
    return;
}

        Sampler cells2 = Samplers.smoothStep(0.005, 0.01, new InvertedCellularNoise(cellSeed, true)); 
        Sampler cellsResampled2 = Samplers.resample(cells2, 1/256.0, 1, 1/256.0);

if( false ) {
    // low frequency cracks
    testElevation(cellsResampled2);
    return;
}

        Sampler cells3 = Samplers.smoothStep(0.005, 0.01, new InvertedCellularNoise(cellSeed, true)); 
        Sampler cellsResampled3 = Samplers.resample(cells2, 1/64.0, 1, 1/64.0);

if( false ) {
    // Higher frequency cracks
    testElevation(cellsResampled3);
    return;
}

        CellularFilter filter = new CellularFilter(cellSeed, fractal);
        //Sampler filterResampled = Samplers.resample(filter, 1/256, 1, 1/256.0); 
        Sampler filterResampled = Samplers.resample(filter, 1/256.0, 1, 1/256.0); 

if( false ) {
    // Random height plateuas
    testElevation(filterResampled);
    return;
}

        Sampler cracked;
        if( true ) {
            cracked = Samplers.add(Samplers.scale(
                                                Samplers.mult(cellsResampled3, 
                                                    Samplers.mult(cellsResampled, cellsResampled2)
                                                    ), 
                                                200), 
                                        Samplers.scale(filterResampled, 50));
        } else {
            // Just faster for now  
            cracked = Samplers.scale(cellsResampled, 200);
        }  
        //mapState.setElevation(cracked);
if( false ) {
    // Random height cracked plateaus
    testElevation(cracked);
    return;
}


        // This is the basic continent configuration
        //=============================================
        // Characteristics: 
        // large scale land masses with large oceans between them.
        // Large land masses are mostly isolated such that all oceans
        // are reachable.
        // There don't appear to be many deserts in this version... not sure
        // why. 

        fractal = new FractalSum(noise1);
        fractal.setFrequencyIterations(3);              

        resampled = Samplers.resample(fractal, 1/8096.0, 1, 1/8096.0);

if( false ) {
    // smooth large scale fractal, though not that large scale.
    testElevation(resampled);
    return;
}

        //mapState.setElevation(resampled);

        double raiseWidth = 40096.0;
        double raiseHeight = 40096.0;        
        //double raiseWidth = 60096.0;        
        Sampler raise = Samplers.resample(noise1, 1/raiseWidth, 1, 1/raiseHeight);
        raise = Samplers.subtract(raise, Samplers.constant(0.1));

        // raise should be in the range of -1.1 to 0.9 now.

if( false ) {
    // VERY large scale noise.
    testElevation(raise);
    return;
}

        log.info("raise range:" + raise.getRange());

        //mapState.setElevation(raise);

        resampled = Samplers.add(resampled, Samplers.scale(raise, 3));
        log.info("resampled range:" + resampled.getRange());

if( false ) {
    // Large content shapes
    testElevation(resampled);
    return;
}

        // Trying to scale things properly so that continents is in -1..1 space
        //resampled = Samplers.add(Samplers.scale(resampled, 0.25), Samplers.scale(raise, 0.75));
        resampled = Samplers.scale(resampled, 0.25);

        log.info("resampled range:" + resampled.getRange());

        // Check myself before I wreck myself... this should make it obvious when
        // I mess up
        resampled = Samplers.clip(resampled, -1, 1); 

if( false ) {
    // Essentially the same when rescaled to terrain elevations.
    testElevation(resampled);
    return;
}

        log.info("resampled range:" + resampled.getRange());

        Sampler unscaledContinents = resampled;
        resampled = Samplers.scale(resampled, 600);
        Sampler continents = resampled;
        //mapState.setElevation(continents);

        // Let's play with a transition fractal

        FractalSum fractal1 = new FractalSum(noise1);
        fractal1.setFrequencyIterations(2);              

        FractalSum fractal2 = new FractalSum(noise2);
        fractal2.setFrequencyIterations(2);              

        FractalSum fractal3 = new FractalSum(noise3);
        fractal3.setFrequencyIterations(2);              

        combined = Samplers.mult(fractal1, fractal2);
        Sampler mix1 = Samplers.smoothStep(-0.005, 0.005, Samplers.resample(combined, 1/8192.0, 1, 1/8192.0));

if( false ) {
    // Large scale 0..1 plateaus with smoothness between them. 
    testElevation(mix1);
    return;
}

        // When we use mix1 for mountainous terrain mixing them we want a wider slope
        //mix1 = Samplers.smoothStep(-0.05, 0.05, Samplers.resample(combined, 1/8192.0, 1, 1/8192.0));
//        mix1 = Samplers.smoothStep(-0.005, 0.1, Samplers.resample(combined, 1/8192.0, 1, 1/8192.0));
//
//if( false ) {
//    // Large scale 0..1 plateaus with smoothness between them. 
//    testElevation(mix1);
//    return;
//}
// That set is exactly the same as the next one.

        //mix1 = Samplers.smoothStep(-0.005, 0.1, Samplers.resample(combined, 1/4096.0, 1, 1/4096.0));

        mix1 = Samplers.smoothStep(-0.005, 0.1, Samplers.resample(combined, 1/8192.0, 1, 1/8192.0));
        
if( false ) {
    // Large scale 0..1 plateaus with smoothness between them. 
    testElevation(mix1);
    return;
}
        // mix1 is probably pretty close to what we'd need for mountainous country... with a smoother step.

        Sampler scaled = Samplers.scale(mix1, 400);
        //mapState.setElevation(scaled);

        //Sampler test = Samplers.add(continents, Samplers.mult(cracked, mix1));
        //mapState.setElevation(test);

        // Let's try a more isolated fractal... sparser
        //resampled = Samplers.resample(fractal1, 1/1024.0, 1, 1/1024.0);
        //mapState.setElevation(Samplers.scale(resampled, 400));
        Sampler sparse = new CellularNoise(cellSeed);
        sparse = Samplers.subtract(Samplers.constant(1), sparse);
        filter = new CellularFilter(cellSeed, Samplers.scale(Samplers.resample(fractal1, 0.25, 1, 0.25), 8)); 
        sparse = Samplers.add(sparse, filter);
        sparse = Samplers.step(4, sparse);
        resampled = Samplers.resample(sparse, 1/2000.0, 1, 1/2000.0);
        Sampler mix2 = resampled;
        //mapState.setElevation(Samplers.scale(mix2, 600));

if( false ) {
    // Sparse plateaus... very spread out.
    testElevation(mix2);
    return;
}
        // 2022-12-26
        // It occurs to me that it would be interesting to use noise to feed into
        // the slope of the cracks and stuff so that they aren't always so vertical.

        //Sampler test2 = Samplers.add(continents, Samplers.mult(mix2, cracked));
        //mapState.setElevation(test2);

        // So now what about some mountains?
        fractal1 = new FractalSum(noise1);
        fractal1.setFrequencyIterations(6);
        resampled = Samplers.resample(fractal1, 1/2048.0, 1, 1/2048.0);
        Sampler mountains = Samplers.scale(resampled, 600);
        //mapState.setElevation(Samplers.scale(resampled, 600));

if( false ) {
    // Exactly what is says on the tin... mountains.  This might
    // also be a good place for a ridge fractal 
    testElevation(mountains);
    return;
}

        //mapState.setElevation(Samplers.mult(Samplers.scale(resampled, 600), mix1));

        Sampler continentsSquared = Samplers.reslope(unscaledContinents, 2, 0.005, 0.8);

if( false ) {
    // Large scale continent shapes essentially copied forward from way above.   
    //testElevation(unscaledContinents);
    // This seems to be turning the continents into "yes" and "no" style
    // fractal.   Big giant jigsaw shapes.
    // Way below, we add this to the final fractal I guess to better carve out
    // the continents. 
    testElevation(continentsSquared);
    return;
}

        continentsSquared = Samplers.scale(continentsSquared, 600);
        //mapState.setElevation(continentsSquared);

        mix1 = Samplers.mult(mix1, Samplers.step(-0.1, unscaledContinents));

if( false ) {
    // Roughly continent shaped areas of sparse plateaus with smooht transitions
    testElevation(mix1);
    return;
}


        // And just some basic rolling hills
        fractal1 = new FractalSum(noise1);
        fractal1.setFrequencyIterations(4);
        resampled = Samplers.resample(fractal1, 1/512.0, 1, 1/512.0);
        Sampler unscaledRollingHills = resampled;
        Sampler rollingHills = Samplers.scale(unscaledRollingHills, 50);  

if( false ) {
    // Basically what it says 
    testElevation(rollingHills);
    return;
}

        // Break out the negative part of the rolling hills so that
        // we can apply it after we do the 'max' on the other terrain types
        // ...but mute it a bit because we don't want to go too negative.
        //def negativeRollingHills = Samplers.clamp(Samplers.scale(rollingHills, 0.5), -600, 0);
        //def negativeRollingHills = Samplers.clamp(Samplers.scale(rollingHills, 0.25), -600, 0);
        // Or what if we let hight elevations be more dramatic by scaling against
        // the continent itself
        Sampler negativeRollingHills = Samplers.clamp(Samplers.scale(unscaledRollingHills, 1), -600, 0);

if( false ) {
    // This one is a weird one at least in how it renders
    //testElevation(negativeRollingHills);
    // So yeah, it only renders weird, if I flip it upside down then 
    // it's eactly as it says... the negative part of the rolling hills
    testElevation(Samplers.scale(negativeRollingHills, -1));
    return;
}

        Sampler noiseScale = Samplers.pow(Samplers.clamp(unscaledContinents, 0, 1), 2);

if( false ) {
    // Smooth versions of the larger continents clamped to just the positive parts.
    // Running it through pow() makes it slightly more dramatic I guess... but you
    // can't really tell. 
    testElevation(noiseScale);
    return;
}

        negativeRollingHills = Samplers.mult(noiseScale, negativeRollingHills);

if( false ) {
    // Clamping the negative hills to just the large continent shapes
    testElevation(Samplers.scale(negativeRollingHills, -1));
    return;
}

        //mapState.setElevation(Samplers.scale(negativeRollingHills, 100));
        negativeRollingHills = Samplers.scale(negativeRollingHills, 500);

if( false ) {
    testElevation(Samplers.scale(negativeRollingHills, -1));
    return;
}

        Sampler mixedMountains = Samplers.mult(mix1, mountains);

if( false ) {
    // area-clamped mountains, sometimes with hard edges sometimes with
    // smooth edges. 
    testElevation(mixedMountains);
    return;
}

        Sampler mixedCracks = Samplers.mult(mix2, cracked);

if( false ) {
    // area-clamped cracked plateaus, always hard edges... maybe unfortunately. 
    testElevation(mixedCracks);
    return;
}

if( false ) {
    // Just seeing what it looks like if we use the smooth+hard edged
    // mix on the cracked sampler... looks kind of cool and we have some
    // gradual cracked plateua hills.  Might be worth investigating. 
    testElevation(Samplers.mult(mix1, cracked));
    return;
}

        Sampler rocks = Samplers.max(mixedMountains, mixedCracks);
        
if( false ) {
    // Exactly what it looks like... the better of mountains or cracks 
    testElevation(rocks);
    return;
}
        
        rocks = Samplers.max(rollingHills, rocks);
        
if( false ) {
    // Bringing back in the rolling hills variations
    testElevation(rocks);
    return;
}
        
        rocks = Samplers.add(rocks, negativeRollingHills);

if( false ) {
    // It's weird because this seems to take away some of the negative
    // areas and I expected it to add to them.  Hmmm...
    testElevation(rocks);
    return;
}

        Sampler test3 = Samplers.add(continentsSquared, rocks);
        setElevation(Samplers.offset(test3, 1000000, 0, 1000000));
        setEstimatedElevation(elevation);
        
        //initializeClimate(seed);
    } 
    
    private void initializeSineTest( long seed ) {

        //long seed = 0; // 7; //0;

        Sampler sinX = Samplers.sin(Samplers.dot(Vec3d.UNIT_X));
        Sampler sinZ = Samplers.sin(Samplers.dot(Vec3d.UNIT_Z));
 
        Sampler combined = Samplers.mult(sinX, sinZ);
        
        // And flatten the curves a little... e * e * e
        Sampler pow = Samplers.mult(combined, combined);
        pow = Samplers.mult(pow, combined);

        Sampler resampled = Samplers.resample(pow, Math.PI/256, 1, Math.PI/256);
        final Sampler base = resampled;

        // We don't have result remapping so this is what we do
        Sampler terrain = new AbstractSampler(-128, 512) {
                public double getSample( double x, double y, double z ) {
                    double e = base.getSample(x, y, z);
                    if( e < 0 ) {
                        return e * 128; 
                    } else {
                        return e * 512;
                    }
                }
            };
        setElevation(Samplers.offset(terrain, 1000000, 0, 1000000));
        setEstimatedElevation(Samplers.offset(terrain, 1000000, 0, 1000000));

        //coloring = resampled;
        
        //layers[0] = Samplers.constant(0);
        //layers[1] = Samplers.constant(0);
        //layers[2] = Samplers.constant(0);
        //layers[3] = Samplers.constant(0);
 
        // For temperature zones 
        double temperatureWidth = 16384 * 2;
        double temperatureHeight = 16384;
        resampled = Samplers.resample(new PerlinNoise(seed), 1/temperatureWidth, 0, 1/temperatureHeight);
        final Sampler temperature = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 0.5);
         
        // For wetness
        double wetnessWidth = 16384;
        double wetnessHeight = 16384 * 2;
        resampled = Samplers.resample(new PerlinNoise(seed + 1), 1/wetnessWidth, 0, 1/wetnessHeight);                   
        final Sampler unnormalizedWetness = resampled;
        final Sampler wetness = Samplers.scale(Samplers.add(unnormalizedWetness, Samplers.constant(1)), 0.5);

        // anything over the snow line is 'snow'... no matter what
        final double snowLine = 500;       
        coloring = new AbstractSampler(0, 1) {
                public double getSample( double x, double y, double z ) {
                
                    double height = y; 
                    if( height > maxElevation ) {
                        maxElevation = height;
                    } else if( height < minElevation ) {
                        minElevation = height;
                    }
                    if( height <= 0 ) {
                        double underWater = Math.min(1, (height-1)/-300);
                        return -underWater;
                    } 
                    height = height / snowLine;                     
                    double t = temperature.getSample(x, 0, z);
                    double baselineHeight = 0.2;
                    double heightEffect = (height - baselineHeight) / (1.0 - baselineHeight);
                    double temperatureAdjust = heightEffect * 0.4;
                    
                    t -= temperatureAdjust;  
                    
                    if( t > maxTemperature ) {
                        maxTemperature = t;
                    }
                    if( t < minTemperature ) {
                        minTemperature = t;
                    }
                    double w = wetness.getSample(x, 0, z);
                    double climateAdjust = t - 0.5;
                    double color = w - climateAdjust;
                    if( color < 0 ) return 0;
                    if( color > 1 ) return 1;
                    return color; 
                }
            }; 
 
        layers[0] = temperature;
        layers[1] = Samplers.subtract(Samplers.constant(1), wetness); // inverts 0..1 to 1..0        
        
        resampled = Samplers.resample(new PerlinNoise(seed), 1/16.0, 1, 1/16.0);
        Sampler veg1 = resampled;
        resampled = Samplers.resample(new PerlinNoise(seed), 1/128.0, 1, 1/128.0);
        Sampler veg2 = resampled;
        resampled = Samplers.resample(new PerlinNoise(seed), 1/1024.0, 1, 1/1024.0);
        Sampler veg3 = resampled;
        Sampler veg = Samplers.scale(Samplers.add(veg1, veg2), 0.5);
        veg = Samplers.scale(Samplers.add(veg, veg3), 0.5);
        veg = Samplers.add(veg, Samplers.scale(unnormalizedWetness, 0.5));
        final Sampler vegBase = veg;

        final double treeLine = snowLine;
        final double deepWater = -100;        
        veg = new AbstractSampler(-1, 1) {
                public double getSample( double x, double y, double z ) {
                    double height = y; //elevation.getSample(x, y, z);
                    if( height > treeLine ) {
                        return 0;
                    }
                    if( height < deepWater ) {
                        return 0;
                    }
                    double result = vegBase.getSample(x, 0, z);
                    if( height < 0 ) {
                        result *= 0.5;
                    }
                    return result;
                }
            };         
        
        veg = Samplers.clamp(veg, 0, 1); 
        layers[2] = veg;
        layers[3] = Samplers.constant(0);
    }
    
    private void initializeDefault( long seed ) {
        //double resample = 1/1024.0;
        //double resample1 = 1/8.0;
        //double resample2 = 1/32.0;
        /*double resample1 = 1/32.0;
        double resample2 = 1/128.0;
        double resample3 = 1/512.0;
        final Sampler sin1 = Samplers.sin(Samplers.dot(Vec3d.UNIT_X));
        Sampler sin2 = Samplers.sin(Samplers.dot(Vec3d.UNIT_Z));
        Sampler combined = Samplers.add(sin1, sin2);
        Sampler raw1 = Samplers.resample(combined, resample1, 1, resample1); 
        Sampler raw2 = Samplers.resample(combined, resample2, 1, resample2);
        Sampler raw3 = Samplers.scale(Samplers.resample(combined, resample3, 1, resample3), 10);
        //Sampler raw = Samplers.mult(raw3, Samplers.mult(raw1, raw2));
        
        Sampler raw4 = Samplers.sin(Samplers.scale(Samplers.distance(512, 0, 512), 0.0025));
        raw4 = Samplers.scale(Samplers.add(raw4, Samplers.constant(1)), 10);
         
        Sampler raw = Samplers.add(raw4, Samplers.add(raw3, Samplers.mult(raw1, raw2))); 
        final Sampler scaled = Samplers.scale(Samplers.add(raw, Samplers.constant(25)), 30); 
        //elevation = scaled;
        elevation = new Sampler() {
                public double getSample( double x, double y, double z ) {
                    if( Math.abs(x) < 400 && Math.abs(z) < 400 ) {
                        return 0;
                    }
                    return scaled.getSample(x, y, z);
                }                
            };
        //elevation = Samplers.constant(0);*/
        // The above was the undulating layered sine waves
        
        //long seed = 123; //0; // 7; //0;
        //seed = 1234;
        
        Sampler noise = new PerlinNoise(seed);
        // Note: if we don't offset this then it creates a cool giant mesa/canyon effect
        // which we could probbaly trigger with some kind of 'step' sampler.
        //elevation = Samplers.scale(Samplers.resample(noise, 1/1024.0, 1, 1/1024.0), 100); 
        
        //final Sampler resampled = Samplers.resample(noise, 1/4096.0, 1, 1/4096.0); 
        //elevation = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 600); 
        //elevation = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 3000);
 
        // Let's try to make canyons
        //elevation = Samplers.scale(Samplers.abs(resampled), 600);
 
        // This does a pretty good job at making desert mesa style terrain
        // with leveled plateaus.       
        /*final Sampler resampled = Samplers.resample(noise, 1/2048.0, 1, 1/2048.0); 
        Sampler custom  = new Sampler() {
                public double getSample( double x, double y, double z ) {
                    double val = resampled.getSample(x, y, z);
                    if( val < -0.5 ) {
                        val = 3 + -val;
                    } else if( val < -0.25 ) {
                        val = 2 + -val;
                    } else if( val < 0 ) {
                        val += 1;
                    } else if( val < 0.1 ) {
                        val += 0.5;
                    }
                    return val;
                }
            };                     
        elevation = Samplers.scale(custom, 300);*/

        // Noisier canyons
        /*final Sampler resampled = Samplers.resample(noise, 1/2048.0, 1, 1/2048.0); 
        Sampler custom  = new Sampler() {
                public double getSample( double x, double y, double z ) {
                    double val = resampled.getSample(x, y, z);
                    if( val < -0.5 ) {
                        val = 3 + -val;
                    } else if( val < -0.25 ) {
                        val = 2 + -val;
                    } else if( val < 0 ) {
                        val += 1;
                    } else if( val < 0.1 ) {
                        val += 0.5;
                    }
                    return val;
                }
            };        
        Sampler offset1 = Samplers.scale(Samplers.resample(new PerlinNoise(1), 1/100.0, 1, 1/100.0), 100);                     
        Sampler offset2 = Samplers.scale(Samplers.resample(new PerlinNoise(2), 1/100.0, 1, 1/100.0), 100);
        // Fairly normal x,z perturbation                     
        //elevation = Samplers.scale(Samplers.offset(custom, offset1, Samplers.constant(0), offset2), 300);
        // Super wild spiky terrain... very cool
        // Spiky                     
        //Sampler offset3 = Samplers.scale(Samplers.resample(new PerlinNoise(3), 1/100.0, 1, 1/100.0), 1);
        // Similar to the x,z perturbation but only one noise 
        //Sampler offset3 = Samplers.scale(Samplers.resample(new PerlinNoise(3), 1/100.0, 1, 1/100.0), 0.1);
        // Less chaotic than the super spiky one.. maybe still a little too chaotic.        
        Sampler offset3 = Samplers.scale(Samplers.resample(new PerlinNoise(3), 1/100.0, 1, 1/100.0), .5); 
        elevation = Samplers.scale(Samplers.offset(custom, Samplers.constant(0), offset3, Samplers.constant(0)), 300);
        */

        // Playing with a good noise for switching terrain types
        /*final Sampler resampled = Samplers.resample(noise, 1/16384.0, 1, 1/16384.0);
        //Sampler normalized = Samplers.add(resampled, Samplers.constant(1));
        Sampler normalized = Samplers.step(0.0, resampled);        
        elevation = Samplers.scale(normalized, 3000);*/ 
 
        // The above is decent for a single switch... or could be used for climate
        // related things.  It doesn't make very good islands, though.

        // This makes really cool mazes of canyons... but it was not really what I 
        // was going for.  Still trying to find a good island/continent base.
        /*double size = 4096; // 16384
        final Sampler resampled1 = Samplers.resample(noise, 1/4096.0, 1, 1/4096.0);
        final Sampler resampled2 = Samplers.resample(new PerlinNoise(1), 1/4096.0, 1, 1/4096.0);
        
        //Sampler horizontal = Samplers.dot(Vec3d.UNIT_X);
        //Sampler offset = Samplers.offset(resampled, Samplers.scale(horizontal, 0.5), Samplers.constant(0), Samplers.constant(0));
        Sampler combined = Samplers.mult(resampled1, resampled2);
        //Sampler normalized = Samplers.add(combined, Samplers.constant(1));
        Sampler normalized = Samplers.step(0.0, combined);
        elevation = Samplers.scale(normalized, 3000);*/ 
 
        FractalSum fractal = new FractalSum(new PerlinNoise(seed));
        fractal.setFrequencyIterations(2);              
        FractalSum fractal2 = new FractalSum(new PerlinNoise(seed + 1));
        fractal2.setFrequencyIterations(2);              
log.info("Fractal1 range:" + fractal.getRange());
log.info("Fractal2 range:" + fractal2.getRange());
               
        Sampler resampled = Samplers.resample(fractal, 1/4096.0, 1, 1/4096.0);
        Sampler resampled2 = Samplers.resample(fractal2, 1/4096.0, 1, 1/4096.0);
        resampled = Samplers.add(resampled, resampled2);
log.info("Resampled range:" + resampled.getRange());
        //resampled = Samplers.subtract(resampled, Samplers.constant(0.25));
        //Sampler normalized = Samplers.add(resampled, Samplers.constant(1));
        //Sampler normalized = Samplers.step(0.0, resampled);
        //elevation = Samplers.scale(normalized, 600);
        //elevation = Samplers.scale(resampled, 600);
 
        //double raiseWidth = 32768.0;        
        double raiseWidth = 40096.0;
        double raiseHeight = 40096.0;        
        //double raiseWidth = 60096.0;        
        Sampler raise = Samplers.resample(noise, 1/raiseWidth, 1, 1/raiseHeight);
        raise = Samplers.subtract(raise, Samplers.constant(0.1));
log.info("Raise range:" + raise.getRange());
//        raise = Samplers.clamp(raise, 0, 1);
        
        // So this make a pretty good 'island base' in the sense that
        // we get lots of large, but not too large, land masses and you can
        // almost always find a way around by water.
        resampled = Samplers.add(resampled, Samplers.scale(raise, 3));
log.info("Resampled range:" + resampled.getRange());
        //resampled = Samplers.scale(raise, 3);
        // If we get a land fractal we like then we can add it in.  It would
        // also maybe make a decent terrain selector.
 
        Sampler terrain = Samplers.scale(resampled, 200); //600); 
        setEstimatedElevation(Samplers.offset(terrain, 1000000, 0, 1000000));       
 
log.info("Elevation range:" + terrain.getRange());
 
        Sampler bumpier = new FractalSum(new PerlinNoise(seed), 8);
        bumpier = Samplers.resample(bumpier, 1/1024.0, 1, 1/1024.4);
        bumpier = Samplers.scale(bumpier, 150);
        // This shows what a higher frequency fractal would look like
        // but it's not the 'real one' and for me not very interesting.
        // It looks cool but slows the visualization way down.
        terrain = Samplers.add(terrain, bumpier);
 
        // The ocean goes muuuuch deeper than 128 so if we reflect there
        // raw then we make too many islands.  So we'll clamp it first
        // to make sure reflect never goes more than 60 back.
        terrain = Samplers.clamp(terrain, -(128 + 60), 1000);       
        terrain = Samplers.reflect(terrain, -128, 512);
        
        setElevation(Samplers.offset(terrain, 1000000, 0, 1000000));
        // The above makes for large flat areas of the ocean in the deepest
        // parts... we really need to be able to rescale the positive and
        // negative halves differently but for now this will do.
 
        // Desert terrain test       
        //elevation = new TempFractalTest(0);         


        // Trying out some simple overlays that we might use for
        // climate.
        /*resampled = Samplers.resample(new PerlinNoise(0), 1/16384.0, 1, 1/16384.0);
        Sampler layer1 = Samplers.clip(resampled, 0.0, 1.0);
        resampled = Samplers.resample(new PerlinNoise(1), 1/16384.0, 1, 1/16384.0);
        Sampler layer2 = Samplers.clip(Samplers.add(resampled, Samplers.constant(1.0)), 1.0, 2.0);

        coloring = Samplers.max(
                layer1,
                layer2
            );*/
            
        //initializeClimate(seed);
    }
  
    
    protected void initializeClimate( long seed ) {

        // For temperature zones 
        double temperatureWidth = 16384 * 2;
        double temperatureHeight = 16384;
        Sampler resampled = Samplers.resample(new PerlinNoise(seed), 1/temperatureWidth, 0, 1/temperatureHeight);
        final Sampler temperature = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 0.5);
         
log.info("Temperature range:" + temperature.getRange()); 

        // For wetness
        double wetnessWidth = 16384;
        double wetnessHeight = 16384 * 2;
        resampled = Samplers.resample(new PerlinNoise(seed + 1), 1/wetnessWidth, 0, 1/wetnessHeight);                   
        final Sampler unnormalizedWetness = resampled;
        final Sampler wetness = Samplers.scale(Samplers.add(unnormalizedWetness, Samplers.constant(1)), 0.5);

log.info("Wetness range:" + wetness.getRange()); 
 
        // anything over the snow line is 'snow'... no matter what
        final double snowLine = 500;       
        coloring = new AbstractSampler(0, 1) {
                public double getSample( double x, double y, double z ) {
                
                    double height = y; 
                    if( height > maxElevation ) {
                        maxElevation = height;
                    } else if( height < minElevation ) {
                        minElevation = height;
                    }
                    if( height <= 0 ) {
                        double underWater = Math.min(1, (height-1)/-300);
                        return -underWater;
                    }
                    height = height / snowLine; 
                    
                    // So now we need to combine height, temperature, and wetness
                    // into a value that fits our climate gradient where 0 is
                    // desert 0.5 is green, and 1.0 is snot.  0.25 if dirt/prairie
                    // and 0.75 is rocky.
                    double t = temperature.getSample(x, 0, z);
                    
                    // Elevation affects temperature... we'll consider temperature
                    // to be the baseline at sea level for now and then adjust
                    // based on elevation.  We may need to adjust what we consider
                    // base line to be.
                    // From the web:
                    // "the temperature decreases by about 5.4 F for every 1,000 feet 
                    // (9.8 C per 1,000 meters) up you go in elevation."  
                    // On our temperature scale, I think 0.01 = 0.833 degree F.
                    // So about 0.04 per 1000 feet.  Mt Everest is about 30k feet.
                    // Our max elevation is ~600 for the sake of this... but in
                    // no way should compare to a mountain like everest.  Let's take
                    // 10k feet as our ceiling.  0..1 elevation == 0..10k feet.
                    // 0..10 scale degrees.  So 0.04 temp per 0.1 elevation as our
                    // starting point and then tweak to what we like.
                    // 0.04 / 0.1 = 0.4 / 1.0
                    //double baselineHeight = 0.0;
                    //double temperatureAdjust = (height - baselineHeight) * 0.4;
                    // Raw, that's a little too agressive
                                       
                    double baselineHeight = 0.2;
                    double heightEffect = (height - baselineHeight) / (1.0 - baselineHeight);
                    double temperatureAdjust = heightEffect * 0.4;
                    
                    t -= temperatureAdjust;  
                    
                    if( t > maxTemperature ) {
                        maxTemperature = t;
                    }
                    if( t < minTemperature ) {
                        minTemperature = t;
                    }
                    //
                    // Let's pretend that temperature is 0-100 F for a second.
                    // Except that doesn't really work because we don't go above
                    // 100 so everything is skewed lower.  We're better off treating
                    // it like a raw range and finding good thresholds.                    
                    /*if( t <= 0.30 ) {
                    //if( t <= 0.25 ) {
                        // Below freezing
                        return 1.0;
                    }
                    if( t >= 0.7 ) {
                    //if( t >= 0.75 ) {
                        // Hot
                        return 0.0;
                    }
                    return 0.5;*/

                    double w = wetness.getSample(x, 0, z);
                    /*if( w <= 0.3 ) {
                        // Arid
                        return 0.0;
                    }
                    if( w >= 0.7 ) {
                        // Wet
                        return 0.5;
                    }
                    return 0.25;*/                    
                    
                    //return height;
                    
                    // Ok, so now how do we combine them?
                    // hot and humid is green... very green.
                    // hot and dry is desert
                    // cold and dry is rocky tundra
                    // cold and wet is snow
                    // Proper terrain generation will take all of these into
                    // account but I'm just trying to summarize for a map color
                    //
                    // Can we get away with just turning temperature into a +/-
                    // on wetness?  Let's try it... turn it info +/- 0.5
                    double climateAdjust = t - 0.5;
                    // So effectively, hotter temperature makes things drier.
                    double color = w - climateAdjust;
                    if( color < 0 ) return 0;
                    if( color > 1 ) return 1;
                    return color; 
                }
            }; 
 
log.info("Coloring range:" + coloring.getRange()); 
 
        //layers[0] = Samplers.modulo(Samplers.dot(Vec3d.UNIT_X), 256);
        layers[0] = temperature;
        layers[1] = Samplers.subtract(Samplers.constant(1), wetness); // inverts 0..1 to 1..0
        
        
        resampled = Samplers.resample(new PerlinNoise(seed), 1/16.0, 1, 1/16.0);
        //Sampler veg1 = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 0.5);
        Sampler veg1 = resampled;
        resampled = Samplers.resample(new PerlinNoise(seed), 1/128.0, 1, 1/128.0);
        //Sampler veg2 = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 0.5);
        Sampler veg2 = resampled;
        resampled = Samplers.resample(new PerlinNoise(seed), 1/1024.0, 1, 1/1024.0);
        //Sampler veg2 = Samplers.scale(Samplers.add(resampled, Samplers.constant(1)), 0.5);
        Sampler veg3 = resampled;
        Sampler veg = Samplers.scale(Samplers.add(veg1, veg2), 0.5);
        veg = Samplers.scale(Samplers.add(veg, veg3), 0.5);
        veg = Samplers.add(veg, Samplers.scale(unnormalizedWetness, 0.5));
        final Sampler vegBase = veg;

        final double treeLine = snowLine;
        final double deepWater = -65; // -100;        
        veg = new AbstractSampler(-1, 1) {
                public double getSample( double x, double y, double z ) {
                    double height = y; 
                    if( height > treeLine ) {
                        return 0;
                    }
                    if( height < deepWater ) {
                        return 0;
                    }
                    double result = vegBase.getSample(x, 0, z);
                    if( height < 0 ) {
                        result *= 0.5;
                    }
                    return result;
                }
            }; 
        
        
        veg = Samplers.clamp(veg, 0, 1); 
        layers[2] = veg;
        layers[3] = Samplers.constant(0);
         
        for( int i = 0; i < layers.length; i++ ) {
            log.info("layers[" + i + "] range:" + layers[i].getRange());
        }     
    }
    
    public void initConstantClimate() {
        //coloring = Samplers.constant(0.5);
        // anything over the snow line is 'snow'... no matter what
        final double snowLine = 500;       
        coloring = new AbstractSampler(0, 1) {
                public double getSample( double x, double y, double z ) {
                
                    double height = y; 
                    if( height > maxElevation ) {
                        maxElevation = height;
                    } else if( height < minElevation ) {
                        minElevation = height;
                    }
                    if( height <= 0 ) {
                        double underWater = Math.min(1, (height-1)/-300);
                        return -underWater;
                    }
                    height = height / snowLine; 
                    
                    double t = 0.5;
                    double baselineHeight = 0.2;
                    double heightEffect = (height - baselineHeight) / (1.0 - baselineHeight);
                    double temperatureAdjust = heightEffect * 0.4;
                    
                    t -= temperatureAdjust;  
                    
                    if( t > maxTemperature ) {
                        maxTemperature = t;
                    }
                    if( t < minTemperature ) {
                        minTemperature = t;
                    }
                    double w = 0.5;
                    double climateAdjust = t - 0.5;
                    double color = w - climateAdjust;
                    if( color < 0 ) return 0;
                    if( color > 1 ) return 1;
                    return color; 
                }
            }; 
        
        layers[0] = Samplers.constant(0);
        layers[1] = Samplers.constant(0);
        layers[2] = Samplers.constant(0);
        layers[3] = Samplers.constant(0);
         
        for( int i = 0; i < layers.length; i++ ) {
            log.info("layers[" + i + "] range:" + layers[i].getRange());
        }     
    }
 
    public void setElevation( Sampler elevation ) {
log.info("setElevation(" + elevation + ")", new Throwable("stack-trace"));    
        this.elevation = elevation;
        version++;
    }
 
    public Sampler getElevation() {
        return elevation;
    }

    public void setEstimatedElevation( Sampler estimated ) {
        this.estimated = estimated;
        version++;
    }
 
    public Sampler getEstimatedElevation() {
        return estimated;
    }

    public void setColoring( Sampler coloring ) {
        this.coloring = coloring;
        version++;
    }

    public Sampler getColoring() {
        return coloring;
    }
    
    public void setLayer( int layer, Sampler sampler ) {
        layers[layer] = sampler;
        version++;
    }
    
    public Sampler[] getLayers() {
        return layers;
    }
 
    public Vec3d findSpawn() {
        //return findSpawn(1015808, 1015808, 32768);
        return findSpawn(1015808 - 1000000, 1015808 - 1000000, 32768);  
    }
        
    public Vec3d findSpawn( double xStart, double zStart, double radius ) {
 
        MapperConfig config = MapperConfig.getInstance();        
        if( config.getStartupSetting("spawn.x", null) != null 
            && config.getStartupSetting("spawn.z", null) != null ) {  
            long cx = config.getStartupSettingLong("spawn.x", 0);
            long cz = config.getStartupSettingLong("spawn.z", 0);
            double y = estimated.getSample(cx, 0, cz);
            return new Vec3d(cx, y, cz);
        } 
 
        if( false ) {
            double x = 1036647;
            double z = 1039734;
            double y = estimated.getSample(x, 0, z);
            return new Vec3d(x, y, z);
        }

        if( false ) {
            double x = 1023754;
            double z = 1002818;
            double y = estimated.getSample(x, 0, z);
            return new Vec3d(x, y, z);
        }

        if( false ) {
            double x = 1004386;
            double z = 992666;
            double y = estimated.getSample(x, 0, z);
            return new Vec3d(x, y, z);
        }

        if( false ) {
            double x = 1004386 - 1000000;
            double z = 992666 - 1000000;
            double y = estimated.getSample(x, 0, z);
            return new Vec3d(x, y, z);
        }
        
        // Basically find the highest estimated point in the given area    
        Vec3d best = null;
        double max = 0;
        double step = (radius * 2) / 1024;
        for( double x = xStart - radius; x <= xStart + radius; x += step ) {
            for( double z = zStart - radius; z <= zStart + radius; z += step ) {
                double y = estimated.getSample(x, 0, z);
                if( best == null ) {
                    max = y;
                    best = new Vec3d(x, y, z);
                } else if( y > max ) {
                    max = y;
                    best.set(x, y, z);
                }                 
            } 
        } 
    
        return best;
    }

    @Override
    public long getVersion() {
        return version;
    }
    
    @Override
    public MapState getObject() {
        return this;
    }
    
    @Override
    public VersionedReference<MapState> createReference() {
        return new VersionedReference<>(this);
    } 
    
    @Override
    protected void initialize( Application app ) {
        Vec3d start = findSpawn();
        getState(CameraControlState.class).setPosition(start);
    }
    
    @Override
    protected void cleanup( Application app ) {
    }
    
    @Override
    protected void onEnable() {
    }
    
    @Override
    protected void onDisable() {
    }
    
    @Override
    public void update( float tpf ) {
        if( lastMaxElevation != maxElevation || lastMinElevation != minElevation ) {
            lastMaxElevation = maxElevation;
            lastMinElevation = minElevation;
            log.info("Min elevation:" + minElevation + "  Max elevation:" + maxElevation);
        }
        if( lastMaxTemperature != maxTemperature || lastMinTemperature != minTemperature ) {
            lastMaxTemperature = maxTemperature;
            lastMinTemperature = minTemperature;
            log.info("Min temperature:" + minTemperature + "  Max temperature:" + maxTemperature);
        }
    }
}
