/*
 * $Id$
 * 
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mapper;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.BiConsumer;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.asset.TextureKey;
import com.jme3.bounding.BoundingBox;
import com.jme3.material.*;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.*;
import com.jme3.scene.Spatial.CullHint;
import com.jme3.scene.shape.*;
import com.jme3.texture.*;
import com.jme3.texture.image.ColorSpace;
import com.jme3.util.*;

import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedReference;

import com.simsilica.mathd.*;
import com.simsilica.thread.*;

import com.simsilica.fractal.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MapViewState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(MapViewState.class);

    private Node viewRoot;

    private VersionedReference<Vec3d> posRef;

    private MapSettings settings = new MapSettings();
    private TileGrid[] grids;
    private double[] gridZoomLevels;
    private Node[] gridNodes; // because we cheat and use offsets instead of masking
     
    private VersionedReference<Double> zoomRef;
    private Sampler elevation;
    private Sampler coloring;
    private Sampler[] layers;
 
    private VersionedHolder<Double> viewOffset = new VersionedHolder<>();
    
    private int maxTileSize = 32768;

    private TileBuilder tileBuilder;
    private TileMesh tileMesh;
    
    private TimeLogger timeLogger = new TimeLogger();

    public MapViewState() {        
    }
 
    public VersionedReference<Double> createViewOffsetRef() {
        return viewOffset.createReference();
    }
 
    public TileBuilder getTileBuilder() {
        return tileBuilder;
    }
 
    public JobState getJobState() {
        return getState(JobState.class);
    }
 
    protected Node getRoot() {
        return ((Main)getApplication()).getRootNode();
    }
    
    protected Texture loadGradient( String name ) {
        TextureKey key = new TextureKey(name);
        key.setGenerateMips(false); 
        return getApplication().getAssetManager().loadTexture(key);
    }
    
    @Override
    protected void initialize( Application app ) {
 
        this.posRef = getState(CameraControlState.class).createPosRef();
        this.zoomRef = getState(CameraControlState.class).createZoomRef();

        this.elevation = getState(MapState.class).getElevation();
        this.coloring = getState(MapState.class).getColoring();
        this.layers = getState(MapState.class).getLayers();  
        this.tileMesh = new TileMesh(settings.getTileMeshSize(), settings.getTileImageSize()); 
        this.tileBuilder = new TileBuilder(elevation, coloring, layers, tileMesh, timeLogger);

        MapLayer[] mapLayers = new MapLayer[] {
                new MapLayer(0.0, "Textures/temperature.png"),
                new MapLayer(0.0, "Textures/moisture.png"),
                new MapLayer(0.5, "Textures/vegetation.png"),
                new MapLayer(0.0, null)
            };
        settings.setMapLayers(mapLayers);

        // The 1024 sized mesh will be 'natural sized' when it is 
        // at a particular scale and scaled up/down on the other resolutions.
        // So everything will be relative to this master scale.
        double masterScale = settings.getTileMeshSize()/(double)maxTileSize;

        // 1024x592
        Texture texture = app.getAssetManager().loadTexture("Textures/hexagons.png");
        texture.setWrap(Texture.WrapMode.Repeat);
        int hexImageWidth = 1024;
        int hexImageHeight = 592;
        Vec3i hexSize = new Vec3i(hexImageWidth, hexImageHeight, 0);
        
        tileMesh.getMesh().setBound(new BoundingBox(new Vector3f(0, -32767, 0), 
                                    new Vector3f(settings.getTileMeshSize(), (float)(32767 * masterScale), settings.getTileMeshSize())));

        Material tileMaterial = new Material(app.getAssetManager(), "MatDefs/TerrainTile.j3md");
        tileMaterial.setColor("Diffuse", new ColorRGBA(1f, 1f, 1f, 1));
        tileMaterial.setBoolean("UseMaterialColors", true);
        // model space to texture space is the same for every mesh
        tileMaterial.setFloat("TileScale", tileMesh.getTileScale());
        // In the one mesh per tile use-case, this should be unnecessary
        tileMaterial.setVector2("TileOffset", new Vector2f(0, 0));        
        tileMaterial.setTexture("Overlay", texture);

        Texture gradient = loadGradient(settings.getBaseHighGradient());
        Texture gradient2 = loadGradient(settings.getBaseLowGradient());

        tileMaterial.setTexture("Gradient", gradient);
        
        for( int i = 0; i < mapLayers.length; i++ ) {
            MapLayer mapLayer = mapLayers[i];
            if( mapLayer.getMix() == 0 || mapLayer.getGradient() == null ) {
                continue;
            }
            String s = "Layer" + (i+1);
            tileMaterial.setTexture(s, loadGradient(mapLayer.getGradient()));
            tileMaterial.setFloat(s + "Mix", (float)mapLayer.getMix());
        }
        
        tileMaterial.getAdditionalRenderState().setWireframe(settings.getWireframe());
    
        Material tileMat1 = tileMaterial.clone();
        tileMat1.setTexture("Gradient", gradient2);
        tileMat1.setFloat("UnderwaterNormalBias", 16f);
        Material tileMat2 = tileMaterial.clone();
        //tileMat2.setTexture("Gradient", gradient2);
        tileMat2.setFloat("UnderwaterNormalBias", 8f);
        Material tileMat3 = tileMaterial.clone();
        tileMat3.setFloat("UnderwaterNormalBias", 4f);
        Material tileMat4 = tileMaterial.clone();
        tileMat4.setFloat("UnderwaterNormalBias", 2f);
        Material tileMat5 = tileMaterial.clone();
        Material tileMat6 = tileMaterial.clone();
        Material tileMat7 = tileMaterial.clone();

        this.viewRoot = new Node("viewRoot");
        boolean lores = false;
        if( lores ) { 
            grids = new TileGrid[] {
                new TileGrid(this, 8, 65536, settings, tileMesh, tileMat1, hexSize),
                new TileGrid(this, 7, 32768, settings, tileMesh, tileMat2, hexSize),
                new TileGrid(this, 6, 16384, settings, tileMesh, tileMat3, hexSize),
                new TileGrid(this, 5, 8192, settings, tileMesh, tileMat4, hexSize),
                new TileGrid(this, 4, 4096, settings, tileMesh, tileMat5, hexSize),
                new TileGrid(this, 3, 2048, settings, tileMesh, tileMat6, hexSize),
                new TileGrid(this, 2, 1024, settings, tileMesh, tileMat6, hexSize),
                new TileGrid(this, 1, 512, settings, tileMesh, tileMat7, hexSize),
                new TileGrid(this, 0, 256, settings, tileMesh, tileMat7, hexSize)
            };
        
            // Poor man's LOD, just based it on the zoom level
            gridZoomLevels = new double[] {
                1000000, // always
                2000, //1000, 
                1000, //800,
                500, //400,
                250, //200,
                125, //100,
                80, //100,
                40, //10
                20 //10
            };            
        } else {

            grids = new TileGrid[] {
                new TileGrid(this, 8, 65536, settings, tileMesh, tileMat1, hexSize),
                new TileGrid(this, 7, 32768, settings, tileMesh, tileMat2, hexSize),
                new TileGrid(this, 6, 16384, settings, tileMesh, tileMat3, hexSize),
                new TileGrid(this, 5, 8192, settings, tileMesh, tileMat4, hexSize),
                new TileGrid(this, 4, 4096, settings, tileMesh, tileMat5, hexSize),
                new TileGrid(this, 3, 2048, settings, tileMesh, tileMat5, hexSize),
                new TileGrid(this, 2, 1024, settings, tileMesh, tileMat6, hexSize),
                new TileGrid(this, 1, 512, settings, tileMesh, tileMat7, hexSize),
            };
        
            // Poor man's LOD, just based it on the zoom level
            gridZoomLevels = new double[] {
                1000000, // always
                1000, 
                800,
                400,
                200,
                100,
                50,
                25
            };            
        }
        for( int i = 1; i < grids.length; i++ ) {
            grids[i].setParentGrid(grids[i-1]);
        }

        gridNodes = new Node[grids.length];
        int offset = 0;
        for( TileGrid grid : grids ) {
            Node temp = new Node("temp");
            viewRoot.attachChild(temp);
            temp.attachChild(grid.getRoot());
            gridNodes[offset] = temp;
            offset++;
        }
        viewRoot.setLocalScale((float)masterScale);
 
        updateGridPositions();
    }
    
    @Override
    protected void cleanup( Application app ) {
        timeLogger.close();
    }
    
    @Override
    protected void onEnable() {
        getRoot().attachChild(viewRoot);
    }
    
    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }
    
    @Override
    public void update( float tpf ) {
        if( posRef.update() || zoomRef.update() ) {
            updateGridPositions();
        }
    }
 
    public void invalidate() {
        this.elevation = getState(MapState.class).getElevation();
        this.coloring = getState(MapState.class).getColoring();
        this.layers = getState(MapState.class).getLayers();
        tileBuilder.updateSamplers(elevation, coloring, layers);
        for( TileGrid grid : grids ) {
            grid.invalidate();
        }
    }
    
    protected void updateGridPositions() {
        Vec3d pos = posRef.get();
 
        double zoom = zoomRef.get();
        double h = elevation.getSample(pos.x, 0, pos.z);
        
        int index = 0;
        int active = 0;
        for( TileGrid grid : grids ) {
            if( gridZoomLevels[index] > zoom ) {
                grid.updatePosition(pos);
                grid.setVisible(true);
                active++;
            } else {
                // It should be invisible
                grid.setVisible(false);
            }
            
            index++;
        }
        
        viewOffset.updateObject(h);
    }
    
    private class TimeLogger implements BiConsumer<TileKey, Long> {
 
        private String base = "times-" + System.currentTimeMillis();
        
        private Map<Integer, PrintWriter> files = new HashMap<>();
 
        public void close() {
            for( PrintWriter out : files.values() ) {
                out.close();
            }
        }
        
        protected synchronized PrintWriter getFile( Integer tileSize )  {
            PrintWriter result = files.get(tileSize);
            if( result == null ) {
                File f = new File(base + "@" + tileSize + ".csv");
                try {
                    result = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"));
                    files.put(tileSize, result);
                } catch( IOException e ) {
                    throw new RuntimeException("Error creating file:" + f, e);
                }
            }
            return result;
        }   
    
        public void accept( TileKey key, Long time ) {
            log.info(key + ":" + time);
            if( true ) return;
            double ms = time / 1000000.0;
            String s = String.format("%.03f", ms);
            getFile(key.getTileSize()).println(s);
        }
    }
}
