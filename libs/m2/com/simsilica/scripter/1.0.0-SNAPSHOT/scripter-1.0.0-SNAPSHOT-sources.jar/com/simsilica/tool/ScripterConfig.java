/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;
import com.google.gson.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ScripterConfig {
    static Logger log = LoggerFactory.getLogger(ScripterConfig.class);

    public static final String CONFIG_FILE = "scripter.config";
    public static final String DEFAULT_PROJECT_DIR = ".";
    public static final String DEFAULT_SCRIPT_DIR = "scripts";
    public static final String DEFAULT_MODS_DIR = "mods";

    private String projectDir;
    private String scriptDir;
    private String modsDir;

    private static String configFile = CONFIG_FILE;
    private static ScripterConfig instance;

    public ScripterConfig() {
    }

    protected void initializeDefaults() {
        projectDir = DEFAULT_PROJECT_DIR;
        scriptDir = DEFAULT_SCRIPT_DIR;
        modsDir = DEFAULT_MODS_DIR;
    }

    protected boolean upgrade() {
        boolean changed = false;
        if( modsDir == null ) {
            modsDir = DEFAULT_MODS_DIR;
            changed = true;
        }
        return changed;
    }

    public File getProjectDir() {
        File result = new File(projectDir);
        if( !result.exists() ) {
            result.mkdirs();
        }
        return result;
    }

    public File getScriptsDir() {
        File result = new File(projectDir, scriptDir);
        if( !result.exists() ) {
            result.mkdirs();
        }
        return result;
    }

    public File getModsDir() {
        File result = new File(projectDir, modsDir);
        if( !result.exists() ) {
            result.mkdirs();
        }
        return result;
    }

    public File getFile( String name ) {
        return new File(getProjectDir(), name);
    }

    public static ScripterConfig getInstance() {
        if( instance == null ) {
            try {
                File f = new File(configFile);
                if( f.exists() ) {
                    instance = load(f);
                    if( instance.upgrade() ) {
                        store(instance, f);
                    }
                }
            } catch( Exception e ) {
                log.error("Error loading config file.  Initializing defaults", e);
            }
        }
        if( instance == null ) {
            instance = new ScripterConfig();
            instance.initializeDefaults();
            File f = new File(configFile);
            if( !f.exists() ) {
                store(instance, new File(configFile));
            }
        }
        return instance;
    }

    public static ScripterConfig load( File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            String json = Files.toString(f, Charsets.UTF_8);
            return gson.fromJson(json, ScripterConfig.class);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + f, e);
        }
    }

    public static void store( ScripterConfig config, File f ) {
        GsonBuilder gsonBuilder = new GsonBuilder().setPrettyPrinting();
        Gson gson = gsonBuilder.create();
        try {
            log.info("Storing:" + f);
            String json = gson.toJson(config);
            Files.write(json, f, Charsets.UTF_8);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing:" + f, e);
        }
    }
}

