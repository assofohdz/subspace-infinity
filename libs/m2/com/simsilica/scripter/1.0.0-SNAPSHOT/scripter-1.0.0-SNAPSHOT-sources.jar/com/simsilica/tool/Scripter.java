/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.app.*;
import com.jme3.app.state.ScreenshotAppState;
import com.jme3.math.*;
import com.jme3.material.Material;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.system.AppSettings;
import com.jme3.texture.Texture;

import com.simsilica.event.EventBus;
import com.simsilica.input.*;
import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.OptionPanelState;
import com.simsilica.lemur.anim.AnimationState;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.BaseStyles;
import com.simsilica.state.*;
import com.simsilica.util.LogAdapter;


import com.simsilica.fx.LightingState;
import com.simsilica.fx.sky.SkyState;
import com.simsilica.fx.sky.SkySettingsState;
import com.simsilica.mathd.*;

import com.simsilica.tool.*;


/**
 *  A tool that basically just provides a runtime environment for
 *  groovy to make it easier to do one-off testing of various
 *  things.  Basically the auto-loading script support from mapper
 *  but with a separate environment... maybe with some blockworld
 *  specific stuff setup for us.
 *
 *  @author    Paul Speed
 */
public class Scripter extends SimpleApplication {
    static Logger log = LoggerFactory.getLogger(Scripter.class);

    public static void main( String... args ) throws Exception {

        // Make sure JUL logging goes to our log4j configuration
        LogAdapter.initialize();

        Scripter main = new Scripter(args);

        AppSettings settings = new AppSettings(true);

        // Set some defaults that will get overwritten if
        // there were previously saved settings from the last time the user
        // ran.
        settings.setWidth(1280);
        settings.setHeight(720);
        settings.setVSync(true);

        settings.load("Scripter");
        settings.setTitle("Scripter");
        settings.setUseJoysticks(true);

        main.setSettings(settings);

        main.start();
    }

    public Scripter( String... args ) {
        super(new StatsAppState(), new DebugKeysAppState(), new BasicProfilerState(false),
              new OptionPanelState(), // from Lemur
              new DebugHudState(), // SiO2 utility class
              new MemoryDebugState(),
              new CameraState(),
              new GridState(),
              new MainMenuState("Scripter", false),
              new ToolState(),
              new MovementState(),
              new LightingState(),
              new SkyState(new ColorRGBA(0.3f, 0.5f, 0.1f, 1), true),
              new SkySettingsState(),
              new PostProcessingState(),
              new SettingsState(),
              new MessageState(),
              new CommandConsoleState(),
              new ScriptState(),
              new ModManagerState(),
              new ScreenshotAppState("", System.currentTimeMillis()));
    }

    public void simpleInitApp() {

        setPauseOnLostFocus(false);
        setDisplayFps(false);
        setDisplayStatView(false);

        GuiGlobals.initialize(this);

        GuiGlobals globals = GuiGlobals.getInstance();
        BaseStyles.loadGlassStyle();
        globals.getStyles().setDefaultStyle("glass");

        InputMapper inputMapper = globals.getInputMapper();
        stateManager.getState(MovementState.class).setEnabled(true);
        MainMenuState.initializeDefaultMappings(inputMapper);
        //SettingsState.initializeDefaultMappings(inputMapper);

        globals.setCursorEventsEnabled(false);
        getInputManager().setCursorVisible(false);

        SkyState sky = stateManager.getState(SkyState.class);
        sky.getGroundColor().set(0.3f, 0.5f, 0.1f, 1);

        // Set the time of day
        LightingState lighting = stateManager.getState(LightingState.class);
        lighting.setSunColor(ColorRGBA.White.clone());
        lighting.setAmbient(ColorRGBA.White.clone());

        //cam.setLocation(new Vector3f(-0.0062390394f, 4.1946564f, 9.266036f));
        //cam.setRotation(new Quaternion(-9.990217E-5f, 0.9788456f, -0.20459962f, -4.77952E-4f));

        cam.setLocation(new Vector3f(-0.005187753f, 0.989732f, 2.5806348f));

        stateManager.getState(MainMenuState.class).connect((b) -> stateManager.getState(MovementState.class).setEnabled(!b));

        enqueue( () -> stateManager.getState(MainMenuState.class).setEnabled(true) );

        // Setup some standard mod manager stuff
        ModManagerState modState = stateManager.getState(ModManagerState.class);
        modState.setModRoot(ScripterConfig.getInstance().getModsDir());
        modState.setGlobalBinding("config", ScripterConfig.getInstance());
        modState.setGlobalBinding("gui", getGuiNode());
        modState.setGlobalBinding("post", stateManager.getState(PostProcessingState.class));

    }
}


