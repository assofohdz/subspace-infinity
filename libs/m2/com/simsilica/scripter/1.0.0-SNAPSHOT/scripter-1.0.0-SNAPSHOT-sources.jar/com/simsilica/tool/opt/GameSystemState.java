/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.tool.opt;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

import com.simsilica.sim.*;


/**
 *  An optional GameSystemManager wrapping app state that scripter applications
 *  can attach if they need it.  It comes with some basic GUI controls that can
 *  be enabled.
 *  This is setup to start/stop the systems when the state is attached.
 *  setEnabled(false) will just pause the systems.
 *
 *  @author    Paul Speed
 */
public class GameSystemState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(GameSystemState.class);

    private static final long IDEAL_FRAME_NANOS = 1000000000L / 60L;

    private GameSystemManager systems = new GameSystemManager();
    private boolean paused;

    public GameSystemState() {
    }

    public <T> T get( Class<T> type ) {
        return get(type, false);
    }

    public <T> T get( Class<T> type, boolean failOnMiss ) {
        return systems.get(type, failOnMiss);
    }

    public GameSystemManager getGameSystems() {
        return systems;
    }

    public void setPaused( boolean paused ) {
        if( this.paused == paused ) {
            return;
        }
        this.paused = paused;
        if( !paused ) {
            rebaseTime(0);
        }
    }

    public boolean isPaused() {
        return paused;
    }

    public void singleStep() {
        if( !paused ) {
            return;
        }
        rebaseTime(IDEAL_FRAME_NANOS);
        systems.update();
    }

    protected void rebaseTime( long frameTime ) {
        // Note: the physics engine is using a fixed tpf so this really doesn't
        // matter... but I also feel better letting all of the systems have accurate
        // tpf even when single-stepping.
        long nanos = System.nanoTime();
        long back = nanos - frameTime;
        SimTime time = systems.getStepTime();
        if( back < time.getTime() ) {
            back = time.getTime();
        }
        time.update(back);
        time.update(nanos);
    }

    @Override
    protected void initialize( Application app ) {
        log.info("initialize()");

        log.info("initializing game systems.");
        systems.initialize();

        log.info("starting game systems.");
        systems.start();
    }

    @Override
    protected void cleanup( Application app ) {
        log.info("cleanup()");
        log.info("stopping game systems.");
        systems.stop();
        log.info("terminating game systems.");
        systems.terminate();
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void update( float tpf ) {
        if( paused ) {
            return;
        }
        //log.info("update");
        systems.update();
    }
}

