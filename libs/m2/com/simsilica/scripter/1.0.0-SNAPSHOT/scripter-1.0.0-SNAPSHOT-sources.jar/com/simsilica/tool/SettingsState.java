/*
 * $Id$
 *
 * Copyright (c) 2016, Simsilica, LLC
 * All rights reserved.
 */

package com.simsilica.tool;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.input.KeyInput;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.BorderLayout;
import com.simsilica.lemur.input.FunctionId;
import com.simsilica.lemur.input.InputMapper;
import com.simsilica.lemur.style.ElementId;

import com.simsilica.fx.sky.SkySettingsState;

import com.simsilica.input.MovementState;

/**
 *
 *
 *  @author    Paul Speed
 */
public class SettingsState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(SettingsState.class);

    public SettingsState() {
        //setEnabled(false);
    }

    @Override
    protected void initialize( Application app ) {
        MainMenuState tabs = getState(MainMenuState.class);
        SkySettingsState skySettings = getState(SkySettingsState.class);
        tabs.addTab("Sky", skySettings.getSettings());

        PostProcessingState postProc = getState(PostProcessingState.class);
        tabs.addTab("Post", postProc.getSettings());
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }
}


