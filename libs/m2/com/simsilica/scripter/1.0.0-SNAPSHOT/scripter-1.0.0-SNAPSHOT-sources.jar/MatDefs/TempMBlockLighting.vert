#import "Common/ShaderLib/GLSLCompat.glsllib"
#import "Common/ShaderLib/Instancing.glsllib"
#import "Common/ShaderLib/Skinning.glsllib"
#import "Common/ShaderLib/Lighting.glsllib"
#import "Common/ShaderLib/MorphAnim.glsllib"

#ifdef VERTEX_LIGHTING
    #import "Common/ShaderLib/BlinnPhongLighting.glsllib"
#endif

// fog - jayfella
#ifdef USE_FOG
varying float fog_distance;
#endif
uniform vec3 g_CameraPosition;

uniform vec4 m_Ambient;
uniform vec4 m_Diffuse;
uniform vec4 m_Specular;
uniform float m_Shininess;

uniform vec4 g_LightColor;
uniform vec4 g_LightPosition;
uniform vec4 g_AmbientLightColor;

varying vec2 texCoord;
#ifdef SEPARATE_TEXCOORD
  varying vec2 texCoord2;
  attribute vec2 inTexCoord2;
#endif

varying vec3 AmbientSum;
varying vec4 DiffuseSum;
varying vec3 SpecularSum;

varying vec4 modelLight;
varying vec3 localLightDir;
uniform float m_LocalLightStrength;
//uniform vec3 g_CameraDirection;

#ifdef HAS_LOCAL_LIGHTING
    uniform vec4 m_LocalLighting;
#endif

attribute vec3 inPosition;
attribute vec2 inTexCoord;
attribute vec3 inNormal;
attribute vec4 inTangent;

varying vec3 lightVec;

#ifdef CARVE_SCALE
flat varying int textureDirection;
varying float textureDepth;
#endif
#ifdef WARP_TYPE
uniform vec3 m_WarpCenter;
#endif

//#ifdef VERTEX_COLOR
  attribute vec4 inColor;
//#endif

#ifdef NORMAL_LOOKUP
    attribute float inSize;
#endif

#ifndef VERTEX_LIGHTING
  //attribute vec4 inTangent;

  #ifndef NORMALMAP
    varying vec3 vNormal;
  #endif
  varying vec3 vViewDir;
  varying vec4 vLightDir;
#else
  varying vec2 vertexLightValues;
  uniform vec4 g_LightDirection;
#endif

#if (defined(PARALLAXMAP) || (defined(NORMALMAP_PARALLAX) && defined(NORMALMAP))) && !defined(VERTEX_LIGHTING)
    varying vec3 vViewDirPrlx;
#endif

#ifdef USE_REFLECTION
    uniform vec3 g_CameraPosition;

    uniform vec3 m_FresnelParams;
    varying vec4 refVec;

    /**
     * Input:
     * attribute inPosition
     * attribute inNormal
     * uniform g_WorldMatrix
     * uniform g_CameraPosition
     *
     * Output:
     * varying refVec
     */
    void computeRef(in vec4 modelSpacePos){
        // vec3 worldPos = (g_WorldMatrix * modelSpacePos).xyz;
        vec3 worldPos = TransformWorld(modelSpacePos).xyz;

        vec3 I = normalize( g_CameraPosition - worldPos  ).xyz;
        // vec3 N = normalize( (g_WorldMatrix * vec4(inNormal, 0.0)).xyz );
        vec3 N = normalize( TransformWorld(vec4(inNormal, 0.0)).xyz );

        refVec.xyz = reflect(I, N);
        refVec.w   = m_FresnelParams.x + m_FresnelParams.y * pow(1.0 + dot(I, N), m_FresnelParams.z);
    }
#endif

void main(){
   vec4 modelSpacePos = vec4(inPosition, 1.0);

    #ifdef NORMAL_LOOKUP
        vec3 normal;
        vec3 tangent;
        float normalIndex = inSize;
        if( normalIndex == 0.0 ) {
            //{0, 0, -1},  // NORTH
            //{ -1, 0, 0 },
            normal = vec3( 0.0, 0.0, -1.0 );
            tangent = vec3( -1.0, 0.0, 0.0 );
        } else if( normalIndex == 1.0 ) {
            //{0, 0, 1}, // SOUTH
            //{ 1, 0, 0 },
            normal = vec3( 0.0, 0.0, 1.0 );
            tangent = vec3( 1.0, 0.0, 0.0 );
        } else if( normalIndex == 2.0 ) {
            //{1, 0, 0},  // EAST
            //{ 0, 0, -1 },
            normal = vec3( 1.0, 0.0, 0.0 );
            tangent = vec3( 0.0, 0.0, -1.0 );
        } else if( normalIndex == 3.0 ) {
            //{-1, 0, 0}, // WEST
            //{ 0, 0, 1 },
            normal = vec3( -1.0, 0.0, 0.0 );
            tangent = vec3( 0.0, 0.0, 1.0 );
        } else if( normalIndex == 4.0 ) {
            //{0, 1, 0},  // UP
            //{ 1, 0, 0 },
            normal = vec3( 0.0, 1.0, 0.0 );
            tangent = vec3( 1.0, 0.0, 0.0 );
        } else if( normalIndex == 5.0 ) {
            //{0, -1, 0}, // DOWN
            //{ 1, 0, 0 },
            normal = vec3( 0.0, -1.0, 0.0 );

            // Tangent is in the same direction as for up
            // because we "flip" in y and not x.
            tangent = vec3( 1.0, 0.0, 0.0 );
        } else {
            normal = vec3( 0.0, 0.0, -1.0 );
            tangent = vec3( -1.0, 0.0, 0.0 );
        }
        //vec3 wvNormal  = normalize(g_NormalMatrix * normal);
        vec3 modelSpaceNorm = normal;
        vec3 modelSpaceTan  = tangent;
    #else
        //vec3 wvNormal  = normalize(g_NormalMatrix * BYTE_TO_UNIT(inNormal));
        //vec3 wvNormal  = normalize(g_NormalMatrix * BYTE_TO_UNIT(inNormal));
        vec3 modelSpaceNorm = inNormal;
        vec3 modelSpaceTan  = inTangent.xyz;
    #endif



   //#ifndef VERTEX_LIGHTING
   //     vec3 modelSpaceTan  = inTangent.xyz;
   //#endif

   #ifdef NUM_MORPH_TARGETS
        #if defined(NORMALMAP) && !defined(VERTEX_LIGHTING)
           Morph_Compute(modelSpacePos, modelSpaceNorm, modelSpaceTan);
        #else
           Morph_Compute(modelSpacePos, modelSpaceNorm);
        #endif
   #endif

   #ifdef NUM_BONES
        #ifndef VERTEX_LIGHTING
        Skinning_Compute(modelSpacePos, modelSpaceNorm, modelSpaceTan);
        #else
        Skinning_Compute(modelSpacePos, modelSpaceNorm);
        #endif
   #endif

   texCoord = inTexCoord;

    vec3 relativePos;
    vec3 localPos;
    #if defined(USE_WARP)
        if( WARP_TYPE == 1 ) {
            // Wrap the model position based on shape and center
            //modelSpacePos.xyz = m_WarpCenter + abs(modelSpacePos.xyz - m_WarpCenter);
            relativePos = modelSpacePos.xyz - m_WarpCenter;

            #ifdef CARVE_SCALE
                // Local pos is for texture mapping and is the 'regular space' local coordinate
                localPos = relativePos - vec3(CARVE_SCALE * 0.5, 0.0, CARVE_SCALE * 0.5);
            #else
                localPos = relativePos;
            #endif
            //float radius = (CARVE_SCALE * 0.5);
            float radius = max(abs(relativePos.x), abs(relativePos.z));
            float dist = length(relativePos.xz);
            if( dist > 0 ) {
                relativePos.xz *= (radius / dist);
            }
        } else if( WARP_TYPE == 2 ) {
            relativePos = modelSpacePos.xyz - m_WarpCenter;

            #ifdef CARVE_SCALE
                // Local pos is for texture mapping and is the 'regular space' local coordinate
                localPos = relativePos - vec3(CARVE_SCALE * 0.5, CARVE_SCALE * 0.5, CARVE_SCALE * 0.5);
            #else
                localPos = relativePos;
            #endif

            float radius = max(abs(relativePos.y), max(abs(relativePos.x), abs(relativePos.z)));
            float dist = length(relativePos);
            if( dist > 0 ) {
                relativePos *= (radius / dist);
            }
        } else {
            relativePos = modelSpacePos.xyz - m_WarpCenter;
            #ifdef CARVE_SCALE
                localPos = relativePos - vec3(CARVE_SCALE * 0.5, 0.0, CARVE_SCALE * 0.5);
            #else
                localPos = relativePos;
            #endif
        }
        modelSpacePos.xyz = m_WarpCenter + relativePos;
    #elif defined(CARVE_SCALE)
        localPos = modelSpacePos.xyz - vec3(CARVE_SCALE * 0.5, 0.0, CARVE_SCALE * 0.5);
    #endif

    #ifdef CARVE_SCALE
        // Characterize the direction of the vertex
        float nx = abs(modelSpaceNorm.x);
        float ny = abs(modelSpaceNorm.y);
        float nz = abs(modelSpaceNorm.z);
        float nxz = max(nx, nz);
        if( ny > nxz ) {
            //texCoord = modelSpacePos.xz / CARVE_SCALE;
            //textureDepth = modelSpacePos.y / CARVE_SCALE;
            texCoord = localPos.xz / CARVE_SCALE;
            textureDepth = localPos.y / CARVE_SCALE;
            textureDirection = 0;
        } else if( nx > nz ) {
            texCoord = localPos.zy / CARVE_SCALE;
            textureDepth = localPos.x / CARVE_SCALE;
            textureDirection = 1;
        } else {
            texCoord = localPos.xy / CARVE_SCALE;
            textureDepth = localPos.z / CARVE_SCALE;
            textureDirection = 2;
        }
        //textureDepth = modelSpacePos.y / CARVE_SCALE;
    #endif

   #ifdef SEPARATE_TEXCOORD
      texCoord2 = inTexCoord2;
   #endif

   gl_Position = TransformWorldViewProjection(modelSpacePos);// g_WorldViewProjectionMatrix * modelSpacePos;

   vec3 wvPosition = TransformWorldView(modelSpacePos).xyz;// (g_WorldViewMatrix * modelSpacePos).xyz;
   vec3 wvNormal  = normalize(TransformNormal(modelSpaceNorm));//normalize(g_NormalMatrix * modelSpaceNorm);
   vec3 viewDir = normalize(-wvPosition);

   //// Calculate the local light direction as if our camera was a point light.
   //// ...this still isn't quite right, I think.
   //localLightDir = normalize((g_ViewMatrix * vec4(g_CameraPosition, 1.0)).xyz - wvPosition);

   modelLight = inColor;

   #ifdef HAS_LOCAL_LIGHTING
        // Sunlight should combine directly
        modelLight.a *= m_LocalLighting.a;

        // Local lighting should be the best of one or the other
        modelLight.xyz = max(modelLight.xyz, m_LocalLighting.xyz);
   #endif

   modelLight.xyz *= m_LocalLightStrength;

   vec4 wvLightPos = (g_ViewMatrix * vec4(g_LightPosition.xyz,clamp(g_LightColor.w,0.0,1.0)));
   wvLightPos.w = g_LightPosition.w;
   vec4 lightColor = g_LightColor;

   #if (defined(NORMALMAP) || defined(PARALLAXMAP)) && !defined(VERTEX_LIGHTING)
     vec3 wvTangent = normalize(TransformNormal(modelSpaceTan));
     vec3 wvBinormal = cross(wvNormal, wvTangent);
     mat3 tbnMat = mat3(wvTangent, wvBinormal * inTangent.w,wvNormal);
   #endif

   #if defined(NORMALMAP) && !defined(VERTEX_LIGHTING)
     vViewDir  = -wvPosition * tbnMat;
     #if (defined(PARALLAXMAP) || (defined(NORMALMAP_PARALLAX) && defined(NORMALMAP)))
         vViewDirPrlx = vViewDir;
     #endif
     lightComputeDir(wvPosition, lightColor.w, wvLightPos, vLightDir, lightVec);
     vLightDir.xyz = (vLightDir.xyz * tbnMat).xyz;
   #elif !defined(VERTEX_LIGHTING)
     vNormal = wvNormal;
     vViewDir = viewDir;
     #if defined(PARALLAXMAP)
        vViewDirPrlx  =  -wvPosition * tbnMat;
     #endif
     lightComputeDir(wvPosition, lightColor.w, wvLightPos, vLightDir, lightVec);
   #endif

   float sunLight = modelLight.a;

   //#ifdef MATERIAL_COLORS
   //   AmbientSum  = (m_Ambient  * g_AmbientLightColor * sunLight).rgb;
   //   DiffuseSum  =  m_Diffuse  * vec4(lightColor.rgb * sunLight, 1.0);
   //   SpecularSum = (m_Specular * lightColor).rgb * sunLight;
   // #else
      // Defaults: Ambient and diffuse are white, specular is black.
      AmbientSum  = g_AmbientLightColor.rgb * sunLight;
      DiffuseSum  =  vec4(lightColor.rgb * sunLight, 1.0);
      //SpecularSum = vec3(sunLight); //vec3(0.0);
      #ifdef MATERIAL_COLORS
        // For regular lighting we'll wait to multiply in the material colors
        // until the .frag shader but specular is already calculated differently
        // and will do its own thing for local lighting.
        SpecularSum = (m_Specular * lightColor).rgb * sunLight;
      #else
        // Putting this back to black... specify material colors to get specular.
        SpecularSum = vec3(0.0);
      #endif
   // #endif

    //#ifdef VERTEX_COLOR
    //  AmbientSum *= inColor.rgb;
    //  DiffuseSum *= inColor;
    //#endif

    #ifdef VERTEX_LIGHTING
        float spotFallOff = 1.0;
        vec4 vLightDir;
        lightComputeDir(wvPosition, lightColor.w, wvLightPos, vLightDir, lightVec);
        #if __VERSION__ >= 110
            // allow use of control flow
        if(lightColor.w > 1.0){
        #endif
           spotFallOff = computeSpotFalloff(g_LightDirection, lightVec);
        #if __VERSION__ >= 110
        }
        #endif

        vertexLightValues = computeLighting(wvNormal, viewDir, vLightDir.xyz, vLightDir.w * spotFallOff, m_Shininess);
    #endif

    #ifdef USE_REFLECTION
        computeRef(modelSpacePos);
    #endif

    vec3 wRelative = g_CameraPosition - (TransformWorld(modelSpacePos)).xyz;
    #ifdef USE_FOG
        //fog_distance = distance(g_CameraPosition, (TransformWorld(modelSpacePos)).xyz);
        fog_distance = length(wRelative);
    #endif

    // Calculate the local light direction as if our camera was a point light.
    // ...this still isn't quite right, I think.
    localLightDir = normalize((g_ViewMatrix * vec4(g_CameraPosition, 1.0)).xyz - wvPosition);
    //localLightDir = normalize(wRelative);
    /// We want the light dir in view space not in world space... ie: camera-relative
    // space.
}
