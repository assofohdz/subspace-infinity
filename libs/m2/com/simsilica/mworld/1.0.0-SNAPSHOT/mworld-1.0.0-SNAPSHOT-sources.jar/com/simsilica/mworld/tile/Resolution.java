/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;


/**
 *
 *
 *  @author    Paul Speed
 */
public enum Resolution {

    /**
     *  Image is a 1:1 ratio where 1 image pixel = 1 meter
     */
    High(1024),

    /**
     *  Image is a 1:8 ration where 1 image pixel = 8 meters
     */
    Medium(1024/8),

    /**
     *  Image is a 1:16 ration where 1 image pixel = 16 meters.
     */
    Low(1024/16);

    /**
     *  Number of samples in a layer/tile that represents a 1024
     *  area of the world.
     */
    private int size;

    private Resolution( int size ) {
        this.size = size;
    }

    public static Resolution fromSamples( int samples ) {
        for( Resolution res : values() ) {
            if( res.getSamples() == samples ) {
                return res;
            }
        }
        throw new IllegalArgumentException("Invalid samples:" + samples);
    }

    /**
     *  Returns the number of samples that represent the 1024 tile size.
     *  For example, an 8x (medium) resolution is 128 samples... ie: every
     *  8 'cells' of a 1024 tile.
     */
    public int getSamples() {
        return size;
    }

    /**
     *  Returns true if this Resolution is a lower resolution than the specified
     *  resolution.
     */
    public boolean isLowerThan( Resolution res ) {
        return size < res.size;
    }

    /**
     *  Returns the resolution immediately below this one in quality or null
     *  if this resolution is already the lowest quality.
     */
    public Resolution getLowerResolution() {
        switch( this ) {
            case High:
                return Resolution.Medium;
            case Medium:
                return Resolution.Low;
            case Low:
                return null;
            default:
                throw new UnsupportedOperationException("Unhandled resolution:" + this);
        }
    }

    public Resolution[] affectedResolutions() {
        switch( this ) {
            case High:
                return values();
            case Medium:
                return new Resolution[] { Resolution.Medium, Resolution.Low };
            case Low:
                return new Resolution[] { Resolution.Low };
            default:
                throw new UnsupportedOperationException("Unhandled resolution:" + this);
        }
    }
}


