/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.mworld.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TileBasedColumnGenerator implements Function<ColumnId, ColumnData> {
    static Logger log = LoggerFactory.getLogger(TileBasedColumnGenerator.class);

    private TileManager tiles;
    private int leafCount;
    private TileColumnProcessor[] processors;

    public TileBasedColumnGenerator( TileManager tiles, int leafCount, TileColumnProcessor... processors ) {
        this.tiles = tiles;
        this.leafCount = leafCount;
        this.processors = processors;
    }

    @Override
    public ColumnData apply( ColumnId columnId ) {
        TileId tileId = columnId.getTileId();
        Tile tile = tiles.getTile(tileId, Resolution.High);

        ColumnData result = createEmptyColumnData(columnId);

        boolean changed = false;
        for( TileColumnProcessor proc : processors ) {
            if( proc.apply(result, tile) ) {
                changed = true;
            }
        }

        return result;
    }

    protected ColumnData createEmptyColumnData( ColumnId colId ) {
        return new ColumnData(colId, leafCount);
    }
}



