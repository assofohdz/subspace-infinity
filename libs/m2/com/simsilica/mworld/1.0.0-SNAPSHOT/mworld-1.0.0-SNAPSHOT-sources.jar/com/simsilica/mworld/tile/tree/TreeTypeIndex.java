/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import java.util.*;

import org.slf4j.*;


/**
 *  An index of available tree types.  This primarily provides a consistent
 *  ordering of types such that they can be looked up by index.
 *
 *  @author    Paul Speed
 */
public class TreeTypeIndex implements java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(TreeTypeIndex.class);

    static final long serialVersionUID = 42L;    

    private static TreeTypeIndex instance = new TreeTypeIndex();

    private transient Map<String, TreeType> nameIndex = new HashMap<>();
    private transient List<TreeType> typeList = new ArrayList<>();
    private TreeType[] types;

    private TreeTypeIndex() {
    }

    public static TreeTypeIndex getInstance() {
        // It's convenient for a lot of classes if they don't have to be passed
        // this upon initialization and much like block types, there will be a global
        // one for the world.  So I'm straddling the line between static class like
        // BlockTypeIndex and fully custom instances by using the singleton pattern.
        // Any world-specific initialization could be done against the singleton like
        // we do for BlockTypeIndex's static fields.
        // World clients will only need the atlas info from the tree type so it's
        // possible that we create a simpler tree data structure for returning from
        // world and then only use TreeLayer internally.  At that point, everyone
        // using instances versus static methods means we have limited impact if
        // we choose to go back to fully custom.
        return instance;
    }

    public boolean isInitialized() {
        return types != null;
    }

    protected void checkInitialized( boolean desiredState ) {
        // If the state we desire is the state we have then no issues
        if( desiredState == (types != null) ) {
            return;
        }
        if( types != null ) {
            throw new IllegalStateException("Type list already initialized");
        } else {
            throw new IllegalStateException("Type list not initialized");
        }
    }

    public synchronized void registerType( TreeType type ) {
        checkInitialized(false);
        TreeType existing = nameIndex.get(type.getName());
        if( existing != null ) {
            throw new IllegalArgumentException("Type already exists for name:" + type.getName());
        }
        if( typeList.size() >= Short.MAX_VALUE ) {
            // Someone is abusing this class or misunderstanding how tree
            // types work.
            throw new IllegalStateException("Type list exceeds maximum size:" + Short.MAX_VALUE);
        }
        // Adding this because it was missing... but apparently we never look them
        // up by name?
        nameIndex.put(type.getName(), type);
        
        type.setIndex((short)typeList.size());
log.info("registeredType:" + type + "  at index:" + typeList.size());
        typeList.add(type);
    }

    public synchronized void initialize() {
        log.info("intialize()");
        checkInitialized(false);
        types = typeList.toArray(new TreeType[0]);

        assert types.length != 0 : "Cannot initialize the tree type index with no tree types";
        for( TreeType type : types ) {
            type.initialize(this);
        }

        log.info("initialized with:" + types.length + " types");
    }
    
    public synchronized void initialize( TreeTypeIndex other ) {
        log.info("intialize(other)");
        checkInitialized(false);
        
        // Copy the array directly since we want to keep the
        // regular type.index values and don't want to risk accidentally
        // moving them
        this.types = other.types;        
        
        // Don't do a full register type... just reindex even though
        // we don't really use the name index
        if( other.types != null ) {
            for( TreeType type : other.types ) {
                nameIndex.put(type.getName(), type);
                
                // And just in case, we'll let the tree types reinit
                type.initialize(this);
            }
        }
    }

    public synchronized void terminate() {
        log.info("terminate()");
        this.types = null;
        nameIndex.clear();
        typeList.clear();
        log.info("checking isInitialized():" + isInitialized());
    }

    public TreeType getType( int index ) {
        return getType((short)index);
    }

    public TreeType getType( short index ) {
        checkInitialized(true);
        return types[index];
    }

    public int size() {
        return types != null ? types.length : typeList.size();
    }

    public TreeType[] getTypes() {
        return types;
    }
}


