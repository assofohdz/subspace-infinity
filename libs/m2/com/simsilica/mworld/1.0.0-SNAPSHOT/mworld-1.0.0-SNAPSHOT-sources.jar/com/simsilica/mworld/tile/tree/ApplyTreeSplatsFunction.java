/*
 * $Id$
 *
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import org.slf4j.*;

import com.simsilica.mworld.tile.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ApplyTreeSplatsFunction implements TileFunction {
    static Logger log = LoggerFactory.getLogger(ApplyTreeSplatsFunction.class);

    public ApplyTreeSplatsFunction() {
    }

    @Override
    public void accept( Tile tile ) {
        TreeLayer trees = tile.get(TreeLayer.class);
        //if( trees.getVersion().getLoadVersion() >= 0 ) {
        //    // This is not a new layer
        //    return;
        //}
        // 2024-10-20: Similar comment in ApplyMorphologyFunction from some time back
        // but I'm not sure why I ever thought the above is correct.  We don't care if
        // the tree layer is new... only if the terrain image itself is new.  Found
        // this when implementing the copy logic for regenerating columns from scratch.
        log.info("Splatting trees for tile:" + tile);

        TerrainImage terrain = tile.get(TerrainImageType.Terrain, TerrainImage.class);
        TerrainImage fluid = tile.get(TerrainImageType.Fluid, TerrainImage.class);
        if( terrain.getVersion().getLoadVersion() >= 0 && fluid.getVersion().getLoadVersion() >= 0 ) {
            log.info("terrain was already generated, tile:" + tile.getTileId().getWorld(null) + ", res:" + tile.getResolution());
            return;
        }

        // For now we will only deal with high resolution here... but we could/should
        // do better.
        if( tile.getResolution() != Resolution.High ) {
            return;
        }

        boolean changed = false;
        for( Tree tree : trees.getTrees() ) {
            if( tree.type.insertTree(tree, terrain) ) {
                changed = true;
            }
        }
    }
}


