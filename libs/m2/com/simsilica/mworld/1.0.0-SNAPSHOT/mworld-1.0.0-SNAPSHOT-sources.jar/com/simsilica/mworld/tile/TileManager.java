/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.io.File;
import java.util.*;

import org.slf4j.*;

import com.google.common.base.Function;
import com.google.common.cache.*;
import com.google.common.collect.*;

import com.simsilica.mworld.*;
import com.simsilica.util.CacheTracker;

/**
 *  This may be a temporary class as I work out the coordination
 *  necessary to generate tile images, etc..
 *
 *  @author    Paul Speed
 */
public class TileManager {
    static Logger log = LoggerFactory.getLogger(TileManager.class);

    private File root;
    private boolean initialized;

    private TerrainImageDb terrainImageDb;

    private LoadingCache<TileResolutionId, Tile> cache;

    private ListMultimap<Resolution, TileFunction> tileFunctions = MultimapBuilder.hashKeys().arrayListValues().build();
    private ListMultimap<Resolution, TileFunction> resetFunctions = MultimapBuilder.hashKeys().arrayListValues().build();

    public TileManager( TerrainImageDb terrainImageDb ) {

        // No maximum size because we basically never want objects
        // evicted unless they are no longer referencable.
        this.cache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<TileResolutionId, Tile>() {
                                @Override
                                public void onRemoval( RemovalNotification<TileResolutionId, Tile> notification ) {
                                    if( log.isDebugEnabled() ) {
                                        log.debug("cacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<TileResolutionId, Tile>() {
                                @Override
                                public Tile load( TileResolutionId id ) {
                                    return loadTile(id.getTileId(), id.getResolution());
                                }
                            });
        CacheTracker.track(cache, "TileManager@" + System.identityHashCode(this), true);

        this.terrainImageDb = terrainImageDb;
        addTileFunction(terrainImageDb.getLoadFunction());
        addResetFunction(terrainImageDb.getResetFunction());
    }

    public void addTileFunction( TileFunction... functions ) {
        for( Resolution res : Resolution.values() ) {
            addTileFunction(res, functions);
        }
    }

    public void addTileFunction( Resolution res, TileFunction... functions ) {
        for( TileFunction f : functions ) {
            tileFunctions.put(res, f);
        }
    }

    public <T> T getTileFunction( Resolution res, Class<T> tileFunctionType ) {
        for( TileFunction f : tileFunctions.get(res) ) {
            if( tileFunctionType.isInstance(f) ) {
                return tileFunctionType.cast(f);
            }
        }
        return null;
    }

    /**
     *  Adds a TileFunction that is only used when force-resetting a tile.
     */
    public void addResetFunction( TileFunction... functions ) {
        for( Resolution res : Resolution.values() ) {
            addResetFunction(res, functions);
        }
    }

    public void addResetFunction( Resolution res, TileFunction... functions ) {
        for( TileFunction f : functions ) {
            resetFunctions.put(res, f);
        }
    }

    protected Tile loadTile( TileId id, Resolution res ) {
        Tile result = new Tile(this, id, res);
        for( TileFunction f : tileFunctions.get(res) ) {
            f.accept(result);
        }
        return result;
    }

    /**
     *  Creates a new Tile instance as it was originally generated.
     *  Usually, it is only the runtime modifiable portions that are
     *  generated from scratch and the other elements may be reloaded from
     *  persistence.
     *  Reset tiles (in general) should not be repersisted and should
     *  therefore have their data copied to the original Tile as required
     *  if a real reset is needed.
     */
    public Tile createResetTile( TileId tileId, Resolution res ) {
        Tile result = new Tile(this, tileId, res);
        for( TileFunction f : resetFunctions.get(res) ) {
            log.info("applying reset:" + f);
            f.accept(result);
        }
        for( TileFunction f : tileFunctions.get(res) ) {
            log.info("applying:" + f);
            f.accept(result);
        }
        return result;
    }

    public synchronized void resetColumn( ColumnId colId ) {
        Resolution res = Resolution.High;
        log.info("resetColumn(" + colId + ")");
        TileId tileId = colId.getTileId();
        Tile original = getTile(tileId, res);
        //Tile generated = loadTile(tileId, res);
        Tile generated = new Tile(this, tileId, res);
        for( TileFunction f : tileFunctions.get(res) ) {
            log.info("applying:" + f);
            f.accept(generated);
        }

        // Copy the parts of the tile for the column
        original.setImageData(colId, generated);

        // One of these will be the one that saves the data
        //for( TileFunction f : tileFunctions.get(Resolution.High) ) {
        //    f.accept(result);
        //}
    }

    public void initialize() {
        if( initialized ) {
            throw new IllegalStateException("Already initialized");
        }
        log.info("initialize()");
        terrainImageDb.initialize();
        initialized = true;
    }

    public void terminate() {
        if( !initialized ) {
            throw new IllegalStateException("Not initialized");
        }
        log.info("terminate()");
        terrainImageDb.terminate();
        for( TileFunction f : tileFunctions.values() ) {
            if( f instanceof AutoCloseable ) {
                try {
                    ((AutoCloseable)f).close();
                } catch( Exception e ) {
                    log.error("Error closing:" + f, e);
                }
            }
        }
        initialized = false;
    }

    public Tile getTile( TileId id, Resolution res ) {
        return cache.getUnchecked(new TileResolutionId(id, res));
    }
}

