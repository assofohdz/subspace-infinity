/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;
import com.google.common.base.MoreObjects;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.*;

/**
 *  A leaf-size area of fluid information.
 *
 *  @author    Paul Speed
 */
public class FluidData implements CellData {
    static Logger log = LoggerFactory.getLogger(FluidData.class);

    // For convenience
    private static final int SIZE = LeafId.SIZE;
    private static final int CELL_COUNT = LeafId.CELL_COUNT;

    // Set to true if there is some suspicion that setCell() is
    // letting counts get out of sync.
    private static final boolean SLOW_CHECKS = false;

    private LeafId leafId;
    private CellArray cells;
    private int emptyCellCount;

    public FluidData( LeafId leafId ) {
        this(leafId, null, CELL_COUNT);
    }

    public FluidData( LeafId leafId, CellArray cells, int emptyCellCount ) {
        this.leafId = leafId;
        this.cells = cells;
        this.emptyCellCount = emptyCellCount;
        if( emptyCellCount < 0 ) {
            fixCounts();
        }
        assert checkCounts();
    }

    public final boolean checkCounts() {
        if( cells == null ) {
            if( !isEmpty() ) {
                log.error("No cells but inconsistent counts, empty:" + emptyCellCount);
                return false;
            }
            return true;
        }
        int e = 0;
        for( int val : cells.getArray() ) {
            if( val == 0 ) {
                e++;
            }
        }
        if( e != emptyCellCount ) {
            log.error("Cell count check failed, counted empty:" + e + "  But have empty:" + emptyCellCount);
            return false;
        }
        return true;
    }

    /**
     *  Force fixes the empty cell to match the actual data.  Returns true if the
     *  counts were fixed and false otherwise.
     */
    public final boolean fixCounts() {
        if( cells == null ) {
            if( isEmpty() ) {
                return false;
            }
            emptyCellCount = CELL_COUNT;
            return true;
        }
        int e = 0;
        for( int val : cells.getArray() ) {
            if( val == 0 ) {
                e++;
            }
        }
        if( e != emptyCellCount ) {
            emptyCellCount = e;
            return true;
        }
        return false;
    }

    public LeafId getLeafId() {
        return leafId;
    }

    /**
     *  Returns the number of cells that have no fluid at all.
     */
    public final int getEmptyCellCount() {
        return emptyCellCount;
    }

    /**
     *  Returns true if there is no fluid at all in this leaf.
     */
    public final boolean isEmpty() {
        return emptyCellCount == CELL_COUNT;
    }

    public final boolean containsCell( Vec3i world ) {
        return containsCell(world.x, world.y, world.z);
    }

    public final boolean containsCell( int x, int y, int z ) {
        long id = WorldGrids.LEAF_GRID.worldToId(x, y, z);
        return id == leafId.getId();
    }

    private boolean isValid( int x, int y, int z ) {
        if( x < 0 || y < 0 || z < 0 ) {
            return false;
        }
        if( x >= SIZE || y >= SIZE || z >= SIZE ) {
            return false;
        }
        return true;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            return 0;
        }
        return cells.getCell(x, y, z);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            return 0;
        }
        return cells.getCell(x, y, z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            // This isn't right if the direction takes us outside of the
            // leaf area.  FIXME: detect boundary crossings and return defaultValue.
            return 0;
        }
        return cells.getCell(x, y, z, dir, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";

        // Note: this method is not thread safe.  It assumes that the
        // caller either has exclusive control over the FluidData or
        // that updates are single threaded.  In the cases where there
        // is cross-leaf boundary interaction, it's up to the caller to
        // properly gate that access. (for example, cross column masking.)

        if( cells == null ) {
            if( value == 0 && isEmpty() ) {
                // Nothing to do... it wouldn't change anything
                return;
            }

            // Initialize the cells array
            cells = new CellArray(LeafId.SIZE);
            if( !isEmpty() ) {
                throw new RuntimeException("Invalid state during cell array initialization");
            }

            cells.setCell(x, y, z, value);

            // Cancel out the 'old values' for some new value
            if( isEmpty() ) {
                emptyCellCount--;
            }

            if( SLOW_CHECKS ) {
                assert checkCounts() : "Invalid counts for:" + this + " when setting:" + value + " on new cells";
            }

            // Already set the value.
            return;
        }

        int oldVal = cells.getCell(x, y, z);
        if( oldVal == value ) {
            return;
        }
        cells.setCell(x, y, z, value);

        int oEmpty = emptyCellCount;

        // Adjust the counts from removal of the old value
        if( oldVal == 0 ) {
            emptyCellCount--;
        }
        // Adjust the counts for adding the new value
        if( value == 0 ) {
            emptyCellCount++;
        }

        if( SLOW_CHECKS ) {
            assert checkCounts() : "Invalid counts for:" + this + " when setting:" + value + " over:" + oldVal
                                    + " original empty:" + oEmpty;
        }
    }

    public CellArray getRawCells() {
        return cells;
    }

    public int[] getArray() {
        return cells == null ? null : cells.getArray();
    }

    /**
     *  If the FluidData is fully clear then its cell array reference will be cleared.
     */
    public void compact() {
        if( isEmpty() ) {
            cells = null;
        }
    }

    public void setData( FluidData data ) {
        if( cells == null || data.cells == null ) {
            cells = data.cells;
        } else {
            cells.set(data.cells);
        }
        emptyCellCount = data.emptyCellCount;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("id", leafId)
                .add("emptyCellCount", emptyCellCount)
                .add("cells", cells)
                .toString();
    }
}
