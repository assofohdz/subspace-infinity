/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;


/**
 *  Information about block data that can be grafted directly into
 *  the world by the BlockInsertLayer.
 *
 *  @author    Paul Speed
 */
public class BlockInsert implements Cloneable {
    static Logger log = LoggerFactory.getLogger(BlockInsert.class);

    /**
     *  No special carving, object data is inserted 'as is' and local
     *  empty cells are simply skipped.
     */
    public static final int CARVE_NONE = 0b0;

    /**
     *  Carves out voids below the lowest block in the object.
     */
    public static final int CARVE_BELOW = 0b1;

    /**
     *  Carves out any voids between the highest and lowest blocks.
     *  If there is only one layer of blocks when this will carve
     *  all the way to the top.
     */
    public static final int CARVE_INNER = 0b10;

    /**
     *  Carves out any voids above the highest layer of blocks.
     */
    public static final int CARVE_ABOVE = 0b100;

//    /**
//     *  Object data is inset directly, including local empty cells.
//     */
//    public static final int CARVE_INSET = 0b1;
//
//    /**
//     *  Object data is inset directly using the y=0 layer as a
//     *  cut-out template.
//     */
//    public static final int CARVE_INSCRIBE = 0b10;
//
    /**
     *  Whatever the bottom layer is will be extended down to the next
     *  non-zero block using whatever other carve flags are in effect.
     */
    public static final int CARVE_EXTEND_DOWN = 0b1000;

    /**
     *  Whatever the top layer is will be extended up to the next
     *  zero block using whatever other carve flags are in effect.
     */
    public static final int CARVE_EXTEND_UP = 0b10000;
//
//    /**
//     *  Clears from the top of the inserted data up to the next
//     *  zero block.
//     */
//    public static final int CARVE_VOID_UP = 0b10000;

    public Vec3i world;
    public BlockDataId blockDataId;
    public long objectId;
    public int carveFlags;
    public byte xSize;  // max insert size 127 x 127
    public byte ySize;
    public byte zSize;
    public boolean aboveGround;
    public byte groundLevel;  // same range as ySize

    public BlockInsert( Vec3i world, BlockDataId blockDataId, int carveFlags, int xSize, int ySize, int zSize, long objectId ) {
        this(world, blockDataId, carveFlags, xSize, ySize, zSize, true, ySize, objectId);
    }

    public BlockInsert( Vec3i world, BlockDataId blockDataId, int carveFlags,
                        int xSize, int ySize, int zSize, boolean aboveGround, int groundLevel,
                        long objectId ) {
        this.world = world.clone();
        this.blockDataId = blockDataId;
        this.carveFlags = carveFlags;
        this.xSize = (byte)xSize;
        this.ySize = (byte)ySize;
        this.zSize = (byte)zSize;
        this.aboveGround = aboveGround;
        this.groundLevel = (byte)groundLevel;
        this.objectId = objectId;
        if( this.xSize != xSize ) {
            throw new IllegalArgumentException("Overflow in xSize:" + xSize);
        }
        if( this.ySize != ySize ) {
            throw new IllegalArgumentException("Overflow in ySize:" + ySize);
        }
        if( this.zSize != zSize ) {
            throw new IllegalArgumentException("Overflow in zSize:" + zSize);
        }
    }    

    public BlockInsert clone() {
        try {
            BlockInsert result = (BlockInsert)super.clone();
            result.world = world.clone();
            return result;
        } catch( CloneNotSupportedException e ) {
            throw new RuntimeException("Checked exceptions, hurray", e);
        }
    }
    
    public boolean intersects( BlockInsert other ) {
        // Our max is less than other's min
        if( world.x + xSize < other.world.x ) {
            return false;
        }
        if( world.z + zSize < other.world.z ) {
            return false;
        }
        // Other's max is less than our min
        if( other.world.x + other.xSize < world.x ) {
            return false;
        }
        if( other.world.z + other.zSize < world.z ) {
            return false;
        }
        // both min->max ranges overlap in some way
        return true;
    }
    
    public boolean intersects( TileId tileId ) {
        Vec3i origin = tileId.getWorld(null);
        int xMin = world.x - origin.x;
        int zMin = world.z - origin.z;
        int xMax = xMin + xSize;
        int zMax = zMin + zSize;

        // See if we are even within the tile bounds
        if( xMax < 0 || zMax < 0 ) {
            return false;
        }
        if( xMin >= TileId.SIZE || zMin >= TileId.SIZE ) {
            return false;
        }
        return true;
    }

    public Iterable<Short> getAffectedColumns( TileId tileId ) {

        List<Short> results = new ArrayList<>();

        Vec3i origin = tileId.getWorld(null);

        int xMin = world.x - origin.x;
        int zMin = world.z - origin.z;
        int xMax = xMin + xSize;
        int zMax = zMin + zSize;

        // See if we are even within the tile bounds
        if( xMax < 0 || zMax < 0 ) {
            return results;
        }
        if( xMin >= TileId.SIZE || zMin >= TileId.SIZE ) {
            return results;
        }

        // We intersect the tile somewhere so clamp the bounds
        xMin = Math.max(0, xMin);
        xMax = Math.min(xMax, 1023);
        zMin = Math.max(0, zMin);
        zMax = Math.min(zMax, 1023);

        // Now move it into grid cell space
        Vec3i min = ColumnId.GRID.worldToCell(xMin, 0, zMin);
        Vec3i max = ColumnId.GRID.worldToCell(xMax, 0, zMax);

        for( int x = min.x; x <= max.x; x++ ) {
            for( int z = min.z; z <= max.z; z++ ) {
                short id = ColumnId.toTileLocalIndexId(x, z);
                results.add(id);

                // just double-check our math
                ColumnId colId = ColumnId.fromTileLocalIndex(tileId, x, z);
                if( tileId.getId() != colId.getTileId().getId() ) {
                    // It's in a different tile... but we shouldn't ever
                    // get here if our bounds math is correct.
                    log.warn("Tile mismatch for (" + x + ", " + z + ") tile:" + tileId + "  min:" + min + "  max:" + max);
                    continue;
                }
            }
        }

        return results;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("world", world)
                .add("blockDataId", blockDataId)
                .add("carveFlags", Integer.toBinaryString(carveFlags))
                .add("objectId", objectId)
                .add("xSize", xSize)
                .add("zSize", zSize)
                .toString();

    }
}

/*
BlockInsert {
    Vec3i world;       // where to insert
    BlockDataId data;  // for looking up BlockData
    long objectId;     // parent entity (the whole building)
}

BlockData {  (could even live in mblock)
    CellArray cells;
    CellArray fluid;
    Vec3i[] preserved; (optional)
    int carveFlags;    (optional)
        // for example, carved out basements are different
        // then embedded footers or other solid or nearly solid
        // inserts.
}

BlockDataId {
}

BlockDatabase<BlockDataId, BlockData> {
}

BlockInsertLayer {
}

BlockInsertLayerDb {
}
...etc.
*/
