/*
 * $Id$
 * 
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import com.simsilica.mathd.Vec3i;  

import com.simsilica.mblock.*;  
import com.simsilica.mworld.*;  

/**
 *  A CellData implementation that can lookup neighbor leafs when
 *  necessary to calculate a particular cell's value.  Coordinates
 *  are in 'leaf origin' space.  So 0,0,0 is the leaf's 0,0,0 and
 *  -1,0,0 is the 31,0,0 coordinate in the west neighbor. 
 *
 *  @author    Paul Speed
 */
public class LocalCellData implements CellData {

    private World world;
    private LeafData center;
    private CellArray cells;
    private LeafData[] neighbors = new LeafData[6]; // 6 directions

    public LocalCellData( LeafData center, World world ) {
        this.world = world;
        this.center = center;
        this.cells = center.getRawCells(); 
    }
    
    public LocalCellData( LeafData center, LeafData[] neighbors ) {
        this.neighbors = neighbors; 
        this.center = center;
        this.cells = center.getRawCells(); 
    }
    
    public LeafData[] getNeighbors() {
        return neighbors;
    }
    
    private CellArray getNeighbor( Direction dir ) {
        int ord = dir.ordinal();
        LeafData result = neighbors[ord];
        if( result == null ) {
            LeafId leafId = LeafId.fromWorld(center.getInfo().location);
            result = world.getLeaf(leafId);
        } 
        return result.getRawCells(); 
    }

    public int getCell( int x, int y, int z ) {
        if( x < 0 ) {
            return getNeighbor(Direction.West).getCell(x + cells.getSizeX(), y, z);
        } else if( y < 0 ) {
            return getNeighbor(Direction.Down).getCell(x, y + cells.getSizeY(), z);
        } else if( z < 0 ) {
            return getNeighbor(Direction.North).getCell(x, y, z + cells.getSizeZ());
        } else if( x >= cells.getSizeX() ) {
            return getNeighbor(Direction.East).getCell(x - cells.getSizeX(), y, z); 
        } else if( y >= cells.getSizeY() ) {
            return getNeighbor(Direction.Up).getCell(x, y - cells.getSizeY(), z); 
        } else if( z >= cells.getSizeZ() ) {
            return getNeighbor(Direction.South).getCell(x, y, z - cells.getSizeZ()); 
        }
        return cells.getCell(x, y, z);
    }
        
    public int getCell( int x, int y, int z, int defaultValue ) {
        if( x < 0 ) {
            return getNeighbor(Direction.West).getCell(x + cells.getSizeX(), y, z, defaultValue);
        } else if( y < 0 ) {
            return getNeighbor(Direction.Down).getCell(x, y + cells.getSizeY(), z, defaultValue);
        } else if( z < 0 ) {
            return getNeighbor(Direction.North).getCell(x, y, z + cells.getSizeZ(), defaultValue);
        } else if( x >= cells.getSizeX() ) {
            return getNeighbor(Direction.East).getCell(x - cells.getSizeX(), y, z, defaultValue); 
        } else if( y >= cells.getSizeY() ) {
            return getNeighbor(Direction.Up).getCell(x, y - cells.getSizeY(), z, defaultValue); 
        } else if( z >= cells.getSizeZ() ) {
            return getNeighbor(Direction.South).getCell(x, y, z - cells.getSizeZ(), defaultValue); 
        }
        return cells.getCell(x, y, z, defaultValue);
    }
        
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue); 
    }
        
    public void setCell( int x, int y, int z, int type ) {
        if( x < 0 ) {
            getNeighbor(Direction.West).setCell(x + cells.getSizeX(), y, z, type);
        } else if( y < 0 ) {
            getNeighbor(Direction.Down).setCell(x, y + cells.getSizeY(), z, type);
        } else if( z < 0 ) {
            getNeighbor(Direction.North).setCell(x, y, z + cells.getSizeZ(), type);
        } else if( x >= cells.getSizeX() ) {
            getNeighbor(Direction.East).setCell(x - cells.getSizeX(), y, z, type); 
        } else if( y >= cells.getSizeY() ) {
            getNeighbor(Direction.Up).setCell(x, y - cells.getSizeY(), z, type); 
        } else if( z >= cells.getSizeZ() ) {
            getNeighbor(Direction.South).setCell(x, y, z - cells.getSizeZ(), type); 
        }
        cells.setCell(x, y, z, type);
    }
}
