/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.util.Objects;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mworld.TileId;
import com.simsilica.mworld.SedectileId;

/**
 *  The unique identifier for a particular image which is a combination
 *  of TileId and Resolution.
 *
 *  @author    Paul Speed
 */
public class TerrainImageId {
    static Logger log = LoggerFactory.getLogger(TerrainImageId.class);

    private TileId tileId;
    private TerrainImageType type;
    private Resolution resolution;

    public TerrainImageId( TileId tileId, TerrainImageType type, Resolution resolution ) {
        this.tileId = tileId;
        this.type = type;
        this.resolution = resolution;
    }

    public TileId getTileId() {
        return tileId;
    }

    public TerrainImageType getType() {
        return type;
    }

    public Resolution getResolution() {
        return resolution;
    }

    public SedectileId getParentId() {
        return tileId.getSedectileId();
    }

    /**
     *  Returns the TerrainImageId with a resolution immediately below this one in quality or null
     *  if this ID's resolution is already the lowest quality.
     */
    public TerrainImageId getLowerResolution() {
        Resolution lower = resolution.getLowerResolution();
        return lower == null ? null : new TerrainImageId(tileId, type, lower);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tileId, type, resolution);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        TerrainImageId other = (TerrainImageId)o;
        if( other.resolution != resolution ) {
            return false;
        }
        if( other.type != type ) {
            return false;
        }
        if( tileId.getId() != other.tileId.getId() ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("tileId", tileId)
            .add("type", type)
            .add("resolution", resolution)
            .toString();
    }
}

