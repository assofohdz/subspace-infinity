/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;

/**
 *  A post processor that will calculate the side masks for
 *  a leaf if they have not already been generated.
 *
 *  @author    Paul Speed
 */
public class MaskPostProcessor implements ColumnPostProcessor {
    static Logger log = LoggerFactory.getLogger(MaskPostProcessor.class);

    private PostProcColumnDb parent;
    private ColumnDb delegate;

    @Override
    public void initialize( PostProcColumnDb parent ) {
        this.parent = parent;
        this.delegate = parent.getDelegate();
    }

    @Override
    public void terminate() {
    }

    @Override
    public boolean postProcess( ColumnData col ) {
        //log.info("postProcess(" + col + ")");

        if( col.hasGenerationFlag(ColumnData.GEN_SIDE_MASKS) ) {
            //log.info("already post processed");
            return false;
        }

        if( log.isTraceEnabled() ) {
            log.trace("postProcess(" + col + ")  flags:" + Long.toBinaryString(col.getGenerationFlags()));
        }
        ColumnNeighborhood cellData = new ColumnNeighborhood(delegate, col);

        // Calculate the data for the leafs with actual data in them
        LeafData[] leafs = col.getLeafs();
        int size = LeafInfo.SIZE;
        int zSize = LeafInfo.SIZE;
        for( int i = 0; i < leafs.length; i++ ) {
            LeafData leaf = leafs[i];
            if( leaf == null || leaf.isEmpty() ) {
                continue;
            }

            // Else there is data here so let's recalculate that range
            int k = LeafInfo.SIZE * i;
            int result = MaskUtils.calculateSideMasks(cellData,
                                                      0, k, 0,
                                                      LeafInfo.SIZE, k + LeafInfo.SIZE, LeafInfo.SIZE,
                                                      -1);
        }

        FluidData[] fluids = col.getFluid();
        for( int i = 0; i < fluids.length; i++ ) {
            FluidData fluid = fluids[i];
            if( fluid == null || fluid.isEmpty() ) {
                continue;
            }
            int k = LeafInfo.SIZE * i;
            FluidUtils.calculateSideMasks(cellData.getFluidCellData(), cellData,
                                          0, k, 0,
                                          LeafInfo.SIZE, k + LeafInfo.SIZE, LeafInfo.SIZE);
            FluidUtils.calculateFluidSlopes(cellData.getFluidCellData(), cellData,
                                          0, k, 0,
                                          LeafInfo.SIZE, k + LeafInfo.SIZE, LeafInfo.SIZE);
        }
        col.setGenerationFlag(ColumnData.GEN_SIDE_MASKS);

        return true;
    }
}
