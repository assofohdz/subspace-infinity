/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.transaction.CellEdit;


/**
 *
 *
 *  @author    Paul Speed
 */
public class CellChangeEventProtocol implements ObjectProtocol<CellChangeEvent> {
    private int protocolVersion = 1;

    public CellChangeEventProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }

    @Override
    public void write( CellChangeEvent event, BitOutputStream out ) throws IOException {

        out.writeBits(protocolVersion, 8);

        // ID is all the location information that we need
        out.writeLongBits(event.getLeafId().getId(), 64);

        writeChanges(event.getBlockChanges(), DataType.Block, out);
        writeChanges(event.getLightChanges(), DataType.Light, out);
        writeChanges(event.getFluidChanges(), DataType.Fluid, out);
    }

    @Override
    public CellChangeEvent read( BitInputStream in ) throws IOException {

        // Read the protocol version that was used to store the data
        int version = in.readBits(8);

        // Read the LeafInfo
        LeafId leafId = new LeafId(in.readLongBits(64));

        CellEdit[] blocks = readChanges(DataType.Block, in);
        CellEdit[] lights = readChanges(DataType.Light, in);
        CellEdit[] fluids = readChanges(DataType.Fluid, in);

        return new CellChangeEvent(leafId, blocks, lights, fluids);
    }

    protected void writeChanges( CellEdit[] edits, DataType type, BitOutputStream out ) throws IOException {
        if( edits == null ) {
            out.writeBits(0, 16);
            return;
        }

        out.writeBits(edits.length, 16);

        // Right now no particular compression though we could do better
        // based on type, RLE, etc.  Changes are likely to come in runs.
        for( CellEdit edit : edits ) {
            // locations are leaf-relative so 0..31
            out.writeBits(edit.getX(), 5);
            out.writeBits(edit.getY(), 5);
            out.writeBits(edit.getZ(), 5);
            out.writeBits(edit.getValue(), 32);
            out.writeBits(edit.getOldValue(), 32);
        }
    }

    protected CellEdit[] readChanges( DataType type, BitInputStream in ) throws IOException {
        int size = in.readBits(16);
        if( size == 0 ) {
            return null;
        }
        CellEdit[] edits = new CellEdit[size];
        for( int i = 0; i < size; i++ ) {
            byte x = (byte)in.readBits(5);
            byte y = (byte)in.readBits(5);
            byte z = (byte)in.readBits(5);
            int value = in.readBits(32);
            int oldValue = in.readBits(32);
            edits[i] = new CellEdit(x, y, z, value, oldValue);
        }
        return edits;
    }

}


