/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import java.util.Arrays;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;

/**
 *  For lack of a better name, this is comined cell and fluid data
 *  with some optional carving information that can be used to
 *  construct block models or to insert data into other targets.
 *  Usually loaded by the BlockDb.
 *
 *  @author    Paul Speed
 */
public class BlockData {
    static Logger log = LoggerFactory.getLogger(BlockData.class);

    private CellArray cells;
    private CellArray fluid;
    private Vec3i[] preserved;

    public BlockData( CellArray cells, CellArray fluid, Vec3i... preserved ) {
        this.cells = cells;
        this.fluid = fluid;
        if( preserved != null && preserved.length == 0 ) {
            this.preserved = null;
        } else {
            this.preserved = preserved;
        }
    }

    public CellArray getCells() {
        return cells;
    }

    public CellArray getFluid() {
        return fluid;
    }

    public void setPreserved( Vec3i... preserved ) {
        if( preserved != null && preserved.length == 0 ) {
            this.preserved = null;
        } else {
            this.preserved = preserved;
        }
    }

    public Vec3i[] getPreserved() {
        return preserved;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("cells", cells)
                .add("fluid", fluid)
                .add("preserved", preserved == null ? null : Arrays.asList(preserved))
                .toString();
    }
}

