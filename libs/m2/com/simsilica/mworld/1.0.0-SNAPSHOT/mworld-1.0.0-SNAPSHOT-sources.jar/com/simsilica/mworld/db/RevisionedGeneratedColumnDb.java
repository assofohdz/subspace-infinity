/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

import org.slf4j.*;

import com.simsilica.mworld.ColumnData;
import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.util.RevisionFiles;

/**
 *  Extends GeneratedColumnDb to provide simple world revisions that can
 *  be reverted to previous states.
 *
 *  @author    Paul Speed
 */
public class RevisionedGeneratedColumnDb extends GeneratedColumnDb {
    static Logger log = LoggerFactory.getLogger(RevisionedGeneratedColumnDb.class);

    private final RevisionFiles revisions;
    private Supplier<Long> currentRevision;

    public RevisionedGeneratedColumnDb( Function<ColumnId, ColumnData> generator,
                                        Function<ColumnId, File> fileFunc,
                                        RevisionFiles revisions,
                                        Supplier<Long> currentRevision ) {
        super(generator, fileFunc);
        this.revisions = revisions;
        this.currentRevision = currentRevision;
    }

    public void setCurrentRevision( Supplier<Long> currentRevision ) {
        this.currentRevision = currentRevision;
    }

    public Supplier<Long> getCurrentRevision() {
        return currentRevision;
    }

    public List<Long> getRevisions( ColumnId columnId ) {
        File file = columnToFile(columnId);
        try {
            return revisions.getRevisions(file);
        } catch( IOException e ) {
            throw new RuntimeException("Error retrieving revisions for:" + columnId + " current:" + file, e);
        }
    }

    /**
     *  Recovers the specified column data from before the specified revision mark.
     */
    public boolean recoverColumn( ColumnId columnId, long revision ) {
        log.info("recoverColumn(" + columnId + ", " + revision + ")");

        // Find the backup file from before the specified revision
        File file = columnToFile(columnId);
        File backup = revisions.getRevision(file, revision);
        if( !backup.exists() ) {
            log.warn("Revision:" + revision + " doesn't exist for:" + columnId + " at:" + backup + "  original:" + file);
            return false;
        }

        // Load the original so we can copy the data into it.  Other threads
        // may have a copy of this column data loaded and so we copy the data in directly.
        ColumnData original = getColumn(columnId);
        log.info("original column version:" + original.getVersion());

        synchronized(original) {
            ColumnData reverted = readColumn(backup);
            log.info("recover column version:" + reverted.getVersion());

            // Copy the data over
            original.setData(reverted);

            // Write it back write now
            //markChanged(original);
            writeColumn(file, original);
        }
        return true;
    }

    @Override
    protected void writeColumn( File f, ColumnData col ) {
        long rev = currentRevision.get();
        long current = col.getBranchRevision();
        if( current < rev ) {
            // This column is from before the current branch so we need to potentially back it up.
            if( f.exists() ) {
                File backupFile = revisions.getRevision(f, rev);
                if( backupFile.exists() ) {
                    log.error("Backup file already exists:" + backupFile + " for:" + f + "  baseline:" + rev + " current:" + current, new Throwable("stack-trace"));
                    // But we'll let it stand because there is a case
                    // where if writing the column fails AFTER we've backed it up then we could
                    // leave things in a state of not being able to easily recover.
                } else {
                    try {
                        log.info("Backing up:" + f);
                        // Copy it to the backup for this revision... the state of the column
                        // before the current revision.
                        revisions.backup(f, rev);
                    } catch( IOException e ) {
                        throw new RuntimeException("Error backing up column:" + f, e);
                    }
                }
            } else {
                log.warn("Column with older data has no original:" + f);
            }
        }
        // Make sure the column has the correct revision before writing it
        col.setBranchRevision(rev);
        super.writeColumn(f, col);
    }
}

