/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import java.util.Objects;
import java.util.function.Consumer;

import com.simsilica.mathd.*;

/**
 *  The unique ID of a 32x32x32 area of the world.
 *  The grid definition is such that there can be
 *  +/- 1048576 in all directions.  This is the only thing
 *  that sets a mathemetical upper limit on our world size
 *  as +/- 33,554,432 meters... which is about 160% the size
 *  of the earth at the equator. (I suspect many other game
 *  systems will start to fail or act strange long before the leaf
 *  coordinates wrap around.
 *
 *  @author    Paul Speed
 */
public class LeafId implements GridBasedId {
    public static final int SIZE = WorldGrids.LEAF_SIZE;
    public static final int CELL_COUNT = SIZE * SIZE * SIZE;
    public static final Grid GRID = WorldGrids.LEAF_GRID;

    private long leafId;

    public LeafId( long leafId ) {
        this.leafId = leafId;
    }

    public static LeafId fromWorld( Vec3i world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    public static LeafId fromWorld( Vec3d world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    public static LeafId fromWorld( double x, double y, double z ) {
        long id = GRID.worldToId(x, y, z);
        return new LeafId(id);
    }

    public static LeafId fromWorld( int x, int y, int z ) {
        long id = GRID.worldToId(x, y, z);
        return new LeafId(id);
    }

    @Override
    public long getId() {
        return leafId;
    }

    /**
     *  Returns the world location of this column.
     */
    @Override
    public Vec3i getWorld( Vec3i store ) {
        Vec3i loc = GRID.idToCell(leafId, store);
        loc = GRID.cellToWorld(loc, loc);
        return loc;
    }

    @Override
    public GridCell getGridCell() {
        return getGrid().getContainingCell(getWorld(null));
    }

    public ColumnId getColumnId() {
        Vec3i world = getWorld(null);
        return ColumnId.fromWorld(world);
    }

    @Override
    public Grid getGrid() {
        return GRID;
    }

    @Override
    public Grid getParentGrid() {
        return ColumnId.GRID;
    }

    public void visitNeighbors( int xzRadius, int yRadius, Consumer<LeafId> visitor ) {
        Vec3i origin = getWorld(null);
        for( int x = -xzRadius; x <= xzRadius; x++ ) {
            for( int z = -xzRadius; z <= xzRadius; z++ ) {
                for( int y = -yRadius; y <= yRadius; y++ ) {
                    visitor.accept(fromWorld(origin.x + SIZE * x, origin.y + SIZE * y, origin.z + SIZE * z));
                }
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(leafId);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        LeafId other = (LeafId)o;
        if( other.leafId != leafId ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + leafId + "]";
    }

}


