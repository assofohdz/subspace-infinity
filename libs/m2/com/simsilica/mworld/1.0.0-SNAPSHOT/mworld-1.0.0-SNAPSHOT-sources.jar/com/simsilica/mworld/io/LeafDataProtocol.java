/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class LeafDataProtocol implements ObjectProtocol<LeafData> {
    private int protocolVersion = 1;

    // We use this just for the RLE stuff.
    private CellArrayProtocol cellProtocol = new CellArrayProtocol();

    public LeafDataProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }

    @Override
    public void write( LeafData leafData, BitOutputStream out ) throws IOException {
        // Assumes any necessary protocol version information was already written

        //assert leafData.checkCounts();

        // Even though the version is redundant in our actual use-case,
        // it improves the flexibility of this class and maybe provides a bit
        // of error detection if we go ahead and write it out for every object.
        // It also means that we could technically have different protocol
        // versions per leaf if we ever need it for some dumb reason.
        // I mean, technically the leaf ID is redundant, too.
        // We support up to 256 versions... beyond that the protocol
        // will have to adapt to read another byte.
        out.writeBits(protocolVersion, 8);

        // ID is all the location information that we need
        out.writeLongBits(leafData.getInfo().leafId.getId(), 64);

        // Write the version for now "just in case" but note that nothing
        // real uses this and it should go away... and we can do like for
        // the other "leaf" data objects (LightData, FluidData, etc.) and
        // just write -1 here.  I'm leaving it in case we do end up using
        // the version field later or if there is legacy code that uses it
        // today.  -pspeed:2022-01-10
        out.writeLongBits(leafData.getInfo().version.getVersion(), 64);

        out.writeBits(leafData.getEmptyCellCount(), 16); // 1 bit more than we need, actually.

        int[] array = leafData.getArray();
        if( array == null ) {
            // Write a null marker... and that's it for this leaf
            out.writeBits(0, 1);
            return;
        }
        // Write a not null marker
        out.writeBits(1, 1);

        // Write the block types... we give them the lower 16 bits for now
        cellProtocol.writeRleData(array, 0xffff, 0, 16, out);

        // pspeed:2022-12-31 - note that our actual type bits are 20 now and
        // we might use the upper bits as a sub-type marker at some point.
        // This format will continue to work but it will throw a little extra
        // chaos into the side masks.  At the time we start caring about this
        // then we could use the protocol version to split the mask data
        // out again and start writing the masks separately.  Overall this
        // would probably result in smaller files but can also be done later
        // without breaking existing worlds.
        // FIXME: modify the protocol to split masks out from the high order
        // type bits.

        // Write out the masks.
        cellProtocol.writeRleData(array, 0xffff0000, 16, 16, out);
    }

    @Override
    public LeafData read( BitInputStream in ) throws IOException {

        // Read the protocol version that was used to store the data
        int version = in.readBits(8);

        // Read the LeafInfo
        LeafId leafId = new LeafId(in.readLongBits(64));
        Vec3i world = leafId.getWorld(null);

        long dataVersion = in.readLongBits(64);

        LeafInfo info = new LeafInfo(world, leafId, new DataVersion(dataVersion));

        // Read the cell data
        int emptyCellCount = in.readBits(16);

        int nullBit = in.readBits(1);
        if( nullBit == 0 ) {
            return new LeafData(info, null, emptyCellCount);
        }

        CellArray cells = new CellArray(LeafInfo.SIZE);

        // Read the block types
        cellProtocol.readRleData(cells.getArray(), 0xffff, 0, 16, in);

        // Read the masks.
        cellProtocol.readRleData(cells.getArray(), 0xffff0000, 16, 16, in);

        return new LeafData(info, cells, emptyCellCount);
    }

}


