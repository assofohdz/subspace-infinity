/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.util;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.slf4j.*;


/**
 *  Keeps track of backup revisions for a set of files where
 *  the current files are in $base/some/path/file.ext and the
 *  backup revisions are in $revisionBase/$revision/some/path/file.ext
 *
 *  <p>So in this case, a 'revision' on the disk represents the state
 *  of files BEFORE that revision.
 *
 *  @author    Paul Speed
 */
public class RevisionFiles {
    static Logger log = LoggerFactory.getLogger(RevisionFiles.class);

    private Path base;
    private Path revisionBase;

    public RevisionFiles( File base, File revisionBase ) {
        this.base = base.toPath();
        this.revisionBase = revisionBase.toPath();
    }

    protected String revisionToString( long revision ) {
        return String.valueOf(revision);
    }

    protected long stringToRevision( String revision ) {
        return Long.parseLong(revision);
    }

    public Path getRevision( Path current, long revision ) {
        Path rel = base.relativize(current);
        return revisionBase.resolve(revisionToString(revision)).resolve(rel);
    }

    public File getRevision( File current, long revision ) {
        return getRevision(current.toPath(), revision).toFile();
    }

    public List<Long> getRevisions( File current ) throws IOException {
        Path rel = base.relativize(current.toPath());

        return Files.list(revisionBase)
            .map( (d) -> {
                Path rev = d.resolve(rel);
                if( Files.exists(rev) ) {
                    return (Long)stringToRevision(d.getName(d.getNameCount() - 1).toString());
                }
                return null;
            })
            .filter((d) -> d != null)
            .collect(Collectors.toList());
    }

    public List<File> getBackups( File current ) throws IOException {
        Path rel = base.relativize(current.toPath());

        return Files.list(revisionBase)
            .map( (d) -> {
                Path rev = d.resolve(rel);
                if( Files.exists(rev) ) {
                    return rev.toFile();
                }
                return null;
            })
            .filter((d) -> d != null)
            .collect(Collectors.toList());
    }

    /**
     *  Backs up the specified file to the specified revision, essentially
     *  moving it.  'current' will no longer exist after this call.
     */
    public File backup( File current, long revision ) throws IOException {
        if( !current.exists() ) {
            throw new IllegalArgumentException("File does not exist:" + current);
        }
        Path path = current.toPath();
        Path target = getRevision(path, revision);

        if( !Files.exists(target.getParent()) ) {
            Files.createDirectories(target.getParent());
        }
        Files.move(path, target);
        return target.toFile();
    }
}

