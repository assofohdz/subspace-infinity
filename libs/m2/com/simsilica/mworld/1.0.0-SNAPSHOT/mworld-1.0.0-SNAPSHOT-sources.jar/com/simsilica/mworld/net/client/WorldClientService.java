/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.net.client;

import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.jme3.network.MessageConnection;
import com.jme3.network.service.AbstractClientService;
import com.jme3.network.service.ClientServiceManager;
import com.jme3.network.service.rmi.RmiClientService;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.LeafChangeListenerSupport;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.io.*;
import com.simsilica.mworld.net.WorldDataSession;
import com.simsilica.mworld.net.WorldDataListener;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.PointCloudLayer;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.mworld.tile.tree.TreeTypeIndex;

/**
 *
 *
 *  @author    Paul Speed
 */
public class WorldClientService extends AbstractClientService
                                implements World {

    static Logger log = LoggerFactory.getLogger(WorldClientService.class);

    private RmiClientService rmiService;
    private int channel;
    private WorldDataSession delegate;
    private RemoteWorldData remoteDb;
    private boolean cleanupBlockIndexes;
    private boolean cleanupTreeIndex;

    private WorldSessionCallback sessionCallback = new WorldSessionCallback();


    private List<CellChangeListener> cellListeners = new ArrayList<>();
    private CellChangeListener[] cellListenerArray;
    private CellChangeListener[] emptyCellListenerArray = new CellChangeListener[0];

    private LeafChangeListenerSupport leafListeners = new LeafChangeListenerSupport();

    private CopyOnWriteArrayList<TileListener> tileListeners = new CopyOnWriteArrayList<>();

    /**
     *  Creates a new world service that will use the default reliable
     *  channel for communication.
     */
    public WorldClientService() {
        this(MessageConnection.CHANNEL_DEFAULT_RELIABLE);
    }

    /**
     *  Creates a new world service that will use the specified channel
     *  for any reliable communication.
     */
    public WorldClientService( int channel ) {
        this.channel = channel;
        this.remoteDb = new RemoteWorldData();
    }

    @Override
    public synchronized void addLeafChangeListener( LeafChangeListener l ) {
        leafListeners.add(l);
    }

    @Override
    public synchronized void removeLeafChangeListener( LeafChangeListener l ) {
        leafListeners.remove(l);
    }

    @Override
    public synchronized void addCellChangeListener( CellChangeListener l ) {
        cellListeners.add(l);
        cellListenerArray = null;
    }

    @Override
    public synchronized void removeCellChangeListener( CellChangeListener l ) {
        cellListeners.remove(l);
        cellListenerArray = null;
    }

    protected CellChangeListener[] getCellListenerArray() {
        if( cellListenerArray == null ) {
            cellListenerArray = cellListeners.toArray(emptyCellListenerArray);
        }
        return cellListenerArray;
    }

    @Override
    public void addColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removeColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    public synchronized void addTileListener( TileListener l ) {
        tileListeners.add(l);
    }

    public synchronized void removeTileListener( TileListener l ) {
        tileListeners.remove(l);
    }

    protected synchronized void fireLeafChanged( LeafChangeEvent event ) {
        leafListeners.fireLeafChanged(event);
    }

    protected synchronized void fireCellChanged( CellChangeEvent event ) {
        if( log.isTraceEnabled() ) {
            log.trace("fireCellChanged(" + event + ")");
        }
        for( CellChangeListener l : getCellListenerArray() ) {
            l.cellChanged(event);
        }
    }

    protected synchronized void fireTileChanged( TileChangeEvent event ) {
        for( TileListener l : tileListeners ) {
            l.tileChanged(event);
        }
    }

    @Override
    public int getMaxY() {
        return remoteDb.getMaxY();
    }

    @Override
    public int setWorldCell( Vec3d world, int cellType ) {
        // If we ever support this at all then it should be an optional
        // extension to the protocol.  For many cases, allowing clients
        // direct access to setting world cells is dangerous even if
        // they limit actual edits.  It's a bad way to spam the system
        // and clients will definitely be hacked.
        throw new UnsupportedOperationException();
    }

    /**
     *  Sets cell data only in any locally cached LeafData objects
     *  and can be used in conjunction with other separate server
     *  commands to give the users a preview of changes that might
     *  be coming.
     */
    public boolean setLocalWorldCell( Vec3i world, int cellType ) {
        if( world.y < 0 ) {
            return false;
        }
        Set<LeafId> changes = remoteDb.setLocalWorldCell(world, cellType);
        if( changes == null || changes.isEmpty() ) {
            return false;
        }
        for( LeafId id : changes ) {
            LeafChangeEvent event = new LeafChangeEvent(id, 0, false);
            if( log.isTraceEnabled() ) {
                log.trace("firing local event:" + event);
            }
            synchronized(leafListeners) {
                leafListeners.fireLeafChanged(event);
            }
        }
        return true;
    }

    @Override
    public int getWorldCell( Vec3d world ) {
        if( world.y >= getMaxY() ) {
            return 0;
        }
        if( world.y < 0 ) {
            return -1;
        }
        LeafId id = LeafId.fromWorld(world);
        LeafData leaf = getLeaf(id);
        if( leaf == null ) {
            return -1;
        }
        int x = Coordinates.worldToCell(world.x) - leaf.getInfo().location.x;
        int y = Coordinates.worldToCell(world.y) - leaf.getInfo().location.y;
        int z = Coordinates.worldToCell(world.z) - leaf.getInfo().location.z;
        return leaf.getCell(x, y, z);
    }


    @Override
    public LeafData getWorldLeaf( Vec3d worldLocation ) {
        return getLeaf(LeafId.fromWorld(worldLocation));
    }

    protected boolean threadCheck() {
        if( "jME3 Main".equals(Thread.currentThread().getName()) ) {
            return true;
            //log.warn("Long queries being called from JME update thread", new Throwable("stack trace"));
        }
        return false;
    }

    @Override
    public LeafData getLeaf( LeafId leafId ) {
        if( leafId == null ) {
            return null;
        }
        Vec3i loc = leafId.getWorld(null);
        if( loc.y >= getMaxY() ) {
            return null;
        }
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getLeaf(leafId);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    @Override
    public LightData getLight( LeafId leafId ) {
        if( leafId == null ) {
            return null;
        }
        Vec3i loc = leafId.getWorld(null);
        if( loc.y >= getMaxY() ) {
            return null;
        }
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getLight(leafId);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    @Override
    public FluidData getFluid( LeafId leafId ) {
        if( leafId == null ) {
            return null;
        }
        Vec3i loc = leafId.getWorld(null);
        if( loc.y >= getMaxY() ) {
            return null;
        }
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getFluid(leafId);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    public LeafData getLeafIfPresent( LeafId leafId ) {
        return remoteDb.getLeafIfPresent(leafId);
    }

    public LightData getLightIfPresent( LeafId leafId ) {
        return remoteDb.getLightIfPresent(leafId);
    }

    public FluidData getFluidIfPresent( LeafId leafId ) {
        return remoteDb.getFluidIfPresent(leafId);
    }

    @Override
    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res ) {
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getTerrainImage(id, type, res);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    @Override
    public TreeLayer getTrees( TileId id, Resolution res ) {
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getTrees(id, res);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    @Override
    public PointCloudLayer getPointCloudLayer( TileId id, Resolution res ) {
        boolean check = threadCheck();
        long start = System.nanoTime();
        try {
            return remoteDb.getPointCloudLayer(id, res);
        } finally {
            long end = System.nanoTime();
            if( check && (end - start) > 1000000 ) {
                log.info("Long-style query from JME update thread, took:" + ((end - start)/1000000.0) + " ms", new Throwable("stack trace"));
            }
        }
    }

    @Override
    protected void onInitialize( ClientServiceManager s ) {
        log.debug("onInitialize(" + s + ") channel:" + channel);
        this.rmiService = getService(RmiClientService.class);
        if( rmiService == null ) {
            throw new RuntimeException("WorldClientService requires RMI service");
        }
        log.debug("Sharing session callback.");
        rmiService.share((byte)channel, sessionCallback, WorldDataListener.class);
    }

    /**
     *  Called during connection setup once the server-side services have been initialized
     *  for this connection and any shared objects, etc. should be available.
     */
    @Override
    public void start() {
        log.debug("start()");
        super.start();
        remoteDb.start(getDelegate());

        log.info("TreeTypeIndex are blocks initialized:" + BlockTypeIndex.isInitialized());

        // See if we need to load the block type index
        if( !BlockTypeIndex.isInitialized() ) {
            // Need to initialize them from server data
            log.info("Need to get blocks/fluids types from server.");
            BlockTypeIndex.initialize(remoteDb.getBlockTypeData());
            FluidTypeIndex.initialize(remoteDb.getFluidTypeData());

            // Remember that we need to reset those later
            cleanupBlockIndexes = true;
        }

        // The tree index is not necessarily in sync with the block indexes.
        // It "should" be but they are managed in different areas of the code and it's
        // safer to be sure.
        if( !TreeTypeIndex.getInstance().isInitialized() ) {
            TreeTypeIndex.getInstance().initialize(remoteDb.getTreeTypeIndex());

            // Remember that we need to terminate this later
            cleanupTreeIndex = true;
        }
    }

    @Override
    public void terminate( ClientServiceManager serviceManager ) {
        super.terminate(serviceManager);

        remoteDb.stop();

        if( cleanupBlockIndexes ) {
            // Terminate the local static indexes that we initialized in start
            BlockTypeIndex.reset();
            FluidTypeIndex.reset();
        }
        if( cleanupTreeIndex ) {
            TreeTypeIndex.getInstance().terminate();
        }
    }

    private WorldDataSession getDelegate() {
        // We look up the delegate lazily to make the service more
        // flexible.  This way we don't have to know anything about the
        // connection lifecycle and can simply report an error if the
        // game is doing something screwy.
        if( delegate == null ) {
            // Look it up
            this.delegate = rmiService.getRemoteObject(WorldDataSession.class);
            log.debug("delegate:" + delegate);
            if( delegate == null ) {
                throw new RuntimeException("No chat session found");
            }
        }
        return delegate;
    }

    /**
     *  Shared with the server over RMI so that it can notify us about account
     *  related stuff.
     */
    private class WorldSessionCallback implements WorldDataListener {

        @Override
        public void cellChanged( long leafId, byte[] eventData, boolean zipped ) {
            CellChangeEvent event = remoteDb.cellChanged(leafId, eventData, zipped);
            if( event != null ) {
                if( remoteDb.applyChange(event) ) {
                    fireCellChanged(event);

                    // And that means the leaf changed too... and since we
                    // are normally not passing those on, we'll indicate the change
                    leafListeners.fireLeafChanged(new LeafChangeEvent(new LeafId(leafId), -1, false));
                }
            }
        }

        @Override
        public void leafChanged( long leafId, long leafVersion, boolean reset ) {
            LeafChangeEvent event = new LeafChangeEvent(new LeafId(leafId), leafVersion, reset);
            if( log.isTraceEnabled() ) {
                log.trace("leafChanged(" + event + ")");
            }
            if( event.isReset() ) {
                // Internally asynchronous so that we don't block the
                // channel
                remoteDb.resetLeaf(event.getLeafId(), () -> {
                    leafListeners.fireLeafChanged(event);
                });
            }
        }

        @Override
        public void tileChanged( Class dataType, long tileId, long dataVersion, Resolution res ) {
            TileChangeEvent event = remoteDb.tileChanged(dataType, tileId, dataVersion, res);
            if( event != null ) {
                if( remoteDb.applyChange(event) ) {
                    fireTileChanged(event);
                }
            }
        }

        @Override
        public void partReceived( long requestId, byte part, byte total, byte[] data ) {
            remoteDb.partReceived(requestId, part, total, data);
        }
    }

}


