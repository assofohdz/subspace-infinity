/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.io.*;
import java.util.function.Function;
import java.util.zip.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.tile.Tile;
import com.simsilica.mworld.tile.TileFunction;

/**
 *
 *
 *  @author    Paul Speed
 */
public class InsertLayerDb extends SpoolingObjectDb<TileId, InsertLayer> {
    static Logger log = LoggerFactory.getLogger(InsertLayerDb.class);

    private File root;
    private InsertLayerProtocol protocol;
    private Function<TileId, File> fileFunc;

    public InsertLayerDb( File root, InsertLayerProtocol protocol ) {
        this.root = root;
        this.protocol = protocol;
        this.fileFunc = new ParentIdFileFunction<>(root, "inserts");
    }

    public InsertLayerProtocol getProtocol() {
        return protocol;
    }
    
    @Override   
    public void update( TileId key, InsertLayer value ) {
        // Attempting to fix an issue where generator functions might
        // add the same data to a layer twice because different Tile resolutions
        // happen to be calculating at the same time.  If we kept all tile
        // resolutions together then this wouldn't really be an issue but as
        // it stands a tile with medium resolution might fill a morphology
        // layer and then a tile with high resolution might fill it again because
        // the data hasn't been stored yet so the layer still looks new.
        // So when we store a layer, we will make it look 'unnew'
        DataVersion version = value.getVersion();
        synchronized(version) {
            // We will basically burn two versions with every change because
            // just saving it will increment both loaded and version together.
            // I'm going to limit it to just the first time because that's the
            // case we care about today.  We want to know "is this layer brand
            // new?" and there is (prior to this change) no reliable way to tell.
            if( version.getLoadVersion() == -1 ) {
                // First time saving is a special case
                version.resetChanged(System.currentTimeMillis());
                // Make sure it still looks changed because we haven't
                // actually saved it yet.
                version.markChanged();
            }
        }
        super.update(key, value);
    }

    /**
     *  Creates a Tile function that can load the Tile's morphology layer.
     */
    public TileFunction getLoadFunction() {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    InsertLayer layer = tile.get(InsertLayer.class);
                    if( layer != null ) {
                        throw new IllegalStateException("Tile:" + tile.getTileId() + " already has morphology layer");
                    }
                    layer = get(tile.getTileId());
                    tile.put(InsertLayer.class, layer);
                }
            };
    }

    public TileFunction getSaveFunction() {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    InsertLayer layer = tile.get(InsertLayer.class);
                    if( layer.getVersion().isChanged() ) {
                        log.info("Storing:" + layer);
                        update(layer.getTileId(), layer);
                    }
                }
            };
    }

    protected File toFile( TileId id ) {
        //Vec3i sedectile = id.getSedectileId().getCell(null);
        //String path = sedectile.x + "/" + sedectile.z;
        //File dir = new File(root, path);
        //if( !dir.exists() ) {
        //    dir.mkdirs();
        //}
        //
        //String name = id.getId() + ".inserts";
        //return new File(dir, name);
        return fileFunc.apply(id);
    }

    protected InsertLayer loadObject( TileId id ) {
        File file = toFile(id);
        if( file.exists() ) {
            return readObjectFile(id, file);
        }
        // If we created it then make sure that it looks dirty
        return new InsertLayer(id, new DataVersion(0, -1));
    }

    protected InsertLayer readObjectFile( TileId id, File file ) {
        try( BufferedInputStream in = new BufferedInputStream(new GZIPInputStream(new FileInputStream(file))) ) {
            InsertLayer result = protocol.read(in);
            assert id.equals(result.getTileId());
            return result;
        } catch( IOException e ) {
            throw new RuntimeException("Error reading object:" + id + " from:" + file, e);
        }
    }

    protected void storeObject( TileId id, InsertLayer value ) {
        File file = toFile(id);
        DataVersion version = value.getVersion();
        synchronized(version) {
            writeObjectFile(id, file, value);

            // OLD-FIXME: this DataVersion operation is not thread safe and we
            // may race past some other thread incementing the changed flag.
            // Note: I have made DataVersion synchronized so we can expand
            // a synchronized block.  It's ugly but it should alleviate my
            // fixme concerns above.  Though I admit I have not done a detailed
            // analysis. 2023-05-30 
            version.resetChanged(System.currentTimeMillis());
        }
    }

    protected void writeObjectFile( TileId id, File file, InsertLayer value ) {
        long start = System.nanoTime();
        // FIXME: probably the GZIP part, buffered stream, etc. should be in the
        // protocol in case we ever decide on different compression schemes we could
        // select by protocol version.  Don't need to really worry about it until
        // we want something different.
        try( BufferedOutputStream out = new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(file))) ) {
            protocol.write(value, out);
        } catch( IOException e ) {
            throw new RuntimeException("Error writing object:" + id + " to:" + file, e);
        }
        long end = System.nanoTime();
        log.info("Wrote [" + id + "] in " + ((end - start)/1000000.0) + " ms");
    }
}


