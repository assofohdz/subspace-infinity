/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.Tile;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TreeLayer {
    static Logger log = LoggerFactory.getLogger(TreeLayer.class);

    private static int COLUMN_SIZE = WorldGrids.LEAF_SIZE;

    private TileId tileId;
    private DataVersion version;
    
    // Initial generation may happen in several passes and
    // this lets us still know when the tile requires some generation.
    private byte generationLevel;
    
    private List<Tree> trees;
    private ListMultimap<Short, Tree> binIndex;

    public TreeLayer( TileId tileId, DataVersion version ) {
        this(tileId, version, 0, new ArrayList<>());
    }

    public TreeLayer( TileId tileId, DataVersion version, int generationLevel, List<Tree> trees ) {
        this.tileId = tileId;
        this.version = version;
        this.generationLevel = (byte)generationLevel;
        this.trees = trees;
        this.binIndex = MultimapBuilder.hashKeys().arrayListValues().build();

        for( Tree tree : trees ) {
            indexTree(tree);
        }
    }

    /**
     *  Converts a world-scaled but tile-relative value to a column bin.
     *  Values are always clamped to the range 0..31.
     */
    private int localToBin( int val ) {
        if( val < 0 ) {
            return 0;
        }
        return Math.min(val / COLUMN_SIZE, 31);
    }

    private short toBinId( int x, int z ) {
        // Needs to match ColumnId.getTileLocalIndexId()
        // FIXME: share a method instead of using magic numbers
        return (short)((z << 5) | x);
    }

    public TileId getTileId() {
        return tileId;
    }

    public DataVersion getVersion() {
        return version;
    }

    public void setGenerationLevel( int generationLevel ) {
        if( this.generationLevel > generationLevel ) {
            throw new IllegalArgumentException("Generation level cannot go backwards.");
        }
        this.generationLevel = (byte)generationLevel;
    }

    public int getGenerationLevel() {
        return generationLevel;
    }
    
    public List<Tree> getTrees() {
        return trees;
    }

    public Set<Short> getActiveBinIds() {
        return binIndex.keySet();
    }

    public boolean addTree( Tree tree ) {
        if( !trees.add(tree) ) {
            return false;
        }

//ColumnId colId = ColumnId.fromWorld(tileId.getWorld(null).add(tree.x, 0, tree.z));
//Vec3i tileLocal = colId.getTileLocal(null);
//Vec3i tileLocalIndex = colId.getTileLocalIndex(null);
//log.info("addTree(" + tree + ")  tree column tileLocal:" + tileLocal + "  index:" + tileLocalIndex);
//
//if( tileLocalIndex.x != localToBin(tree.x) ) {
//    throw new RuntimeException("localToBin(x) mismatch:" + tileLocalIndex.x + "  bin:" + localToBin(tree.x));
//}
//if( tileLocalIndex.z != localToBin(tree.z) ) {
//    throw new RuntimeException("localToBin(z) mismatch:" + tileLocalIndex.z + "  bin:" + localToBin(tree.z));
//}
        indexTree(tree);
        return true;
    }
    
    public boolean removeTree( Tree tree ) {
        if( !trees.remove(tree) ) {
            return false;
        }
        unindexTree(tree);
        return true;
    }

    protected void indexTree( Tree tree ) {
        // Index it into the bins
        int xMin = localToBin(tree.x - tree.radius);
        int zMin = localToBin(tree.z - tree.radius);
        int xMax = localToBin(tree.x + tree.radius);
        int zMax = localToBin(tree.z + tree.radius);

//log.info("min:" + xMin + ", " + zMin + "  max:" + xMax + ", " + zMax);

        for( int x = xMin; x <= xMax; x++ ) {
            for( int z = zMin; z <= zMax; z++ ) {
                // If we ever have really odd shaped trees then we
                // may want to ask them but for now we'll assume
                // a bounding box is 'good enough'.
                short binId = toBinId(x, z);
                //log.info("Adding tree:" + tree + "  to binId:" + binId + "  in:" + getTileId());
                binIndex.put(binId, tree);
            }
        }

//if( !getLocalTrees(tree.x, tree.z).contains(tree) ) {
//    throw new RuntimeException("Tree missed its bin:" + tree + "  tileId:" + tileId);
//}
    }

    protected void unindexTree( Tree tree ) {
        // Index it into the bins
        int xMin = localToBin(tree.x - tree.radius);
        int zMin = localToBin(tree.z - tree.radius);
        int xMax = localToBin(tree.x + tree.radius);
        int zMax = localToBin(tree.z + tree.radius);

//log.info("min:" + xMin + ", " + zMin + "  max:" + xMax + ", " + zMax);

        for( int x = xMin; x <= xMax; x++ ) {
            for( int z = zMin; z <= zMax; z++ ) {
                // If we ever have really odd shaped trees then we
                // may want to ask them but for now we'll assume
                // a bounding box is 'good enough'.
                short binId = toBinId(x, z);
                //log.info("Adding tree:" + tree + "  to binId:" + binId + "  in:" + getTileId());
                binIndex.remove(binId, tree);
            }
        }

//if( !getLocalTrees(tree.x, tree.z).contains(tree) ) {
//    throw new RuntimeException("Tree missed its bin:" + tree + "  tileId:" + tileId);
//}
    }

    //public List<Tree> getBinTrees( int x, int z ) {
    //    return binIndex.get(toBinId(x, z));
    //}

    public List<Tree> getTrees( ColumnId colId ) {
        return getTrees(colId.getWorld(null));
    }

    public List<Tree> getTrees( Vec3i world ) {
//log.info("getTrees(" + world + ")");
        Vec3i origin = getTileId().getWorld(null);
//log.info("origin:" + origin + "  relative:" + (world.subtract(origin)));
        int x = (world.x - origin.x) / COLUMN_SIZE;
        int z = (world.z - origin.z) / COLUMN_SIZE;
//log.info("bin:" + x + "," + z);
        if( x < 0 || z < 0 ) {
            throw new IllegalArgumentException("Location:" + world + " not in layer at:" + getTileId());
        }
        if( x >= 32 || z >= 32 ) {
            throw new IllegalArgumentException("Location:" + world + " not in layer at:" + getTileId());
        }
        return getBinTrees(x, z);
    }

    public List<Tree> getLocalTrees( int xLocal, int zLocal ) {
        int x = xLocal / COLUMN_SIZE;
        int z = zLocal / COLUMN_SIZE;
//log.info("bin:" + x + "," + z);
        if( x < 0 || z < 0 ) {
            throw new IllegalArgumentException("Location:" + xLocal + ", " + zLocal + " not in layer at:" + getTileId());
        }
        if( x >= 32 || z >= 32 ) {
            throw new IllegalArgumentException("Location:" + xLocal + ", " + zLocal + " not in layer at:" + getTileId());
        }
        return getBinTrees(x, z);
    }

    protected List<Tree> getBinTrees( int xBin, int zBin ) {
        short binId = toBinId(xBin, zBin);
        List<Tree> result = binIndex.get(binId);
//log.info("binId:" + binId + "  trees:" + result.size());
        return result;
    }

    public boolean apply( ColumnData col, Tile tile ) {
        ColumnId columnId = col.getColumnId();
        List<Tree> local = getTrees(columnId);
        if( local.isEmpty() ) {
            return false;
        }
        Random rand = new Random(columnId.getId()); // consistent random per column
        boolean updated = false;
        TileColumnCells cells = new TileColumnCells(col);
//log.info("Applying:" + local.size() + " trees to:" + col.getColumnId() + "  loc:" + col.getColumnId().getWorld(null));
        for( Tree tree : local ) {
            //log.info("  insert:" + tree + " into:" + col.getColumnId());
            if( tree.type.insertTree(tree, cells, rand) ) {
                updated = true;
            }
        }
        return updated;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[tileId:" + tileId + ", version:" + version + ", size:" + trees.size() + "]";
    }
}


