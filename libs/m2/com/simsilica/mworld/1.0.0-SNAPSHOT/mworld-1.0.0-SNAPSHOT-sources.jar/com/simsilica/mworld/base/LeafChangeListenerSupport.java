/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mworld.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class LeafChangeListenerSupport {
    static Logger log = LoggerFactory.getLogger(LeafChangeListenerSupport.class);

    private List<LeafChangeListener> leafListeners = new ArrayList<>();
    private LeafChangeListener[] leafListenerArray;
    private static LeafChangeListener[] emptyLeafListenerArray = new LeafChangeListener[0];

    public void add( LeafChangeListener l ) {
        synchronized(leafListeners) {
            // Saw an ArrayIndexOutOfBoundsException during this add()
            // which implies that there are some multithreading shenanigans
            // going on.  Since these methods are the only ones that modify
            // the list then hopefully it's just during setup... however,
            // I need to track down what's happening at some point because
            // this should be single-threaded access. -pspeed:2022-12-22
            // FIXME: trace thread usage of this method during startup.
            leafListeners.add(l);
            leafListenerArray = null;
        }
    }

    public void remove( LeafChangeListener l ) {
        synchronized(leafListeners) {
            leafListeners.remove(l);
            leafListenerArray = null;
        }
    }

    protected LeafChangeListener[] getArray() {
        if( leafListenerArray == null ) {
            leafListenerArray = leafListeners.toArray(emptyLeafListenerArray);
        }
        return leafListenerArray;
    }

    public void fireLeafChanged( LeafId leafId, long version, boolean reset ) {
//log.info("fireLeafChanged(" + leafId + ", " + version + ") listeners count:" + leafListeners.size());
        if( leafListeners.isEmpty() ) {
            return;
        }
        LeafChangeEvent event = new LeafChangeEvent(leafId, version, reset);
        fireLeafChanged(event);
    }

    public void fireLeafChanged( LeafChangeEvent event ) {
        for( LeafChangeListener l : getArray() ) {
            l.leafChanged(event);
        }
    }
}

