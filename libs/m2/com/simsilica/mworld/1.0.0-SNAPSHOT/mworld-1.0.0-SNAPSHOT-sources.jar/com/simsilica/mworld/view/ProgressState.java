/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.util.*;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.util.SafeArrayList;

import com.simsilica.lemur.*;
import com.simsilica.lemur.core.*;
import com.simsilica.state.*;

import com.simsilica.progress.ProgressTracker;
import com.simsilica.progress.ProgressTrackers;
import com.simsilica.progress.ProgressTrackers.ThreadTrackers;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ProgressState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(ProgressState.class);

    private Container progressPanel;
    private Map<ProgressTracker, ProgressView> index = new HashMap<>();

    private SafeArrayList<ProgressView> views = new SafeArrayList<>(ProgressView.class);
    private boolean positionInvalid;

    private VersionedReference trackers;

    public ProgressState() {
    }

    @Override
    protected void initialize( Application app ) {
        trackers = ProgressTrackers.createReference();

        progressPanel = new Container(DebugHudState.CONTAINER_ID);

        updateView();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getGuiNode().attachChild(progressPanel);
        positionInvalid = true;
    }

    @Override
    protected void onDisable() {
        progressPanel.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( trackers.update() ) {
            updateView();
        }
        for( ProgressView view : views.getArray() ) {
            view.update();
        }
        if( positionInvalid ) {
            resetPosition();
        }
    }

    protected void resetPosition() {
        Vector3f size = progressPanel.getPreferredSize();

        float width = getApplication().getCamera().getWidth();
        progressPanel.setLocalTranslation(width - size.x, size.y, 100);
        positionInvalid = false;
    }

    protected void addView( ProgressView view ) {
        views.add(view);
        progressPanel.addChild(view.label);
        positionInvalid = true;
    }

    protected void removeView( ProgressView view ) {
        views.remove(view);
        progressPanel.removeChild(view.label);
        positionInvalid = true;
    }

    protected void updateView() {
        for( ThreadTrackers trackers : ProgressTrackers.getThreadTrackers() ) {
            for( ProgressTracker progress : trackers ) {
                ProgressView view = index.get(progress);
                if( view == null ) {
                    // It's a new one
                    view = new ProgressView(progress);
                    index.put(progress, view);
                    addView(view);
                }
            }
        }

        // Remove any of the dead ones
        for( Iterator<Map.Entry<ProgressTracker, ProgressView>> it = index.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<ProgressTracker, ProgressView> e = it.next();
            if( e.getKey().isClosed() ) {
                it.remove();
                removeView(e.getValue());
            }
        }
    }

    protected String progressToString( ProgressTracker progress ) {
        return String.format("%s: %.02f", progress.getName(), progress.getPercent() * 100);
    }

    private class ProgressView {
        private VersionedReference<ProgressTracker> progress;
        private Label label;

        public ProgressView( ProgressTracker progress ) {
            this.progress = progress.createReference();
            this.label = new Label(progressToString(progress), DebugHudState.VALUE_ID);
        }

        public void update() {
            if( progress.update() ) {
                label.setText(progressToString(progress.get()));
            }
        }
    }
}
