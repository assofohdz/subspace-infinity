/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.lang.ref.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mworld.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Tile {
    static Logger log = LoggerFactory.getLogger(Tile.class);

    private TileManager tileManager;
    private TileId id;
    private Resolution resolution;

    private Map<Object, Object> layers = new HashMap<>();

    public Tile( TileManager tileManager, TileId id, Resolution resolution ) {
        this.tileManager = tileManager;
        this.id = id;
        this.resolution = resolution;
    }

    public TileId getTileId() {
        return id;
    }

    public Resolution getResolution() {
        return resolution;
    }

    public void put( Object key, Object layer ) {
        layers.put(key, layer);
    }

    public <T> T get( Class<T> type ) {
        return get(type, type);
    }

    public <T> T get( Object key, Class<T> type ) {
        Object result = layers.get(key);
        return type.cast(result);
    }

    @SuppressWarnings("unchecked")
    public void setImageData( ColumnId colId, Tile from ) {
        log.info("setImageData(" + colId + ", " + from + ")");

        Vec3i start = colId.getTileLocal(null);
        for( Map.Entry<Object, Object> entry : layers.entrySet() ) {
            if( !(entry.getValue() instanceof TileImageData) ) {
                continue;
            }
            TileImageData target = (TileImageData)entry.getValue();
            TileImageData source = (TileImageData)from.layers.get(entry.getKey());
            if( target == source ) {
                log.info("target and source are same instance for:" + entry);
                continue;
            }
            log.info("Copying data from:" + source + " to:" + target);
            target.setData(source, start.x, start.z, ColumnId.SIZE, ColumnId.SIZE);
        }
    }

    @Override
    public String toString() {
        return "Tile[id=" + getTileId() + ", resolution=" + resolution + "]";
    }
}
