/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.net.client;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

import org.slf4j.*;

import com.google.common.cache.*;

import com.simsilica.mathd.*;
import com.simsilica.util.CacheTracker;

import com.simsilica.mblock.*;
import com.simsilica.mblock.io.BlockTypeData;
import com.simsilica.mblock.io.FluidTypeData;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.AbstractWorld;
import com.simsilica.mworld.io.*;
import com.simsilica.mworld.net.WorldDataSession;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.PointCloudLayer;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.mworld.tile.tree.TreeTypeIndex;
import com.simsilica.mworld.transaction.*;

/**
 *  Communicates with the server to provide direct access to world data.
 *
 *  @author    Paul Speed
 */
public class RemoteWorldData extends AbstractWorld {
    static Logger log = LoggerFactory.getLogger(RemoteWorldData.class);

    private WorldDataSession delegate;
    private int yMax;

    // Standardized object buffering where objects larger than
    // 32k can be broken up and sent to be reconstituted on this end.
    // We cheat a little and use the built-in SpiderMonkey RPC/RMI instead of
    // a custom message object.  It shouldn't matter.
    private AtomicLong nextRequestId = new AtomicLong(42); // start at a value to make errors more obvious
    private Map<Long, PacketCollector> packetCollectors = new ConcurrentHashMap<>();
    private ProtocolSerializers protocols = new ProtocolSerializers();

    private LoadingCache<LeafId, LeafData> leafCache;
    private LoadingCache<LeafId, LightData> lightCache;
    private LoadingCache<LeafId, FluidData> fluidCache;

    private LoadingCache<TerrainImageId, TerrainImage> terrainCache;
    private LoadingCache<TileResolutionId, TreeLayer> treeCache;
    private LoadingCache<TileResolutionId, PointCloudLayer> pointCloudCache;

    public RemoteWorldData() {

        // No maximum size because we basically never want objects
        // evicted unless they are no longer referencable.
        this.leafCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<LeafId,LeafData>() {
                                @Override
                                public void onRemoval( RemovalNotification<LeafId,LeafData> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("leafCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<LeafId,LeafData>() {
                                @Override
                                public LeafData load( LeafId key ) {
                                    return loadLeaf(key);
                                }
                            });
        CacheTracker.track(leafCache, "remote:leaf", true);

        this.lightCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<LeafId,LightData>() {
                                @Override
                                public void onRemoval( RemovalNotification<LeafId,LightData> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("lightCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<LeafId,LightData>() {
                                @Override
                                public LightData load( LeafId key ) {
                                    return loadLight(key);
                                }
                            });
        CacheTracker.track(lightCache, "remote:light", true);

        this.fluidCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<LeafId,FluidData>() {
                                @Override
                                public void onRemoval( RemovalNotification<LeafId,FluidData> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("fluidCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<LeafId,FluidData>() {
                                @Override
                                public FluidData load( LeafId key ) {
                                    return loadFluid(key);
                                }
                            });
        CacheTracker.track(fluidCache, "remote:fluid", true);

        this.terrainCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<TerrainImageId, TerrainImage>() {
                                @Override
                                public void onRemoval( RemovalNotification<TerrainImageId, TerrainImage> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("terrainCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<TerrainImageId, TerrainImage>() {
                                @Override
                                public TerrainImage load( TerrainImageId key ) {
                                    return loadTerrainImage(key.getTileId(), key.getType(), key.getResolution());
                                }
                            });
        CacheTracker.track(terrainCache, "remote:terrain", true);

        this.treeCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<TileResolutionId, TreeLayer>() {
                                @Override
                                public void onRemoval( RemovalNotification<TileResolutionId, TreeLayer> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("treeCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<TileResolutionId, TreeLayer>() {
                                @Override
                                public TreeLayer load( TileResolutionId key ) {
                                    return loadTrees(key.getTileId(), key.getResolution());
                                }
                            });
        CacheTracker.track(treeCache, "remote:tree", true);

        this.pointCloudCache = CacheBuilder.newBuilder()
                        .removalListener(new RemovalListener<TileResolutionId, PointCloudLayer>() {
                                @Override
                                public void onRemoval( RemovalNotification<TileResolutionId, PointCloudLayer> notification ) {
                                    if( log.isTraceEnabled() ) {
                                        log.trace("pointCloudCacheRemoval(" + notification + ") reason:" + notification.getCause());
                                    }
                                }
                            })
                        .weakValues()
                        .recordStats()
                        .build(new CacheLoader<TileResolutionId, PointCloudLayer>() {
                                @Override
                                public PointCloudLayer load( TileResolutionId key ) {
                                    return loadPointCloudLayer(key.getTileId(), key.getResolution());
                                }
                            });
        CacheTracker.track(pointCloudCache, "remote:pointCloud", true);

    }

    public void start( WorldDataSession delegate ) {
        if( delegate == null ) {
            throw new IllegalArgumentException("World cannot be started with null WorldDataSession");
        }
        this.delegate = delegate;
    }

    public boolean isRunning() {
        return delegate != null;
    }

    public void stop() {
        this.delegate = null;

        // Dump some debug information if we want to
    }

    @Override
    public int getMaxY() {
        if( yMax == 0 ) {
            if( delegate != null ) {
                yMax = delegate.getMaxY();
            }
        }
        return yMax;
    }

    @Override
    public int setWorldCell( Vec3d world, int cellType ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public LeafData getLeaf( LeafId leafId ) {
        // General logic:
        // -retrieve LeafData from cache.
        // -check if valid
        //   true = return data
        //   false = synch on data
        //  -check validation again
        //  -if still invalid then load data directly
        //  -apply changes to cached data
        return leafCache.getUnchecked(leafId);
    }

    @Override
    public LightData getLight( LeafId leafId ) {
        return lightCache.getUnchecked(leafId);
    }

    @Override
    public FluidData getFluid( LeafId leafId ) {
        return fluidCache.getUnchecked(leafId);
    }

    public LeafData getLeafIfPresent( LeafId leafId ) {
        return leafCache.getIfPresent(leafId);
    }

    public LightData getLightIfPresent( LeafId leafId ) {
        return lightCache.getIfPresent(leafId);
    }

    public FluidData getFluidIfPresent( LeafId leafId ) {
        return fluidCache.getIfPresent(leafId);
    }

    @Override
    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res ) {
        return terrainCache.getUnchecked(new TerrainImageId(id, type, res));
    }

    @Override
    public TreeLayer getTrees( TileId id, Resolution res ) {
        return treeCache.getUnchecked(new TileResolutionId(id, res));
    }

    @Override
    public PointCloudLayer getPointCloudLayer( TileId id, Resolution res ) {
        return pointCloudCache.getUnchecked(new TileResolutionId(id, res));
    }

    /**
     *  Called by WorldClientService when we receive cell change data.
     */
    protected CellChangeEvent cellChanged( long leafId, byte[] data, boolean zipped ) {
        // Maybe see if we even cache this leafId before bothering to create
        // the event.
        try {
            CellChangeEvent event = protocols.fromBytes(CellChangeEvent.class, data, zipped);
            return event;
        } catch( IOException e ) {
            throw new RuntimeException("Error deserializing cell change event data for:" + leafId, e);
        }
    }

    protected TileChangeEvent tileChanged( Class dataType, long tileId, long dataVersion, Resolution res ) {
        // We don't cache any tile data at the moment so there isn't
        // anything special to do
        TileChangeEvent event = new TileChangeEvent(dataType, new TileId(tileId), dataVersion, res);
        return event;
    }

    public Set<LeafId> setLocalWorldCell( Vec3i world, int value ) {
        log.info("setLocalWorldCell(" + world + ", " + value + ")");

        if( world.y == 0 ) {
            log.warn("Cannot remove 'bedrock'");
            return null;
        }

        LeafId leafId = LeafId.fromWorld(world);
        LeafData leaf = leafCache.getIfPresent(leafId);
        if( leaf == null ) {
            // There was nothing loaded yet
            return null;
        }
        Vec3i origin = leafId.getWorld(null);
        Vec3i loc = world.subtract(origin);

        // Is it even a real change
        int existing = MaskUtils.getType(leaf.getCell(loc.x, loc.y, loc.z, value));
        if( existing == value ) {
            // We didn't have to set anything.  No change.
            return null;
        }

        CellDataNeighborhood neighborhood = new CellDataNeighborhood(leaf,
                                                                     new Vec3i(LeafInfo.SIZE, LeafInfo.SIZE, LeafInfo.SIZE),
                                                                     1);
        Set<LeafId> changes = new HashSet<>();
        changes.add(leafId);

        // See if we need to load one of the neighbors to calculate a proper mask.
        // Because of the way masks are calculated when single, we shouldn't need to
        // corners.
        if( loc.x == 0 ) {
            LeafId n = LeafId.fromWorld(origin.subtract(32, 0, 0));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(-1, 0, 0, neighbor);
            changes.add(n);
        }
        if( loc.y == 0 && origin.y >= 32 ) {
            LeafId n = LeafId.fromWorld(origin.subtract(0, 32, 0));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(0, -1, 0, neighbor);
            changes.add(n);
        }
        if( loc.z == 0 ) {
            LeafId n = LeafId.fromWorld(origin.subtract(0, 0, 32));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(0, 0, -1, neighbor);
            changes.add(n);
        }
        if( loc.x == 31 ) {
            LeafId n = LeafId.fromWorld(origin.add(32, 0, 0));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(1, 0, 0, neighbor);
            changes.add(n);
        }
        if( loc.y == 31 && origin.y + 32 <= yMax ) {
            LeafId n = LeafId.fromWorld(origin.add(0, 32, 0));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(0, 1, 0, neighbor);
            changes.add(n);
        }
        if( loc.z == 31 ) {
            LeafId n = LeafId.fromWorld(origin.add(0, 0, 32));
            LeafData neighbor = leafCache.getIfPresent(leafId);
            if( neighbor == null ) {
                // We don't have enough data loaded
                return null;
            }
            neighborhood.setCellData(0, 0, 1, neighbor);
            changes.add(n);
        }

        // Keep from interfering with any cell edits we may receive
        // from the server.  Note: if we ever do more than set blocks here
        // then the locking in applyChange(CellChangeEvent) will have to
        // change, too.
        synchronized(this) {
            neighborhood.setCell(loc.x, loc.y, loc.z, value);
            MaskUtils.recalculateSideMasks(neighborhood, loc.x, loc.y, loc.z, 0);
        }
        return changes;
    }

    protected boolean applyEdits( DataType dataType, CellData cells, CellEdit[] edits ) {
        boolean changed = false;
        for( CellEdit edit : edits ) {
            if( edit.apply(dataType, cells) ) {
                changed = true;
            }
        }
        return changed;
    }

    /**
     *  Applies this cell change to any locally cached leafs.
     */
    protected boolean applyChange( CellChangeEvent event ) {
        if( log.isTraceEnabled() ) {
            log.trace("applyChange(" + event + ")");
            if( event.getBlockChanges() != null ) {
                log.trace("Block changes:" + Arrays.asList(event.getBlockChanges()));
            }
            if( event.getLightChanges() != null ) {
                log.trace("Light changes:" + Arrays.asList(event.getLightChanges()));
            }
            if( event.getFluidChanges() != null ) {
                log.trace("Fluid changes:" + Arrays.asList(event.getFluidChanges()));
            }
        }
        boolean changed = false;

        // We'll keep track of the data lock in order of
        // LeafData, FluidData, LightData.
        // Most things that want to lock the data so it doesn't move will
        // have a LeafData already... however, if our caches already have
        // LightData and FluidData then we'll want to update those as well...
        // even if we don't have a LeafData.

        LeafData blocks = leafCache.getIfPresent(event.getLeafId());
        FluidData fluid = fluidCache.getIfPresent(event.getLeafId());
        LightData lights = lightCache.getIfPresent(event.getLeafId());

        Object lock = blocks;
        if( lock == null ) {
            lock = fluid;
        }
        if( lock == null ) {
            lock = lights;
        }
        if( lock == null ) {
            // We have no data to process... nothing is cached.
            // So we can't know if things have changed or not.
            return true;
        }

        synchronized(lock) {
            // This method will be more straight-forward because it's already
            // assumed that masks have been calculated on the server.
            if( event.getBlockChanges() != null ) {
                if( blocks != null ) {
                    // Lock against local changes from setLocal.  We only
                    // have to lock for block changes because setLocalWorldCell only
                    // changes blocks and does not mess with other types.  If that
                    // ever changes then we'll have to move the synchronized out
                    // to cover the other if blocks.
                    synchronized(this) {
                        if( applyEdits(DataType.Block, blocks, event.getBlockChanges()) ) {
                            if( log.isTraceEnabled() ) {
                                log.trace("cells changed");
                            }
                            changed = true;
                        }
                    }
                } else {
                    // We cannot make the change locally and thus the server
                    // is guaranteed to have better data, ie: we cannot simply
                    // pretend the event didn't happen.  Return true to fire an
                    // event.
                    changed = true;
                }
            }

            if( event.getFluidChanges() != null ) {
                if( fluid != null ) {
                    if( applyEdits(DataType.Fluid, fluid, event.getFluidChanges()) ) {
                        log.trace("fluid changed");
                        changed = true;
                    }
                } else {
                    // We cannot make the change locally and thus the server
                    // is guaranteed to have better data, ie: we cannot simply
                    // pretend the event didn't happen.  Return true to fire an
                    // event.
                    changed = true;
                }
            }

            if( event.getLightChanges() != null ) {
                if( lights != null ) {
                    if( applyEdits(DataType.Light, lights, event.getLightChanges()) ) {
                        log.trace("light changed");
                        changed = true;
                    }
                } else {
                    // We cannot make the change locally and thus the server
                    // is guaranteed to have better data, ie: we cannot simply
                    // pretend the event didn't happen.  Return true to fire an
                    // event.
                    changed = true;
                }
            }
        }
        return changed;
    }

    protected void resetLeaf( LeafId id, Runnable callback ) {
        if( log.isTraceEnabled() ) {
            log.trace("resetLeaf(" + id + ")");
        }
        log.info("resetLeaf(" + id + ")");

        // Regular updates will come as cell updates but if we get a
        // full reset then we need to pull the data over and write it into
        // any existing leaf structures we might have.

        // Check what we have already and what we'll use as the lock when
        // updating leaf data
        LeafData blocks = leafCache.getIfPresent(id);
        FluidData fluid = fluidCache.getIfPresent(id);
        LightData lights = lightCache.getIfPresent(id);

        Object lockCandidate = blocks;
        if( lockCandidate == null ) {
            lockCandidate = fluid;
        }
        if( lockCandidate == null ) {
            lockCandidate = lights;
        }
        if( lockCandidate == null ) {
            // We have no data to process... nothing is cached.
            // So we can't know if things have changed or not.
            return;
        }
        final Object lock = lockCandidate;

        // Keep track of how many results we should expect
        AtomicInteger count = new AtomicInteger(0);
        if( blocks != null ) {
            count.incrementAndGet();
        }
        if( fluid != null ) {
            count.incrementAndGet();
        }
        if( lights != null ) {
            count.incrementAndGet();
        }

        // Probably we could get away with incrementing as we go but if this thread
        // was ever interrupted then we might have a race... so we'll count in one
        // step and request in another

        // Only need to update what is already cached
        // Note: we currently deserialize the objects on the network thread upon
        // which we are notified... we could instead stick these collectors in
        // an updater queue to be applied the next time the caller requests the
        // leaf.  Of course the problem is that most callers already have their leaf
        // data and won't request it again just because we sent and event... so we'd
        // need some 'update' to apply them.  I think deserialization should only
        // minimally hold up networking and leaf resets should be hopefully rare anyway.
        if( blocks != null ) {
            PacketCollector<LeafData> collector = newCollector(LeafData.class);
            collector.onDone((c) -> {
                synchronized(lock) {
                    blocks.setData(collector.getObject());
                    if( count.decrementAndGet() <= 0 ) {
                        callback.run();
                    }
                }
            });
            getDelegate().requestLeafData(collector.requestId, id.getId());
        }
        if( fluid != null ) {
            PacketCollector<FluidData> collector = newCollector(FluidData.class);
            collector.onDone((c) -> {
                synchronized(lock) {
                    fluid.setData(collector.getObject());
                    if( count.decrementAndGet() <= 0 ) {
                        callback.run();
                    }
                }
            });
            getDelegate().requestFluidData(collector.requestId, id.getId());
        }
        if( lights != null ) {
            PacketCollector<LightData> collector = newCollector(LightData.class);
            collector.onDone((c) -> {
                synchronized(lock) {
                    lights.setData(collector.getObject());
                    if( count.decrementAndGet() <= 0 ) {
                        callback.run();
                    }
                }
            });
            getDelegate().requestLightData(collector.requestId, id.getId());
        }

        return;
    }

    protected boolean applyChange( TileChangeEvent event ) {

        // We don't really get any finer grained events than this.  The
        // client can always choose to only refetch far terrain related
        // stuff at intervals to get combinations of changes at once.

        terrainCache.invalidate(new TerrainImageId(event.getTileId(), TerrainImageType.Terrain, event.getResolution()));
        terrainCache.invalidate(new TerrainImageId(event.getTileId(), TerrainImageType.Fluid, event.getResolution()));

        TileResolutionId id = new TileResolutionId(event.getTileId(), event.getResolution());
        treeCache.invalidate(id);
        pointCloudCache.invalidate(id);

        return true;
    }

    protected WorldDataSession getDelegate() {
        if( delegate == null ) {
            throw new IllegalStateException("Not started");
        }
        return delegate;
    }

    /**
     *  Called by WorldClientService when we receive new packet data.
     */
    protected void partReceived( long requestId, byte part, byte total, byte[] data ) {
        if( log.isTraceEnabled() ) {
            log.trace("partReceived(" + requestId + ", " + part + ", " + total + ", " + data + ")");
            log.trace("Received array length:" + (data == null ? "null" : String.valueOf(data.length)));
        }
        PacketCollector collector = packetCollectors.get(requestId);
        if( collector == null ) {
            throw new RuntimeException("No collector found for:" + requestId);
        }
        collector.packetReceived(part, total, data);
    }

    /**
     *  Sets up a new packet collector for receiving responses.  The created
     *  collector will have a new unique request ID and be prepped and ready to
     *  receive data.
     */
    protected <T> PacketCollector<T> newCollector( Class<T> type ) {
        long requestId = nextRequestId.incrementAndGet();
        PacketCollector<T> collector = new PacketCollector<>(requestId, type);
        packetCollectors.put(requestId, collector);
        return collector;
    }

    public BlockTypeData getBlockTypeData() {
        PacketCollector<BlockTypeData> collector = newCollector(BlockTypeData.class);
        getDelegate().requestIndexData(collector.requestId, WorldDataSession.IndexType.BlockType);
        return collector.getObject();
    }

    public FluidTypeData getFluidTypeData() {
        PacketCollector<FluidTypeData> collector = newCollector(FluidTypeData.class);
        getDelegate().requestIndexData(collector.requestId, WorldDataSession.IndexType.FluidType);
        return collector.getObject();
    }

    public TreeTypeIndex getTreeTypeIndex() {
        PacketCollector<TreeTypeIndex> collector = newCollector(TreeTypeIndex.class);
        getDelegate().requestIndexData(collector.requestId, WorldDataSession.IndexType.TreeType);
        return collector.getObject();
    }

    protected LeafData loadLeaf( LeafId leafId ) {
        PacketCollector<LeafData> collector = newCollector(LeafData.class);
        getDelegate().requestLeafData(collector.requestId, leafId.getId());
        return collector.getObject();
    }

    protected LightData loadLight( LeafId leafId ) {
        PacketCollector<LightData> collector = newCollector(LightData.class);
        getDelegate().requestLightData(collector.requestId, leafId.getId());
        return collector.getObject();
    }

    protected FluidData loadFluid( LeafId leafId ) {
        PacketCollector<FluidData> collector = newCollector(FluidData.class);
        getDelegate().requestFluidData(collector.requestId, leafId.getId());
        return collector.getObject();
    }

    protected TerrainImage loadTerrainImage( TileId id, TerrainImageType type, Resolution res ) {
        PacketCollector<TerrainImage> collector = newCollector(TerrainImage.class);
        getDelegate().requestTerrainImage(collector.requestId, id.getId(), type, res);
        return collector.getObject();
    }

    protected TreeLayer loadTrees( TileId id, Resolution res ) {
        PacketCollector<TreeLayer> collector = newCollector(TreeLayer.class);
        getDelegate().requestTrees(collector.requestId, id.getId(), res);
        return collector.getObject();
    }

    protected PointCloudLayer loadPointCloudLayer( TileId id, Resolution res ) {
        PacketCollector<PointCloudLayer> collector = newCollector(PointCloudLayer.class);
        getDelegate().requestPointCloudLayer(collector.requestId, id.getId(), res);
        return collector.getObject();
    }

    private class PacketCollector<T> {
        private long requestId;
        private Class<T> type;
        private byte[][] buffers;
        private int received;
        private int total;
        private T result;
        private Consumer<PacketCollector<T>> callback;

        public PacketCollector( long requestId, Class<T> type ) {
            this.requestId = requestId;
            this.type = type;
        }

        public PacketCollector<T> onDone( Consumer<PacketCollector<T>> callback ) {
            this.callback = callback;
            return this;
        }

        private boolean isDone() {
            return total > 0 && received == total;
        }

        public T getObject() {
            if( result != null ) {
                return result;
            }
            byte[][] array = getData();
            if( array == null ) {
                // Null response
                return null;
            }
            this.result = protocols.fromPackets(type, Arrays.asList(array), true);
            return result;
        }

        protected synchronized byte[][] getData() {
            while( !isDone() ) {
                try {
                    if( log.isTraceEnabled() ) {
                        log.trace("waiting or:" + requestId);
                    }
                    wait();
                } catch( InterruptedException e ) {
                    // I really hate checked exceptions
                    throw new RuntimeException("We were interrupted and there isn't a damn thing we can do about it", e);
                }
            }
            return buffers;
        }

        protected void close() {
            packetCollectors.remove(requestId);
            notifyAll();
            if( callback != null ) {
                callback.accept(this);
            }
        }

        public synchronized void packetReceived( int part, int total, byte[] data ) {
            if( log.isTraceEnabled() ) {
                log.trace("packeteCollector.dataReceived(" + part + ", " + total + ") requestId:" + requestId);
            }
            // If the host sent null then it sent it for a reason
            if( data != null ) {
                if( buffers == null ) {
                    buffers = new byte[total][];
                    this.total = total;
                }
                buffers[part] = data;
            } else {
                // Nulls should only ever be sent as part 1 of 1.
                if( part != 0 && total != 1 ) {
                    throw new IllegalArgumentException("Null data for part:" + part + " of:" + total);
                }
                this.total = total;
            }
            received = part + 1;
            if( isDone() ) {
                // We've gotten all of the data so we can close ourselves
                close();
            }
        }
    }
}
