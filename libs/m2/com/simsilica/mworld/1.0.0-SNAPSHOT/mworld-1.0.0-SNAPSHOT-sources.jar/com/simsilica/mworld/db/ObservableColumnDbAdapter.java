/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mworld.*;

/**
 *  Wraps a regular ColumnDb to provide listener support.  Any column
 *  passed to markChanged() will first go to the delegate and then fire
 *  change events to the registered listeners.
 *
 *  Note: the listener list is not synchronize internally and is designed
 *  for setup during initialization and tear-down during termination.
 *  This is the most common use-case with all modification operations happening
 *  on a single game logic thread.  Applications that require synchronization
 *  can either take care to synchronize or write their own synchronized wrapper
 *  and take the synchronization hit (or implement read/write locks, change
 *  dispatch queues, whatever).
 *
 *  @author    Paul Speed
 */
public class ObservableColumnDbAdapter extends AbstractColumnDb implements ObservableColumnDb {
    static Logger log = LoggerFactory.getLogger(ObservableColumnDbAdapter.class);

    private ColumnDb delegate;
    private boolean initialized;

    private List<ColumnChangeListener> listeners = new ArrayList<>();
    private ColumnChangeListener[] listenerArray = null;

    private List<ColumnGenerationListener> genListeners = new ArrayList<>();
    private ColumnGenerationListener[] genListenerArray = null;

    private ColumnGenerationListener originalHook;

    public ObservableColumnDbAdapter( ColumnDb delegate ) {
        this.delegate = delegate;
    }

    /**
     *  Calls delegate.initialize() directly and sets the generation hook.
     */
    public void initialize() {
        if( initialized ) {
            log.warn("initialize(): Double initialization");
            return;
        }
        log.info("initialize()");
        this.originalHook = delegate.getGenerationHook();

        // We could wait to do this until we see if we have listeners
        delegate.setGenerationHook(new ColumnGenerationListener() {
                @Override
                public void columnGenerated( ColumnGeneratedEvent event ) {
                    fireColumnGenerated(event);
                }
            });
        delegate.initialize();
        initialized = true;
    }

    /**
     *  Calls delegate.terminate() directly and resets the generation hook.
     */
    public void terminate() {
        if( !initialized ) {
            log.warn("terminate(): Not initialized");
            return;
        }
        log.info("terminate()");
        delegate.terminate();
        delegate.setGenerationHook(originalHook);
        originalHook = null;
        initialized = false;
    }

    /**
     *  Calls delegate.getColumn(columnId) directly.
     */
    public ColumnData getColumn( ColumnId columnId ) {
        if( !initialized ) {
            throw new IllegalStateException("Not initialized");
        }
        return delegate.getColumn(columnId);
    }

    /**
     *  Adds a listener that will be notified whenever markChanged() is called.
     *  Note: the listener list is not thread safe so if listeners are to be
     *  added/removed during normal multithreaded operation then care must
     *  be taken and access to the add/remove methods synchronized along with
     *  markChanged().
     */
    @Override
    public void addColumnChangeListener( ColumnChangeListener l ) {
        listeners.add(l);
        listenerArray = null;
    }

    /**
     *  Removes a listener that was previously registered.
     *  Note: the listener list is not thread safe so if listeners are to be
     *  added/removed during normal multithreaded operation then care must
     *  be taken and access to the add/remove methods synchronized along with
     *  markChanged().
     */
    @Override
    public void removeColumnChangeListener( ColumnChangeListener l ) {
        listeners.remove(l);
        listenerArray = null;
    }

    protected ColumnChangeListener[] getListeners() {
        if( listenerArray == null ) {
            listenerArray = listeners.toArray(new ColumnChangeListener[0]);
        }
        return listenerArray;
    }

    @Override
    public void addColumnGenerationListener( ColumnGenerationListener l ) {
        genListeners.add(l);
        genListenerArray = null;
    }

    public void removeColumnGenerationListener( ColumnGenerationListener l ) {
        genListeners.remove(l);
        genListenerArray = null;
    }

    protected ColumnGenerationListener[] getGenListeners() {
        if( genListenerArray == null ) {
            genListenerArray = genListeners.toArray(new ColumnGenerationListener[0]);
        }
        return genListenerArray;
    }

    @Override
    public void markChanged( ColumnData col ) {
        if( !initialized ) {
            throw new IllegalStateException("Not initialized");
        }
        delegate.markChanged(col);
        fireColumnChanged(col, false);
    }

    @Override
    public void resetColumn( ColumnId columnId ) {
        log.info("resetColumn(" + columnId + ")");
        delegate.resetColumn(columnId);
        ColumnData col = getColumn(columnId);
        fireColumnChanged(col, true);
    }

    @Override
    public void reloadColumn( ColumnId columnId ) {
        log.info("reloadColumn(" + columnId + ")");
        delegate.reloadColumn(columnId);
        ColumnData col = getColumn(columnId);
        fireColumnChanged(col, true);
    }

    protected void fireColumnChanged( ColumnData col, boolean reset ) {
        if( listeners.isEmpty() ) {
            return;
        }
        ColumnChangeEvent event = new ColumnChangeEvent(col.getColumnId(), col.getVersion().getVersion(), reset);
        for( ColumnChangeListener l : getListeners() ) {
            try {
                l.columnChanged(event);
            } catch( RuntimeException e ) {
                log.error("Error from listener:" + l, e);
            }
        }
    }

    protected void fireColumnGenerated( ColumnData col ) {
        if( genListeners.isEmpty() ) {
            return;
        }
        ColumnGeneratedEvent event = new ColumnGeneratedEvent(col);
        fireColumnGenerated(event);
    }

    protected void fireColumnGenerated( ColumnGeneratedEvent event ) {
        for( ColumnGenerationListener l : getGenListeners() ) {
            try {
                l.columnGenerated(event);
            } catch( RuntimeException e ) {
                log.error("Error from listener:" + l, e);
            }
        }
    }
}
