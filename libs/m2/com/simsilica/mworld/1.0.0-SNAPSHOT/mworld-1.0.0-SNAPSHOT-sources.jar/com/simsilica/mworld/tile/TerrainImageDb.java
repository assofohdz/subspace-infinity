/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.io.*;
import java.util.zip.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.tile.io.*;

/**
 *  Loads/stores TerrainImage objects to the file system.
 *
 *  @author    Paul Speed
 */
public class TerrainImageDb extends SpoolingObjectDb<TerrainImageId, TerrainImage> {
    static Logger log = LoggerFactory.getLogger(TerrainImageDb.class);

    private File root;
    private TerrainImageProtocol protocol = new TerrainImageProtocol();

    public TerrainImageDb( File root ) {
        this.root = root;
    }

    /**
     *  Creates a Tile function that can load the Tile's terrain image for the
     *  particular terrain type.
     */
    public TileFunction getTileFunction( final TerrainImageType type ) {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    TerrainImage image = tile.get(type, TerrainImage.class);
                    if( image != null ) {
                        if( image.getVersion().isTransient() ) {
                            log.info("Ignoring transient image for:" + tile.getTileId() + " type:" + type);
                            return;
                        }
                        throw new IllegalStateException("Tile:" + tile.getTileId() + " already has terrain image for:" + type);
                    }
                    image = get(new TerrainImageId(tile.getTileId(), type, tile.getResolution()));
                    tile.put(type, image);
                }
            };
    }

    /**
     *  Creates a Tile function that can load the Tile's terrain image for all terrain types.
     */
    public TileFunction getLoadFunction() {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    for( TerrainImageType type : TerrainImageType.values() ) {
                        TerrainImage image = tile.get(type, TerrainImage.class);
                        if( image != null ) {
                            if( image.getVersion().isTransient() ) {
                                log.info("Ignoring transient image for:" + tile.getTileId() + " type:" + type);
                                return;
                            }
                            throw new IllegalStateException("Tile:" + tile.getTileId() + " already has terrain image for:" + type);
                        }
                        image = get(new TerrainImageId(tile.getTileId(), type, tile.getResolution()));
                        tile.put(type, image);
                    }
                }
            };
    }

    public TileFunction getSaveFunction() {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    for( TerrainImageType type : TerrainImageType.values() ) {
                        TerrainImage image = tile.get(type, TerrainImage.class);
                        if( image.getVersion().isChanged() ) {
                            log.info("Storing:" + image);
                            update(image.getId(), image);
                        }
                    }
                }
            };
    }

    public TileFunction getResetFunction() {
        return new TileFunction() {
                @Override
                public void accept( Tile tile ) {
                    log.info("Reset tile:" + tile.getTileId());
                    for( TerrainImageType type : TerrainImageType.values() ) {
                        TerrainImageId id = new TerrainImageId(tile.getTileId(), type, tile.getResolution());
                        TerrainImage image = new TerrainImage(id, new TransientDataVersion());
                        tile.put(type, image);
                    }
                }
            };
    }

    @Override
    public void update( TerrainImageId id, TerrainImage image ) {
        if( log.isTraceEnabled() ) {
            log.trace("update(" + id + ", " + image + ")");
        }

        // Applying a similar data version fix here as to the other spooling DB
        // cases.  I don't know that it matters in the case of TerrainImages but
        // it will at least be consistent.
        DataVersion version = image.getVersion();
        synchronized(version) {
            if( version.getLoadVersion() == -1 ) {
                // First time saving is a special case
                version.resetChanged(System.currentTimeMillis());
                // Make sure it still looks changed because we haven't
                // actually saved it yet.
                version.markChanged();
            }
        }

        super.update(id, image);

        // But we also want to reproject any lower resolutions... if we
        // do the next lower resolution then it will do its next lower
        // resolution and so on.
        TerrainImageId lower = id.getLowerResolution();
        if( lower != null ) {
            // Grabbing it this way ensures that if there is already one loaded
            // that we will be using that one.
            TerrainImage target = get(lower);
            target.write(image);
            target.getVersion().markChanged();
            update(lower, target);
        }
    }

    protected File toFile( TerrainImageId id ) {
        Vec3i sedectile = id.getParentId().getCell(null);
        String path = sedectile.y + "/" + sedectile.x + "/" + sedectile.z;
        File dir = new File(root, path);
        if( !dir.exists() ) {
            dir.mkdirs();
        }

        String name = id.getTileId().getId() + "-" + id.getResolution() + "." + id.getType();
        return new File(dir, name);
    }

    protected TerrainImage loadObject( TerrainImageId id ) {
        if( log.isTraceEnabled() ) {
            log.trace("loadObject(" + id + ")");
        }
        File file = toFile(id);
        if( file.exists() ) {
            TerrainImage result = readObjectFile(id, file);
            return result;
        }
        return new TerrainImage(id, new DataVersion(-1));
    }

    protected TerrainImage readObjectFile( TerrainImageId id, File file ) {
        try( BufferedInputStream in = new BufferedInputStream(new GZIPInputStream(new FileInputStream(file))) ) {
            TerrainImage result = protocol.read(in);
            assert id.equals(result.getId());
            if( log.isTraceEnabled() ) {
                log.trace("Loaded terrain image for:" + id);
            }
            return result;
        } catch( IOException e ) {
            throw new RuntimeException("Error reading object:" + id + " from:" + file, e);
        }
    }

    protected void storeObject( TerrainImageId id, TerrainImage value ) {
        File file = toFile(id);
        DataVersion version = value.getVersion();
        synchronized(version) {
            writeObjectFile(id, file, value);

            // OLD-FIXME: this DataVersion operation is not thread safe and we
            // may race past some other thread incementing the changed flag.
            // Note: I have made DataVersion synchronized so we can expand
            // a synchronized block.  It's ugly but it should alleviate my
            // fixme concerns above.  Though I admit I have not done a detailed
            // analysis. 2023-05-30
            value.getVersion().resetChanged(System.currentTimeMillis());
        }
    }

    protected void writeObjectFile( TerrainImageId id, File file, TerrainImage value ) {
        if( log.isTraceEnabled() ) {
            log.trace("writeObjectFile(" + id + ", " + file + ")");
        }
        long start = System.nanoTime();
        // FIXME: probably the GZIP part, buffered stream, etc. should be in the
        // protocol in case we ever decide on different compression schemes we could
        // select by protocol version.  Don't need to really worry about it until
        // we want something different.
        try( BufferedOutputStream out = new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(file))) ) {
            protocol.write(value, out);
        } catch( IOException e ) {
            throw new RuntimeException("Error writing object:" + id + " to:" + file, e);
        }
        long end = System.nanoTime();
        log.info("Wrote [" + id + "] in " + ((end - start)/1000000.0) + " ms");
    }
}


