/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;

/**
 *  Just fills the intersecting terrain image or column with
 *  a prespecified fill value.  0 is considered "empty".
 *
 *  @author    Paul Speed
 */
public class SphereFill extends AbstractSphereMorphology {
    static Logger log = LoggerFactory.getLogger(SphereFill.class);

    private int blockFill;
    private byte terrainFill;

    public SphereFill( Vec3i center, int radius, int blockFill, byte terrainFill ) {
        super(center, radius);
        this.blockFill = blockFill;
        this.terrainFill = terrainFill;
    }

    public int getBlockFill() {
        return blockFill;
    }

    public byte getTerrainFill() {
        return terrainFill;
    }

    protected double calculateY( double x, double z ) {
        // Equation for a sphere:
        // (x - h)^2 + (y - k)^2 + (z-l)^2 = r^2
        // where hkl is the center.
        //
        // We know x and z and can easily make them center relative.
        //
        // x^2 + (y - k)^2 + z^2 = r^2
        // (y - k)^2 = r^2 - x^2 - z^2
        Vec3i center = getCenter();
        double r = getRadius();
        double rSq = r * r;

        x = x - center.x;
        z = z - center.z;

        double ySq = rSq - (x * x) - (z * z);
        if( ySq < 0 ) {
            return Double.NaN;
        }
        double y = Math.sqrt(ySq);

        return y + center.y;
    }

    public boolean morph( Tile tile, Random rand ) {
        log.info("morph(" + tile + ")");

        TerrainImage terrain = tile.get(TerrainImageType.Terrain, TerrainImage.class);
        int size = terrain.getSize();
        int skip = 1024 / size;

        Vec3i tileMin = tile.getTileId().getWorld(null);
        Vec3i tileMax = tileMin.add(1024, 0, 1024);
        Vec3i center = getCenter();
        int radius = getRadius();

        int xMin = (Math.max(tileMin.x, center.x - radius) - tileMin.x) / skip;
        int xMax = (Math.min(tileMax.x, center.x + radius + 1) - tileMin.x) / skip;
        int zMin = (Math.max(tileMin.z, center.z - radius) - tileMin.z) / skip;
        int zMax = (Math.min(tileMax.z, center.z + radius + 1) - tileMin.z) / skip;

        boolean changed = false;
        for( int x = xMin; x < xMax; x++ ) {
            for( int z = zMin; z < zMax; z++ ) {

                double y = calculateY(tileMin.x + x * skip, tileMin.z + z * skip);
                if( Double.isNaN(y) ) {
                    // Outside the sphere
                    continue;
                }
                int elevation = (int)y;
                if( elevation > terrain.getElevation(x, z) ) {
                    terrain.setElevation(x, z, (short)elevation);
                    terrain.setType(x, z, terrainFill);
                    changed = true;
                }
            }
        }

        return changed;
    }

    public boolean morph( ColumnData colData, Tile tile, Random rand ) {

        Vec3i colMin = colData.getColumnId().getWorld(null);
        Vec3i colMax = colMin.add(COLUMN_SIZE, colData.getCeiling(), COLUMN_SIZE);
        Vec3i center = getCenter();
        int radius = getRadius();

        int xMin = Math.max(colMin.x, center.x - radius) - colMin.x;
        int xMax = Math.min(colMax.x, center.x + radius + 1) - colMin.x;
        int yMin = Math.max(colMin.y, center.y - radius) - colMin.y;
        int yMax = Math.min(colMax.y, center.y + radius + 1) - colMin.y;
        int zMin = Math.max(colMin.z, center.z - radius) - colMin.z;
        int zMax = Math.min(colMax.z, center.z + radius + 1) - colMin.z;

        // Find the center in column space
        int xCenter = center.x - colMin.x;
        int yCenter = center.y - colMin.y;
        int zCenter = center.z - colMin.z;

        int rSq = radius * radius;

        boolean changed = false;
        for( int y = yMin; y < yMax; y++ ) {
            int layer = y / LeafId.SIZE;
            int yBase = layer * LeafId.SIZE;
            LeafData leaf = colData.getLeafs()[layer];
            int j = y - yBase;

            for( int i = xMin; i < xMax; i++ ) {
                for( int k = zMin; k < zMax; k++ ) {

                    int dx = i - xCenter;
                    int dy = y - yCenter;
                    int dz = k - zCenter;
                    double dSq = dx * dx + dy * dy + dz * dz;
                    if( dSq <= rSq ) {
                        leaf.setCell(i, j, k, blockFill);
                        changed = true;
                    }
                }
            }
        }

        return changed;
    }
}
