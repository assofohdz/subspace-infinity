/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.io.ObjectProtocol;


/**
 *
 *
 *  @author    Paul Speed
 */
public class TreeLayerProtocol implements ObjectProtocol<TreeLayer> {
    static Logger log = LoggerFactory.getLogger(TreeLayerProtocol.class);

    private static final int XZ_BITS = 10;        // 0-1023 possible
    private static final int ELEVATION_BITS = 10; // 0-1023 possible, 512 wouldn't be enough
    private static final int HEIGHT_BITS = 6;  // 1..64 meters, 0 height makes no sense
    private static final int RADIUS_BITS = 4;  // 1..16, 0 radius makes no sense
    // 40 bits without the type... so 5 bytes per tree plus type bits

    // We use this in some cases for a secondary trunk height but
    // I've left it general.  Still, we'll give it the same bits.
    // But note that this value allows 0 and so will only go up to 63.
    private static final int OTHER_BITS = HEIGHT_BITS;

    // 42 is the original version.
    // 43 includes the generation level
    private int version = 43;

    private TreeTypeIndex treeTypeIndex;
    private int baseTypeBits;

    public TreeLayerProtocol() {
        this(TreeTypeIndex.getInstance());
    }

    public TreeLayerProtocol( TreeTypeIndex treeTypeIndex ) {
        this.treeTypeIndex = treeTypeIndex;

        if( treeTypeIndex.isInitialized() ) {
            // Calculate a good size for type indexes
            this.baseTypeBits = Integer.SIZE - Integer.numberOfLeadingZeros(treeTypeIndex.size());
            log.info("baseTypeBits:" + baseTypeBits + "  index size:" + treeTypeIndex.size());
        }
    }

    public int getProtocolVersion() {
        return version;
    }

    // I will probably regret not having a proper init/terminate cycle
    // for protocols.  In the mean time, we will lazily adapt an appropriate
    // base bits.
    private void checkBaseBits() {
        if( baseTypeBits == 0 ) {
            log.warn("baseTypeBits is 0, checking index initialized state...");
            if( !treeTypeIndex.isInitialized() ) {
                throw new IllegalStateException("Tree type index has not been initialized, cannot write tree layers");
            }
            // Calculate a good size for type indexes
            this.baseTypeBits = Integer.SIZE - Integer.numberOfLeadingZeros(treeTypeIndex.size());
            log.info("baseTypeBits:" + baseTypeBits + "  index size:" + treeTypeIndex.size());
        }
    }

    public void write( TreeLayer data, BitOutputStream out ) throws IOException {
        checkBaseBits();

        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        // Header stuff
        TileId tileId = data.getTileId();
        long id = tileId.getId();
        out.writeLongBits(id, 64);
        out.writeLongBits(data.getVersion().getVersion(), 64);
        out.writeBits(data.getGenerationLevel(), 8);

        // Write out the number of bits we will use for type... this will
        // make the reading side a little more adaptive
        out.writeBits(baseTypeBits, 8);

        int size = data.getTrees().size();
        out.writeBits(size, 32);
        // Realistically we would never need more than 20 bits would be a tree
        // in every cell... but it's only stored once per tile.

        for( Tree tree : data.getTrees() ) {
            out.writeBits(tree.x, XZ_BITS);
            out.writeBits(tree.y, ELEVATION_BITS);
            out.writeBits(tree.z, XZ_BITS);

            out.writeBits(tree.height - 1, HEIGHT_BITS);
            out.writeBits(tree.radius - 1, RADIUS_BITS);
            out.writeBits(tree.other, OTHER_BITS);

            out.writeBits(tree.type.getIndex(), baseTypeBits);
        }
    }

    public TreeLayer read( BitInputStream in ) throws IOException {

        int version = in.readBits(16);
        // Could check version to see if we need to read in a special way

        // Read the header and create the tile
        TileId tileId = new TileId(in.readLongBits(64));
        long dataVersion = in.readLongBits(64);

        int generationLevel = 0;
        if( version >= 43 ) {
            // Then we can read the generation level
            generationLevel = in.readBits(8);
        }

        int typeBits = in.readBits(8);

        int size = in.readBits(32);

        List<Tree> trees = new ArrayList<>(size);
        //Tree[] trees = new Tree[size];
        for( int i = 0; i < size; i++ ) {
            int x = in.readBits(XZ_BITS);
            int y = in.readBits(ELEVATION_BITS);
            int z = in.readBits(XZ_BITS);

            int height = in.readBits(HEIGHT_BITS) + 1;
            int radius = in.readBits(RADIUS_BITS) + 1;
            int other = in.readBits(OTHER_BITS);

            int typeIndex = in.readBits(typeBits);
            TreeType type = treeTypeIndex.getType(typeIndex);

            //trees[i] = new Tree((short)x, (short)y, (short)z, (byte)height, (byte)radius, type);
            Tree tree = new Tree((short)x, (short)y, (short)z, (byte)height, (byte)radius, (byte)other, type);
            trees.add(tree);
        }

        return new TreeLayer(tileId, new DataVersion(dataVersion), generationLevel, trees);
    }

    public void write( TreeLayer trees, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(trees, out);
        } finally {
            out.close();
        }
    }

    public TreeLayer read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }
}

