/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import org.slf4j.*;

/**
 *  Represent a "tree" or other large multi-cell plant in the world.
 *
 *  @author    Paul Speed
 */
public class Tree {
    static Logger log = LoggerFactory.getLogger(Tree.class);

    public final short x;
    public final short y;
    public final short z;

    public final byte height; // 1..64
    public final byte radius; // 1..16
    public final byte other;  // 0..63

    public final TreeType type;

    public Tree( short x, short y, short z, byte height, byte radius, TreeType type ) {
        this(x, y, z, height, radius, (byte)0, type);
    }

    public Tree( short x, short y, short z, byte height, byte radius, byte other, TreeType type ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.height = height;
        this.radius = radius;
        this.other = other;
        this.type = type;
    }

    @Override
    public String toString() {
        return "Tree[loc:[" + x + ", " + y + ", " + z + "], height:"+ height + ", radius:" + radius + ", other:" + other + ", type:" + type + "]";
    }
}


