/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.net.server;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.jme3.network.HostedConnection;
import com.jme3.network.MessageConnection;
import com.jme3.network.Server;
import com.jme3.network.serializing.Serializer;
import com.jme3.network.serializing.serializers.EnumSerializer;
import com.jme3.network.serializing.serializers.FieldSerializer;
import com.jme3.network.service.AbstractHostedConnectionService;
import com.jme3.network.service.HostedServiceManager;
import com.jme3.network.service.rmi.RmiHostedService;
import com.jme3.network.service.rmi.RmiRegistry;

import com.simsilica.mblock.BlockTypeIndex;
import com.simsilica.mblock.FluidTypeIndex;
import com.simsilica.mworld.*;
import com.simsilica.mworld.base.DefaultWorld;
import com.simsilica.mworld.base.LeafChangeListenerSupport;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.io.*;
import com.simsilica.mworld.net.WorldDataSession;
import com.simsilica.mworld.net.WorldDataListener;
import com.simsilica.mworld.net.msg.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.PointCloudLayer;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.mworld.tile.tree.TreeTypeIndex;


/**
 *
 *
 *  @author    Paul Speed
 */
public class WorldHostedService extends AbstractHostedConnectionService {

    static Logger log = LoggerFactory.getLogger(WorldHostedService.class);

    private static final String ATTRIBUTE_SESSION = "world.session";

    private RmiHostedService rmiService;
    private int channel;

    private World world;

    private ThreadPoolExecutor workers;

    private ProtocolSerializers protocols = new ProtocolSerializers();

    /**
     *  Creates a new world hosting service that will use the default reliable channel
     *  for reliable communication.
     */
    public WorldHostedService( World world ) {
        this(world, MessageConnection.CHANNEL_DEFAULT_RELIABLE);
    }

    /**
     *  Creates a new world hosting service that will use the specified channel
     *  for reliable communication.
     */
    public WorldHostedService( World world, int channel ) {
        this.channel = channel;
        this.world = world;
        //setAutoHost(false);

        // Make sure our local serialization needs are met
        Serializer.registerClass(CellChangeEvent.class, new FieldSerializer());
        Serializer.registerClass(LeafChangeEvent.class, new FieldSerializer());

        Serializer.registerClass(TerrainImageType.class, new EnumSerializer());
        Serializer.registerClass(Resolution.class, new EnumSerializer());

        // We register some just so that we can send class parameters as arguments
        // Zay-es has serializers for Class objects and class fields... but they
        // all rely on the class having been registered with the serializer.
        // But there are several classes that we want to send as 'types' but never
        // actually send as objects.
        // We may not need this unless we support generic queries.
        //Serializer.registerClass(LeafData.class, NullSerializer.INSTANCE);

        // We only want the class registered so we can pass it as Class parameters.
        // SpiderMonkey doesn't provide a direct way to do this (that I know)
        // so we will fake it
        Serializer.registerClass(TerrainImage.class, NullSerializer.INSTANCE);
        Serializer.registerClass(PointCloudLayer.class, NullSerializer.INSTANCE);

        Serializer.registerClass(WorldDataSession.IndexType.class, new EnumSerializer());

        workers = createThreadPool(1000, 4);
    }

    protected ThreadPoolExecutor createThreadPool( int maxRequests, int poolSize ) {
        BlockingQueue<Runnable> queue = new LinkedBlockingDeque<>(maxRequests);
        ThreadFactory tf = new ThreadFactoryBuilder()
                .setDaemon(true)
                .setNameFormat("world-host-pool-%d")
                .setUncaughtExceptionHandler((Thread t, Throwable e ) -> log.error("uncaught exception", e))
                .build();

        return new ThreadPoolExecutor(poolSize, poolSize, 0L, TimeUnit.MILLISECONDS,
                                      queue, tf, new ThreadPoolExecutor.CallerRunsPolicy());
    }

    protected WorldDataSessionImpl getWorldSession( HostedConnection conn ) {
        return conn.getAttribute(ATTRIBUTE_SESSION);
    }

    @Override
    protected void onInitialize( HostedServiceManager s ) {

        // Grab the RMI service so we can easily use it later
        this.rmiService = getService(RmiHostedService.class);
        if( rmiService == null ) {
            throw new RuntimeException("WorldHostedService requires an RMI service.");
        }
    }

    /**
     *  Starts hosting the world services on the specified connection.
     */
    @Override
    public void startHostingOnConnection( HostedConnection conn ) {
        log.debug("startHostingOnConnection(" + conn + ") channel:" + channel);

        WorldDataSessionImpl session = new WorldDataSessionImpl(conn);
        conn.setAttribute(ATTRIBUTE_SESSION, session);

        // Expose the session as an RMI resource to the client
        RmiRegistry rmi = rmiService.getRmiRegistry(conn);
        rmi.share((byte)channel, session, WorldDataSession.class);
    }

    @Override
    public void stopHostingOnConnection( HostedConnection conn ) {
        log.debug("stopHostingOnConnection(" + conn + ")");
        WorldDataSessionImpl session = getWorldSession(conn);
        if( session != null ) {

            // Then we are still hosting on the connection... it's
            // possible that stopHostingOnConnection() is called more than
            // once for a particular connection since some other game code
            // may call it and it will also be called during connection shutdown.
            conn.setAttribute(ATTRIBUTE_SESSION, null);

            // Do any local cleanup necessary... for example, removing
            // cell change listeners from the main world instance.
            session.cleanup();
        }
    }

    /**
     *  The connection-specific 'host' for the WorldDataSession.  For convenience
     *  this also implements the WorldDataListener.  Since the methods don't
     *  collide at all it's convenient for our other code not to have to worry
     *  about the internal delegate.
     */
    private class WorldDataSessionImpl implements WorldDataSession,
                                                  CellChangeListener,
                                                  LeafChangeListener,
                                                  ColumnChangeListener,
                                                  TileListener {

        private HostedConnection conn;
        private WorldDataListener callback;

        public WorldDataSessionImpl( HostedConnection conn ) {
            this.conn = conn;

            // Note: at this point we won't be able to look up the callback
            // because we haven't received the client's RMI shared objects yet.
        }

        public void cleanup() {
            world.removeCellChangeListener(this);
        }

        protected WorldDataListener getCallback() {
            if( callback == null ) {
                RmiRegistry rmi = rmiService.getRmiRegistry(conn);
                callback = rmi.getRemoteObject(WorldDataListener.class);
                if( callback == null ) {
                    throw new RuntimeException("Unable to locate client callback for WorldDataListener");
                }

                world.addCellChangeListener(this);
                world.addLeafChangeListener(this);
                world.addColumnChangeListener(this);
                world.addTileListener(this);
            }
            return callback;
        }

        @Override
        public int getMaxY() {
            return world.getMaxY();
        }

        @Override
        public void requestLeafData( final long requestId, final long leafId ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestLeafData(" + requestId + ", " + leafId + ")");
            }
            workers.execute( () -> {
                    LeafData leaf = world.getLeaf(new LeafId(leafId));
                    if( leaf == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(leaf, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        @Override
        public void requestLightData( final long requestId, final long leafId ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestLightData(" + requestId + ", " + leafId + ")");
            }
            workers.execute( () -> {
                    LightData value = world.getLight(new LeafId(leafId));
                    if( value == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(value, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        @Override
        public void requestFluidData( final long requestId, final long leafId ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestFluidData(" + requestId + ", " + leafId + ")");
            }
            workers.execute( () -> {
                    FluidData value = world.getFluid(new LeafId(leafId));
                    if( value == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(value, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        @Override
        public void requestTerrainImage( final long requestId, final long tileId,
                                         final TerrainImageType type, final Resolution res ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestTerrainImage(" + requestId + ", " + tileId + ", " + type + ", " + res + ")");
            }
            workers.execute( () -> {
                    TerrainImage value = world.getTerrainImage(new TileId(tileId), type, res);
                    if( value == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(value, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        @Override
        public void requestTrees( final long requestId, final long tileId, final Resolution res ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestTrees(" + requestId + ", " + tileId + ", " + res + ")");
            }
            workers.execute( () -> {
                    TreeLayer value = world.getTrees(new TileId(tileId), res);
                    if( value == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(value, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }


        @Override
        public void requestPointCloudLayer( final long requestId, final long tileId, final Resolution res ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestPointCloudLayer(" + requestId + ", " + tileId + ", " + res + ")");
            }
            workers.execute( () -> {
                    PointCloudLayer value = world.getPointCloudLayer(new TileId(tileId), res);
                    if( value == null ) {
                        partReceived(requestId, (byte)0, (byte)1, null);
                        return;
                    }
                    List<byte[]> data = protocols.toPackets(value, 32000, true);

                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        @Override
        public void requestIndexData( final long requestId, final IndexType type ) {
            if( log.isTraceEnabled() ) {
                log.trace("requestIndexData(" + requestId + ", " + type + ")");
            }
            workers.execute( () -> {
                    List<byte[]> data;
                    switch( type ) {
                        case BlockType:
                            data = protocols.toPackets(BlockTypeIndex.toBlockTypeData(), 32000, true);
                            break;
                        case FluidType:
                            data = protocols.toPackets(FluidTypeIndex.toFluidTypeData(), 32000, true);
                            break;
                        case TreeType:
                            data = protocols.toPackets(TreeTypeIndex.getInstance(), 32000, true);
                            break;
                        default:
                            throw new IllegalArgumentException("Unhandled type:" + type);
                    }
                    log.info(type + " packet count:" + data.size());
                    // Send the packets on
                    byte part = 0;
                    byte total = (byte)data.size();
                    for( byte[] packet : data ) {
                        partReceived(requestId, part++, total, packet);
                    }
                });
        }

        // Start of callback methods to talk to the client

        //@Override
        protected void partReceived( long requestId, byte part, byte total, byte[] data ) {
            getCallback().partReceived(requestId, part, total, data);
        }

        @Override
        public void cellChanged( CellChangeEvent event ) {
            if( log.isTraceEnabled() ) {
                log.trace(conn + "->" + event);
            }
            boolean zipIt = event.getChangeCount() > 100;
            if( log.isTraceEnabled() ) {
                log.trace("cellChanged(" + event + ") zipIt:" + zipIt);
            }
            try {
                byte[] data = protocols.toBytes(event, zipIt);
                if( log.isTraceEnabled() ) {
                    log.trace("cell event data size:" + data.length);
                }
                getCallback().cellChanged(event.getLeafId().getId(), data, zipIt);
            } catch( IOException e ) {
                throw new RuntimeException("Error serializing event data for:" + event.getLeafId().getId(), e);
            }
        }

        @Override
        public void leafChanged( LeafChangeEvent event ) {
            if( log.isTraceEnabled() ) {
                log.trace(conn + "->" + event);
            }
            getCallback().leafChanged(event.getLeafId().getId(), event.getLeafVersion(), event.isReset());
        }

        @Override
        public void columnChanged( ColumnChangeEvent event ) {
            if( log.isTraceEnabled() ) {
                log.trace("conn" + "->" + event);
            }
            if( event.isReset() ) {
                // Apply for each of the leafs
                for( LeafId leafId : event.getColumnId().getLeafIds(world.getMaxY()) ) {
                    LeafChangeEvent leafEvent = new LeafChangeEvent(leafId, event.getVersion(), true);
                    leafChanged(leafEvent);
                }
            }
        }

        @Override
        public void tileChanged( TileChangeEvent event ) {
            if( log.isTraceEnabled() ) {
                log.trace("conn" + "->" + event);
            }
            getCallback().tileChanged(event.getDataType(), event.getTileId().getId(),
                                      event.getDataVersion(), event.getResolution());
        }

    }
}


