/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mworld.*;

/**
 *  Given a world, this will lazily build the immediate neighborhood
 *  around a single leaf's LightData.  This is used for creating
 *  lighting gradients on the client for smooth lighting, etc..
 *
 *  Note: this is not necessarily the most efficient way to provide
 *  the border lights but it is expedient.  (Better might be to build
 *  a custom data structure or CellArray presampled and sent over the
 *  wire in client-server and simply backed by the LightData in
 *  non-client server, ie: DefaultWorld could build a neighborhood
 *  like this and the world host could sample it and send back an array.
 *  So this class is not wasted either way.
 *  Note2: we could also consider building the gradients on the server
 *  and keeping them up to data with world changes.  Time vs space.
 *
 *  @author    Paul Speed
 */
public class LightNeighborhood implements CellData {
    static Logger log = LoggerFactory.getLogger(LightNeighborhood.class);

    private World world;
    private Vec3i origin;
    private LightData center;

    private LightData[][][] array = new LightData[3][3][3];

    public LightNeighborhood( World world, LightData center ) {
        this.world = world;
        this.center = center;
        this.origin = center.getLeafId().getWorld(null);

        array[1][1][1] = center;
    }

    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    public int getCell( int x, int y, int z, int defaultValue ) {
        // The most common case
        if( x >= 0 && y >= 0 && z >= 0
            && x < LeafId.SIZE && y < LeafId.SIZE && z < LeafId.SIZE ) {
            return center.getCell(x, y, z, defaultValue);
        }
        // Presumably, 6 conditionals will be faster than two
        // 3D array lookups below + coordinate math.

        // Find the array location and normalize the coordinates
        int ax = 1;
        int ay = 1;
        int az = 1;
        if( x < 0 ) {
            ax--;
            x += LeafId.SIZE;
        }
        if( y < 0 ) {
            ay--;
            y += LeafId.SIZE;
        }
        if( z < 0 ) {
            az--;
            z += LeafId.SIZE;
        }
        if( x >= LeafId.SIZE ) {
            ax++;
            x -= LeafId.SIZE;
        }
        if( y >= LeafId.SIZE ) {
            ay++;
            y -= LeafId.SIZE;
        }
        if( z >= LeafId.SIZE ) {
            az++;
            z -= LeafId.SIZE;
        }
        int yWorld = origin.y + (ay-1) * LeafId.SIZE;
        if( yWorld < 0 || yWorld >= world.getMaxY() ) {
            // We've dropped out of the bottom of the world so just return
            // the default value.
            return defaultValue;
        }
        if( array[ax][ay][az] == null ) {
            // Look it up... calculate the leaf ID of the neighbor
            LeafId id = LeafId.fromWorld(origin.x + (ax-1) * LeafId.SIZE,
                                         yWorld,
                                         origin.z + (az-1) * LeafId.SIZE);
            array[ax][ay][az] = world.getLight(id);
        }
        if( array[ax][ay][az] == null ) {
            // note: this can also happen with finite worlds
            //log.warn("Exceeded y somewhere, world Y:" + yWorld + "  maxY:" + world.getMaxY() + "  ay:" + ay + "  y:" + y);
            return defaultValue;
        }
        return array[ax][ay][az].getCell(x, y, z, defaultValue);
    }

    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    public void setCell( int x, int y, int z, int type ) {
        // Read only
    }
}

