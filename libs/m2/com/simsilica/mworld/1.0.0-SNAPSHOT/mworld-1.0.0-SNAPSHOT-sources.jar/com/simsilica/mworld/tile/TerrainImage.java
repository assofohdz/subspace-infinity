/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mworld.DataVersion;

/**
 *  Represents the elevation + terrain types for a particular
 *  1024x1024 section of the map at various resolutions.
 *
 *  @author    Paul Speed
 */
public class TerrainImage implements TileImageData<TerrainImage> {
    static Logger log = LoggerFactory.getLogger(TerrainImage.class);

    private TerrainImageId id;
    private DataVersion version;

    // Initial image generation may happen in several passes and
    // this lets us still know when the tile requires some generation.
    private byte generationLevel;

    private int size;
    private short[] elevations;
    private byte[] types;
    private byte[] lights;

    public TerrainImage( TerrainImageId id, DataVersion version ) {
        this(id, version, 0);
    }

    public TerrainImage( TerrainImageId id, DataVersion version, int generationLevel ) {
        this.id = id;
        this.version = version;
        this.generationLevel = (byte)generationLevel;

        this.size = id.getResolution().getSamples();
        this.elevations = new short[size * size];
        this.types = new byte[size * size];
        this.lights = new byte[size * size];
    }

    public TerrainImageId getId() {
        return id;
    }

    public DataVersion getVersion() {
        return version;
    }

    public void setGenerationLevel( int generationLevel ) {
        if( this.generationLevel > generationLevel ) {
            throw new IllegalArgumentException("Generation level cannot go backwards.");
        }
        this.generationLevel = (byte)generationLevel;
    }

    public int getGenerationLevel() {
        return generationLevel;
    }

    public int getSize() {
        return size;
    }

    private int index( int x, int y ) {
        // Data is stored in rows
        return size * y + x;
    }

    public final void setElevation( int x, int y, short elevation ) {
        elevations[index(x, y)] = elevation;
    }

    public final short getElevation( int x, int y ) {
        return elevations[index(x, y)];
    }

    public final void setType( int x, int y, byte type ) {
        types[index(x, y)] = type;
    }

    public final byte getType( int x, int y ) {
        return types[index(x, y)];
    }

    public final void setLight( int x, int y, byte light ) {
        lights[index(x, y)] = light;
    }

    /**
     *  Performs logic against the existing light value to update in
     *  a consistent way.  If there is any positive light value then negative
     *  light values will be ignored.  Otherwise, the highest positive
     *  value or lowest negative value will win.
     */
    public final boolean updateLight( int x, int y, byte light ) {
        int index = index(x, y);
        byte existing = lights[index];
        if( existing == light ) {
            return false;
        }
        if( existing >= 0 && light > existing ) {
            lights[index] = light;
            return true;
        }
        if( existing <= 0 && light < 0 ) {
            // For shadows, we will accumulate a bit if there is already
            // existing data.  Added 2024-10-20 to try to help dark forests splat darker.
            if( existing == 0 ) {
                // Just set it
                lights[index] = light;
            } else {
                // accumulate a little bit
                int val = (light < existing ? light : existing) - 1;
//log.info("[" + x + "][" + y + "] existing:" + existing + " light:" + light + " val:" + val);
                lights[index] = (byte)(val < -15 ? -15: val);
            }
            return true;
        }
        return false;
    }

    public final byte getLight( int x, int y ) {
        return lights[index(x, y)];
    }

    public final short[] getElevations() {
        return elevations;
    }

    public final byte[] getTypes() {
        return types;
    }

    public final byte[] getLights() {
        return lights;
    }

    @Override
    public void setData( TerrainImage from, int xStart, int yStart, int xSize, int ySize ) {
        log.info("setData(" + from + ", " + xStart + ", " + yStart + ", " + xSize + ", " + ySize + ")");
        if( from.size != size ) {
            throw new IllegalArgumentException("Size mismatch:" + size + " versus:" + from.size);
        }

        // Adjust in to local space sizes... so if our image size
        // is 128 then it means each 'pixel' represents 8 meters and we need to
        // divide everything by 8.   (128/1024 = 1/8)
        xStart = xStart * size / 1024;
        yStart = yStart * size / 1024;
        xSize = xSize * size / 1024;
        ySize = ySize * size / 1024;

        for( int i = 0; i < xSize; i++ ) {
            for( int j = 0; j < ySize; j++ ) {
                int index = index(xStart + i, yStart + j);
                //int existing = elevations[index];
                //int change = from.elevations[index];
                //if( existing != change ) {
                //    log.info("changing[" + (xStart + i) + "][" + (yStart + j) + "] from:" + existing + " to:" + change);
                //}
//log.info("[" + i + "][" + j + "] " + String.format("e:%d, t:%d, l:%d", from.elevations[index], from.types[index], from.lights[index]));
                elevations[index] = from.elevations[index];
                types[index] = from.types[index];
                lights[index] = from.lights[index];
            }
        }
    }

    /**
     *  Writes the specified image to this one, resampling as required.
     */
    public void write( TerrainImage image ) {
        if( image.size < size ) {
            throw new IllegalArgumentException("Cannot extrapolate image data from a lower resolution:" + image.getId().getResolution());
        }
        // Now we know that the supplied image is the same or bigger than we are
        // and we just need to figure out how much data to skip with each 'pixel'
        int skip = image.size / size;
        int src = 0;
        int target = 0;
        short[] srcElevations = image.elevations;
        byte[] srcTypes = image.types;
        byte[] srcLights = image.lights;
        for( int i = 0; i < size; i++ ) {
            // Find the right source row for this pass
            src = i * skip * image.size;
            for( int j = 0; j < size; j++ ) {
                elevations[target] = srcElevations[src];
                types[target] = srcTypes[src];
                lights[target] = srcLights[src];
                target++;
                src += skip;
            }
        }
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("id", getId())
            .add("version", getVersion())
            .add("size", size)
            .toString();
    }

}

