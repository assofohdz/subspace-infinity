/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;

/**
 *  Adapts a ColumnDb to a LeafDb interface... until LeafDb goes away.
 *
 *  @author    Paul Speed
 */
public class ColumnDbLeafDbAdapter implements LeafDb {
    static Logger log = LoggerFactory.getLogger(ColumnDbLeafDbAdapter.class);
    
    private ColumnDb delegate;    
    
    public ColumnDbLeafDbAdapter( ColumnDb delegate ) {
        this.delegate = delegate;
    }
 
    @Override   
    public LeafData loadLeaf( LeafId id ) {
        Vec3i world = id.getWorld(null);
        ColumnData column = delegate.getColumn(id.getColumnId());
        return column.getLeafData(world.y);       
    }
    
    @Override   
    public void storeLeaf( LeafData leaf ) {
    
        LeafId id = leaf.getInfo().leafId;
log.info("storeLeaf(id:" + id + ")");        
        Vec3i world = id.getWorld(null);
        ColumnId columnId = ColumnId.fromWorld(world);               
        ColumnData column = delegate.getColumn(id.getColumnId());
//log.info("reloaded column:" + column);        
        column.getVersion().markChanged();
        
        LeafData original = column.getLeafData(world.y);
        
        // Make sure they are the same
        if( original != leaf ) {
            throw new RuntimeException("Cache miss?");
        }
        
        delegate.markChanged(column);
    }
}
