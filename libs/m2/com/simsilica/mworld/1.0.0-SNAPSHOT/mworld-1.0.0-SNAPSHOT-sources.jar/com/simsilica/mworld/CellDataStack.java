/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import com.simsilica.mblock.*;


/**
 *  An array of CellData objects that appear as one large CellData where
 *  the y value chooses the array entry to use.  This can be used to make
 *  an entire ColumnData's leaf, light, or fluid data look like a contiguous
 *  CellData.
 *
 *  @author    Paul Speed
 */
public class CellDataStack implements CellData {
    private int elementSize;
    private CellData[] array;

    public CellDataStack( int elementSize, CellData... array ) {
        this.elementSize = elementSize;
        this.array = array;
    }

    public int getMaxY() {
        return array.length * elementSize;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        int k = y / elementSize;
        return array[k].getCell(x, y - (k * elementSize), z);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        int k = y / elementSize;
        if( k < 0 || k >= array.length ) {
            return defaultValue;
        }
        return array[k].getCell(x, y - (k * elementSize), z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        int k = y / elementSize;
        if( k < 0 || k >= array.length ) {
            return defaultValue;
        }
        return array[k].getCell(x, y - (k * elementSize), z, dir, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
        int k = y / elementSize;
        if( k < 0 || k >= array.length ) {
            return;
        }
        array[k].setCell(x, y - (k * elementSize), z, value);
    }

}
