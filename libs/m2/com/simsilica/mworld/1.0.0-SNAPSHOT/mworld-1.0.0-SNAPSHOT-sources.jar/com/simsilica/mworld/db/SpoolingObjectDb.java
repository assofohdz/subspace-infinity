/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import org.slf4j.*;

/**
 *  ObjectDb implementation that uses a background thread to spool
 *  object updates to storage.
 *
 *  @author    Paul Speed
 */
public abstract class SpoolingObjectDb<K, V> extends AbstractObjectDb<K, V> {

    public static final long DEFAULT_INTERVAL = 1000;

    static Logger log = LoggerFactory.getLogger(SpoolingObjectDb.class);

    private ConcurrentLinkedQueue<ToStore<K, V>> pending = new ConcurrentLinkedQueue<>();

    // Keep track of the ToStore objects that are already pending but
    // not handled by a thread yet.  Since we are guaranteed that there will
    // only be one instance of V at a time, if the object is already waiting in
    // pending then it's going to get stored with whatever the latest changes are,
    // regardless of when update() is called.
    private ConcurrentHashMap<K, ToStore<K, V>> pendingIndex = new ConcurrentHashMap<>();

    private String name;
    private Spooler spooler;
    private AtomicBoolean running = new AtomicBoolean();
    private long interval;

    public SpoolingObjectDb() {
        this(null, DEFAULT_INTERVAL);
    }

    public SpoolingObjectDb( String name ) {
        this(name, DEFAULT_INTERVAL);
    }

    public SpoolingObjectDb( String name, long interval ) {
        super(name);
        this.name = name;
        this.interval = interval;
    }

    public String getName() {
        return name;
    }

    /**
     *  Starts the thread that will spool data to storage.
     */
    @Override
    public void initialize() {
        if( spooler != null ) {
            log.warn("initialize(): Double initialization");
            return;
        }
        super.initialize();
        if( name == null ) {
            spooler = new Spooler();
        } else {
            spooler = new Spooler(name);
        }
        running.set(true);
        spooler.start();
    }

    /**
     *  Stops the thread that is spooling data to storage after all
     *  current items have been spooled.  Returns once storage has completed.
     */
    @Override
    public void terminate() {
        if( spooler == null ) {
            log.warn("terminate(): Not initialized");
            return;
        }
        running.set(false);
        try {
            spooler.join();
        } catch( InterruptedException e ) {
            throw new RuntimeException("Interrupted waiting for spooler completion:" + spooler, e);
        }
        // spool any remaining items
        spoolAllPending();

        // Setup for re-init
        spooler = null;
        super.terminate();
    }

    /**
     *  Stops the spooling thread immediately after the current item is done
     *  storing and then drops the other pending update requests.
     */
    public void kill() {
        pendingIndex.clear();
        pending.clear();
        running.set(false);

        try {
            spooler.join();
        } catch( InterruptedException e ) {
            throw new RuntimeException("Interrupted waiting for spooler completion:" + spooler, e);
        }

        // Just in case
        pendingIndex.clear();
        pending.clear();

        // Setup for re-init
        spooler = null;
    }

    @Override
    public V get( K key ) {
        if( spooler == null ) {
            throw new IllegalStateException("Not initialized");
        }
        return super.get(key);
    }

    @Override
    public void update( K key, V value ) {
        if( spooler == null ) {
            throw new IllegalStateException("Not initialized");
        } else if( !running.get() ) {
            throw new IllegalStateException("Spooler is shutting down, update requests rejected");
        }
        ToStore<K, V> store = new ToStore<>(key, value);
        if( pendingIndex.putIfAbsent(key, store) == null ) {
            // It's not already in the map
            pending.add(store);

            // Make sure it's in the cache for others to retrieve.  This
            // may have been the first time we've ever seen this key/object...
            // for example, non-generator ObjectDbs that do not create their own
            // objects on demand.  For other DBs, it seems like a small harmless
            // operation.
            // Note: another, perhaps better, approach might be to separate
            // the operation of adding a new object from that of updating an existing
            // one.
            getCache().put(key, value);
        } else {
            if( log.isTraceEnabled() ) {
                log.trace("update already pending for:" + key);
            }
        }
    }

    protected abstract void storeObject( K key, V value );

    protected void spoolAllPending() {
        ToStore<K, V> store = null;
        while( (store = pending.poll()) != null ) {
            pendingIndex.remove(store.key);
            try {
                storeObject(store.key, store.value);
            } catch( Exception e ) {
                // We want to try to continue storing whatever we can
                // so we won't kill the thread just for one bad object.
                log.error("Error storing object:" + store.key, e);
                // FIXME: send an error event to the EventBus and maybe provide a subclass hook
            }
        }
    }

    protected static class ToStore<K, V> {
        private K key;
        private V value;

        public ToStore( K key, V value ) {
            this.key = key;
            this.value = value;
        }
    }

    private class Spooler extends Thread {
        public Spooler() {
        }

        public Spooler( String name ) {
            super(name);
        }

        @Override
        public void run() {
            try {
                while( running.get() ) {
                    try {
                        spoolAllPending();
                    } catch( Exception e ) {
                        // See if it's the thread dying that is killing the spooler
                        log.error("Error spooling", e);
                    } catch( AssertionError e ) {
                        // This is definitely killing the spooler on occasion... in the
                        // case I'm seeing it is LightData's count checks.  Something bad is happening
                        // but I can't see track traces.
                        log.error("Assertion error spooling", e);
                    }
                    try {
                        Thread.sleep(interval);
                    } catch( InterruptedException e ) {
                        if( running.get() ) {
                            log.error("Interrupted while sleeping", e);
                            throw new RuntimeException("Interrupted while sleeping", e);
                        }
                    }
                }
            } catch( Throwable t ) {
                log.error("Spooling thread is dying", t);
            }
        }
    }
}



