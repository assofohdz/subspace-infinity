/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

/**
 *  Represents the version of a piece of loaded data.
 *
 *  @author    Paul Speed
 */
public class DataVersion implements Cloneable {

    static Logger log = LoggerFactory.getLogger(DataVersion.class);

    private long version;
    private long loadVersion;
    private long loadTimestamp;

    public DataVersion() {
        this(0, 0, System.currentTimeMillis());
    }

    public DataVersion( long version ) {
        this(version, version, System.currentTimeMillis());
    }

    public DataVersion( long version, long loadVersion ) {
        this(version, loadVersion, System.currentTimeMillis());
    }

    public DataVersion( long version, long loadVersion, long loadTimestamp ) {
        if( version < loadVersion ) {
            throw new IllegalArgumentException("Version " + version + " cannot be less than load version " + loadVersion);
        }
        this.version = version;
        this.loadVersion = loadVersion;
        this.loadTimestamp = loadTimestamp;
    }

    /**
     *  Returns true if this version represents a "non-persistent" version that should
     *  never be stored or loaded.
     */
    public boolean isTransient() {
        return false;
    }

    public synchronized DataVersion clone() {
        try {
            return (DataVersion)super.clone();
        } catch( CloneNotSupportedException e ) {
            throw new RuntimeException("we know better", e);
        }
    }

    public synchronized boolean isChanged() {
        return version > loadVersion;
    }

    public synchronized void markChanged() {
        version++;
    }

    public synchronized void resetChanged( long loadTimestamp ) {
        this.loadTimestamp = loadTimestamp;
        loadVersion = version;
    }

    public synchronized long getVersion() {
        return version;
    }

    public synchronized long getLoadVersion() {
        return loadVersion;
    }

    public synchronized long getLoadTimestamp() {
        return loadTimestamp;
    }

    public synchronized String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("version", version)
            .add("loadVersion", loadVersion)
            .add("loadTimestamp", loadTimestamp)
            .toString();
    }
}
