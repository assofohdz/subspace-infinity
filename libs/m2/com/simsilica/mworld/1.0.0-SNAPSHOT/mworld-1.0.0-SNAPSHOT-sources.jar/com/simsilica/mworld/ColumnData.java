/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class ColumnData {
    static Logger log = LoggerFactory.getLogger(ColumnData.class);

    /**
     *  Indicates that the side masks have been set for this
     *  column.  Prior to this stage, the side mask data is 0
     *  indicating no visible sides.
     */
    public static final int GEN_SIDE_MASKS = 0x1;

    /**
     *  Indicates that the starting lighting data has been initialized
     *  for the column.  Prior to this stage, all lighting data is null.
     *  This step generally requires that masks have been calculated
     *  as they may be used for the starting sun propagation.
     */
    public static final int GEN_INITIAL_SUNLIGHT = 0x2;

    /**
     *  Indicates whether or not light propagation has been performed
     *  on this column.  This is the stage where all sunlight and local
     *  lights within the column itself have been resolved, including
     *  effects on neighbors.
     */
    public static final int GEN_LIGHT_INTERNAL = 0x4;

    /**
     *  Indicates whether or not light propagation has been performed
     *  from all neighbors, ie: all 8 neighbors have at least the GEN_LIGHT_INTERNAL
     *  bit set.
     */
    public static final int GEN_LIGHT_EXTERNAL = 0x8;

    private ColumnId columnId;
    private Vec3i loc;
    private LeafData[] leafs;
    private FluidData[] fluid;
    private LightData[] lighting;
    private DataVersion version;
    private long generationFlags;

    // This column's branch revision in a revisioned DB.
    private long branchRevision;

    public ColumnData( ColumnId columnId, int size ) {
        this(columnId,
             createLeafData(columnId, size),
             createFluidData(columnId, size),
             createLightData(columnId, size),
             new DataVersion(), 0);
    }

    // For temporary backwards compatibility with demo code
    public ColumnData( ColumnId columnId, LeafData[] leafs,
                       DataVersion version, long generationFlags ) {
        this(columnId, leafs,
             createFluidData(columnId, leafs.length),
             createLightData(columnId, leafs.length),
             version, generationFlags);
    }

    // For temporary backwards compatibility with demo code
    public ColumnData( ColumnId columnId, LeafData[] leafs, LightData[] lighting,
                       DataVersion version, long generationFlags ) {
        this(columnId, leafs, createFluidData(columnId, leafs.length), lighting, version, generationFlags);
    }

    public ColumnData( ColumnId columnId, LeafData[] leafs, FluidData[] fluid, LightData[] lighting,
                       DataVersion version, long generationFlags ) {
        this.columnId = columnId;
        this.leafs = leafs;
        this.fluid = fluid;
        this.lighting = lighting;
        this.loc = columnId.getWorld(null);
        this.version = version;
        this.generationFlags = generationFlags;
    }

    private static LeafData[] createLeafData( ColumnId columnId, int size ) {
        LeafData[] result = new LeafData[size];
        Vec3i world = columnId.getWorld(null);
        for( int i = 0; i < result.length; i++ ) {
            LeafId id = LeafId.fromWorld(world.x, i * LeafId.SIZE, world.z);
            result[i] = new LeafData(id, -1);
        }
        return result;
    }

    private static FluidData[] createFluidData( ColumnId columnId, int size ) {
        FluidData[] result = new FluidData[size];
        Vec3i world = columnId.getWorld(null);
        for( int i = 0; i < result.length; i++ ) {
            LeafId id = LeafId.fromWorld(world.x, i * LeafId.SIZE, world.z);
            result[i] = new FluidData(id);
        }
        return result;
    }

    private static LightData[] createLightData( ColumnId columnId, int size ) {
        LightData[] result = new LightData[size];
        Vec3i world = columnId.getWorld(null);
        for( int i = 0; i < result.length; i++ ) {
            LeafId id = LeafId.fromWorld(world.x, i * LeafId.SIZE, world.z);
            result[i] = new LightData(id);
        }
        return result;
    }

    public int getCeiling() {
        return leafs.length * LeafId.SIZE;
    }

    public void setGenerationFlag( int flag ) {
        generationFlags = generationFlags | flag;
    }

    public boolean hasGenerationFlag( int flag ) {
        return (generationFlags & flag) != 0;
    }

    public void resetGenerationFlags( long generationFlags ) {
        this.generationFlags = generationFlags;
    }

    public long getGenerationFlags() {
        return generationFlags;
    }

    public void resetChanged( long timestamp ) {
        version.resetChanged(timestamp);
        if( leafs != null ) {
            for( LeafData leaf : leafs ) {
                if( leaf != null ) {
                    leaf.getInfo().version.resetChanged(timestamp);
                }
            }
        }
    }

    public ColumnId getColumnId() {
        return columnId;
    }

    public DataVersion getVersion() {
        return version;
    }

    /**
     *  Used by a revision-based database to keep track of the branch for this
     *  column data instance.
     */
    public long getBranchRevision() {
        return branchRevision;
    }

    /**
     *  Called by a revision-based database to set the proper branch revision before
     *  saving.  This should only be called internally or under very special circumstances
     *  and always in a case where a column lock is acquired.
     */
    public void setBranchRevision( long branchRevision ) {
        this.branchRevision = branchRevision;
    }

    public LeafData getLeafData( int yWorld ) {
        if( yWorld < 0 ) {
            return null;
        }
        int layer = yWorld / LeafId.SIZE;
        if( layer >= leafs.length || layer < 0 ) {
            //log.warn("getLeafData(" + yWorld + ") layer:" + layer + " exceeds max layer:" + leafs.length);
            return null;
        }
        return leafs[layer];
    }

    public LeafData[] getLeafs() {
        return leafs;
    }

    public LightData getLightData( int yWorld ) {
        if( yWorld < 0 ) {
            return null;
        }
        int layer = yWorld / LeafId.SIZE;
        if( layer >= lighting.length || layer < 0 ) {
            //log.warn("getLightData(" + yWorld + ") layer:" + layer + " exceeds max layer:" + leafs.length);
            return null;
        }
        return lighting[layer];
    }

    public LightData[] getLighting() {
        return lighting;
    }

    public FluidData getFluidData( int yWorld ) {
        if( yWorld < 0 ) {
            return null;
        }
        int layer = yWorld / LeafId.SIZE;
        if( layer >= fluid.length || layer < 0 ) {
            //log.warn("getFluidData(" + yWorld + ") layer:" + layer + " exceeds max layer:" + leafs.length);
            return null;
        }
        return fluid[layer];
    }

    public FluidData[] getFluid() {
        return fluid;
    }

    public void setData( ColumnData data ) {
        for( int i = 0; i < leafs.length; i++ ) {
            leafs[i].setData(data.leafs[i]);
        }
        for( int i = 0; i < fluid.length; i++ ) {
            fluid[i].setData(data.fluid[i]);
        }
        for( int i = 0; i < lighting.length; i++ ) {
            lighting[i].setData(data.lighting[i]);
        }
        generationFlags = data.generationFlags;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[loc:" + loc + ", id:" + columnId + ", instance:" + System.identityHashCode(this) + "]";
    }
}


