/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mworld.TileId;
import com.simsilica.mworld.tile.ColumnStates;


/**
 *
 *
 *  @author    Paul Speed
 */
public class ColumnStatesProtocol {
    static Logger log = LoggerFactory.getLogger(ColumnStatesProtocol.class);

    private int version = 1;

    public ColumnStatesProtocol() {
    }

    public void write( ColumnStates state, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(state, out);
        } finally {
            out.close();
        }
    }

    public ColumnStates read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }

    public void write( ColumnStates state, BitOutputStream out ) throws IOException {
        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        out.writeLongBits(state.getTileId().getId(), 64);

        // Get a stabilized set so that the size doesn't change while we iterate
        Set<Short> ids = new TreeSet<>(state.getTileLocalColumnIds());
        out.writeBits(ids.size(), 10); // can never be more than 32x32
        for( Short s : ids ) {
            out.writeBits(s, 10);
        }
    }

    public ColumnStates read( BitInputStream in ) throws IOException {
        int version = in.readBits(16);

        TileId tileId = new TileId(in.readLongBits(64));
        ColumnStates result = new ColumnStates(tileId);

        int count = in.readBits(10);
        for( int i = 0; i < count; i++ ) {
            short s = (short)in.readBits(10);
            result.getTileLocalColumnIds().add(s);
        }

        return result;
    }

}


