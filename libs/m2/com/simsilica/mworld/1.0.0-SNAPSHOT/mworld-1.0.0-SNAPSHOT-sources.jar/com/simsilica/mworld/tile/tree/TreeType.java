/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import java.util.Random;

import com.simsilica.mworld.ColumnData;
import com.simsilica.mworld.CellGenType;
import com.simsilica.mworld.tile.TerrainImage;

/**
 *  The insert and factory functions for a certain type of Tree.
 *
 *  @author    Paul Speed
 */
public interface TreeType {

    public static final int TREE_BITS = CellGenType.Flora.apply(0);

    /**
     *  The unique name for this tree type.
     */
    public String getName();

    /**
     *  Sets this types TreeTypeIndex index value.  This should only be
     *  called by the TreeTypeIndex when the type is registered.
     */
    public void setIndex( short index );

    /**
     *  This type's index in the TreeTypeIndex.
     */
    public short getIndex();

    /**
     *  Returns the atlas index information appropriate for far LOD rendering
     *  the specified tree.
     */
    public AtlasCell getAtlasCell( Tree tree );

    /**
     *  Initializes the tree type, basically letting it look up any block
     *  types that it might need, etc..
     */
    public void initialize( TreeTypeIndex treeTypes );

    /**
     *  Creates an instance of a tree at the specified location, randomized
     *  as appropriate for the terrain type, terrain, etc..
     */
    public Tree createTree( short x, short y, short z, TerrainImage terrain, Random random );

    /**
     *  Marks the appropriate slots in the 'used' array for this particular
     *  type of tree.  Returns true if values were actually changed.
     */
    public boolean markTree( Tree tree, boolean[][] used );

    /**
     *  Inserts the tree data into the specified Column.  Returns true
     *  if data was actually changed.
     */
    public boolean insertTree( Tree tree, TileColumnCells colData, Random random );

    /**
     *  Modifies the specified TerrainImage to support the tree.  This
     *  may mean splatting down additional 'foliage' markers or even
     *  some carving depending on the tree type.  Returns true if data
     *  was actually changed.
     */
    public boolean insertTree( Tree tree, TerrainImage terrain );

    /**
     *  Returns true if the specified block is likely part of the specified
     *  tree.  The location is relative to the tree's own location.
     *  (This negates any worry about which origin, tile, column, etc. considering
     *  that a tree may span any of those... by keeping it relative to the tree
     *  itself, all guessing is removed.)
     */
    public boolean isBlock( Tree tree, int x, int y, int z, int type ); 
}
