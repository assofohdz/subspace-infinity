/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.pc;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.*;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.progress.*;


/**
 *  Manages the generation of PointCloudLayers by querying and watching
 *  the TileManager.  PointCloudLayers are generated as a post-processing
 *  step and managed separately from the normal Tile layers.
 *
 *  @author    Paul Speed
 */
public class PointCloudManager {
    static Logger log = LoggerFactory.getLogger(PointCloudManager.class);

    private File root;
    private PointCloudDb pointCloudDb;
    private ObservableColumnDb columnDb;
    private TileManager tiles;
    private TerrainImageManager terrainMgr;

    private PointIndexFunction pointIndexFunction;

    private ColumnStatesDb colStates;

    private CopyOnWriteArrayList<TileListener> listeners = new CopyOnWriteArrayList<>();

    public PointCloudManager( File root, ObservableColumnDb columnDb, TileManager tiles, TerrainImageManager terrainMgr ) {
        this.root = root;

        this.pointCloudDb = new PointCloudDb(root);
        this.colStates = new ColumnStatesDb(root, "pc.state");

        // set a default that will treat everything as terrain
        pointIndexFunction = new PointIndexFunction() {
                private PointType defaultType = new PointType((byte)0);

                @Override
                public PointIndex getPointIndex( int rawType, int type, PointIndex target ) {
                    if( target == null ) {
                        target = new PointIndex();
                    }

                    return null;
                }
            };


        // So we know when to mark columns dirty
        this.columnDb = columnDb;

        // So we know what the initial dirty columns should be
        this.tiles = tiles;

        this.terrainMgr = terrainMgr;

        // Add observers
        columnDb.addColumnChangeListener( (event) -> { markDirty(event.getColumnId()); } );

    }

    public TileManager getTileManager() {
        return tiles;
    }

    public void addTileListener( TileListener l ) {
        listeners.add(l);
    }

    public void removeTileListener( TileListener l ) {
        listeners.remove(l);
    }

    public void setPointIndexFunction( PointIndexFunction pointIndexFunction ) {
        this.pointIndexFunction = pointIndexFunction;
    }

    public PointIndexFunction getPointIndexFunction() {
        return pointIndexFunction;
    }

    public void initialize() {
        colStates.initialize();
        pointCloudDb.initialize();
    }

    public void terminate() {
        pointCloudDb.terminate();
        colStates.terminate();
    }

    protected boolean initializeStates( TileId id, ColumnStates states ) {
        boolean changed = false;
        // FIXME: find a better way to initialize the starting column states
//        com.simsilica.mworld.tile.Tile tile = tiles.getTile(id, Resolution.High);
//        StructureLayer structures = tile.get(StructureLayer.class);
//        for( Short s : structures.getActiveBinIds() ) {
//            if( states.markDirty(s) ) {
//                changed = true;
//            }
//        }
//
//        if( changed ) {
//            // As a hack, make sure the terrain image is also up to date
//            TerrainImage image = terrainMgr.getTerrainImage(id, TerrainImageType.Terrain, Resolution.High);
//        }

        return changed;
    }

    protected boolean updateColumns( PointCloudLayer result, ColumnStates states ) {

        if( states.isValid() ) {
            return false;
        }

        Vec3i origin = result.getTileId().getWorld(null);
        String name = String.format("Low LOD: %d, %d update", origin.x, origin.z);
        ProgressTracker progress = ProgressTrackers.openTracker(name);
        try {
            boolean changed = false;
            progress.setMax(states.size());

            // Regular state updates
            for( Iterator<ColumnId> it = states.getDirtyColumns().iterator(); it.hasNext(); ) {
                ColumnId colId = it.next();
                it.remove();
                if( log.isTraceEnabled() ) {
                    log.trace("  update column:" + colId);
                }

                long start = System.nanoTime();
                ColumnData col = columnDb.getColumn(colId);
                if( log.isTraceEnabled() ) {
                    log.trace("  loaded:" + col);
                }
                long end = System.nanoTime();
                log.info(String.format("Loaded column %s in %.2f ms", String.valueOf(colId), (end-start)/1000000.0));

                start = System.nanoTime();
                Map<PointType, List<Point>> points = extractPoints(col);
                end = System.nanoTime();
                if( log.isTraceEnabled() ) {
                    log.trace(String.format("Extracted points in %.2f ms", (end-start)/1000000.0));
                }

                if( !points.isEmpty() ) {
                    Vec3i local = colId.getWorld(null).subtract(origin);
                    PointCloudData pc = new PointCloudData(local.x, local.z);

                    for( Map.Entry<PointType, List<Point>> e : points.entrySet() ) {
                        List<Point> list = e.getValue();
                        if( list.isEmpty() ) {
                            continue;
                        }
                        pc.setPoints(e.getKey(), list.toArray(new Point[0]));
                    }

                    result.updatePointCloud(pc);

                    changed = true;
                }
                progress.increment();
            }
            return changed;
        } finally {
            progress.close(true);
        }
    }

    public PointCloudLayer getPointCloud( TileId id, Resolution res ) {
        // For now we'll only support high res
        if( res != Resolution.High ) {
            throw new UnsupportedOperationException("Only high resolution is supported");
        }

        Vec3i origin = id.getWorld(null);
        // 2023-12-19 - removing progress tracker from this level as I think it's
        // superfluous today and adds a lot of progress-tracking logs even when there
        // isn't any work to be done.  updateColumns() is already tracking progress
        // and that's where the real work happens.
        // If there's ever a case where initializeStates() does work again then maybe
        // it makes sense to put it back.  But somehow, today, states seem to be getting
        // dirtied appropriately without the extra step.
        //String name = String.format("Low LOD: %d, %d", origin.x, origin.z);
        //ProgressTracker progress = ProgressTrackers.openTracker(name);
        //try {
            //progress.setMax(4);

            // It shouldn't matter if we grab this before synchronizing
            // ...at least I'm pretty sure.
            PointCloudLayer result = pointCloudDb.get(id);
            //progress.increment();

            // Grab the column states for this column
            ColumnStates states = colStates.get(id);
            synchronized(states) {
                //progress.increment();

                // See if we need to initialize the states from generated
                // tiles, ie: the first time we've been here
                if( result.getVersion().getLoadVersion() < 0 ) {
                    // Synchronizing on the states performs double-duty...
                    // not only will we have safe access to the states object
                    // but we'll guard against other getPointCloud() calls that
                    // also see the version == 0.
                    // Initial load so see if we need to dirty the state
                    initializeStates(id, states);
                }
                //progress.increment();

                if( updateColumns(result, states) ) {

                    // All caught up... write it back to disk
                    colStates.update(id, states);

                    // Move the version along and spool the point cloud
                    // note: we spool this data but we don't spool the column states.
                    // It's theoretically possible that our point cloud data could therefore
                    // be behind.
                    result.getVersion().markChanged();
                    pointCloudDb.update(id, result);
                }
                //progress.increment();
            }

            return result;
        //} finally {
        //    progress.close(true);
        //}
    }

    protected void markDirty( ColumnId colId ) {
        TileId tileId = colId.getTileId();
        if( log.isTraceEnabled() ) {
            log.trace("markDirty(" + colId + ") in tile:" + tileId);
        }
        colStates.markDirty(colId);

        // Notify the listeners
        TileChangeEvent event = new TileChangeEvent(PointCloudLayer.class, tileId, Integer.MAX_VALUE, Resolution.High);
        for( TileListener l : listeners ) {
            l.tileChanged(event);
        }
    }

    protected Map<PointType, List<Point>> extractPoints( ColumnData col ) {

        Map<PointType, List<Point>> result = new HashMap<>();

        List<Point> points = new ArrayList<>();
        result.put(new PointType((byte)0), points);

        // We're going to assume that the TerrainLayer is doing its
        // own updates but we should not count on them in our algorithm
        // if we can avoid it.

        // Basic approach, work our way down from the top and
        // add any non-terrain block types until we reach terrain.
        // In the future we may need to disambiguate floating terrain
        // from ground terrain... but that is tomorrow's problem.

        // Keep an array for the x,z values where we hit ground already
        // and can stop looking.
        boolean[][] ground = new boolean[LeafInfo.SIZE][LeafInfo.SIZE];
        int groundLeft = LeafInfo.SIZE * LeafInfo.SIZE;

        LeafData[] leafs = col.getLeafs();

//long start = System.nanoTime();
        // An expensive non-lazy way... need something better. FIXME
        //ColumnLightData lighting = ColumnLightData.loadNeighborhood(columnDb, col, false);
        // Well, hopefully column neighborhood is lazy enough to negate that
        // comment but I'll leave it for now.  2021-10-29
        CellData lighting = new ColumnNeighborhood(columnDb, col).getLightingCellData();

        PointIndex pointIndex = new PointIndex();

        for( int i = leafs.length - 1; i >= 0; i-- ) {
            LeafData leaf = leafs[i];
            int yBase = i * LeafInfo.SIZE;
            if( leaf.isEmpty() ) {
                continue;
            }
            CellData leafLight = new OffsetCellData(lighting, 0, yBase, 0);
            for( int x = 0; x < LeafInfo.SIZE; x++ ) {
                for( int z = 0; z < LeafInfo.SIZE; z++ ) {
                    if( ground[x][z] ) {
                        continue;
                    }
                    for( int y = LeafInfo.SIZE -1; y >= 0; y-- ) {
                        int val = leaf.getCell(x, y, z);
                        int type = MaskUtils.getType(val);
                        if( type == 0 ) {
                            continue;
                        }

                        int sideMask = MaskUtils.getSideMask(val);
                        if( sideMask == 0 ) {
                            continue;
                        }
                        PointIndex index = pointIndexFunction.getPointIndex(val, type, pointIndex);
                        if( index == null ) {
                            // We've hit ground and should stop searching this cell column
                            ground[x][z] = true;
                            groundLeft--;
                            break;
                        }
                        if( index.type == null ) {
                            // Just a skipped type
                            continue;
                        }

                        int light = 0; //0xff00;
                        // Need to find the best light to use.  For lack of
                        // anything else, we'll use 'most sunlight' as an indicator
                        // to get the lighting that is most likely facing outward
                        // rather than inside the structure.
                        int mostSun = 0;
                        for( Direction dir : Direction.values() ) {
                            if( (sideMask & dir.getBitMask()) == 0 ) {
                                // This side isn't visible
                                continue;
                            }
                            int local = leafLight.getCell(x, y, z, dir, -1);
                            if( local == -1 ) {
                                continue;  // weird
                            }
                            int sun = LightUtils.sun(local);
                            if( sun > mostSun ) {
                                light = local;
                                mostSun = sun;
                            }
                        }

                        // Else add it to the points
                        points.add(new Point(x, yBase + y, z, index.index, (short)light, sideMask));
                    }
                }
            }
            if( groundLeft <= 0 ) {
                break;
            }
        }

        return result;
    }
}
