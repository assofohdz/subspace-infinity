/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.io.IOException;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;
import com.simsilica.mathd.*;
import com.simsilica.mworld.io.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class BoxFillProtocol implements ObjectProtocol<BoxFill> {

    static Logger log = LoggerFactory.getLogger(BoxFillProtocol.class);

    public static final int X_BITS = 32;
    public static final int Y_BITS = 10;
    public static final int Z_BITS = 32;

    public static final int BLOCK_FILL_BITS = 16;
    public static final int TERRAIN_FILL_BITS = 16;

    private int version = 0;

    public BoxFillProtocol() {
    }

    public int getProtocolVersion() {
        return version;
    }

    public void write( BoxFill data, BitOutputStream out ) throws IOException {

        out.writeBits(version, 8); // we can have 255 versions while embedded in the object protocol

        Vec3i min = data.getMin();
        Vec3i max = data.getMax();
        out.writeBits(min.x, X_BITS);
        out.writeBits(min.y, Y_BITS);
        out.writeBits(min.z, Z_BITS);
        out.writeBits(max.x, X_BITS);
        out.writeBits(max.y, Y_BITS);
        out.writeBits(max.z, Z_BITS);

        out.writeBits(data.getBlockFill(), BLOCK_FILL_BITS);
        out.writeBits(data.getTerrainFill(), TERRAIN_FILL_BITS);
    }

    public BoxFill read( BitInputStream in ) throws IOException {
        int version = in.readBits(8);

        int x = in.readBits(X_BITS);
        int y = in.readBits(Y_BITS);
        int z = in.readBits(Z_BITS);
        Vec3i min = new Vec3i(x, y, z);

        x = in.readBits(X_BITS);
        y = in.readBits(Y_BITS);
        z = in.readBits(Z_BITS);
        Vec3i max = new Vec3i(x, y, z);

        int blockFill = in.readBits(BLOCK_FILL_BITS);
        byte terrainFill = (byte)in.readBits(TERRAIN_FILL_BITS);

        return new BoxFill(min, max, blockFill, terrainFill);
    }
}
