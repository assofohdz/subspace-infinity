/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.BlockDataId;
import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.io.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class InsertLayerProtocol implements ObjectProtocol<InsertLayer> {
    static Logger log = LoggerFactory.getLogger(InsertLayerProtocol.class);

    // 42 is the original version.
    // 43 includes the generation level
    // 44 increases the bits for location
    private int version = 44;
    
    private ProtocolSerializers protocols = new ProtocolSerializers();

    public InsertLayerProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return version;
    }

    @Override
    public void write( InsertLayer data, BitOutputStream out ) throws IOException {
        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        // Header stuff
        TileId tileId = data.getTileId();
        Vec3i tileOrigin = tileId.getWorld(null);
        long id = tileId.getId();
        out.writeLongBits(id, 64);
        out.writeLongBits(data.getVersion().getVersion(), 64);
        out.writeBits(data.getGenerationLevel(), 8);

        List<BlockInsert> inserts = data.getInserts();
        int size = inserts.size();
        out.writeBits(size, 32);

        for( BlockInsert insert : inserts ) {
            writeInsert(insert, tileOrigin, out);
        }
    }

    @Override
    public InsertLayer read( BitInputStream in ) throws IOException {
        int version = in.readBits(16);
        // Could check version to see if we need to read in a special way

        // Read the header and create the tile
        TileId tileId = new TileId(in.readLongBits(64));
        Vec3i tileOrigin = tileId.getWorld(null);
        long dataVersion = in.readLongBits(64);

        int generationLevel = 0;
        if( version >= 43 ) {
            // Then we can read the generation level
            generationLevel = in.readBits(8);
        }

        int size = in.readBits(32);

        List<BlockInsert> inserts = new ArrayList<>(size);
        for( int i = 0; i < size; i++ ) {
            BlockInsert insert = readInsert(tileOrigin, version, in);
            inserts.add(insert);
        }

        return new InsertLayer(tileId, new DataVersion(dataVersion), generationLevel, inserts);
    }

    public void write( InsertLayer morphs, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(morphs, out);
        } finally {
            out.close();
        }
    }

    public InsertLayer read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }


    protected void writeInsert( BlockInsert insert, Vec3i tileOrigin, BitOutputStream out ) throws IOException {

        // Tile-relative coordinates can be stored in way fewer bits.
        // Else it would take 192 bits (64*3... 24 bytes) to store just
        // the location.  Tile-relative we can do it in 192 bits, ~4 bytes
        int x = insert.world.x - tileOrigin.x;
        int y = insert.world.y;
        int z = insert.world.z - tileOrigin.z;
        // Except we need to be able to store x,z locations that are negative so
        // we will need one extra bit to have +/- 1024 instead of just 1024.
        // We don't need the full range for negatives but there's nothing we
        // can do about that.  (We don't need the full range because we'll never
        // be more than negative size which is limited to 7 bits.)
        out.writeBits(x, 11);
        out.writeBits(y, 10);
        out.writeBits(z, 11);

        out.writeLongBits(insert.blockDataId.getId(), 64);

        out.writeBits(insert.carveFlags, 8); // we are only using 5 bits right now

        out.writeBits(insert.xSize, 7); // we don't allow negative bytes so we don't store bit 8
        out.writeBits(insert.ySize, 7);
        out.writeBits(insert.zSize, 7);

        out.writeBits(insert.aboveGround ? 1 : 0, 1);
        out.writeBits(insert.groundLevel, 7);

        // There could be a case where we spam inserts for small things like
        // road/path parts and we don't feel like paying the 4-byte per insert
        // price for object IDs.  So we'll eat 1 bit for a flag.
        if( insert.objectId >= 0 ) {
            out.writeBits(1, 1);
            out.writeLongBits(insert.objectId, 64);
        } else {
            out.writeBits(0, 1);
        }

        // 111 - 175 bits (13.875 - 21.875 bytes) per insert
    }

    protected BlockInsert readInsert( Vec3i tileOrigin, int version, BitInputStream in ) throws IOException {
        int x;
        int y;
        int z;
        if( version > 43 ) {
            x = in.readBits(11);
            if( (x & 0b10000000000) != 0 ) {
                x = x | 0b11111111111111111111110000000000; 
            }
            y = in.readBits(10);
            z = in.readBits(11);
            if( (z & 0b10000000000) != 0 ) {
                z = z | 0b11111111111111111111110000000000; 
            }
        } else {
            x = in.readBits(10);
            y = in.readBits(10);
            z = in.readBits(10);
        }
        x += tileOrigin.x;
        z += tileOrigin.z;

        long id = in.readLongBits(64);
        BlockDataId blockDataId = new BlockDataId(id);

        int carveFlags = in.readBits(8);

        int xSize = in.readBits(7); // we don't allow negative bytes so we don't store bit 8
        int ySize = in.readBits(7);
        int zSize = in.readBits(7);

        boolean aboveGround = in.readBits(1) == 1;
        int groundLevel = in.readBits(7);

        BlockInsert result = new BlockInsert(new Vec3i(x, y, z), blockDataId, carveFlags,
                                             xSize, ySize, zSize,
                                             aboveGround, groundLevel,
                                             -1);

        int hasObjectId = in.readBits(1);
        if( hasObjectId == 1 ) {
            result.objectId = in.readLongBits(64);
        }

        return result;
    }
}


