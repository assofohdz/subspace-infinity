/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.pc;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.io.*;
import com.simsilica.mworld.tile.pc.*;

//import com.simsilica.mworld.tile.pc.*;
//import com.simsilica.demo.world.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PointCloudDataProtocol {

    static Logger log = LoggerFactory.getLogger(PointCloudDataProtocol.class);

    private int version = 1;
    private int xBits;
    private int yBits;
    private int zBits;

    public PointCloudDataProtocol() {
        this(5, 10, 5);
    }

    public PointCloudDataProtocol( int xBits, int yBits, int zBits ) {
        this.xBits = xBits;
        this.yBits = yBits;
        this.zBits = zBits;
    }

    public void write( PointCloudData pc, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(pc, out);
        } finally {
            out.close();
        }
    }

    public PointCloudData read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }

    public void write( PointCloudData pc, BitOutputStream out ) throws IOException {
        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        out.writeBits(pc.getOriginX(), 10); //0..1023
        out.writeBits(pc.getOriginZ(), 10); //0..1023

        Map<PointType, Point[]> points = pc.getPoints();
        out.writeBits(points.size(), 8);
        for( Map.Entry<PointType, Point[]> e : pc.getPoints().entrySet() ) {
            out.writeBits(e.getKey().getTypeIndex(), 8); // up to 255 different point types... way more than needed
            writePoints(e.getValue(), out);
        }
    }

    public PointCloudData read( BitInputStream in ) throws IOException {
        int version = in.readBits(16);

        int xOrigin = in.readBits(10);
        int zOrigin = in.readBits(10);

        PointCloudData result = new PointCloudData(xOrigin, zOrigin);

        int layerCount = in.readBits(8);
        for( int i = 0; i < layerCount; i++ ) {
            byte typeIndex = (byte)in.readBits(8);
            Point[] points = readPoints(in);
            result.setPoints(new PointType(typeIndex), points);
        }

        return result;
    }

    protected void writePoints( Point[] array, BitOutputStream out ) throws IOException {

        // In theory there could be more than half million points in the very
        // very worst case.  But probably it will be in the several thousand
        // range or less.  We could use a bit encoding to trigger different
        // sizes but today I will do it the easy way and pick a reasonable
        // bit size.  19 bits gets us 524,000 values.

        int size = array.length;
        int maxSize = 0b1111111111111111111;
        if( size > maxSize ) {
            log.error("Point cloud size exceeds 19 bits, size:" + size + "  max:" + maxSize + "  Clamping.");
            // At least avoid wrapping and cutting things off
            size = maxSize;
        }

        out.writeBits(size, 19);

        for( Point p : array ) {
            writePoint(p, out);
        }
    }

    protected Point[] readPoints( BitInputStream in ) throws IOException {
        int size = in.readBits(19);
        Point[] points = new Point[size];

        for( int i = 0; i < size; i++ ) {
            points[i] = readPoint(in);
        }
        return points;
    }

    public void writePoint( Point p, BitOutputStream out ) throws IOException {
        out.writeBits(p.x, xBits);
        out.writeBits(p.y, yBits);
        out.writeBits(p.z, zBits);
        out.writeBits(p.index, 8);
        out.writeBits(p.light, 16);
        out.writeBits(p.direction, 6);
    }

    public Point readPoint( BitInputStream in ) throws IOException {
        Point p = new Point();
        p.x = (byte)in.readBits(xBits);
        p.y = (short)in.readBits(yBits);
        p.z = (byte)in.readBits(zBits);
        p.index = (byte)in.readBits(8);
        p.light = (short)in.readBits(16);
        p.direction = (byte)in.readBits(6);
        return p;
    }

}

