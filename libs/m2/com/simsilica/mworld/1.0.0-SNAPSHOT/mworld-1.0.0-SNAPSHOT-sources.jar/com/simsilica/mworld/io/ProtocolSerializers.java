/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;
import java.util.*;
import java.util.zip.*;

import org.slf4j.*;

// Bitstreams are cool
import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.io.BlockTypeData;
import com.simsilica.mblock.io.FluidTypeData;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.TerrainImage;
import com.simsilica.mworld.tile.io.TerrainImageProtocol;
import com.simsilica.mworld.tile.pc.PointCloudLayer;
import com.simsilica.mworld.tile.pc.PointCloudLayerProtocol;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.mworld.tile.tree.TreeLayerProtocol;
import com.simsilica.mworld.tile.tree.TreeTypeIndex;

/**
 *  ObjectProtocol handlers registered by type with some convenience
 *  methods for different kinds of read/write scenarios.
 *
 *  @author    Paul Speed
 */
public class ProtocolSerializers {
    static Logger log = LoggerFactory.getLogger(ProtocolSerializers.class);

    private Map<Class, ObjectProtocol> protocols = new HashMap<>();

    public ProtocolSerializers() {
        this(true);
    }

    public ProtocolSerializers( boolean registerDefaults ) {
        if( registerDefaults ) {
            registerProtocol(LeafData.class, new LeafDataProtocol());
            registerProtocol(LightData.class, new LightDataProtocol());
            registerProtocol(FluidData.class, new FluidDataProtocol());
            registerProtocol(PointCloudLayer.class, new PointCloudLayerProtocol());
            registerProtocol(TerrainImage.class, new TerrainImageProtocol());
            registerProtocol(TreeLayer.class, new TreeLayerProtocol());
            registerProtocol(CellChangeEvent.class, new CellChangeEventProtocol());
            registerProtocol(BlockTypeData.class, new BlockTypeDataProtocol());
            registerProtocol(FluidTypeData.class, new FluidTypeDataProtocol());
            registerProtocol(TreeTypeIndex.class, new TreeTypeIndexProtocol());
        }
    }

    public <T> void registerProtocol( Class<T> type, ObjectProtocol<T> protocol ) {
        protocols.put(type, protocol);
    }

    @SuppressWarnings("unchecked")
    public <T> ObjectProtocol<T> getProtocol( Class<T> type ) {
        return (ObjectProtocol<T>)protocols.get(type);
    }

    @SuppressWarnings("unchecked")
    public void write( Object data, BitOutputStream out ) throws IOException {
        ObjectProtocol protocol = protocols.get(data.getClass());
        if( protocol == null ) {
            throw new IllegalArgumentException("No ObjectProtocol found for type:" + data.getClass());
        }
        protocol.write(data, out);
    }

    public <T> T read( Class<T> type, BitInputStream in ) throws IOException {
        ObjectProtocol protocol = protocols.get(type);
        if( protocol == null ) {
            throw new IllegalArgumentException("No ObjectProtocol found for type:" + type);
        }
        return type.cast(protocol.read(in));
    }

    @SuppressWarnings("unchecked")
    public byte[] toBytes( Object data, boolean zipped ) throws IOException {

        ObjectProtocol protocol = protocols.get(data.getClass());
        if( protocol == null ) {
            throw new IllegalArgumentException("No ObjectProtocol found for type:" + data.getClass());
        }

        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        BitOutputStream out;
        if( zipped ) {
            out = new BitOutputStream(new BufferedOutputStream(new GZIPOutputStream(bOut)));
        } else {
            out = new BitOutputStream(new BufferedOutputStream(bOut));
        }
        try {
            protocol.write(data, out);
        } finally {
            out.close();
        }
        return bOut.toByteArray();
    }

    public <T> T fromBytes( Class<T> type, byte[] bytes, boolean zipped ) throws IOException {
        ObjectProtocol protocol = protocols.get(type);
        if( protocol == null ) {
            throw new IllegalArgumentException("No ObjectProtocol found for type:" + type);
        }
        ByteArrayInputStream bIn = new ByteArrayInputStream(bytes);
        BitInputStream in;
        if( zipped ) {
            in = new BitInputStream(new BufferedInputStream(new GZIPInputStream(bIn)));
        } else {
            // Shouldn't need a buffer since the byte array input stream is basically
            // only buffer.
            in = new BitInputStream(bIn);
        }
        try {
            return type.cast(protocol.read(in));
        } finally {
            in.close();
        }
    }

    public List<byte[]> toPackets( Object data, int packetSize, boolean zipped ) {
        try {
            // For now we'll chop up the byte array when we're done but we
            // should write an OutputStream that does it for us as we write.
            byte[] buffer = toBytes(data, zipped);
            if( buffer.length < packetSize ) {
                return Arrays.asList(buffer);
            }

            // Else chop it up
            int count = buffer.length / packetSize;
            if( (buffer.length % packetSize) != 0 ) {
                count++;
            }
            List<byte[]> results = new ArrayList<>(count);
            int bytesRemaining = buffer.length;
            for( int i = 0; i < count; i++ ) {
                int size = Math.min(packetSize, bytesRemaining);
                byte[] packet = new byte[size];
                System.arraycopy(buffer, i * packetSize, packet, 0, size);
                results.add(packet);
                bytesRemaining -= size;
            }
            assert bytesRemaining == 0 : "Mismatched bytes remaining";

            return results;
        } catch( IOException e ) {
            throw new RuntimeException("Error converting to packets:" + data, e);
        }
    }

    public <T> T fromPackets( Class<T> type, List<byte[]> packets, boolean zipped ) {

        try {
            // For now, we'll unchop the array but we should write an
            // InputStream that takes the list of byte[] packets instead
            int size = 0;
            for( byte[] packet : packets ) {
                size += packet.length;
            }
            byte[] buffer = new byte[size];
            int pos = 0;
            for( byte[] packet : packets ) {
                System.arraycopy(packet, 0, buffer, pos, packet.length);
                pos += packet.length;
            }

            return fromBytes(type, buffer, zipped);
        } catch( IOException e ) {
            throw new RuntimeException("Error converting from packets, type:" + type, e);
        }
    }
}


