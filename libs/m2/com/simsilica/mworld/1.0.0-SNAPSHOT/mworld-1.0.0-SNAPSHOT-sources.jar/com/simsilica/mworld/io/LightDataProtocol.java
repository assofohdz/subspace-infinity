/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class LightDataProtocol implements ObjectProtocol<LightData> {
    private int protocolVersion = 1;

    // We use this just for the RLE stuff.
    private CellArrayProtocol cellProtocol = new CellArrayProtocol();
    
    public LightDataProtocol() {
    }
    
    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }
    
    @Override
    public void write( LightData lightData, BitOutputStream out ) throws IOException {
        // Assumes any necessary protocol version information was already written
 
        assert lightData.checkCounts();    
 
        // Even though the version is redundant in our actual use-case,
        // it improves the flexibility of this class and maybe provides a bit
        // of error detection if we go ahead and write it out for every object.
        // It also means that we could technically have different protocol
        // versions per leaf if we ever need it for some dumb reason.
        // I mean, technically the light ID is redundant, too.
        // We support up to 256 versions... beyond that the protocol
        // will have to adapt to read another byte.
        out.writeBits(protocolVersion, 8);

        // ID is all the location information that we need            
        out.writeLongBits(lightData.getLeafId().getId(), 64);
        
        // LightData doesn't have a version yet... neither does LeafData
        // and I need to think more deeply about whether we need it.
        // Use a placeholder for now so we can add it later if we want to
        out.writeLongBits(-1, 64);        
 
        out.writeBits(lightData.getSunCellCount(), 16); // 1 bit more than we need, actually.
        out.writeBits(lightData.getEmptyCellCount(), 16); // 1 bit more than we need, actually.
            
        int[] array = lightData.getArray();
        if( array == null ) {
            // Write a null marker
            out.writeBits(0, 1);
            return;
        }
        // Write a not nul marker
        out.writeBits(1, 1);

        // Write the light data... it's only possible for it to be 16 bits.
        // 4, 4, 4, 4 : sun, red, green, blue
        // We write all 32 bits for now so that we still have the upper bits
        // available for something else later.
        cellProtocol.writeRleData(array, 0xffffffff, 0, 32, out);    
    }
    
    @Override
    public LightData read( BitInputStream in ) throws IOException {
 
        // Read the protocol version that was used to store the data
        int version = in.readBits(8);
 
        // Read the LeafInfo           
        LeafId leafId = new LeafId(in.readLongBits(64));
 
        long dataVersion = in.readLongBits(64);                
            
        // Read the cell data
        int sunCellCount = in.readBits(16);
        int emptyCellCount = in.readBits(16);
            
        int nullBit = in.readBits(1);
        if( nullBit == 0 ) {
            return new LightData(leafId, null, emptyCellCount, sunCellCount);
        }
            
        CellArray cells = new CellArray(LeafId.SIZE);
            
        // Read the light data
        cellProtocol.readRleData(cells.getArray(), 0xffffffff, 0, 32, in);
        
        return new LightData(leafId, cells, emptyCellCount, sunCellCount);           
    }
        
}


