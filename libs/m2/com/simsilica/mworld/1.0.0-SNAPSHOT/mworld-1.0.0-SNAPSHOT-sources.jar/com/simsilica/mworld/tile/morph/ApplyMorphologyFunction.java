/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import org.slf4j.*;

import com.simsilica.mworld.tile.*;

/**
 *  For supplied tiles, looks up the morphology layer and applies it if
 *  it exists.
 *
 *  @author    Paul Speed
 */
public class ApplyMorphologyFunction implements TileFunction {
    static Logger log = LoggerFactory.getLogger(ApplyMorphologyFunction.class);

    public ApplyMorphologyFunction() {
    }

    @Override
    public void accept( Tile tile ) {
        MorphologyLayer layer = tile.get(MorphologyLayer.class);
        if( log.isTraceEnabled() ) {
            log.trace("accept(" + tile + ")  layer:" + layer);
        }
        //if( layer.getVersion().getLoadVersion() >= 0 ) {
        //    // This is not a new layer
        //    return;
        //}
        // I have no idea what I was thinking when I wrote the above.
        // It's not about whether the morphology layer is new or not but whether
        // the target terrain is new or not.
        TerrainImage terrain = tile.get(TerrainImageType.Terrain, TerrainImage.class);
        TerrainImage fluid = tile.get(TerrainImageType.Fluid, TerrainImage.class);
        if( terrain.getVersion().getLoadVersion() >= 0 && fluid.getVersion().getLoadVersion() >= 0 ) {
            if( log.isTraceEnabled() ) {
                log.trace("terrain was already generated, tile:" + tile.getTileId().getWorld(null) + ", res:" + tile.getResolution());
            }
            return;
        }

        if( layer.apply(tile) ) {
            // Mark the images as changed if they aren't already
            if( !terrain.getVersion().isChanged() ) {
                terrain.getVersion().markChanged();
            }
            if( !fluid.getVersion().isChanged() ) {
                fluid.getVersion().markChanged();
            }
        }
    }
}


