/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.bounding.BoundingBox;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.image.ColorSpace;
import com.jme3.util.BufferUtils;

import com.simsilica.lemur.LayerComparator;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.sim.Blackboard;
import com.simsilica.state.BlackboardState;
import com.simsilica.thread.*;

import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.World;
import com.simsilica.mworld.geom.*;
import com.simsilica.mworld.tile.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class FarTerrainState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(FarTerrainState.class);

    // This value gets multiplied by the tile size to determing the amount of "work"
    // done from runOnUpdate().  Each call to runOnUpdate() (that does any work at all)
    // will do a blit of size*size... to it seems reasonable to scale the amount of
    // work by tile size.
    // trying largest tile = 1 unit of work for now
    // Could be that we want to make this configurable.
    private static final double MIN_WORK = 1.0 / 1024.0;

    private Node root = new Node("terrainRoot");
    private JobState workers;
    private Blackboard blackboard;

    private World world;

    private Geometry test;
    private Vector3f original;

    private VersionedReference<Vec3d> posRef;

    private LoresLayer nearLayer;
    private LoresLayer farLayer;

    private LoresLayer nearFluid;
    private LoresLayer farFluid;

    //private int radials = 720;
    // When moving to the "NEW_WAY" in the terrain frag shader, it seems like
    // more radials becomes important.  We already cut the near terrain triangles
    // in half so I guess it's ok to spend a little more here.
    private int radials = 1440;
    //private int radials = 360;
    private boolean wireframe = false;
    private byte[] fill = new byte[] { (byte)0, (byte)0, (byte)0, (byte)0 };

    private boolean lightingEnabled = true;

    private FogSettings fogSettings;
    private VersionedReference<FogSettings> fogSettingsRef;

    private double minStep = 1;
    //private double growth = 1;
    // Seems like with "NEW_WAY" we can get away with a higher growth, too.
    // Growth of 1.0 has basically zero flicker but 1.5 is not bad and improves
    // the triangle count.
    private double growth = 1.5;

    private Function<TerrainImageType, Material> materialFactory;

    // True if the camera never moves in xz space, false if it moves within its grid cell.
    // In the long run, this is not as flexible as it needs to be but it will work today.
    private boolean xzLockedCamera = false;

    // Turn this on to have cell edges outlined
    private boolean cellDebug = false;

    private VersionedHolder<Integer> terrainTriangleCount = new VersionedHolder<>();
    private VersionedHolder<Integer> fluidTriangleCount = new VersionedHolder<>();

    private float horizontalLimit = 0.20f;
    private float verticalLimit = 0.65f;

    public FarTerrainState() {
        this(false);
    }

    public FarTerrainState( Blackboard blackboard ) {
        this(false);
        this.blackboard = blackboard;
    }

    public FarTerrainState( boolean xzLockedCamera ) {
        setEnabled(true);
        this.xzLockedCamera = xzLockedCamera;
    }

    /**
     *  Returns the distance from the current position to the closest edge
     *  on the grid.  Everything within this radius will be rendered.  Some
     *  things outside of the radius may also be rendered but not in all directions.
     */
    public double getVisualRadius() {
        Vec3d pos = posRef.get().clone();
        return farLayer.getVisualRadius(pos);
    }

    public double getNearestBlankDistance() {
        Vec3d pos = posRef.get().clone();
        pos.y = 0;
        double min1 = getNearBlankDistance(pos);
        if( min1 == 0 ) {
            return 0;
        }
        double min2 = getFarBlankDistance(pos);
        return Math.min(min1, min2);
    }

    protected double getNearBlankDistance( Vec3d pos ) {
        double min1 = nearLayer.getNearestBlankDistance(pos);
        if( min1 == 0 ) {
            return 0;
        }
        double min2 = nearFluid.getNearestBlankDistance(pos);
        return Math.min(min1, min2);
    }

    protected double getFarBlankDistance( Vec3d pos ) {
        double min1 = farLayer.getNearestBlankDistance(pos);
        if( min1 == 0 ) {
            return 0;
        }
        double min2 = farFluid.getNearestBlankDistance(pos);
        return Math.min(min1, min2);
    }

    public VersionedReference<Integer> getTerrainTriangleCount() {
        return terrainTriangleCount.createReference();
    }

    public VersionedReference<Integer> getFluidTriangleCount() {
        return fluidTriangleCount.createReference();
    }

    public void setMaterialFactory( Function<TerrainImageType, Material> materialFactory ) {
        this.materialFactory = materialFactory;
        if( nearLayer != null ) {
            nearLayer.updateMaterial(materialFactory);
            farLayer.updateMaterial(materialFactory);
            nearFluid.updateMaterial(materialFactory);
            farFluid.updateMaterial(materialFactory);
        }
    }

    public Function<TerrainImageType, Material> getMaterialFactory() {
        return materialFactory;
    }

    public void setXzLockedCamera( boolean f ) {
        this.xzLockedCamera = f;
    }

    public boolean isXzLockedCamera() {
        return xzLockedCamera;
    }

    public void setCellDebug( boolean f ) {
        this.cellDebug = f;
    }

    public boolean getCellDebug() {
        return cellDebug;
    }

    public void setRadials( int radials ) {
        if( this.radials == radials ) {
            return;
        }
        this.radials = radials;
        regenerateGeometry();
    }

    public int getRadials() {
        return radials;
    }

    public void setMinStep( double minStep ) {
        if( this.minStep == minStep ) {
            return;
        }
        this.minStep = minStep;
        regenerateGeometry();
    }

    public double getMinStep() {
        return minStep;
    }

    public void setGrowth( double growth ) {
        if( this.growth == growth ) {
            return;
        }
        this.growth = growth;
        regenerateGeometry();
    }

    public double getGrowth() {
        return growth;
    }

    public Texture getFarTerrainTexture() {
        return farLayer.getTexture();
    }

    public Texture getNearTerrainTexture() {
        return nearLayer.getTexture();
    }

    public Texture getFarFluidTexture() {
        return farFluid.getTexture();
    }

    public Texture getNearFluidTexture() {
        return nearFluid.getTexture();
    }

    protected void regenerateGeometry() {
        nearLayer.setRadials(radials);
        nearLayer.setMinStep(minStep);
        nearLayer.setGrowth(growth);

        farLayer.setRadials(radials);
        farLayer.setMinStep(minStep);
        farLayer.setGrowth(growth);

        nearLayer.regenerateMesh();
        farLayer.regenerateMesh();

        terrainTriangleCount.setObject(nearLayer.getTriangleCount() + farLayer.getTriangleCount());

        nearFluid.setRadials(radials);
        nearFluid.setMinStep(minStep);
        nearFluid.setGrowth(growth);

        farFluid.setRadials(radials);
        farFluid.setMinStep(minStep);
        farFluid.setGrowth(growth);

        nearFluid.regenerateMesh();
        farFluid.regenerateMesh();

        fluidTriangleCount.setObject(nearFluid.getTriangleCount() + farFluid.getTriangleCount());
    }

    public void setLightingEnabled( boolean lightingEnabled ) {
        if( this.lightingEnabled == lightingEnabled ) {
            return;
        }
        this.lightingEnabled = lightingEnabled;
        nearLayer.setLightingEnabled(lightingEnabled);
        farLayer.setLightingEnabled(lightingEnabled);
        nearFluid.setLightingEnabled(lightingEnabled);
        farFluid.setLightingEnabled(lightingEnabled);
    }

    public boolean isLightingEnabled() {
        return lightingEnabled;
    }

    public void setFogSettings( FogSettings fogSettings ) {
        this.fogSettings = fogSettings;
        fogSettingsRef = fogSettings == null ? null : fogSettings.createReference();
        resetFog();
    }

    public FogSettings getFogSettings() {
        return fogSettings;
    }

    protected int getFogDistance() {
        return fogSettings == null ? 0 : fogSettings.getFogDistance();
    }

    protected void resetFog() {
        TerrainState.updateFogDistance(root, getFogDistance(), -1);
    }


    public void setWireframe( boolean wireframe ) {
        if( this.wireframe == wireframe ) {
            return;
        }
        this.wireframe = wireframe;
        if( nearLayer != null ) {
            nearLayer.setWireframe(wireframe);
        }
        if( farLayer != null ) {
            farLayer.setWireframe(wireframe);
        }
        if( nearFluid != null ) {
            nearFluid.setWireframe(wireframe);
        }
        if( farFluid != null ) {
            farFluid.setWireframe(wireframe);
        }
    }

    public boolean getWireframe() {
        return wireframe;
    }

    public void setHorizontalLimit( float limit ) {
        if( this.horizontalLimit == limit ) {
            return;
        }
        this.horizontalLimit = limit;
        if( nearLayer != null ) {
            nearLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( farLayer != null ) {
            farLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( nearFluid != null ) {
            nearFluid.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( farFluid != null ) {
            farFluid.setUpnessRange(horizontalLimit, verticalLimit);
        }
    }

    public float getHorizontalLimit() {
        return horizontalLimit;
    }

    public void setVerticalLimit( float limit ) {
        if( this.verticalLimit == limit ) {
            return;
        }
        this.verticalLimit = limit;
        if( nearLayer != null ) {
            nearLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( farLayer != null ) {
            farLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( nearFluid != null ) {
            nearFluid.setUpnessRange(horizontalLimit, verticalLimit);
        }
        if( farFluid != null ) {
            farFluid.setUpnessRange(horizontalLimit, verticalLimit);
        }
    }

    public float getVerticalLimit() {
        return verticalLimit;
    }


    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {

        if( blackboard == null ) {
            blackboard = getState(BlackboardState.class, true).getBlackboard();
        }
        this.world = blackboard.get(World.class);

        blackboard.onInitialize(FogSettings.class, (FogSettings fogSettings) -> { setFogSettings(fogSettings); });

        workers = getState("regularWorkers", JobState.class);
        if( workers == null ) {
            // Try something
            workers = getState(JobState.class, true);
        }

        // FIXME: give blackboard a better casting pattern to avoid requiring warning suppression
        posRef = ((VersionedObject<Vec3d>)blackboard.get("position")).createReference();

        // If no material material factory is defined then set one up
        if( getMaterialFactory() == null ) {
            log.warn("No material factory configured.  Using a default coloredTerrainMaterial()");
            //ColorRGBA color = new ColorRGBA(0.15f, 0.3f, 0.1f, 1.0f);
            ColorRGBA groundColor = new ColorRGBA(0.15f, 0.25f, 0.1f, 1.0f);
            ColorRGBA waterColor = new ColorRGBA(107/255f, 141/255f, 217/255f, 0.9f); //0.8f);

            setMaterialFactory(MaterialFactories.coloredFarTerrainMaterial(getApplication(),
                                                                           groundColor, waterColor));
        }

        int nearScale = 1024/Resolution.Medium.getSamples(); //8;
        int farScale = 1024/Resolution.Low.getSamples(); //16;
        int outerRadius = (int)((((nearScale/2) - 1) * 1024)/nearScale);

        int nearBasePriority = 10000;
        int farBasePriority = 100000;

        nearLayer = new LoresLayer(TerrainImageType.Terrain, nearBasePriority,
                                   radials, (int)(512f/nearScale), outerRadius,
                                   minStep, growth, Resolution.Medium);

        int farOuterRadius = (int)((((farScale/2) - 1) * 1024)/farScale);
        //farLayer = new LoresLayer(TerrainImageType.Terrain, farBasePriority,
        //                          radials, (int)(outerRadius * (float)nearScale/(float)farScale), farOuterRadius,
        //                          minStep, growth,
        //                          new ColorRGBA(0.15f, 0.20f, 0.1f, 1.0f), Resolution.Low, false);
        // It's kind of too bad that we lose the auto-darkening in the far ring, but a) it's not
        // really correct and created a seam from the proper angles, and b) it's better done with
        // a proper distance attenuation + fog function of some kind.
        farLayer = new LoresLayer(TerrainImageType.Terrain, farBasePriority,
                                  radials, (int)(outerRadius * (float)nearScale/(float)farScale), farOuterRadius,
                                  minStep, growth, Resolution.Low);

        terrainTriangleCount.setObject(nearLayer.getTriangleCount() + farLayer.getTriangleCount());

        world.addTileListener(nearLayer);
        world.addTileListener(farLayer);


        nearFluid = new LoresLayer(TerrainImageType.Fluid, nearBasePriority,
                                   radials, (int)(512f/nearScale), outerRadius,
                                   minStep, growth, Resolution.Medium);
        farFluid = new LoresLayer(TerrainImageType.Fluid, farBasePriority,
                                  radials, (int)(outerRadius * (float)nearScale/(float)farScale), farOuterRadius,
                                  minStep, growth, Resolution.Low);
        fluidTriangleCount.setObject(nearFluid.getTriangleCount() + farFluid.getTriangleCount());
        nearFluid.setSpatialOffset(-0.25f);
        farFluid.setSpatialOffset(-0.25f);

    }

    private void fill( ByteBuffer data, byte... bytes ) {
        data.position(0);
        while( data.remaining() > 0 ) {
            data.put(bytes);
        }
    }

    /**
     *  Writes the specified tile to the target image 1024x1024 image data.
     */
    private void writeTerrainLayerToImage( TerrainImage tile, ByteBuffer data, int xTarget, int yTarget ) {

        int pos = xTarget + yTarget * 1024;

        for( int y = 0; y < tile.getSize(); y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < tile.getSize(); x++ ) {
                short val = tile.getElevation(x, y);
                int elev = val & 0x3ff;

                int type = tile.getType(x, y);
                if( cellDebug ) {
                    if( x == 0 || y == 0 ) {
                        type = 96;
                        //type = 0xff;
                    } //else if( (x % 32) == 0 || (y % 32) == 0 ) {
                    //    type = 255;
                    //}
                }

                // The bytes will be passed through as a float where 0 = 0
                // and 1 == 255.  So to fit our stuff in we have to break it up
                // appropriately.
                int hi = (int)(elev / 255);
                int lo = (int)(elev % 255);


                byte r = (byte)type;
                int light = tile.getLight(x, y);
                byte g = (byte)((0.5 + (light / 32.0)) * 255);
                byte b = (byte)hi;
                byte a = (byte)lo;

                data.put(a).put(r).put(g).put(b);
                pos++;
            }
            pos += 1024 - tile.getSize();
        }
    }

    private void writeBlankTerrainLayerToImage( int size, ByteBuffer data, int xTarget, int yTarget ) {

        int pos = xTarget + yTarget * 1024;

        for( int y = 0; y < size; y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < size; x++ ) {
                data.put((byte)0).put((byte)0).put((byte)0).put((byte)0);
                pos++;
            }
            pos += 1024 - size;
        }
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getRootNode().attachChild(root);
    }

    @Override
    protected void onDisable() {
        root.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( posRef.update() ) {
            Vec3d pos = posRef.get();
            nearLayer.setPosition(pos);
            farLayer.setPosition(pos);
            nearFluid.setPosition(pos);
            farFluid.setPosition(pos);
        }

        if( fogSettingsRef != null && fogSettingsRef.update() ) {
            resetFog();
        }

        nearLayer.processUpdates();
        farLayer.processUpdates();
        nearFluid.processUpdates();
        farFluid.processUpdates();
    }

    private class LoresLayer implements TileListener {

        private TerrainImageType type;
        private boolean water;
        private int basePriority;
        private Material material;
        private Geometry geom;
        private Vector3f baseGeomOffset;
        private float spatialOffset;
        private Texture texture;
        private Image image;
        private Vector2f terrainOffset = new Vector2f();
        private Grid terrainGrid = new Grid(1024, 1024, 1024);
        private Vec3i gridCenter = new Vec3i();
        private Vec3i centerWorld = new Vec3i();
        private Resolution res;
        private int scale;
        private int size;
        private int radius;
        private int tileSize;
        private int radials;
        private int innerRadius;
        private int outerRadius;
        private double minStep = 1;
        private double growth = 1;
        private ByteBuffer imageData;

        private ImageTile[][] tiles;
        private Map<TileId, ImageTile> tileCache = new HashMap<>();

        private ConcurrentLinkedQueue<TileChange> changed = new ConcurrentLinkedQueue<>();

        // Queue up the image writes to that we can execute just some number per frame to
        // spread out the load
        private ConcurrentLinkedQueue<Runnable> imageWriters = new ConcurrentLinkedQueue<>();

        // Keep track of the grid corners
        private Vec3i minCorner = new Vec3i();
        private Vec3i maxCorner = new Vec3i();

        public LoresLayer( TerrainImageType type,
                           int basePriority, int radials, int innerRadius, int outerRadius,
                           double minStep, double growth, Resolution res ) {

            this.type = type;
            this.water = water;
            this.basePriority = basePriority;
            this.res = res;
            this.scale = 1024/res.getSamples();
            this.radials = radials;
            this.innerRadius = innerRadius;
            this.outerRadius = outerRadius;
            this.minStep = minStep;
            this.growth = growth;

            boolean water = type == TerrainImageType.Fluid;

            Mesh fan = new FanMeshBuilder().near(innerRadius).far(outerRadius).radials(radials)
                                .minStep(minStep).growthFactor(growth).skirtSize(water ? 0 : 20)
                                .build();

            geom = new Geometry("fan" + scale, fan);
            LayerComparator.setLayer(geom, water ? 2 : 1);

            geom.setLocalScale(scale, 1, scale);
            geom.center();
            // The skirt will cause center() artificially move this by 5 units... so we'll move it back
            // ...and anyway we don't want center to move y anyway.
            geom.move(0, -geom.getLocalTranslation().y, 0);
            baseGeomOffset = geom.getLocalTranslation().clone();
            geom.setModelBound(new BoundingBox(new Vector3f(-10000, -100, -10000), new Vector3f(10000, 10000, 10000)));
            root.attachChild(geom);

            ByteBuffer data = imageData = BufferUtils.createByteBuffer(1024 * 1024 * 4);

            // Fill the data with known "garbage" so we know about tile misses
            fill(data, fill);

            // Fill the whole image in.  We could exclude the stuff inside inner radius
            // but then we have to remember to fill it again as we move around across
            // tile boundaries.
            // 'radius' is setup in such a way that there are an odd number of tiles.
            // The center tile and 'radius' amount of tiles on each side of that.
            // That means at any given time, we've wasted a tile's width of space on
            // each axis.  NPOT textures would have apparently wasted the same amount
            // in RAM.  We could also technically preload that data 'just in case' if
            // we wanted which would be faster uptick of visuals in that direction.
            // ...but I suspect we will probably pull the outer radius in some if that's
            // ever an issue.  Or more likely, defer to the lower res texture for missing
            // areas.
            this.radius = (scale / 2) - 1;
            this.size = radius * 2 + 1;

            tiles = new ImageTile[size][size];

            this.tileSize = 1024 / scale;
            /*for( int i = -radius; i <= radius; i++ ) {
                for( int j = -radius; j <= radius; j++ ) {
                    Tile tile = tileDb.getTile(i * 1024, j * 1024, scale);
                    writeTileToImage(tile, data, 512 + (i * tileSize), 512 + (j * tileSize));
                }
            }*/
            image = new Image(Image.Format.ARGB8, 1024, 1024, data, ColorSpace.Linear);

            /*
            for( int i = 0; i < size; i++ ) {
                for( int j = 0; j < size; j++ ) {
                    int x = i-radius;
                    int z = j-radius;
                    String key = x + "x" + z;
                    tiles[i][j] = new ImageTile(key, x * 1024, z * 1024, scale, image, imageData);
                    tiles[i][j].setImagePosition(512 + (x * tileSize), 512 + (z * tileSize));
                    tiles[i][j].runOnWorker();
                    tiles[i][j].runOnUpdate();
                    tileCache.put(key, tiles[i][j]);

                    //Tile tile = tileDb.getTile(x * 1024, z * 1024, scale);
                    //writeTileToImage(tile, data, 512 + (x * tileSize), 512 + (z * tileSize));
                }
            }*/
            // I'm commenting this out because in a client-server world it's
            // especially expensive to try to load the world around origin to
            // just replace it right away.
            //updateTerrainTiles(new Vec3d(), true);

            texture = new Texture2D(image);
            //texture.setMagFilter(Texture.MagFilter.Nearest);
            //geom.getMaterial().setTexture("DiffuseMap", texture);

            updateMaterial(getMaterialFactory());
        }

        public double getVisualRadius( Vec3d pos ) {
            // See if we are even in the box... and calculate our base offset
            if( pos.x < minCorner.x || pos.x >= maxCorner.x
                || pos.z < minCorner.z || pos.z >= maxCorner.z ) {
                return 0;
            }

            // The farthest a blank can ever be is the nearest edge of the grid
            double xDist = Math.min(pos.x - minCorner.x, maxCorner.x - pos.x);
            double zDist = Math.min(pos.z - minCorner.z, maxCorner.z - pos.z);
            return Math.min(xDist, zDist);
        }

        public double getNearestBlankDistance( Vec3d pos ) {
            // What is the farthest distance we can ever have that wouldn't show
            // blank space anyway.
            double minDist = getVisualRadius(pos);
            if( minDist == 0 ) {
                // We aren't even in the grid at the moment
                return 0;
            }

            TileId posTile = TileId.fromWorld(pos);
            Vec3i base = posTile.getWorld(null);
            if( !base.equals(centerWorld) ) {
                // We cannot accurately calculate the distance because the grid is out
                // of step with the current position.
                return 0;
            }
            Vec3i offset = pos.subtract(centerWorld.add(TileId.SIZE/2, 0, TileId.SIZE/2)).floor();

            double minDistSq = minDist * minDist;

            for( int i = 0; i < size; i++ ) {
                for( int j = 0; j < size; j++ ) {
                    ImageTile tile = tiles[i][j];
                    if( tile != null && tile.rendered ) {
                        continue;
                    }

                    TileId id;
                    if( tile != null ) {
                        id = tile.id;
                    } else {
                        int x = (i - radius);
                        int z = (j - radius);
                        id = TileId.fromWorld(centerWorld.x + x * 1024, centerWorld.y, centerWorld.z + z * 1024);
                    }

                    if( posTile.equals(id) ) {
                        // We are standing in an unrendered tile
                        return 0;
                    }

                    // Get the center to center distance from our home tile
                    Vec3i delta = id.getWorld(null).subtractLocal(centerWorld);
                    if( delta.x != 0 ) {
                        delta.x -= offset.x;
                    }
                    if( delta.z != 0 ) {
                        delta.z -= offset.z;
                    }
                    double dSq = delta.lengthSq();
                    if( dSq < minDistSq ) {
                        minDistSq = dSq;
                    }
                }
            }

            return Math.sqrt(minDistSq);
        }

        public void setSpatialOffset( float spatialOffset ) {
            this.spatialOffset = spatialOffset;
        }

        public void updateMaterial( Function<TerrainImageType, Material> materialFactory ) {
            Material mat = material = getMaterialFactory().apply(type);
            if( fogSettings != null ) {
                fogSettings.apply(mat);
            }

            mat.setVector2("TerrainOffset", terrainOffset);
            material.setFloat("TerrainSize", res == Resolution.Medium ? 8192f : 16384f);
            mat.getAdditionalRenderState().setWireframe(wireframe);
            mat.setTexture("DiffuseMap", texture);

            setUpnessRange(horizontalLimit, verticalLimit);

            geom.setMaterial(mat);
        }

        public void setLightingEnabled( boolean lightingEnabled ) {
            geom.getMaterial().setFloat("LocalLightStrength", lightingEnabled ? 0.8f : 0);
        }

        public void setWireframe( boolean wireframe ) {
            geom.getMaterial().getAdditionalRenderState().setWireframe(wireframe);
        }

        public void setUpnessRange( float min, float max ) {
            if( min < max ) {
                material.setFloat("HorizontalLimit", min);
                material.setFloat("VerticalLimit", max);
            } else {
                material.setFloat("HorizontalLimit", min);
                material.setFloat("VerticalLimit", min + 0.001f);
            }
        }

        public void setRadials( int radials ) {
            this.radials = radials;
        }

        public void setMinStep( double minStep ) {
            this.minStep = minStep;
        }

        public void setGrowth( double growth ) {
            this.growth = growth;
        }

        public Texture getTexture() {
            return texture;
        }

        public void regenerateMesh() {
            Mesh fan = new FanMeshBuilder().near(innerRadius).far(outerRadius).radials(radials)
                                .minStep(minStep).growthFactor(growth).skirtSize(water ? 0 : 20)
                                .build();
            geom.setMesh(fan);
        }

        public int getTriangleCount() {
            return geom.getMesh().getTriangleCount();
        }

        @Override
        public void tileChanged( TileChangeEvent event ) {
            if( event.getDataVersion() == 0 ) {
                // ignore generation events since we are either already requesting
                // the tile or don't care about it
                return;
            }
            // We only care about the changes that are the same or higher since
            // change events for High won't automatically send change events for
            // medium or low, etc..
            if( event.getResolution().isLowerThan(res) ) {
                return;
            }
            changed.add(new TileChange(event.getTileId(), event.getDataVersion()));
        }

        public void setPosition( Vec3d pos ) {
            updateTerrainTiles(pos, false);

            boolean continuous = false;

            if( continuous ) {
                terrainOffset.x = (float)(((pos.x % 1024.0))/scale);
                if( terrainOffset.x < 0 ) {
                    terrainOffset.x += 1024/scale;
                }
                terrainOffset.y = (float)(((pos.z % 1024.0))/scale);
                if( terrainOffset.y < 0 ) {
                    terrainOffset.y += 1024/scale;
                }
            } else {
                // Else we don't move the terrain offset except when crossing
                // column boundaries. 32x32.
                Vec3d columnPos = ColumnId.fromWorld(pos).getWorld(null).toVec3d();

                // If we use the raw column position then we will never be centered
                // over the fan center... so we'll adjust it by half a column
                columnPos.x += 16;
                columnPos.z += 16;

                if( xzLockedCamera ) {
                    Vec3d offset = pos.subtract(columnPos);
                    geom.setLocalTranslation(baseGeomOffset.add((float)-offset.x, spatialOffset, (float)-offset.z));
                } else {
                    // Just offset for the layer offset we build in to keep the
                    // fan 'centered' over the current cell
                    geom.setLocalTranslation(baseGeomOffset.add((float)16, spatialOffset, (float)16));
                }

                terrainOffset.x = (float)(((columnPos.x % 1024.0))/scale);
                if( terrainOffset.x < 0 ) {
                    terrainOffset.x += 1024/scale;
                }
                terrainOffset.y = (float)(((columnPos.z % 1024.0))/scale);
                if( terrainOffset.y < 0 ) {
                    terrainOffset.y += 1024/scale;
                }
            }
        }

        public void processUpdates() {
            Runnable todo = imageWriters.poll();
            if( todo != null ) {
                todo.run();
            }

            TileChange change = null;
            while( (change = changed.poll()) != null ) {
                if( log.isTraceEnabled() ) {
                    log.trace("Checking change:" + change.id + "  " + change.version);
                }
                ImageTile it = tileCache.get(change.id);
                if( it == null ) {
                    log.trace("no tile");
                    continue;
                }
                if( it.version > change.version ) {
                    log.trace("Already newer");
                    continue;
                }
                it.queued = true;
                workers.execute(it, it.priority);
            }
        }

        protected void updateTerrainTiles( Vec3d pos, boolean immediate ) {
            Vec3i center = terrainGrid.worldToCell(pos, null);

            if( !tileCache.isEmpty()
                && center.x == gridCenter.x && center.y == gridCenter.y && center.z == gridCenter.z ) {
                return;
            }
            gridCenter.set(center.x, center.y, center.z);
            centerWorld = terrainGrid.cellToWorld(gridCenter, centerWorld);

            // Any existing image writers are about to be invalid
            imageWriters.clear();

            TileId minTile = TileId.fromWorld(centerWorld.x - radius * 1024, centerWorld.y, centerWorld.z - radius * 1024);
            minTile.getWorld(minCorner);
            TileId maxTile = TileId.fromWorld(centerWorld.x + radius * 1024, centerWorld.y, centerWorld.z + radius * 1024);
            maxTile.getWorld(maxCorner);
            maxCorner.addLocal(1024, 0, 1024);


            // Fan 'uv' runs from 0 to 1024, effectively.
            // Which is -512 to 512 in actual space.... scaled up of course
            // So 0 in world space is 512 in uv space.
            // We write the 0 tile into 512, 512 so we should be ok with that.

            for( int i = 0; i < size; i++ ) {
                for( int j = 0; j < size; j++ ) {
                    int x = (i - radius);
                    int z = (j - radius);
                    TileId tileId = TileId.fromWorld(centerWorld.x + x * 1024, centerWorld.y, centerWorld.z + z * 1024);
                    ImageTile tile = tileCache.remove(tileId);
                    int priority = basePriority + x * x + z * z;
                    if( tile == null ) {
                        if( log.isTraceEnabled() ) {
                            log.trace("Creating tile for:" + tileId);
                        }
                        tile = new ImageTile(type, tileId, centerWorld.x + x * 1024, centerWorld.z + z * 1024, res, image, imageData);
                        tile.priority = priority;
                        if( !immediate ) {
                            tile.queued = true;
                            workers.execute(tile, tile.priority);
                        }
                    } else {
                        tile.priority = priority;
                    }
                    tiles[i][j] = tile;

                    // Enqueue this for spreading out over multiple frames.
                    // This will internally blank out a portion of the data or write
                    // actual terrain data... either way, a lot of these can take a significant
                    // amount of frame time if done all at once.
                    tile.setImagePosition(512 + (x * tileSize), 512 + (z * tileSize));
                    //imageWriters.add(new ImagePositioner(tile, 512 + (x * tileSize), 512 + (z * tileSize)));
                    // The problem is that it's really ugly and the terrain looks all gappy in every
                    // transition.  The above could work if we bulk-blit the whole image shift first
                    // and then let uncovered stuff fill in.

                    if( immediate ) {
                        tile.runOnWorker();
                        tile.runOnUpdate();
                    }
                }
            }

            // Release any of the tiles that weren't used
            for( ImageTile tile : tileCache.values() ) {
                tile.release();

                // By checking if it's already queued we should avoid
                // book-keeping overhead trying to remove something that
                // isn't even submitted.
                if( tile.queued ) {
                    // And cancel it if possible
                    if( !workers.cancel(tile) ) {
                        log.debug("Tile job not canceled for:" + tile.id);
                    } else {
                        tile.queued = false;
                    }
                }
            }
            tileCache.clear();

            // And rebuild the cache
            for( int i = 0; i < size; i++ ) {
                for( int j = 0; j < size; j++ ) {
                    ImageTile tile = tiles[i][j];
                    tileCache.put(tile.id, tile);
                }
            }
        }
    }

    private class ImagePositioner implements Runnable {
        ImageTile tile;
        int xImage;
        int yImage;

        public ImagePositioner( ImageTile tile, int xImage, int yImage ) {
            this.tile = tile;
            this.xImage = xImage;
            this.yImage = yImage;
        }

        public void run() {
            tile.setImagePosition(xImage, yImage);
        }
    }

    private class TileChange {
        TileId id;
        //DataVersion version;
        long version;

        public TileChange( TileId id, long version ) {
            this.id = id;
            this.version = version;
        }
    }

    private class ImageTile implements Job {
        TerrainImageType type;
        TileId id;
        int priority;
        long version;
        int xCorner;
        int zCorner;
        Resolution res;
        Image image;
        ByteBuffer imageData;
        volatile TerrainImage terrainImage;
        int xImage;
        int yImage;
        volatile boolean visible = true;
        volatile boolean queued;
        boolean rendered;

        public ImageTile( TerrainImageType type, TileId id, int xCorner, int zCorner, Resolution res, Image image, ByteBuffer imageData ) {
            this.type = type;
            this.id = id;
            this.xCorner = xCorner;
            this.zCorner = zCorner;
            this.res = res;
            this.image = image;
            this.imageData = imageData;
        }

        public void setImagePosition( int xImage, int yImage ) {
            this.xImage = xImage;
            this.yImage = yImage;
            if( !visible ) {
                log.warn("Setting image position to invisible tile:" + this);
                return;
            }
            // The image writes in here are quite expensive when accumulated
            // so we should spread them over many frames
            if( terrainImage != null ) {
                writeTerrainLayerToImage(terrainImage, imageData, xImage, yImage);
            } else {
                writeBlankTerrainLayerToImage(res.getSamples(), imageData, xImage, yImage);
            }
            image.setUpdateNeeded();
        }

        public void release() {
            visible = false;
        }

        @Override
        public void runOnWorker() {
            queued = false;
            if( !visible ) {
                return;
            }
            long start = System.nanoTime();
            terrainImage = world.getTerrainImage(id, type, res);

            long end = System.nanoTime();
            if( log.isTraceEnabled() ) {
                log.trace("tile time, resolution:" + res + "  in:" + ((end - start)/1000000.0) + " ms");
            }
        }

        @Override
        public double runOnUpdate() {
            if( !visible ) {
                return 0;
            }
            this.version = terrainImage.getVersion().getVersion();
            writeTerrainLayerToImage(terrainImage, imageData, xImage, yImage);
            image.setUpdateNeeded();
            rendered = true;
            //return 1;
            // 2024-05-17: I think we can do more than one of these per frame (in the default
            // configuration).  Probably should scale by image size, though... fewer pixels
            // is less time.
            return res.getSamples() * MIN_WORK;
        }

        @Override
        public String toString() {
            return "ImageTile[" + id + ", resolution=" + res + "]";
        }
    }
}

