/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.transaction.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class ColumnNeighborhood implements CellData {
    static Logger log = LoggerFactory.getLogger(ColumnNeighborhood.class);

    private ColumnDb columnDb;
    private ColumnData center;
    private Vec3i world;
    private ColumnData[][] columns = new ColumnData[3][3]; // some use-cases will need the corners
    //private boolean[][] changed = new boolean[3][3];
    private CellData lightingCells;
    private CellData fluidCells;
    private WorldEdits worldEdits;
    private boolean readOnlyNeighbors;

    public ColumnNeighborhood( ColumnDb columnDb, ColumnData center ) {
        this(columnDb, center, null);
    }

    public ColumnNeighborhood( ColumnDb columnDb, ColumnData center, WorldEdits worldEdits ) {
        this(columnDb, center, worldEdits, false);
    }

    public ColumnNeighborhood( ColumnDb columnDb, ColumnData center, WorldEdits worldEdits, boolean readOnlyNeighbors ) {
        this.columnDb = columnDb;
        this.center = center;
        this.world = center.getColumnId().getWorld(null);
        //this.changedLeafs = changedLeafs;
        this.worldEdits = worldEdits;
        this.readOnlyNeighbors = readOnlyNeighbors;
        columns[1][1] = center;
    }

    public CellData getLightingCellData() {
        if( lightingCells == null ) {
            lightingCells = new LightingCellData();
        }
        return lightingCells;
    }

    public CellData getFluidCellData() {
        if( fluidCells == null ) {
            fluidCells = new FluidCellData();
        }
        return fluidCells;
    }

    //public Set<ColumnData> getModifiedColumns() {
    //    Set<ColumnData> results = new HashSet<>();
    //    for( int i = 0; i < 3; i++ ) {
    //        for( int j = 0; j < 3; j++ ) {
    //            if( changed[i][j] ) {
    //                results.add(columns[i][j]);
    //            }
    //        }
    //    }
    //    return results;
    //}

    private ColumnData getColumn( int x, int z ) {
        // Calculate the indexes into the columns array
        // If x is < 0 we want i to be 0.
        // If x is between 0 and 31, we want i to be 1.
        // if x is > 31 then we want i to be 2
        int i = (x + LeafInfo.SIZE) / LeafInfo.SIZE;
        int j = (z + LeafInfo.SIZE) / LeafInfo.SIZE;
        ColumnData col = columns[i][j];
        if( col == null ) {
            // Need to look it up
            ColumnId id = ColumnId.fromWorld(world.x + x, world.y, world.z + z);
            col = columnDb.getColumn(id);
            columns[i][j] = col;
        }
        return col;
    }

    private void markChanged( ColumnData col, CellData data, DataType type, LeafId id, int i, int j, int k, int value, int oldValue ) {
        if( worldEdits != null ) {
            if( log.isTraceEnabled() ) {
                log.trace("markChanged(" + type + ", " + i + ", " + j + ", " + k + ", "
                                        + Integer.toHexString(value) + ") original:"
                                        + Integer.toHexString(oldValue));
            }
            worldEdits.cellChanged(col, id, type, i, j, k, value, oldValue);
        }
    }

    @Override
    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        if( y < 0 ) {
            return defaultValue;
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            return defaultValue;
        }
        int k = y / LeafInfo.SIZE;
        if( k >= col.getLighting().length ) {
            return defaultValue;
        }
        LeafData leaf = col.getLeafs()[k];
        if( leaf == null ) {
            return defaultValue;
        }
        if( leaf.isEmpty() ) {
            return 0;
        }

        // The column will have already been correctly selected for us
        // above so now we need to move our x,z into range.
        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }

        return leaf.getCell(x, y - (k * LeafInfo.SIZE), z);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    @Override
    public void setCell( final int x, final int y, final int z, int value ) {
        if( log.isTraceEnabled() ) {
            log.trace("setCell(" + x + ", " + y + ", " + z + ", " + value + ")");
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            throw new RuntimeException("ColumnData not found for:" + x + ", " + z);
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            // return;
        }
        if( col != center && readOnlyNeighbors ) {
            return;
        }
        // We already know we're in the neighborhood if we got a column
        // so we just need to adjust x and z to be in the local block range.
        int xLocal = x;
        int zLocal = z;
        if( x < 0 ) {
            xLocal = x + LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            xLocal = x - LeafInfo.SIZE;
        }
        if( z < 0 ) {
            zLocal = z + LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            zLocal = z - LeafInfo.SIZE;
        }
        int k = y / LeafInfo.SIZE;
        int yLocal = y - (k * LeafInfo.SIZE);

        LeafData leaf = col.getLeafs()[k];
        int existing = -1;
        if( worldEdits != null ) {
            existing = leaf.getCell(xLocal, yLocal, zLocal, value);
            if( existing == value ) {
                return;
            }
        }
        leaf.setCell(xLocal, yLocal, zLocal, value);
        markChanged(col, leaf, DataType.Block, leaf.getLeafId(), xLocal, yLocal, zLocal, value, existing);
    }

    public int getLight( int x, int y, int z, int defaultValue ) {
        if( y < 0 ) {
            return defaultValue;
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            return defaultValue;
        }
        int k = y / LeafInfo.SIZE;
        if( k >= col.getLighting().length ) {
            return LightUtils.DIRECT_SUN;
        }
        LightData lighting = col.getLighting()[k];
        if( lighting.isSolidDark() ) {
            return LightUtils.SOLID;
        }
        if( lighting.isFullSun() ) {
            return LightUtils.DIRECT_SUN;
        }

        // The column will have already been correctly selected for us
        // above so now we need to move our x,z into range.
        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }

        return lighting.getCell(x, y - (k * LeafInfo.SIZE), z);
    }

    public void setLight( final int x, final int y, final int z, int value ) {
        if( log.isTraceEnabled() ) {
            log.trace("setLight(" + x + ", " + y + ", " + z + ", " + value + ")");
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            throw new RuntimeException("Column not found for:" + x + ", " + z);
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            // return;
        }
        if( col != center && readOnlyNeighbors ) {
            return;
        }
        // We already know we're in the neighborhood if we got a column
        // so we just need to adjust x and z to be in the local block range.
        int xLocal = x;
        int zLocal = z;
        if( x < 0 ) {
            xLocal = x + LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            xLocal = x - LeafInfo.SIZE;
        }
        if( z < 0 ) {
            zLocal = z + LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            zLocal = z - LeafInfo.SIZE;
        }
        int k = y / LeafInfo.SIZE;
        int yLocal = y - (k * LeafInfo.SIZE);

        LightData lighting = col.getLighting()[k];
        int existing = -1;
        if( worldEdits != null ) {
            existing = lighting.getCell(xLocal, yLocal, zLocal, value);
            if( existing == value ) {
                return;
            }
        }
        lighting.setCell(xLocal, yLocal, zLocal, value);
        markChanged(col, lighting, DataType.Light, lighting.getLeafId(), xLocal, yLocal, zLocal, value, existing);
    }

    public int getFluid( int x, int y, int z, int defaultValue ) {
        if( y < 0 ) {
            return defaultValue;
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            return defaultValue;
        }
        int k = y / LeafInfo.SIZE;
        if( k >= col.getFluid().length ) {
            return LightUtils.DIRECT_SUN;
        }
        FluidData fluidData = col.getFluid()[k];
        if( fluidData.isEmpty() ) {
            return 0;
        }

        // The column will have already been correctly selected for us
        // above so now we need to move our x,z into range.
        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }

        return fluidData.getCell(x, y - (k * LeafInfo.SIZE), z);
    }

    public void setFluid( final int x, final int y, final int z, int value ) {
        if( log.isTraceEnabled() ) {
            log.trace("setFluid(" + x + ", " + y + ", " + z + ", " + value + ")");
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            throw new RuntimeException("Column not found for:" + x + ", " + z);
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            // return;
        }
        if( col != center && readOnlyNeighbors ) {
            return;
        }
        // We already know we're in the neighborhood if we got a column
        // so we just need to adjust x and z to be in the local block range.
        int xLocal = x;
        int zLocal = z;
        if( x < 0 ) {
            xLocal = x + LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            xLocal = x - LeafInfo.SIZE;
        }
        if( z < 0 ) {
            zLocal = z + LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            zLocal = z - LeafInfo.SIZE;
        }
        int k = y / LeafInfo.SIZE;
        int yLocal = y - (k * LeafInfo.SIZE);

        FluidData fluidData = col.getFluid()[k];
        int existing = -1;
        if( worldEdits != null ) {
            existing = fluidData.getCell(xLocal, yLocal, zLocal, value);
            if( existing == value ) {
                return;
            }
        }
        fluidData.setCell(xLocal, yLocal, zLocal, value);
        markChanged(col, fluidData, DataType.Fluid, fluidData.getLeafId(), xLocal, yLocal, zLocal, value, existing);
    }

    private class LightingCellData implements CellData {

        @Override
        public int getCell( int x, int y, int z ) {
            return getLight(x, y, z, -1);
        }

        @Override
        public int getCell( int x, int y, int z, int defaultValue ) {
            return getLight(x, y, z, defaultValue);
        }

        @Override
        public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
            Vec3i v = dir.getVec3i();
            return getLight(v.x + x, v.y + y, v.z + z, defaultValue);
        }

        @Override
        public void setCell( int x, int y, int z, int light ) {
            setLight(x, y, z, light);
        }

    }

    private class FluidCellData implements CellData {

        @Override
        public int getCell( int x, int y, int z ) {
            return getFluid(x, y, z, -1);
        }

        @Override
        public int getCell( int x, int y, int z, int defaultValue ) {
            return getFluid(x, y, z, defaultValue);
        }

        @Override
        public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
            Vec3i v = dir.getVec3i();
            return getFluid(v.x + x, v.y + y, v.z + z, defaultValue);
        }

        @Override
        public void setCell( int x, int y, int z, int fluid ) {
            setFluid(x, y, z, fluid);
        }

    }
}

