/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.io.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class MorphologyLayerProtocol implements ObjectProtocol<MorphologyLayer> {
    static Logger log = LoggerFactory.getLogger(MorphologyLayerProtocol.class);

    // 42 is the original version.
    // 43 includes the generation level
    private int version = 43;
    
    private ProtocolSerializers protocols = new ProtocolSerializers();
    private Map<Class, ClassInfo> registry = new HashMap<>();
    private Map<Short, ClassInfo> idIndex = new HashMap<>();
    private Map<String, Class> nameIndex = new HashMap<>();
    private int baseTypeBits;
    private byte[] registryBytes;
    private boolean initialized = false;

    public MorphologyLayerProtocol() {
    }

    public int getProtocolVersion() {
        return version;
    }

    public <T> void registerProtocol( Class<T> type, ObjectProtocol<T> protocol ) {
        if( initialized ) {
            throw new IllegalStateException("Protocol already initialized");
        }
        protocols.registerProtocol(type, protocol);
        short id = (short)idIndex.size();
        ClassInfo info = new ClassInfo(type, id, protocol.getProtocolVersion());
        registry.put(type, info);
        idIndex.put(id, info);
        nameIndex.put(type.getName(), type);
    }

    public void initialize() {
        setupBaseBits();
        setupRegistryBytes();
        initialized = true;
    }

    private void confirmInitialized() {
        if( !initialized ) {
            throw new IllegalStateException("Protocol not initialized");
        }
    }

    private void setupBaseBits() {
        if( baseTypeBits == 0 ) {
            log.info("baseTypeBits is 0, checking index initialized state...");
            // Calculate a good size for type indexes
            this.baseTypeBits = Integer.SIZE - Integer.numberOfLeadingZeros(idIndex.size());
            log.info("baseTypeBits:" + baseTypeBits + "  index size:" + idIndex.size());
        }
    }

    private void setupRegistryBytes() {
        // Prebuild the type registry bytes for easy streaming
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bos);
        try {
            out.writeShort(idIndex.size());
            for( ClassInfo info : idIndex.values() ) {
                // We write the versions just in case we someday want to pull
                // those out of the per-object data blocks.
                out.writeUTF(info.type.getName());
                out.writeShort(info.id);
                out.writeInt(info.version);
            }
            out.close();
        } catch( IOException e ) {
            throw new RuntimeException("Error building registry bytes", e);
        }
        registryBytes = bos.toByteArray();
        log.info("Registry bytes size:" + registryBytes.length);
    }

    protected void writeClassRegistry( BitOutputStream out ) throws IOException {
        out.writeBits(registryBytes.length, 16);
        for( byte b : registryBytes ) {
            out.writeBits(b, 8);
        }
    }

    protected Map<Short, ClassInfo> readClassRegistry( BitInputStream bitIn ) throws IOException {
        int size = bitIn.readBits(16);
        byte[] bytes = new byte[size];
        for( int i = 0; i < size; i++ ) {
            bytes[i] = (byte)bitIn.readBits(8);
        }
        ByteArrayInputStream bin = new ByteArrayInputStream(bytes);
        DataInputStream in = new DataInputStream(bin);
        size = in.readShort();
        Map<Short, ClassInfo> results = new HashMap<>();
        for( int i = 0; i < size; i++ ) {
            String name = in.readUTF();
            short id = in.readShort();
            int version = in.readInt();
            Class type = nameIndex.get(name);
            if( type == null ) {
                // Not much we can do here because we won't have a protocol available
                throw new IOException("Stream references unknown type:" + name);
            }
            results.put(id, new ClassInfo(type, id, version));
        }
        return results;
    }

    public void write( MorphologyLayer data, BitOutputStream out ) throws IOException {
        confirmInitialized();

        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        // Header stuff
        TileId tileId = data.getTileId();
        long id = tileId.getId();
        out.writeLongBits(id, 64);
        out.writeLongBits(data.getVersion().getVersion(), 64);
        out.writeBits(data.getGenerationLevel(), 8);

        if( log.isTraceEnabled() ) {
            log.trace("writing layer for:" + tileId + "  size:" + data.getMorphology().size());
        }

        // Write out the number of bits we will use for type... this will
        // make the reading side a little more adaptive
        out.writeBits(baseTypeBits, 8);

        // Write out the class index
        writeClassRegistry(out);

        int size = data.getMorphology().size();
        out.writeBits(size, 32);

        for( Morphology m : data.getMorphology() ) {
            ClassInfo info = registry.get(m.getClass());
            if( info == null ) {
                throw new IOException("No protocol registered for class:" + m.getClass());
            }
            out.writeBits(info.id, baseTypeBits);

            protocols.write(m, out);
        }
    }

    //public <T> T read( Class<T> type, BitInputStream in ) throws IOException {
    //    ObjectProtocol protocol = protocols.getProtocol(type);
    //    if( protocol == null ) {
    //        throw new IllegalArgumentException("No ObjectProtocol found for type:" + type);
    //    }
    //    return type.cast(protocol.read(in));
    //}

    @SuppressWarnings("unchecked")
    public MorphologyLayer read( BitInputStream in ) throws IOException {
        confirmInitialized();

        int version = in.readBits(16);
        // Could check version to see if we need to read in a special way

        // Read the header and create the tile
        TileId tileId = new TileId(in.readLongBits(64));
        long dataVersion = in.readLongBits(64);

        int generationLevel = 0;
        if( version >= 43 ) {
            // Then we can read the generation level
            generationLevel = in.readBits(8);
        }

        if( log.isTraceEnabled() ) {
            log.trace("reading layer for:" + tileId);
        }

        int typeBits = in.readBits(8);

        // Read the class index
        Map<Short, ClassInfo> index = readClassRegistry(in);

        int size = in.readBits(32);

        List<Morphology> morphs = new ArrayList<>();
        for( int i = 0; i < size; i++ ) {
            int typeId = in.readBits(typeBits);
            ClassInfo info = index.get((short)typeId);
            if( info == null ) {
                throw new RuntimeException("No class registered for type ID:" + typeId);
            }
            Morphology m = (Morphology)protocols.read(info.type, in);
            morphs.add(m);
        }

        return new MorphologyLayer(tileId, new DataVersion(dataVersion), generationLevel, morphs);
    }

    public void write( MorphologyLayer morphs, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(morphs, out);
        } finally {
            out.close();
        }
    }

    public MorphologyLayer read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }

    private static class ClassInfo {
        Class type;
        short id;
        int version;

        public ClassInfo( Class type, short id, int version ) {
            this.type = type;
            this.id = id;
            this.version = version;
        }
    }
}

