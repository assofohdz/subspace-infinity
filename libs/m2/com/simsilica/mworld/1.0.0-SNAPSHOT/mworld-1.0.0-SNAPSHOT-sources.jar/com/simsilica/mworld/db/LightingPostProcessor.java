/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;


import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class LightingPostProcessor implements ColumnPostProcessor {

    static Logger log = LoggerFactory.getLogger(LightingPostProcessor.class);

    private PostProcColumnDb parent;
    private ColumnDb delegate;

    public LightingPostProcessor() {
    }

    @Override
    public void initialize( PostProcColumnDb parent ) {
        this.parent = parent;
        this.delegate = parent.getDelegate();
    }

    @Override
    public void terminate() {
    }

    @Override
    public boolean postProcess( ColumnData col ) {
        //log.info("postProcess(" + col + ")");

        // See if this column has already been fully lit
        if( col.hasGenerationFlag(ColumnData.GEN_LIGHT_EXTERNAL) ) {
            //log.info("already post processed");
            return false;
        }

        if( log.isTraceEnabled() ) {
            log.trace("postProcess(" + col + ")");
        }
        //log.info(col + " flags:" + Long.toHexString(col.getGenerationFlags()));

        ColumnNeighborhood cellData = new ColumnNeighborhood(delegate, col);

        // In theory, we should never be writing back to the neighbors but we DO need
        // the real neighbor lighting values.  This whole approach is actually a bit
        // wrong but let's get it working first.
        // FIXME: the above comment is important.  Need to clamp down on read-only neighbors
        //ColumnLightData lightData = ColumnLightData.loadNeighborhood(delegate, col, false);
        CellData lightData = cellData.getLightingCellData();

        // Note: if we knew that all of the borders were 'full sun' or 'empty'
        // then we could probably short-circuit this call.

        synchronized( col ) {
            int count = LightUtils.propagateBorders(cellData, lightData, 0, 0, 0, LeafId.SIZE, col.getCeiling(), LeafId.SIZE);
//        int count = LightUtils.propagateBorders(cellData, lightData, 0, 0, 0, LeafId.SIZE, lightData.getCeiling(), LeafId.SIZE);
            if( count > 500000 ) {
                if( log.isTraceEnabled() ) {
                    log.trace(col + " iteration overrun");
                }
            }
        }

        col.setGenerationFlag(ColumnData.GEN_LIGHT_EXTERNAL);

        return true;
    }
}


