/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.nio.*;
import java.util.*;

import org.slf4j.*;

import com.jme3.texture.image.ColorSpace;
import com.jme3.texture.*;
import com.jme3.util.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;


/**
 *  Keeps track of the cells in the 'leaf grid' that have locally
 *  rendered leaf objects.  This can be used to mask out low LOD
 *  stuff nearby based on what is actually currently being rendered
 *  in the highest levels of detail.
 *
 *  @author    Paul Speed
 */
public class ViewMask implements VersionedObject<Vec3i> {

    static Logger log = LoggerFactory.getLogger(ViewMask.class);

    private Grid grid;
    private Vec3i viewRadius;
    private Vec3i size;
    private Vec3i centerWorld;

    private long version;
    private Vec3i centerCell;

    private Layer[] layers;
    private TextureArray maskTextures;
    private Image arrayImage;

    private boolean debug = false;

    public ViewMask( Grid grid, Vec3i viewRadius ) {
        this.grid = grid;
        this.viewRadius = viewRadius;
        this.centerWorld = new Vec3i(0, viewRadius.y + 1, 0);
        this.size = viewRadius.mult(2).addLocal(1, 1, 1);

        List<Image> layerImages = new ArrayList<>();
        layers = new Layer[size.y];
        for( int i = 0; i < size.y; i++ ) {
            layers[i] = new Layer(i, size.x, size.z);
            layerImages.add(layers[i].maskImage);
        }
        maskTextures = new TextureArray(layerImages);
        arrayImage = maskTextures.getImage();
        //maskTextures.setMagFilter(Texture.MagFilter.Nearest);
        maskTextures.setMagFilter(Texture.MagFilter.Bilinear);
        maskTextures.setMinFilter(Texture.MinFilter.NearestNoMipMaps);
        if( debug ) {
            testCrissCross();
        }
    }

    protected void testCrissCross() {
        for( int i = -viewRadius.x; i <= viewRadius.x; i++ ) {
            for( int j = -viewRadius.z; j <= viewRadius.z; j++ ) {
                for( int k = -viewRadius.y; k <= viewRadius.y; k++ ) {
                    boolean visible = (i == j || -i == j) && (k % 2) == 0;
                    markRendered(new Vec3i(i, k, j), visible);
                }
            }
        }
    }

    public void setRendered( Vec3i offset, boolean rendered ) {
        if( !debug ) {
            markRendered(offset, rendered);
        }
    }

    public Image getLayerImage( int layer ) {
        return layers[layer].maskImage;
    }

    protected void markRendered( Vec3i offset, boolean rendered ) {
        int x = viewRadius.x + offset.x;
        int y = viewRadius.y + offset.y;
        int z = viewRadius.z + offset.z;
        int c1 = z * size.x + x;
        layers[y].markRendered(c1, rendered);
    }

    public Vec3i getSize() {
        return size;
    }

    public Vec3i getViewRadius() {
        return viewRadius;
    }

    public void setCenterWorld( Vec3i v ) {
        if( centerWorld.equals(v) ) {
            return;
        }
        centerWorld.set(v);
        version++;
    }

    public Vec3i getCenterWorld() {
        return centerWorld;
    }

    public Texture getMaskTextures() {
        return maskTextures;
    }

    public long getVersion() {
        return version;
    }

    public Vec3i getObject() {
        return centerWorld;
    }

    public VersionedReference<Vec3i> createReference() {
        return new VersionedReference<>(this);
    }

    private class Layer {
        private int layerIndex;
        private ByteBuffer mask;
        private Image maskImage;

        public Layer( int layerIndex, int width, int height ) {
            this.layerIndex = layerIndex;

            mask = BufferUtils.createByteBuffer(width * height * 4);

            // I couldn't figure out how to get R8I to show up in a view and
            // so I don't know if it's working or not.  This is not an overly huge texture
            // anyway and maybe we can use the other channels for other kinds of markers.
            //maskImage = new Image(Image.Format.R8I, size.x * size.y, size.z, mask, ColorSpace.Linear);
            maskImage = new Image(Image.Format.ARGB8, width, height, mask, ColorSpace.Linear);
        }

        public void markRendered( int index, boolean rendered ) {
            // Mark with the red channel (that's the +1)
            mask.put(index * 4 + 1, rendered ? (byte)0xff : (byte)0);
            maskImage.setUpdateNeeded();

            // TextureArray will not automatically update when images change
            // so we have to do some surgery.
            arrayImage.setData(layerIndex, maskImage.getData(0));
        }
    }
}

