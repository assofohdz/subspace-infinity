/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.tile.tree.*;

/**
 *  Prototype of a terrain image supplier that manages the ongoing
 *  updates of the TerrainImage objects afer initial generation.
 *  When the hires tile is first generated, a hires TerrainImage is
 *  generated that represents the composite world fractal.  This is
 *  essentially what is used to generate columns and the other terrain
 *  layers.  However, as columns get modified we need to write this data
 *  back to the TerrainImage similar to what is done to generate PointClouds
 *  (in fact, you can see these two as sympathetic).
 *  As long as we can get away with it, we are going to use the same
 *  object for the "initial fractal data" and the "ongoing terrain image".
 *
 *  @author    Paul Speed
 */
public class TerrainImageManager {
    static Logger log = LoggerFactory.getLogger(TerrainImageManager.class);

    /**
     *  The key to a special Tile ColumnStates that indicates columns that require
     *  full column generation write-back to the TerrainImage layer during initialization.
     *  This is usually used in the cases where TileFunctions modify the lighting in
     *  some way but could be used for any deferred generation where the TerrainImage
     *  cannot be updated properly during normal tile generation.
     *  If there is no tile.get(TILE_INCOMPLETE_COLUMNS, ColumnStates.class) in the tile
     *  then the TerrainImage is considered ready to go when received from the Tile.
     */
    public static final String TILE_INCOMPLETE_COLUMNS = "incompleteColumns";

    private File root;
    private TerrainImageDb terrainDb;
    private ObservableColumnDb columnDb;
    private TileManager tiles;

    private TerrainTypeFunction typeFunction;

    private ColumnStatesDb colStatesDb;

    private boolean reprocessTrees = true;

    private CopyOnWriteArrayList<TileListener> listeners = new CopyOnWriteArrayList<>();

    public TerrainImageManager( File root, TerrainImageDb terrainDb, ObservableColumnDb columnDb, TileManager tiles, TerrainTypeFunction typeFunction ) {
        this.root = root;
        this.terrainDb = terrainDb;
        this.colStatesDb = new ColumnStatesDb(root, "terrain.state");

        // So we know when to mark columns dirty
        this.columnDb = columnDb;

        // So we know what the initial dirty columns should be
        this.tiles = tiles;

        // Block types to terrain image types
        this.typeFunction = typeFunction;

        // Add observers
        columnDb.addColumnChangeListener( (event) -> { markDirty(event.getColumnId(), true); } );

        // Just straight forward for now
        columnDb.addColumnGenerationListener( (event) -> { markGenerated(event.getColumnData()); } );
    }

    public void addTileListener( TileListener l ) {
        listeners.add(l);
    }

    public void removeTileListener( TileListener l ) {
        listeners.remove(l);
    }

    public void initialize() {
        colStatesDb.initialize();
    }

    public void terminate() {
        colStatesDb.terminate();
    }

    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res ) {

        if( log.isTraceEnabled() ) {
            log.trace("getTerrainImage(" + id + ", " + type + ", " + res + ")");
        }

        Tile tile = tiles.getTile(id, res);
        TerrainImage result = tile.get(type, TerrainImage.class);

        if( res != Resolution.High ) {
            // Just return it... for now we only update the lores tiles
            // as part of hires requests
            return result;
        }

        if( type == TerrainImageType.Fluid ) {
            // We don't deal with this yet
            return result;
        }

        // Grab the column states for this column
        ColumnStates states = colStatesDb.get(id);

        // We don't have to synchronize on it anymore but it prevents us from
        // trying to update the same TerrainImage from multiple threads.
        synchronized(states) {
            boolean changed = false;

            // See if we need to initialize our TILE_INCOMPLETE_COLUMNS
            // Because the terrain image is fully generated by the tile,
            // we don't have to do any speciail init processing to set starting
            // states like we do for point clouds.
            // Umm.... except we do when other layers might dirty us up for
            // things like lighting.  Need a way to get columns that might affect
            // the terrain layer.  Perhaps there is a general way that things like
            // structure layers might report this during creation.

            // See if we need to initialize the states from generated
            // tiles, ie: the first time we've been here
            // Technically this check is unnecessary because the first time we
            // load we'll have the incomplete set generated and from then on not.
            //if( result.getVersion().getLoadVersion() < 0 ) {
            // FIXME: this will only be present the first time the tile is loaded which
            // may not be the first time we try to get a TerrainImage.  Need to use
            // a persistent state or more likely share the same column states that this
            // class is using.
                ColumnStates incomplete = tile.get(TILE_INCOMPLETE_COLUMNS, ColumnStates.class);
                if( incomplete != null ) {
                    log.info("markAll(" + incomplete + ")");
                    states.markAll(incomplete);
                }
//            //}

            // See if there are any column updates
            if( updateTerrain(tile, result, states.getDirtyColumns()) ) {
                // All caught up... clear the invalid state and write it back to disk
                //states.validate();
                // We clear the state as we use it now
                log.info("storing:" + states);
                colStatesDb.update(id, states);

                // Move the version along and spool to the underlying terrain DB
                result.getVersion().markChanged();
                terrainDb.update(result.getId(), result);

                // Note: terrainDb.update() will write lower resolutions as necessary
            }
        }

        // Note: in the case of TerrainImage, we hope to not have to worry about
        // readwrite locks for a while.  It's not fully safe to be sharing an array
        // from multiple threads without any sort of memory barrier but at least it
        // won't corrupt the data structure.  And anyway, updates within a tile are
        // already synchronized so maybe it doesn't matter.

        return result;
    }

    protected void markDirty( ColumnId colId, boolean notifyTileListeners ) {
        TileId tileId = colId.getTileId();
log.info("markDirty(" + colId + ", " + notifyTileListeners + ") in tile:" + tileId);
        colStatesDb.markDirty(colId);

        if( notifyTileListeners ) {
            // Notify the listeners
            TileChangeEvent event = new TileChangeEvent(TerrainImage.class, tileId, Integer.MAX_VALUE, Resolution.High);
            for( TileListener l : listeners ) {
                l.tileChanged(event);
            }
        }
    }

    protected void markGenerated( ColumnData col ) {
log.info("markGenerated(" + col + ")");
        // Here we could do some additional checking to see if the
        // generation actually made modifications... like check for lighting.
//        markDirty(col.getColumnId(), false);
    }

    protected boolean updateTerrain( Tile tile, TerrainImage image, Iterable<ColumnId> columns ) {
        Vec3i base = image.getId().getTileId().getWorld(null);
        boolean changed = false;

        TreeLayer trees = null;
        if( reprocessTrees ) {
            trees = tile.get(TreeLayer.class);
        }

        //for( ColumnId colId : columns ) {
        // Use an iterator and we'll remove the items as we process them
        for( Iterator<ColumnId> it = columns.iterator(); it.hasNext(); ) {

            ColumnId colId = it.next();

            // Remove it right after we get it.  If something else dirties it while
            // we're working then we'll miss it otherwise.
            it.remove();

            // This column should already be lit
            ColumnData col = columnDb.getColumn(colId);
log.info("processing dirty column:" + col);

            // Build up the terrain morphology by starting
            // at the top and working our way down
            boolean[][] done = new boolean[LeafInfo.SIZE][LeafInfo.SIZE];
            int groundLeft = LeafInfo.SIZE * LeafInfo.SIZE;

            LeafData[] leafs = col.getLeafs();
            LightData[] lighting = col.getLighting();

            for( int i = leafs.length - 1; i >= 0; i-- ) {
                LeafData leaf = leafs[i];
                LightData lights = lighting[i];
                int yBase = i * LeafInfo.SIZE;
                if( leaf.isEmpty() ) {
                    continue;
                }

                for( int x = 0; x < LeafInfo.SIZE; x++ ) {
                    for( int z = 0; z < LeafInfo.SIZE; z++ ) {
                        if( done[x][z] ) {
                            continue;
                        }

                        // Calculate the tile-relative index for this location
                        int tx = leaf.getInfo().location.x + -base.x + x;
                        int tz = leaf.getInfo().location.z + -base.z + z;

                        int existing = image.getType(tx, tz);

                        int lastLight = LightUtils.DIRECT_SUN;
                        for( int y = LeafInfo.SIZE -1; y >= 0; y-- ) {
                            int val = leaf.getCell(x, y, z);
                            int type = MaskUtils.getType(val);
                            BlockType bt = BlockTypeIndex.get(type);

                            // We always get the light value even if the block is solid
                            // because the ground may be underneath solid blocks.
                            int light = lights.getCell(x, y, z);
                            if( bt != null && !bt.isSolid() && !bt.isTransparent() ) {
                                lastLight = light;
                                continue;
                            }
                            // For this, we ignore the masks because we want to
                            // find the terrain surface even if it is underneath
                            // a solid structure.  (ie: the top of our block might
                            // be hidden by a non-ground block but it's still a
                            // ground block.)

                            int groundType = typeFunction.apply(existing, val, type);
//log.info("checking[" + x + "][" + y + "][" + z + "] type:" + type + " result:" + groundType);
                            if( groundType != -1 ) {
                                // Then we've hit ground
                                done[x][z] = true;
                                groundLeft--;

                                int elevation = leaf.getInfo().location.y + y + 1;


                                if( image.getElevation(tx, tz) != elevation ) {
                                    image.setElevation(tx, tz, (short)elevation);
                                    changed = true;
                                }
                                if( existing != groundType ) {
                                    image.setType(tx, tz, (byte)groundType);
                                    changed = true;
                                }
                                int sun = LightUtils.sun(lastLight);
                                int local = LightUtils.localMax(lastLight);
                                int overall = local - (15 - sun);
//log.info("setLight(" + tx + ", " + tz + ", " + overall + ") sun:" + sun + "  local:" + local + "  lastLight:" + Integer.toHexString(lastLight));
                                //image.setLight(tx, tz, (byte)overall);
                                if( image.getLight(tx, tz) != overall ) {
                                    image.setLight(tx, tz, (byte)overall);
                                    changed = true;
                                }

                                break;
                            }
                            lastLight = light;
                        }
                    }
                }
                if( groundLeft <= 0 ) {
                    break;
                }
            }

            // 2023-09-26 FIXME: this should probably be part of a general chain of updates
            // when columns have been recalculated.
            if( trees != null ) {
                // See if we need to resplat anything
                for( Tree tree : trees.getTrees(colId) ) {
                    tree.type.insertTree(tree, image);
                }

            }
        }

        return changed;
    }
}


