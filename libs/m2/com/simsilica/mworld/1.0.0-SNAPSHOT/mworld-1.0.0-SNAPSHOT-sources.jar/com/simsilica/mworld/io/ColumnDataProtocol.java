/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class ColumnDataProtocol implements ObjectProtocol<ColumnData> {

    static Logger log = LoggerFactory.getLogger(ColumnDataProtocol.class);

    // Version notes:
    // 3: when branchRevision was added
    private int protocolVersion = 3;

    private LeafDataProtocol leafProtocol = new LeafDataProtocol();
    private LightDataProtocol lightProtocol = new LightDataProtocol();
    private FluidDataProtocol fluidProtocol = new FluidDataProtocol();

    public ColumnDataProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }

    public void write( ColumnData col, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(col, out);
        } finally {
            out.close();
        }
    }

    @Override
    public void write( ColumnData col, BitOutputStream out ) throws IOException {

        // Write the protocol version first
        out.writeBits(protocolVersion, 16); // we can have 65k versions

        out.writeLongBits(col.getColumnId().getId(), 64);
        out.writeLongBits(col.getVersion().getVersion(), 64);
        out.writeLongBits(col.getGenerationFlags(), 64);
        out.writeLongBits(col.getBranchRevision(), 64);

        LeafData[] leafs = col.getLeafs();

        // Write out the size of the array... just in case we
        // change world heights later.
        out.writeBits(leafs.length, 8); // Way bigger than needed

        for( LeafData leaf : leafs ) {
            leafProtocol.write(leaf, out);
        }

        FluidData[] fluid = col.getFluid();
        out.writeBits(fluid.length, 8);
        for( FluidData fluidData : fluid ) {
            fluidProtocol.write(fluidData, out);
        }

        LightData[] lighting = col.getLighting();
        out.writeBits(lighting.length, 8);
        for( LightData lightData : lighting ) {
            lightProtocol.write(lightData, out);
        }
    }

    public ColumnData read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }

    @Override
    public ColumnData read( BitInputStream in ) throws IOException {
        int version = in.readBits(16);

        ColumnId columnId = new ColumnId(in.readLongBits(64));
        long dataVersion = in.readLongBits(64);
        long generationFlags = in.readLongBits(64);
        long branchRevision;
        if( version > 2 ) {
            branchRevision = in.readLongBits(64);
        } else {
            branchRevision = 0;
        }

        int arraySize = in.readBits(8);

        LeafData[] leafs = new LeafData[arraySize];
        for( int i = 0; i < arraySize; i++ ) {
            leafs[i] = leafProtocol.read(in);
        }

        int fluidSize = in.readBits(8);
        FluidData[] fluid = new FluidData[fluidSize];
        for( int i = 0; i < fluidSize; i++ ) {
            fluid[i] = fluidProtocol.read(in);
        }

        int lightingSize = in.readBits(8);
        LightData[] lighting = new LightData[lightingSize];
        for( int i = 0; i < lightingSize; i++ ) {
            lighting[i] = lightProtocol.read(in);
        }

        ColumnData result = new ColumnData(columnId, leafs, fluid, lighting,
                                           new DataVersion(dataVersion),
                                           generationFlags);
        result.setBranchRevision(branchRevision);
        return result;
    }
}

