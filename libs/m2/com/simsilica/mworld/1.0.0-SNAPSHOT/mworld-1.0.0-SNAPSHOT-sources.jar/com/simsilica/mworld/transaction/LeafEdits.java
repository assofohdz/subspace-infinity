/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.transaction;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mworld.CellChangeEvent;
import com.simsilica.mworld.DataType;
import com.simsilica.mworld.LeafId;

/**
 *  Keeps track of a set of cell edits that have been performed within
 *  a particular leaf.
 *
 *  @author    Paul Speed
 */
public class LeafEdits {
    static Logger log = LoggerFactory.getLogger(LeafEdits.class);

    private static final CellEdit[] EMPTY_ARRAY = new CellEdit[0];

    private static final int CHANGE_THRESHOLD = 10;

    private LeafId leafId;

    private List<CellEdit> blockChanges = new ArrayList<>();
    private List<CellEdit> lightChanges = new ArrayList<>();
    private List<CellEdit> fluidChanges = new ArrayList<>();

    public LeafEdits( LeafId leafId ) {
        this.leafId = leafId;
    }

    /**
     *  Use a spatial index to collapse redundant edits.
     */
    protected List<CellEdit> collapse( DataType type, List<CellEdit> changes ) {
        if( changes.size() <= CHANGE_THRESHOLD ) {
            return changes;
        }
log.info("Attempting to reduce " + changes.size() + " " + type + " changes");
        long start = System.nanoTime();
        Map<Vec3i, CellEdit> index = new HashMap<>();
        int removed = 0;
        for( int i = 0; i < changes.size(); i++ ) {
            CellEdit edit = changes.get(i);
            Vec3i loc = edit.getCellLocation();
            CellEdit previous = index.put(loc, edit);
            if( previous == null ) {
                // First time... it's fine
                continue;
            }

            // Else we may need to collapse out one or both.
            // Note: we assume that the final state of all of the different
            // buffers is accurate even if we skip changes.  This should be
            // true as long as transactions are all created an run in the same
            // thread sequentially.
            int oldValue = previous.getOldValue();
            int newValue = edit.getValue();
            if( log.isTraceEnabled() ) {
                log.trace("loc:" + loc + " oldValue:" + oldValue + " newValue:" + newValue
                          + "  skipping:" + previous.getValue() + "/" + edit.getOldValue());
            }
            if( oldValue == newValue ) {
                // Both are redundant
                removed += 2;
                index.remove(loc);
            } else {
                // Remember to replace the current one first before the list
                // shifts.
                CellEdit newEdit = new CellEdit(edit.getX(), edit.getY(), edit.getZ(), newValue, oldValue);
                removed++;
                index.put(loc, newEdit);
            }
        }

        if( removed == 0 ) {
            return changes;
        }

        // Block-to-block order shouldn't matter once we've collapsed it
        // down to the final edits.
        List<CellEdit> result = new ArrayList<>(index.values());

        long end = System.nanoTime();
        long duration = end - start;
log.info("Collapsed " + changes.size() + " " + type + " events to:" + result.size() + "  in:" + (duration/1000000.0) + " ms");
        return result;
    }

    public CellChangeEvent createCellChangeEvent() {
        blockChanges = collapse(DataType.Block, blockChanges);
        lightChanges = collapse(DataType.Light, lightChanges);
        fluidChanges = collapse(DataType.Fluid, fluidChanges);
        CellEdit[] blocks = blockChanges.isEmpty() ? null : blockChanges.toArray(EMPTY_ARRAY);
        CellEdit[] lights = lightChanges.isEmpty() ? null : lightChanges.toArray(EMPTY_ARRAY);
        CellEdit[] fluids = fluidChanges.isEmpty() ? null : fluidChanges.toArray(EMPTY_ARRAY);
        return new CellChangeEvent(leafId, blocks, lights, fluids);
    }

    public void cellChanged( DataType type, int i, int j, int k, int value, int oldValue ) {
        CellEdit edit = new CellEdit((byte)i, (byte)j, (byte)k, value, oldValue);
        switch( type ) {
            case Block:
                blockChanges.add(edit);
                break;
            case Light:
                lightChanges.add(edit);
                break;
            case Fluid:
                fluidChanges.add(edit);
                break;
            default:
                throw new UnsupportedOperationException("Type not yet supported:" + type);
        }
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[leafId:" + leafId
                            + ", #blockChanges:" + blockChanges.size()
                            + ", #lightChanges:" + lightChanges.size()
                            + ", #fluidChanges:" + fluidChanges.size()
                            + "]";
    }
}
