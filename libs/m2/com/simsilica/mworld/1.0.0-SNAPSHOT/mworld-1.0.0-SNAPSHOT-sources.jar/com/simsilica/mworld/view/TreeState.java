/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.material.Material;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.texture.Texture;
import com.jme3.scene.*;
import com.jme3.util.SafeArrayList;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.sim.Blackboard;
import com.simsilica.state.*;
import com.simsilica.thread.*;

import com.simsilica.mblock.geom.ColliderlessMesh;

import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.World;
import com.simsilica.mworld.tile.Resolution;
import com.simsilica.mworld.tile.tree.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class TreeState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(TreeState.class);

    private Node treeRoot;

    private Blackboard blackboard;
    private World world;
    private JobState workers;
    private int basePriority = 500;

    private VersionedReference<Vec3d> posRef;

    //private Texture treeAtlas;
    private Function<String, Material> materialFactory;

    private int treeRadius = 2;
    private int conveyorSize = treeRadius * 2 + 1;
    private TileGeometry[][] tiles = new TileGeometry[conveyorSize][conveyorSize];
    private Vec3i center = new Vec3i(0, 100, 0);  // set it to something that will never match
    private Vec3i centerWorld = new Vec3i();

    private FogSettings fogSettings;
    private VersionedReference<FogSettings> fogSettingsRef;

    private float clipDistance = 6000;

    private SafeArrayList<TileGeometry> fadingTiles = new SafeArrayList<>(TileGeometry.class);

    // True if the camera never moves in xz space, false if it moves within its grid cell.
    // In the long run, this is not as flexible as it needs to be but it will work today.
    private boolean xzLockedCamera = false;

    private ViewMask viewMask;
    private VersionedReference<Vec3i> maskCenter;

    public TreeState() {
        this(false);
    }

    public TreeState( Blackboard blackboard ) {
        this(false);
        this.blackboard = blackboard;
    }

    public TreeState( boolean xzLockedCamera ) {
        //setEnabled(false);
        this.xzLockedCamera = xzLockedCamera;
    }

    public void setXzLockedCamera( boolean f ) {
        this.xzLockedCamera = f;
    }

    public boolean isXzLockedCamera() {
        return xzLockedCamera;
    }

    public void setMaterialFactory( Function<String, Material> materialFactory ) {
        if( this.materialFactory == materialFactory ) {
            return;
        }
        this.materialFactory = materialFactory;
        if( tiles != null ) {
            for( int i = 0; i < conveyorSize; i++ ) {
                for( int j = 0; j < conveyorSize; j++ ) {
                    TileGeometry tile = tiles[i][j];
                    if( tile == null ) {
                        continue;
                    }
                    tile.updateMaterial(materialFactory);
                }
            }
        }
    }

    public Function<String, Material> getMaterialFactory() {
        return materialFactory;
    }

    public void setClipDistance( float distance ) {
        if( this.clipDistance == distance ) {
            return;
        }
        this.clipDistance = distance;
        resetFog();
    }

    public float getClipDistance() {
        return clipDistance;
    }

    public void setFogSettings( FogSettings fogSettings ) {
        this.fogSettings = fogSettings;
        fogSettingsRef = fogSettings == null ? null : fogSettings.createReference();
        resetFog();
    }

    public FogSettings getFogSettings() {
        return fogSettings;
    }

    protected int getFogDistance() {
        return fogSettings == null ? 0 : fogSettings.getFogDistance();
    }

    protected void resetFog() {
        if( treeRoot != null ) {
            TerrainState.updateFogDistance(treeRoot, getFogDistance(), clipDistance);
        }
    }

    protected void setViewMask( ViewMask viewMask ) {
        this.viewMask = viewMask;
        this.maskCenter = viewMask.createReference();

        if( tiles != null ) {
            for( int i = 0; i < conveyorSize; i++ ) {
                for( int j = 0; j < conveyorSize; j++ ) {
                    TileGeometry tile = tiles[i][j];
                    if( tile == null ) {
                        continue;
                    }
                    // Let the tile know where the latest center is
                    tile.updateViewMask();
                }
            }
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {
        this.treeRoot = new Node("TreesRoot");

        // If no material material factory is defined then set one up
        if( getMaterialFactory() == null ) {
            log.warn("No material factory configured.  Using a default treeBuildboardMaterial()");

            setMaterialFactory(MaterialFactories.treeBillboardMaterial(getApplication()));
        }

        if( blackboard == null ) {
            blackboard = getState(BlackboardState.class, true).getBlackboard();
        }
        // If something sets a view mask then we'll use it.
        this.world = blackboard.get(World.class);

        blackboard.onInitialize(ViewMask.class, (ViewMask mask) -> { setViewMask(mask); });
        blackboard.onInitialize(FogSettings.class, (FogSettings fogSettings) -> { setFogSettings(fogSettings); });

        workers = getState("regularWorkers", JobState.class);

        // FIXME: give blackboard a better casting pattern to avoid requiring warning suppression
        posRef = ((VersionedObject<Vec3d>)blackboard.get("position")).createReference();
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getRootNode().attachChild(treeRoot);
    }

    @Override
    protected void onDisable() {
        treeRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( posRef.update() ) {
            Vec3d pos = posRef.get();
            updateTiles(pos);

            if( xzLockedCamera ) {
                treeRoot.setLocalTranslation(-(float)(pos.x - centerWorld.x), 0, -(float)(pos.z - centerWorld.z));
            } else {
                // Only move it when crossing column boundaries
                Vec3d columnPos = ColumnId.fromWorld(pos).getWorld(null).toVec3d();
                treeRoot.setLocalTranslation(-(float)(columnPos.x - centerWorld.x), 0, -(float)(columnPos.z - centerWorld.z));
            }
        }

        if( fogSettingsRef != null && fogSettingsRef.update() ) {
            resetFog();
        }

        // Tree tiles are much bigger than the mask cells so if the tree
        // tile boundary was crossed then we are also guaranteed to have
        // updated the mask center... which is why we get away without having
        // to set mask center in the updateTiles() method.
        if( maskCenter.update() ) {
            Vec3i columnPos = ColumnId.fromWorld(posRef.get()).getWorld(null);
            for( int i = 0; i < conveyorSize; i++ ) {
                for( int j = 0; j < conveyorSize; j++ ) {
                    TileGeometry tile = tiles[i][j];
                    if( tile == null ) {
                        continue;
                    }
                    // Let the tile know where the latest center is
                    tile.setMaskCenter(columnPos, maskCenter.get());
                }
            }
        }

        for( TileGeometry tg : fadingTiles.getArray() ) {
            tg.update(tpf);
        }
    }


    protected void updateTiles( Vec3d pos ) {

        Vec3i newCenter = TileId.GRID.worldToCell(pos);
        Vec3i columnPos = ColumnId.fromWorld(pos).getWorld(null);

        if( newCenter.equals(center) ) {
            return;
        }
        center.set(newCenter);
        centerWorld = TileId.GRID.cellToWorld(center);

        System.out.println("Need to refresh tree tiles.... tile Center:" + center + "  world center:" + centerWorld);

        int radius = treeRadius;

        Map<Long, TileGeometry> tileMap = new HashMap<>();

        // Copy the existing tiles into the index
        for( int x = -radius; x <= radius; x++ ) {
            for( int y = -radius; y <= radius; y++ ) {
                TileGeometry tile = tiles[x+radius][y+radius];
                if( tile == null ) {
                    continue;
                }
//System.out.println("Saving tile:" + tile.id);
                tileMap.put(tile.id, tile);
//tile.geom.removeFromParent();
            }
        }

        for( int x = -radius; x <= radius; x++ ) {
            for( int y = -radius; y <= radius; y++ ) {

                int xTile = centerWorld.x + x * 1024;
                int zTile = centerWorld.z + y * 1024;
                long id = calculateTileId(xTile, centerWorld.y, zTile);
//System.out.println("Looking up tile:" + id);
                TileGeometry tile = tileMap.remove(id);
                if( tile == null ) {
                    //tile = createTile(xTile, zTile);
                    //tile.geom = createGeometry(tile.treeTile);
                    //treeRoot.attachChild(tile.geom);
                    tile = new TileGeometry(id, xTile, centerWorld.y, zTile);
                    tile.setMaskCenter(columnPos, maskCenter.get());
                    int priority = basePriority + x * x + y * y;
                    workers.execute(tile, priority);
                } else {
                    //System.out.println("Reusing tile for:" + xTile + ", " + zTile);
                }

                //tile.geom.setLocalTranslation((float)(x * 1024), -64, (float)(y * 1024));
                tile.setPosition((float)(x * 1024), 0, (float)(y * 1024));

//System.out.println("Set geometry location to:" + tile.geom.getLocalTranslation());
                tiles[x + radius][y + radius] = tile;
            }
        }

        for( TileGeometry tile : tileMap.values() ) {
            //System.out.println("Removing tile:" + tile.treeTile.xCorner + ", " + tile.treeTile.yCorner);
            //tile.geom.removeFromParent();
            tile.release();
        }

    }

    protected Geometry createGeometry( TreeLayer layer ) {

        List<Tree> trees = layer.getTrees();

        // For now we only support one atlas name so we'll check and extract it
        String atlasName = null;
        for( Tree tree : trees ) {
            String name = tree.type.getAtlasCell(tree).getAtlasName();
            if( atlasName == null ) {
                atlasName = name;
            } else if( !atlasName.equals(name) ) {
                throw new UnsupportedOperationException("Multiple atlases not yet supported.");
            }
        }

        // For now just vertical lines to show us where things
        // are.
        Mesh mesh = new ColliderlessMesh("trees[" + layer + "]");
        mesh.setMode(Mesh.Mode.Triangles);

        int verts = trees.size() * 4;
        int triangles = trees.size() * 2;
        float[] fv = new float[verts * 3];
        float[] ft = new float[verts * 2];
        float[] sizeb = new float[verts];
        int[]   ib = new int[triangles * 3 * 2];
        int fp = 0;
        int ti = 0;
        int si = 0;
        int index = 0;
        int baseIndex = 0;
        for( Tree tree : trees ) {

            //float u = (tree.type.cell % 4) / 4f;
            //float v = 1f - (tree.type.cell / 4) / 4f - 0.25f;

            float radius = tree.radius + 1;
            float height = tree.height;

            float x = (float)(tree.x + 0.5);
            float y = (float)tree.y;
            float z = (float)(tree.z + 0.5);

            int cell = tree.type.getAtlasCell(tree).getIndex();
//if( cell == 4 ) {
//    log.info("tree with atlas cell 4, type:" + tree.type);
//} else {
//    cell = 8;
//}
//if( tree.type.getIndex() > 3 ) {
//    log.info("tree with high type:" + tree.type);
//}

            fv[fp++] = x;
            fv[fp++] = y;
            fv[fp++] = z;

            ft[ti++] = -radius;
            ft[ti++] = 0;
            sizeb[si++] = (byte)cell;

            fv[fp++] = x;
            fv[fp++] = y;
            fv[fp++] = z;

            ft[ti++] = radius;
            ft[ti++] = 0;
            sizeb[si++] = (byte)cell;

            fv[fp++] = x;
            fv[fp++] = y;
            fv[fp++] = z;

            ft[ti++] = radius;
            ft[ti++] = height;
            sizeb[si++] = (byte)cell;

            fv[fp++] = x;
            fv[fp++] = y;
            fv[fp++] = z;

            ft[ti++] = -radius;
            ft[ti++] = height;
            sizeb[si++] = (byte)cell;

            ib[index++] = baseIndex + 0;
            ib[index++] = baseIndex + 1;
            ib[index++] = baseIndex + 2;
            ib[index++] = baseIndex + 0;
            ib[index++] = baseIndex + 2;
            ib[index++] = baseIndex + 3;

            baseIndex += 4;
        }
        mesh.setBuffer(VertexBuffer.Type.Position, 3, fv);
        mesh.setBuffer(VertexBuffer.Type.Index, 3, ib);
        mesh.setBuffer(VertexBuffer.Type.TexCoord, 2, ft);
        mesh.setBuffer(VertexBuffer.Type.Size, 1, sizeb);
        mesh.updateBound();
        mesh.setStatic();

        Vec3i worldPos = layer.getTileId().getWorld(null);
        Geometry geom = new Geometry(worldPos.x + "x" + worldPos.y, mesh);
        geom.setUserData("atlasName", atlasName);

        Material mat = materialFactory.apply(geom.getUserData("atlasName"));
        if( fogSettings != null ) {
            fogSettings.apply(mat);
        }
        geom.setMaterial(mat);

        //geom.setLocalTranslation(tile.xCorner, -64, tile.yCorner);
        geom.setQueueBucket(Bucket.Transparent);

        TerrainState.updateFogDistance(geom, getFogDistance(), clipDistance);

        return geom;
    }

    protected long calculateTileId( int xCorner, int yCorner, int zCorner ) {
        Vec3i cell = TileId.GRID.worldToCell(xCorner, yCorner, zCorner);
        return TileId.GRID.cellToId(cell.x, cell.y, cell.z);
    }

    private class TileGeometry implements Job {
        long id;
        int xCorner;
        int yCorner;
        int zCorner;
        TreeLayer treeLayer;

        Geometry geom;
        Vector3f position = new Vector3f();

        volatile Geometry viewGeom;
        Vector3f maskOffset = new Vector3f();

        volatile boolean visible;
        boolean firstTime = true;

        float alpha;

        public TileGeometry( long id, int xCorner, int yCorner, int zCorner ) {
            this.id = id;
            this.xCorner = xCorner;
            this.yCorner = yCorner;
            this.zCorner = zCorner;
            this.visible = true;
        }

        public void updateMaterial( Function<String, Material> materialFactory ) {
            if( viewGeom != null ) {
                Material material = materialFactory.apply(viewGeom.getUserData("atlasName"));
                if( fogSettings != null ) {
                    fogSettings.apply(material);
                }
                viewGeom.setMaterial(material);
            }
        }

        public void updateViewMask() {
            Material material = viewGeom.getMaterial();
            if( log.isTraceEnabled() ) {
                log.trace(id + ".updateViewMask() viewMask:" + viewMask + "  material:" + material);
            }
            if( viewMask != null && material != null ) {
                material.setTexture("MaskArray", viewMask.getMaskTextures());
                material.setVector3("MaskOffset", maskOffset);
                material.setFloat("ViewMaskRadiusXZ", viewMask.getViewRadius().x);
                material.setFloat("ViewMaskRadiusY", viewMask.getViewRadius().y);
            }
        }

        public void setMaskCenter( Vec3i colPos, Vec3i viewCenter ) {
            if( log.isTraceEnabled() ) {
                log.trace(id + ".setMaskCenter(" + center + ") world:" + xCorner + ", " + zCorner);
            }

            // The view mask coordinate is taken directly from the
            // vertex position offset by -maskOffset.
            // The view mask's "center" is the leaf-grid position of the
            // camera... all view mask cells are +/- relative to that location.
            // We want to set the mask offset such that it moves our model
            // position into this range as appropriate for the camera position.

            maskOffset.x = viewCenter.x - xCorner;
            maskOffset.y = viewCenter.y;
            maskOffset.z = viewCenter.z - zCorner;
            // So then in the shader, (modelSpacePos - maskOffset) / 32 should
            // be our mask texture coordinate.
        }

        public void update( float tpf ) {
            alpha += tpf;
            if( alpha >= 1f ) {
                fadingTiles.remove(this);
                alpha = 1;
            }
            geom.getMaterial().setFloat("Alpha", alpha);
        }

        public void setPosition( float x, float y, float z ) {
            position.set(x, y, z);
            if( geom != null ) {
                geom.setLocalTranslation(x, y, z);
            }
        }

        public void release() {
            visible = false;
            if( geom != null ) {
                geom.removeFromParent();
            }
        }

        @Override
        public void runOnWorker() {
            if( !visible ) {
                return;
            }
            this.treeLayer = world.getTrees(TileId.fromWorld(xCorner, yCorner, zCorner), Resolution.High);
            this.geom = createGeometry(treeLayer);
        }

        @Override
        public double runOnUpdate() {
            if( visible ) {
                viewGeom = geom;
                updateViewMask();
                treeRoot.attachChild(geom);
                geom.setLocalTranslation(position);
                if( firstTime ) {
                    firstTime = false;
                    alpha = 0;
                    fadingTiles.add(this);
                } else {
                    alpha = 1;
                }
                geom.getMaterial().setFloat("Alpha", alpha);
                return 1;
            } else {
                return 0;
            }
        }

        @Override
        public String toString() {
            return "Trees[" + xCorner + ", " + zCorner + "]";
        }
    }

}
