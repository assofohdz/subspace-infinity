/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.transaction;

import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mathd.Vec3i;

import com.simsilica.mworld.DataType;


/**
 *  Represent an edit of a single cell value of any kind.
 *
 *  @author    Paul Speed
 */
public class CellEdit {
    static Logger log = LoggerFactory.getLogger(CellEdit.class);

    private byte x;
    private byte y;
    private byte z;
    private int value;
    private int oldValue;

    // Keeping the old value and the new value will let us interpret
    // what actually has changed... value versus mask for example, and apply
    // just that edit.

    public CellEdit( byte x, byte y, byte z, int value, int oldValue ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.value = value;
        this.oldValue = oldValue;
    }

    public final boolean apply( DataType dataType, CellData cells ) {
        // Pass the value as the default so that this is a no-op if
        // we are out of bounds in some way.
        int existing = cells.getCell(x, y, z, value);
        if( existing == value ) {
            // No change at any level.
            return false;
        }

        int result = value;

        if( log.isTraceEnabled() ) {
            log.trace("apply(" + x + ", " + y + ", " + z + ", " + dataType + ")");
        }

        // Now we need to be smart about what we set.
        switch( dataType ) {
            case Block:
                int oldType = MaskUtils.getType(oldValue);
                int oldMask = MaskUtils.getSideMask(oldValue);
                int newType = MaskUtils.getType(value);
                int newMask = MaskUtils.getSideMask(value);
                int type;
                if( oldType != newType ) {
                    type = newType;
                    if( log.isTraceEnabled() ) {
                        log.trace("   changing type to:" + type);
                    }
                } else {
                    type = MaskUtils.getType(existing);
                }
                int mask;
                if( oldMask != newMask ) {
                    mask = newMask;
                    if( log.isTraceEnabled() ) {
                        log.trace("   changing mask to:" + Integer.toHexString(mask));
                    }
                } else {
                    mask = MaskUtils.getSideMask(existing);
                }
                result = MaskUtils.setSideMask(type, mask);
                break;

            // FIXME: do a similar breakdown of at least fluid for change detection
            case Light:
            case Fluid:
                break;
        }

        if( log.isTraceEnabled() ) {
            log.trace(dataType + " setCell(" + x + ", " + y + ", " + z + ", " + result + ")  existing:" + existing);
        }

        cells.setCell(x, y, z, result);
        return true;
    }

    public final byte getX() {
        return x;
    }

    public final byte getY() {
        return y;
    }

    public final byte getZ() {
        return z;
    }

    public final Vec3i getCellLocation() {
        return new Vec3i(x, y, z);
    }

    public final int getValue() {
        return value;
    }

    public final int getOldValue() {
        return oldValue;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[cellLocation=" + getCellLocation() + ", value=" + value + ", oldValue=" + oldValue + "]";
    }

}
