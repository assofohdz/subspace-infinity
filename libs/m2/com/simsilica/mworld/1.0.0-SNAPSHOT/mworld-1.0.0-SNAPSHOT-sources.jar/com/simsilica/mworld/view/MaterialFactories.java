/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.material.Material;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.ColorRGBA;
import com.jme3.texture.Texture;

import com.simsilica.mworld.tile.TerrainImageType;
import com.simsilica.mworld.tile.pc.PointType;

/**
 *  A set of standard material factories for terrain and far terrain.
 *
 *  @author    Paul Speed
 */
public class MaterialFactories {
    static Logger log = LoggerFactory.getLogger(MaterialFactories.class);

    public static Function<TerrainImageType, Material> coloredTerrainMaterial( final Application app,
                                                                               final ColorRGBA groundColor,
                                                                               final ColorRGBA waterColor ) {
        return (TerrainImageType type) -> {

                String matDef = "MatDefs/terrain/Terrain.j3md";
                ColorRGBA color = groundColor;
                if( type == TerrainImageType.Fluid ) {
                    //matDef = "MatDefs/terrain/WaterTiles.j3md";
                    color = waterColor;
                }

                Material mat = new Material(app.getAssetManager(), matDef);
                mat.setBoolean("UseMaterialColors", true);
                mat.setColor("Diffuse", color);
                mat.setColor("Ambient", ColorRGBA.White);
                if( color.a < 1 ) {
                    mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                }
                if( type != TerrainImageType.Fluid ) {
                    // For non-water we will want calculated normals
                    mat.setBoolean("CalculateNormals", true);
                }
                mat.setBoolean("SmoothLighting", true);

                return mat;
            };
    }

    public static Function<TerrainImageType, Material> coloredFarTerrainMaterial( final Application app,
                                                                                  final ColorRGBA groundColor,
                                                                                  final ColorRGBA waterColor ) {
        return (TerrainImageType type) -> {

                ColorRGBA color = groundColor;
                if( type == TerrainImageType.Fluid ) {
                    color = waterColor;
                }

                Material mat = new Material(app.getAssetManager(), "MatDefs/terrain/Terrain.j3md");
                mat.setBoolean("UseMaterialColors", true);
                mat.setColor("Diffuse", color);
                mat.setColor("Ambient", color);

                if( type != TerrainImageType.Fluid ) {
                    // For non-water we will want calculated normals
                    mat.setBoolean("CalculateNormals", true);
                }
                mat.setBoolean("SmoothLighting", true);

                if( color.a < 1 ) {
                    mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
                }

                return mat;
            };
    }


    public static Function<String, Material> treeBillboardMaterial( final Application app ) {
        return (String atlasName) -> {

                Material mat = new Material(app.getAssetManager(), "MatDefs/tree/TreeBB.j3md");
                if( atlasName != null ) {
                    Texture treeAtlas = app.getAssetManager().loadTexture(atlasName);
                    mat.setTexture("DiffuseMap", treeAtlas);
                }
                mat.setFloat("AlphaDiscardThreshold", 0.25f);
                mat.setBoolean("UseMaterialColors", true);
                mat.setColor("Diffuse", new ColorRGBA(1.00f, 1.00f, 1.00f, 1.0f));
                mat.setColor("Ambient", new ColorRGBA(1.00f, 1.00f, 1.00f, 1.0f));

                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

                return mat;
            };
    }

    public static Function<PointType, Material> pointCloudMaterial( final Application app ) {

        return (PointType type) -> {

                Material mat = new Material(app.getAssetManager(), "MatDefs/BlockPoints.j3md");

                // Just use a default texture
                Texture atlas = app.getAssetManager().loadTexture("Textures/palette1.png");
                mat.setTexture("ColorMap", atlas);

                mat.setFloat("ClipDistance", 8192);

                mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);

                return mat;
            };

    }

}



