/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.pc;

import java.io.*;
import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.io.*;
import com.simsilica.mworld.tile.Resolution;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PointCloudLayerProtocol implements ObjectProtocol<PointCloudLayer> {

    static Logger log = LoggerFactory.getLogger(PointCloudLayerProtocol.class);

    private int version = 1;
    private PointCloudDataProtocol pcProtocol = new PointCloudDataProtocol();

    public PointCloudLayerProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return version;
    }

    public void write( PointCloudLayer layer, BitOutputStream out ) throws IOException {

        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        // Header stuff
        long id = layer.getTileId().getId();
        out.writeLongBits(id, 64);
        out.writeLongBits(layer.getVersion().getVersion(), 64);
        int scale = 1024/layer.getResolution().getSamples();
        out.writeBits(scale, 8); // max 16... there are only three diffferent ones
                                           // so we could get away with 2 bits.

        Collection<PointCloudData> pointClouds = layer.getPointClouds();

        // Max is 32x32 columns, so 11 bits because we need to capture 0 also
        int maxSize = 0b11111111111;
        if( pointClouds.size() > maxSize ) {
            throw new RuntimeException("Major problems, point clouds count somehow exceeds max size."
                                        + "count:" + pointClouds.size() + " max:" + maxSize);
        }
        out.writeBits(pointClouds.size(), 11);

        for( PointCloudData pc : pointClouds ) {
            pcProtocol.write(pc, out);
        }
    }

    public PointCloudLayer read( BitInputStream in ) throws IOException {

        int version = in.readBits(16);
        // Could check version to see if we need to read in a special way

        // Read the header and create the tile
        TileId id = new TileId(in.readLongBits(64));
        long dataVersion = in.readLongBits(64);
        DataVersion layerVersion = new DataVersion(dataVersion);

        int scale = in.readBits(8);
        int size = 1024 / scale;
        Resolution res = Resolution.fromSamples(size);

        PointCloudLayer layer = new PointCloudLayer(id, layerVersion, res);

        int count = in.readBits(11);
        for( int i = 0; i < count; i++ ) {
            PointCloudData pc = pcProtocol.read(in);
            layer.updatePointCloud(pc);
        }

        return layer;
    }

    public void write( PointCloudLayer layer, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(layer, out);
        } finally {
            out.close();
        }
    }

    public PointCloudLayer read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }
}

