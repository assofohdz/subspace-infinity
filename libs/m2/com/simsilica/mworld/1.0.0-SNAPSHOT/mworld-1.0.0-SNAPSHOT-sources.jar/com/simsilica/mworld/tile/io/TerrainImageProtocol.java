/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.io;

import java.io.*;

import org.slf4j.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.io.ObjectProtocol;
import com.simsilica.mworld.tile.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TerrainImageProtocol implements ObjectProtocol<TerrainImage> {

    static Logger log = LoggerFactory.getLogger(TerrainImageProtocol.class);

    private static final int ELEVATION_BITS = 10; // 0-1024 possible
    private static final int TYPE_BITS = 8;
    private static final int LIGHT_BITS = 8;

    // 42 is the original version.
    // 43 includes the generation level
    private int version = 43;

    public TerrainImageProtocol() {
    }

    public int getProtocolVersion() {
        return version;
    }

    public void write( TerrainImage terrain, BitOutputStream out ) throws IOException {
        // Write the protocol version first
        out.writeBits(version, 16); // we can have 65k versions

        // Header stuff
        TerrainImageId imageId = terrain.getId();
        long id = imageId.getTileId().getId();
        out.writeLongBits(id, 64);
        int scale = 1024/imageId.getResolution().getSamples();
        out.writeBits(scale, 8); // max 16... there are only three diffferent ones
                                           // so we could get away with 2 bits.
        out.writeBits(imageId.getType().getId(), 4);
        out.writeLongBits(terrain.getVersion().getVersion(), 64);
        out.writeBits(terrain.getGenerationLevel(), 8);

        int size = terrain.getSize();
        size = size * size;

        // For now just a straight dump, no compression
        short[] elevations = terrain.getElevations();
        for( int i = 0; i < size; i++ ) {
            out.writeBits(elevations[i], ELEVATION_BITS);
        }
        byte[] types = terrain.getTypes();
        for( int i = 0; i < size; i++ ) {
            out.writeBits(types[i], TYPE_BITS);
        }
        byte[] lights = terrain.getLights();
        for( int i = 0; i < size; i++ ) {
            out.writeBits(lights[i], LIGHT_BITS);
        }
    }

    public TerrainImage read( BitInputStream in ) throws IOException {
        int version = in.readBits(16);
        // Could check version to see if we need to read in a special way

        // Read the header and create the tile
        TileId tileId = new TileId(in.readLongBits(64));
        int scale = in.readBits(8);
        int typeId = in.readBits(4);
        int size = 1024 / scale;

        long dataVersion = in.readLongBits(64);
        DataVersion layerVersion = new DataVersion(dataVersion);
        int generationLevel = 0;
        if( version >= 43 ) {
            // Then we can read the generation level
            generationLevel = in.readBits(8);
        }
        Resolution resolution = Resolution.fromSamples(size);
        TerrainImageType type = TerrainImageType.forId(typeId);

        TerrainImageId id = new TerrainImageId(tileId, type, resolution);
        TerrainImage layer = new TerrainImage(id, layerVersion, generationLevel);

        size = size * size;
        short[] elevations = layer.getElevations();
        for( int i = 0; i < size; i++ ) {
            elevations[i] = (short)in.readBits(ELEVATION_BITS);
        }
        byte[] types = layer.getTypes();
        for( int i = 0; i < size; i++ ) {
            types[i] = (byte)in.readBits(TYPE_BITS);
        }
        byte[] lights = layer.getLights();
        for( int i = 0; i < size; i++ ) {
            lights[i] = (byte)in.readBits(LIGHT_BITS);
        }

        return layer;
    }

    public void write( TerrainImage terrain, OutputStream rawOut ) throws IOException {
        BitOutputStream out = new BitOutputStream(rawOut);
        try {
            write(terrain, out);
        } finally {
            out.close();
        }
    }

    public TerrainImage read( InputStream rawIn ) throws IOException {
        BitInputStream in = new BitInputStream(rawIn);
        try {
            return read(in);
        } finally {
            in.close();
        }
    }
}

