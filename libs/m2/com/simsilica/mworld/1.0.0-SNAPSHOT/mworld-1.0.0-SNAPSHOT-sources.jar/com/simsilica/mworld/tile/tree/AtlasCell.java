/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import java.util.*;

import org.slf4j.*;

/**
 *  Represents a cell in a particular atlas.  This is a more general
 *  class than just for trees and should probably move... but here is
 *  where I need it today.  If I have some other use-cases in the future
 *  then I will figure out where it really needs to live.
 *
 *  @author    Paul Speed
 */
public class AtlasCell implements java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(AtlasCell.class);

    static final long serialVersionUID = 42L;
        
    private String atlasName;
    private int index;

    public AtlasCell( String atlasName, int index ) {
        this.atlasName = atlasName;
        this.index = index;
    }

    public String getAtlasName() {
        return atlasName;
    }

    public int getIndex() {
        return index;
    }

    public int hashCode() {
        return Objects.hash(atlasName, index);
    }

    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        AtlasCell other = (AtlasCell)o;
        if( other.index != index ) {
            return false;
        }
        if( !Objects.equals(other.atlasName, atlasName) ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "AtlasCell[atlasName:" + atlasName + ", index:" + index + "]";
    }
}
