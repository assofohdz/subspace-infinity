/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import java.util.Objects;
import java.util.function.Consumer;

import com.simsilica.mathd.*;


/**
 *  The unique ID of a 32x32 area of the map.
 *
 *  @author    Paul Speed
 */
public class ColumnId implements GridBasedId {
    public static final int SIZE = WorldGrids.LEAF_SIZE;
    public static final Grid GRID = WorldGrids.COLUMN_GRID;

    private long columnId;

    public ColumnId( long columnId ) {
        this.columnId = columnId;
    }

    public static ColumnId fromWorld( Vec3i world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    public static ColumnId fromWorld( Vec3d world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    public static ColumnId fromWorld( double x, double y, double z ) {
        long id = GRID.worldToId(x, y, z);
        return new ColumnId(id);
    }

    public static ColumnId fromWorld( int x, int y, int z ) {
        long id = GRID.worldToId(x, y, z);
        return new ColumnId(id);
    }

//    public static ColumnId fromWorld( double x, double z ) {
//        long id = GRID.worldToId(x, 0, z);
//        return new ColumnId(id);
//    }

//    public static ColumnId fromWorld( int x, int z ) {
//        long id = GRID.worldToId(x, 0, z);
//        return new ColumnId(id);
//    }

    @Override
    public long getId() {
        return columnId;
    }

    /**
     *  Returns the world location of this column.
     */
    public Vec3i getWorld( Vec3i store ) {
        Vec3i loc = GRID.idToCell(columnId, store);
        loc = GRID.cellToWorld(loc, loc);
        return loc;
    }

    @Override
    public GridCell getGridCell() {
        return getGrid().getContainingCell(getWorld(null));
    }

    /**
     *  Returns the ID of the tile (1024x1024 area) that contains
     *  this column
     */
    public TileId getTileId() {
        Vec3i world = getWorld(null);
        return TileId.fromWorld(world);
    }

    /**
     *  Returns the tile-relative location of this column in
     *  column world space.  x=0..1023, z=0..1023
     */
    public Vec3i getTileLocal( Vec3i store ) {
        TileId tileId = getTileId();
        Vec3i local = getWorld(store);
        local.subtractLocal(tileId.getWorld(null));
        return local;
    }

    /**
     *  Returns the tile-relative location of this column in
     *  column cell space. x=0..31, z=0..31.
     */
    public Vec3i getTileLocalIndex( Vec3i store ) {
        TileId tileId = getTileId();
        Vec3i local = getWorld(store);
        local.subtractLocal(tileId.getWorld(null));
        local.x = local.x / SIZE;
        local.z = local.z / SIZE;
        return local;
    }

    /**
     *  Returns the per-tile-unique ID of the tile-relative column.
     *  This will be a value from 0..1023 representing the grid cell
     *  within the tile.
     */
    public short getTileLocalIndexId() {
        Vec3i local = getTileLocalIndex(null);
        return (short)((local.z << 5) | local.x);
    }

    public static short toTileLocalIndexId( int xLocal, int zLocal ) {
        return (short)((zLocal << 5) | xLocal);
    }

    public static ColumnId fromTileLocalIndex( TileId id, int x, int z ) {
        Vec3i world = id.getWorld(null);
        world.addLocal(x * SIZE, 0, z * SIZE);
        return fromWorld(world);
    }

    public static ColumnId fromTileLocal( TileId id, int x, int z ) {
        Vec3i world = id.getWorld(null);
        world.addLocal(x, 0, z);
        return fromWorld(world);
    }

    public static ColumnId fromTileLocalIndexId( TileId id, short indexId ) {
        int x = indexId & 0x1f;
        int z = indexId >> 5;
        return fromTileLocalIndex(id, x, z);
    }

    public LeafId[] getLeafIds( int yMax ) {
        int leafCount = yMax / LeafId.SIZE;
        LeafId[] result = new LeafId[leafCount];
        Vec3i base = getWorld(null);
        for( int i = 0; i < leafCount; i++ ) {
            result[i] = LeafId.fromWorld(base.add(0, i * LeafId.SIZE, 0));
        }
        return result;
    }

    public boolean contains( LeafId leafId ) {
        if( leafId == null ) {
            return false;
        }
        // Just the straight forward way for now but we could
        // also do math without the garbage
        ColumnId colId = leafId.getColumnId();
        return colId.getId() == this.columnId;
    }

    public boolean contains( Vec3i world ) {
        ColumnId id = ColumnId.fromWorld(world.x, world.y, world.z);
        return id.columnId == columnId;
    }

    @Override
    public Grid getGrid() {
        return GRID;
    }

    @Override
    public Grid getParentGrid() {
        return TileId.GRID;
    }

    public void visitNeighbors( int radius, Consumer<ColumnId> visitor ) {
        Vec3i origin = getWorld(null);
        for( int x = -radius; x <= radius; x++ ) {
            for( int z = -radius; z <= radius; z++ ) {
                visitor.accept(fromWorld(origin.x + SIZE * x, origin.y, origin.z + SIZE * z));
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(columnId);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        ColumnId other = (ColumnId)o;
        if( other.columnId != columnId ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[id:" + columnId + ", tileId:" + getTileId() + "]";
    }
}



