/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class LeafData implements CellData {
    private LeafInfo info;
    private CellArray cells;
    private int emptyCells;

    public LeafData( LeafId id, long version ) {
        this(new LeafInfo(id.getWorld(null), id, new DataVersion(version)));
    }

    public LeafData( LeafInfo info ) {
        this(info, null, LeafInfo.CELL_COUNT);
    }

    public LeafData( LeafInfo info, CellArray cells, int emptyCellCount ) {
        this.info = info;
        this.cells = cells;
        this.emptyCells = emptyCellCount;
if( cells == null && !isEmpty() ) {
    throw new IllegalArgumentException("Cells array is null but leaf is not empty");
}
    }

    public final int getEmptyCellCount() {
        return emptyCells;
    }

    public final boolean isEmpty() {
        return emptyCells == LeafInfo.CELL_COUNT;
    }

    public final boolean containsCell( Vec3i world ) {
        return containsCell(world.x, world.y, world.z);
    }

    public final boolean containsCell( int x, int y, int z ) {
        x = x - info.location.x;
        y = y - info.location.y;
        z = z - info.location.z;
        return isValid(x, y, z);
    }

    private boolean isValid( int x, int y, int z ) {
        if( x < 0 || y < 0 || z < 0 ) {
            return false;
        }
        if( x >= LeafInfo.SIZE || y >= LeafInfo.SIZE || z >= LeafInfo.SIZE ) {
            return false;
        }
        return true;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        /*if( !isValid(x, y, z) ) {
            throw new IndexOutOfBoundsException("[" + x + ", " + y + ", " + z + "]");
        }*/
        return cells == null ? 0 : cells.getCell(x, y, z);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        /*if( !isValid(x, y, z) ) {
            throw new IndexOutOfBoundsException("[" + x + ", " + y + ", " + z + "]");
        }*/
        return cells == null ? 0 : cells.getCell(x, y, z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        /*if( !isValid(x, y, z) ) {
            throw new IndexOutOfBoundsException("[" + x + ", " + y + ", " + z + "]");
        }*/
        return cells == null ? 0 : cells.getCell(x, y, z, dir, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
        /*if( !isValid(x, y, z) ) {
            throw new IndexOutOfBoundsException("[" + x + ", " + y + ", " + z + "]");
        }*/
        if( cells == null ) {
            // Initialize the cells array
            cells = new CellArray(LeafInfo.SIZE);
            cells.setCell(x, y, z, value);
            emptyCells--;
            return;
        }

        int oldVal = cells.getCell(x, y, z);
        cells.setCell(x, y, z, value);

        // If the old value was empty and the new value isn't then
        // we need to decrement the empty cells.  And vice versa
        if( oldVal == 0 && value != 0 ) {
            emptyCells--;
        } else if( oldVal != 0 && value == 0 ) {
            // New value is empty and old value wasn't
            emptyCells++;
        }
    }

    public LeafId getLeafId() {
        return info.leafId;
    }

    public LeafInfo getInfo() {
        return info;
    }

    public CellArray getRawCells() {
        return cells;
    }

    public int[] getArray() {
        return cells == null ? null : cells.getArray();
    }

    public void setData( LeafData data ) {
        if( cells == null || data.cells == null ) {
            cells = data.cells;
        } else {
            cells.set(data.cells);
        }
        emptyCells = data.emptyCells;
    }
}
