/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.io.*;
import java.util.function.*;
import java.util.zip.*;

import org.slf4j.*;

import com.google.common.cache.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.io.ColumnDataProtocol;
import com.simsilica.util.CacheTracker;


/**
 *  A file-based ColumnDb that initializes its columns by
 *  calling an external generator function.
 *
 *  @author    Paul Speed
 */
public class GeneratedColumnDb extends AbstractColumnDb {
    static Logger log = LoggerFactory.getLogger(GeneratedColumnDb.class);

    private Function<ColumnId, File> fileFunc;
    private ColumnDataProtocol protocol = new ColumnDataProtocol();

    private Function<ColumnId, ColumnData> generator;
    private LoadingCache<ColumnId, ColumnData> cache;

    private SpoolingObjectDb<ColumnId, ColumnData> storage;

    public GeneratedColumnDb( File root, Function<ColumnId, ColumnData> generator ) {
        // Shifting grid cell coordinates 5 bits means that all of the columns
        // for a particular tile will be in the same directory.
        //this(generator, new IdFileFunction<ColumnId>(root, 5, "col"));
        // 2023-01-15 as part of the y-layering, I'm switching to the
        // ParentIdFileFunction which already effectively does the shifting
        // but in a way that's guaranteed to line up with the other tiles.
        this(generator, new ParentIdFileFunction<ColumnId>(root, "col"));
    }

    public GeneratedColumnDb( Function<ColumnId, ColumnData> generator,
                              Function<ColumnId, File> fileFunc ) {
        this.generator = generator;
        this.fileFunc = fileFunc;

        this.cache = CacheBuilder.newBuilder()
                        .maximumSize(100)
                        .recordStats()
                        .build(new ColumnLoader());
        CacheTracker.track(cache, "GeneratedColumnDb@" + System.identityHashCode(this), true);

        this.storage = new SpoolingObjectDb<ColumnId, ColumnData>("columns") {
                protected ColumnData loadObject( ColumnId id ) {
                    return loadColumn(id);
                }

                protected void storeObject( ColumnId id, ColumnData data ) {
                    // FIXME: column locks instead of hard sync
                    synchronized(data) {
                        writeColumn(data);
                    }
                }
            };
    }

    protected File columnToFile( ColumnId columnId ) {
        return fileFunc.apply(columnId);
    }

    @Override
    public void initialize() {
        storage.initialize();
    }

    @Override
    public void terminate() {
        storage.terminate();
    }

    @Override
    public ColumnData getColumn( ColumnId columnId ) {
        return cache.getUnchecked(columnId);
    }

    @Override
    public void markChanged( ColumnData col ) {
        DataVersion version = col.getVersion();
        synchronized(version) {
            if( version.getLoadVersion() == -1 ) {
                // First time saving is a special case
                version.resetChanged(System.currentTimeMillis());
                // Make sure it still looks changed because we haven't
                // actually saved it yet.
                version.markChanged();
            }
        }
        storage.update(col.getColumnId(), col);
    }

    @Override
    public void resetColumn( ColumnId columnId ) {
        log.info("resetColumn(" + columnId + ")");

        ColumnData original = getColumn(columnId);
        log.info("original version:" + original.getVersion());
        ColumnData result = generator.apply(columnId);
        log.info("reset version:" + result.getVersion());

        // Copy the data over
        original.setData(result);

        markChanged(original);
    }

    @Override
    public synchronized void reloadColumn( ColumnId columnId ) {
        log.info("reloadColumn(" + columnId + ")");

        // Load the original so we can copy the data into it.  Other threads
        // may have a copy of this column data loaded and so we copy the data in directly.
        ColumnData original = getColumn(columnId);
        log.info("original column version:" + original.getVersion());

        synchronized(original) {
            File file = columnToFile(columnId);

            // Read the raw data again
            ColumnData reloaded = readColumn(file);

            // Copy the data over
            original.setData(reloaded);
        }
    }

    protected ColumnData loadColumn( ColumnId columnId ) {

        // See if we've generated this column before
        File f = columnToFile(columnId);
        if( f.exists() ) {
            return readColumn(f);
        }

        if( log.isDebugEnabled() ) {
            log.debug("generate column(" + columnId + ")");
        }

        ColumnData result = generator.apply(columnId);

        columnGenerated(result);

        return result;
    }

    protected ColumnData readColumn( File f ) {
        try( BufferedInputStream in = new BufferedInputStream(new GZIPInputStream(new FileInputStream(f))) ) {
            return protocol.read(in);
        } catch( IOException e ) {
            throw new RuntimeException("Error reading column:" + f, e);
        }
    }

    protected void writeColumn( ColumnData col ) {
        File f = fileFunc.apply(col.getColumnId());

        // Reset the version first so that we write the new version value
        // to the file.
        // OLD-FIXME: fix the thread sync issue here that is pretty common with all
        // DataVerison use-cases.
        // Note: I have made DataVersion synchronized so we can expand
        // a synchronized block.  It's ugly but it should alleviate my
        // fixme concerns above.  Though I admit I have not done a detailed
        // analysis. 2023-05-30
        DataVersion version = col.getVersion();
        synchronized(version) {
            writeColumn(f, col);

            // Moved this to after the write to follow the other patterns
            col.resetChanged(System.currentTimeMillis());
        }
    }

    protected void writeColumn( File f, ColumnData col ) {
        long start = System.nanoTime();
        try( BufferedOutputStream out = new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(f))) ) {
            protocol.write(col, out);
        } catch( IOException e ) {
            throw new RuntimeException("Error writing column:" + f, e);
        }
        long end = System.nanoTime();
        log.info("Wrote column [" + col + "] in " + ((end - start)/1000000.0) + " ms");
    }


    protected class ColumnLoader extends CacheLoader<ColumnId, ColumnData> {
        public ColumnData load( ColumnId id ) {
            return storage.get(id);
        }
    }
}

