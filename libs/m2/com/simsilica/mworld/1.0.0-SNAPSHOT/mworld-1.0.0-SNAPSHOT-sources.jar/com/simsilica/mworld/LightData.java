/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;
import com.google.common.base.MoreObjects;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class LightData implements CellData {
    static Logger log = LoggerFactory.getLogger(LightData.class);

    // For convenience
    private static final int SIZE = LeafId.SIZE;
    private static final int CELL_COUNT = LeafId.CELL_COUNT;

    // Set to true if there is some suspicion that setCell() is
    // letting counts get out of sync.
    private static final boolean SLOW_CHECKS = false;

    private LeafId leafId;
    private CellArray cells;
    private int sunCellCount;
    private int emptyCellCount;

    public LightData( LeafId leafId ) {
        this(leafId, null, 0, LeafId.CELL_COUNT);
    }

    public LightData( LeafId leafId, CellArray cells, int emptyCellCount, int sunCellCount ) {
        this.leafId = leafId;
        this.cells = cells;
        this.emptyCellCount = emptyCellCount;
        this.sunCellCount = sunCellCount;
        if( sunCellCount < 0 || emptyCellCount < 0 ) {
            // negative values trigger a recount
            fixCounts();
        }
        assert checkCounts();
    }

    public void clear( int value ) {
        if( value == LightUtils.SOLID ) {
            emptyCellCount = CELL_COUNT;
            sunCellCount = 0;
        } else if( value == LightUtils.DIRECT_SUN ) {
            emptyCellCount = 0;
            sunCellCount = CELL_COUNT;
        } else {
            cells = new CellArray(LeafId.SIZE);
            sunCellCount = 0;
            emptyCellCount = 0;
        }
        if( cells != null ) {
            cells.clear(value);
        }
    }

    public final boolean checkCounts() {
        // Note: checkCounts() is run after every setCell() call if
        // assertions are enabled.
        //if( true ) return true;
        if( cells == null ) {
            if( !isSolidDark() && !isFullSun() ) {
                log.error("No cells but inconsistent counts, sun:" + sunCellCount + ", empty:" + emptyCellCount);
                return false;
            }
            return true;
        }
        int e = 0;
        int s = 0;
        for( int val : cells.getArray() ) {
            if( val == LightUtils.SOLID ) {
                e++;
            }
            if( val == LightUtils.DIRECT_SUN ) {
                s++;
            }
        }
        if( e != emptyCellCount || s != sunCellCount ) {
            log.error("Cell count check failed, counted empty:" + e + " sun:" + s + "  But have fields empty:" + emptyCellCount + " sun:" + sunCellCount);
            return false;
        }
        return true;
    }

    /**
     *  Force fixes the empty cell and sun cell counts to match the
     *  actual data.  Returns true if the counts were fixed and false otherwise.
     */
    public final boolean fixCounts() {
        try {
            if( cells == null ) {
                if( isSolidDark() || isFullSun() ) {
                    return false;
                }
                // Need to fix the counts... but we'll just guess based on the
                // prevaling winds.
                if( sunCellCount < emptyCellCount ) {
                    emptyCellCount = CELL_COUNT;
                } else {
                    sunCellCount = CELL_COUNT;
                }
                return true;
            }
            int e = 0;
            int s = 0;
            for( int val : cells.getArray() ) {
                if( val == LightUtils.SOLID ) {
                    e++;
                }
                if( val == LightUtils.DIRECT_SUN ) {
                    s++;
                }
            }
            if( e != emptyCellCount || s != sunCellCount ) {
                emptyCellCount = e;
                sunCellCount = s;
                return true;
            }
            return false;
        } finally {
            assert checkCounts();
        }
    }

    public LeafId getLeafId() {
        return leafId;
    }

    /**
     *  Returns the number of cells that are pure sunlight.
     */
    public final int getSunCellCount() {
        return sunCellCount;
    }

    /**
     *  Returns the number of cells that have no lighting at all.
     */
    public final int getEmptyCellCount() {
        return emptyCellCount;
    }

    public final boolean isFullSun() {
        return sunCellCount == CELL_COUNT;
    }

    public final boolean isSolidDark() {
        return emptyCellCount == CELL_COUNT;
    }

    public final boolean containsCell( Vec3i world ) {
        return containsCell(world.x, world.y, world.z);
    }

    public final boolean containsCell( int x, int y, int z ) {
        long id = WorldGrids.LEAF_GRID.worldToId(x, y, z);
        return id == leafId.getId();
    }

    private boolean isValid( int x, int y, int z ) {
        if( x < 0 || y < 0 || z < 0 ) {
            return false;
        }
        if( x >= SIZE || y >= SIZE || z >= SIZE ) {
            return false;
        }
        return true;
    }

    @Override
    public int getCell( int x, int y, int z ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            return isFullSun() ? LightUtils.DIRECT_SUN : LightUtils.SOLID;
        }
        return cells.getCell(x, y, z);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            return isFullSun() ? LightUtils.DIRECT_SUN : LightUtils.SOLID;
        }
        return cells.getCell(x, y, z, defaultValue);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";
        if( cells == null ) {
            // This isn't right if the direction takes us outside of the
            // leaf area.  FIXME: detect boundary crossings and return defaultValue.
            return isFullSun() ? LightUtils.DIRECT_SUN : LightUtils.SOLID;
        }
        return cells.getCell(x, y, z, dir, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
        assert isValid(x, y, z) : "[" + x + ", " + y + ", " + z + "]";

        // Note: this method is not thread safe.  It assumes that the
        // caller either has exclusive control over the LightData or
        // that updates are single threaded.  In the cases where there
        // is cross-leaf boundary interaction, it's up to the caller to
        // properly gate that access. (for example, cross column light
        // propagation.)

        if( cells == null ) {
            // See if it would change the nature of the state
            if( value == LightUtils.DIRECT_SUN && isFullSun() ) {
                // Nothing to do... it wouldn't change anything
                return;
            }
            if( value == LightUtils.SOLID && isSolidDark() ) {
                // Nothing to do... it wouldn't change anything
                return;
            }

            // Initialize the cells array
            cells = new CellArray(LeafId.SIZE);
            if( isFullSun() ) {
                cells.clear(LightUtils.DIRECT_SUN);
            } else if( isSolidDark() ) {
                cells.clear(LightUtils.SOLID);
            } else {
                throw new RuntimeException("Invalid state during cell array initialization, sun:"
                                            + sunCellCount + ", empty:" + emptyCellCount);
            }

            cells.setCell(x, y, z, value);

            // Cancel out the 'old values' for some new value
            if( isFullSun() ) {
                sunCellCount--;
            }
            if( isSolidDark() ) {
                emptyCellCount--;
            }
            // Add back in the new value as appropriate
            if( value == LightUtils.SOLID ) {
                emptyCellCount++;
            }
            if( value == LightUtils.DIRECT_SUN ) {
                sunCellCount++;
            }

            if( SLOW_CHECKS ) {
                assert checkCounts() : "Invalid counts for:" + this + " when setting:" + value + " on new cells";
            }

            // Already set the value.
            return;
        }

        int oldVal = cells.getCell(x, y, z);
        if( oldVal == value ) {
            return;
        }
        cells.setCell(x, y, z, value);

        int oSun = sunCellCount;
        int oEmpty = emptyCellCount;

        // Adjust the counts from removal of the old value
        if( oldVal == LightUtils.DIRECT_SUN ) {
            sunCellCount--;
        }
        if( oldVal == LightUtils.SOLID ) {
            emptyCellCount--;
        }
        // Adjust the counts for adding the new value
        if( value == LightUtils.DIRECT_SUN ) {
            sunCellCount++;
        }
        if( value == LightUtils.SOLID ) {
            emptyCellCount++;
        }

        if( SLOW_CHECKS ) {
            assert checkCounts() : "Invalid counts for:" + this + " when setting:" + value + " over:" + oldVal
                                    + " original sun:" + oSun + " original empty:" + oEmpty;
        }
    }

    public CellArray getRawCells() {
        return cells;
    }

    public int[] getArray() {
        return cells == null ? null : cells.getArray();
    }

    /**
     *  If the LightData is fully sun or fully clear then its cell array
     *  reference will be cleared.
     */
    public void compact() {
        if( isSolidDark() || isFullSun() ) {
            cells = null;
        }
    }

    public void setData( LightData data ) {
        if( cells == null || data.cells == null ) {
            cells = data.cells;
        } else {
            cells.set(data.cells);
        }
        sunCellCount = data.sunCellCount;
        emptyCellCount = data.emptyCellCount;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
                .add("id", leafId)
                .add("sunCellCount", sunCellCount)
                .add("emptyCellCount", emptyCellCount)
                .add("cells", cells)
                .toString();
    }
}
