/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.concurrent.TimeUnit;

import com.google.common.cache.*;

import com.simsilica.mworld.*;
import com.simsilica.util.CacheTracker;

/**
 *  Wraps a LeafDb to provide caching support.
 *
 *  @author    Paul Speed
 */
public class LeafDbCache implements LeafDb {

    private LeafDb delegate;
    private LoadingCache<LeafId, LeafData> cache;

    public LeafDbCache( LeafDb delegate ) {
        this(delegate, 1000);
    }

    public LeafDbCache( LeafDb delegate, int cacheSize ) {
        this.delegate = delegate;
        this.cache = CacheBuilder.newBuilder()
                .maximumSize(cacheSize)
                .expireAfterAccess(10, TimeUnit.MINUTES)
                .recordStats()
                .build(new LeafCacheLoader());
        CacheTracker.track(cache, "LeafDbCache@" + System.identityHashCode(this), true);
    }

    @Override
    public LeafData loadLeaf( LeafId leafId ) {
        return cache.getUnchecked(leafId);
    }

    public void storeLeaf( LeafData leaf ) {
        cache.put(leaf.getInfo().leafId, leaf);
        delegate.storeLeaf(leaf);
    }

    /**
     *  Returns the specified leaf only if it's already in the cache.
     */
    public LeafData getCachedLeaf( LeafId leafId ) {
        return cache.getIfPresent(leafId);
    }

    private class LeafCacheLoader extends CacheLoader<LeafId, LeafData> {
        public LeafData load( LeafId key ) {
            return delegate.loadLeaf(key);
        }
    }
}
