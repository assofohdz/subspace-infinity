/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.tree.TreeLayer;

/**
 *
 *
 *  @author    Paul Speed
 */
public abstract class AbstractWorld implements World {
    static Logger log = LoggerFactory.getLogger(AbstractWorld.class);

    protected AbstractWorld() {
    }

    @Override
    public int getWorldCell( Vec3d world ) {
        LeafId id = LeafId.fromWorld(world);
        LeafData leaf = getLeaf(id);
        if( leaf == null ) {
            return -1;
        }
        int x = Coordinates.worldToCell(world.x) - leaf.getInfo().location.x;
        int y = Coordinates.worldToCell(world.y) - leaf.getInfo().location.y;
        int z = Coordinates.worldToCell(world.z) - leaf.getInfo().location.z;
        return leaf.getCell(x, y, z);
    }

    @Override
    public LeafData getWorldLeaf( Vec3d worldLocation ) {
        return getLeaf(LeafId.fromWorld(worldLocation));
    }

    @Override
    public void addTileListener( TileListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removeTileListener( TileListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void addLeafChangeListener( LeafChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removeLeafChangeListener( LeafChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void addCellChangeListener( CellChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removeCellChangeListener( CellChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void addColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void removeColumnChangeListener( ColumnChangeListener l ) {
        throw new UnsupportedOperationException();
    }
}
