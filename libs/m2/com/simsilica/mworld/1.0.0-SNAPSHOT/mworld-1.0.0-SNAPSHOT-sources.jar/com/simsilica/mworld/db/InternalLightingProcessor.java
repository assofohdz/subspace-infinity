/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;


import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;


/**
 *  Performs the light propagation based only on the column's own light
 *  sources.
 *
 *  @author    Paul Speed
 */
public class InternalLightingProcessor implements ColumnPostProcessor {

    static Logger log = LoggerFactory.getLogger(InternalLightingProcessor.class);

    private PostProcColumnDb parent;
    private ColumnDb delegate;

    public InternalLightingProcessor() {
    }

    @Override
    public void initialize( PostProcColumnDb parent ) {
        this.parent = parent;
        this.delegate = parent.getDelegate();
    }

    @Override
    public void terminate() {
    }

    @Override
    public boolean postProcess( ColumnData col ) {
        //log.info("postProcess(" + col + ")");

        // See if this column has already been internally lit
        if( col.hasGenerationFlag(ColumnData.GEN_LIGHT_INTERNAL) ) {
            //log.info("already post processed");
            return false;
        }

        if( log.isTraceEnabled() ) {
            log.trace("postProcess(" + col + ")  flags:" + Long.toBinaryString(col.getGenerationFlags()));
        }
        //log.info(col + " flags:" + Long.toHexString(col.getGenerationFlags()));

        // From the top, find the first LeafData we encounter that is not
        // completely empty.
        LeafData[] leafs = col.getLeafs();
        int top;
        for( top = leafs.length-1; top >= 0; top-- ) {
            if( !leafs[top].isEmpty() ) {
                break;
            }
        }
        int yTop = top * LeafId.SIZE + 32;
        if( log.isTraceEnabled() ) {
            log.trace("Highest y value:" + yTop);
        }

        ColumnNeighborhood cellData = new ColumnNeighborhood(delegate, col);
        ColumnLightData lightData = ColumnLightData.loadNeighborhood(delegate, col, true);

        synchronized( col ) {
            LightUtils.recalculateLighting(cellData, lightData, 0, 0, 0, LeafId.SIZE, yTop, LeafId.SIZE);

            col.setGenerationFlag(ColumnData.GEN_LIGHT_INTERNAL);
        }

        if( log.isTraceEnabled() ) {
            log.trace("end postProcess(" + col + ")  flags:" + Long.toBinaryString(col.getGenerationFlags()));
        }

        return true;
    }
}


