/*
 * $Id$
 * 
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;

import com.simsilica.mblock.LightUtils;
import com.simsilica.mathd.*;

/**
 *  A convenience class that provides optimal retrieval of block,
 *  light, and fluid information where the position is relatively 
 *  coherent.  (Internally, it uses a small cache to make sure not to
 *  re-lookup leaf data unnecesarily.)
 *
 *  @author    Paul Speed
 */
public class WorldView {
    static Logger log = LoggerFactory.getLogger(WorldView.class);
    
    // We can evolve how caching is done over time as the World implementations
    // evolve.
    
    private World world;
    private GridCell cell;
 
    // Right now we'll center on one leaf grid cell but to be optimal
    // it should probably be 8 in case we are asking lots of times about
    // a particular block and an adjacent block. (common in my particular
    // use case)
    private Vec3i origin; 
    private LeafId leafId;  
    private LeafData leaf;
    private LightData light;
    private FluidData fluid;    
    
    public WorldView( World world ) {
        this.world = world;
    }
 
    protected void validate( Vec3d worldPos ) {
        if( cell != null && !cell.contains(worldPos) ) {
            cell = null;
        }
        if( cell == null ) {
            cell = LeafId.GRID.getContainingCell(worldPos);
            leafId = new LeafId(cell.getId());
            origin = cell.getWorldOrigin();
            leaf = null;
            light = null;
            fluid = null;
        }
    }
 
    protected LeafData getLeafData( Vec3d worldPos ) {
        validate(worldPos);
        if( leaf == null ) {
            leaf = world.getLeaf(leafId);
        }
        return leaf;
    }

    protected LightData getLightData( Vec3d worldPos ) {
        validate(worldPos);
        if( light == null ) {
            light = world.getLight(leafId);
        }
        return light;
    }
    
    protected FluidData getFluidData( Vec3d worldPos ) {
        validate(worldPos);
        if( fluid == null ) {
            fluid = world.getFluid(leafId);
        }
        return fluid;
    }
 
    public int getBlock( Vec3d worldPos ) {
        LeafData data = getLeafData(worldPos);
        if( data == null ) {
            return 0;
        }
        int i = (int)Math.floor(worldPos.x) - origin.x;
        int j = (int)Math.floor(worldPos.y) - origin.y;
        int k = (int)Math.floor(worldPos.z) - origin.z;
        return data.getCell(i, j, k);
    }
    
    public int getLight( Vec3d worldPos ) {
        LightData data = getLightData(worldPos);
        if( data == null ) {
            return LightUtils.DIRECT_SUN;
        }
        int i = (int)Math.floor(worldPos.x) - origin.x;
        int j = (int)Math.floor(worldPos.y) - origin.y;
        int k = (int)Math.floor(worldPos.z) - origin.z;
        return data.getCell(i, j, k);
    } 
    
    public int getFluid( Vec3d worldPos ) {
        FluidData data = getFluidData(worldPos);
        if( data == null ) {
            return 0;
        }
        int i = (int)Math.floor(worldPos.x) - origin.x;
        int j = (int)Math.floor(worldPos.y) - origin.y;
        int k = (int)Math.floor(worldPos.z) - origin.z;
        return data.getCell(i, j, k);
    } 

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[]";
    }
}
