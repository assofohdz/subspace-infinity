/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

import org.slf4j.*;

import com.simsilica.mathd.Vec3i;
import com.simsilica.mworld.*;

/**
 *  Implements an all "in memory" column DB where every column is always
 *  resident in RAM.
 *
 *  @author    Paul Speed
 */
public class InMemoryColumnDb extends AbstractColumnDb {
    static Logger log = LoggerFactory.getLogger(InMemoryColumnDb.class);

    private Vec3i center;
    private int radius;
    private int height;
    private Consumer<ColumnData> initializer;
    private Map<ColumnId, ColumnData> data = new ConcurrentHashMap<>();

    public InMemoryColumnDb( Vec3i center, int radius, int height, Consumer<ColumnData> initializer ) {
        this.center = center;
        this.radius = radius;
        this.height = height;
        this.initializer = initializer;
    }

    @Override
    public void initialize() {
        int span = LeafId.SIZE;
        int size = (int)Math.ceil((double)height / span);

        for( int x = -radius; x <= radius; x++ ) {
            for( int z = -radius; z <= radius; z++ ) {
                Vec3i loc = center.add(x * span, 0, z * span);
                ColumnId id = ColumnId.fromWorld(loc);
                ColumnData columnData = new ColumnData(id, size);
                initializer.accept(columnData);
                data.put(id, columnData);
                columnGenerated(columnData);
            }
        }

        log.info("created " + data.size() + " columns.");
    }

    @Override
    public void terminate() {
    }

    @Override
    public ColumnData getColumn( ColumnId columnId ) {
        return data.get(columnId);
    }

    @Override
    public void markChanged( ColumnData col ) {
        // Make sure we act like storage from a versioning perspective...
        // which means we jump to reset changed right away.
        DataVersion version = col.getVersion();
        synchronized(version) {
            version.resetChanged(System.currentTimeMillis());
        }
    }
}


