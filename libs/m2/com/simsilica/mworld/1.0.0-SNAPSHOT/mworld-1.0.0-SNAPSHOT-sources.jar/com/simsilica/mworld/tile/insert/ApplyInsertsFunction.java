/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;

/**
 *  Applies any necessary Tile adjustments based on the insert layer,
 *  for example: carving voids out of terrain, setting base terrain
 *  types, adjusting water layers, etc..
 *
 *  @author    Paul Speed
 */
public class ApplyInsertsFunction implements TileFunction {
    static Logger log = LoggerFactory.getLogger(ApplyInsertsFunction.class);

    private Function<BlockDataId, BlockData> blocksFunction;
    private TerrainTypeFunction typeFunction;
    private IntCombiner typeCombiner;

    public ApplyInsertsFunction( Function<BlockDataId, BlockData> blocksFunction, TerrainTypeFunction typeFunction, IntCombiner typeCombiner ) {
        this.blocksFunction = blocksFunction;
        this.typeFunction = typeFunction;
        this.typeCombiner = typeCombiner;
    }

    public void accept( Tile tile ) {
        InsertLayer layer = tile.get(InsertLayer.class);
        if( log.isTraceEnabled() ) {
            log.trace("accept(" + tile + ")  layer:" + layer);
        }
        if( layer == null ) {
            // No inserts layer
            log.warn("No inserts layer for tile:" + tile.getTileId().getWorld(null) + ", res:" + tile.getResolution());
            return;
        }
        //if( layer.getVersion().getLoadVersion() >= 0 ) {
        //    // This is not a new layer
        //    return;
        //}
        // We don't want to check the inserts to see if they are new but the
        // terrain image.

        TerrainImage terrain = tile.get(TerrainImageType.Terrain, TerrainImage.class);
        TerrainImage fluid = tile.get(TerrainImageType.Fluid, TerrainImage.class);
        if( terrain.getVersion().getLoadVersion() >= 0 && fluid.getVersion().getLoadVersion() >= 0 ) {
            if( log.isTraceEnabled() ) {
                log.trace("terrain was already generated, tile:" + tile.getTileId().getWorld(null) + ", res:" + tile.getResolution());
            }
            return;
        }
        
        // For now we will only deal with high resolution here... but we could/should
        // do better.
        // FIXME: implement proper 'spread' logic below
        if( tile.getResolution() != Resolution.High ) {
            return;
        } 

        Vec3i origin = tile.getTileId().getWorld(null);

        boolean changed = false;
        for( BlockInsert insert : layer.getInserts() ) {

            //if( !insert.affectsGround ) {
            //    // For whatever reason, this insert does not affect the terrain
            //    // at all... either because it's fully above or fully below
            //    // or its intersection with the terrain is otherwise hidden.
            //    continue;
            //}
            if( insert.groundLevel == 0 ) {
                // It doesn't affect ground level
                // Objects that want to affect ground even a little will
                // have to set groundLevel to at least 1.  This includes
                // objects that contain no ground block types but would
                // like to clear out grass, etc..
                // If we ever need ground level ground types to be
                // projected as point sprites, we may have to rethink
                // this.
                continue;
            }

            BlockData blocks = blocksFunction.apply(insert.blockDataId);
            if( blocks == null ) {
                log.warn("No BlockData found for:" + insert);
                continue;
            }
            int carveFlags = insert.carveFlags;
            boolean carveBelow = (carveFlags & BlockInsert.CARVE_BELOW) != 0;
            boolean carveInner = (carveFlags & BlockInsert.CARVE_INNER) != 0;
            boolean carveAbove = (carveFlags & BlockInsert.CARVE_ABOVE) != 0;
            boolean extendDown = (carveFlags & BlockInsert.CARVE_EXTEND_DOWN) != 0;
            boolean extendUp = (carveFlags & BlockInsert.CARVE_EXTEND_UP) != 0;

            int x = insert.world.x - origin.x;
            int y = insert.world.y;
            int z = insert.world.z - origin.z;
            int xSize = insert.xSize;
            int ySize = insert.ySize;
            int zSize = insert.zSize;

            int xSource = 0;
            int zSource = 0;

            if( x < 0 ) {
                xSize += x;
                xSource -= x;
                x = 0;
            }
            if( z < 0 ) {
                zSize += z;
                zSource -= z;
                z = 0;
            }
            if( x + xSize > 1024 ) {
                xSize = 1024 - x;
            }
            if( z + zSize > 1024 ) {
                zSize = 1024 - z;
            }

            CellArray cells = blocks.getCells();
            CellArray fluidCells = blocks.getFluid();

            assert ySize > 0;

            for( int i = 0; i < xSize; i++ ) {
                for( int k = 0; k < zSize; k++ ) {

                    // We'll be super straight forward and just work down
                    // from ground level until we find the first 'terrain block'
                    // based on the terrain type function.
                    int groundLevel = insert.groundLevel - 1;
                    int elevation = y + groundLevel + 1;
                    int terrainType = -1;
                    boolean empty = true;
                    
                    // Calculate the tile-relative index for this location
                    int existingTerrainType = terrain.getType(x + i, z + k);
                    
                    for( int j = groundLevel; j >= 0; j-- ) {
                        int val = cells.getCell(xSource + i, j, zSource + k);
                        int type = MaskUtils.getType(val);
                        if( type != 0 ) {
                            empty = false;
                            int xform = typeFunction.apply(existingTerrainType, val, type);
                            if( xform >= 0 ) {
                                terrainType = xform;
                                break;
                            }
                        }
                        elevation--;
                    }
                    if( empty ) {
                        // We didn't encounter any block at all
                        continue;
                    }

                    int existingTerrainTypeMasked = existingTerrainType & 0xff;
                    int existingElevation = terrain.getElevation(x + i, z + k);
                    terrainType = typeCombiner.apply(existingTerrainTypeMasked, terrainType);
                    if( terrainType == -1 ) {
                        terrain.setElevation(x + i, z + k, (short)elevation);
                    } else if( terrainType == -2 ) {
                        if( existingElevation > elevation && elevation <= y + groundLevel ) {
                            terrain.setElevation(x + i, z + k, (short)elevation);
                        }
                    } else {
                        terrain.setType(x + i, z + k, (byte)terrainType);
                        terrain.setElevation(x + i, z + k, (short)elevation);
                    }


//
//                    int yBottom = -1;
//                    int yTop = ySize;
//
//                    // Find the bottom whether we carve below/inner or not because it
//                    // will tell us if there is anything in the column at all.
//                    for( int j = 0; j < ySize; j++ ) {
//                        int type = MaskUtils.getType(cells.getCell(xSource + i, j, zSource + k));
//                        if( type != 0 ) {
//                            yBottom = j;
//                            break;
//                        }
//                    }
//                    if( yBottom == -1 ) {
//                        // Skip this column because we don't carve out anything
//                        // for empty columns right now.
//                        continue;
//                    }
//
//                    if( carveInner || carveAbove ) {
//                        // Then we need to know what "inner" and "above" means
//
//                        // Find the top-most non-empty block
//                        for( int j = ySize - 1; j >= 0; j-- ) {
//                            int type = MaskUtils.getType(cells.getCell(xSource +  + i, j, zSource + k));
//                            if( type != 0 ) {
//                                yTop = j;
//                                break;
//                            }
//                        }
//                    }
//
//                    // Starting at ground level, we need to go up or down depending
//                    // on the type mapping or emptiness of the block in conjunction
//                    // with the carve modes.
//                    // Carve modes may require us to further limit the range of
//                    // search so we know whether empty space is a cavity or existing
//                    // ground.
//                    // Hmmm... based on groundLevel semantics, we never need to go
//                    // up because we will always chop it off there even if there
//                    // are ground types above.  We do need to know the yTop and yBottom
//                    // range to know whether or not to carve out a void, though.
//
//                    int groundLevel = Math.min(insert.groundLevel - 1, ySize - 1);
//                    int elevation = y + groundLevel;
//                    int type = -1;
//                    int terrainType = -1;
//
//log.info("[" + i + "][" + k + "]  range:" + yBottom + " " + yTop + "  groundLevel:" + groundLevel);
//
//                    int yStop = 0;
//
//                    for( int j = groundLevel; j >= 0; j-- ) {
//                        type = MaskUtils.getType(cells.getCell(xSource +  + i, j, zSource + k));
//log.info("   j:" + j + "  type:" + type + "  elevation:" + elevation + "  yStop:" + yStop);
//                        if( yStop > 0 && type == 0 ) {
//                            if( j < yBottom ) {
//log.info("     below, carveBelow:" + carveBelow);
//                                if( !carveBelow ) {
//                                    // Stop carving, we're done
//                                    //break;
//                                    // Except we might hit a block type that tells
//                                    // us to carve out anyway.
//                                    yStop = j;
//                                }
//                            } else if( j > yBottom && j < yTop ) {
//log.info("     inner, carveInner:" + carveInner);
//                                if( !carveInner ) {
//                                    // Stop carving, we're done
//                                    //break;
//                                    // Except we might hit a block type that tells
//                                    // us to carve out anyway.
//                                    yStop = j;
//                                }
//                            } else if( j > yTop ) {
//log.info("     above, carveAbove:" + carveAbove);
//                                if( !carveAbove ) {
//                                    // Stop carving, we're done
//                                    //break;
//                                    // Except we might hit a block type that tells
//                                    // us to carve out anyway.
//                                    yStop = j;
//                                }
//                            }
//                        } else if( type != 0 ) {
//                            // Translate the block type to a terrain type to
//                            // see if we stop or not
//                            int xform = typeFunction.apply(type);
//log.info("    type:" + type + "  xform:" + xform);
//                            if( xform >= 0 ) {
//                                // We hit terrain... so stop
//                                terrainType = xform;
//                                break;
//                            }
//                        }
//                        elevation--;
//                    }
//
//                    // If there were any blocks at all in the column then we want
//                    // to be able to adjust the terrain type... even if if's just
//                    // to turn grass into dirt or something.
//                    int existingTerrainType = terrain.getType(x + i, z + k) & 0xff;
//                    terrainType = typeCombiner.apply(existingTerrainType, terrainType);
//log.info("   terrainType:" + terrainType + "  yStop:" + yStop + "   elevation:" + elevation);
//                    if( terrainType >= 0 ) {
//                        terrain.setType(x + i, z + k, (byte)terrainType);
//                    }
//                    if( yStop > 0 && terrainType >= -1 ) {
//                        // We shouldn't have been carving, so restore where we
//                        // found the first empty.
//                        elevation = y + yStop;
//                    }
//                    int existingElevation = terrain.getElevation(x + i, z + k);
//                    if( terrainType >= -1 || existingElevation > elevation ) {
//                        terrain.setElevation(x + i, z + k, (short)elevation);
//                    }
//                    changed = true;
//
//                    //int existingElevation = terrain.getElevation(x + i, z + k);
//                    //if( terrainType == -1 ) {
//                    //    if( elevation < existingElevation ) {
//                    //        terrain.setElevation(x + i, z + k, (short)elevation);
//                    //        changed = true;
//                    //    }
//                    //    // Empty space or non-terrain blocks... leave the terrain where it is
//                    //    continue;
//                    //}
//                    //
//                    //if( terrainType == -1 ) {
//                    //    // Now... it's empty space or non-terrain blocks... leave the terrain where it is
//                    //    // For example, some types we treat as "leave things the way they are"
//                    //    continue;
//                    //}
//                    //
//                    //terrain.setElevation(x + i, z + k, (short)elevation);
//                    //terrain.setType(x + i, z + k, (byte)terrainType);
//                    //
//                    //changed = true;
                }
            }
        }

//            if( true ) {
//                continue;
//            }
//
//
//
//
//
//            boolean inset = false; //(carveFlags & BlockInsert.CARVE_INSET) != 0;
//            boolean inscribe = true; //(carveFlags & BlockInsert.CARVE_INSCRIBE) != 0;
//            boolean carve = inset | inscribe;
//            if( !carve ) {
//                continue;
//            }
//
//            // For now, just carve out everything
//
//
//
//            CellArray cells = blocks.getCells();
//log.info("leveling:" + x + ", " + z + "  size:" + xSize + ", " + zSize + "  cells size:" + cells.getSize());
//
//            int ySize = cells.getSizeY();
//            for( int i = 0; i < xSize; i++ ) {
//                for( int k = 0; k < zSize; k++ ) {
//                    int type;
//                    try {
//                        type = cells.getCell(xSource + i, 0, zSource + k);
//                    } catch( ArrayIndexOutOfBoundsException e ) {
//                        log.error("Error retrievinv type (" + (xSource + i) + ", " + 0 + ", " + (zSource + k) + ")", e);
//                        throw e;
//                    }
//                    if( type == 0 && inscribe ) {
//                        continue;
//                    }
//                    int elevation = y;
//                    int terrainType = -1;
//                    // Search from the ground up... we might want a top-down option someday.
//                    for( int j = 0; j < ySize; j++ ) {
//                        type = MaskUtils.getType(cells.getCell(xSource + i, j, zSource + k));
//                        int xform = typeFunction.apply(type);
//                        if( xform != -1 ) {
//                            // +1 because if the block is filled then we are one higher
//                            // than just base y.
//                            elevation = y + j + 1;
//                            terrainType = xform;
//                        } else {
//                            break;
//                        }
//                    }
//                    int existingTerrainType = terrain.getType(x + i, z + k) & 0xff;
//                    terrainType = typeCombiner.apply(existingTerrainType, terrainType);
//                    if( terrainType != -1 ) {
//                        terrain.setElevation(x + i, z + k, (short)elevation);
//                        terrain.setType(x + i, z + k, (byte)terrainType);
//                    }
//                }
//            }
//
//            changed = true;
//        }

        if( changed ) {
            if( !terrain.getVersion().isChanged() ) {
                terrain.getVersion().markChanged();
            }
            if( !fluid.getVersion().isChanged() ) {
                fluid.getVersion().markChanged();
            }
        }
    }
}



