/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;

/**
 *  Just fills the intersecting terrain image or column with
 *  a prespecified fill value.  0 is considered "empty".
 *
 *  @author    Paul Speed
 */
public class BoxFill extends AbstractBoxMorphology {
    static Logger log = LoggerFactory.getLogger(BoxFill.class);

    private int blockFill;
    private byte terrainFill;
    private boolean affectTerrain;
    private boolean carve;

    public BoxFill( Vec3i min, Vec3i max, int blockFill, byte terrainFill ) {
        this(min, max, blockFill, terrainFill, true, false);
    }

    public BoxFill( Vec3i min, Vec3i max, int blockFill, byte terrainFill, boolean affectTerrain, boolean carve ) {
        super(min, max);
        this.blockFill = blockFill;
        this.terrainFill = terrainFill;
        this.affectTerrain = affectTerrain;
        this.carve = carve;
    }

    public int getBlockFill() {
        return blockFill;
    }

    public byte getTerrainFill() {
        return terrainFill;
    }

    public boolean morph( Tile tile, Random rand ) {

        if( !affectTerrain ) {
            return false;
        }

        TerrainImage terrain = tile.get(TerrainImageType.Terrain, TerrainImage.class);
        int size = terrain.getSize();
        int skip = 1024 / size;

        Vec3i tileMin = tile.getTileId().getWorld(null);
        Vec3i tileMax = tileMin.add(1024, 0, 1024);
        int xMin = (Math.max(tileMin.x, getMin().x) - tileMin.x) / skip;
        int xMax = (Math.min(tileMax.x, getMax().x) - tileMin.x) / skip;
        int zMin = (Math.max(tileMin.z, getMin().z) - tileMin.z) / skip;
        int zMax = (Math.min(tileMax.z, getMax().z) - tileMin.z) / skip;
        int y = carve ? getMin().y : getMax().y;

        boolean changed = false;
        for( int x = xMin; x < xMax; x++ ) {
            for( int z = zMin; z < zMax; z++ ) {
                terrain.setElevation(x, z, (short)y);
                terrain.setType(x, z, terrainFill);
                changed = true;
            }
        }

        return changed;
    }

    public boolean morph( ColumnData colData, Tile tile, Random rand ) {

        Vec3i colMin = colData.getColumnId().getWorld(null);
        Vec3i colMax = colMin.add(COLUMN_SIZE, colData.getCeiling(), COLUMN_SIZE);

        int xMin = Math.max(colMin.x, getMin().x) - colMin.x;
        int xMax = Math.min(colMax.x, getMax().x) - colMin.x;
        int yMin = Math.max(colMin.y, getMin().y) - colMin.y;
        int yMax = Math.min(colMax.y, getMax().y) - colMin.y;
        int zMin = Math.max(colMin.z, getMin().z) - colMin.z;
        int zMax = Math.min(colMax.z, getMax().z) - colMin.z;

        boolean changed = false;
        for( int y = yMin; y < yMax; y++ ) {
            int layer = y / LeafId.SIZE;
            int yBase = layer * LeafId.SIZE;
            LeafData leaf = colData.getLeafs()[layer];
            int j = y - yBase;

            for( int i = xMin; i < xMax; i++ ) {
                for( int k = zMin; k < zMax; k++ ) {
                    leaf.setCell(i, j, k, blockFill);
                    changed = true;
                }
            }
        }

        return changed;
    }
}
