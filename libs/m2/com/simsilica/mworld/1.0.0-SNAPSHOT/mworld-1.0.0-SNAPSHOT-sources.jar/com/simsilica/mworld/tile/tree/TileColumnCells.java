/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;

/**
 *  Utility class that presents a column as a CellArray where the origin
 *  is the tile origin.  Coordinates outside column are automatically
 *  ignored and there is automatic 'existing value' filtering.
 *
 *  @author    Paul Speed
 */
public class TileColumnCells implements CellData {
    static Logger log = LoggerFactory.getLogger(TileColumnCells.class);

    private Vec3i tileOrigin;
    private Vec3i colOrigin;
    private ColumnData colData;
    private LeafData[] leafArray;

    public TileColumnCells( ColumnData colData ) {
        this.colData = colData;
        ColumnId colId = colData.getColumnId();
        TileId tileId = colId.getTileId();
        this.tileOrigin = tileId.getWorld(null);
        this.colOrigin = colId.getWorld(null).subtractLocal(tileOrigin);
        this.leafArray = colData.getLeafs();
    }

    public ColumnData getColumnData() {
        return colData;
    }

    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    public int getCell( int x, int y, int z, int defaultValue ) {
        x = x - colOrigin.x;
        z = z - colOrigin.z;
        if( x < 0 || z < 0 ) {
            return defaultValue;
        }
        if( x >= 32 || z >= 32 ) {
            return defaultValue;
        }
        int layer = y / 32;
        y = y - (layer * 32);
        return leafArray[layer].getCell(x, y, z);
    }

    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    public void setCell( int x, int y, int z, int type ) {
        x = x - colOrigin.x;
        z = z - colOrigin.z;
        if( x < 0 || z < 0 ) {
            return;
        }
        if( x >= 32 || z >= 32 ) {
            return;
        }
        int layer = y / 32;
        y = y - (layer * 32);
        LeafData leaf = leafArray[layer];
        int existing = MaskUtils.getType(leaf.getCell(x, y, z));
        // Just a basic check for now
        if( existing > 0 ) {
            return;
        }
        leaf.setCell(x, y, z, type);
    }
}
