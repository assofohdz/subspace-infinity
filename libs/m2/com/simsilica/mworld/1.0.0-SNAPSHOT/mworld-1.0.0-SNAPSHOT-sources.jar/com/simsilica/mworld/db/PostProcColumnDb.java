/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.util.*;

import com.google.common.cache.*;

import org.slf4j.*;

import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.ColumnData;

/**
 *  Wraps a column DB to allow a set of post-processors to run that
 *  can do additional generation that may require access to neighboring
 *  columns.
 *
 *  @author    Paul Speed
 */
public class PostProcColumnDb extends AbstractColumnDb {
    static Logger log = LoggerFactory.getLogger(PostProcColumnDb.class);

    private static final ColumnData NULL_COLUMN = new ColumnData(ColumnId.fromWorld(0, Integer.MIN_VALUE, 0), 0);

    private ColumnDb delegate;
    private List<ColumnPostProcessor> processorList = new ArrayList<>();
    private ColumnPostProcessor[] processors;

    // wrap access in a loading cache just to make sure we only process
    // a particular column one thread at a time... avoid duplication basically.
    private LoadingCache<ColumnId, ColumnData> cache;

    public PostProcColumnDb( ColumnDb delegate, ColumnPostProcessor... procs ) {
        this.delegate = delegate;
        this.cache = CacheBuilder.newBuilder()
                .weakValues()
                .build(new CacheLoader<ColumnId, ColumnData>(){
                        public ColumnData load( ColumnId id ) {
                            ColumnData result = loadColumn(id);
                            if( result == null ) {
                                return NULL_COLUMN;
                            }
                            return loadColumn(id);
                        }
                    });
        if( procs != null && procs.length > 0 ) {
            processorList.addAll(Arrays.asList(procs));
        }
    }

    public void addColumnPostProcessor( ColumnPostProcessor proc ) {
        if( processors != null ) {
            throw new IllegalArgumentException("Cannot add a processor to initialized PostProcColumnDb");
        }
        processorList.add(proc);
    }

    public void removeColumnPostProcessor( ColumnPostProcessor proc ) {
        if( processors != null ) {
            throw new IllegalArgumentException("Cannot add a processor to initialized PostProcColumnDb");
        }
        processorList.remove(proc);
    }

    public ColumnDb getDelegate() {
        return delegate;
    }

    @Override
    public void initialize() {
        delegate.initialize();
        processors = processorList.toArray(new ColumnPostProcessor[0]);
        for( ColumnPostProcessor proc : processors ) {
            proc.initialize(this);
        }
    }

    @Override
    public void terminate() {
        for( ColumnPostProcessor proc : processors ) {
            proc.terminate();
        }
        delegate.terminate();
    }

    @Override
    public ColumnData getColumn( ColumnId columnId ) {
        ColumnData result = cache.getUnchecked(columnId);
        if( result == NULL_COLUMN ) {
            return null;
        }
        return result;
    }

    @Override
    public void markChanged( ColumnData col ) {
        delegate.markChanged(col);
    }

    @Override
    public synchronized void resetColumn( ColumnId columnId ) {
        log.info("resetColumn(" + columnId + ")");
        delegate.resetColumn(columnId);
        loadColumn(columnId);
    }

    @Override
    public synchronized void reloadColumn( ColumnId columnId ) {
        log.info("reloadColumn(" + columnId + ")");
        delegate.reloadColumn(columnId);
        loadColumn(columnId);
    }

    protected ColumnData loadColumn( ColumnId columnId ) {
        ColumnData result = delegate.getColumn(columnId);
        if( result == null ) {
            return result;
        }
        boolean changed = false;
        for( ColumnPostProcessor proc: processors ) {
            if( proc.postProcess(result) ) {
                changed = true;
            }
        }
        if( changed ) {
            // store it back
            delegate.markChanged(result);

            // And from our perspective, that means we "generated" it.
            // This speculation might get us in trouble since we run the
            // post-processors whenever we load the column from the delegate.
            // It imposes rules on the 'changed' means with respect to post
            // processors but there also isn't much we can do about it.
            // The delegate may have already generated, stored, and upped
            // the version number.  So we don't even know if it's really new...
            // and even if we did we'd want to reserver 'generated' state
            // until the post processors had run.  So we'll assume that if
            // any post-processors ran then all that were supposed to run have
            // run.  In our current use-cases, this holds out and we can
            // forward the 'generated' event to interested listeners.
            columnGenerated(result);
        }
        return result;
    }
}
