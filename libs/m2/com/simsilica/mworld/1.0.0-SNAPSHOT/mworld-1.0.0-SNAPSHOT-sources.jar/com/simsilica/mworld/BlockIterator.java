/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.CellData;
import com.simsilica.mblock.MaskUtils;

/**
 *  Iterates over the non-zero world blocks that intersect a given ray.
 *  All blocks where a facing side intersects the ray will be returned and
 *  it's up to the caller to do any more detailed hit testing if necessary
 *  or skip certain types if desired.
 *
 *  @author    Paul Speed
 */
public class BlockIterator implements Iterator<BlockIterator.Intersection> {
    static Logger log = LoggerFactory.getLogger(BlockIterator.class);

    // Values we use to find the blocks
    private CellData cells;
    private Rayd ray;
    private double limit;

    // Working data
    private PlaneIntersector[] planeIntersects;
    private double[] dists = new double[3];
    private double distance;
    private Intersection next;

    public BlockIterator( World world, Rayd ray, double limit ) {
        this(new WorldCellDataAdapter(world), ray, limit);
    }

    public BlockIterator( CellData cells, Rayd ray, double limit ) {
        this.cells = cells;
        this.ray = ray;
        this.limit = limit;

        planeIntersects = new PlaneIntersector[] {
                    new PlaneIntersector(ray, 0),
                    new PlaneIntersector(ray, 1),
                    new PlaneIntersector(ray, 2)
                };
    }

    // Returns the index of the smallest float
    private int minIndex( double... vals ) {
        int minIndex = 0;  // always return something
        double min = Double.POSITIVE_INFINITY; // because index 0 might be Nan
        for( int i = 0; i < vals.length; i++ ) {
            if( vals[i] == Double.NaN ) {
                continue;
            }
            if( vals[i] < min ) {
                min = vals[i];
                minIndex = i;
            }
        }
        return minIndex;
    }

    /**
     *  Returns BlockIterator's distance limit.  Only collisions found within
     *  this limit will be returned.
     */
    public double getLimit() {
        return limit;
    }

    /**
     *  Returns the Ray that is being used for world intersection traversal.
     */
    public Rayd getRay() {
        return ray;
    }

    /**
     *  Fetch the next intersection of one is not already pending and we haven't
     *  already exceeded limit.
     */
    protected void fetch() {
        if( next != null || distance >= limit ) {
            return;
        }

        while( distance < limit ) {
            // Find the closest plane intersection
            dists[0] = planeIntersects[0].getNextLength();
            dists[1] = planeIntersects[1].getNextLength();
            dists[2] = planeIntersects[2].getNextLength();
            int minIndex = minIndex(dists);
            PlaneIntersector plane = planeIntersects[minIndex];

            distance = plane.getNextLength();
            Vec3i blockIntersect = plane.getNextBlockIntersect();

            // Advance that plane intersect.
            Vec3d intersect = plane.next();

            // 'intersect' should be the actual point of intersection
            //int value = world.getWorldCell(blockIntersect.toVec3d());
            int value = cells.getCell(blockIntersect.x, blockIntersect.y, blockIntersect.z, -1);
            if( value == -1 ) {
                continue;
            }
            int type = MaskUtils.getType(value);
            if( type == 0 ) {
                continue;
            }

            next = new Intersection(intersect, blockIntersect, type, value, plane.normal);
            break;
        }
    }

    @Override
    public boolean hasNext() {
        fetch();
        return next != null;
    }

    @Override
    public Intersection next() {
        fetch();
        Intersection result = next;
        next = null;
        return result;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException( "Remove not supported on intersectors." );
    }

    public static class Intersection {

        private Vec3d point;
        private Vec3i block;
        private Vec3d normal;
        private int type;
        private int value;

        public Intersection( Vec3d point, Vec3i block, int type, int value, Vec3d normal ) {
            this.point = point;
            this.block = block;
            this.type = type;
            this.value = value;
            this.normal = normal;
        }

        public int getType() {
            return type;
        }

        public int getCellValue() {
            return value;
        }

        public Vec3d getPoint() {
            return point;
        }

        public Vec3d getNormal() {
            return normal;
        }

        public Vec3i getBlock() {
            return block;
        }

        @Override
        public String toString() {
            return "Intersection[block:" + block + ", point:" + point + ", type:" + type + ", normal:" + normal + "]";
        }
    }

    /**
     *  Tracks the intersection of a certain gridded plane orientation
     *  down a particular vector.  If you imagine the world sliced up
     *  into axis-perpendicular planes, this will intersect them one at a time for
     *  a particular axis.
     *  So if you have three of them, you can step through all block intersections
     *  by checking to see which next PlaneIntersector has the closest hit.
     */
    private static class PlaneIntersector {

        private Vec3d start;
        private int axis = 0;
        private int step = 0;
        private Vec3d normal;
        private double sign;
        private Vec3d dir;
        private double dirLength;
        private double nextLength;

        public PlaneIntersector( Rayd ray, int axis ) {
            // Calculate the plane steps
            this.axis = axis;

            Vec3d pos = ray.getOrigin();
            Vec3d heading = ray.getDirection();

            // First, we create a vector scaled up so that the
            // 'axis' element is 1.0
            sign = Math.signum(heading.get(axis));
            dir = heading.mult(sign / heading.get(axis));

            if( sign == 0 ) {
                dirLength = Double.POSITIVE_INFINITY;
            } else {
                // 2023-11-05: whatever the case, the axis direction should
                // always be an integer else we might end up with 0.99999999999
                // which leads to inaccuracies later and double hits on the same
                // block and so on.
                dir.set(axis, sign);

                dirLength = dir.length();
            }

            // Calculate the appropriate normal for the axis.
            // Saves us time later..
            // Note that the normal points back towards the ray origin.
            this.normal = new Vec3d();
            normal.set(axis, -sign);

            // Now we need to figure out where our first intersection
            // would be from the current position.  This is our
            // first intersection and our "start" position.

            // Our grid position along the axis
            double grid = Math.floor(pos.get(axis));
            if( sign > 0 ) {
                grid++; // intersect ahead not behind
            }

            // We want to scale the other components of the
            // start delta vector without changing their signs.
            double scale = (grid - pos.get(axis)) / sign;

            // Create just the delta vector first so we can
            // get an initial intersection length
            start = dir.mult(scale);
            nextLength = start.length();

            // And now add the position for the real starting location
            // in world space.
            start.addLocal( pos );
        }

        public double getSign() {
            return sign;
        }

        public double getNextLength() {
            return nextLength;
        }

        public Vec3i getNextBlockIntersect() {

            Vec3d pos = getNextIntersect();
            Vec3i result = pos.floor();

            // Now, if we approached negatively down our
            // axis then the floor will be one cell off
            if( sign < 0 ) {
                result.set(axis, result.get(axis)-1);
            }

            return result;
        }

        public Vec3d getNextIntersect() {
            return start.add(dir.mult(step));
        }

        public Vec3d next() {
            Vec3d last = getNextIntersect();
            nextLength += dirLength;
            step++;
            return last;
        }
    }
}
