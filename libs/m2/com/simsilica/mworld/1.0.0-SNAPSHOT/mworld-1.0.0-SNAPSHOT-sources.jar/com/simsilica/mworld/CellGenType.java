/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import org.slf4j.*;

/**
 *  Can be used to determine the origin of a particular block value.
 *  It's up to the various generation functions to take advantage of
 *  these bits as the mworld library cannot easily enforce it.
 *
 *  @author    Paul Speed
 */
public enum CellGenType {

    None(0b00), Terrain(0b01), Insert(0b10), Flora(0b11);

    static Logger log = LoggerFactory.getLogger(CellGenType.class);

    private static final int TYPE_BITS = 0b11;
    private static final int TYPE_SHIFT = 24;
    private static final int TYPE_MASK  = TYPE_BITS << TYPE_SHIFT;

    private int bits;
    private int mask;
    private CellGenType( int bits ) {
        this.bits = bits;
        this.mask = bits << TYPE_SHIFT;
    }

    public int apply( int value ) {
        return value | mask;
    }

    public int getBits() {
        return bits;
    }

    public static int getTypeBits( int value ) {
        return (value >> TYPE_SHIFT) & TYPE_BITS;
    }

    public static CellGenType getType( int value ) {
        // Hard coded because it's faster
        int b = getTypeBits(value);
        switch( b ) {
            case 0b00:
                return CellGenType.None;
            case 0b01:
                return CellGenType.Terrain;
            case 0b10:
                return CellGenType.Insert;
            case 0b11:
                return CellGenType.Flora;
            default:
                throw new IllegalArgumentException("Unknown type bits:" + b);
        }
    }
}


