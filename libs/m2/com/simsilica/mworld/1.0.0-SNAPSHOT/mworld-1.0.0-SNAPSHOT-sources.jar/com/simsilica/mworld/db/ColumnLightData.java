/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *  A special light data access that creates temporary neighbor copies that can
 *  be written to without affecting the real data.  So this is not just a read-only
 *  neighborhood but allows side-effect free lighting propagation pass-through.
 *
 *  @author    Paul Speed
 */
public class ColumnLightData implements CellData {
    static Logger log = LoggerFactory.getLogger(ColumnLightData.class);

    private ColumnDb columnDb;
    private ColumnData center;
    private ColumnData[][] columns = new ColumnData[3][3];
    private int yTop;

    public ColumnLightData( ColumnDb columnDb, ColumnData[][] columns ) {
        this.columnDb = columnDb;
        this.columns = columns;
        this.center = columns[1][1];

        // calculate the ceiling of the world for this dataset
        yTop = center.getLighting().length * LeafInfo.SIZE;
    }

    public int getCeiling() {
        return yTop;
    }

    public static ColumnLightData loadNeighborhood( ColumnDb columnDb, ColumnData center, boolean readOnlyNeighbors ) {
        Vec3i world = center.getColumnId().getWorld(null);

        int radius = 1;
        int size = radius * 2 + 1;
        ColumnData[][] columns = new ColumnData[size][size];
        for( int x = -radius; x <= radius; x++ ) {
            for( int z = -radius; z <= radius; z++ ) {
                if( x == 0 && z == 0 ) {
                    columns[x + radius][z + radius] = center;
                } else {
                    ColumnId id = ColumnId.fromWorld(world.x + x * LeafInfo.SIZE, world.y, world.z + z * LeafInfo.SIZE);
                    ColumnData col = columnDb.getColumn(id);
                    if( col == null ) {
                        // A null column will still need lighting data for propagation to work... so
                        // we'll create an empty one on the fly
                        col = new ColumnData(id, center.getLighting().length);
                    } else if( readOnlyNeighbors ) {
                        // Create our own version of the column with just our own
                        // empty lighting data that we can write into temporarily
                        LightData[] lighting = col.getLighting();
                        LightData[] empties = new LightData[lighting.length];
                        for( int i = 0; i < empties.length; i++ ) {
                            empties[i] = new LightData(lighting[i].getLeafId(), null, LeafId.CELL_COUNT, 0);
                        }
                        col = new ColumnData(col.getColumnId(), col.getLeafs(), null, empties, col.getVersion(), col.getGenerationFlags());
                    }
                    columns[x + radius][z + radius] = col;
                }
            }
        }

        return new ColumnLightData(columnDb, columns);
    }

    private ColumnData getColumn( int x, int z ) {
        // Calculate the indexes into the columns array
        // If x is < 0 we want i to be 0.
        // If x is between 0 and 31, we want i to be 1.
        // if x is > 31 then we want i to be 2
        int i = (x + LeafInfo.SIZE) / LeafInfo.SIZE;
        int j = (z + LeafInfo.SIZE) / LeafInfo.SIZE;
        return columns[i][j];
    }

    @Override
    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    @Override
    public int getCell( int x, int y, int z, int defaultValue ) {
        if( y < 0 ) {
            return defaultValue;
        }
        if( y >= yTop ) {
            // Always sunlight at the top of the world
            return LightUtils.DIRECT_SUN;
        }
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            return defaultValue;
        }
        int k = y / LeafInfo.SIZE;
        if( k >= col.getLighting().length ) {
            log.info("BAD: k:" + k + " y:" + y + "  yTop:" + yTop + "  length:" + col.getLighting().length);
            return LightUtils.DIRECT_SUN;
        }

        LightData lighting = col.getLighting()[k];
        if( lighting.isSolidDark() ) {
            return LightUtils.SOLID;
        }
        if( lighting.isFullSun() ) {
            return LightUtils.DIRECT_SUN;
        }

        // The column will have already been correctly selected for us
        // above so now we need to move our x,z into range.
        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }

        return lighting.getCell(x, y - (k * LeafInfo.SIZE), z);
    }

    // A debug-heavy version of getCell() for cases where bad things are
    // happening and we want to double-check why.
    private int getCell2( int x, int y, int z, int defaultValue ) {
log.info("getCell2(" + x + ", " + y + ", " + z + ") yTop:" + yTop);
        if( y < 0 ) {
            return defaultValue;
        }
        if( y >= yTop ) {
            // Always sunlight at the top of the world
            return LightUtils.DIRECT_SUN;
        }
        ColumnData col = getColumn(x, z);
log.info("getCell2() col:" + col);
        if( col == null ) {
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            return defaultValue;
        }
        int k = y / LeafInfo.SIZE;
if( k >= col.getLighting().length ) {
    log.info("BAD: k:" + k + " y:" + y + "  yTop:" + yTop + "  length:" + col.getLighting().length);
}
        LightData lighting = col.getLighting()[k];
log.info("getCell2() lighting:" + lighting);
        if( lighting.isSolidDark() ) {
            return LightUtils.SOLID;
        }
        if( lighting.isFullSun() ) {
            return LightUtils.DIRECT_SUN;
        }

        // The column will have already been correctly selected for us
        // above so now we need to move our x,z into range.
        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }

log.info("getCell2() on:" + lighting + " at:" + x + ", " + (y - (k * LeafInfo.SIZE)) + ", " + z);
        return lighting.getCell(x, y - (k * LeafInfo.SIZE), z);
    }

    @Override
    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    @Override
    public void setCell( int x, int y, int z, int value ) {
int ox = x;
int oy = y;
int oz = z;
        ColumnData col = getColumn(x, z);
        if( col == null ) {
            throw new RuntimeException("ColumnData not found for:" + x + ", " + z);
            // This should never happen but we'll leave it in just in case
            // we want to reuse this code for sparse neighborhoods or 'cross'
            // neighborhoods.
            // return;
        }
        // We already know we're in the neighborhood if we got a column
        // so we just need to adjust x and z to be in the local block range.

        if( x < 0 ) {
            x += LeafInfo.SIZE;
        } else if( x >= LeafInfo.SIZE ) {
            x -= LeafInfo.SIZE;
        }
        if( z < 0 ) {
            z += LeafInfo.SIZE;
        } else if( z >= LeafInfo.SIZE ) {
            z -= LeafInfo.SIZE;
        }
        int k = y / LeafInfo.SIZE;
        LightData lighting = col.getLighting()[k];
        lighting.setCell(x, y - (k * LeafInfo.SIZE), z, value);

int retest = lighting.getCell(x, y - (k * LeafInfo.SIZE), z, -1);
if( retest != value ) {
    throw new RuntimeException("Value not set for:" + lighting
                                + " at:" + x + ", " + (y - (k * LeafInfo.SIZE)) + ", " + z
                                + " from:" + ox + ", " + oy + ", " + oz
                                + " value:" + value + "  found:" + retest);
}
retest = getCell(ox, oy, oz, -1);
if( retest != value ) {
    int retest2 = getCell2(ox, oy, oz, -1);
    if( retest != retest2 ) {
        throw new RuntimeException("What the hell is going on?");
    }

    throw new RuntimeException("Value not set for:" + lighting
                                + " at:" + x + ", " + (y - (k * LeafInfo.SIZE)) + ", " + z
                                + " from:" + ox + ", " + oy + ", " + oz
                                + " value:" + value + "  found:" + retest);
}
    }

}

