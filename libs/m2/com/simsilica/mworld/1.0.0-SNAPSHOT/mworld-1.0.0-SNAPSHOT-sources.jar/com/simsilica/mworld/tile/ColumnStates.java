/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.util.*;
import java.util.concurrent.*;

import org.slf4j.*;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;

import com.simsilica.mworld.*;


/**
 *  Represents the dirty/clean state of columns in a particular tile
 *  for a certain context.
 *
 *  @author    Paul Speed
 */
public class ColumnStates {
    static Logger log = LoggerFactory.getLogger(ColumnStates.class);

    private TileId tileId;
    private Set<Short> dirty = new ConcurrentSkipListSet<>();

    public ColumnStates( TileId tileId ) {
        this.tileId = tileId;
    }

    public TileId getTileId() {
        return tileId;
    }

    /**
     *  Returns true if there are no dirty states for this tile.
     */
    public boolean isValid() {
        return dirty.isEmpty();
    }

    public boolean markDirty( ColumnId col ) {
        return markDirty(col.getTileLocalIndexId());
    }

    public boolean markDirty( short tileLocalColumnId ) {
        if( log.isTraceEnabled() ) {
            log.trace(tileId + ".markDirty(" + tileLocalColumnId + ")");
        }
        return dirty.add(tileLocalColumnId);
    }

    public Set<Short> getTileLocalColumnIds() {
        return dirty;
    }

    public int size() {
        return dirty.size();
    }

    public Iterable<ColumnId> getDirtyColumns() {
        return Iterables.transform(dirty, new ToColumnId(tileId));
    }

    public boolean markAll( ColumnStates other ) {
        return dirty.addAll(other.dirty);
    }

    public String toString() {
        return getClass().getSimpleName() + "[id:" + tileId + ", dirty:" + dirty + "]";
    }

    private static class ToColumnId implements Function<Short, ColumnId> {
        private TileId tileId;

        public ToColumnId( TileId tileId ) {
            this.tileId = tileId;
        }

        public ColumnId apply( Short s ) {
            return ColumnId.fromTileLocalIndexId(tileId, s);
        }
    }
}



