/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import java.io.*;
import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.db.SpoolingObjectDb;
import com.simsilica.mworld.db.ParentIdFileFunction;
import com.simsilica.mworld.tile.io.ColumnStatesProtocol;



/**
 *  Single-instance access to persisted ColumnStates objects.
 *  While any object holds a reference to a particular ColumnStates
 *  object, it is guaranteed to be the only instance of that object
 *  for a particular TileId.
 *
 *  This can be used for a variety of reasons but is generally
 *  used by tile layer generators/providers that need to keep track
 *  of when the existing layer is 'dirty' and should be updated
 *  upon next access.
 *
 *  @author    Paul Speed
 */
public class ColumnStatesDb extends SpoolingObjectDb<TileId, ColumnStates> {
    static Logger log = LoggerFactory.getLogger(ColumnStatesDb.class);

    private File root;
    private ColumnStatesProtocol stateProtocol = new ColumnStatesProtocol();
    private Function<TileId, File> fileFunc;

    public ColumnStatesDb( File root ) {
        this(root, ".state");
    }

    public ColumnStatesDb( File root, String extension ) {
        super("ColumnStatesDb:" + extension);
        this.root = root;
        if( extension.charAt(0) != '.' ) {
            extension = "." + extension;
        }
        this.fileFunc = new ParentIdFileFunction<>(root, extension);
    }

    /**
     *  Marks the specific column dirty in whatever Tile's ColumnStates is
     *  appropriate.
     */
    public boolean markDirty( ColumnId colId ) {
        TileId tileId = colId.getTileId();
        if( log.isTraceEnabled() ) {
            log.trace("markDirty(" + colId + ") in tile:" + tileId);
        }
        ColumnStates states = get(tileId);
        if( states.markDirty(colId) ) {
            // Need to store the state
            log.info("Need to store column state for:" + tileId);
            update(tileId, states);
            return true;
        }
        return false;
    }

    protected ColumnStates loadObject( TileId id ) {
        if( log.isTraceEnabled() ) {
            log.trace("loadObject(" + id + ")");
        }
        File f = fileFunc.apply(id);
        if( f.exists() ) {
            return readStatesFile(f);
        }
        if( log.isTraceEnabled() ) {
            log.trace("new ColumnStates(" + id + ")");
        }
        return new ColumnStates(id);
    }

    protected void storeObject( TileId id, ColumnStates states ) {
        File f = fileFunc.apply(id);
        log.info("writing states:" + states + " to:" + f);
        writeStatesFile(f, states);
    }

    protected ColumnStates readStatesFile( File f ) {
        try( BufferedInputStream in = new BufferedInputStream(new FileInputStream(f)) ) {
            return stateProtocol.read(in);
        } catch( IOException e ) {
            throw new RuntimeException("Error reading column states file:" + f, e);
        }
    }

    protected void writeStatesFile( File f, ColumnStates states ) {
        long start = System.nanoTime();
        try( BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(f)) ) {
            stateProtocol.write(states, out);
        } catch( IOException e ) {
            throw new RuntimeException("Error writing column states:" + f, e);
        }
        long end = System.nanoTime();
        if( log.isTraceEnabled() ) {
            log.trace("Wrote [" + states + "] in " + ((end - start)/1000000.0) + " ms");
        }
    }

}


