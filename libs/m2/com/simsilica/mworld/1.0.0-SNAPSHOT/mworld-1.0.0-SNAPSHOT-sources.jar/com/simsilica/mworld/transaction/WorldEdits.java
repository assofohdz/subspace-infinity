/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.transaction;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mworld.CellChangeEvent;
import com.simsilica.mworld.ColumnData;
import com.simsilica.mworld.DataType;
import com.simsilica.mworld.LeafId;


/**
 *  Keeps track of a set of cell edits that have been performed.
 *
 *  @author    Paul Speed
 */
public class WorldEdits {
    static Logger log = LoggerFactory.getLogger(WorldEdits.class);

    private Map<LeafId, LeafEdits> leafIndex = new HashMap<>();
    private Set<ColumnData> modifiedColumns = new HashSet<>();

    public WorldEdits() {
    }

    public Set<ColumnData> getModifiedColumns() {
        return modifiedColumns;
    }

    public Set<LeafId> getModifiedLeafIds() {
        return leafIndex.keySet();
    }

    public List<CellChangeEvent> createCellChangeEvents() {
        List<CellChangeEvent> result = new ArrayList<>();
        for( LeafEdits trans : leafIndex.values() ) {
            result.add(trans.createCellChangeEvent());
        }
        return result;
    }

    public ColumnData getColumnData( LeafId leafId ) {
        long searchId = leafId.getColumnId().getId();
        for( ColumnData col : modifiedColumns ) {
            if( col.getColumnId().getId() == searchId ) {
                return col;
            }
        }
        return null;
    }

    protected final LeafEdits getLeafTrans( LeafId leafId, boolean create ) {
        LeafEdits result = leafIndex.get(leafId);
        if( result == null && create ) {
            result = new LeafEdits(leafId);
            leafIndex.put(leafId, result);
        }
        return result;
    }

    public void cellChanged( ColumnData col, LeafId leafId, DataType type, int i, int j, int k, int value, int oldValue ) {
        modifiedColumns.add(col);
        if( log.isTraceEnabled() ) {
            log.trace("cellChanged(" + leafId + ", " + type + ", " + i + ", " + j + ", " + k + ", " + Integer.toHexString(value) + ")");
        }
        getLeafTrans(leafId, true).cellChanged(type, i, j, k, value, oldValue);
    }
}
