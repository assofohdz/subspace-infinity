/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.math.*;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.renderer.Camera;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.texture.Texture;
import com.jme3.scene.*;
import com.jme3.shader.VarType;
import com.jme3.util.BufferUtils;
import com.jme3.util.SafeArrayList;

import com.simsilica.lemur.GuiGlobals;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.sim.Blackboard;
import com.simsilica.state.*;
import com.simsilica.thread.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.*;
import com.simsilica.mworld.view.*;


/**
 *  Displays the LOD points clouds for the tiles.
 *
 *  @author    Paul Speed
 */
public class PointCloudState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(PointCloudState.class);

    private Node viewRoot;

    private Blackboard blackboard;
    private World world;
    private String workerPoolId = "regularWorkers";
    private JobState workers;
    private int basePriority = 500;

    private VersionedReference<Vec3d> posRef;

    private Function<PointType, Material> materialFactory;

    private int viewRadius = 2;
    private int conveyorSize = viewRadius * 2 + 1;
    //private TileGeometry[][] tiles = new TileGeometry[conveyorSize][conveyorSize];
    private Slot[] slots;
    private Vec3i center = new Vec3i(0, 100, 0);  // set it to something that will never match
    private Vec3i centerWorld = new Vec3i();

    private ViewMask viewMask;
    private VersionedReference<Vec3i> maskCenter;

    private SafeArrayList<TileGeometry> fadingTiles = new SafeArrayList<>(TileGeometry.class);

    // True if the camera never moves in xz space, false if it moves within its grid cell.
    // In the long run, this is not as flexible as it needs to be but it will work today.
    private boolean xzLockedCamera = false;

    private PointCloudObserver pcObserver = new PointCloudObserver();
    private ConcurrentLinkedQueue<TileId> invalidTiles = new ConcurrentLinkedQueue<>();

    private FogSettings fogSettings;
    private VersionedReference<FogSettings> fogSettingsRef;

    private float clipDistance = 6000;

    private float pointScale = 1f;

    public PointCloudState() {
        this(null, true);
    }

    public PointCloudState( boolean enabled ) {
        this(null, enabled);
    }

    public PointCloudState( Blackboard blackboard ) {
        this(blackboard, true);
    }

    public PointCloudState( Blackboard blackboard, boolean enabled ) {
        setEnabled(enabled);
        this.blackboard = blackboard;
    }

    public PointCloudState xzLockedCamera( boolean xzLockedCamera ) {
        setXzLockedCamera(xzLockedCamera);
        return this;
    }

    public PointCloudState workerPoolId( String workerPoolId ) {
        this.workerPoolId = workerPoolId;
        if( isInitialized() ) {
            throw new IllegalStateException("Cannot change the worker pool once initialized");
        }
        return this;
    }

    public void setXzLockedCamera( boolean f ) {
        this.xzLockedCamera = f;
    }

    public boolean isXzLockedCamera() {
        return xzLockedCamera;
    }

    public void setClipDistance( float distance ) {
        if( this.clipDistance == distance ) {
            return;
        }
        this.clipDistance = distance;
        resetFog();
    }

    public float getClipDistance() {
        return clipDistance;
    }

    public void setFogSettings( FogSettings fogSettings ) {
        this.fogSettings = fogSettings;
        fogSettingsRef = fogSettings == null ? null : fogSettings.createReference();
        resetFog();
    }

    public FogSettings getFogSettings() {
        return fogSettings;
    }

    public void setPointScale( float pointScale ) {
        log.info("setPointScale(" + pointScale + ")");
        if( this.pointScale == pointScale ) {
            return;
        }
        this.pointScale = pointScale;
        if( slots != null ) {
            for( Slot slot : slots ) {
                if( slot.tile ==  null ) {
                    continue;
                }
                slot.tile.setPointScale(pointScale);
            }
        }
    }

    public float getPointScale() {
        return pointScale;
    }

    protected int getFogDistance() {
        return fogSettings == null ? 0 : fogSettings.getFogDistance();
    }

    protected void resetFog() {
        if( viewRoot != null ) {
            TerrainState.updateFogDistance(viewRoot, getFogDistance(), clipDistance);
        }
    }

    public void setMaterialFactory( Function<PointType, Material> materialFactory ) {
        if( this.materialFactory == materialFactory ) {
            return;
        }
        this.materialFactory = materialFactory;
        //if( tiles != null ) {
        //    for( int i = 0; i < conveyorSize; i++ ) {
        //        for( int j = 0; j < conveyorSize; j++ ) {
        //            TileGeometry tile = tiles[i][j];
        //            if( tile == null ) {
        //                continue;
        //            }
        //            tile.updateMaterial(materialFactory);
        //        }
        //    }
        //}
        if( slots != null ) {
            for( Slot slot : slots ) {
                if( slot.tile ==  null ) {
                    continue;
                }
                slot.tile.updateMaterial(materialFactory);
            }
        }
    }

    public Function<PointType, Material> getMaterialFactory() {
        return materialFactory;
    }

    protected void setViewMask( ViewMask viewMask ) {
        this.viewMask = viewMask;
        this.maskCenter = viewMask.createReference();

        if( slots != null ) {
            for( Slot slot : slots ) {
                if( slot.tile ==  null ) {
                    continue;
                }
                // Let the tile know where the latest center is
                slot.tile.updateViewMask();
            }
        }
        //if( tiles != null ) {
        //    for( int i = 0; i < conveyorSize; i++ ) {
        //        for( int j = 0; j < conveyorSize; j++ ) {
        //            TileGeometry tile = tiles[i][j];
        //            if( tile == null ) {
        //                continue;
        //            }
        //            // Let the tile know where the latest center is
        //            tile.updateViewMask();
        //        }
        //    }
        //}
    }

    protected void initializeSlots() {
        List<Slot> list = new ArrayList<>();

        int radius = viewRadius;
        for( int x = -radius; x <= radius; x++ ) {
            for( int z = -radius; z <= radius; z++ ) {
                list.add(new Slot(x, z));
            }
        }

        Collections.sort(list);
        this.slots = list.toArray(new Slot[0]);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {
        this.viewRoot = new Node("PointCloudRoot");

        initializeSlots();

        // If no material material factory is defined then set one up
        if( getMaterialFactory() == null ) {
            log.warn("No material factory configured.  Using a default pointCloudMaterial()");

            setMaterialFactory(MaterialFactories.pointCloudMaterial(getApplication()));
        }

        if( blackboard == null ) {
            blackboard = getState(BlackboardState.class, true).getBlackboard();
        }
        this.world = blackboard.get(World.class);

        blackboard.onInitialize(ViewMask.class, (ViewMask mask) -> { setViewMask(mask); });
        blackboard.onInitialize(FogSettings.class, (FogSettings fogSettings) -> { setFogSettings(fogSettings); });

        workers = getState(workerPoolId, JobState.class);

        // FIXME: give blackboard a better casting pattern to avoid requiring warning suppression
        posRef = ((VersionedObject<Vec3d>)blackboard.get("position")).createReference();

        world.addTileListener(pcObserver);

        //pointClouds = getState(WorldState.class, true);
        //workers = getState("regularWorkers", JobState.class);
        //
        //posRef = getState(PlayerState.class).createPositionReference();
        //
        //viewMask = getState(LocalViewState.class, true).getViewMask();
        //maskCenter = viewMask.createReference();

        //pointClouds.addPointCloudListener(pcObserver);
    }

    @Override
    protected void cleanup( Application app ) {
        //pointClouds.removePointCloudListener(pcObserver);
        world.removeTileListener(pcObserver);
    }

    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getRootNode().attachChild(viewRoot);
    }

    @Override
    protected void onDisable() {
        viewRoot.removeFromParent();
    }

    @Override
    public void update( float tpf ) {
        if( posRef.update() ) {
            Vec3d pos = posRef.get();
            updateTiles(pos);

            if( xzLockedCamera ) {
                viewRoot.setLocalTranslation(-(float)(pos.x - centerWorld.x), 0, -(float)(pos.z - centerWorld.z));
            } else {
                // Only move it when crossing column boundaries
                Vec3d columnPos = ColumnId.fromWorld(pos).getWorld(null).toVec3d();
                viewRoot.setLocalTranslation(-(float)(columnPos.x - centerWorld.x), 0, -(float)(columnPos.z - centerWorld.z));
            }
        }

        if( fogSettingsRef != null && fogSettingsRef.update() ) {
            resetFog();
        }

        for( TileGeometry tg : fadingTiles.getArray() ) {
            tg.update(tpf);
        }

        TileId toUpdate = null;
        while( (toUpdate = invalidTiles.poll()) != null ) {
            for( Slot slot : slots ) {
                TileGeometry tile = slot.tile;
                // Could theoretically be null if updateTiles() has never been run before.
                if( tile == null ) {
                    continue;
                }
                if( Objects.equals(tile.id, toUpdate) ) {
                    tile.queued = true;
                    workers.execute(tile, basePriority);
                }
            }

            //for( int i = 0; i < conveyorSize; i++ ) {
            //    for( int j = 0; j < conveyorSize; j++ ) {
            //        TileGeometry tile = tiles[i][j];
            //        if( Objects.equals(tile.id, toUpdate) ) {
            //            tile.queued = true;
            //            workers.execute(tile, basePriority);
            //        }
            //    }
            //}
        }

        if( maskCenter.update() ) {
            updateTileMasks(maskCenter.get());
        }
    }

    protected void updateTiles( Vec3d pos ) {
        Vec3i newCenter = TileId.GRID.worldToCell(pos);
        if( newCenter.equals(center) ) {
            return;
        }
        center.set(newCenter);
        centerWorld = TileId.GRID.cellToWorld(center);

        System.out.println("Need to refresh point cloud tiles.... tile Center:" + center + "  world center:" + centerWorld);

        int radius = viewRadius;

        Map<TileId, TileGeometry> tileMap = new HashMap<>();

        // Copy the existing tiles into the index
        for( Slot slot : slots ) {
            TileGeometry tile = slot.tile;
            if( tile == null ) {
                continue;
            }
            tileMap.put(tile.id, tile);
        }
        //for( int x = -radius; x <= radius; x++ ) {
        //    for( int y = -radius; y <= radius; y++ ) {
        //        TileGeometry tile = tiles[x+radius][y+radius];
        //        if( tile == null ) {
        //            continue;
        //        }
        //        tileMap.put(tile.id, tile);
        //    }
        //}

        for( Slot slot : slots ) {
            int xTile = centerWorld.x + slot.xTile;
            int yTile = centerWorld.y;
            int zTile = centerWorld.z + slot.zTile;
            TileId id = TileId.fromWorld(xTile, yTile, zTile);
            TileGeometry tile = tileMap.remove(id);
            if( tile == null ) {
                tile = new TileGeometry(id, xTile, zTile);
                tile.setMaskCenter(maskCenter.get());
                int priority = basePriority + slot.priority;
                tile.queued = true;
                workers.execute(tile, priority);
            } else {
                //System.out.println("Reusing tile for:" + xTile + ", " + zTile);
            }

            tile.setPosition((float)slot.xTile, 0, (float)slot.zTile);
            slot.tile = tile;
        }

        //for( int x = -radius; x <= radius; x++ ) {
        //    for( int y = -radius; y <= radius; y++ ) {
        //
        //        int xTile = centerWorld.x + x * 1024;
        //        int zTile = centerWorld.z + y * 1024;
        //        TileId id = TileId.fromWorld(xTile, zTile);
        //        TileGeometry tile = tileMap.remove(id);
        //        if( tile == null ) {
        //            tile = new TileGeometry(id, xTile, zTile);
        //            tile.setMaskCenter(maskCenter.get());
        //            int priority = basePriority + x * x + y * y;
        //            // FIXME: because we execute them as we encounter them then
        //            // the worker slots get filled up with lower priority stuff
        //            // from the lower corner.
        //            tile.queued = true;
        //            workers.execute(tile, priority);
        //        } else {
        //            //System.out.println("Reusing tile for:" + xTile + ", " + zTile);
        //        }
        //
        //        tile.setPosition((float)(x * 1024), 0, (float)(y * 1024));
        //        tiles[x + radius][y + radius] = tile;
        //    }
        //}

        for( TileGeometry tile : tileMap.values() ) {
            if( tile.queued ) {
                // Still being worked so try to get rid of it
                if( workers.cancel(tile) ) {
                    tile.queued = false;
                }
            }
            tile.release();
        }

    }

    protected void updateTileMasks( Vec3i center ) {

        for( Slot slot : slots ) {
            TileGeometry tile = slot.tile;
            if( tile != null ) {
                tile.setMaskCenter(center);
            }
        }

        //int radius = viewRadius;
        //for( int x = -radius; x <= radius; x++ ) {
        //    for( int y = -radius; y <= radius; y++ ) {
        //        TileGeometry tile = tiles[x + radius][y + radius];
        //        if( tile !=  null ) {
        //            tile.setMaskCenter(center);
        //        }
        //    }
        //}
    }

    protected Vector2f colorToUv( int color ) {
        int x = color & 0x7;
        int y = (color & 0x38) >> 3;

        float textureScale = 0.125f; // 1/8th
        float halfScale = textureScale * 0.5f;
        float s = x * textureScale + halfScale;
        float t = 1f - (y * textureScale + halfScale);
        return new Vector2f(s, t);
    }

    protected Vector4f lightToVec4( int light ) {
        float s = LightUtils.sun(light)/15f;
        float r = LightUtils.red(light)/15f;
        float g = LightUtils.green(light)/15f;
        float b = LightUtils.blue(light)/15f;
        return new Vector4f(r, g, b, s);
    }

    protected Geometry createGeometry( PointCloudLayer layer ) {

        // For now, just the default point type
        PointType pointType = new PointType((byte)0);

        Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.Points);

        List<Vector3f> verts = new ArrayList<>();
        List<Vector3f> norms = new ArrayList<>();
        List<Vector2f> uvs = new ArrayList<>();
        List<Vector4f> colors = new ArrayList<>();

        int faces = 0; // just for math fun

int maxCloudSize = 0;

        for( PointCloudData pc : layer.getPointClouds() ) {

            //Vec3i base = pc.getColumnId().getTileLocal(null);
            int xBase = pc.getOriginX();
            int zBase = pc.getOriginZ();

            Point[] points = pc.getPoints(pointType);
            if( points == null || points.length == 0 ) {
                continue;
            }

if( points.length > maxCloudSize ) {
    maxCloudSize = points.length;
}

            for( Point p : points ) {
//public class Point {
//    public byte x;
//    public short y;
//    public byte z;
//    public byte type;
//    public byte direction;

                // For  now, don't add the light types
                // FIXME: more robust light handling or move this filtering into point cloud generation
                if( p.index >= 65 ) {
                    continue;
                }

                verts.add(new Vector3f(xBase + p.x, p.y, zBase + p.z));

                // We're going to encode the direction mask
                // into the normal so that proper view-dependent normals
                // can be calculated.
                // 0 = no direction at all
                // 0.25 = only one direction
                // 0.5 = both directions
                // 0.75 = only the other direction
                float xd = 0;
                float yd = 0;
                float zd = 0;

                int mask = p.direction;
                if( DirectionMasks.hasEastOrWest(mask) ) {
                    if( !DirectionMasks.hasEast(mask) ) {
                        // Only west
                        xd = 0.25f;
                        faces++;
                    } else if( !DirectionMasks.hasWest(mask) ) {
                        // Only east
                        xd = 0.75f;
                        faces++;
                    } else {
                        // Both
                        xd = 0.5f;
                        faces++;
                        faces++;
                    }
                }
                if( DirectionMasks.hasUpOrDown(mask) ) {
                    if( !DirectionMasks.hasUp(mask) ) {
                        // Only down
                        yd = 0.25f;
                        faces++;
                    } else if( !DirectionMasks.hasDown(mask) ) {
                        // Only up
                        yd = 0.75f;
                        faces++;
                    } else {
                        // Both
                        yd = 0.5f;
                        faces++;
                        faces++;
                    }
                }
                if( DirectionMasks.hasNorthOrSouth(mask) ) {
                    if( !DirectionMasks.hasSouth(mask) ) {
                        // Only north
                        zd = 0.25f;
                        faces++;
                    } else if( !DirectionMasks.hasNorth(mask) ) {
                        // Only south
                        zd = 0.75f;
                        faces++;
                    } else {
                        // Both
                        zd = 0.5f;
                        faces++;
                        faces++;
                    }
//if( zd == 0.5 ) {
//    log.info("p[" + p.x + ", " + p.y + ", " + p.z + "] zd:" + zd);
//}
                }

                norms.add(new Vector3f(xd, yd, zd));
                uvs.add(colorToUv(p.index-1));

                colors.add(lightToVec4(p.light));
            }
        }

log.info("Cloud points count:" + verts.size() + "  visible faces:" + faces);
log.info("Max cloud size:" + maxCloudSize);

        int vertCount = verts.size();
        FloatBuffer pb = BufferUtils.createFloatBuffer(vertCount * 3);
        FloatBuffer tb = BufferUtils.createFloatBuffer(vertCount * 2);
        FloatBuffer nb = BufferUtils.createFloatBuffer(vertCount * 3);
        FloatBuffer cb = BufferUtils.createFloatBuffer(vertCount * 4);

        for( Vector3f v : verts ) {
            pb.put(v.x);
            pb.put(v.y);
            pb.put(v.z);
        }
        for( Vector3f v : norms ) {
            nb.put(v.x);
            nb.put(v.y);
            nb.put(v.z);
        }
        for( Vector2f v : uvs ) {
            tb.put(v.x);
            tb.put(v.y);
        }
        for( Vector4f v : colors ) {
            cb.put(v.x);
            cb.put(v.y);
            cb.put(v.z);
            cb.put(v.w);
        }

        mesh.setBuffer(VertexBuffer.Type.Position, 3, pb);
        mesh.setBuffer(VertexBuffer.Type.TexCoord, 2, tb);
        mesh.setBuffer(VertexBuffer.Type.Normal, 3, nb);
        mesh.setBuffer(VertexBuffer.Type.Color, 4, cb);
        mesh.setStatic();
        mesh.updateBound();

        GuiGlobals globals = GuiGlobals.getInstance();
        Texture texture = globals.loadTexture("Textures/palette-desert.png", true, true);

        Geometry geom = new Geometry("pointCloud:" + layer.getTileId(), mesh);
        //Material mat = new Material(getApplication().getAssetManager(), "MatDefs/BlockPoints.j3md");
        //geom.setMaterial(mat);
        // For now, just one point type layer
        Material mat = materialFactory.apply(null);
        if( fogSettings != null ) {
            fogSettings.apply(mat);
        }
        geom.setMaterial(mat);

        //mat.setTexture("ColorMap", texture);
        //
        Camera cam = getApplication().getCamera();
        float c = cam.getProjectionMatrix().m00;
        c *= cam.getWidth() * 0.5f;
        // send attenuation params
        mat.setFloat("Quadratic", c);
        mat.setFloat("PointScale", pointScale);
        log.info("setting created material point scale to:" + pointScale);

        ////mat.setTexture("MaskMap", viewMask.getMaskTexture());
        //mat.setTexture("MaskArray", viewMask.getMaskTextures());
        //mat.setFloat("ViewMaskRadiusXZ", viewMask.getViewRadius().x);
        //mat.setFloat("ViewMaskRadiusY", viewMask.getViewRadius().y);

        //mat.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        geom.setQueueBucket(Bucket.Transparent);

        TerrainState.updateFogDistance(geom, getFogDistance(), clipDistance);

        return geom;
    }

    private class Slot implements Comparable<Slot> {
        int xSlot;
        int zSlot;
        int xTile;
        int zTile;
        int priority;
        TileGeometry tile;

        public Slot( int xSlot, int zSlot ) {
            this.xSlot = xSlot;
            this.zSlot = zSlot;
            this.xTile = xSlot * 1024;
            this.zTile = zSlot * 1024;
            this.priority = xSlot * xSlot + zSlot * zSlot;
        }

        public int compareTo( Slot slot ) {
            if( this.priority < slot.priority ) {
                return -1;
            }
            if( this.priority > slot.priority ) {
                return 1;
            }
            return 0;
        }
    }


    private class TileGeometry implements Job {
        TileId id;
        int xCorner;
        int zCorner;
        PointCloudLayer pointLayer;

        Geometry generatedGeom;
        Geometry geom;
        Vector3f position = new Vector3f();

        volatile boolean visible;
        boolean firstTime = true;
        private volatile boolean queued;

        Vector3f maskOffset = new Vector3f();

        float alpha;

        public TileGeometry( TileId id, int xCorner, int zCorner ) {
            this.id = id;
            this.xCorner = xCorner;
            this.zCorner = zCorner;
            this.visible = true;
        }

        public void setPointScale( float pointScale ) {
            if( geom != null ) {
                geom.getMaterial().setFloat("PointScale", pointScale);
                log.info("setting material point scale to:" + pointScale);
            }
        }

        public void updateMaterial( Function<PointType, Material> materialFactory ) {
            if( geom != null ) {
                // For now, just one point type layer
                Material material = materialFactory.apply(null);
                if( fogSettings != null ) {
                    fogSettings.apply(material);
                }
                geom.setMaterial(material);
                geom.getMaterial().setFloat("PointScale", pointScale);
                log.info("setting updated material point scale to:" + pointScale);
            }
        }

        public void updateViewMask() {
            Material material = geom.getMaterial();
            if( log.isTraceEnabled() ) {
                log.trace(id + ".updateViewMask() viewMask:" + viewMask + "  material:" + material);
            }
            if( viewMask != null && material != null ) {
                material.setTexture("MaskArray", viewMask.getMaskTextures());
                material.setVector3("MaskOffset", maskOffset);
                material.setFloat("ViewMaskRadiusXZ", viewMask.getViewRadius().x);
                material.setFloat("ViewMaskRadiusY", viewMask.getViewRadius().y);
            }
        }

        public void setMaskCenter( Vec3i center ) {

            // Note: retrieving the world location of the tile ID seems redundant
            // when we already have it in xCorner/yCorner.  If we consolidate TreeState
            // and PointCloudState into a base class + specializations then TreeState does
            // that part better.
            Vec3i world = id.getWorld(null);
            if( log.isTraceEnabled() ) {
                log.trace(id + ".setMaskCenter(" + center + ") world:" + world + "  corner:" + xCorner + ", " + zCorner);
            }

            // The point cloud mesh is in tile space.
            // That should make this calculation pretty easy.
            maskOffset.x = (float)(center.x - world.x);
            maskOffset.y = (float)(center.y);
            maskOffset.z = (float)(center.z - world.z);

            // So then in the shader, (modelSpacePos - maskOffset) / 32 should
            // be our mask texture coordinate.
        }

        public void update( float tpf ) {
            alpha += tpf;
            if( alpha >= 1f ) {
                fadingTiles.remove(this);
                alpha = 1;
            }
            geom.getMaterial().setFloat("Alpha", alpha);
        }

        public void setPosition( float x, float y, float z ) {
            position.set(x, y, z);
            if( geom != null ) {
                geom.setLocalTranslation(x, y, z);
            }
        }

        public void release() {
            visible = false;
            if( geom != null ) {
                geom.removeFromParent();
            }
        }

        public void runOnWorker() {
            if( !visible ) {
                return;
            }
            queued = false;
            //this.pointLayer = pointClouds.getLayer(id);
            //this.pointLayer = pointClouds.getPointCloudLayer(id);
            this.pointLayer = world.getPointCloudLayer(id, Resolution.High);
            Geometry temp = createGeometry(pointLayer);
            if( temp != null ) {
                temp.getMaterial().setVector3("MaskOffset", maskOffset);
            }
            synchronized(this) {
                this.generatedGeom = temp;
            }
        }

        public double runOnUpdate() {
            if( visible ) {
                if( geom != null ) {
                    geom.removeFromParent();
                }
                synchronized(this) {
                    geom = generatedGeom;

                    // We just created this geometry and now need to attach the
                    // update-thread managed state to it.
                    updateViewMask();
                }
                viewRoot.attachChild(geom);
                geom.setLocalTranslation(position);
                if( firstTime ) {
                    firstTime = false;
                    alpha = 0;
                    fadingTiles.add(this);
                } else {
                    alpha = 1;
                }
                geom.getMaterial().setFloat("Alpha", alpha);
                return 1;
            } else {
                return 0;
            }
        }

        @Override
        public String toString() {
            return "PointCloud[" + xCorner + ", " + zCorner + "]";
        }
    }

    private class PointCloudObserver implements TileListener {
        @Override
        public void tileChanged( TileChangeEvent event ) {
            if( event.getResolution() != Resolution.High ) {
                return;
            }
            if( log.isTraceEnabled() ) {
                log.trace("tileChanged(" + event + ")");
            }
            invalidTiles.add(event.getTileId());
        }
    }
}
