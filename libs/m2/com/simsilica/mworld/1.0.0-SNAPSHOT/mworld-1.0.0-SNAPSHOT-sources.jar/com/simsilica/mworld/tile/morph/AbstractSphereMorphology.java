/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;

/**
 *  Morphology base class that can return affected column IDs by
 *  using center and radius.
 *
 *  @author    Paul Speed
 */
public abstract class AbstractSphereMorphology extends AbstractMorphology {
    static Logger log = LoggerFactory.getLogger(AbstractSphereMorphology.class);

    private Vec3i center;
    private int radius;

    protected AbstractSphereMorphology( Vec3i center, int radius ) {
        this.center = center;
        this.radius = radius;
    }

    protected Vec3i getCenter() {
        return center;
    }

    protected int getRadius() {
        return radius;
    }

    @Override
    public Iterable<Short> getAffectedColumns( TileId tileId ) {
        // Could precalculate this for all affected tiles but there
        // seems little point given how often this is called and how we'd
        // have to initialize it every time we load it from disk either way.

        List<Short> results = new ArrayList<>();

        // Figure out the min/max bounds in tile-local column space
        Vec3i origin = tileId.getWorld(null);
        int xMin = (center.x - radius) - origin.x;
        int zMin = (center.z - radius) - origin.z;
        int xMax = (center.x + radius) - origin.x;
        int zMax = (center.z + radius) - origin.z;

        // See if we are even within the tile bounds
        if( xMax < 0 || zMax < 0 ) {
            return results;
        }
        if( xMin >= TileId.SIZE || zMin >= TileId.SIZE ) {
            return results;
        }

        // We intersect the tile somewhere so clamp the bounds
        xMin = Math.max(0, xMin);
        xMax = Math.min(xMax, 1023);
        zMin = Math.max(0, zMin);
        zMax = Math.min(zMax, 1023);

        // Now move it into grid cell space
        Vec3i min = ColumnId.GRID.worldToCell(xMin, 0, zMin);
        Vec3i max = ColumnId.GRID.worldToCell(xMax, 0, zMax);

        for( int x = min.x; x <= max.x; x++ ) {
            for( int z = min.z; z <= max.z; z++ ) {
                short id = ColumnId.toTileLocalIndexId(x, z);
                results.add(id);

                // just double-check our math
                ColumnId colId = ColumnId.fromTileLocalIndex(tileId, x, z);
                if( tileId.getId() != colId.getTileId().getId() ) {
                    // It's in a different tile... but we shouldn't ever
                    // get here if our bounds math is correct.
                    log.warn("Tile mismatch for (" + x + ", " + z + ") tile:" + tileId + "  min:" + min + "  max:" + max);
                    continue;
                }
            }
        }

        return results;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[center:" + center + ", radius:" + radius + "]";
    }
}
