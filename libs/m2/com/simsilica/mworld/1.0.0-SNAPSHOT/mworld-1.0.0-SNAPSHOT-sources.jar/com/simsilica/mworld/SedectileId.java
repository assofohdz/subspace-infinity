/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import java.util.Objects;

import com.simsilica.mathd.*;


/**
 *  The unique ID of a 16384x16384 area of the map.  This is the
 *  largest "generation unit" in the typical algorithms.
 *
 *  @author    Paul Speed
 */
public class SedectileId implements GridBasedId, java.io.Serializable {
    public static final int SIZE = WorldGrids.SEDECTTILE_SIZE;
    public static final Grid GRID = WorldGrids.SEDECTILE_GRID;

    private static final long serialVersionUID = 42L;

    private long id;
    
    public SedectileId( long id ) {
        this.id = id;
    }
 
    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
    public static SedectileId fromWorld( Vec3i world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
    public static SedectileId fromWorld( Vec3d world ) {
        return fromWorld(world.x, world.y, world.z);
    }

    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
    public static SedectileId fromWorld( double x, double y, double z ) {
        long id = GRID.worldToId(x, y, z);
        return new SedectileId(id);
    }

    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
    public static SedectileId fromWorld( int x, int y, int z ) {
        long id = GRID.worldToId(x, y, z);
        return new SedectileId(id);
    }
    
    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
//    public static SedectileId fromWorld( double x, double z ) {
//        long id = GRID.worldToId(x, 0, z);
//        return new SedectileId(id);
//    }

    /**
     *  Returns the ID for the sedectile (16384x16384 area) that contains
     *  the specified world coordinate.
     */
//    public static SedectileId fromWorld( int x, int z ) {
//        long id = GRID.worldToId(x, 0, z);
//        return new SedectileId(id);
//    }
 
    /**
     *  Returns the ID for the sedectile (16384x16384 area) represented
     *  by the cell coordinates where xCell and zCell are the
     *  raw sedectile coordinates on the tile grid.
     */
    public static SedectileId fromCell( int xCell, int zCell ) {
        long id = GRID.cellToId(xCell, 0, zCell);
        return new SedectileId(id);
    }
    
    @Override   
    public long getId() {
        return id;
    }
    
    /**
     *  Returns the world location of this sedectile.
     */
    public Vec3i getWorld( Vec3i store ) {    
        Vec3i loc = GRID.idToCell(id, store);
        loc = GRID.cellToWorld(loc, loc);             
        return loc;
    }
    
    /**
     *  Returns the cell coordinate on the sedectile grid for this
     *  ID.
     */
    public Vec3i getCell( Vec3i store ) {
        return GRID.idToCell(id, store);
    }
    
    @Override
    public GridCell getGridCell() {
        return getGrid().getContainingCell(getWorld(null));        
    }
     
    @Override   
    public Grid getGrid() {
        return GRID;
    }
    
    @Override
    public Grid getParentGrid() {
        return null;
    }
    
    @Override    
    public int hashCode() {
        return Objects.hash(id);
    }
        
    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        SedectileId other = (SedectileId)o;
        if( other.id != id ) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + id + "]";
    }
}



