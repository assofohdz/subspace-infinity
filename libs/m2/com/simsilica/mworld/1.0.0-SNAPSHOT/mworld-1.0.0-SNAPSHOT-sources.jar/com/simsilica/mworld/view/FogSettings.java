/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import org.slf4j.*;

import com.jme3.math.ColorRGBA;
import com.jme3.material.Material;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

/**
 *  Centrally keeps track of the fog distance, fog color, and any
 *  other fog-related parameters we might have.
 *
 *  @author    Paul Speed
 */
public class FogSettings implements VersionedObject<FogSettings> {
    static Logger log = LoggerFactory.getLogger(FogSettings.class);

    private long version;

    private ColorRGBA fogColor = new ColorRGBA(0.7f, 0.7f, 0.9f, 1f);
    private int fogDistance = 3072;

    public FogSettings() {
    }

    public FogSettings( ColorRGBA fogColor ) {
        this.fogColor.set(fogColor);
    }

    public void setFogColor( ColorRGBA fogColor ) {
        this.fogColor.set(fogColor);
        version++;
    }

    public ColorRGBA getFogColor() {
        return fogColor;
    }

    public void setFogDistance( int fogDistance ) {
        if( this.fogDistance == fogDistance ) {
            return;
        }
        this.fogDistance = fogDistance;
        version++;
    }

    public int getFogDistance() {
        return fogDistance;
    }

    /**
     *  Applies the fog settings to the specified material.
     */
    public void apply( Material material ) {
        if( fogDistance == 0 ) {
            material.setBoolean("UseFog", false);
        } else {
            // Fog parameters
            //  Boolean UseFog
            //  Color FogColor
            //  Vector2 LinearFog
            //  Float ExpFog
            //  Float ExpSqFog

            material.setBoolean("UseFog", true);
            material.setColor("FogColor", fogColor);
            material.setFloat("ExpFog", 1f/fogDistance);
        }
    }

    @Override
    public long getVersion() {
        return version;
    }

    @Override
    public FogSettings getObject() {
        return this;
    }

    @Override
    public VersionedReference<FogSettings> createReference() {
        return new VersionedReference<>(this);
    }

}
