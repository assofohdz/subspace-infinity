/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.net;

import com.jme3.network.service.rmi.Asynchronous;

import com.simsilica.mworld.tile.TerrainImageType;
import com.simsilica.mworld.tile.Resolution;

/**
 *  The client for the underlying data transfer mechanism that
 *  handles the breaking up and streaming of leaf data messages.
 *
 *  @author    Paul Speed
 */
public interface WorldDataSession {

    public enum IndexType { BlockType, FluidType, TreeType };

    public int getMaxY();

    @Asynchronous
    public void requestLeafData( long requestId, long leafId );

    @Asynchronous
    public void requestLightData( long requestId, long leafId );

    @Asynchronous
    public void requestFluidData( long requestId, long leafId );

    @Asynchronous
    public void requestTerrainImage( long requestId, long tileId, TerrainImageType type, Resolution res );

    @Asynchronous
    public void requestTrees( long requestId, long tileId, Resolution res );

    @Asynchronous
    public void requestPointCloudLayer( long requestId, long tileId, Resolution res );
    
    @Asynchronous
    public void requestIndexData( long requestId, IndexType type );
}


