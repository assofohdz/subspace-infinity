/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import org.slf4j.*;

import java.util.Random;

import com.simsilica.mathd.*;

import com.simsilica.mblock.MaskUtils;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.TerrainImage;

/**
 *  Base class that includes some default implementations of
 *  TreeType methods to make writing custom tree types easier.
 *
 *  @author    Paul Speed
 */
public abstract class AbstractTreeType implements TreeType, java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(AbstractTreeType.class);

    static final long serialVersionUID = 42L;    

    private String name;
    private short index;
    private AtlasCell atlasCell;

    protected AbstractTreeType( String name, AtlasCell atlasCell ) {
        this.name = name;
        this.atlasCell = atlasCell;
    }

    @Override
    public final String getName() {
        return name;
    }

    @Override
    public void setIndex( short index ) {
        this.index = index;
    }

    @Override
    public final short getIndex() {
        return index;
    }

    @Override
    public AtlasCell getAtlasCell( Tree tree ) {
        return atlasCell;
    }

    @Override
    public void initialize( TreeTypeIndex treeTypes ) {
    }

    /**
     *  Default version marks a 3x3 area around the tree as "used".
     */
    @Override
    public boolean markTree( Tree tree, boolean[][] used ) {
        // Just a small 3x3 splat
        int xMin = Math.max(0, tree.x - 1);
        int zMin = Math.max(0, tree.z - 1);
        int xMax = Math.min(1023, tree.x + 1);
        int zMax = Math.min(1023, tree.z + 1);
        for( int x = xMin; x <= xMax; x++ ) {
            for( int z = zMin; z <= zMax; z++ ) {
                used[x][z] = true;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[name:" + name + ", index:" + index + "]";
    }
}
