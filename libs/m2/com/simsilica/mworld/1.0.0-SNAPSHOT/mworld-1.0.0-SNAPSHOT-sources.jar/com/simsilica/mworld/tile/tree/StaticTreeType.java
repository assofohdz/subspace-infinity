/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.tree;

import org.slf4j.*;

import java.util.Random;

import com.simsilica.mathd.*;

import com.simsilica.mblock.MaskUtils;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.TerrainImage;

/**
 *  A straight-forward tree type implementation that simply inserts
 *  a static array of block types of fixed size.
 *
 *  @author    Paul Speed
 */
public class StaticTreeType extends AbstractTreeType implements java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(StaticTreeType.class);

    static final long serialVersionUID = 42L;    

    private int[] types;
    private int[][][] shape;
    private int shapeHeight;
    private int shapeRadius;
    private int xSize;
    private int zSize;

    private byte[][] splat;
    private int xSplatSize;
    private int zSplatSize;

    public StaticTreeType( String name, AtlasCell atlasCell, int[] types, int[][][] shape ) {
        this(name, atlasCell, types, shape, null);
    }

    public StaticTreeType( String name, AtlasCell atlasCell, int[] types, int[][][] shape, byte[][] splat ) {
        super(name, atlasCell);
        this.types = types;
        this.shape = shape;
        this.shapeHeight = shape.length;
        this.zSize = shape[0].length;
        this.xSize = shape[0][0].length;
        if( xSize >= zSize ) {
            this.shapeRadius = xSize / 2;
        } else {
            this.shapeRadius = zSize / 2;
        }
        this.splat = splat;
        if( splat != null ) {
            this.zSplatSize = splat.length;
            if( zSplatSize > 0 ) {
                this.xSplatSize = splat[0].length;
            }
        }
    }

    @Override
    public Tree createTree( short x, short y, short z, TerrainImage terrain, Random random ) {
        // Nothing random about these trees
        return new Tree(x, y, z, (byte)shapeHeight, (byte)shapeRadius, this);
    }

    @Override
    public boolean markTree( Tree tree, boolean[][] used ) {
        // Just a small 3x3 splat
        int xMin = Math.max(0, tree.x - 1);
        int zMin = Math.max(0, tree.z - 1);
        int xMax = Math.min(1023, tree.x + 1);
        int zMax = Math.min(1023, tree.z + 1);
        for( int x = xMin; x <= xMax; x++ ) {
            for( int z = zMin; z <= zMax; z++ ) {
                used[x][z] = true;
            }
        }
        return true;
    }

    boolean paranoid = true;

    @Override
    public boolean insertTree( Tree tree, TileColumnCells cells, Random random ) {
//log.info(colData.getColumnId() + " tileLocal:" + tileLocal + "  tree:" + tree);
        // Calculate the position of the tree relative to the column
        // in tile-local space
        int xMin = tree.x - tree.radius;
        int zMin = tree.z - tree.radius;
        int xMax = tree.x - tree.radius;
        int zMax = tree.z - tree.radius;

        if( paranoid ) {
            Vec3i tileLocal = cells.getColumnData().getColumnId().getTileLocal(null);

            // If it's outside the column then skip it
            if( xMax < tileLocal.x || zMax < tileLocal.z ) {
                // Why are we even trying?
                throw new RuntimeException("tree lower than column, max:" + xMax + ", " + zMax + "  tileLocal:" + tileLocal);
                //return false;
            }
            if( xMin >= (tileLocal.x + 32) || zMin >= (tileLocal.z + 32) ) {
                // Why are we even trying?
                throw new RuntimeException("tree higher than column, min:" + xMin + ", " + zMin + "  tileLocal + 32:" + tileLocal.add(32, 0, 32));
                //return false;
            }
        }

        int yMin = tree.y;
        int yMax = tree.y + tree.height;

        boolean changed = false;
        for( int y = 0; y < shapeHeight; y++ ) {
            int yLocal = y + yMin;
            int[][] layer = shape[y];
            for( int x = 0; x < xSize; x++ ) {
                for( int z = 0; z < zSize; z++ ) {
                    int insert = layer[x][z];
                    if( insert == 0 ) {
                        continue;
                    }
                    int xLocal = xMin + x;
                    int zLocal = zMin + z;
                    insert = types[insert-1];
                    cells.setCell(xLocal, yLocal, zLocal, insert | TREE_BITS);
                    changed = true;
                }
            }
        }
        return changed;
    }

    @Override
    public boolean insertTree( Tree tree, TerrainImage terrain ) {
        if( splat == null ) {
            return false;
        }

        int xCorner = tree.x - (xSplatSize / 2);
        int zCorner = tree.z - (zSplatSize / 2);

        for( int x = 0; x < xSplatSize; x++ ) {
            for( int z = 0; z < zSplatSize; z++ ) {
                int tx = xCorner + x;
                int tz = zCorner + z;
                if( tx < 0 || tz < 0 ) {
                    continue;
                }
                if( tx >= 1024 || tz >= 1024 ) {
                    continue;
                }
                byte b = splat[x][z];
                if( b != 0 ) {
                    terrain.setType(tx, tz, b);
                    terrain.updateLight(tx, tz, (byte)-7);
                }
            }
        }

        // For now
        return false;
    }

    @Override
    public boolean isBlock( Tree tree, int x, int y, int z, int type ) {
        if( x < -tree.radius || z < -tree.radius ) {
            return false;
        }
        if( x > tree.radius || z > tree.radius ) {
            return false;
        }
        if( y < 0 || y >= shape.length ) {
            return false;
        } 
        int xCorner = -tree.radius;
        int zCorner = -tree.radius;
        int[][] layer = shape[y];
        return layer[x][z] == type;
    } 

    //@Override
    //public String toString() {
    //    return getClass().getSimpleName() + "[name:" + getName() + ", index:" + getIndex() + "]";
    //}
}
