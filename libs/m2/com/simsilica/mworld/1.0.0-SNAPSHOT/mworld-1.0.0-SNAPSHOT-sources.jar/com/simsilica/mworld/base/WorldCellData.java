/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.Vec3i;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.transaction.*;

/**
 *  A CellData implementation that centers around a single leaf but is
 *  otherwise backed by the World for cells that fall outside of that
 *  range.  This is to support resetting the masking values of local
 *  neighborhoods of cells when a single cell's value has changed.
 *  It's not necessarily efficient for whole-leaf mask recalculations.
 *
 *  @author    Paul Speed
 */
public class WorldCellData implements CellData {

    static Logger log = LoggerFactory.getLogger(WorldCellData.class);

    private World world;
    private LeafData center;
    private Map<LeafId, LeafData> neighbors = new HashMap<>();
    private Set<LeafData> modified = new HashSet<>();
    private Map<Vec3i, CellChangeEvent> changes = new LinkedHashMap<>();
    private WorldEdits worldEdits = new WorldEdits();

    public WorldCellData( LeafData center, World world ) {
        this.world = world;
        this.center = center;
    }

    public Set<LeafData> getModified() {
        return modified;
    }

    public Collection<CellChangeEvent> getChanges() {
        return worldEdits.createCellChangeEvents();
    }

    private LeafData getLeaf( int x, int y, int z ) {
        if( y < 0 ) {
            //throw new IllegalArgumentException("y cannot be less than 0");
            // We're outside of the world bounds so just return
            // a null leaf and let the caller sort out what to do about it.
            return null;
        }
        if( center.containsCell(x, y, z) ) {
            return center;
        }
        LeafId leafId = LeafId.fromWorld(x, y, z);
        LeafData neighbor = neighbors.get(leafId);
        if( neighbor == null ) {
            neighbor = world.getLeaf(leafId);
            neighbors.put(leafId, neighbor);
        }
        return neighbor;
    }

    public int getCell( int x, int y, int z ) {
        return getCell(x, y, z, -1);
    }

    public int getCell( int x, int y, int z, int defaultValue ) {
        LeafData leaf = getLeaf(x, y, z);
        if( leaf == null ) {
            return defaultValue;
        }

        // Localize the coordinate (should do this in LeafData, really)
        Vec3i leafWorld = leaf.getInfo().location;
        int xCell = x - leafWorld.x;
        int yCell = y - leafWorld.y;
        int zCell = z - leafWorld.z;
//log.info("getCell(" + x + ", " + y + ", " + z + ") leafWorld:" + leaf.getInfo().location + "  cell:" + xCell + ", " + yCell + ", " + zCell);
        return leaf.getCell(xCell, yCell, zCell, defaultValue);
    }

    public int getCell( int x, int y, int z, Direction dir, int defaultValue ) {
        if( y == 0 && dir == Direction.Down ) {
            return defaultValue;
        }
        Vec3i v = dir.getVec3i();
        return getCell(x + v.x, y + v.y, z + v.z, defaultValue);
    }

    public void setCell( int x, int y, int z, int value ) {
        LeafData leaf = getLeaf(x, y, z);
        if( leaf == null ) {
            return;
        }
        Vec3i leafWorld = leaf.getInfo().location;
        int xCell = x - leafWorld.x;
        int yCell = y - leafWorld.y;
        int zCell = z - leafWorld.z;
        int oldValue = leaf.getCell(xCell, yCell, zCell);
        leaf.setCell(xCell, yCell, zCell, value);

        // Only create events for actual changes
        if( oldValue != value ) {
            modified.add(leaf);

            // It's possible that during a WorldCellData 'worldEdits' that
            // a cell gets set multiple times (for example, the center cell value)
            // so we'll keep track of only the unique changes.
            //CellChangeEvent event = new CellChangeEvent(leaf.getInfo().leafId, xCell, yCell, zCell, value);
            //changes.put(new Vec3i(xCell, yCell, zCell), event);
            worldEdits.cellChanged(null, leaf.getInfo().leafId, DataType.Block, xCell, yCell, zCell, value, oldValue);
        }
    }
}
