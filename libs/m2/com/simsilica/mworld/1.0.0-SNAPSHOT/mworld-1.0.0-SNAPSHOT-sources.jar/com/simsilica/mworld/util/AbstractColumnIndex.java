/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.util;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;
import com.simsilica.mworld.ColumnId;

/**
 *  A base class for creating column neihbor data sets.  This internally
 *  keeps track of an array of neighboring ColumnIds around a central
 *  ColumnId and will call abstract methods to load/release those items
 *  as the central column changes. 
 *
 *  @author    Paul Speed
 */
public abstract class AbstractColumnIndex<V> {
    static Logger log = LoggerFactory.getLogger(AbstractColumnIndex.class);
 
    private ColumnId centerColumn;
    
    private int radius;
    private int size;
    private ColumnId[][] neighbors;
    private Map<ColumnId, V> index = new HashMap<>();
 
    protected AbstractColumnIndex( int radius ) {
        this.radius = radius;
        this.size = radius * 2 + 1;
        this.neighbors = new ColumnId[size][size];
    }
 
    public void setCenterColumnId( ColumnId centerColumn ) {
        if( Objects.equals(centerColumn, this.centerColumn) ) {
            return;
        }
        this.centerColumn = centerColumn;
        updateNeighbors();
    }
    
    public ColumnId getCenterColumnId() {
        return centerColumn;
    }
    
    public ColumnId getNeighborColumnId( int xOffset, int zOffset ) {
        return neighbors[xOffset + radius][zOffset + radius];
    }
    
    public V getNeighborColumn( int xOffset, int zOffset ) {
        return index.get(getNeighborColumnId(xOffset, zOffset));
    }

    public V getNeighborColumn( ColumnId colId ) {
        return index.get(colId);
    }
 
    public Set<ColumnId> getColumnIds() {
        return index.keySet();
    }
    
    public Collection<V> getColumns() {
        return index.values();
    }
    
    protected void updateNeighbors() {                
        Set<ColumnId> toRemove = new HashSet<>(index.keySet());
        
        // Set up the neighbor array and load up neighbor information
        Vec3i center = centerColumn.getWorld(null);
        for( int x = -radius; x <= radius; x++ ) {
            for( int z = -radius; z <= radius; z++ ) {
                Vec3i pos = center.add(x * 32, 0, z * 32);
                ColumnId id = ColumnId.fromWorld(pos); 
                neighbors[x + radius][z + radius] = id;
                if( !toRemove.remove(id) ) {
                    // We haven't seen this column before so load it
                    index.put(id, loadColumn(id));
                }
            }
        }
        
        // Anything left in toRemove is old data... so clear it from the index
        for( ColumnId id : toRemove ) {
            V val = index.remove(id);
            releaseColumn(id, val);
        }
    }

    protected abstract V loadColumn( ColumnId id );    
    protected abstract void releaseColumn( ColumnId id, V column );
}


