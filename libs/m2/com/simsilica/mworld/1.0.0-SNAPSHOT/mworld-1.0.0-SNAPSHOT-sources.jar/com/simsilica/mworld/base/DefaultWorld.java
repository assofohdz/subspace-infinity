/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.base;

import java.util.*;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.db.*;
import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.tree.TreeLayer;
import com.simsilica.mworld.tile.pc.*;
import com.simsilica.mworld.transaction.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class DefaultWorld implements World {

    static Logger log = LoggerFactory.getLogger(DefaultWorld.class);

    private boolean initialized;
    private boolean terminated;
    private ColumnDb colDb;
    private int yMax;

    private List<CellChangeListener> cellListeners = new ArrayList<>();
    private CellChangeListener[] cellListenerArray;
    private CellChangeListener[] emptyCellListenerArray = new CellChangeListener[0];

    private LeafChangeListenerSupport leafListeners = new LeafChangeListenerSupport();

    private TileManager tileManager;
    private TerrainImageManager terrainImageManager;
    private PointCloudManager pointCloudManager;

    public DefaultWorld( ColumnDb colDb, TileManager tileManager,
                         TerrainImageManager terrainImageManager, PointCloudManager pointCloudManager,
                         int yMax ) {
        this.colDb = colDb;
        this.tileManager = tileManager;
        this.terrainImageManager = terrainImageManager;
        this.pointCloudManager = pointCloudManager;
        this.yMax = yMax;
    }

    public void initialize() {
        if( initialized ) {
            throw new IllegalStateException("Already initialized");
        }
        colDb.initialize();
        if( tileManager != null ) {
            tileManager.initialize();
        }
        if( terrainImageManager != null ) {
            terrainImageManager.initialize();
        }
        if( pointCloudManager != null ) {
            pointCloudManager.initialize();
        }
        initialized = true;
        terminated = false;
    }

    public void terminate() {
        if( terminated ) {
            throw new IllegalStateException("Already termintated");
        }
        if( !initialized ) {
            throw new IllegalStateException("Not initialized");
        }
        if( pointCloudManager != null ) {
            pointCloudManager.terminate();
        }
        if( terrainImageManager != null ) {
            terrainImageManager.terminate();
        }
        if( tileManager != null ) {
            tileManager.terminate();
        }
        colDb.terminate();
        initialized = false;
        terminated = true;
    }

    @Override
    public void addCellChangeListener( CellChangeListener l ) {
        cellListeners.add(l);
        cellListenerArray = null;
    }

    @Override
    public void removeCellChangeListener( CellChangeListener l ) {
        cellListeners.remove(l);
        cellListenerArray = null;
    }

    protected CellChangeListener[] getCellListenerArray() {
        if( cellListenerArray == null ) {
            cellListenerArray = cellListeners.toArray(emptyCellListenerArray);
        }
        return cellListenerArray;
    }

//    protected void fireCellChanged( LeafId leafId, int x, int y, int z, int value ) {
////log.info("fireCellChanged(" + leafId + ", " + x + ", " + y + ", " + z + ", " + value + ") listeners count:" + cellListeners.size());
//        if( cellListeners.isEmpty() ) {
//            return;
//        }
//        CellChangeEvent event = new CellChangeEvent(leafId, x, y, z, value);
//        fireCellChanged(event);
//    }

    @Override
    public void addLeafChangeListener( LeafChangeListener l ) {
        leafListeners.add(l);
    }

    @Override
    public void removeLeafChangeListener( LeafChangeListener l ) {
        leafListeners.remove(l);
    }

    @Override
    public void addColumnChangeListener( ColumnChangeListener l ) {
        if( colDb instanceof ObservableColumnDb ) {
            ((ObservableColumnDb)colDb).addColumnChangeListener(l);
        } else {
            throw new IllegalArgumentException("Column DB is not observable");
        }
    }

    @Override
    public void removeColumnChangeListener( ColumnChangeListener l ) {
        if( colDb instanceof ObservableColumnDb ) {
            ((ObservableColumnDb)colDb).removeColumnChangeListener(l);
        } else {
            throw new IllegalArgumentException("Column DB is not observable");
        }
    }

    protected void fireCellChanged( CellChangeEvent event ) {
        for( CellChangeListener l : getCellListenerArray() ) {
            l.cellChanged(event);
        }
    }

    @Override
    public int getMaxY() {
        return yMax;
    }

    @Override
    public int setWorldCell( Vec3d world, int type ) {
        // Only log this if we aren't going to be trace logging
        if( !log.isTraceEnabled() ) {
            log.trace("setWorldCell(" + world + ", " + type + ")");
        }
        WorldEdits worldEdits = new WorldEdits();
        int result = setWorldCell(world, type, worldEdits);
        deliverEvents(worldEdits);
        return result;
    }

    public int setWorldCell( Vec3d world, int type, WorldEdits worldEdits ) {

        if( log.isTraceEnabled() ) {
            log.trace("setWorldCell(" + world + ", " + type + ")");
        }

        if( world.y == 0 ) {
            log.warn("Cannot remove 'bedrock'");
            return -1;
        }

        ColumnId colId = ColumnId.fromWorld(world);
        if( log.isTraceEnabled() ) {
            log.trace("colId:" + colId + "  world:" + colId.getWorld(null));
        }
        ColumnData col = colDb.getColumn(colId);
        if( col == null ) {
            return -1;
        }
        LeafData leaf = col.getLeafData((int)world.y);
        if( log.isTraceEnabled() ) {
            log.trace("leaf:" + leaf);
        }
        if( leaf == null ) {
            return -1;
        }
        if( log.isTraceEnabled() ) {
            log.trace("modifying:" + colId);
        }

        // Need to update light and fluid data also
        // ...basically, the rest of this method needs to be rewritten
        // with columns, lighting, and fluids in mind.

        // 2021-10-30
        // I'm going to implement this because it's a useful primitive
        // to have even if it's server-side only and even if the "real way"
        // is probably going to be to queue a mutation function of some kind.

        // Steps look like this:
        // 1) set the cell, keep track of the original version
        //      -get the original value, if it's not a change then return
        //      -set the new value
        //      -recalculate the masks for that cell
        // 2) check for lighting changes
        //      -compare old block light transmissability to new
        //      -if not different then done (ie: replaced a solid block with a solid block)
        //      -subtract old lighting propagated by this block
        //      -seed from surrounding blocks and propagate new lighting from this block
        // 3) check for fluid changes
        //      -compare old block solidness to new
        //      -if not different then it doesn't matter if we are in fluid or not
        //      -get fluid at this block
        //      -if block is empty and not in fluid, check for neighboring fluid
        //          -queue water flow adjustments as necessary
        //      -if block is not empty and in fluid
        //          -delete fluid cell if block is solid
        //          -queue water flow adjustments as necessary
        //
        // Except it's easier if we modify the above to do some lighting
        // subtraction before we modify the blocks.  It's easier to remove
        // a particular light value when the original 'add' propagation can
        // be unwound.

        // Get the coordinate in 'cell space', ie: with the fractional parts chopped off
        int x = Coordinates.worldToCell(world.x);
        int y = Coordinates.worldToCell(world.y);
        int z = Coordinates.worldToCell(world.z);

        // And move them into "column space" which is relative to this
        // column's origin
        Vec3i origin = colId.getWorld(null);
        int cx = x - origin.x;
        int cy = y - origin.y; // should be a no-op
        int cz = z - origin.z;

        // Step 1: See if we need to change the cell
        ColumnNeighborhood data = new ColumnNeighborhood(colDb, col, worldEdits);
        int originalValue = data.getCell(cx, cy, cz);
        if( type == originalValue ) {
            // Really no change
            return originalValue;
        }
        int originalType = MaskUtils.getType(originalValue);
        if( originalType == type ) {
            // Effectively no change
            return originalValue;
        }

        // Step 2.a: lighting subtraction
        // Need to subtract any existing lighting that will be removed
        // before we change blocks... else the subtraction won't propagate properly.
        int originalLight = data.getLight(cx, cy, cz, 0);

        int newType = MaskUtils.getType(type);

        // Step 2: Change the lighting if necessary
        BlockType bOld = BlockTypeIndex.get(originalType);
        BlockType bNew = BlockTypeIndex.get(newType);

        int newLight = 0;
        if( bNew != null ) {
            if( bNew.getLight() != 0 ) {
                //data.setLight(cx, cy, cz, newLight = bNew.getLight());
                newLight = bNew.getLight();
                // Let the seed propagation set it
            } else if( bNew.isSolid() && !bNew.isTransparent() ) {
                //data.setLight(cx, cy, cz, newLight = LightUtils.SOLID);
                newLight = LightUtils.SOLID;
            }
        } else {
            // We need to clear any lighting value that was there before
            // in case it was "solid"
            //data.setLight(cx, cy, cz, 0);
        }
        if( log.isTraceEnabled() ) {
            log.trace("original light:" + Integer.toHexString(originalLight) + "  new:" + Integer.toHexString(newLight));
        }

        CellData light = data.getLightingCellData();

        // Calculate the seeds of any subtraction that we might need.
        // Cases where we need to subtract lighting:
        // -propagation has changed that affects our cell (ie: solid block placed over empty)
        // -new light is different than old light (ie: there will be some lighting change)
        //  AND: parts of the old lighting value match parts of the old block's lighting
        //  AND: new lighting value is not unilaterally greater than old lighting value,
        //          ie: some component will go down.
        //
        // Cases where we don't need to subtract lighting:
        // -lighting has not changed at all
        // -none of the old light matched the old block type's light
        boolean propagationChanged = lightPropagationChanged(bOld, bNew);
        boolean subtractLight = propagationChanged;
        if( !subtractLight && originalLight != newLight ) {
            // Is the new light decreasing at all in any component.
            if( LightUtils.isDecreasing(originalLight, newLight) ) {
                // Did the old block contribute to this lighting in
                // any way.
                int bOldLight = bOld == null ? 0 : bOld.getLight();
                subtractLight = LightUtils.anyMatch(bOldLight, originalLight);
            }
        }
        if( log.isTraceEnabled() ) {
            log.trace("Subtract light:" + subtractLight);
        }

        List<Vec3i> removed = null;
        if( subtractLight ) {
            light = data.getLightingCellData();

            // If the cell used to have light and the new light is 'less'
            // then we need to subtract the old contribution.
            // Try to remove the original light and its influence
            removed = LightUtils.subtractLight(data, light, cx, cy, cz, originalLight);
        }

        // Safe to change the block data now and it will be necessary to calculate
        // any potential 'new light' seeds.
        // Set the data and recalculate the masks
        data.setCell(cx, cy, cz, type);
        MaskUtils.recalculateSideMasks(data, cx, cy, cz, -1); // -1 so that 'outside the world' is badType

        int newValue = data.getCell(cx, cy, cz);

        // Now that we've removed any of the subtracted lights and set the
        // real blocks, it is safe to repropagate any 'removed' light neighbors
        // Note: if we don't do this after setting the cell value then calculateSeed
        // will just repropagate the light because it will find the existing cell
        // just like it was with all of its neighbors contributing back to it.
        if( removed != null ) {
            LinkedList<LightUtils.LightSeed> seeds = new LinkedList<>();
            for( Vec3i v : removed ) {
                LightUtils.LightSeed seed = LightUtils.calculateSeed(data, light, v.x, v.y, v.z, 0, 0);
                if( seed != null ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("  suck:" + seed);
                    }
                    seeds.add(seed);
                }
            }

            // Go ahead and resolve any of those seeds
            int result = LightUtils.propagateSeeds(data, light, seeds, false);
        }

        // See if the lighting change requires a new seed for the new block
        if( originalLight != newLight || propagationChanged ) {
            if( light == null ) {
                light = data.getLightingCellData();
            }
            // Then we might need to contribute new lighting
            LightUtils.LightSeed seed = LightUtils.calculateSeed(data, light, cx, cy, cz, originalLight, newLight);
            if( log.isTraceEnabled() ) {
                log.trace("Seed:" + seed);
            }
            if( seed != null ) {
                LinkedList<LightUtils.LightSeed> seeds = new LinkedList<>();
                seeds.add(seed);
                int result = LightUtils.propagateSeeds(data, light, seeds, false);
            }
        }

        // Step 3: Change the fluid if necessary
        // TBD

        // Step 4: recalculate the fluid-related masks, etc..
        FluidUtils.recalculateSideMasks(data.getFluidCellData(), data, cx, cy, cz, -1); // -1 so that 'outside the world' is badType

        return newValue;
    }

    /**
     *  Sets a raw light value without propagation.
     */
    public int debugSetWorldLight( Vec3d world, int light ) {
        // Only log this if we aren't going to be trace logging
        log.info("debugSetWorldLight(" + world + ", " + light + ")");
        WorldEdits worldEdits = new WorldEdits();
        int result = debugSetWorldLight(world, light, worldEdits);
        deliverEvents(worldEdits);
        return result;
    }

    public int debugSetWorldLight( Vec3d world, int light, WorldEdits worldEdits ) {

        log.info("debugSetWorldLight(" + world + ", " + light + ")");

        if( world.y == 0 ) {
            log.warn("Cannot edit 'bedrock'");
            return -1;
        }

        ColumnId colId = ColumnId.fromWorld(world);
        if( log.isTraceEnabled() ) {
            log.trace("colId:" + colId + "  world:" + colId.getWorld(null));
        }
        ColumnData col = colDb.getColumn(colId);
        LightData leaf = col.getLightData((int)world.y);
        if( log.isTraceEnabled() ) {
            log.trace("leaf:" + leaf);
        }
        if( leaf == null ) {
            return -1;
        }
        if( log.isTraceEnabled() ) {
            log.trace("modifying:" + colId);
        }

        // Get the coordinate in 'cell space', ie: with the fractional parts chopped off
        int x = Coordinates.worldToCell(world.x);
        int y = Coordinates.worldToCell(world.y);
        int z = Coordinates.worldToCell(world.z);

        // And move them into "column space" which is relative to this
        // column's origin
        Vec3i origin = colId.getWorld(null);
        int cx = x - origin.x;
        int cy = y - origin.y; // should be a no-op
        int cz = z - origin.z;

        // Step 1: See if we need to change the cell
        ColumnNeighborhood data = new ColumnNeighborhood(colDb, col, worldEdits);
        int originalValue = data.getLight(cx, cy, cz, -1);
        data.setLight(cx, cy, cz, light);

        return light;
    }

    public void deliverEvents( WorldEdits worldEdits ) {

        // Push the column changes back to the DB
        for( ColumnData cd : worldEdits.getModifiedColumns() ) {
            // Make sure the version is incremented
            cd.getVersion().markChanged();

            // And
            colDb.markChanged(cd);
        }

        // Notify the leaf listeners
        for( LeafId id : worldEdits.getModifiedLeafIds() ) {
            // Lookup the column so we can get the version
            DataVersion version = worldEdits.getColumnData(id).getVersion();
            if( log.isTraceEnabled() ) {
                log.trace("fireLeafChanged(" + id + ")  leaf loc:" + id.getWorld(null));
            }
            // 2022-01-16 - note that there is a slight bug in how we detect
            // changes that will miss some relevant lighting updates.
            // If we add a block at cell 31 of some leaf against a wall in
            // the next leaf (theoretical cell 32) then we properly
            // detect the change in it and its neighbor (because the neighbor's
            // mask changes..  We also detect the new shadow casting all the way
            // down in that leaf and the ones below it.  However, the shadow
            // won't actually render below the leaf because we didn't send updates
            // for the lower neighbor leaf... and that's what actually renders
            // the shading in this 'sheer wall' example.
            // This is a solvable problem but not one I want to tackle today.
            // Off the top of my head, additional "am I a border" checks in
            // ColumnNeighborhood's markChanged(light) could also mark the
            // neighbor as changed even if it hasn't really changed.  I kind
            // of want to wait until that is smarter about detecting real updates.
            // Adding a bug to the task list and leaving this edge-case for
            // future-Paul to deal with.  T000537

            leafListeners.fireLeafChanged(id, version.getVersion(), false);
        }

        // Notify the cell change listeners
        for( CellChangeEvent event : worldEdits.createCellChangeEvents() ) {
            fireCellChanged(event);
        }
    }

    protected boolean lightPropagationChanged( BlockType oldType, BlockType newType ) {
        if( oldType == newType ) {
            return false;
        }

        boolean oldCheck, newCheck;
        oldCheck = oldType == null ? true : oldType.isTransparent();
        newCheck = newType == null ? true : newType.isTransparent();
        if( log.isTraceEnabled() ) {
            log.trace("old is transparent:" + oldCheck + "  new:" + newCheck);
        }
        if( oldCheck && newCheck ) {
            // need to check further for groups, directional transparency, etc.
            // but we'll temporarily assume 'true'
            return true;
        } else if( oldCheck != newCheck ) {
            // One is transparent and the other isn't... light propagation has changed
            return true;
        }

        oldCheck = oldType == null ? false : oldType.isSolid();
        newCheck = newType == null ? false : newType.isSolid();
        if( log.isTraceEnabled() ) {
            log.trace("old is solid:" + oldCheck + "  new:" + newCheck);
        }
        if( oldCheck != newCheck ) {
            // Lighting might have changed could compare boundary shapes
            // and such, too.
            return true;
        }

        return false;
    }

    @Override
    public int getWorldCell( Vec3d world ) {
        ColumnId colId = ColumnId.fromWorld(world);
        ColumnData col = colDb.getColumn(colId);
        LeafData leaf = col.getLeafData((int)world.y);
        if( leaf == null ) {
            return -1;
        }
        int x = Coordinates.worldToCell(world.x) - leaf.getInfo().location.x;
        int y = Coordinates.worldToCell(world.y) - leaf.getInfo().location.y;
        int z = Coordinates.worldToCell(world.z) - leaf.getInfo().location.z;
        return leaf.getCell(x, y, z);
    }

    @Override
    public LeafData getWorldLeaf( Vec3d worldLocation ) {
        return getLeaf(LeafId.fromWorld(worldLocation));
    }

    @Override
    public LeafData getLeaf( LeafId leafId ) {
        ColumnId colId = leafId.getColumnId();
        ColumnData col = colDb.getColumn(colId);
        // Kind of inefficient just to get 'y'
        Vec3i world = leafId.getWorld(null);
        return col == null ? null : col.getLeafData(world.y);
    }

    @Override
    public LightData getLight( LeafId leafId ) {
        ColumnId colId = leafId.getColumnId();
        ColumnData col = colDb.getColumn(colId);
        // Kind of inefficient just to get 'y'
        Vec3i world = leafId.getWorld(null);
        return col == null ? null : col.getLightData(world.y);
    }

    @Override
    public FluidData getFluid( LeafId leafId ) {
        ColumnId colId = leafId.getColumnId();
        ColumnData col = colDb.getColumn(colId);
        // Kind of inefficient just to get 'y'
        Vec3i world = leafId.getWorld(null);
        return col == null ? null : col.getFluidData(world.y);
    }

    @Override
    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res ) {
        return terrainImageManager ==  null ? null : terrainImageManager.getTerrainImage(id, type, res);
    }

    @Override
    public TreeLayer getTrees( TileId id, Resolution res ) {
        // Right now go directly to the tile... because there is no tree manager.
        Tile tile = tileManager.getTile(id, res);
        return tile.get(TreeLayer.class);
    }

    @Override
    public PointCloudLayer getPointCloudLayer( TileId id, Resolution res ) {
        return pointCloudManager == null ? null : pointCloudManager.getPointCloud(id, res);
    }

    @Override
    public void addTileListener( TileListener l ) {
        // When terrain image manager says the tile has changed then
        // it's a different type of change than if the point cloud manager
        // says.  We have to listen to both... but we someday might choose
        // to intercept them with our own listener before dispatching them.
        if( terrainImageManager != null ) {
            terrainImageManager.addTileListener(l);
        }
        if( pointCloudManager != null ) {
            pointCloudManager.addTileListener(l);
        }
    }

    @Override
    public void removeTileListener( TileListener l ) {
        if( terrainImageManager != null ) {
            terrainImageManager.addTileListener(l);
        }
        if( pointCloudManager != null ) {
            pointCloudManager.removeTileListener(l);
        }
    }

    // Hopefully temporary but useful in debugging lighting issues
    public void recalculateLighting( ColumnId colId ) {
        ColumnData col = colDb.getColumn(colId);

        LeafData[] leafs = col.getLeafs();
        LightData[] light = col.getLighting();
        int size = leafs.length;
        boolean lit = true;

        // Note: this brute-force method does not correctly send
        // lighting change events because it misses the initial sun
        // settting and the initial "resetLighting" call because the
        // WorldEdits is created later.  Fixing this is non-trivial and this
        // method is more-or-less a 'fix bugs' function.

        // From the top down, any empty leafs we'll mark the light as sunlight
        // until we reach the first non-empty leaf... then everything else will
        // be cleared to fully black.
        int clearValue = LightUtils.DIRECT_SUN;
        for( int i = size-1; i >= 0; i-- ) {
            if( lit ) {
                // While we're lit from the top, keeping going
                // until the first non-empty leaf
                if( !leafs[i].isEmpty() ) {
                    lit = false;
                    clearValue = LightUtils.SOLID;
                }
            }
            light[i].clear(clearValue);
        }

        // We do the above because it will make resetLighting a lot faster
        // because it can completely ignore the blocks that are fully filled
        // with sunlight already.

        CellDataStack blocks = new CellDataStack(LeafInfo.SIZE, col.getLeafs());
        CellDataStack lighting = new CellDataStack(LeafId.SIZE, col.getLighting());

        long start = System.nanoTime();
        LightUtils.resetLighting(LightUtils.DIRECT_SUN, blocks, lighting,
                                0, 0, 0, LeafId.SIZE, lighting.getMaxY(), LeafId.SIZE);
        long end = System.nanoTime();
        log.info(String.format("reset lighting in: %.02f ms", ((end - start)/1000000.0)));

        // From the top, find the first LeafData we encounter that is not
        // completely empty.
        int top;
        for( top = leafs.length-1; top >= 0; top-- ) {
            if( !leafs[top].isEmpty() ) {
                break;
            }
        }
        int yTop = top * LeafId.SIZE + 32;
        if( log.isTraceEnabled() ) {
            log.trace("Highest y value:" + yTop);
        }

        WorldEdits worldEdits = new WorldEdits();
        ColumnNeighborhood cellData = new ColumnNeighborhood(colDb, col, worldEdits);
        CellData lightData = ColumnLightData.loadNeighborhood(colDb, col, true);

        // 2022-03-26 - something I notice today as I'm copying it from my scripts as
        // that we won't propagate light into the leaf data above yTop... this will matter
        // when we're trying to light objects but doesn't really matter right now.
        LightUtils.recalculateLighting(cellData, lightData, 0, 0, 0, LeafId.SIZE, yTop, LeafId.SIZE);

        lightData = cellData.getLightingCellData();

        int count = LightUtils.propagateBorders(cellData, lightData, 0, 0, 0, LeafId.SIZE, col.getCeiling(), LeafId.SIZE);

        for( ColumnData it : worldEdits.getModifiedColumns() ) {
            if( log.isTraceEnabled() ) {
                log.trace("Changed:"  + it.getColumnId());
            }
            colDb.markChanged(it);
        }
        colDb.markChanged(col);

        if( log.isTraceEnabled() ) {
            log.trace("Post iterations:" + count);
        }

        // Recalculate the fluids, too...
        FluidUtils.calculateSideMasks(cellData.getFluidCellData(), cellData,
                                      0, 0, 0,
                                      LeafInfo.SIZE, 256, LeafInfo.SIZE);
        FluidUtils.calculateFluidSlopes(cellData.getFluidCellData(), cellData,
                                      0, 0, 0,
                                      LeafInfo.SIZE, 256, LeafInfo.SIZE);

        // Note: I don't think this is sending out change events.
        // 2023-05-14: Now it is.
        deliverEvents(worldEdits);
    }
}
