/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mworld.TileId;

/**
 *  Encapsulates information about a change to a particular type of
 *  tile data.
 *
 *  @author    Paul Speed
 */
public class TileChangeEvent {
    static Logger log = LoggerFactory.getLogger(TileChangeEvent.class);

    // Note: if feels like class is not good enough because in cases like
    // TerrainImage we won't know if it's terrain type or fluid type... but
    // in practice, those data managers are firing events based on columns
    // being dirty and themselves won't know the difference either.  We
    // also don't know until we regenerate the images whether or not there
    // will be terrain changes, fluid changes, or both.
    private Class dataType;
    private TileId tileId;
    private long dataVersion;
    private Resolution resolution;

    public TileChangeEvent( Class dataType, TileId tileId, long dataVersion ) {
        this(dataType, tileId, dataVersion, Resolution.High);
    }

    public TileChangeEvent( Class dataType, TileId tileId, long dataVersion, Resolution resolution ) {
        this.dataType = dataType;
        this.tileId = tileId;
        this.dataVersion = dataVersion;
        this.resolution = resolution;
    }

    public Class getDataType() {
        return dataType;
    }

    public TileId getTileId() {
        return tileId;
    }

    public long getDataVersion() {
        return dataVersion;
    }

    public Resolution getResolution() {
        return resolution;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("dataType", dataType)
            .add("tileId", tileId)
            .add("dataVersion", dataVersion)
            .add("resolution", resolution)
            .toString();
    }
}


