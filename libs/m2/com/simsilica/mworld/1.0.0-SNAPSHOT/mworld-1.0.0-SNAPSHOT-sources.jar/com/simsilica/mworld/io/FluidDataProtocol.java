/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *
 *
 *  @author    Paul Speed
 */
public class FluidDataProtocol implements ObjectProtocol<FluidData> {
    private int protocolVersion = 1;

    // We use this just for the RLE stuff.
    private CellArrayProtocol cellProtocol = new CellArrayProtocol();

    public FluidDataProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }

    @Override
    public void write( FluidData fluidData, BitOutputStream out ) throws IOException {
        // Assumes any necessary protocol version information was already written

        assert fluidData.checkCounts();

        // Even though the version is redundant in our actual use-case,
        // it improves the flexibility of this class and maybe provides a bit
        // of error detection if we go ahead and write it out for every object.
        // It also means that we could technically have different protocol
        // versions per leaf if we ever need it for some dumb reason.
        // I mean, technically the fluid ID is redundant, too.
        // We support up to 256 versions... beyond that the protocol
        // will have to adapt to read another byte.
        out.writeBits(protocolVersion, 8);

        // ID is all the location information that we need
        out.writeLongBits(fluidData.getLeafId().getId(), 64);

        // FluidData doesn't have a version yet... neither does LeafData
        // and I need to think more deeply about whether we need it.
        // Use a placeholder for now so we can add it later if we want to
        out.writeLongBits(-1, 64);

        out.writeBits(fluidData.getEmptyCellCount(), 16); // 1 bit more than we need, actually.

        int[] array = fluidData.getArray();
        if( array == null ) {
            // Write a null marker
            out.writeBits(0, 1);
            return;
        }
        // Write a not nul marker
        out.writeBits(1, 1);

        // Write the fluid data... we'll separate the parts into layers
        // to improve RLE performance

        // Fluid type
        cellProtocol.writeRleData(array, FluidUtils.TYPE_MASK, 0, 5, out);

        // Levels
        cellProtocol.writeRleData(array, FluidUtils.LEVEL_MASK, 5, 4, out);

        // We'll support the other bits in the future

        // Side masks
        cellProtocol.writeRleData(array, FluidUtils.SIDE_MASK, 26, 6, out);

        // Connect masks
        cellProtocol.writeRleData(array, FluidUtils.CONNECT_MASK, FluidUtils.CONNECT_MASK_SHIFT, 4, out);

        // Probably temporary but corner levels
        cellProtocol.writeRleData(array, FluidUtils.SLOPE_MASK, FluidUtils.SLOPE_MASK_SHIFT, 12, out);
    }

    @Override
    public FluidData read( BitInputStream in ) throws IOException {

        // Read the protocol version that was used to store the data
        int version = in.readBits(8);

        // Read the LeafInfo
        LeafId leafId = new LeafId(in.readLongBits(64));

        long dataVersion = in.readLongBits(64);

        // Read the cell data
        int emptyCellCount = in.readBits(16);

        int nullBit = in.readBits(1);
        if( nullBit == 0 ) {
            return new FluidData(leafId, null, emptyCellCount);
        }

        CellArray cells = new CellArray(LeafId.SIZE);

        // Fluid type
        cellProtocol.readRleData(cells.getArray(), FluidUtils.TYPE_MASK, 0, 5, in);

        // Levels
        cellProtocol.readRleData(cells.getArray(), FluidUtils.LEVEL_MASK, 5, 4, in);

        // We'll support the other bits in the future

        // Side masks
        cellProtocol.readRleData(cells.getArray(), FluidUtils.SIDE_MASK, 26, 6, in);

        // Connect masks
        cellProtocol.readRleData(cells.getArray(), FluidUtils.CONNECT_MASK, FluidUtils.CONNECT_MASK_SHIFT, 4, in);

        // Probably temporary but corner levels
        cellProtocol.readRleData(cells.getArray(), FluidUtils.SLOPE_MASK, FluidUtils.SLOPE_MASK_SHIFT, 12, in);

        return new FluidData(leafId, cells, emptyCellCount);
    }

}


