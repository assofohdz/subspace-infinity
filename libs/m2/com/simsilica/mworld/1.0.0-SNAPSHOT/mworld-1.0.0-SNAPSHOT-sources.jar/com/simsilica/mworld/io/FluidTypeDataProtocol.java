/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.mathd.*;

import com.simsilica.ethereal.io.*;

import com.simsilica.mblock.*;
import com.simsilica.mblock.io.*;
import com.simsilica.mworld.*;


/**
 *  A thin wrapper around regular FluidTypeData read/write to
 *  make it compatible with ObjectProtocol.
 *
 *  @author    Paul Speed
 */
public class FluidTypeDataProtocol implements ObjectProtocol<FluidTypeData> {
    private int protocolVersion = 1;

    public FluidTypeDataProtocol() {
    }

    @Override
    public int getProtocolVersion() {
        return protocolVersion;
    }

    @Override
    public void write( FluidTypeData data, BitOutputStream out ) throws IOException {
        // Unfortunately a lot of shuffling to make this happen because
        // we don't have bit stream/output stream wrapper
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        try {
            FluidTypeData.store(data, bOut);
        } finally {
            bOut.close();
        }
        byte[] bytes = bOut.toByteArray();
        out.writeBits(bytes.length, 32);
        for( byte b : bOut.toByteArray() ) {
            out.writeBits(b, 8);
        }        
    }

    @Override
    public FluidTypeData read( BitInputStream in ) throws IOException {
        int size = in.readBits(32);
        byte[] bytes = new byte[size];
        for( int i = 0; i < size; i++ ) {
            bytes[i] = (byte)in.readBits(8);
        }
        FluidTypeData data = FluidTypeData.load(new ByteArrayInputStream(bytes));
        return data; 
    }

}


