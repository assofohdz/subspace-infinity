/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.pc;

import java.util.*;

import org.slf4j.*;

import com.google.common.base.MoreObjects;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.Resolution;


/**
 *
 *
 *  @author    Paul Speed
 */
public class PointCloudLayer {
    static Logger log = LoggerFactory.getLogger(PointCloudLayer.class);

    private static int COLUMN_SIZE = WorldGrids.LEAF_SIZE;

    private TileId tileId;
    private Resolution resolution;
    private DataVersion version;

    private Map<Short, PointCloudData> index = new HashMap<>();

    public PointCloudLayer( TileId tileId, DataVersion version, Resolution resolution ) {
        this.tileId = tileId;
        this.version = version;
        this.resolution = resolution;
    }

    public Resolution getResolution() {
        return resolution;
    }

    public TileId getTileId() {
        return tileId;
    }

    public DataVersion getVersion() {
        return version;
    }

    public void updatePointCloud( PointCloudData cloud ) {
        short indexId = ColumnId.toTileLocalIndexId(cloud.getOriginX() / ColumnId.SIZE,
                                                    cloud.getOriginZ() / ColumnId.SIZE);
        index.put(indexId, cloud);
    }

    public PointCloudData getPointCloud( ColumnId id ) {
        TileId tileId = id.getTileId();
        if( !Objects.equals(tileId, getTileId()) ) {
            throw new IllegalArgumentException("Column is not in this tile:" + id + ", tile:" + getTileId());
        }
        int localId = id.getTileLocalIndexId();
        return index.get(localId);
    }

    public Collection<PointCloudData> getPointClouds() {
        return index.values();
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass().getSimpleName())
            .add("tileId", tileId)
            .add("resolution", resolution)
            .add("version", version)
            .toString();
    }
}
