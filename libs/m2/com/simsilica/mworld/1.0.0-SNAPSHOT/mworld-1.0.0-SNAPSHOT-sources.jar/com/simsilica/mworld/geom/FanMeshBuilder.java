/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.geom;

import java.util.*;

import org.slf4j.*;

import com.jme3.scene.*;

import com.simsilica.mblock.geom.ColliderlessMesh;

/**
 *  Given a configured set of parameters, this will generate fan
 *  meshes of certain truncation and spacing.  These fans are purpose-built
 *  for the far terrain algorithms where vertex coordinates directly map
 *  to "texture" coordinates and normals, y, etc. are calculated in shader.
 *
 *  By default, the factory will create a 512 radius fan centered at
 *  512, 512 with some default spacing.
 *
 *  The mesh will be generated as triangulated circles starting at the 'near'
 *  radius and working outwards to the 'far' radius.  'minStep' and 'growthFactor'
 *  control how the the radius of the circles grows as it moves outwards.
 *  'radials' controls the number of triangles in each circle (radials * 2)
 *
 *  @author    Paul Speed
 */
public class FanMeshBuilder {
    static Logger log = LoggerFactory.getLogger(FanMeshBuilder.class);

    private int xCenter = 512;
    private int zCenter = 512;
    private int near = 0;
    private int far = 512;
    private int radials = 1440;
    private double minStep = 1;
    private double growthFactor = 1;
    private double skirtSize = 0;
    private boolean includeNormals = false;

    public FanMeshBuilder() {
    }

    /**
     *  Sets the center coordinate from which the radials will be projected.
     */
    public FanMeshBuilder center( int xCenter, int zCenter ) {
        this.xCenter = xCenter;
        this.zCenter = zCenter;
        return this;
    }

    public FanMeshBuilder near( int near ) {
        this.near = near;
        return this;
    }

    public FanMeshBuilder far( int far ) {
        this.far = far;
        return this;
    }

    public FanMeshBuilder radials( int radials ) {
        this.radials = radials;
        return this;
    }

    public FanMeshBuilder minStep( double minStep ) {
        this.minStep = minStep;
        return this;
    }

    public FanMeshBuilder growthFactor( double growthFactor ) {
        this.growthFactor = growthFactor;
        return this;
    }

    /**
     *  For non-zero skirt sizes and non-zero near radiuses, this controls
     *  the size of the geometric skirt that will be dropped down from the
     *  near edge.
     */
    public FanMeshBuilder skirtSize( double skirtSize ) {
        this.skirtSize = skirtSize;
        return this;
    }

    /**
     *  May be useful for non-terrain applications and/or debugging.
     */
    public FanMeshBuilder includeNormals( boolean f ) {
        this.includeNormals = f;
        return this;
    }

    public ColliderlessMesh build() {
        ColliderlessMesh mesh = new ColliderlessMesh("fan[" + near + ":" + far + "]", false);
        mesh.setMode(Mesh.Mode.Triangles);
        //mesh.setMode(Mesh.Mode.TriangleStrip);
        // Triangles first and then we'll try strips.
        // FIXME: switch to triangle strips to save index buffer sizes.

        // We won't share the start/end seam since eventually we'll be
        // generating separate wedges anyway.

        // Figure out the distance steps that we want based on the
        // radials.  Basically, we want the next loop to be roughly
        // the same distance from the previous loop as the radials are
        // at that distance.

        // We want the loops of the fan to grow at the same rate as the
        // distance between the radials.  I at first thought that the distance
        // would be the sine of the radial angle... but that's not right.
        // The sine is based on a right triangle but the wedges aren't
        // right triangles.  Off the top of my head, I forget the formula
        // for chord length.  But google knows:
        //  The formula for the chord length is: 2rsin(theta/2) where r is
        //  the radius of the circle and theta is the angle from the centre
        //  of the circle to the two points of the chord.
        // Which is what I'd locally derived since if we bisect the wedge (theta/2)
        // then the problem IS based on right triangles and then add them back
        // together.
        double wedgeAngle = 1.0/radials * Math.PI * 2;
        double growth = Math.sin(wedgeAngle * 0.5) * 2 * growthFactor;

        List<Double> distances = new ArrayList<>();
        distances.add((double)near);
        for( double d = near; d < far; ) {
            // Exponential function
            d += Math.max(minStep, (growth * d));
            distances.add(Math.min(d, far));
        }

        if( log.isTraceEnabled() ) {
            log.trace("Distances count:" + distances.size());
            for( Double d : distances ) {
                log.trace(" d:" + d);
            }
        }

        // For each radial (with one extra for the final edge) and each
        // distance, there will be one vertex.
        int rings = distances.size();
        if( skirtSize > 0 && near > 0 ) {
            rings++;
        }
        int verts = (radials + 1) * rings;

        float[] fv = new float[verts * 3];
        float[] fn = includeNormals ? new float[verts * 3] : null;
        int vIndex = 0;
        int nIndex = 0;
        int vertNum = 0;

        if( skirtSize > 0 && near > 0 ) {
            // Include an extra inner ring
            Double d = distances.get(0);
            for( int r = 0; r <= radials; r++ ) {

                double a = (double)r/radials * Math.PI * 2;
                double x1 = xCenter + Math.cos(a) * d;
                double z1 = zCenter + Math.sin(a) * d;

                fv[vIndex++] = (float)x1;
                fv[vIndex++] = (float)-skirtSize;
                fv[vIndex++] = (float)z1;

                if( includeNormals ) {
                    fn[nIndex++] = (float)0;
                    fn[nIndex++] = (float)1;
                    fn[nIndex++] = (float)0;
                }
            }
        }

        for( Double d : distances ) {
            for( int r = 0; r <= radials; r++ ) {

                double a = (double)r/radials * Math.PI * 2;
                double x1 = xCenter + Math.cos(a) * d;
                double z1 = zCenter + Math.sin(a) * d;

                fv[vIndex++] = (float)x1;
                fv[vIndex++] = (float)0;
                fv[vIndex++] = (float)z1;

                if( includeNormals ) {
                    fn[nIndex++] = (float)0;
                    fn[nIndex++] = (float)1;
                    fn[nIndex++] = (float)0;
                }
            }
        }

        // Even though it's a fan, it's built like a regular grid.
        // It's just wrapped around a center and the side edges meet
        // at a seam.
        int quads = radials * (rings-1);
        int[] ib = new int[quads * 2 * 3];
        int index = 0;
        int ringStart = 0;
        int ringSize = radials + 1; // number of verts in each ring
        for( int i = 1; i < rings; i++ ) {
            for( int r = 0; r < radials; r++ ) {
                // Near left
                ib[index++] = ringStart + r;
                // near right
                ib[index++] = ringStart + r + 1;
                // far right
                ib[index++] = ringStart + ringSize + r + 1;

                // near left
                ib[index++] = ringStart + r;
                // far right
                ib[index++] = ringStart + ringSize + r + 1;
                // far left
                ib[index++] = ringStart + ringSize + r;
            }

            ringStart += ringSize;
        }

        mesh.setBuffer(VertexBuffer.Type.Position, 3, fv);
        if( includeNormals ) {
            mesh.setBuffer(VertexBuffer.Type.Normal, 3, fn);
        }
        mesh.setBuffer(VertexBuffer.Type.Index, 3, ib);
        mesh.updateBound();
        mesh.setStatic();

        return mesh;
    }
}
/*
    // doesn't belong here but it's good enough for now.
    // Generates a big giant grid.  I'm keeping it around because it
    // uses TriangleStrip and the way the fan meshes are setup, TriangleStrip
    // indexes will work for them, too.
    public Mesh generateFlatMesh( int width, int height ) {

        Mesh mesh = new Mesh();
        mesh.setMode(Mesh.Mode.TriangleStrip);

        int w = width;
        int h = height;

        float[] fv = new float[w * h * 3];
        float[] fn = new float[w * h * 3];
        int vIndex = 0;
        int nIndex = 0;
        for( int y = 0; y < h; y++ ) {
            for( int x = 0; x < w; x++ ) {

                fv[vIndex++] = (float)x;
                fv[vIndex++] = (float)0;
                fv[vIndex++] = (float)y;

                fn[nIndex++] = (float)0;
                fn[nIndex++] = (float)1;
                fn[nIndex++] = (float)0;
            }
        }

        // Build an index buffer for a triangle strip.  The first three
        // start a triangle and then the next joins the previous two, and so on.
        // So the pattern has to go something like:
        // 1-3-5-7
        // |\|\|\|
        // 0-2-4-6
        //
        // Of flip it for counter-clockwise initial winding:
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7
        //
        // To start the next row there has to be some degenerate triangles
        // enough so we can start over with a counter-clockwise winding on the
        // next row.  So I think if we do the last vertex again then that's
        // a counter-clockwise
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               cc
        //
        // Then a vertex at the 'home' of the second row
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               678:cc 789:c
        // 9
        // No, because we need one more degenerate triangle to get down
        // to the third row before we can start making triangles again.
        // We'd have to put 10 there also then drop down to the next row
        // for 11... which I guess is counter-clockwise so 10, 11, 12 would
        // be...  Wait:
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7.8               678:cc 789:c
        // 9.A C                 89A:cc 9AB:c        4 degenerate
        // |  /                  ABC:cc... correct.
        // B - D
        // Yeah, so 10, 11, 12 is setup to be cc again.
        // Note: we waste fewer triangles per row if we alternate patterns, I think.
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7                   678=degen cc
        // E-C-A-8
        // |\|\|\|  cc\c cc\c cc\c
        // F-D-B-9
        //                  789=degen c  ...and so we're still off by one flip
        // 0-2-4-6
        // |/|/|/|  cc/c cc/c cc/c
        // 1-3-5-7                   678=degen cc
        // F-D-B-8.9                   789=degen c
        // |\|\|\|  cc\c cc\c cc\c     89A=dege cc  9AB = c  3 degenerate
        // G-E-C-A
        //
        // one fewer per row for more complexity... smaller degen triangles, though.
        //
        // So each row takes width * 2 indexes plus one extra.
        // ie: we end row one on 7 but add 9 also.  That gives us the 678 degenerate
        // triangle.
        // Row 2 adds 9 which gives us the second 789 degenerate triangle.
        // then it adds A which gives us the third 89A...then we are back on cycle.
        // But note that each 'row' in this cases is actually straddling two rows
        // of vertexes... so we need one less in the buffer in the end.
        int[] ib = new int[(w * 2 + 1) * (h-1)];
        int index = 0;

        for( int row = 0; row < h-1; row++ ) {
            if( (row % 2) == 0 ) {
                // Even rows
                // Top version is for x-right, z-up style winding. ie: if we let
                // x go 0 to 1024 and z go 0 to 1024 then it will face down and not up.
                //for( int col = w-1; col >= 0; col-- ) {
                for( int col = 0; col < w; col++ ) {
                    ib[index++] = col + row * w;
                    ib[index++] = col + (row + 1) * w;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            } else {
                // Odd rows
                for( int col = w-1; col >= 0; col-- ) {
                //for( int col = 0; col < w; col++ ) {
                    ib[index++] = col + row * w;
                    ib[index++] = col + (row + 1) * w;
                }
                // Add the extra makeup point
                ib[index] = ib[index-1];
                index++;
            }
        }

        mesh.setBuffer(VertexBuffer.Type.Position, 3, fv);
        mesh.setBuffer(VertexBuffer.Type.Normal, 3, fn);
        mesh.setBuffer(VertexBuffer.Type.Index, 1, ib);
        mesh.updateBound();
        mesh.setStatic();

        return mesh;
    }

}*/
