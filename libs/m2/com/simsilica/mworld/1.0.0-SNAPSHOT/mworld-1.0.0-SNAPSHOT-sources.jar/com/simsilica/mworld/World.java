/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import com.simsilica.mathd.*;

import com.simsilica.mworld.tile.*;
import com.simsilica.mworld.tile.pc.PointCloudLayer;
import com.simsilica.mworld.tile.tree.TreeLayer;

/**
 *
 *
 *  @author    Paul Speed
 */
public interface World {

    public int setWorldCell( Vec3d world, int cellType );
    public int getWorldCell( Vec3d world );

    default int getWorldLight( Vec3d world ) {
        LeafId id = LeafId.fromWorld(world);
        LightData leaf = getLight(id);
        if( leaf == null ) {
            return -1;
        }
        Vec3i origin = id.getWorld(null);
        int x = Coordinates.worldToCell(world.x) - origin.x;
        int y = Coordinates.worldToCell(world.y) - origin.y;
        int z = Coordinates.worldToCell(world.z) - origin.z;
        return leaf.getCell(x, y, z);
    }

    public int getMaxY();

    public LeafData getWorldLeaf( Vec3d worldLocation );
    public LeafData getLeaf( LeafId leafId );
    public LightData getLight( LeafId leafId );
    public FluidData getFluid( LeafId leafId );

    public TerrainImage getTerrainImage( TileId id, TerrainImageType type, Resolution res );
    public TreeLayer getTrees( TileId id, Resolution res );
    public PointCloudLayer getPointCloudLayer( TileId id, Resolution res );

    public void addTileListener( TileListener l );
    public void removeTileListener( TileListener l );

    public void addColumnChangeListener( ColumnChangeListener l );
    public void removeColumnChangeListener( ColumnChangeListener l );

    public void addLeafChangeListener( LeafChangeListener l );
    public void removeLeafChangeListener( LeafChangeListener l );

    public void addCellChangeListener( CellChangeListener l );
    public void removeCellChangeListener( CellChangeListener l );
}
