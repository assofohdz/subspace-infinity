/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import com.google.common.base.*;

/**
 *  A general interface for any object providing 'database' 
 *  with specific instance semantics, where for a given key
 *  there will only be one value instance at a time.  Any implementations
 *  of ObjectDb will ensure that as long as some caller is still referencing
 *  the value instance that further requests for that key will return the
 *  same value instance.  This provides consistent locking and update
 *  semantics across threads.
 *
 *  @author    Paul Speed
 */
public interface ObjectDb<K, V> {
    
    public void initialize();
    
    public void terminate();

    /**
     *  Returns the value for the specified key.  The value may be
     *  different instances from one call to the next for any specific
     *  key but if any part of the application is holding that value
     *  instance then further calls for the same key are guaranteed to return
     *  the same == value instance.      
     */
    public V get( K key );
    
    /**
     *  Indicates that the specified value has changed and the database
     *  should store its specific implementation.  The object may be
     *  pushed to persistence immediately or at a later time but calls
     *  to get() for the same key are guaranteed to return the modified
     *  version of the object. 
     */
    public void update( K key, V value );
}


