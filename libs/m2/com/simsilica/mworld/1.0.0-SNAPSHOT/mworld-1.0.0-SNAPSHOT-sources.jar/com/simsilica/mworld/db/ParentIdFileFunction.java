/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.io.File;
import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.mathd.Grid;
import com.simsilica.mathd.Vec3i;

import com.simsilica.mworld.GridBasedId;

/**
 *  A function that provides a File for an ID based on its
 *  parent cell.  parentCell.y/parentCell.x/parentCell.z/id.extension
 *
 *  @author    Paul Speed
 */
public class ParentIdFileFunction<T extends GridBasedId> implements Function<T, File> {
    static Logger log = LoggerFactory.getLogger(ParentIdFileFunction.class);

    private File root;
    private String extension;

    public ParentIdFileFunction( File root, String extension ) {
        this.root = root;
        if( extension.charAt(0) == '.' ) {
            extension = extension.substring(1);
        }
        this.extension = extension;
    }

    public File apply( GridBasedId id ) {
        Vec3i world = id.getWorld(null);
        Vec3i parentCell = id.getParentGrid().worldToCell(world.toVec3d());
        File dir = new File(root, parentCell.y + "/" + parentCell.x + "/" + parentCell.z);
        if( !dir.exists() ) {
            dir.mkdirs();
        }
        return new File(dir, id.getId() + "." + extension);
    }
}


