/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.io.File;

import org.slf4j.*;

import com.google.common.base.Function;

import com.simsilica.mathd.Grid;
import com.simsilica.mathd.Vec3i;

/**
 *  Translates a long grid cell ID into a file name.
 *
 *  @author    Paul Speed
 */
public class GridCellFileFunction implements Function<Long, File> {
    static Logger log = LoggerFactory.getLogger(GridCellFileFunction.class);

    private File root;
    private Grid grid;
    private int shift;
    private String extension;
    
    public GridCellFileFunction( File root, Grid grid, int shift, String extension ) {
        this.root = root;
        this.grid = grid;
        this.shift = shift;
        if( extension.charAt(0) == '.' ) {
            extension = extension.substring(1);
        }
        this.extension = extension;
    }
    
    public File apply( Long id ) {
        Vec3i cell = grid.idToCell(id);
        File dir = new File(root, (cell.x >> shift) + "/" + (cell.z >> shift));
        if( !dir.exists() ) {
            dir.mkdirs();
        }
        return new File(dir, id + "." + extension);  
    }
}


