/*
 * $Id$
 *
 * Copyright (c) 2018, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.io;

import java.io.*;

import com.simsilica.ethereal.io.BitInputStream;
import com.simsilica.ethereal.io.BitOutputStream;

import com.simsilica.mblock.CellArray;

/**
 *  Reads and writes CellData.
 *
 *  @author    Paul Speed
 */
public class CellArrayProtocol {

    private int sizeBits;
    private int lengthBits;
    private int maxLength;

    public CellArrayProtocol() {
        this(8, 8);
    }

    public CellArrayProtocol( int sizeBits, int lengthBits ) {
        this.sizeBits = sizeBits;
        this.lengthBits = lengthBits;
        this.maxLength = (0x1 << lengthBits) - 1;
    }

    public static byte[] toBytes( CellArray array ) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            new CellArrayProtocol().write(array, out);
            out.close();
            return out.toByteArray();
        } catch( IOException e ) {
            throw new RuntimeException("Error converting cell array to bytes", e);
        }
    }

    public static CellArray fromBytes( byte[] array ) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(array);
            return new CellArrayProtocol().read(in);
        } catch( IOException e ) {
            throw new RuntimeException("Error converting bytes to cell array", e);
        }
    }

    public CellArray read( InputStream in ) throws IOException {
        BitInputStream bIn = new BitInputStream(in);
        int xSize = bIn.readBits(sizeBits);
        int ySize = bIn.readBits(sizeBits);
        int zSize = bIn.readBits(sizeBits);

        CellArray data = new CellArray(xSize, ySize, zSize);

        // Read the block types
        readRleData(data.getArray(), 0xffff, 0, 16, bIn);

        // Read the masks... together for now
        readRleData(data.getArray(), 0xffff0000, 16, 16, bIn);

        // To make sure the underlying stream is caught up to the nearest
        // byte, the writer wrote some extra bits... so we'll read this now.
        int marker = 0;
        while( (marker = bIn.readBits(1)) != 0 ) {
        }

        return data;
    }

    public long write( CellArray data, OutputStream out ) throws IOException {
        if( data == null ) {
            throw new IllegalArgumentException("Data cannot be null.");
        }
        BitOutputStream bOut = new BitOutputStream(out);

        long bitCount = 0;

        // Write the size
        bOut.writeBits(data.getSizeX(), sizeBits);
        bOut.writeBits(data.getSizeY(), sizeBits);
        bOut.writeBits(data.getSizeZ(), sizeBits);
        bitCount += (sizeBits * 3);

        // Here we could write info about how we've split the values up
        // but I'm hard-coding it for the moment.

        // We'll run length encode the lower 16 bits then the upper 16 bits.
        // Eventually we may want to split this into three or four separate
        // runs of even different bit sizes.  I can imagine light mask, dir mask,
        // water level, and block type for example.

        int[] array = data.getArray();

        // Write the block types... we give them the lower 16 bits for now
        bitCount += writeRleData(array, 0xffff, 0, 16, bOut);

        // Write out the masks.  We write them together for now.
        bitCount += writeRleData(array, 0xffff0000, 16, 16, bOut);

        // Fill up any pending bits so we end on an even byte
        // This is better than flushing because the read side will know
        // how to finish off reading in case we are reading a partial
        // stream.
        // Note: we write out even if the bitsLeft is 8 because we
        // need some indicator that there is no more real data... so we
        // will always write at least one extra byte, basically.
        // (So does BitOutputStream's flush, though)
        int bitsLeft = bOut.getPendingBits();
        for( ; bitsLeft > 1; bitsLeft-- ) {
            bOut.writeBits(1, 1);
            bitCount++;
        }
        bOut.writeBits(0, 1);
        bitCount++;

        return bitCount;
    }

    public long writeRleData( int[] array, int mask, int shift, int valueBits, BitOutputStream out ) throws IOException {

        long bitCount = 0;

        // Pass one, the block types
        int lastVal = (array[0] & mask) >> shift;
        int count = 0;
        for( int val : array ) {
            int part = (val & mask) >> shift;
            if( part == lastVal && count < maxLength ) {
                count++;
                continue;
            }

            // We've encoutered a new value or run out of count
            // space so we know how many of the previous one there were
            if( count == 1 ) {
                // No run length
                out.writeBits(0, 1);
                bitCount++;
            } else {
                // Write out the run length count
                out.writeBits(1, 1);
                bitCount++;
                out.writeBits(count, lengthBits);
                bitCount+=lengthBits;
            }
            out.writeBits(lastVal, valueBits);
            bitCount+=valueBits;
            lastVal = part;
            count = 1;
        }

        // Write the last value
        if( count == 1 ) {
            out.writeBits(0, 1);
            bitCount++;
        } else {
            out.writeBits(1, 1);
            bitCount++;
            out.writeBits(count, lengthBits);
            bitCount+=lengthBits;
        }
        out.writeBits(lastVal, valueBits);
        bitCount+=valueBits;

        return bitCount;
    }

    public void readRleData( int[] array, int mask, int shift, int valueBits, BitInputStream in ) throws IOException {

        int index = 0;
        int total = array.length;
        while( index < total ) {
            int length;
            int marker = in.readBits(1);
            if( marker == 0 ) {
                // Single entry
                length = 1;
            } else {
                // Need to read the length
                length = in.readBits(lengthBits);
            }
            int val = (in.readBits(valueBits) << shift) & mask;
            for( int i = 0; i < length; i++ ) {
                int original = array[index];
                array[index] = original | val;
                index++;
            }
        }
    }
}


