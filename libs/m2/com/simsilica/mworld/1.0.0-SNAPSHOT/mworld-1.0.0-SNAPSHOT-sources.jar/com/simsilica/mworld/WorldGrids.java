/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld;

import com.simsilica.mathd.Grid;

/**
 *  Centralized constants for the different grids that divide the
 *  world.  At the lowest level there is LEAF_GRID which is wrapped
 *  by the stacks of leaf data COLUMN_GRID.  The TILE_GRID then wraps
 *  that with 1024x1024 grid cells.
 *
 *  @author    Paul Speed
 */
public class WorldGrids {

    public static final int LEAF_SIZE = LeafInfo.SIZE;
    public static final int TILE_SIZE = 1024; 
    public static final int OCTTILE_SIZE = 1024 * 8; 
    public static final int SEDECTTILE_SIZE = 1024 * 16; 
 
    // Default bits are fine here.  21 bits for each component is
    // +/-1048576 cells which is +/- 33,554,432 meters.
    // Because this is the primary limiter in all world coordinate-based grid IDs,
    // it is not necessary to fiddle with the bit sizes for the other large scale
    // grids because their x/z will already be similarly constrained to LEAF_GRID's
    // max world size.  They end up having way more bits than needed in all directions.    
    public static Grid LEAF_GRID = new Grid(LeafInfo.SIZE, LeafInfo.SIZE, LeafInfo.SIZE);
    
    // In order to allow world layers, the large grid based columns will include 
    // a Y spacing.  I got back and forth here between creating a value big enough
    // that any reasonable world would fit and using 1024 which is the only reasonable
    // column height.  Since in most implementations, columns are loaded in full
    // height all the time, and since currently the worlds I have max at 640, the
    // 'bitness' in order to hold all of that is 1024... which would be 32 leafs high.
    // ...still within the realm of loading all at once.  The benefit to slicing
    // the worlds off at 1024 is that an implementation could use this to support taller
    // worlds by managing two column layers at a time.  If the grids are set with y spacing
    // larger then that wouldn't be possible.
    // It just means that apps need to be careful not to fly above 1024 in their own
    // worlds or to limit their world queries in that case... unless switching to a 
    // different set of columns is desired.
    public static Grid COLUMN_GRID = new Grid(LeafInfo.SIZE, TILE_SIZE, LeafInfo.SIZE);
    public static Grid TILE_GRID = new Grid(TILE_SIZE, TILE_SIZE, TILE_SIZE); 
    public static Grid OCTILE_GRID = new Grid(OCTTILE_SIZE * 8, TILE_SIZE, OCTTILE_SIZE * 8); 
    public static Grid SEDECTILE_GRID = new Grid(SEDECTTILE_SIZE, TILE_SIZE, SEDECTTILE_SIZE); 

}
