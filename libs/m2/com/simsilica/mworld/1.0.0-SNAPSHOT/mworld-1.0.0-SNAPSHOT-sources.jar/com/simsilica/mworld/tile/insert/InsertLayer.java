/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.Tile;

/**
 *  A layer that keeps track of block data that should be directly
 *  inserted into a particular tile.
 *
 *  @author    Paul Speed
 */
public class InsertLayer {
    static Logger log = LoggerFactory.getLogger(InsertLayer.class);

    private static int COLUMN_SIZE = WorldGrids.LEAF_SIZE;

    private TileId tileId;
    private DataVersion version;
    
    // Initial generation may happen in several passes and
    // this lets us still know when the tile requires some generation.
    private byte generationLevel;
    
    private List<BlockInsert> insertList; // order matters
    private ListMultimap<Short, BlockInsert> binIndex;

    public InsertLayer( TileId tileId, DataVersion version ) {
        this(tileId, version, 0, new ArrayList<>());
    }

    public InsertLayer( TileId tileId, DataVersion version, int generationLevel, List<BlockInsert> insertList ) {
        this.tileId = tileId;
        this.version = version;
        this.generationLevel = (byte)generationLevel;
        this.insertList = insertList;
        this.binIndex = MultimapBuilder.hashKeys().arrayListValues().build();

        for( BlockInsert insert : insertList ) {
            indexInsert(insert);
        }
    }

    public TileId getTileId() {
        return tileId;
    }

    public DataVersion getVersion() {
        return version;
    }

    public void setGenerationLevel( int generationLevel ) {
        if( this.generationLevel > generationLevel ) {
            throw new IllegalArgumentException("Generation level cannot go backwards.");
        }
        this.generationLevel = (byte)generationLevel;
    }

    public int getGenerationLevel() {
        return generationLevel;
    }
    
    public List<BlockInsert> getInserts() {
        return insertList;
    }
    
    public boolean intersectsExisting( BlockInsert insert ) {
        if( insert == null ) {
            throw new IllegalArgumentException("Insert cannot be null");
        }
        // We could check intersecting bins to be faster but for
        // now we'll be slower.
        // FIXME: use grid check instead of brute force iteration.
        for( BlockInsert other : insertList ) {
            if( insert.intersects(other) ) {
                return true;
            }
        }
        return false;
    }

    public Set<Short> getActiveBinIds() {
        return binIndex.keySet();
    }

    protected boolean indexInsert( BlockInsert insert ) {
        boolean hit = false;
        for( Short s : insert.getAffectedColumns(tileId) ) {
            binIndex.put(s, insert);
            hit = true;
        }
        return hit;
    }

    public boolean addInsert( BlockInsert insert ) {
        if( indexInsert(insert) ) {
            insertList.add(insert);
            return true;
        }
        log.warn("Insert:" + insert + " did not hit any columns in:" + tileId + "(" + tileId.getWorld(null) + ")");
        return false;
    }

    public Iterable<BlockInsert> getInserts( ColumnId columnId ) {
        short binId = columnId.getTileLocalIndexId();
        return binIndex.get(binId);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[tileId:" + tileId + ", version:" + version + ", size:" + insertList.size() + "]";
    }
}

