/*
 * $Id$
 *
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.insert;

import java.util.function.Function;

import org.slf4j.*;

import com.simsilica.mathd.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.*;

/**
 *  Carves the InsertLayer BlockInserts into a column.
 *
 *  @author    Paul Speed
 */
public class InsertColumnProcessor implements TileColumnProcessor {
    static Logger log = LoggerFactory.getLogger(InsertColumnProcessor.class);

    private static int LEAF_SIZE = WorldGrids.LEAF_SIZE;

    public static final int INSERT_BITS = CellGenType.Insert.apply(0);

    private Function<BlockDataId, BlockData> blocksFunction;
    private IntCombiner blockMerge;
    private IntCombiner fluidMerge;

    public InsertColumnProcessor( Function<BlockDataId, BlockData> blocksFunction ) {
        this(blocksFunction, null, null);
    }

    public InsertColumnProcessor( Function<BlockDataId, BlockData> blocksFunction,
                                  IntCombiner blockMerge,
                                  IntCombiner fluidMerge ) {
        this.blocksFunction = blocksFunction;
        this.blockMerge = blockMerge;
        this.fluidMerge = fluidMerge;
    }

    @Override
    public boolean apply( ColumnData colData, Tile tile ) {
        ColumnId columnId = colData.getColumnId();
        InsertLayer insertLayer = tile.get(InsertLayer.class);
        if( insertLayer == null ) {
            return false;
        }

        Vec3i origin = columnId.getWorld(null);
        LeafData[] leafs = colData.getLeafs();
        FluidData[] fluids = colData.getFluid();
        int yStop = leafs.length * LEAF_SIZE;

        boolean changed = false;
        for( BlockInsert insert : insertLayer.getInserts(columnId) ) {
            try {
                BlockData blocks = blocksFunction.apply(insert.blockDataId);
                if( blocks == null ) {
                    log.warn("No block data found for:" + insert);
                    continue;
                }
                int carveFlags = insert.carveFlags;
                boolean carveBelow = (carveFlags & BlockInsert.CARVE_BELOW) != 0;
                boolean carveInner = (carveFlags & BlockInsert.CARVE_INNER) != 0;
                boolean carveAbove = (carveFlags & BlockInsert.CARVE_ABOVE) != 0;
                boolean extendDown = (carveFlags & BlockInsert.CARVE_EXTEND_DOWN) != 0;
                boolean extendUp = (carveFlags & BlockInsert.CARVE_EXTEND_UP) != 0;

//log.info("carve below:" + carveBelow + " inner:" + carveInner + " above:" + carveAbove
//             + " extend down:" + extendDown + "  up:" + extendUp);

//log.info("insert:" + insert + "  blocks:" + blocks);
                CellArray cells = blocks.getCells();
                CellArray fluid = blocks.getFluid();

                // CellUtils won't clamp for us so we will need to do it
                int xMin = insert.world.x - origin.x;
                int yMin = insert.world.y;
                int zMin = insert.world.z - origin.z;

                int xMax = xMin + insert.xSize;
                int yMax = yMin + insert.ySize;
                int zMax = zMin + insert.zSize;

                int xSource = 0;
                int zSource = 0;

                if( xMin < 0 ) {
                    xSource -= xMin;
                    xMin = 0;
                }
                if( zMin < 0 ) {
                    zSource -= zMin;
                    zMin = 0;
                }
                xMax = Math.min(xMax, LEAF_SIZE);
                zMax = Math.min(zMax, LEAF_SIZE);

                int xSize = xMax - xMin;
                int ySize = yMax - yMin;
                int zSize = zMax - zMin;

                int minLayer = yMin / LEAF_SIZE;
                int maxLayer = (yMax - 1) / LEAF_SIZE;
                if( maxLayer >= leafs.length ) {
                    log.warn("Insert:" + insert + " exceeds maximum world height:" + yMax);
                    maxLayer = leafs.length - 1; 
                }

                // Do the copying ourselves to better support the carve features
                // ...plus it's bound to be a little faster
                for( int i = 0; i < xSize; i++ ) {
                    for( int k = 0; k < zSize; k++ ) {
    
                        // Find the bottom-most non-empty block
                        int yBottom = -1;
                        int baseType = 0;
                        int topType = 0;
                        if( carveBelow || carveInner ) {
                            for( int y = 0; y < ySize; y++ ) {
                                int type = cells.getCell(xSource + i, y, zSource + k);
                                if( type != 0 ) {
                                    yBottom = y;
                                    break;
                                }
                            }
                            if( extendDown ) {
                                baseType = yBottom == -1 ? 0 : cells.getCell(xSource + i, 0, zSource + k);
                            }
                            if( extendUp ) {
                                topType = yBottom == -1 ? 0 : cells.getCell(xSource + i, ySize - 1, zSource + k);
                            }
                        } else {
                            if( extendDown ) {
                                baseType = cells.getCell(xSource + i, 0, zSource + k);
                            }
                            if( extendUp ) {
                                topType = cells.getCell(xSource + i, ySize - 1, zSource + k);
                            }
                        }
                        if( yBottom == -1 ) {
                            // Skip this column because we don't carve out anything
                            // for empty columns right now.
                            continue;
                        }

                        int yTop = -1;
                        if( carveInner || carveAbove ) {
                            if( yBottom >= 0 && yBottom < ySize ) {
                                // Find the top-most non-empty block
                                for( int y = ySize - 1; y >= 0; y-- ) {
                                    int type = cells.getCell(xSource + i, y, zSource + k);
                                    if( type != 0 ) {
                                        yTop = y;
                                        break;
                                    }
                                }
                            }
                        }
//log.info("carve range[" + (xSource + i) + "][" + (zSource + k) + "] bottom:" + yBottom + " top:" + yTop);

                        boolean copyEmpty = carveBelow && yBottom > 0;
                        int emptyType = extendDown ? baseType : 0;

                        for( int layer = minLayer; layer <= maxLayer; layer++ ) {
                            LeafData leafData = leafs[layer];
                            FluidData fluidData = null;
                            if( fluid != null ) {
                                fluidData = fluids[layer];
                            }
    
                            int yLayer = layer * LEAF_SIZE;
                            int ySource = 0;
    
                            int yTarget = yMin - yLayer;
                            if( yTarget < 0 ) {
                                ySource -= yTarget;
                                yTarget = 0;
                            }
                            int localMax = Math.min(yMax - yLayer, LEAF_SIZE);
                            int yLocalSize = localMax - yTarget;

                            for( int j = 0; j < yLocalSize; j++ ) {
                                int y = ySource + j;
                                int type = cells.getCell(xSource + i, y, zSource + k, 0);
                                int fType = fluid == null ? 0 : fluid.getCell(xSource + i, y, zSource + k, 0);
                                if( type == 0 && fType == 0 && !copyEmpty ) {
                                    continue;
                                }
                                if( y == yBottom ) {
                                    copyEmpty = carveInner;
                                    //emptyType = 0;
                                } else if( y == yTop ) {
                                    copyEmpty = carveAbove;
                                    //emptyType = extendUp ? topType : 0;
                                }
//log.info("  y:" + y + "  copyEmpty:" + copyEmpty + "  type:" + type);
                                //if( type == 0 ) {
                                //    type = emptyType;
                                //}
                                if( type == 0 ) {
                                    if( !copyEmpty ) {
                                        continue;
                                    }
                                } else {
                                    type = type | INSERT_BITS;
                                }
    
                                // Check the type combiner
                                // We gate on type because if type is 0 then our carving rules
                                // override the merge rules.
                                if( type != 0 && blockMerge != null ) {
                                    int existing = leafData.getCell(xMin + i, yTarget + j, zMin + k, 0);
                                    type = blockMerge.apply(existing, type);
                                }

                                leafData.setCell(xMin + i, yTarget + j, zMin + k, type);
    
                                if( fluid != null ) {
                                    int existing = fluidData.getCell(xMin + i, yTarget + j, zMin + k, 0);
                                    fluidData.setCell(xMin + i, yTarget + j, zMin + k, fType);
                                }
                            }
                        }
                    }
                }
            } catch( RuntimeException e ) {
                log.info("Error processing insert:" + insert, e);
            }
        }

        return changed;
    }


//    @Override
//    public boolean apply( ColumnData colData, Tile tile ) {
//        ColumnId columnId = colData.getColumnId();
//        InsertLayer insertLayer = tile.get(InsertLayer.class);
//        if( insertLayer == null ) {
//            return false;
//        }
//
//        Vec3i origin = columnId.getWorld(null);
//        int yStop = colData.getLeafs().length * LEAF_SIZE;
//
//        boolean changed = false;
//        for( BlockInsert insert : insertLayer.getInserts(columnId) ) {
//            BlockData blocks = blocksFunction.apply(insert.blockDataId);
//            if( blocks == null ) {
//                log.warn("No block data found for:" + insert);
//                continue;
//            }
//            int carveFlags = insert.carveFlags;
//            boolean inset = (carveFlags & BlockInsert.CARVE_INSET) != 0;
//            boolean inscribe = (carveFlags & BlockInsert.CARVE_INSCRIBE) != 0;
//            boolean extendUp = (carveFlags & BlockInsert.CARVE_EXTEND_UP) != 0;
//            boolean voidUp = (carveFlags & BlockInsert.CARVE_VOID_UP) != 0;
//            boolean extendDown = (carveFlags & BlockInsert.CARVE_EXTEND_DOWN) != 0;
//
////log.info("insert:" + insert + "  blocks:" + blocks);
//            CellArray cells = blocks.getCells();
//            CellArray fluid = blocks.getFluid();
//
//            // CellUtils won't clamp for us so we will need to do it
//            int xMin = insert.world.x - origin.x;
//            int yMin = insert.world.y;
//            int zMin = insert.world.z - origin.z;
//
//            int xMax = xMin + insert.xSize;
//            int yMax = yMin + cells.getSizeY();
//            int zMax = zMin + insert.zSize;
//
//            int xSource = 0;
//            int zSource = 0;
//
//            if( xMin < 0 ) {
//                xSource -= xMin;
//                xMin = 0;
//            }
//            if( zMin < 0 ) {
//                zSource -= zMin;
//                zMin = 0;
//            }
//            xMax = Math.min(xMax, LEAF_SIZE);
//            zMax = Math.min(zMax, LEAF_SIZE);
//
//            int xSize = xMax - xMin;
//            int zSize = zMax - zMin;
//
//            int minLayer = yMin / LEAF_SIZE;
//            int maxLayer = (yMax - 1) / LEAF_SIZE;
//
//            // Do the copying ourselves to better support the carve features
//            // ...plus it's bound to be a little faster
//            for( int i = 0; i < xSize; i++ ) {
//                for( int k = 0; k < zSize; k++ ) {
//                    int baseType = cells.getCell(xSource + i, 0, zSource + k);
//                    int baseFluid = fluid == null ? 0 : fluid.getCell(xSource + i, 0, zSource + k);
//                    boolean emptyBase = baseType == 0 && baseFluid == 0;
//                    boolean copyEmpty = inset || (inscribe && !emptyBase);
//                    //if( inscribe && baseType == 0 && baseFluid == 0 ) {
//                    //    // We don't want to clear blocks but we do want
//                    //    // to copy any real blocks over
//                    //    //continue;
//                    //    // But we'll only extend down baseType == 0 if we
//                    //    // are not inscriibed
//                    //}
//                    if( extendDown && (!emptyBase || copyEmpty) ) {
//                        // Not many better ways than a step-wise y check
//                        for( int y = yMin - 1; y >= 0; y-- ) {
//                            int layer = y / LEAF_SIZE;
//                            int j = y % LEAF_SIZE;
//                            LeafData leafData = colData.getLeafs()[layer];
//                            int existing = leafData.getCell(xMin + i, j, zMin + k, 0);
//                            if( existing != 0 ) {
//                                // We could actually still pass it through the type
//                                // combiner and check for == existing to decide.
//                                // Going to wait for a use-case... sorry future-Paul
//                                break;
//                            }
//                            leafData.setCell(xMin + i, j, zMin + k, baseType);
//                            if( fluid != null && baseFluid != 0 ) {
//                                FluidData fluidData = colData.getFluid()[layer];
//                                fluidData.setCell(xMin + i, j, zMin + k, baseFluid);
//                            }
//                        }
//                    }
//
//                    if( extendUp || voidUp ) {
//                        int yTop = cells.getSizeY() - 1;
//                        int topType = voidUp ? 0 : cells.getCell(xSource + i, yTop, zSource + k);
//                        int topFluid = voidUp ? 0 : fluid == null ? 0 : fluid.getCell(xSource + i, yTop, zSource + k);
//
//                        // Not many better ways than a step-wise y check
//                        for( int y = yMax; y < yStop; y++ ) {
//                            int layer = y / LEAF_SIZE;
//                            int j = y % LEAF_SIZE;
//                            LeafData leafData = colData.getLeafs()[layer];
//                            int existing = leafData.getCell(xMin + i, j, zMin + k, 0);
//                            if( existing == 0 ) {
//                                break;
//                            }
//                            leafData.setCell(xMin + i, j, zMin + k, topType);
//                            if( fluid != null && topFluid != 0 ) {
//                                FluidData fluidData = colData.getFluid()[layer];
//                                fluidData.setCell(xMin + i, j, zMin + k, topFluid);
//                            }
//
//                            if( y == yStop - 1 ) {
//                                log.warn("Somehow extended too far");
//                            }
//                        }
//                    }
//
//                    for( int layer = minLayer; layer <= maxLayer; layer++ ) {
//                        LeafData leafData = colData.getLeafs()[layer];
//                        FluidData fluidData = null;
//                        if( fluid != null ) {
//                            fluidData = colData.getFluid()[layer];
//                        }
//
//                        int yLayer = layer * LEAF_SIZE;
//                        int ySource = 0;
//
//                        int yTarget = yMin - yLayer;
//                        if( yTarget < 0 ) {
//                            ySource -= yTarget;
//                            yTarget = 0;
//                        }
//                        int localMax = Math.min(yMax - yLayer, LEAF_SIZE);
//                        int ySize = localMax - yTarget;
//
//                        for( int j = 0; j < ySize; j++ ) {
//                            int type = cells.getCell(xSource + i, ySource + j, zSource + k, 0);
//                            int fType = fluid == null ? 0 : fluid.getCell(xSource + i, ySource + j, zSource + k, 0);
//                            if( type == 0 && fType == 0 && !copyEmpty ) {
//                                continue;
//                            }
//                            if( inscribe ) {
//                                copyEmpty = true;
//                            }
//
//                            int existing = leafData.getCell(xMin + i, yTarget + j, zMin + k, 0);
//                            // Check the type combiner
//                            if( blockMerge != null ) {
//                                type = blockMerge.apply(existing, type);
//                            }
//
//                            leafData.setCell(xMin + i, yTarget + j, zMin + k, type);
//
//                            if( fluid != null ) {
//                                existing = fluidData.getCell(xMin + i, yTarget + j, zMin + k, 0);
//                                fluidData.setCell(xMin + i, yTarget + j, zMin + k, fType);
//                            }
//                        }
//                    }
//
//                }
//            }
//
//
//        }
//
//        return changed;
//    }
}


