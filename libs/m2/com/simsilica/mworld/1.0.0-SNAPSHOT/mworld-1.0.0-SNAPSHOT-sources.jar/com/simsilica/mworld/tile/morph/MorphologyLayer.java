/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.tile.morph;

import java.util.*;

import org.slf4j.*;

import com.google.common.collect.*;

import com.simsilica.mathd.*;

import com.simsilica.mworld.*;
import com.simsilica.mworld.tile.Tile;

/**
 *
 *
 *  @author    Paul Speed
 */
public class MorphologyLayer {
    static Logger log = LoggerFactory.getLogger(MorphologyLayer.class);

    private static int COLUMN_SIZE = WorldGrids.LEAF_SIZE;

    private TileId tileId;
    private DataVersion version;
    
    // Initial generation may happen in several passes and
    // this lets us still know when the tile requires some generation.
    private byte generationLevel;
    
    private List<Morphology> morphList; // order matters
    private ListMultimap<Short, Morphology> binIndex;

    public MorphologyLayer( TileId tileId, DataVersion version ) {
        this(tileId, version, 0, new ArrayList<>());
    }

    public MorphologyLayer( TileId tileId, DataVersion version, int generationLevel, List<Morphology> morphList ) {
        this.tileId = tileId;
        this.version = version;
        this.generationLevel = (byte)generationLevel;
        this.morphList = morphList;
        this.binIndex = MultimapBuilder.hashKeys().arrayListValues().build();

        for( Morphology m : morphList ) {
            indexMorphology(m);
        }
    }

    public TileId getTileId() {
        return tileId;
    }

    public DataVersion getVersion() {
        return version;
    }

    public void setGenerationLevel( int generationLevel ) {
        if( this.generationLevel > generationLevel ) {
            throw new IllegalArgumentException("Generation level cannot go backwards.");
        }
        this.generationLevel = (byte)generationLevel;
    }

    public int getGenerationLevel() {
        return generationLevel;
    }
    
    public List<Morphology> getMorphology() {
        return morphList;
    }
    
    public <T extends Morphology> boolean hasMorphology( Class<T> type ) {
        for( Morphology m : morphList ) {
            if( type.isInstance(m) ) {
                return true;
            }
        }
        return false;        
    }

    public Set<Short> getActiveBinIds() {
        return binIndex.keySet();
    }

    // Provided for some temporary searching because my morphology
    // layer is temporarily holding some buildings.
    public ListMultimap<Short, Morphology> getBinIndex() {
        return binIndex;
    }

    public boolean addMorphology( Morphology m ) {
        if( indexMorphology(m) ) {
            morphList.add(m);
            return true;
        }
        log.warn("Morphology:" + m + " did not hit any columns in:" + tileId + "(" + tileId.getWorld(null) + ")");
        return false;
    }

    protected boolean indexMorphology( Morphology m ) {
        boolean hit = false;
        for( Short s : m.getAffectedColumns(tileId) ) {
            binIndex.put(s, m);
            hit = true;
        }        
        return hit;
    }

    public boolean apply( Tile tile ) {

        Random rand = new  Random(tile.getTileId().getId());
        boolean changed = false;
        for( Morphology m : morphList ) {
            if( m.morph(tile, rand) ) {
                changed = true;
            }
        }

        return changed;
    }

    public boolean apply( ColumnData colData, Tile tile ) {
        Random rand = new  Random(colData.getColumnId().getId());

        short binId = colData.getColumnId().getTileLocalIndexId();

        boolean changed = false;
        for( Morphology m : binIndex.get(binId) ) {
            if( m.morph(colData, tile, rand) ) {
                changed = true;
            }
        }

        return changed;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[tileId:" + tileId + ", version:" + version + ", size:" + morphList.size() + "]";
    }
}
