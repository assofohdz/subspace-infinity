/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import org.slf4j.*;

import com.simsilica.mblock.*;
import com.simsilica.mworld.*;


/**
 *  A post processor that will initialize the lighting data structures
 *  and minimally propagate down the sunlight from the top, clearing
 *  all lighting data in the column as appropriate.
 *
 *  @author    Paul Speed
 */
public class InitialSunlightProcessor implements ColumnPostProcessor {

    static Logger log = LoggerFactory.getLogger(InitialSunlightProcessor.class);

    private PostProcColumnDb parent;
    private ColumnDb delegate;

    @Override
    public void initialize( PostProcColumnDb parent ) {
        this.parent = parent;
        this.delegate = parent.getDelegate();
    }

    @Override
    public void terminate() {
    }

    @Override
    public boolean postProcess( ColumnData col ) {
        //log.info("postProcess(" + col + ")");

        if( col.hasGenerationFlag(ColumnData.GEN_INITIAL_SUNLIGHT) ) {
            //log.info("already post processed");
            return false;
        }

        if( log.isTraceEnabled() ) {
            log.trace("postProcess(" + col + ")");
        }

        // Preprocess the light data so that leafs likely to be in full sun
        // are initialized to full sun and leafs likely to be partially dark
        // are marked fully dark.  99% of the stuff below ground will be fully
        // dark and so clearing the light arrays in this way is huge savings
        // because of the LightData short-circuiting that happens for fully
        // empty lights.
        // Note: we are really just pushing off a performance issue if there
        // are ever really deep holes in really high ground, etc.... because for
        // some reason LightData.setCell() is reasonably slow when faced with
        // clearing an entire column.  (32 x 32 x 672 = 688128 setcells in the
        // very worst case.  So taking a while is not strange.)
        LeafData[] leafs = col.getLeafs();
        LightData[] light = col.getLighting();
        int size = leafs.length;
        boolean lit = true;

        // From the top down, any empty leafs we'll mark the light as sunlight
        // until we reach the first non-empty leaf... then everything else will
        // be cleared to fully black.
        int clearValue = LightUtils.DIRECT_SUN;
        for( int i = size-1; i >= 0; i-- ) {
            if( lit ) {
                // While we're lit from the top, keeping going
                // until the first non-empty leaf
                if( !leafs[i].isEmpty() ) {
                    lit = false;
                    clearValue = LightUtils.SOLID;
                }
            }
            light[i].clear(clearValue);
        }

        //for( int i = 0; i < size; i++ ) {
        //    log.info("  col:" + col.getColumnId().getId() + "[" + i + "] isEmpty:" + leafs[i].isEmpty()
        //             + "  fully lit:" + light[i].isFullSun() + " fully dark:" + light[i].isSolidDark()
        //             + "  has light cells:" + (light[i].getRawCells() != null));
        //}

        CellDataStack blocks = new CellDataStack(LeafInfo.SIZE, col.getLeafs());
        CellDataStack lighting = new CellDataStack(LeafId.SIZE, col.getLighting());

        synchronized( col ) {
            long start = System.nanoTime();
            LightUtils.resetLighting(LightUtils.DIRECT_SUN, blocks, lighting,
                                    0, 0, 0, LeafId.SIZE, lighting.getMaxY(), LeafId.SIZE);
            long end = System.nanoTime();
            if( log.isTraceEnabled() ) {
                log.trace(String.format("reset lighting in: %.02f ms", ((end - start)/1000000.0)));
            }
        }

        //for( int i = 0; i < size; i++ ) {
        //    log.info("  after:" + col.getColumnId().getId() + "[" + i + "] isEmpty:" + leafs[i].isEmpty()
        //             + "  fully lit:" + light[i].isFullSun() + " fully dark:" + light[i].isSolidDark()
        //             + "  has light cells:" + (light[i].getRawCells() != null));
        //}

        //for( int i = 0; i < 32; i++ ) {
        //    //for( int j = 0; j < 32; j++ ) {
        //    int j = 31;
        //        for( int k = 0; k < 32; k++ ) {
        //            int val = light[0].getCell(i, 0, k);
        //            if( val != LightUtils.SOLID ) {
        //                log.info(" non-zero value:" + i + ", " + j + ", " + k + "  val:" + val);
        //            }
        //        }
        //    //}
        //}

        col.setGenerationFlag(ColumnData.GEN_INITIAL_SUNLIGHT);

        return true;
    }
}
