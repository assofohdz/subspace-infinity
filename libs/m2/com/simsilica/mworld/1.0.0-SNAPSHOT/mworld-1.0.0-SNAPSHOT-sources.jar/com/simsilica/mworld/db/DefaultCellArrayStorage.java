/*
 * $Id$
 * 
 * Copyright (c) 2022, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.db;

import java.io.*;
import java.util.*;
import java.util.concurrent.locks.*;

import org.slf4j.*;

import com.google.common.hash.*;
import com.google.common.io.Files;

import com.simsilica.mblock.*;
import com.simsilica.mblock.db.*;
import com.simsilica.mworld.io.CellArrayProtocol;


/**
 *  Stores CellArray objects and allows for later retrieval.
 *  This is different than a normal ObjectDb-style database because
 *  the ID is not know until storage time and we avoid duplicates
 *  wherever possible.  This implementation peforms no caching.
 *
 *  @author    Paul Speed
 */
public class DefaultCellArrayStorage implements CellArrayStorage {   
    static Logger log = LoggerFactory.getLogger(DefaultCellArrayStorage.class);

    // Note: these classes could have lived over in mblock if we
    // had put CellArrayProtocol over there.  And then mblock would
    // need a SimEthereal reference for the bitstream classes...
    // it gets messy.
    
    private File root;
    private HashFunction crc32 = Hashing.crc32();
        
    private ReadWriteLock lock = new ReentrantReadWriteLock();       
 
    public DefaultCellArrayStorage( File root ) {
        this.root = root;
    }

    protected File idToFile( long id ) {
        // No way to cache a preparsed format this way so we'll hope that
        // Java is going this efficiently.  We have formatting requirements
        // here that the regular CellArrayId.toFileName() does not.  Plus
        // we avoid creating at least one extra object and we never need to
        // to the other direction anyway.
        String name = String.format("%016x", id);
        
        // Try to spread them out a little in case there are a lot of them
        String prefix = name.charAt(0) + "" + name.charAt(1) + "/" + name.charAt(2) + "" + name.charAt(3);
        
        return new File(root, prefix + "/" + name + ".ca");
    }

    @Override    
    public CellArray apply( CellArrayId id ) {
        return get(id);
    }
    
    @Override
    public CellArray get( CellArrayId id ) {        
        File f = idToFile(id.getId());
        if( !f.exists() ) {
            return null;
        }
        lock.readLock().lock();
        try {
            return readCellArray(f);
        } catch( IOException e ) {
            throw new RuntimeException("Error loading:" + id, e);
        } finally {
            lock.readLock().unlock();
        }       
    }

    @Override
    public boolean exists( CellArrayId id ) {
        File f = idToFile(id.getId());
        return f.exists();
    }
 
    protected int sizeHash( CellArray array ) {
        // It doesn't matter if we retain all of the 
        // information... just as long as result is compact.
        // So we'll do whatever we can to fit it into 2 bytes.
        // ...5 bits per element.  We don't even care if they
        // overlap so we won't bother to mask them.
        // Subtract 1 so that we get a little more range.
        // size will never be 0 but it might be 32
        int x = array.getSizeX() - 1;
        int y = array.getSizeY() - 1;
        int z = array.getSizeZ() - 1;
        // Since we have a bit left over from 5,5,5 we'll
        // give y a little extra space by moving z up an
        // extra bit.
        // Actually, we use only 15 bits now so that we can
        // give an extra bit to the base ID part and avoid
        // the sign bit.
        int result = x | (y << 5) | (z << 10);
        return result & 0xffff;       
    }
 
    protected long calculateBaseId( byte[] bytes, CellArray array ) {
        HashCode hash = crc32.hashBytes(bytes);
        
        // Use a long here in case sizeHash() returns something with the 16th
        // bit set... else when we << 16 later it will sign extend and fill
        // all of the high bits.  We'd prefer not. 
        long sizeHash = sizeHash(array);
 
        // Using the upper 6 bytes leaves us 2 bytes for collision
        // increments (actually more depending on how we calculate it).
        // For example, if we increment the 16 bits then we can have
        // 65536 collisions before we start colliding with size hashes.
        // And that just has a reduced collision space, we can still
        // increment into them and test hits.  Collisions are already
        // pretty ugly and we hope they don't happen often.
        long hashId = hash.asInt() & 0xffffffffL;
        // Don't extend into the sign bit because it makes parsing harder
        // and we don't really need the bit.
        // Use xor instead of or just in case sizeHash extends up into
        // the hashId bitspace. xor will keep some randomness where 
        // or will eventually homogenize.
        long baseId = (hashId << 31) ^ (sizeHash << 16);

        //log.info("hash:" + hash + " int:" + Long.toHexString(hashId) + "  sizeHash:" + String.format("%x", sizeHash) + "  binary:" + Integer.toBinaryString(sizeHash));
        //log.info("BaseID:" + Long.toHexString(baseId));
        
        return baseId;
    }
  
    @Override   
    public CellArrayId store( CellArray array ) {
 
        assert array.getSizeX() != 0;
        assert array.getSizeY() != 0;
        assert array.getSizeZ() != 0;
        
        // Need to generate an ID and to do that we will need bytes
        byte[] bytes = CellArrayProtocol.toBytes(array);
        
        CellArray test = CellArrayProtocol.fromBytes(bytes);
       
        //log.info("start:" + array + "  reload:" + test);
        assert Objects.equals(test.getSize(), array.getSize());

        // Calculate the initial baseId that we hope doesn't 
        // collide with anything
        long baseId = calculateBaseId(bytes, array);
        
        // So far, all of the above is 100% independent of DB state.
        // Because of the nature of how our IDs are generated then we
        // should also be able to try to lookup any existing CellArray bytes,
        // look up the file, etc..  But to avoid trying to read a file being
        // partially written then we'd have to juggle read locks and write locks.
        // Since the caller has the expectation that they are writing something
        // then we might as well grab the write lock
        lock.writeLock().lock();
        try {        
            // We'll also go ahead and wrap the collision logic into
            // the lower level store method
            long actualId = storeBytes(baseId, bytes);
            
            //File testFile = idToFile(actualId);
            //log.info("reloading:" + testFile);
            //test = readCellArray(testFile);
            //log.info("start:" + array + "  reload:" + test);
            
            return new CellArrayId(actualId);
        } catch( IOException e ) {
            throw new RuntimeException("Error storing cells:" + array, e);
        } finally {
            lock.writeLock().unlock();
        }        
    }
    
    protected void logBytes( byte[] bytes ) {
        StringBuilder sb = new StringBuilder();
        for( int i = 0; i < bytes.length; i++ ) {
            if( i > 0 && (i %32) == 0 ) {
                sb.append("\n");
            } else if( i > 0 ) {
                sb.append(" ");
            }
            sb.append(String.format("%x", bytes[i]));
        }
        log.info(sb.toString()); 
    }
    
    protected long storeBytes( long baseId, byte[] bytes ) throws IOException {
        long result = baseId;

        //log.info(String.format("storeBytes(%x)", baseId) + " length:" + bytes.length);
        //logBytes(bytes);

        // I feel the need to at least track it... waiting until int wraps
        // around means we can try 2,147,483,648 times.  Which is probably too
        // many but the algorithm is a bit unpredictable... so we will log
        // overflow milestones and hope for the best.
        int attempts = 0;
        while( attempts >= 0 ) {
            File f = idToFile(result);
            if( !f.exists() ) {
                File dir = f.getParentFile(); 
                if( !dir.exists() ) {
                    log.info("Making dirs:" + dir);
                    dir.mkdirs();
                }
                log.info("Writing:" + f + "  length:" + bytes.length);
                // Then we are clear to just write it
                Files.write(bytes, f);
                return result;
            }
            
            // Check this file to see if it's actually the same as us
            // ie: a dupe and not a collision
            byte[] existing = Files.toByteArray(f);
            if( Arrays.equals(bytes, existing) ) {
                log.info("array already stored:" + f + "  length:" + existing.length);
                // Nothing to store... baseId is fine.
                return result;
            }
            log.info(String.format("collision:%x", result));
            
            // Try the next one
            result++;
        }
        
        // If we fell out then things are very base
        throw new IOException("Exceeded maximum collisions for content ID:" + baseId); 
    }
    
    protected CellArray readCellArray( File f ) throws IOException {
        byte[] test = Files.toByteArray(f);
        //log.info("file:" + f + "  bytes:" + test.length);
        //logBytes(test);
        return CellArrayProtocol.fromBytes(test);
    }
}


