/*
 * $Id$
 *
 * Copyright (c) 2020, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.mworld.view;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.function.Function;

import org.slf4j.*;

import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.BaseAppState;
import com.jme3.bounding.BoundingBox;
import com.jme3.material.*;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.*;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.*;
import com.jme3.texture.*;
import com.jme3.texture.image.ColorSpace;
import com.jme3.util.BufferUtils;

import com.simsilica.lemur.LayerComparator;
import com.simsilica.lemur.core.VersionedHolder;
import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;
import com.simsilica.mathd.*;
import com.simsilica.sim.Blackboard;
import com.simsilica.state.BlackboardState;
import com.simsilica.thread.*;

import com.simsilica.mworld.ColumnId;
import com.simsilica.mworld.DataVersion;
import com.simsilica.mworld.TileId;
import com.simsilica.mworld.World;
import com.simsilica.mworld.geom.*;
import com.simsilica.mworld.tile.Resolution;
import com.simsilica.mworld.tile.TileChangeEvent;
import com.simsilica.mworld.tile.TerrainImage;
import com.simsilica.mworld.tile.TerrainImageType;
import com.simsilica.mworld.tile.TileListener;

/**
 *
 *
 *  @author    Paul Speed
 */
public class TerrainState extends BaseAppState {

    static Logger log = LoggerFactory.getLogger(TerrainState.class);

    private Node root = new Node("terrainRoot");
    private JobState workers;
    private JobState priorityWorkers;
    private Blackboard blackboard;

    private World world;

    private Vector2f mediumTerrainOffset = new Vector2f();
    private Vector2f farTerrainOffset = new Vector2f();

    private Geometry test;
    private Vector3f original;

    private VersionedReference<Vec3d> posRef;

    private Texture emptyTexture;

    private HiresLayer hiresLayer;

    private HiresLayer waterLayer;

    private ViewMask viewMask;
    private VersionedReference<Vec3i> maskCenter;

    private int radials = 720 * 2;
    //private int radials = 1440;
    //private int radials = 360;
    private boolean wireframe = false;
    private byte[] fill = new byte[] { (byte)0, (byte)0, (byte)0, (byte)0 };

    private boolean lightingEnabled = true;

    private FogSettings fogSettings;
    private VersionedReference<FogSettings> fogSettingsRef;

    private boolean waterEnabled = true;

    // The fun thing is that when we switch to "NEW_WAY" in the terrain
    // frag shader that things get more blinky unless we use fewer triangles
    // in the fan mesh.  It seems like growth is still good but pushing out
    // the minStep seems to make things more uniform somehow.
    private double minStep = 1; //0.1;
    private double growth = 1;

    private VersionedHolder<Integer> triangleCount = new VersionedHolder<>();

    // True if the camera never moves in xz space, false if it moves within its grid cell.
    // In the long run, this is not as flexible as it needs to be but it will work today.
    private boolean xzLockedCamera = false;

    // Turn this on to have cell edges outlined
    private boolean cellDebug = false;

    private Function<TerrainImageType, Material> materialFactory;

    private float horizontalLimit = 0.9f; //86f;
    private float verticalLimit = 0.99f;

    private int basicPriorityLevel = 200;
    private int highPriorityLevel = 100;

    public TerrainState() {
        this(false);
    }

    public TerrainState( Blackboard blackboard ) {
        this(false);
        this.blackboard = blackboard;
    }

    public TerrainState( boolean xzLockedCamera ) {
        setEnabled(true);
        this.xzLockedCamera = xzLockedCamera;
    }

    public int getBasicPriorityLevel() {
        return basicPriorityLevel;
    }

    public int getHighPriorityLevel() {
        return highPriorityLevel;
    }

    public void setPriorityLevels( int basicPriorityLevel, int highPriorityLevel ) {
        this.basicPriorityLevel = basicPriorityLevel;
        this.highPriorityLevel = highPriorityLevel;
    }

    /**
     *  Returns the distance from the current position to the closest edge
     *  on the grid.  Everything within this radius will be rendered.  Some
     *  things outside of the radius may also be rendered but not in all directions.
     */
    public double getVisualRadius() {
        Vec3d pos = posRef.get().clone();
        return hiresLayer.getVisualRadius(pos);
    }

    public double getNearestBlankDistance() {
        Vec3d pos = posRef.get().clone();
        pos.y = 0;
        double min1 = hiresLayer.getNearestBlankDistance(pos);
        if( min1 == 0 ) {
            return 0;
        }
        double min2 = waterLayer.getNearestBlankDistance(pos);
        return Math.min(min1, min2);
    }

    public void setMaterialFactory( Function<TerrainImageType, Material> materialFactory ) {
        this.materialFactory = materialFactory;
        if( hiresLayer != null ) {
            hiresLayer.updateMaterial(materialFactory);
            waterLayer.updateMaterial(materialFactory);
        }
    }

    public Function<TerrainImageType, Material> getMaterialFactory() {
        return materialFactory;
    }

    public void setXzLockedCamera( boolean f ) {
        this.xzLockedCamera = f;
    }

    public boolean isXzLockedCamera() {
        return xzLockedCamera;
    }

    public void setCellDebug( boolean f ) {
        this.cellDebug = f;
    }

    public boolean getCellDebug() {
        return cellDebug;
    }

    public VersionedReference<Integer> getTriangleCount() {
        return triangleCount.createReference();
    }

    public void setWaterEnabled( boolean waterEnabled ) {
        if( this.waterEnabled == waterEnabled ) {
            return;
        }
        this.waterEnabled = waterEnabled;
        if( waterLayer != null ) {
            waterLayer.setEnabled(waterEnabled);
        }
    }

    public boolean isWaterEnabled() {
        return waterEnabled;
    }

    public void setLightingEnabled( boolean lightingEnabled ) {
        if( this.lightingEnabled == lightingEnabled ) {
            return;
        }
        this.lightingEnabled = lightingEnabled;
        hiresLayer.setLightingEnabled(lightingEnabled);
        waterLayer.setLightingEnabled(lightingEnabled);
    }

    public boolean isLightingEnabled() {
        return lightingEnabled;
    }

    public void setFogSettings( FogSettings fogSettings ) {
        this.fogSettings = fogSettings;
        fogSettingsRef = fogSettings == null ? null : fogSettings.createReference();
        resetFog();
    }

    public FogSettings getFogSettings() {
        return fogSettings;
    }

    protected int getFogDistance() {
        return fogSettings == null ? 0 : fogSettings.getFogDistance();
    }

    protected void resetFog() {
        if( root != null ) {
            updateFogDistance(root, getFogDistance(), -1);
        }
    }

    public static void updateFogDistance( Spatial s, final float distance, final float clipDistance ) {
        // Sort of a hack because #defines can't changed with material parameter
        // overrides.
        // FIXME: find a better way to globally manage material defines like these
        // ...or fix JME to deal with material parameter overrides properly when
        // wired to #defines.
        s.depthFirstTraversal(new SceneGraphVisitorAdapter() {
                @Override
                public void visit( Geometry geom ) {
                    Material mat = geom.getMaterial();
                    if( mat.getParam("UseFog") == null ) {
                        return;
                    }
                    if( distance > 0 ) {
                        mat.setBoolean("UseFog", true);
                        mat.setFloat("ExpFog", 1/distance);
                    } else {
                        mat.setBoolean("UseFog", false);
                    }
                    if( clipDistance >= 0 && mat.getParam("ClipDistance") != null ) {
                        // Also set the clip distance
                        mat.setFloat("ClipDistance", clipDistance);
                    }
                }
            });
    }

    public void setWireframe( boolean wireframe ) {
        if( this.wireframe == wireframe ) {
            return;
        }
        this.wireframe = wireframe;
        if( hiresLayer != null ) {
            hiresLayer.setWireframe(wireframe);
            waterLayer.setWireframe(wireframe);
        }
    }

    public boolean getWireframe() {
        return wireframe;
    }

    public void setHorizontalLimit( float limit ) {
        if( this.horizontalLimit == limit ) {
            return;
        }
        this.horizontalLimit = limit;
        if( hiresLayer != null ) {
            hiresLayer.setUpnessRange(horizontalLimit, verticalLimit);
            waterLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
    }

    public float getHorizontalLimit() {
        return horizontalLimit;
    }

    public void setVerticalLimit( float limit ) {
        if( this.verticalLimit == limit ) {
            return;
        }
        this.verticalLimit = limit;
        if( hiresLayer != null ) {
            hiresLayer.setUpnessRange(horizontalLimit, verticalLimit);
            waterLayer.setUpnessRange(horizontalLimit, verticalLimit);
        }
    }

    public float getVerticalLimit() {
        return verticalLimit;
    }

    public void setRadials( int radials ) {
        if( this.radials == radials ) {
            return;
        }
        this.radials = radials;
        regenerateGeometry();
    }

    public int getRadials() {
        return radials;
    }

    public void setMinStep( double minStep ) {
        if( this.minStep == minStep ) {
            return;
        }
        this.minStep = minStep;
        regenerateGeometry();
    }

    public double getMinStep() {
        return minStep;
    }

    public void setGrowth( double growth ) {
        if( this.growth == growth ) {
            return;
        }
        this.growth = growth;
        regenerateGeometry();
    }

    public double getGrowth() {
        return growth;
    }

    protected int getTotalTriangleCount() {
        int result = hiresLayer.getTriangleCount();
        if( waterEnabled ) {
            result += waterLayer.getTriangleCount();
        }
        return result;
    }

    protected void regenerateGeometry() {
        hiresLayer.setRadials(radials);
        hiresLayer.setMinStep(minStep);
        hiresLayer.setGrowth(growth);

        waterLayer.setRadials(radials/2);
        waterLayer.setMinStep(minStep); // * 10);
        waterLayer.setGrowth(growth * 10);

        hiresLayer.regenerateMesh();
        waterLayer.regenerateMesh();

        triangleCount.setObject(getTotalTriangleCount());
    }

    protected void setViewMask( ViewMask viewMask ) {
        this.viewMask = viewMask;
        this.maskCenter = viewMask.createReference();

        // It's possible that we get called before the layers
        // have been setup if viewMask was already set before this
        // app state was initialized.
        if( hiresLayer != null ) {
            hiresLayer.updateViewMask();
            waterLayer.updateViewMask();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void initialize( Application app ) {

        if( blackboard == null ) {
            blackboard = getState(BlackboardState.class, true).getBlackboard();
        }
        this.world = blackboard.get(World.class);

        // If something sets a view mask then we'll use it.
        blackboard.onInitialize(ViewMask.class, (ViewMask mask) -> { setViewMask(mask); });
        blackboard.onInitialize(FogSettings.class, (FogSettings fogSettings) -> { setFogSettings(fogSettings); });

        workers = getState("regularWorkers", JobState.class);
        if( workers == null ) {
            // Try something
            workers = getState(JobState.class, true);
        }
        priorityWorkers = getState("priorityWorkers", JobState.class);
        if( priorityWorkers == null ) {
            priorityWorkers = getState(JobState.class, true);
        }
        emptyTexture = createEmptyTexture();

        // FIXME: give blackboard a better casting pattern to avoid requiring warning suppression
        posRef = ((VersionedObject<Vec3d>)blackboard.get("position")).createReference();

        // If no material material factory is defined then set one up
        if( getMaterialFactory() == null ) {
            log.warn("No material factory configured.  Using a default coloredTerrainMaterial()");
            //ColorRGBA color = new ColorRGBA(0.15f, 0.3f, 0.1f, 1.0f);
            ColorRGBA groundColor = new ColorRGBA(0.15f, 0.25f, 0.1f, 1.0f);
            ColorRGBA waterColor = new ColorRGBA(107/255f, 141/255f, 217/255f, 0.9f); //0.8f);

            setMaterialFactory(MaterialFactories.coloredTerrainMaterial(getApplication(),
                                                                        groundColor, waterColor));
        }

        hiresLayer = new HiresLayer(TerrainImageType.Terrain, radials, minStep, growth);

        waterLayer = new HiresLayer(TerrainImageType.Fluid, radials/2, minStep, growth * 10);
        if( !waterEnabled ) {
            waterLayer.setEnabled(waterEnabled);
        }
        // The tops of fluid blocks like water are actually rendered below their
        // actual value.  So y=128 for water would actually be y=127.9 or so.  This
        // in contrast to terrain blocks which would be rendered right at y=128.
        // So we'll offset the water layer down slightly to account for this.
        waterLayer.setSpatialOffset(-0.25f);

        triangleCount.setObject(getTotalTriangleCount());
    }

    private Texture createTexture( TerrainImage terrain ) {
        System.out.println("Creating texture for:" + terrain);

        int imageSize = 1024;
        ByteBuffer data = BufferUtils.createByteBuffer(imageSize * imageSize * 4);
        writeTileToImage(terrain, data, 0, 0);

        Image image = new Image(Image.Format.ARGB8, imageSize, imageSize, data, ColorSpace.Linear);
        Texture texture = new Texture2D(image);
        // If we turn filtering to 'nearest' then it seems like things get a lot
        // more 'blinky' when moving around and the center moves.
        //texture.setMagFilter(Texture.MagFilter.Nearest);
        //texture.setMagFilter(Texture.MagFilter.Bilinear);
        // What we really want is elevation to be based on a filtered value
        // but coloring to be based on nearest.

        return texture;
    }

    private Texture createEmptyTexture() {
        int imageSize = 1;
        ByteBuffer data = BufferUtils.createByteBuffer(imageSize * imageSize * 4);
        Image image = new Image(Image.Format.ARGB8, imageSize, imageSize, data, ColorSpace.Linear);
        Texture texture = new Texture2D(image);
        return texture;
    }

    private void fill( ByteBuffer data, byte... bytes ) {
        data.position(0);
        while( data.remaining() > 0 ) {
            data.put(bytes);
        }
    }

    /**
     *  Writes the specified tile to the target image 1024x1024 image data.
     */
    private void writeTileToImage( TerrainImage terrain, ByteBuffer data, int xTarget, int yTarget ) {

        int pos = xTarget + yTarget * 1024;

        for( int y = 0; y < terrain.getSize(); y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < terrain.getSize(); x++ ) {
                short val = terrain.getElevation(x, y);
                int elev = val & 0x3ff;

                int type = terrain.getType(x, y);
                if( cellDebug ) {
                    if( x == 0 || y == 0 ) {
                        type = 96;
                    } else if( (x % 32) == 0 || (y % 32) == 0 ) {
                        type = 255;
                    }
                }

                // The bytes will be passed through as a float where 0 = 0
                // and 1 == 255.  So to fit our stuff in we have to break it up
                // appropriately.
                int hi = (int)(elev / 255);
                int lo = (int)(elev % 255);

                byte r = (byte)type;
                int light = terrain.getLight(x, y);
                byte g = (byte)((0.5 + (light / 32.0)) * 255);
                byte b = (byte)hi;
                byte a = (byte)lo;

                data.put(a).put(r).put(g).put(b);
                pos++;
            }
            pos += 1024 - terrain.getSize();
        }
    }

    private void writeBlankTileToImage( int size, ByteBuffer data, int xTarget, int yTarget ) {

        int pos = xTarget + yTarget * 1024;

        for( int y = 0; y < size; y++ ) {
            data.position(pos * 4);
            for( int x = 0; x < size; x++ ) {
                data.put((byte)0).put((byte)0).put((byte)0).put((byte)0);
                pos++;
            }
            pos += 1024 - size;
        }
    }

    @Override
    protected void cleanup( Application app ) {
    }

    @Override
    protected void onEnable() {
        ((SimpleApplication)getApplication()).getRootNode().attachChild(root);
    }

    @Override
    protected void onDisable() {
        root.removeFromParent();
    }

    boolean continuous = false;

    @Override
    public void update( float tpf ) {
        if( posRef.update() ) {
            Vec3d pos = posRef.get();

            if( continuous ) {
                hiresLayer.setPosition(pos);
                hiresLayer.setMaskCenter(pos, maskCenter.get());

                waterLayer.setPosition(pos);
                waterLayer.setMaskCenter(pos, maskCenter.get());
            } else {
                // Else the position will be the world position of the
                // column and then we'll shift the geometry by the difference.
                // This means the look of the mesh won't update except when
                // we cross column boundaries.
                Vec3d columnPos = ColumnId.fromWorld(pos).getWorld(null).toVec3d();

                // If we use the raw column position then we will never be centered
                // over the fan center... so we'll adjust it by half a column
                columnPos.x += 16;
                columnPos.z += 16;

                if( xzLockedCamera ) {
                    Vec3d offset = pos.subtract(columnPos);
                    root.setLocalTranslation((float)-offset.x, 0, (float)-offset.z);
                } else {
                    // Just offset for the layer offset we build in to keep the
                    // fan 'centered' over the current cell
                    root.setLocalTranslation((float)16, 0, (float)16);
                }

                hiresLayer.setPosition(columnPos);
                hiresLayer.setMaskCenter(columnPos, maskCenter.get());

                waterLayer.setPosition(columnPos);
                waterLayer.setMaskCenter(columnPos, maskCenter.get());
            }
        }

        if( fogSettingsRef != null && fogSettingsRef.update() ) {
            resetFog();
        }
    }

    @Override
    public void render( RenderManager rm ) {
        Vec3d pos = posRef.get();
        if( continuous ) {
            hiresLayer.setMaskCenter(pos, maskCenter.get());
            waterLayer.setMaskCenter(pos, maskCenter.get());
        } else {
            // Mask center may have changed so we need the latest to avoid
            // flashing.
            Vec3d columnPos = ColumnId.fromWorld(pos).getWorld(null).toVec3d();
            // If we use the raw column position then we will never be centered
            // over the fan center... so we'll adjust it by half a column
            columnPos.x += 16;
            columnPos.z += 16;
            hiresLayer.setMaskCenter(columnPos, maskCenter.get());
            waterLayer.setMaskCenter(columnPos, maskCenter.get());
        }
    }

    /**
     *  Manages the central hi-resolution fan and the 2x2 texture setup
     *  that underpins it.
     */
    private class HiresLayer implements TileListener {

        private Material material;
        private Vector2f terrainOffset = new Vector2f();
        private Vector3f maskOffset = new Vector3f();

        private TerrainImageType type;
        private HiresImageTile[][] imageTiles = new HiresImageTile[2][2];

        private Grid subGrid = new Grid(512, 0, 512);
        private Vec3i gridCenter = new Vec3i();
        private Vec3i lastCorner = new Vec3i();
        private Map<String, HiresImageTile> tileCache = new HashMap<>();
        private Geometry center;
        private Geometry ring;
        private float spatialOffset = 0;

        private int radials;
        private double minStep;
        private double growth;

        private Vec3i minCorner = new Vec3i();
        private Vec3i maxCorner = new Vec3i();

        public HiresLayer( TerrainImageType type, int radials, double minStep, double growth ) {

            this.type = type;
            this.radials = radials;
            this.minStep = minStep;
            this.growth = growth;

            boolean water = type == TerrainImageType.Fluid;

            // A hires local tile

            // Nearest fan has different distribution to optimize for the local grid
            Mesh fan = new FanMeshBuilder().far(32).radials(radials/2)
                                .minStep(minStep).growthFactor(growth).build();

            Geometry geom = center = new Geometry("hiresFan", fan);
            LayerComparator.setLayer(geom, water ? 2 : 1);

            geom.center();
            geom.setModelBound(new BoundingBox(new Vector3f(-10000, -100, -10000), new Vector3f(10000, 10000, 10000)));
            root.attachChild(geom);

            fan = new FanMeshBuilder().near(32).far(512).radials(radials)
                                .minStep(minStep).growthFactor(growth).build();

            geom = ring = new Geometry("hiresFan", fan);
            LayerComparator.setLayer(geom, water ? 2 : 1);
            geom.center();
            geom.setModelBound(new BoundingBox(new Vector3f(-10000, -100, -10000), new Vector3f(10000, 10000, 10000)));
            root.attachChild(geom);

            updateMaterial(getMaterialFactory());

            world.addTileListener(this);
        }

        public double getVisualRadius( Vec3d pos ) {
            // See if we are even in the box... and calculate our base offset
            if( pos.x < minCorner.x || pos.x >= maxCorner.x
                || pos.z < minCorner.z || pos.z >= maxCorner.z ) {
                return 0;
            }

            // The farthest a blank can ever be is the nearest edge of the grid
            double xDist = Math.min(pos.x - minCorner.x, maxCorner.x - pos.x);
            double zDist = Math.min(pos.z - minCorner.z, maxCorner.z - pos.z);
            return Math.min(xDist, zDist);
        }

        public double getNearestBlankDistance( Vec3d pos ) {

            // What is the farthest distance we can ever have that wouldn't show
            // blank space anyway.
            double minDist = getVisualRadius(pos);
            if( minDist == 0 ) {
                // We aren't even in the grid at the moment
                return 0;
            }

            // The grid is 2x2 tiles but internally we treat it like a 512x512 grid
            // for the purposes of transitioning.  I don't think we care about that here
            // but it does limit what the maximum returned value should be.  I think we
            // kind of treat it like a 3x3 grid of 512 where we just have an extra 512 loaded
            // all the time.

            // subgrid is our 512z512 grid and here we are figuring out what the
            // min/max tiles are.
            Vec3i world = subGrid.cellToWorld(gridCenter.x+1, 0, gridCenter.z+1);
            Vec3i max = TileId.GRID.worldToCell(world.toVec3d());
            world = subGrid.cellToWorld(gridCenter.x-1, 0, gridCenter.z-1);
            Vec3i min = TileId.GRID.worldToCell(world.toVec3d());

            TileId posTile = TileId.fromWorld(pos);
            Vec3i base = posTile.getWorld(null);
            Vec3i offset = pos.subtract(base.add(TileId.SIZE/2, 0, TileId.SIZE/2)).floor();

            // The max distance we will ever be to empty space is the
            // distance to the nearest edge of the tile space.
            double minDistSq = minDist * minDist;

            for( int i = 0; i < 2; i++ ) {
                for( int j = 0; j < 2; j++ ) {
                    HiresImageTile tile = imageTiles[i][j];
                    if( tile != null && tile.rendered ) {
                        continue;
                    }

                    TileId id;
                    if( tile == null ) {
                        // We don't even have a tile yet so we need to know
                        // what tile we would be in if there was one.
                        Vec3i cell = new Vec3i(min.x + i, min.y, min.z + j);
                        id = TileId.fromCell(cell.x, cell.y, cell.z);
                    } else {
                        id = tile.tileId;
                    }

                    if( posTile.equals(id) ) {
                        // We are standing in an unrendered tile
                        return 0;
                    }

                    // Get the center to center distance from our home tile
                    Vec3i delta = id.getWorld(null).subtractLocal(base);
                    if( delta.x != 0 ) {
                        delta.x -= offset.x;
                    }
                    if( delta.z != 0 ) {
                        delta.z -= offset.z;
                    }
                    double dSq = delta.lengthSq();
                    if( dSq < minDistSq ) {
                        minDistSq = dSq;
                    }
                }
            }

            return Math.sqrt(minDistSq);
        }

        public void setSpatialOffset( float spatialOffset ) {
            this.spatialOffset = spatialOffset;
            resetOffset();
        }

        protected void resetOffset() {
            Vector3f loc = center.getLocalTranslation();
            loc.y = spatialOffset;
            center.setLocalTranslation(loc);

            loc = ring.getLocalTranslation();
            loc.y = spatialOffset;
            ring.setLocalTranslation(loc);
        }

        public void updateMaterial( Function<TerrainImageType, Material> materialFactory ) {
            Material mat = material = materialFactory.apply(type);

            if( fogSettings != null ) {
                fogSettings.apply(mat);
            }

            mat.setVector2("TerrainOffset", terrainOffset);
            material.setFloat("TerrainSize", 1024f);
            mat.getAdditionalRenderState().setWireframe(wireframe);

            updateViewMask();

            material.setTexture("DiffuseMap1", emptyTexture);
            material.setTexture("DiffuseMap2", emptyTexture);
            material.setTexture("DiffuseMap3", emptyTexture);
            material.setTexture("DiffuseMap4", emptyTexture);


            setUpnessRange(horizontalLimit, verticalLimit);

            if( center != null ) {
                center.setMaterial(material);
                ring.setMaterial(material);
            }
        }

        public void updateViewMask() {
            if( viewMask != null ) {
                material.setTexture("MaskArray", viewMask.getMaskTextures());
                material.setVector3("MaskOffset", maskOffset);
                material.setFloat("ViewMaskRadiusXZ", viewMask.getViewRadius().x);
                material.setFloat("ViewMaskRadiusY", viewMask.getViewRadius().y);
            }
        }

        public void setUpnessRange( float min, float max ) {
            // They both use the same material so we only have to change one
            if( min < max ) {
                material.setFloat("HorizontalLimit", min);
                material.setFloat("VerticalLimit", max);
            } else {
                material.setFloat("HorizontalLimit", min);
                material.setFloat("VerticalLimit", min + 0.0001f);
            }
        }

        public void setEnabled( boolean enabled ) {
            if( enabled ) {
                if( center.getParent() == null ) {
                    root.attachChild(center);
                    root.attachChild(ring);
                }
            } else {
                center.removeFromParent();
                ring.removeFromParent();
            }
        }

        public int getTriangleCount() {
            return center.getTriangleCount() + ring.getTriangleCount();
        }

        public void setRadials( int radials ) {
            this.radials = radials;
        }

        public void setMinStep( double minStep ) {
            this.minStep = minStep;
        }

        public void setGrowth( double growth ) {
            this.growth = growth;
        }

        public void regenerateMesh() {
            Mesh fan = new FanMeshBuilder().far(32).radials(radials/2)
                                .minStep(minStep).growthFactor(growth).build();
            center.setMesh(fan);
            center.center();
            center.setModelBound(new BoundingBox(new Vector3f(-10000, -100, -10000), new Vector3f(10000, 10000, 10000)));
            fan = new FanMeshBuilder().near(32).far(512).radials(radials)
                                .minStep(minStep).growthFactor(growth).build();
            ring.setMesh(fan);
            ring.center();
            ring.setModelBound(new BoundingBox(new Vector3f(-10000, -100, -10000), new Vector3f(10000, 10000, 10000)));

            resetOffset();
        }

        public void setLightingEnabled( boolean lightingEnabled ) {
            // They both use the same material so we only have to change one
            center.getMaterial().setFloat("LocalLightStrength", lightingEnabled ? 0.8f : 0);
        }

        public void setWireframe( boolean wireframe ) {
            // They both use the same material so we only have to change one
            center.getMaterial().getAdditionalRenderState().setWireframe(wireframe);
        }

        @Override
        public void tileChanged( TileChangeEvent event ) {
            if( event.getResolution() != Resolution.High ) {
                return;
            }
            if( log.isDebugEnabled() ) {
                log.debug("Terrain changed:" + event);
            }
            TileId id = event.getTileId();
            long version = event.getDataVersion();
            for( HiresImageTile it : tileCache.values() ) {
                if( it.tileId.getId() == id.getId() ) {
                    if( it.isOlderThan(version) && !workers.isQueued(it) ) {
                        // During the first startup, we get a change event for the creation
                        // of the tile and we will double build the image because our
                        // original build hasn't completed yet.  This is a very special
                        // case but I'm not sure it's worth checking for... but it's also
                        // easy.
                        // FIXME: See if the above is still true... I think probably not
                        if( version == 0 ) {
                            continue;
                        }
                        if( log.isTraceEnabled() ) {
                            log.trace("Updating:" + it);
                        }
                        if( priorityWorkers == workers ) {
                            // Then we really are queueing it
                            it.queued = true;
                            // else there is no reason to mark it queued because it
                            // won't be in the one we try to remove it from
                        }
                        // Higher priority than anything else
                        priorityWorkers.execute(it, -1);
                    }
                }
            }
        }

        public void setPosition( Vec3d pos ) {
            updateTerrainTiles(pos);

            Vec3i world = TileId.GRID.cellToWorld(lastCorner);
            //System.out.println("World corner:" + world);

            // Fan vertexes run 0..1024
            // our 2x2 grid runs from world to world + 2048
            // I think texture offset needs to be pos - world... that's
            // the center of our fan in the texture space.
            // The shader can then figure out which texture to use per
            // fragment and per vertex.
            // Bonus: we never had to have any overlap.
            //
            // Math is something like:
            // texCoord = modelPos + textureOffset - 512 (could build the -512 into the offset)
            //
            // Then to actually look it up:
            // texIndex = floor(textCoord.y/1024) * 2 + floor(texCoord.x / 1024);
            // uv = mod(texCoord.x, 1024), mod(texCoord.y, 1024)
            //terrainOffset.x = (float)(pos.x - 512 - world.x);
            //terrainOffset.y = (float)(pos.z - 512 - world.z);
            //terrainOffset.x = (float)(pos.x - world.x);
            //terrainOffset.y = (float)(pos.z - world.z);
            // Hmm... paging is right but the -512 shifts the visible terrain by
            // a lot.  I wonder if it's because of our fan shift.
            // When the fan center at 512, 512 we render it at center 0,0.
            // So visualization 0,0 is 512, 512 in fan space.
            // The thing is, with the -512 thing above, the fan was accurate...
            // it just wasn't rendered in the "scene" where we expected.
            // Without the -512 thing, our paging doesn't load in time if we go
            // in positive directions.
            // 5 in world space should be -1024 to 1024 in tile space.
            // 512 + 5 in fan space.
            // 1024 + 5 in texture space.
            //
            // mmm... normally the fans were -512 to 512 as this fan us but they
            // were also a tile over that span.  I think to put things in the same
            // place I've added a 512 somewhere.
            // Yep, it was built into the database.  Now far terrain is wrong but
            // I'm ok with that.  Near terrain is working and paging!

            terrainOffset.x = (float)(pos.x - 512 - world.x);
            terrainOffset.y = (float)(pos.z - 512 - world.z);
        }

        public void setMaskCenter( Vec3d pos, Vec3i center ) {
            //Vec3i world = TileId.getGrid().cellToWorld(lastCorner);

            // Our fan mesh is generated with the center at 512, 512.
            // That represents 'pos'.  The corner of the 'space' is defined
            // by the tile's corner... so pos - world is the 'mesh relative'
            // position.  The terrain offset takes another 512 out but I think
            // that's because of the 1024 space that it's really representing.
            //
            // In the case of the mask texture, if pos is 5 then our center is
            // 0.  Tile corner is also 0... we want an offset of 5.
            //

            maskOffset.x = (float)(center.x - pos.x) + 512;
            //maskOffset.y = (float)(center.y - 64);
            maskOffset.y = (float)(center.y);
            maskOffset.z = (float)(center.z - pos.z) + 512;

            // So then in the shader, (modelSpacePos - maskOffset) / 32 should
            // be our mask texture coordinate.
        }

        protected void updateTerrainTiles( Vec3d pos ) {
            Vec3i sg = subGrid.worldToCell(pos, null);
            if( !tileCache.isEmpty() && sg.x == gridCenter.x && sg.z == gridCenter.z ) {
                return;
            }
            gridCenter.set(sg.x, 0, sg.z);

            //System.out.println("Grid center:" + gridCenter);

            // Reload the tiles
            Vec3i world = subGrid.cellToWorld(gridCenter.x+1, 0, gridCenter.z+1);
            Vec3i max = TileId.GRID.worldToCell(world.toVec3d());
            world = subGrid.cellToWorld(gridCenter.x-1, 0, gridCenter.z-1);
            Vec3i min = TileId.GRID.worldToCell(world.toVec3d());

            // Keep track of the bounding corners
            TileId.fromCell(min).getWorld(minCorner);
            TileId.fromCell(max).getWorld(maxCorner);
            maxCorner.addLocal(TileId.SIZE, 0, TileId.SIZE);

            if( !tileCache.isEmpty() && min.equals(lastCorner) ) {
                return;
            }
            lastCorner.set(min);

            if( log.isTraceEnabled() ) {
                log.trace("min:" + min + "  max:" + max);
            }

            TileId centerTile = TileId.fromWorld(pos);

            for( int i = 0; i < 2; i++ ) {
                for( int j = 0; j < 2; j++ ) {
                    Vec3i cell = new Vec3i(min.x + i, min.y, min.z + j);
                    String key = cell.x + "x" + cell.z;
                    TileId id = TileId.fromCell(cell.x, cell.y, cell.z);
                    HiresImageTile imageTile = tileCache.remove(key);
                    if( imageTile == null ) {
                        imageTile = new HiresImageTile(type, id, key, material, emptyTexture, cell.x, cell.y, cell.z);

                        if( log.isTraceEnabled() ) {
                            log.trace("Executing:" + imageTile);
                        }

                        // For now these should be the very highest priority but
                        // none is particularly better than any other in a 2x2 grid.
                        // "Missing" is always the highest priority.
                        // No, local terrain is now the highest priority.
                        //workers.execute(imageTile, 1000);
                        // 2021-11-01 - When I reordered the app states we get this
                        // showing up last because the local view dominates.  Really,
                        // we want to prioritize these higher than all but the nearest
                        // view... if we pretend we want to load in a 5x5 area before
                        // attempting these then that would still be (2*2) * 3 priority.
                        // In reality, we don't even want to let this app state fully
                        // come up until at least the base tiles are loaded... then
                        // we could lower this priority.
                        //workers.execute(imageTile, 13);
                        // I put the app state order back to the old way because
                        // of other potential glitches, I'm still going to leave the
                        // priority at least lower than the trees, etc.
                        if( !priorityWorkers.isQueued(imageTile) ) {
                            // No reason to queue it in the regular workers if it's
                            // already in the priority workers waiting... and the
                            // queues are actually the same then it also doesn't need to
                            // be requeued.
                            imageTile.queued = true;
                            // 2024-12-38 - giving the tile right under the player a higher
                            // priority than the others
                            int priority = basicPriorityLevel;
                            if( id.equals(centerTile) ) {
                                priority = highPriorityLevel;
                            }
                            workers.execute(imageTile, priority);
                        }
                    }
                    imageTiles[i][j] = imageTile;
                }
            }

            for( HiresImageTile tile : tileCache.values() ) {
                if( log.isTraceEnabled() ) {
                    log.trace("releasing:" + tile);
                }
                // Release any left overs because they aren't visible anymore
                tile.release();

                // By checking if it's already queued we should avoid
                // book-keeping overhead trying to remove something that
                // isn't even submitted.
                if( tile.queued ) {
                    // And cancel it if possible
                    if( !workers.cancel(tile) ) {
                        if( log.isDebugEnabled() ) {
                            log.debug("Tile job not canceled for:" + tile.tileId);
                        }
                    } else {
                        tile.queued = false;
                    }
                }

            }
            tileCache.clear();

            // Rebuild the cache for later... and set the material parameters
            for( int i = 0; i < 2; i++ ) {
                for( int j = 0; j < 2; j++ ) {
                    HiresImageTile tile = imageTiles[i][j];
                    tileCache.put(tile.key, tile);
                }
            }

            imageTiles[0][0].setParameter("DiffuseMap1");
            imageTiles[1][0].setParameter("DiffuseMap2");
            imageTiles[0][1].setParameter("DiffuseMap3");
            imageTiles[1][1].setParameter("DiffuseMap4");
        }
    }

    private class HiresImageTile implements Job {
        TileId tileId;
        String key;
        int xCell;
        int yCell;
        int zCell;
        //LayerDb<? extends TerrainLayer> db;
        //TerrainView db;
        TerrainImageType type;
        TerrainImage terrain;
        Material material;
        volatile DataVersion tileVersion;
        volatile Texture texture;
        volatile String parameter;
        volatile boolean visible = true;
        volatile boolean queued;

        // Has this ever been rendered... used for 'blank space' checking so
        // we can leave it true when we are re-rendering a tile.
        boolean rendered = false;

        public HiresImageTile( TerrainImageType type, TileId tileId, String key, Material material, Texture empty,
                                int xCell, int yCell, int zCell ) {
            if( log.isTraceEnabled() ) {
                log.trace("new HiresImageTile(" + tileId + ")");
            }
            this.type = type;
            this.tileId = tileId;
            this.key = key;
            this.material = material;
            this.texture = empty;
            this.xCell = xCell;
            this.yCell = yCell;
            this.zCell = zCell;
        }

        public boolean isOlderThan( long version ) {
            if( tileVersion == null ) {
                return true;
            }
            return tileVersion.getVersion() < version;
        }

        public void setParameter( String parameter ) {
            // set parameter and runOnUpdate are both called from
            // the same thread so there is no race condition.
            this.parameter = parameter;
            if( texture != null ) {
                material.setTexture(parameter, texture);
            }
        }

        public void release() {
            visible = false;
        }

        @Override
        public void runOnWorker() {
            // Once we're running, we aren't queued anymore
            queued = false;

            if( !visible ) {
                return;
            }
            terrain = world.getTerrainImage(TileId.fromCell(xCell, yCell, zCell), type, Resolution.High);
            tileVersion = terrain.getVersion().clone();
            if( log.isTraceEnabled() ) {
                log.trace("Refreshing tile:" + this + "  version:" + tileVersion);
            }
            texture = createTexture(terrain);
            //try {
            //    log.info("sleeping:" + tileId);
            //    Thread.sleep(3000);
            //} catch( InterruptedException e ) {
            //}
        }

        @Override
        public double runOnUpdate() {
            if( !visible ) {
                return 0;
            }
            if( parameter != null ) {
                material.setTexture(parameter, texture);
            }
            rendered = true;
            // This is never significant enough to hold up other jobs
            //return 1;
            // 2024-05-17: then why did I put it at a giant score of 1?
            return 0;
        }

        @Override
        public String toString() {
            return "HiresImageTile[" + xCell + ", " + zCell + "]";
        }
    }
}

