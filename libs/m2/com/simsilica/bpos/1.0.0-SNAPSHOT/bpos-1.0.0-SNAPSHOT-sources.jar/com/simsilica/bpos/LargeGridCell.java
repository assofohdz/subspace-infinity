/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.bpos;

import com.simsilica.es.*;
import com.simsilica.mathd.*;

/**
 *  For entities with the LargeObject component, this indicates
 *  which cell of the large grid they are in which can be used for
 *  better client-side filtering.
 *
 *  @author    Paul Speed
 */
public class LargeGridCell implements EntityComponent {

    @IndexedField
    private long cellId;

    private LargeGridCell() {
    }

    public LargeGridCell( long cellId ) {
        this.cellId = cellId;
    }

    public static ComponentFilter<LargeGridCell> cellFilter( long cellId ) {
        return Filters.fieldEquals(LargeGridCell.class, "cellId", cellId);
    }

    public static LargeGridCell create( Grid grid, double x, double y, double z ) {
        return create(grid, new Vec3d(x, y, z));
    }

    public static LargeGridCell create( Grid grid, Vec3d location ) {
        Vec3i cell = grid.worldToCell(location);
        return new LargeGridCell(grid.cellToId(cell.x, cell.y, cell.z));
    }

    public long getCellId() {
        return cellId;
    }

    @Override
    public String toString() {
        return "LargeGridCell[" + cellId + "]";
    }
}


