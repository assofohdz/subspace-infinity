/*
 * $Id$
 * 
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in 
 *    the documentation and/or other materials provided with the 
 *    distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its 
 *    contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.bpos;

import com.simsilica.mathd.trans.*;
import com.simsilica.mathd.Quatd;
import com.simsilica.mathd.Vec3d;

import com.simsilica.es.EntityId;

/**
 *  Extends the normal PositionTransition3D to also include
 *  a non-interpolated parent ID.
 *
 *  @author    Paul Speed
 */
public class ChildPositionTransition3d extends PositionTransition3d {
    private EntityId startParent;
    private EntityId endParent;

    public ChildPositionTransition3d( long endTime, EntityId endParent, Vec3d endPos, Quatd endRot, boolean visible ) {
        super(endTime, endPos, endRot, visible);
        this.endParent = endParent;
    }
 
    // Java doesn't like the change in return type for the static method over the
    // parent class... even though it doesn't really support inheritance of static
    // methods, it does error out.  So I've changed the name.  Unfortunate but still
    // easier than implementing a whole new transition objects from scratch just to 
    // add a parent.   
    public static TransitionBuffer<ChildPositionTransition3d> createChildBuffer( int history ) {
        return new TransitionBuffer<>(history);
    }
    
    @Override
    public void setPreviousTransition( PositionTransition3d previous ) {
        super.setPreviousTransition(previous);
        this.startParent = ((ChildPositionTransition3d)previous).endParent;
    }            
 
    public EntityId getParentId( long time, boolean clamp ) {
        if( startParent ==  null ) {
            return clamp ? endParent : null;
        }
        if( time < getStartTime() ) {
            return clamp ? startParent : null;
        }
        // No tweening... if we are within start and end time then
        // the startParent is the parent
        if( time < getEndTime() ) {
            return startParent;
        }
        // Else we are after end time and that always clamps
        return endParent;        
    }
    
    @Override
    public String toString() {
        return "ChildPositionTransition3d[ t:" + getStartTime() 
                                    + ", pos:" + getStartPosition() 
                                    + ", rot:" + getStartRotation() 
                                    + ", parent:" + startParent 
                                    + ", vis:" + getStartVisibility()
                                + " -> t:" + getEndTime() 
                                    + ", pos:" + getEndPosition() 
                                    + ", rot:" + getEndRotation() 
                                    + ", parent:" + endParent 
                                    + ", vis:" + getEndVisibility() 
                                    + " ]";
    } 
    
}

