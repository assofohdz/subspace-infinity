/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.namegen;

import java.util.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Branches implements java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(Branches.class);
    private static final long serialVersionUID = 42;

    private ClusterPair parent;
    private Map<Cluster, Integer> next = new TreeMap<>();
    private int total;
    private boolean hasTerminator;

    private Branches() {
        // For serialization that requires a no-arg constructor
    }

    public Branches( ClusterPair parent ) {
        this.parent = parent;
    }

    public ClusterPair getParent() {
        return parent;
    }

    public boolean hasTerminator() {
        return hasTerminator;
    }

    public void addNext( Cluster c ) {
        if( c.getType() == ClusterType.End ) {
            this.hasTerminator = true;
        }
        Integer val = next.get(c);
        if( val == null ) {
            next.put(c, 1);
        } else {
            next.put(c, val + 1);
        }
        total++;
    }

    public Map<Cluster, Integer> getChildren() {
        return next;
    }

    public Cluster getNext( double index ) {
        int skip = (int)(index * total);
        for( Map.Entry<Cluster, Integer> entry : next.entrySet() ) {
            skip -= entry.getValue();
            if( skip < 0 ) {
                return entry.getKey();
            }
        }
        return null;
    }

    public Cluster getNext( double index, boolean skipTerminator ) {
        int skip = (int)(index * total);
        for( Map.Entry<Cluster, Integer> entry : next.entrySet() ) {
            skip -= entry.getValue();
            if( skipTerminator && entry.getKey().getType() == ClusterType.End ) {
                continue;
            }
            if( skip < 0 ) {
                return entry.getKey();
            }
        }
        if( skipTerminator ) {
            // Find the first non-terminator
            for( Map.Entry<Cluster, Integer> entry : next.entrySet() ) {
                if( entry.getKey().getType() != ClusterType.End ) {
                    return entry.getKey();
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "[parent:" + parent + ", numChildren:" + next.size() + "]";
    }
}


