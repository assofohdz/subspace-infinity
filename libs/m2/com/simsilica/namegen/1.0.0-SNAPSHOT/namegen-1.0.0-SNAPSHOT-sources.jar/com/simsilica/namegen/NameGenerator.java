/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.namegen;

import java.io.*;
import java.util.*;
import java.util.zip.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class NameGenerator implements java.io.Serializable {
    static Logger log = LoggerFactory.getLogger(NameGenerator.class);

    private static final long serialVersionUID = 42;

    private static final Cluster START = new Cluster("^", ClusterType.Start);
    private static final Cluster END = new Cluster("$", ClusterType.End);

    private int minClusters = Integer.MAX_VALUE;
    private int maxClusters = 0;

    private Map<ClusterPair, Branches> branchIndex = new HashMap<>();
    private Branches rootBranches;

    public NameGenerator() {
        // An easy way to avoid some extra logic is to have a starter
        // branches that's just start, start... so all starting clusters have
        // a branches to start from.
        this.rootBranches = getBranches(START, START, true);
    }

    public int getMinClusters() {
        return minClusters;
    }

    public int getMaxClusters() {
        return maxClusters;
    }

    public void train( String text ) {
        List<Cluster> clusters = Cluster.toClusters(text);
        if( clusters.size() < 2 ) {
            // It's possible to have a word that is a single cluster but it's
            // not useful for generation because it will always just regurgitate
            // the actual word.  Think 'eau'.  If there aren't any other words that
            // start with 'eau' then we'll always randomly generate that exact word
            // if we select that root.  And if there ARE other words then that cluster
            // is covered but we also don't want to ever terminate there.
            // At least the hope is that we rarely spit out training text directly,
            // though it can happen.
            return;
        }
        this.minClusters = Math.min(minClusters, clusters.size());
        this.maxClusters = Math.max(maxClusters, clusters.size());

        Cluster lastCluster = START;
        Branches lastBranches = rootBranches;

        for( Cluster cluster : clusters ) {
            lastBranches.addNext(cluster);
            lastBranches = getBranches(lastCluster, cluster, true);
            lastCluster = cluster;
        }

        if( lastCluster != START ) {
            // Terminate the word
            lastBranches.addNext(END);
        }
    }

    public List<Cluster> generateWord( int minLength, int maxLength, Random rand ) {
        List<Cluster> result = new ArrayList<>();
        List<Branches> back = new ArrayList<>();
        int size = 0;
        for( Branches branches = rootBranches; branches != null; ) {
            if( size >= maxLength ) {
                if( branches.hasTerminator() ) {
                    break;
                }
                log.warn("Exceeding max length:" + maxLength + " because there is no terminator for:" + branches + " result so far:" + Cluster.toWords(result));
                // See if we can back up.
                // Note: another option would have been to jump back just one and try to shorten
                // the current cluster to see if we find a match.  For example, B-a-rr-o-wcl might not
                // find a terminator but B-a-rr-o-w probably would.  As it stands, when we back up
                // we end up at B-a-rr-o... which isn't awful.
                int pushback = 0;
                for( int i = back.size() - 1; i >= minLength; i-- ) {
                    Branches b = back.get(i);
                    log.info("Trying to pushback with:" + b);
                    if( b.hasTerminator() ) {
                        // We found an earlier ending that would have worked
                        log.info("returning:" + Cluster.toWords(result.subList(0, result.size() - pushback)));
                        return result.subList(0, result.size() - pushback);
                    }
                    pushback++;
                }
            }
            double roll = rand.nextDouble();
            Cluster best = branches.getNext(roll, size < minLength);
            if( best == null ) {
                log.warn("Failed to getNext(" + roll + ", " + (size < minLength) + ") for:" + branches);

                // Try it as a root
                Cluster originalSecond = branches.getParent().getSecond();
                branches = getBranches(START, originalSecond, false);
                if( branches == null ) {
                    log.warn("No root branches either for:" + originalSecond);
                    System.out.println("No root branches either for:" + originalSecond);
                    break;
                }
                best = branches.getNext(roll, size < minLength);
                if( best == null ) {
                    log.warn("Failed to getNext(" + roll + ", " + (size < minLength) + ") for:" + branches);
                    System.out.println("Failed to getNext(" + roll + ", " + (size < minLength) + ") for:" + branches);
                    break;
                }
            }
            if( best.getType() == ClusterType.End ) {
                break;
            }
            result.add(best);
            size++;

            // Get the next branches
            Branches newBranches = getBranches(branches.getParent().getSecond(), best, false);
            if( newBranches == null ) {
                log.warn("Premature end, missing branches for:" + branches.getParent().getSecond() + ", " + best);
                System.out.println("Premature end, missing branches for:" + branches.getParent().getSecond() + ", " + best);
                result.add(new Cluster("BAD", ClusterType.End));
                break;
            }
            branches = newBranches;
            back.add(branches);
        }
        return result;
    }

    public List<Cluster> getMostPopular() {
        List<Cluster> result = new ArrayList<>();
        Set<Branches> visited = new HashSet<>();
        for( Branches branches = rootBranches; branches != null; ) {
            if( !visited.add(branches) ) {
                log.warn("Detected loop at:" + branches);
                System.out.println("Detected loop at:" + branches);
                break;
            }
            Cluster best = null;
            int max = 0;
            for( Map.Entry<Cluster, Integer> child : branches.getChildren().entrySet() ) {
                if( child.getValue() > max ) {
                    best = child.getKey();
                    max = child.getValue();
                }
            }
            // And because I'm curious
            int similar = 0;
            for( Map.Entry<Cluster, Integer> child : branches.getChildren().entrySet() ) {
                if( child.getValue() == max ) {
                    similar++;
                }
            }
            if( similar > 1 ) {
                System.out.println(similar + " similar to:" + best);
            }

            if( best.getType() == ClusterType.End ) {
                break;
            }
            result.add(best);
            Branches nextBranches = getBranches(branches.getParent().getSecond(), best, false);
            if( nextBranches == null ) {
                log.warn("Premature end, missing branches for:" + branches.getParent().getSecond() + ", " + best);
                System.out.println("Premature end, missing branches for:" + branches.getParent().getSecond() + ", " + best);
            }
            branches = nextBranches;
        }
        return result;
    }

    protected Branches getBranches( Cluster first, Cluster second, boolean create ) {
        ClusterPair key = new ClusterPair(first, second);
        Branches branches = branchIndex.get(key);
        if( branches == null && create ) {
            branches = new Branches(key);
            branchIndex.put(key, branches);
        }
        return branches;
    }

    // Temporary
    public void write( File f ) throws Exception {
        FileOutputStream fOut = new FileOutputStream(f);
        GZIPOutputStream zOut = new GZIPOutputStream(fOut);
        BufferedOutputStream bOut = new BufferedOutputStream(zOut, 16384);
        try( ObjectOutputStream out = new ObjectOutputStream(bOut) ) {
            out.writeObject(this);
        }
    }

    public static NameGenerator read( File f ) throws Exception {
        return read(new FileInputStream(f));
    }

    public static NameGenerator read( InputStream inStream ) throws Exception {
        GZIPInputStream zIn = new GZIPInputStream(inStream);
        BufferedInputStream bIn = new BufferedInputStream(zIn, 16384);
        try( ObjectInputStream in = new ObjectInputStream(bIn) ) {
            return (NameGenerator)in.readObject();
        }
    }
}


