/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.namegen;

import java.util.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class Cluster implements Comparable<Cluster>, java.io.Serializable  {
    static Logger log = LoggerFactory.getLogger(Cluster.class);
    private static final long serialVersionUID = 42;

    private String letters;
    private ClusterType type;

    private Cluster() {
        // For serialization that requires a no-arg constructor
    }

    public Cluster( String letters, ClusterType type ) {
        this.letters = letters;
        this.type = type;
    }

    public String getLetters() {
        return letters;
    }

    public ClusterType getType() {
        return type;
    }

    public static List<Cluster> toClusters( String phrase ) {
        List<Cluster> results = new ArrayList<>();

        ClusterType lastType = ClusterType.Start;
        int len = phrase.length();
        StringBuilder current = new StringBuilder();
        for( int i = 0; i < len; i++ ) {
            char c = phrase.charAt(i);
            ClusterType type = ClusterType.getType(c);
            if( type == lastType ) {
                current.append(c);
            } else {
                // Only add real clusters
                if( lastType != ClusterType.Start ) {
                    results.add(new Cluster(current.toString(), lastType));
                }
                // But always capture the character
                current.setLength(0);
                current.append(c);
            }
            lastType = type;
        }
        // Follow-up with any remaining open cluster
        if( current.length() > 0 ) {
            results.add(new Cluster(current.toString(), lastType));
        }
        return results;
    }

    public static String toWords( List<Cluster> clusters ) {
        StringBuilder sb = new StringBuilder();
        for( Cluster cluster : clusters ) {
            if( cluster.type != ClusterType.Start ) {
                sb.append(cluster.letters);
            }
        }
        return sb.toString();
    }

    public int compareTo( Cluster other ) {
        int i = letters.compareTo(other.letters);
        if( i != 0 ) {
            return i;
        }
        return type.compareTo(other.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, letters);
    }

    @Override
    public boolean equals( Object o ) {
        if( o == this ) {
            return true;
        }
        if( o == null || o.getClass() != getClass() ) {
            return false;
        }
        Cluster other = (Cluster)o;
        if( other.type != type ) {
            return false;
        }
        if( !Objects.equals(other.letters, letters) ) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "['" + letters + "', " + type + "]";
    }
}

