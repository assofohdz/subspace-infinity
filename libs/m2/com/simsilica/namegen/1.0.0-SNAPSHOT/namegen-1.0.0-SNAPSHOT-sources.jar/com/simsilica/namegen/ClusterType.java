/*
 * $Id$
 *
 * Copyright (c) 2025, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.namegen;

import java.util.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public enum ClusterType {
    Start,
    End,
    Vowel,
    Consonant,
    Y,
    Space,
    Special;

    private static final Set<Character> VOWELS = new HashSet<>(Arrays.asList(
        (char)'A', (char)'E', (char)'I', (char)'O', (char)'U'
    ));
    // Hard-coded for now
    private static final Set<Character> SPECIAL = new HashSet<>(Arrays.asList(
        (char)'`', (char)'-'
    ));

    private ClusterType() {
    }

    public static ClusterType getType( char c ) {
        if( c == ' ' ) {
            return Space;
        }
        if( SPECIAL.contains(c) ) {
            return Special;
        }
        char upper = Character.toUpperCase(c);
        if( upper == 'Y' ) {
            return Y;
        }
        if( VOWELS.contains(upper) ) {
            return Vowel;
        }
        return Consonant;
    }
}


