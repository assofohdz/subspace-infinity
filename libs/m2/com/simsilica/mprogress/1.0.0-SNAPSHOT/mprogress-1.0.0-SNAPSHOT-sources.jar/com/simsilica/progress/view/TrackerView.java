/*
 * $Id$
 *
 * Copyright (c) 2023, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.progress.view;

import java.util.*;
import java.util.function.Predicate;

import org.slf4j.*;

import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial.CullHint;
import com.jme3.util.SafeArrayList;

import com.simsilica.lemur.*;
import com.simsilica.lemur.component.*;
import com.simsilica.lemur.core.*;
import com.simsilica.lemur.style.*;

import com.simsilica.progress.*;
import com.simsilica.progress.ProgressTrackers.ThreadTrackers;

/**
 *  A standard panel for viewing all of the ongoing threaded progress.
 *
 *  @author    Paul Speed
 */
public class TrackerView extends Container {
    static Logger log = LoggerFactory.getLogger(TrackerView.class);

    public static final String ELEMENT_ID = "tracker";

    private ElementId rootElementId;
    private VersionedReference<Collection<ThreadTrackers>> trackerRef;
    private Map<Thread, ThreadView> threadViews = new LinkedHashMap<>();
    private boolean expandOnly = true;
    private boolean alwaysShowDefault = true;
    private float minLabelWidth = 0;
    private boolean forceUpdate = true;

    private Label defaultLabel;
    private ProgressBar defaultProgress; // just for visual spacing

    private Predicate<Thread> mainThreadFilter;

    public TrackerView() {
        this(true, new ElementId(ELEMENT_ID), null);
    }

    protected TrackerView( boolean applyStyles, ElementId elementId, String style ) {
        super(null, false, elementId.child("container"), style);

        this.rootElementId = elementId;
        this.trackerRef = ProgressTrackers.createReference();

        Styles styles = GuiGlobals.getInstance().getStyles();
        if( applyStyles ) {
            styles.applyStyles(this, getElementId(), style);
        }

        defaultLabel = new Label("", elementId.child("thread.title"), style);
        defaultProgress = new ProgressBar(elementId.child("thread.progress"), style);
    }

    /**
     *  Sets a predicate that will be used to determine if a thread is the main
     *  thread or not for special styling.  If null then all threads are treated the same.
     */
    public void setMainThreadFilter( Predicate<Thread> mainThreadFilter ) {
        this.mainThreadFilter = mainThreadFilter;
    }

    public Predicate<Thread> getMainThreadFilter() {
        return mainThreadFilter;
    }

    public void setDefaultText( String text ) {
        defaultLabel.setText(text);
    }

    public String getDefaultText() {
        return defaultLabel.getText();
    }

    public boolean isEmpty() {
        return threadViews.isEmpty();
    }

    public void setExpandOnly( boolean expandOnly ) {
        this.expandOnly = expandOnly;
    }

    public boolean getExpandOnly() {
        return expandOnly;
    }

    public void setAlwaysShowDefault( boolean alwaysShowDefault ) {
        this.alwaysShowDefault = alwaysShowDefault;
    }

    public boolean getAlwaysShowDefault() {
        return alwaysShowDefault;
    }

    public void setMinLabelWidth( float minLabelWidth ) {
        this.minLabelWidth = minLabelWidth;
    }

    public float getMinLabelWidth() {
        return minLabelWidth;
    }

    public void updateLogicalState( float tpf ) {
        if( trackerRef.update() || forceUpdate ) {
            updateThreadTrackers(trackerRef.get());
        }
        super.updateLogicalState(tpf);
    }

    protected ElementId threadViewElementId( Thread thread ) {
        if( mainThreadFilter == null || mainThreadFilter.test(thread) ) {
            return rootElementId.child("thread");
        }
        return rootElementId.child("background.thread");
    }

    protected void updateThreadTrackers( Collection<ThreadTrackers> trackers ) {
        if( log.isTraceEnabled() ) {
            log.trace("updateThreadTrackers() size:" + trackers.size());
        }
        //log.info("trackers:" + trackers);
        boolean rebuildChildren = false;
        for( ThreadTrackers tracker : trackers ) {
            if( log.isTraceEnabled() ) {
                log.trace("  checking:" + tracker + " isEmpty():" + tracker.isEmpty());
            }
            if( tracker.isEmpty() ) {
                ThreadView view = threadViews.remove(tracker.getThread());
                if( view != null ) {
                    rebuildChildren = true;
                }
            } else {
                ThreadView view = threadViews.get(tracker.getThread());
                if( view == null ) {
                    view = new ThreadView(tracker, threadViewElementId(tracker.getThread()), getStyle());
                    threadViews.put(tracker.getThread(), view);
                    rebuildChildren = true;
                }
                view.updateChildren();
            }
        }
        if( rebuildChildren ) {
            clearChildren();
            for( ThreadView view : threadViews.values() ) {
                addChild(view);
            }
            if( threadViews.isEmpty() && alwaysShowDefault ) {
                addChild(defaultLabel);
                addChild(defaultProgress);
            }
        }
    }

    private class ThreadView extends Container {
        private ThreadTrackers trackers;
        private ElementId mainId;
        private Label mainTitle;
        private Container children;
        private ProgressView main;
        private SafeArrayList<ProgressView> views = new SafeArrayList<>(ProgressView.class);

        public ThreadView( ThreadTrackers trackers, ElementId elementId, String style ) {
            super(null, elementId.child("container"), style);
            this.mainId = elementId;
            this.trackers = trackers;
            main = new ProgressView(null, elementId, style);
            main.label = addChild(new Label("", elementId.child("title"), style));
            addChild(main.bar);
            children = addChild(new Container(new SpringGridLayout(Axis.Y, Axis.X, FillMode.None, FillMode.Last)));
        }

        public void updateChildren() {
            if( log.isTraceEnabled() ) {
                log.trace("updateChildren() ProgressTracker main:" + main.tracker);
            }
            boolean first = true;
            int index = 0;
            ProgressView last = main;
            for( ProgressTracker progress : trackers ) {
                if( log.isTraceEnabled() ) {
                    log.trace("    :" + progress);
                }
                if( first ) {
                    main.updateTracker(progress);
                    first = false;
                } else {
                    ProgressView view;
                    if( index < views.size() ) {
                        // We already have a view... so just make sure it's up to date
                        view = views.get(index);
                        view.updateTracker(progress);
                    } else {
                        // Else we need to add one
                        view = new ProgressView(progress, mainId.child("child"), getStyle());
                        views.add(view);
                        children.addChild(view.label);
                        children.addChild(view.bar, 1);
                    }
                    last.setChild(view);
                    last = view;
                    index++;
                }
            }
            last.setChild(null);
            if( views.size() > index ) {
                // We need to remove the rest
                boolean rebuildChildren = false;
                for( int i = index; i < views.size(); i++ ) {
                    if( expandOnly ) {
                        // Leave it in the list
                        views.get(i).updateTracker(null);
                    } else {
                        views.remove(i);
                        rebuildChildren = true;
                    }
                }
                if( rebuildChildren ) {
                    children.clearChildren();
                    for( ProgressView view : views ) {
                        children.addChild(view.label);
                        children.addChild(view.bar, 1);
                    }
                }
            }
        }

        public void updateLogicalState( float tpf ) {
            main.update();
            for( ProgressView view : views.getArray() ) {
                view.update();
            }
            super.updateLogicalState(tpf);
        }
    }

    private class ProgressView {
        private ProgressTracker tracker;
        private Label label;
        private ProgressBar bar;
        private VersionedReference<ProgressTracker> ref;
        private boolean invalid;
        private ProgressView child;
        private double childAdd = 0;
        private double lastValue = 0;

        public ProgressView( ProgressTracker tracker, ElementId elementId, String style ) {
            this.label = new Label("", elementId.child("label"), style);
            this.bar = new ProgressBar(elementId.child("progress"), style);
            if( log.isTraceEnabled() ) {
                log.trace("ProgressView.label ID:" + label.getElementId() + "  bar ID:" + bar.getElementId());
            }
            updateTracker(tracker);
        }

        protected void updateTracker( ProgressTracker tracker ) {
            if( this.tracker == tracker ) {
                return;
            }
            this.tracker = tracker;
            if( tracker != null ) {
                this.ref = tracker.createReference();
                bar.setCullHint(CullHint.Inherit);
            } else {
                this.ref = null;
                bar.setCullHint(CullHint.Always);
            }
            childAdd = 0;
            lastValue = 0;
            invalid = true;
        }

        protected void setChild( ProgressView child ) {
            if( this.child == child ) {
                return;
            }
            this.child = child;
        }

        public void update() {
            if( invalid || (ref != null && ref.update()) ) {
                invalid = false;
                if( tracker == null ) {
                    label.setText("");
                    bar.getModel().setPercent(0);
                } else {
                    if( !Objects.equals(label.getText(), tracker.getName()) ) {
                        if( minLabelWidth > 0 ) {
                            label.setPreferredSize(null);
                        }
                        label.setText(tracker.getName());
                        if( minLabelWidth > 0 ) {
                            Vector3f pref = label.getPreferredSize();
                            pref.x = Math.max(minLabelWidth, pref.x);
                            label.setPreferredSize(pref);
                        }
                    }
                }
                if( child == null ) {
                    // Only update this when we know our own progress is updating
                    // to minimize the chance of progress moving backwards.
                    childAdd = 0;
                    // The case we're trying to fix here is when one
                    // frame had childAdd almost at 1 but then suddenly the child
                    // gets closed but our own tracker might not have been incremented
                    // just yet.
                }
            }
            if( tracker == null ) {
                return;
            }
            double val = tracker.getProgress();
            if( child != null ) {
                childAdd = child.tracker.getPercent();
            }
            val = (val + childAdd) / tracker.getMax();
            // Only allow moving forward... it shouldn't happen but since it
            // will look much worse than it is, we will hide it if it does happen.
            if( val > lastValue ) {
                bar.getModel().setPercent(val);
                lastValue = val;
            }
        }
    }
}


