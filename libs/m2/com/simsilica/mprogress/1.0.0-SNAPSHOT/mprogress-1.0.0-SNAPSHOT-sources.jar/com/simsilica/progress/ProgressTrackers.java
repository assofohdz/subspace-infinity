/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.progress;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

// Note: once finalized, this is a candidate for SiO2.
// FIXME: move to SiO2

/**
 *  Manages the active ProgresTracker objects for the application's
 *  threads.
 *
 *  @author    Paul Speed
 */
public class ProgressTrackers {
    static Logger log = LoggerFactory.getLogger(ProgressTrackers.class);

    private static ConcurrentHashMap<Thread, ThreadTrackers> trackedThreads = new ConcurrentHashMap<>();
    private static List<ThreadTrackers> trackersList = new CopyOnWriteArrayList<>();
    private static ThreadLocal<ThreadTrackers> threadTrackers = new ThreadLocal<ThreadTrackers>() {
            @Override
            protected ThreadTrackers initialValue() {
                ThreadTrackers trackers = new ThreadTrackers();
                trackedThreads.put(trackers.thread, trackers);
                trackersList.add(trackers);
                return trackers;
            }

            @Override
            public void remove() {
                ThreadTrackers trackers = get();
                // If tracker was from this thread then remove it
                if( trackers.thread == Thread.currentThread() ) {
                    if( log.isTraceEnabled() ) {
                        log.trace("Clearing inherited trackers:" + trackers);
                    }
                    trackedThreads.remove(trackers.thread);
                    trackersList.remove(trackers);
                }
                // Otherwise, it was an inherited tracker.
                super.remove();
            }
        };

    private static AtomicLong version = new AtomicLong();
    private static Holder versionedObject = new Holder();

    private ProgressTrackers() {
    }

    public static ProgressTracker openTracker( String name ) {
        return threadTrackers.get().openTracker(name);
    }

    public static void close( ProgressTracker tracker ) {
        threadTrackers.get().close(tracker);

        // Check other threads in case it we inherited
        for( ThreadTrackers trackers : trackersList ) {
            if( trackers.hasTracker(tracker) ) {
                trackers.close(tracker);
            }
        }

        //if( threadTrackers.get().isEmpty() ) {
        //    threadTrackers.remove();
        //}
    }

    public static Collection<ThreadTrackers> getThreadTrackers() {
        //return Collections.unmodifiableCollection(trackedThreads.values());
        return Collections.unmodifiableCollection(trackersList);
    }

    /**
     *  Allows one thread to inherit the tracker management from a different thread, usually at the start
     *  of work so that this one becomes the new parent.
     */
    public static void inheritThreadTrackers( ThreadTrackers trackers ) {
        if( trackers == null ) {
            // Make sure the current tracker is actually from another thread
            if( threadTrackers.get().thread == Thread.currentThread() ) {
                throw new IllegalStateException("Cannot clear a thread's own native trackers");
            }
            threadTrackers.remove();
            return;
        }
        if( threadTrackers.get().isEmpty() ) {
            // Then fine
            threadTrackers.set(trackers);
        } else {
            throw new IllegalStateException("This thread already has active trackers");
        }
    }

    public static ThreadTrackers getThreadTrackers( Thread thread ) {
        if( thread == null ) {
            // Return the current thread's trackers
            return threadTrackers.get();
        }
        return trackedThreads.get(thread);
    }

    public static VersionedReference<Collection<ThreadTrackers>> createReference() {
        return versionedObject.createReference();
    }

    public static class ThreadTrackers implements Iterable<ProgressTracker> {
        private Thread thread;
        // This will only be modified from one thread but we
        // will likely want to read it from other threads.
        // ...and with inheritable trackers, it can be modified from other threads, too.
        private List<ProgressTracker> trackers = new CopyOnWriteArrayList<>();

        // With some tweaking we could aggregate a thread's trackers into
        // one progress value if we assume that each tracker in the stack is
        // treating 1.0 as a single 'unit of work'.  So if there is a nested
        // tracker then that's part of the parent's 1.0 unit.
        // Iterating the list backwards:
        //    overall = (tracker.progress + overall) / tracker.max;
        //
        // At each level, 'overall' is a value from 0..1 representing the
        // overall progress at that level.

        public ThreadTrackers() {
            this.thread = Thread.currentThread();
        }

        public Thread getThread() {
            return thread;
        }

        public Iterator<ProgressTracker> iterator() {
            return Collections.unmodifiableCollection(trackers).iterator();
        }

        public boolean isEmpty() {
            return trackers.isEmpty();
        }

        public void inherit( ProgressTracker tracker ) {
            trackers.add(tracker);
        }

        private ProgressTracker openTracker( String name ) {
            if( log.isTraceEnabled() ) {
                log.trace("openTracker(" + name + ") thread:" + thread + "  currentThread:" + Thread.currentThread());
            }
            ProgressTracker tracker = new ProgressTracker(name);
            trackers.add(tracker);
            version.incrementAndGet();
            return tracker;
        }

        private boolean hasTracker( ProgressTracker tracker ) {
            return trackers.contains(tracker);
        }

        private void close( ProgressTracker tracker ) {
            int index = trackers.indexOf(tracker);
            if( index < 0 ) {
                throw new IllegalArgumentException("Specified tracker is not open:" + tracker);
            }
            //if( index != (trackers.size() - 1) ) {
            //    log.error("Removing tracker:" + tracker + " that is not the top of the stack:" + trackers.get(trackers.size()-1));
            //}
            // trackers.remove(index);
            // Now that we allow inheriting trackers across threads, the above isn't a good check
            // anymore and an index-based removal is also not a great idea because things could have moved.
            trackers.remove(tracker);
            version.incrementAndGet();
        }

        @Override
        public String toString() {
            return "ThreadTrackers[thread:" + thread + ", trackers:" + trackers + "]";
        }
    }

    private static class Holder implements VersionedObject<Collection<ThreadTrackers>> {
        @Override
        public long getVersion() {
            return version.get();
        }

        @Override
        public Collection<ThreadTrackers> getObject() {
            return getThreadTrackers();
        }

        @Override
        public VersionedReference<Collection<ThreadTrackers>> createReference() {
            return new VersionedReference<>(this);
        }
    }
}


