/*
 * $Id$
 *
 * Copyright (c) 2021, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.progress;

import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.*;

import com.simsilica.lemur.core.VersionedObject;
import com.simsilica.lemur.core.VersionedReference;

// Note: once finalized, this is a candidate for SiO2.
// FIXME: move to SiO2

/**
 *  The status/progress of a particular task.
 *
 *  @author    Paul Speed
 */
public class ProgressTracker implements VersionedObject<ProgressTracker> {
    static Logger log = LoggerFactory.getLogger(ProgressTracker.class);

    private String name;
    private volatile double max;
    private volatile double progress;
    private AtomicLong version = new AtomicLong(0);
    private boolean closed;

    public ProgressTracker( String name ) {
        if( log.isTraceEnabled() ) {
            log.trace("creating:" + name +  " this:" + this);
        }
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public long getVersion() {
        return version.get();
    }

    @Override
    public ProgressTracker getObject() {
        return this;
    }

    @Override
    public VersionedReference<ProgressTracker> createReference() {
        return new VersionedReference<>(this);
    }

    public void setMax( double max ) {
        this.max = max;
    }

    public double getMax() {
        return max;
    }

    public void setProgress( double progress ) {
        if( this.progress == progress ) {
            return;
        }
        this.progress = progress;
        if( log.isTraceEnabled() ) {
            log.trace(name + ":setProgress(" + progress + ")  " + String.format("%.02f", getPercent() * 100));
        }
        version.incrementAndGet();
    }

    public double getProgress() {
        return progress;
    }

    public double increment() {
        return add(1);
    }

    public double add( double delta ) {
        setProgress(progress + delta);
        return progress;
    }

    public double getPercent() {
        if( max == 0 ) {
            return 0;
        }
        return progress / max;
    }

    public void close( boolean done ) {
        if( log.isTraceEnabled() ) {
            log.trace("close(" + done + "):" + name +  " this:" + this);
        }
        if( closed ) {
            return;
        }
        if( done && progress < max ) {
            setProgress(max);
        }
        ProgressTrackers.close(this);
        closed = true;
    }

    public boolean isClosed() {
        return closed;
    }

    @Override
    public String toString() {
        return "ProgressTracker[name:" + name + ", progress:" + progress + ", max:" + max + "]";
    }
}
