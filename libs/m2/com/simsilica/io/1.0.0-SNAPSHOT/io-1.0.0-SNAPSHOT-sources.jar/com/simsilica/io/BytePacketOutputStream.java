/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;

/**
 *  An output stream that writes to discrete packets of byte[] arrays.
 *  This is similar to ByteArrayOutputStream except that instead of collecting
 *  bytes into one giant array, it will break the array up into packet byte[]
 *  arrays based on a maximum size.
 *
 *  @author    Paul Speed
 */
public class BytePacketOutputStream extends OutputStream {
    static Logger log = LoggerFactory.getLogger(BytePacketOutputStream.class);

    private int maxPacketSize;
    private List<byte[]> packets = new ArrayList<>();
    private int totalBytes;

    // Even though it means extra copying of byte[] data, we will
    // use ByteArrayOutputStream to build the current packet.  It already
    // has the necessary array sizing stuff and we'd rather not always allocate
    // maxPacketSize.
    private ByteArrayOutputStream currentPacket;
    private int currentPacketSize;

    public BytePacketOutputStream( int maxPacketSize ) {
        this.maxPacketSize = maxPacketSize;
        this.currentPacket = new ByteArrayOutputStream();
    }

    public int getBytesWritten() {
        return totalBytes;
    }

    public byte[][] toPackets() {
        return packets.toArray(new byte[0][]);
    }

    protected void newPacket() {
        packets.add(currentPacket.toByteArray());
        currentPacket = new ByteArrayOutputStream();
        currentPacketSize = 0;
    }

    public void close() throws IOException {
        currentPacket.close();
        if( currentPacketSize > 0 ) {
            packets.add(currentPacket.toByteArray());
        }
    }

    public void write( int b ) {
        // This is the easy one
        if( currentPacketSize == maxPacketSize ) {
            newPacket();
        }
        currentPacket.write(b);
        currentPacketSize++;
        totalBytes++;
    }

    public void write( byte b[], int off, int len ) {

        // Potentially write some of the buffer to the last packet
        // and some to the next and so on
        while( len > 0 ) {
            if( currentPacketSize == maxPacketSize ) {
                newPacket();
            }
            int toWrite = Math.min(len, maxPacketSize - currentPacketSize);
            currentPacket.write(b, off, toWrite);

            off += toWrite;
            len -= toWrite;
            currentPacketSize += toWrite;
            totalBytes += toWrite;
        }
    }

}
