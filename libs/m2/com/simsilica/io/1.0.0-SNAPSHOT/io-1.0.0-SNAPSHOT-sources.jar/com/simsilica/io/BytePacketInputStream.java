/*
 * $Id$
 *
 * Copyright (c) 2024, Simsilica, LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.simsilica.io;

import java.io.*;
import java.util.*;

import org.slf4j.*;

/**
 *
 *
 *  @author    Paul Speed
 */
public class BytePacketInputStream extends InputStream {
    static Logger log = LoggerFactory.getLogger(BytePacketInputStream.class);

    private final byte[][] packets;
    private final int totalSize;

    private int nextPacketIndex = 0;
    private byte[] currentPacket;
    private int packetOffset;
    private int bytesRead;

    public BytePacketInputStream( byte[][] packets ) {
        this.packets = packets;
        int size = 0;
        for( byte[] packet : packets ) {
            size += packet.length;
        }
        this.totalSize = size;
        nextPacket();
    }

    public void close() {
        // Force it to the end
        bytesRead = totalSize;
    }

    public int available() {
        return totalSize - bytesRead;
    }

    protected void nextPacket() {
        if( nextPacketIndex == packets.length ) {
            // We're out of packets
            currentPacket = null;
            return;
        }
        currentPacket = packets[nextPacketIndex++];
        packetOffset = 0;
    }

    public int read() {
        if( bytesRead >= totalSize ) {
            return -1;
        }
        if( packetOffset == currentPacket.length ) {
            nextPacket();
        }
        bytesRead++;
        return currentPacket[packetOffset++] & 0xff;
    }

    public int read( byte b[], int off, int len ) {
        if( b == null ) {
            throw new NullPointerException();
        } else if( off < 0 || len < 0 || len > b.length - off ) {
            throw new IndexOutOfBoundsException();
        }
        if (len <= 0) {
            return 0;
        }
        if( bytesRead >= totalSize ) {
            return -1;
        }

        int result = 0;
        while( len > 0 ) {
            if( packetOffset == currentPacket.length ) {
                nextPacket();
            }
            if( currentPacket == null ) {
                break;
            }

            // How many bytes are left in this packet
            int toCopy = Math.min(len, currentPacket.length - packetOffset);
            System.arraycopy(currentPacket, packetOffset, b, off, toCopy);

            packetOffset += toCopy;
            off += toCopy;
            len -= toCopy;
            bytesRead += toCopy;
            result += toCopy;
        }

        return result;
    }


}
